const INIT = JSON.parse(document.getElementById('init').textContent);
const LOI = INIT.loi || {};
const PAGE_NAME = 'Vòng Trầm Hương Sơn Mộc Hương .';
window.__ev = [];
const lan1 = {}; // đếm lần bấm để gây lỗi "lần 1 không ăn"
const BEN = ['dangReelLan1', 'videoLan1']; // đếm qua cả các lần tải lại trang
const boQuaLan1 = (k) => { if (!LOI[k]) return false; if (BEN.includes(k)) { lan1[k] = +(localStorage.getItem('__l1_' + k) || 0) + 1; localStorage.setItem('__l1_' + k, lan1[k]); } else lan1[k] = (lan1[k] || 0) + 1; if (lan1[k] <= (LOI[k] === true ? 1 : LOI[k])) { window.__ev.push('BOQUA:' + k); return true; } return false; };
const KM = !!INIT.kieuMoi; // kiểu Facebook của Máy Giao: soạn bài + cài đặt + nhóm nằm CHUNG 1 hộp; tiêu đề bước là hộp mỏng riêng
function setHdr(t) {
  if (!KM) return;
  document.querySelectorAll('.hdrdlg').forEach((h) => { if (h.textContent.trim() === t) h.removeAttribute('aria-hidden'); else h.setAttribute('aria-hidden', 'true'); });
  if (![...document.querySelectorAll('.hdrdlg')].some((h) => h.textContent.trim() === t)) { const h = el('<div role="dialog" class="hdrdlg" style="position:fixed;top:5px;left:300px;width:500px;height:60px;background:#fff">' + t + '</div>'); document.body.appendChild(h); }
}
function xoaHdr() { document.querySelectorAll('.hdrdlg').forEach((h) => h.remove()); }
function el(h) { const d = document.createElement('div'); d.innerHTML = h.trim(); return d.firstElementChild; }
// ---- menu tài khoản
document.getElementById('acc').onclick = () => {
  if (INIT.menuHong) return;
  if (boQuaLan1('accLan1')) return;
  const ex = document.getElementById('accmenu'); if (ex) { ex.remove(); return; }
  document.body.appendChild(el('<div role="dialog" id="accmenu" style="position:fixed;top:60px;left:10px;background:#fff;width:300px;height:80px"><a href="/me/">' + (INIT.saiTuCach ? 'Nguoi Khac' : PAGE_NAME) + '</a></div>'));
};
// ---- bài trên trang
function wireCmt(art, pid, idx) {
  art.querySelectorAll('.clk').forEach((b) => b.onclick = () => {
    const nhanGo = b.getAttribute('aria-label') === 'Thích' ? 'Gỡ Thích' : 'Gỡ Thích bình luận';
    if (window.__dbLike) window.__dbLike({ id: pid, kind: 'cmt', idx });
    if (INIT.cmtVeLai) setTimeout(() => { const n = art.cloneNode(true); n.querySelectorAll('.clk').forEach((x) => x.setAttribute('aria-label', nhanGo)); const c = document.createElement('span'); c.textContent = ' 1 cảm xúc'; n.appendChild(c); wireCmt(n, pid, idx); art.replaceWith(n); }, 250);
    else b.setAttribute('aria-label', nhanGo);
  });
}
function hdrText(p) {
  const cx = p.dataset.cx || '', tag = p.dataset.tag === '1';
  return PAGE_NAME + (cx ? ' đang cảm thấy ' + cx : '') + (tag ? ' cùng với Sơn Mộc Hương' : '') + (p.dataset.reel === '1' ? (cx || tag ? ' tại Sơn Mộc Hương.' : ' đang ở Sơn Mộc Hương.') : '');
}
function wireBasic(p) {
  const lk = p.querySelector('.lk');
  const dots = p.querySelector('.dots');
  if (dots) dots.onclick = () => {
    if (boQuaLan1('menuDotsLan1')) return;
    if (document.getElementById('pmenu')) return;
    const m = el('<div role="menu" id="pmenu" style="position:fixed;top:100px;left:100px;width:220px;height:60px;background:#fff"><div role="menuitem" style="height:30px">Chỉnh sửa bài viết</div></div>');
    document.body.appendChild(m);
    m.querySelector('[role=menuitem]').onclick = () => { m.remove(); if (p.dataset.reel === '1') openEditReel(p); else openEdit(p); };
  };
  if (lk) lk.onclick = () => { if (window.__dbLike) window.__dbLike({ id: p.dataset.id, kind: 'post' }); lk.setAttribute('aria-label', 'Gỡ Thích'); };
  const bt = p.querySelector('.bt');
  if (bt) bt.onclick = () => { const dl = el('<div role="dialog" style="position:fixed;top:200px;left:20px;width:200px;height:60px;background:#fff"><div role="button" aria-label="Yêu thích" style="width:50px;height:30px">y</div></div>'); document.body.appendChild(dl); dl.querySelector('div').onclick = () => { if (window.__dbLike) window.__dbLike({ id: p.dataset.id, kind: 'post' }); lk.setAttribute('aria-label', 'Gỡ Yêu thích'); dl.remove(); }; };
  p.querySelectorAll('[role=article]').forEach((a, i) => wireCmt(a, p.dataset.id, i));
  const oc = p.querySelector('.opencm');
  if (oc) oc.onclick = () => { p.querySelector('.cms').innerHTML = oc.dataset.cms; p.querySelector('.cw').innerHTML = oc.dataset.cw; oc.remove(); wirePost(p); };
  const h = p.querySelector('.hdr'); if (h) h.textContent = hdrText(p);
}
function wirePost(p) {
  wireBasic(p);
  const ed = p.querySelector('div[contenteditable]'); const form = p.querySelector('form'); const inp = form && form.querySelector('input[type=file]');
  if (!ed || !form || !inp) return;
  ed.addEventListener('paste', (e) => { e.preventDefault(); const t = e.clipboardData.getData('text/plain'); document.execCommand('insertText', false, t); });
  let attached = null;
  inp.addEventListener('change', () => {
    if (!inp.files.length) return;
    if (boQuaLan1('anhLan1')) { inp.value = ''; return; } // Facebook không nhận ảnh lần đầu
    const f = inp.files[0]; attached = f;
    setTimeout(() => {
      const pv = el('<div class="pv"><img style="width:100px;height:100px;display:block"><div role="button" aria-label="Gỡ ảnh" style="width:20px;height:20px">x</div></div>');
      pv.querySelector('img').src = URL.createObjectURL(f);
      pv.querySelector('[aria-label="Gỡ ảnh"]').onclick = () => { attached = null; pv.remove(); inp.value = ''; };
      form.parentElement.appendChild(pv);
    }, 900);
    window.__ev.push('cmtfile:' + f.name + ':' + f.size + ':' + f.type);
  });
  const gui = () => {
    const txt = ed.innerText.trim();
    const hasImg = !!attached && !!form.parentElement.querySelector('[aria-label="Gỡ ảnh"]');
    if (!txt && !hasImg) return false;
    if (!txt && hasImg && INIT.enterAnhKhongGui) return false;
    const pid = p.dataset.id; const fAtt = attached;
    setTimeout(() => {
      const art = el('<div role="article"><span class="ct"></span><div role="button" aria-label="Thích bình luận của Sơn Mộc" class="clk" style="width:60px;height:20px">Thích</div></div>');
      art.querySelector('.ct').textContent = txt;
      if (hasImg) { const im = document.createElement('img'); im.style.cssText = 'width:80px;height:80px;display:block'; art.insertBefore(im, art.firstChild); im.src = URL.createObjectURL(fAtt); }
      wireCmt(art, pid, p.querySelectorAll('[role=article]').length);
      p.querySelector('.cms').appendChild(art);
      window.__dbComment({ id: pid, message: txt, anh: hasImg });
      window.__ev.push('cmt:' + (hasImg ? 'ANH' : 'TEXT') + ':' + txt.slice(0, 20));
      if (INIT.treo) document.querySelectorAll('div[contenteditable][aria-label^="Bình luận"]').forEach((x) => x.remove());
    }, 500);
    ed.innerHTML = ''; const pv = form.parentElement.querySelector('.pv'); if (pv) pv.remove(); attached = null; inp.value = '';
    return true;
  };
  ed.addEventListener('keydown', (e) => {
    if (e.key !== 'Enter') return;
    if (boQuaLan1('enterLan1')) return; // Enter lần đầu không ăn
    if (gui()) e.preventDefault();
  });
  const nutGui = form.querySelector('.gui'); if (nutGui) nutGui.onclick = () => gui();
}
document.querySelectorAll('.post').forEach(wirePost);
function postHtml(id, text, nImg) {
  return '<div class="post" data-id="' + id + '" style="margin:100px 0;border:1px solid #ccc"><div class="txt"></div><div class="imgs"></div>'
    + '<div role="button" aria-label="Thích" class="lk" style="width:60px;height:20px">Thích</div><div role="button" aria-label="Bày tỏ cảm xúc" class="bt" style="width:60px;height:20px">x</div>'
    + '<div role="button" class="dots" aria-label="Hành động đối với bài viết này của Vòng Trầm Hương Sơn Mộc Hương ." style="width:30px;height:20px">...</div><div class="cms"></div><div class="cw"><form><div contenteditable="true" data-lexical-editor="true" aria-label="Bình luận dưới tên ' + PAGE_NAME + '" style="min-height:30px;border:1px solid #999"></div><input type="file" accept="image/*,video/*"><div role="button" aria-label="Bình luận" class="gui" style="width:30px;height:20px">></div></form></div></div>';
}
// ---- hộp soạn bài
let comp = null;
const promptBtn = Array.from(document.querySelectorAll('[role=button]')).find((b) => b.innerText === 'Bạn đang nghĩ gì?');
promptBtn.onclick = () => { if (INIT.soanHong) { window.__ev.push('SOAN_HONG'); return; } if (boQuaLan1('soanLan1')) return; openComposer(); };
const anhBtn = Array.from(document.querySelectorAll('[role=button]')).find((b) => b.innerText === 'Ảnh/video');
if (anhBtn) anhBtn.onclick = () => { window.__ev.push('MO_ANHVIDEO'); openComposer(); };
function openComposer() {
  if (document.getElementById('cmp')) return;
  const st = { files: [], loc: false, ticked: new Set(Array.from({ length: INIT.preTicked }, (_, i) => i)), text: '' };
  comp = st;
  const d = el('<div role="dialog" id="cmp" style="position:fixed;top:20px;left:300px;width:700px;height:900px;background:#fff;overflow:auto"></div>');
  d.innerHTML = '<div>Tạo bài viết</div><div aria-label="Đóng hộp thoại của công cụ tạo" role="button" style="width:30px;height:30px">x</div>'
    + '<div id="who">' + PAGE_NAME + '<span id="locs"></span></div>'
    + '<div contenteditable="true" data-lexical-editor="true" aria-label="Bạn đang nghĩ gì?" style="min-height:120px;border:1px solid #999"></div>'
    + '<div id="prev"></div><input type="file" accept="image/*,video/*" multiple>'
    + '<div role="button" aria-label="Hiển thị các tùy chọn phông nền" id="aa0" style="width:30px;height:30px">Aa</div><div id="swh"></div>'
    + '<div role="button" aria-label="Vị trí" style="width:60px;height:30px">Vị trí</div><div role="button" aria-label="Tiếp" style="width:60px;height:30px">Tiếp</div>';
  if (KM) { d.innerHTML = '<div id="paneC">' + d.innerHTML + '</div>'; d.style.height = '600px'; } document.body.appendChild(d); setHdr('Tạo bài viết');
  d.querySelector('#aa0').onclick = () => { d.querySelector('#swh').innerHTML = '<div role="button" aria-label="Đỏ đậm, màu nền, phông nền 2" style="width:30px;height:30px">r</div>'; d.querySelector('#swh [role=button]').onclick = () => { st.red = true; }; };
  const ed = d.querySelector('[data-lexical-editor]');
  ed.addEventListener('paste', (e) => { e.preventDefault(); document.execCommand('insertText', false, e.clipboardData.getData('text/plain')); });
  const prev = d.querySelector('#prev'); const inp = d.querySelector('input[type=file]');
  const redraw = () => {
    prev.innerHTML = '';
    st.files.forEach((f) => { const im = document.createElement('img'); im.style.cssText = 'width:200px;height:200px;display:inline-block'; im.src = URL.createObjectURL(f); prev.appendChild(im); });
    if (st.files.length) { const x = el('<div role="button" aria-label="Gỡ file đính kèm trong bài viết" style="width:30px;height:30px">x</div>'); x.onclick = () => { st.files = []; redraw(); }; prev.appendChild(x); }
  };
  inp.addEventListener('change', () => { const fs = Array.from(inp.files); window.__ev.push('compfiles:' + fs.map((f) => f.name + ':' + f.size + ':' + f.type).join(','));
    if (fs.some((f) => /^video\//.test(f.type))) { if (boQuaLan1('videoLan1') || (INIT.hongSize && fs[0].size === INIT.hongSize)) { inp.value = ''; return; } setTimeout(() => { st.video = fs[0]; prev.innerHTML = '<video style="width:200px;height:300px;display:block"></video><div>Đang kiểm tra nội dung có bản quyền</div>'; }, 1500); inp.value = ''; return; }
    setTimeout(() => { st.files = st.files.concat(fs); redraw(); }, 1200); inp.value = ''; });
  d.querySelector('[aria-label="Vị trí"]').onclick = () => {
    const L = el('<div role="dialog" id="locd" style="position:fixed;top:40px;left:320px;width:600px;height:500px;background:#fff"><div>Vị trí</div><input aria-label="Bạn đang ở đâu?" placeholder="Bạn đang ở đâu?" style="width:300px;height:30px"><ul id="res"></ul></div>');
    d.style.display = 'none'; document.body.appendChild(L);
    L.querySelector('input').addEventListener('input', () => {
      L.querySelector('#res').innerHTML = '<li role="option" style="height:40px"><div role="button" tabindex="0">Sơn Mộc Hương<br>Vạn Phúc, Thủ Đức</div></li>';
      L.querySelector('li [role=button]').onclick = () => { if (boQuaLan1('viTriLan1')) return; st.loc = true; L.remove(); d.style.display = ''; d.querySelector('#locs').textContent = ' đang ở Sơn Mộc Hương'; };
    });
  };
  d.querySelector('[aria-label="Tiếp"]').onclick = () => { if (boQuaLan1('tiepLan1')) return; if (st.video) openReelEdit(d, st, ed); else openSettings(d, st, ed); };
  d.querySelector('[aria-label="Đóng hộp thoại của công cụ tạo"]').onclick = () => { const c = el('<div role="dialog" style="position:fixed;top:300px;left:400px;width:300px;height:100px;background:#fff">Bỏ bài viết?<div role="button" style="width:60px;height:30px">Bỏ bài viết</div></div>'); document.body.appendChild(c); c.querySelector('[role=button]').onclick = () => { c.remove(); d.remove(); comp = null; }; };
}
const OFF = 'position:absolute;left:5000px;top:0;width:480px';
function openSettings(d, st, ed) {
  const paneC = () => d.querySelector('#paneC');
  if (KM) paneC().setAttribute('aria-hidden', 'true'); else d.style.display = 'none';
  if (KM) paneC().style.cssText = OFF;
  const S = KM ? el('<div id="set" style="width:480px"></div>') : el('<div role="dialog" id="set" style="position:fixed;top:20px;left:300px;width:700px;height:600px;background:#fff"></div>');
  if (KM) { setHdr('Cài đặt bài viết'); }
  const draw = () => {
    S.innerHTML = (KM ? '<div>Xem trước bài viết</div><div>' + ed.innerText.slice(0, 20) + '</div>' : '<div>Cài đặt bài viết</div>') + '<div role="button" aria-label="Đóng" style="width:20px;height:20px">x</div><div role="button" id="grp" style="height:40px"><span>Chia sẻ lên nhóm</span></div>' + (st.ticked.size ? '<div>Đã chọn ' + st.ticked.size + ' nhóm</div>' : '')
      + '<div role="button" aria-label="Đăng" style="width:80px;height:36px">Đăng</div>';
    S.querySelector('#grp').onclick = openGroups;
    S.querySelector('[aria-label="Đóng"]').onclick = () => { S.remove(); if (KM) { paneC().removeAttribute('aria-hidden'); paneC().style.cssText = ''; setHdr('Tạo bài viết'); } else d.style.display = ''; };
    S.querySelector('[aria-label="Đăng"]').onclick = () => {
      if (window.__ev.some((x) => x === 'lockclick')) return;
      if (boQuaLan1('dangLan1')) return; // nút Đăng lần đầu không ăn
      const text = ed.innerText.trim(); const nImg = st.files.length; const gs = st.ticked.size;
      window.__ev.push('DANG:' + gs + ' nhom:' + nImg + ' anh:loc=' + st.loc);
      const lam = () => {
        S.remove(); d.remove(); comp = null; xoaHdr();
        setTimeout(async () => {
          const id = await window.__dbPost({ text, nImg, nhom: gs, loc: st.loc, ts: Date.now(), files: st.files.map((f) => f.size), red: !!st.red });
          if (INIT.anBaiMoi) return; // bài mới không hiện trên trang chính (chỉ thấy qua API / link riêng)
          const p = el(postHtml(id, text, nImg)); p.querySelector('.txt').textContent = text;
          st.files.forEach((f) => { const im = document.createElement('img'); im.style.cssText = 'width:150px;height:150px;display:inline-block'; im.src = URL.createObjectURL(f); p.querySelector('.imgs').appendChild(im); });
          document.getElementById('feed').prepend(p); wirePost(p);
          if (INIT.reloadSauDang) setTimeout(() => location.reload(), 800);
        }, 2000);
      };
      if (INIT.hopPhu && nImg > 0 && document.getElementById('hphu')) return; // hộp phụ còn → Đăng không chạy
      if (INIT.hopPhu && nImg > 0 && !window.__hopPhuDa) { // Facebook chen hộp gợi ý "Chat trực tiếp với khách hàng" sau khi bấm Đăng bài có ảnh
        window.__hopPhuDa = true;
        const V = INIT.hopPhu;
        const H = V === 2 ? el('<div id="hphu" style="position:fixed;top:200px;left:400px;width:420px;height:260px;background:#fff">Gợi ý mới cho Trang của bạn<div>Thêm nút Nhắn tin</div><div role="button" id="lk" style="width:160px;height:30px">Không phải bây giờ</div><div role="button" id="tn" style="width:80px;height:30px">Thêm nút</div></div>')
          : V === 4 ? el('<div id="hphu" style="position:fixed;top:200px;left:400px;width:420px;height:260px;background:#fff">Hộp không có role<div>Bạn muốn đăng khi nào?</div><div style="width:160px;height:30px"><span id="lk">Lúc khác</span></div><div style="width:160px;height:30px"><span id="tn">Đăng ngay</span></div></div>')
          : V === 3 ? el('<div role="dialog" id="hphu" style="position:fixed;top:200px;left:400px;width:420px;height:260px;background:#fff">Hộp lạ không có nút an toàn<div role="button" id="lk" style="width:160px;height:30px">Tìm hiểu thêm</div><div role="button" id="tn" style="width:80px;height:30px">Thêm nút</div></div>')
          : el('<div role="dialog" id="hphu" style="position:fixed;top:200px;left:400px;width:420px;height:260px;background:#fff">Chat trực tiếp với khách hàng<div>Bạn có thể thêm nút "Gửi tin nhắn" vào bài viết</div><div role="button" id="lk" style="width:80px;height:30px">Lúc khác</div><div role="button" id="tn" style="width:80px;height:30px">Thêm nút</div></div>');
        document.body.appendChild(H); H.querySelector('#tn').onclick = () => { window.__ev.push('THEMNUT'); };
        H.querySelector('#lk').onclick = () => { H.remove(); lam(); }; return;
      }
      if (LOI.dangCham) { S.appendChild(el('<div role="progressbar">...</div>')); setTimeout(lam, 40000); } else lam();
    };
  };
  function openGroups() {
    if (KM) { S.setAttribute('aria-hidden', 'true'); S.style.cssText = OFF; setHdr('Chia sẻ lên nhóm'); } else S.style.display = 'none';
    const G = KM ? el('<div id="grpd" style="width:480px"></div>') : el('<div role="dialog" id="grpd" style="position:fixed;top:20px;left:300px;width:700px;height:700px;background:#fff;overflow:auto"></div>');
    const drawG = () => {
      G.innerHTML = (KM ? '<div>Chọn nhóm</div>' : '<div>Chia sẻ lên nhóm</div>') + '<div><label>Tắt <input type="checkbox" role="switch" aria-label="Tắt"></label></div>'
        + Array.from({ length: INIT.groups }, (_, i) => '<div role="listitem" style="height:36px"><span>Nhóm số ' + (i + 1) + '</span><input type="checkbox" data-i="' + i + '" ' + (st.ticked.has(i) ? 'checked' : '') + '></div>').join('')
        + '<div role="button" id="xong" style="width:60px;height:30px">Xong</div>';
      G.querySelectorAll('input[data-i]').forEach((c) => c.onchange = () => { const i = +c.dataset.i; if (c.checked) st.ticked.add(i); else st.ticked.delete(i); });
      G.querySelector('#xong').onclick = () => { G.remove(); if (KM) { S.removeAttribute('aria-hidden'); S.style.cssText = 'width:480px'; setHdr('Cài đặt bài viết'); } else S.style.display = ''; draw(); };
    };
    (KM ? d : document.body).appendChild(G); drawG();
  }
  (KM ? d : document.body).appendChild(S); draw();
}

function openEdit(p) {
  if (document.getElementById('edt')) return;
  const d = el('<div role="dialog" id="edt" style="position:fixed;top:20px;left:300px;width:700px;height:700px;background:#fff"></div>');
  let n = p.querySelectorAll('.imgs img').length, sw = false, red = false;
  const draw = () => {
    d.innerHTML = '<div>Chỉnh sửa bài viết</div><div>File phương tiện đã tải lên</div>' + Array.from({ length: n }, () => '<div class="pi">img<div role="button" aria-label="Gỡ ảnh" style="width:20px;height:20px">x</div></div>').join('')
      + (n ? '' : '<div role="button" aria-label="Hiển thị các tùy chọn phông nền" id="aa" style="width:30px;height:30px">Aa</div>') + (sw ? '<div role="button" aria-label="Đỏ đậm, màu nền, phông nền 2" id="sw" style="width:30px;height:30px">r</div>' : '') + '<div role="button" id="luu" style="width:60px;height:30px">Lưu</div>';
    d.querySelectorAll('[aria-label="Gỡ ảnh"]').forEach((b) => b.onclick = () => { n--; draw(); });
    const aa = d.querySelector('#aa'); if (aa) aa.onclick = () => { sw = true; draw(); };
    const s = d.querySelector('#sw'); if (s) s.onclick = () => { red = true; };
    d.querySelector('#luu').onclick = () => { if (boQuaLan1('luuNenLan1')) return; p.querySelector('.imgs').innerHTML = ''; if (red) p.classList.add('red'); window.__dbEdit({ id: p.dataset.id, nImg: n, red }); d.remove(); };
  };
  document.body.appendChild(d); draw();
}

// ---- màn "Chỉnh sửa thước phim" (reel)
const CAM_XUC = ['hạnh phúc', 'có phúc', 'được yêu', 'buồn', 'đáng yêu', 'biết ơn', 'hào hứng', 'đang yêu', 'điên', 'cảm kích', 'sung sướng', 'tuyệt vời', 'ngốc nghếch', 'vui vẻ', 'thư giãn', 'hân hoan', 'tích cực'];
function openEditReel(p) {
  if (document.getElementById('edr')) return;
  const goc = location.pathname;
  history.pushState(null, '', '/vongtramhuongsonmochuong/post/edit/' + p.dataset.id);
  const st = { tag: p.dataset.tag === '1', cx: p.dataset.cx || '' };
  const d = el('<div role="dialog" id="edr" style="position:fixed;top:20px;left:300px;width:800px;height:700px;background:#fff"></div>');
  const dong = () => { d.remove(); history.pushState(null, '', goc); };
  const draw = () => {
    d.innerHTML = '<div>Chỉnh sửa thước phim</div><div role="button" aria-label="Đóng" class="dong" style="width:20px;height:20px"><svg width="10" height="10"></svg></div>'
      + `<div role="button" class="ctag" style="width:120px;height:24px">${st.tag ? 'Sơn Mộc Hương' : 'Mọi người'}</div>`
      + '<div role="button" class="cloc" style="width:120px;height:24px">Sơn Mộc Hương</div><div role="button" style="width:120px;height:24px">Cộng tác viên</div>'
      + `<div role="button" class="ccx" style="width:160px;height:24px">${st.cx ? st.cx : 'Cảm xúc/hoạt động'}</div>`
      + '<div role="button" style="width:120px;height:24px">Thêm file khác</div><div role="button" style="width:120px;height:24px">Chỉnh sửa</div><div role="button" class="luu" style="width:60px;height:30px">Lưu</div>';
    d.querySelector('.dong').onclick = () => {
      const c = el('<div role="dialog" style="position:fixed;top:300px;left:400px;width:300px;height:100px;background:#fff">Rời khỏi trang?<div role="button" style="width:60px;height:30px">Rời khỏi</div></div>');
      document.body.appendChild(c); c.querySelector('[role=button]').onclick = () => { c.remove(); dong(); };
    };
    d.querySelector('.ctag').onclick = moThe;
    d.querySelector('.ccx').onclick = moCamXuc;
    d.querySelector('.luu').onclick = () => {
      if (boQuaLan1('luuLan1')) return;
      p.dataset.tag = st.tag ? '1' : ''; p.dataset.cx = st.cx;
      const h = p.querySelector('.hdr'); if (h) h.textContent = hdrText(p);
      window.__dbEdit({ id: p.dataset.id, tag: st.tag, cx: st.cx });
      dong();
    };
  };
  function moThe() {
    if (document.getElementById('tagd')) return;
    const T = el('<div role="dialog" id="tagd" style="position:fixed;top:60px;left:320px;width:500px;height:400px;background:#fff"><div>Gắn thẻ người khác</div><input aria-label="Tìm kiếm bạn bè" style="width:300px;height:30px"><ul id="tres"></ul><div id="tdu"></div><div role="button" class="xong" style="width:60px;height:30px">Xong</div></div>');
    document.body.appendChild(T);
    T.querySelector('input').addEventListener('input', () => {
      T.querySelector('#tres').innerHTML = '<li role="option" style="height:40px"><div role="none">Sơn Mộc Hương<br>Trang · Mua sắm</div></li>';
      T.querySelector('#tres [role=none]').onclick = () => { if (boQuaLan1('theLan1')) return; st.chonThe = true; T.querySelector('#tdu').innerHTML = '<span>Được gắn thẻ</span>'; };
    });
    T.querySelector('.xong').onclick = () => { if (st.chonThe) st.tag = true; T.remove(); setTimeout(draw, LOI.chipCham ? 3000 : 0); };
  }
  function moCamXuc() {
    if (document.getElementById('cxd')) return;
    const C = el('<div role="dialog" id="cxd" style="position:fixed;top:60px;left:320px;width:500px;height:500px;background:#fff;overflow:auto"><div>Bạn đang cảm thấy thế nào?</div><div role="button" aria-label="Quay lại" style="width:20px;height:20px">&lt;</div><ul role="listbox">' + CAM_XUC.map((x) => `<li role="option" style="height:24px"><div role="button">${x}</div></li>`).join('') + '</ul></div>');
    document.body.appendChild(C);
    C.querySelector('[aria-label="Quay lại"]').onclick = () => C.remove();
    C.querySelectorAll('li [role=button]').forEach((b) => b.onclick = () => { if (boQuaLan1('camXucLan1')) return; st.cx = b.innerText.trim(); C.remove(); setTimeout(draw, LOI.chipCham ? 3000 : 0); });
  }
  document.body.appendChild(d); draw();
}

// ===================== (6.0) THƯỚC PHIM: Chỉnh sửa thước phim → Cài đặt thước phim =====================
function openReelEdit(d, st, ed) {
  d.style.display = 'none';
  const T = el('<div role="dialog" id="rthe" style="position:fixed;top:20px;left:300px;width:700px;height:600px;background:#fff"><div>Chỉnh sửa thước phim</div><div role="button" aria-label="Đóng" style="width:20px;height:20px">x</div><input aria-label="Thêm thẻ" style="width:300px;height:30px"><div id="tags"></div><div role="button" style="width:120px;height:24px">Thu ngắn video</div><div role="button" aria-label="Tiếp" style="width:60px;height:30px">Tiếp</div></div>');
  document.body.appendChild(T); st.tags = [];
  const o = T.querySelector('input');
  o.addEventListener('keydown', (e) => { if (e.key === 'Enter' || e.key === ',') { if (boQuaLan1('tagLan1')) return; if (INIT.theHong && /^Bí kíp|^Manifest tài lộc/.test(o.value)) return; if (o.value.trim()) { st.tags.push(o.value.trim()); const s2 = document.createElement('span'); s2.textContent = o.value; T.querySelector('#tags').appendChild(s2); } o.value = ''; e.preventDefault(); } });
  T.querySelector('[aria-label="Tiếp"]').onclick = () => { T.remove(); openReelSettings(d, st, ed); };
  T.querySelector('[aria-label="Đóng"]').onclick = () => { T.remove(); d.remove(); comp = null; };
}
function openReelSettings(d, st, ed) {
  const S = el('<div role="dialog" id="rset" style="position:fixed;top:20px;left:300px;width:700px;height:640px;background:#fff;overflow:' + (INIT.cuonKhuat ? 'hidden' : 'auto') + '"></div>');
  S.innerHTML = '<div><span>Cài đặt thước phim</span></div><div role="button" aria-label="Đóng" style="width:20px;height:20px">x</div>'
    + (INIT.cuonKhuat ? '<div class="cuon" style="height:560px;overflow:auto">' : '')
    + '<div contenteditable="true" aria-label="Mô tả thước phim của bạn..." style="min-height:60px;border:1px solid #999"></div>'
    + '<div>Hình thu nhỏ</div><div role="button" class="thumb" style="width:80px;height:30px">Chỉnh sửa</div>'
    + (INIT.cuonKhuat ? '<div style="height:1400px">khoảng trống dài</div>' : '')
    + '<div role="button" class="grp" style="height:40px">Chia sẻ lên nhóm<br><span class="gs">Không có</span></div>'
    + '<div role="button" aria-label="Lưu thước phim làm bản nháp" class="draft" style="width:60px;height:30px">Lưu</div>'
    + '<div role="button" aria-label="Đăng" class="post" style="width:80px;height:36px">Đăng</div>' + (INIT.cuonKhuat ? '</div>' : '');
  document.body.appendChild(S);
  const vdLan = +(localStorage.getItem('__vd') || 0) + 1; localStorage.setItem('__vd', vdLan);
  if (INIT.videoDung && vdLan <= INIT.videoDung) { const pb = S.querySelector('.post'); pb.setAttribute('aria-disabled', 'true'); S.insertBefore(el('<div class="pt">Đang tải lên 40%</div>'), S.firstChild); window.__ev.push('VIDEO_DUNG'); }
  const mo = S.querySelector('[contenteditable]');
  mo.innerText = INIT.matChuReel ? '' : ed.innerText;
  mo.addEventListener('paste', (e) => { e.preventDefault(); document.execCommand('insertText', false, e.clipboardData.getData('text/plain')); });
  st.nhom = new Set();
  const dong = () => { S.remove(); d.remove(); comp = null; document.querySelectorAll('#rthumb,#rgrp').forEach((x) => x.remove()); };
  S.querySelector('[aria-label="Đóng"]').onclick = dong;
  S.querySelector('.draft').onclick = () => { window.__ev.push('DRAFT'); if (window.__dbDraft) window.__dbDraft({ text: mo.innerText }); dong(); };
  if (INIT.lucKhac) setTimeout(() => { const P = el('<div role="dialog" id="nhac" style="position:fixed;top:200px;left:500px;width:360px;height:140px;background:#fff;z-index:9"><div>' + (INIT.suKien ? 'Bạn đang tổ chức sự kiện?' : 'Bật thông báo để biết khi thước phim đã đăng?') + '</div><div role="button" class="lk" style="width:80px;height:30px">' + (INIT.suKien ? 'Đăng bài viết gốc' : 'Lúc khác') + '</div><div role="button" class="tt" style="width:60px;height:30px">' + (INIT.suKien ? 'Tiếp tục' : 'Bật') + '</div></div>'); P.querySelector('.tt').onclick = () => { window.__ev.push('BAM_SAI_TIEPTUC'); }; document.body.appendChild(P); P.querySelector('.lk').onclick = () => { window.__ev.push('LUCKHAC'); P.remove(); }; }, 800);
  S.querySelector('.grp').onclick = () => {
    if (INIT.nhomHong) return;
    if (document.getElementById('rgrp')) return;
    const G = el('<div role="dialog" id="rgrp" style="position:fixed;top:30px;left:320px;width:600px;height:600px;background:#fff;overflow:auto"><div>Chia sẻ lên nhóm</div><div><label>Tắt <input type="checkbox" role="switch" aria-label="Tắt"></label></div>'
      + Array.from({ length: INIT.groups }, (_, i) => '<div role="listitem" style="height:36px"><span>Nhóm số ' + (i + 1) + '</span><input type="checkbox" data-i="' + i + '"></div>').join('')
      + '<div role="button" class="xong" style="width:60px;height:30px">Xong</div></div>');
    document.body.appendChild(G);
    G.querySelectorAll('input[data-i]').forEach((c) => c.onchange = () => { const i = +c.dataset.i; if (c.checked) st.nhom.add(i); else st.nhom.delete(i); });
    G.querySelector('.xong').onclick = () => { G.remove(); S.querySelector('.gs').textContent = st.nhom.size ? 'Đã chọn ' + st.nhom.size + ' nhóm' : 'Không có'; if (INIT.cuonKhuat) { const c = S.querySelector('.cuon'); c.scrollTop = c.scrollHeight; } };
  };
  S.querySelector('.thumb').onclick = () => {
    if (document.getElementById('rthumb')) return;
    const TH = el('<div role="dialog" id="rthumb" style="position:fixed;top:60px;left:340px;width:500px;height:400px;background:#fff"><div>Chọn hình thu nhỏ</div><input type="range" min="0" max="100" value="40" style="width:300px"><div role="button" style="width:60px;height:30px">Lưu</div></div>');
    setTimeout(() => {
      document.body.appendChild(TH);
      const r = TH.querySelector('input');
      TH.querySelector('[role=button]').onclick = () => { st.thumb = r.value; TH.querySelector('[role=button]').textContent = 'Đang lưu'; setTimeout(() => TH.remove(), 700); };
    }, 600);
  };
  S.querySelector('.post').onclick = () => {
    if (S.querySelector('.post').getAttribute('aria-disabled') === 'true') return;
    if (document.getElementById('nhac') || document.getElementById('hla')) { window.__ev.push('DANG_BI_CHAN'); return; }
    if (INIT.hopLa && !window.__hopLaDa) { window.__hopLaDa = true; const P = el('<div role="dialog" id="hla" style="position:fixed;top:200px;left:500px;width:360px;height:140px;background:#fff;z-index:9"><div>Có tính năng mới cho thước phim của Trang</div><div role="button" aria-label="Đóng" style="width:30px;height:30px">x</div><div role="button" style="width:90px;height:30px">Dùng thử</div></div>'); document.body.appendChild(P); P.querySelector('[aria-label="Đóng"]').onclick = () => { window.__ev.push('HOPLA_DONG'); P.remove(); }; return; }
    if (boQuaLan1('dangReelLan1')) return;
    const text = mo.innerText.trim(); const info = { text, reel: true, nhom: st.nhom.size, loc: !!st.loc, tags: (st.tags || []).length, thumb: st.thumb == null ? null : String(st.thumb), ts: Date.now(), files: [st.video ? st.video.size : 0] };
    window.__ev.push('DANGREEL:' + info.nhom + ' nhom');
    dong();
    setTimeout(() => { window.__dbPost(info); }, INIT.reelCham || 2500);
  };
}
