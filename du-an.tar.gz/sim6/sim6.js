// Mô phỏng bản 6.0 trên Facebook giả + Lark giả + Graph giả (đồng hồ giả, có thể chạy 2 máy cùng lúc)
const { chromium } = require('playwright');
const fs = require('fs');
const GOC = require('path').resolve(__dirname, '..'); // thư mục chứa v6/, sim6/, ảnh thử (chạy được trên Linux lẫn Windows)
const SCEN = process.argv[2] || 'ngay';
let SCRIPT = fs.readFileSync(process.env.SCRIPT || GOC + '/v6/smh6.user.js', 'utf8').normalize('NFC');
const PAGE_JS = fs.readFileSync(__dirname + '/fakefb6.js', 'utf8');
const BIG = fs.readFileSync(GOC + '/big.jpg').toString('base64');
const SMALL = fs.readFileSync(GOC + '/small.jpg').toString('base64');
const NEN = fs.readFileSync(GOC + '/mf/nen.jpg');
const OUT = process.env.OUT || __dirname + '/kq';
fs.mkdirSync(OUT, { recursive: true });
const p2 = (n) => String(n).padStart(2, '0');
const CMT3 = eval(SCRIPT.match(/CMT_BAI3: ('(?:[^'\\]|\\.)*')/)[1]);

// ---------------- kịch bản ----------------
const C = {
  ngay: { may: ['GIAO'], start: [6, 20], den: [21, 0] },
  bu: { may: ['GIAO'], start: [12, 0], den: [20, 30] },
  chot: { may: ['GIAO'], start: [18, 0], den: [22, 5] },
  haimay: { may: ['GIAO', 'CAO'], start: [6, 20], den: [10, 0] },
  caothay: { may: ['GIAO', 'CAO'], start: [6, 20], den: [9, 10], giaoTat: [6, 25], giaoMo: [7, 25] },
  tranh: { may: ['GIAO', 'CAO'], start: [6, 20], den: [8, 0], giaoTat: [6, 25], giaoMo: [6, 59] },
  thieu: { may: ['GIAO'], start: [7, 40], den: [9, 30], thieuVideo1: true },
  cmt: { may: ['GIAO'], start: [7, 40], den: [9, 0], cmtMat: true },
  nhansu: { may: ['GIAO'], start: [6, 30], den: [7, 10], nhanSu: true },
  uicmt: { may: ['GIAO'], start: [13, 0], den: [13, 2], b1Xong: true },
  demnguoc: { may: ['GIAO'], start: [6, 34], den: [6, 50], demNguoc: true, duLieuCu: true },
  hoan: { may: ['GIAO'], start: [7, 45], den: [8, 20], hoan: true },
  khongnhac: { may: ['GIAO'], start: [14, 0], den: [14, 2], ui: true, daXong: true, khongNhac: true },
  chaythuv: { may: ['GIAO'], start: [7, 45], den: [8, 30], chayThu: true, b1Xong: true },
  cmt19: { may: ['GIAO'], start: [18, 50], den: [19, 12], daXong: true, cmt19: true },
  gantay: { may: ['GIAO'], start: [14, 0], den: [14, 6], daXong: true },
  soan: { may: ['GIAO'], start: [7, 0], den: [7, 40], b1Xong: true },
  tay: { may: ['CAO'], start: [20, 25], den: [22, 30], tayHet: true },
  trungtt: { may: ['GIAO'], start: [18, 10], den: [18, 50], tayTrung: true },
  chaythu: { may: ['GIAO'], start: [7, 40], den: [8, 40], chayThu: true },
  khanh: { may: ['CAO'], start: [18, 55], den: [19, 30], date: [2026, 10, 9], khanh: true, daXong: true },
  taoanh: { may: ['GIAO'], start: [14, 0], den: [14, 10], taoAnh: true, daXong: true },
  taoanhtay: { may: ['GIAO'], start: [14, 0], den: [14, 10], taoAnh: true, daXong: true, quotaTu: [13, 0] },
  ui: { may: ['GIAO'], start: [14, 0], den: [14, 20], ui: true, daXong: true },
  chonmay: { may: [''], start: [14, 0], den: [14, 3], ui: true },
  nhac: { may: ['GIAO'], start: [14, 0], den: [14, 5], nhac: true, daXong: true },
  baocao: { may: ['GIAO'], start: [19, 0], den: [20, 0], gan9: true },
  chuangay: { may: ['GIAO'], start: [14, 0], den: [14, 5], daXong: true, chuaNgay: true },
  ngaymai: { may: ['GIAO'], start: [14, 0], den: [15, 30], daXong: true },
  ngaymaihuy: { may: ['GIAO'], start: [14, 0], den: [15, 0], daXong: true },
  soanf5: { may: ['GIAO'], start: [6, 0], den: [7, 0] },
  cuonkhuat: { may: ['GIAO'], start: [7, 40], den: [9, 40], b1Xong: true, cuonKhuat: true },
  nhomhong: { may: ['GIAO'], start: [7, 40], den: [9, 40], b1Xong: true, nhomHong: true },
  hongv1: { may: ['GIAO'], start: [7, 40], den: [12, 0], b1Xong: true, hongSize: 300000 },
  luckhac: { may: ['GIAO'], start: [7, 40], den: [9, 30], b1Xong: true, lucKhac: true },
  thehong: { may: ['GIAO'], start: [7, 40], den: [9, 40], b1Xong: true, theHong: true },
  sukien: { may: ['GIAO'], start: [7, 40], den: [9, 30], b1Xong: true, lucKhac: true, suKien: true },
  suatiep: { may: ['GIAO'], start: [9, 50], den: [11, 30], b1Xong: true, suaTiep: true },
  suamoi: { may: ['GIAO'], start: [9, 50], den: [11, 30], b1Xong: true, suaMoi: true },
  suacu: { may: ['GIAO'], start: [9, 50], den: [11, 30], b1Xong: true, suaCu: true },
  suacucham: { may: ['GIAO'], start: [9, 50], den: [11, 30], b1Xong: true, suaCu: true, suaCuCham: true },
  tamdung: { may: ['GIAO'], start: [7, 40], den: [8, 25] },
  lamngaycao: { may: ['CAO'], start: [8, 40], den: [9, 5], b1Xong: true },
  uitre: { may: ['GIAO'], start: [13, 0], den: [13, 2], b1Xong: true },
  reelmoi: { may: ['GIAO'], start: [7, 40], den: [8, 40], b1Xong: true, reelMoi: true },
  suahong: { may: ['GIAO'], start: [7, 40], den: [9, 20], b1Xong: true, reelMoi: true, suaHongHet: true },
  reelmoibv: { may: ['GIAO'], start: [7, 40], den: [8, 40], b1Xong: true, reelMoi: true, cdBaiViet: true },
  reelmoitim: { may: ['GIAO'], start: [7, 40], den: [8, 40], b1Xong: true, reelMoi: true, goiYKhongCo: true, loi: { theLan1: true } },
  sheetdadang: { may: ['CAO'], start: [8, 40], den: [9, 40], b1Xong: true, v1DaDang: true },
  sualoi: { may: ['GIAO'], start: [7, 40], den: [9, 40], b1Xong: true, loi: { theLan1: true, camXucLan1: true, luuLan1: true } },
  trungcmt: { may: ['GIAO', 'CAO'], start: [10, 15], den: [11, 30], b1Xong: true, mayCu: true },
  lamngay: { may: ['GIAO'], start: [6, 30], den: [6, 50], nhanSu: true },
  suavid: { may: ['GIAO'], start: [7, 40], den: [8, 5], b1Xong: true },
  thetab: { may: ['GIAO'], start: [14, 0], den: [14, 3], daXong: true },
  cmtcta: { may: ['GIAO'], start: [6, 20], den: [8, 30] },
  phanhoi: { may: ['GIAO'], start: [14, 0], den: [14, 5], daXong: true },
  font: { may: ['GIAO'], start: [14, 0], den: [14, 10], taoAnh: true, daXong: true },
  khongan: { may: ['GIAO'], start: [7, 40], den: [9, 0], b1Xong: true, loi: { dangReelLan1: 2 } },
  khonganmai: { may: ['GIAO'], start: [7, 40], den: [11, 0], b1Xong: true, loi: { dangReelLan1: 99 } },
  videodung: { may: ['GIAO'], start: [7, 40], den: [9, 0], b1Xong: true, videoDung: 1 },
  hopla: { may: ['GIAO'], start: [7, 40], den: [8, 30], b1Xong: true, hopLa: true },
  moanh: { may: ['GIAO'], start: [6, 20], den: [8, 30], soanHong: true },
  treo: { may: ['GIAO'], start: [7, 40], den: [9, 0], b1Xong: true, loi: { videoLan1: 1 }, treoNhanh: true },
  loitrang: { may: ['GIAO'], start: [6, 20], den: [7, 10], loiTrang: 2 },
  loitrang3: { may: ['GIAO'], start: [6, 20], den: [7, 10], loiTrang: 3 },
  suckhoe: { may: ['GIAO'], start: [5, 58], den: [6, 5], khongMa: true },
  baocao6: { may: ['GIAO', 'CAO'], start: [7, 40], den: [8, 40], b1Xong: true, loi: { dangReelLan1: 2 } },
  duyet: { may: ['CAO'], start: [14, 0], den: [14, 6], daXong: true, gitCho: '6.17' },
  nhay: { may: ['GIAO'], start: [6, 33], den: [6, 45] },
  bimat: { may: ['GIAO'], start: [6, 20], den: [6, 50], congKhai: true },
  vtrung: { may: ['GIAO', 'CAO'], start: [7, 40], den: [18, 40], b1Xong: true, vTrung: true, reelKep: true },
  nhacsheet: { may: ['GIAO', 'CAO'], start: [15, 50], den: [16, 15], daXong: true, maiThieu: true },
  chuanbi: { may: ['GIAO'], start: [6, 20], den: [7, 0] },
  mf1: { may: ['GIAO'], start: [8, 50], den: [9, 40], b1Xong: true },
  kenhui: { may: ['GIAO'], start: [14, 0], den: [14, 20], ui: true, daXong: true, kenh: true, tamDung: true },
  hb21: { may: ['GIAO', 'CAO'], start: [21, 20], den: [21, 45], daXong: true },
  capnhat: { may: ['GIAO', 'CAO'], start: [14, 0], den: [14, 5], daXong: true, banMoi: '9.9', driveOk: true },
  thunap: { may: ['GIAO', 'CAO'], start: [14, 0], den: [14, 8], daXong: true },
  thunapcsp: { may: ['GIAO', 'CAO'], start: [14, 0], den: [14, 8], daXong: true, csp: true },
  kenh: { may: ['GIAO'], start: [5, 10], den: [9, 40], kenh: true },
  kenhcta: { may: ['GIAO'], start: [5, 10], den: [7, 10], kenh: true, cmtKenh: { 2: false } },
  kenhnhac: { may: ['GIAO', 'CAO'], start: [15, 50], den: [16, 15], daXong: true, kenh: true, kenhMaiThieuVideo: true },
  kenhmatrang: { may: ['GIAO'], start: [5, 10], den: [7, 10], kenh: true, maTrang: true },
  kenhcao: { may: ['GIAO', 'CAO'], start: [5, 10], den: [7, 30], kenh: true, giaoTat: [5, 12], giaoMo: [7, 20] },
  kenhnick: { may: ['GIAO'], start: [5, 10], den: [7, 10], kenh: true, tc0: 'Nguyễn Hoàng Giang' },
  kenhtay: { may: ['GIAO'], start: [5, 10], den: [7, 10], kenh: true, maTrang: true, k2Tay: true },
  kenhcaomt: { may: ['GIAO', 'CAO'], start: [5, 10], den: [7, 30], kenh: true, maTrang: true, giaoTat: [6, 5], giaoMo: [7, 20] },
  // (6.19.2) cài bản mới giữa ngày: video kênh 2, 3 đã được đăng tay từ chiều (thiếu comment CTA)
  giaomuon: { may: ['GIAO'], start: [19, 15], den: [20, 15], kenh: true, maTrang: true, daXong: true, kTay: true },
  giaomuonma: { may: ['GIAO'], start: [19, 15], den: [20, 15], kenh: true, daXong: true, kTay: true },
  bucao: { may: ['CAO'], start: [19, 0], den: [20, 10], kenh: true, daXong: true, kTay: true, tc0: 'Phan Cao', banPhim: [[19, 1], [19, 9]] },
  bucaomenu: { may: ['CAO'], start: [19, 0], den: [20, 10], kenh: true, daXong: true, kTay: true, tc0: 'Phan Cao', menuChi: ['Vòng Trầm Hương Sơn Mộc Hương .'] },
  nhaytab: { may: ['GIAO', 'CAO'], start: [4, 50], den: [5, 25], daXong: false },
  nhaytab2: { may: ['GIAO'], start: [12, 20], den: [12, 50], daXong: true },
  bangthieu: { may: ['GIAO'], start: [14, 0], den: [14, 4], daXong: true, kenh: true, hx: true, kenhMaiThieuVideo: true },
  chendong: { may: ['GIAO'], start: [6, 20], den: [11, 0] },
  bai4: { may: ['GIAO'], start: [14, 10], den: [14, 50], daXong: true, baiNhieu: true },
  hxnhom: { may: ['GIAO'], start: [5, 10], den: [6, 50], kenh: true, hx: true, khongNhom: true },
  hxkhongmuc: { may: ['GIAO'], start: [5, 10], den: [6, 50], kenh: true, hx: true, khongMucNhom: true },
  ghide: { may: ['CAO'], start: [8, 30], den: [8, 50], b1Xong: true, khoaGiao: 'v1' },
  danhdau: { may: ['GIAO'], start: [8, 30], den: [8, 34], b1Xong: true, tuDongTat: true },
  hxmenu: { may: ['GIAO'], start: [5, 10], den: [6, 40], kenh: true, hx: true, khongNutTrang: true, menuChi: ['Vòng Trầm Hương Sơn Mộc Hương .', 'Nguyễn Hoàng Giang'] },
  hxchuyen: { may: ['GIAO'], start: [5, 10], den: [6, 40], kenh: true, hx: true, chuyenHoi: true, menuChi: ['Vòng Trầm Hương Sơn Mộc Hương .', 'Trầm Hương Thủ Đức Sơn Mộc Hương', 'Sơn Mộc Hương - Trầm Chuẩn - Giá Chuẩn'] },
  hx: { may: ['GIAO'], start: [5, 10], den: [13, 50], kenh: true, hx: true, baiNhieu: true },
  tatdang: { may: ['GIAO'], start: [7, 40], den: [9, 30], b1Xong: true, tuDongTat: true },
  trungbai: { may: ['GIAO'], start: [7, 40], den: [8, 20], b1Xong: true, trungBai: true },
  tong12: { may: ['GIAO'], start: [11, 0], den: [12, 30], daXong: true, thieuV2: true },
  taibh: { may: ['GIAO'], start: [6, 20], den: [12, 0], batchHong: true },
  ngay2may: { may: ['GIAO', 'CAO'], start: [6, 20], den: [21, 50], themV: 2, themMf: 1 },
  themvideo: { may: ['GIAO'], start: [6, 20], den: [22, 40], themV: 4, themMf: 1 },
  themgiua: { may: ['GIAO', 'CAO'], start: [14, 0], den: [22, 40], daXong: true, themGiua: true },
  soanan: { may: ['GIAO'], start: [7, 0], den: [7, 40], b1Xong: true },
  chiso: { may: ['CAO'], start: [6, 50], den: [9, 40], date: [2026, 10, 16], csHook: true },
  chisovid: { may: ['CAO'], start: [6, 50], den: [8, 0], date: [2026, 10, 16], csHook: true, vidCu: true },
  chisoloi: { may: ['CAO'], start: [6, 50], den: [9, 40], date: [2026, 10, 16], csHook: true, csHong: true },
  chisoloi10: { may: ['CAO'], start: [6, 50], den: [9, 40], date: [2026, 10, 16], csHook: true, csHong: true, tuDongTat: true },
  chisoan: { may: ['CAO'], start: [6, 50], den: [9, 40], date: [2026, 10, 16], csHook: true },
  chisoanhong: { may: ['CAO'], start: [6, 50], den: [9, 10], date: [2026, 10, 16], csHook: true },
  chisoban: { may: ['CAO'], start: [7, 20], den: [9, 0], date: [2026, 10, 16], csHook: true, gioV1: [7, 30], b1Xong: true },
  chisolai: { may: ['CAO'], start: [14, 0], den: [14, 40], date: [2026, 10, 14], csHook: true, daXong: true, tc0: 'Nguyễn Hoàng Giang', vidCu: true, vinsNull: true },
  chisotv: { may: ['CAO'], start: [6, 50], den: [8, 0], date: [2026, 10, 16], csHook: true, vidCu: true, vinsNull: true },
  tv24: { may: ['CAO'], start: [14, 0], den: [15, 40], date: [2026, 10, 14], daXong: true, tc0: 'Nguyễn Hoàng Giang', vinsNull: true, vid24: true },
  chisobuoc7: { may: ['CAO'], start: [14, 0], den: [14, 30], date: [2026, 10, 14], csHook: true, daXong: true, tc0: 'Nguyễn Hoàng Giang', vidCu: true, csBuoc7: true },
  lich2may: { may: ['GIAO', 'CAO'], start: [6, 20], den: [9, 0], themV: 2, lichLech: true },
  lich1may: { may: ['CAO'], start: [6, 20], den: [8, 0], themV: 2, z8Cu: true },
  cach20: { may: ['GIAO'], start: [7, 40], den: [8, 40], chenTay: true },
  xep9: { may: ['GIAO'], start: [6, 20], den: [6, 40], khongLich: true },
  xep16: { may: ['GIAO', 'CAO'], start: [6, 20], den: [6, 45], khongLich: true, themV: 4, themMf: 2, baiNhieu: true },
  xepanh: { may: ['GIAO'], start: [6, 20], den: [12, 50], khongLich: true, themV: 4, themMf: 2, baiNhieu: true },
  xeptre: { may: ['GIAO'], start: [17, 30], den: [21, 40], khongLich: true, themV: 4, themMf: 2, baiNhieu: true },
  trangmoi: { may: ['GIAO'], start: [6, 20], den: [7, 0], hopTrangMoi: true },
  ketdang: { may: ['GIAO'], start: [6, 50], den: [7, 55], ketDang: true },
  trancung: { may: ['CAO'], start: [6, 20], den: [8, 0], tranCung: true },
  webdoc: { may: ['GIAO'], start: [6, 20], den: [8, 10], quotaTu: [6, 0], webData: true },
  webkhong: { may: ['GIAO'], start: [6, 20], den: [7, 30], quotaTu: [6, 0] },
  quotadang: { may: ['GIAO'], start: [7, 44], den: [8, 15], b1Xong: true, quotaTu: [7, 46] },
  quotaweb: { may: ['GIAO'], start: [7, 30], den: [8, 20], b1Xong: true, quotaTu: [7, 33] },
  quotalogin: { may: ['GIAO'], start: [7, 30], den: [8, 20], b1Xong: true, quotaTu: [7, 33], webHong: 'login' },
  taisan2: { may: ['GIAO'], start: [6, 20], den: [7, 10] },
  bccaoz2: { may: ['CAO'], start: [19, 0], den: [20, 50], gan9: true, tranCung: true, z2Giao: true },
  bccao: { may: ['CAO'], start: [19, 0], den: [20, 50], gan9: true },
  bccaomuon: { may: ['CAO'], start: [22, 0], den: [22, 40], daXong: true, tranCung: true, z2Giao: true, mayCao: true },
  z1cao: { may: ['CAO'], start: [6, 20], den: [9, 40], hongSize: 300000 },
  chisonut: { may: ['CAO'], start: [14, 0], den: [14, 40], date: [2026, 10, 14], csHook: true, daXong: true, tc0: 'Nguyễn Hoàng Giang' },
  soanmaik: { may: ['CAO'], start: [21, 40], den: [22, 0], kenh: true, daXong: true },
  bugiao: { may: ['GIAO'], start: [19, 0], den: [20, 10], kenh: true, daXong: true, kTay: true, tc0: 'Phan Cao' },
}[SCEN];
if (!C) { console.log('KHÔNG CÓ KỊCH BẢN', SCEN); process.exit(1); }
if (C.treoNhanh) SCRIPT = SCRIPT.replace('TREO_PHUT: 4,', 'TREO_PHUT: 0.5,');
if (C.congKhai) SCRIPT = fs.readFileSync(GOC + '/v6/smh6.public.user.js', 'utf8').normalize('NFC');
const BIMAT = JSON.parse(fs.readFileSync(GOC + '/v6/bimat.json', 'utf8'));
const [Y, Mo, D] = C.date || [2026, 10, 9];
const ngayS = (d) => `${p2(d.getDate())}-${p2(d.getMonth() + 1)}-${d.getFullYear()}`;
const T0 = new Date(Y, Mo - 1, D, C.start[0], C.start[1], 0, 0).getTime();
const today = ngayS(new Date(T0)); const mai = ngayS(new Date(T0 + 86400e3));
const H = (h, m) => new Date(Y, Mo - 1, D, h, m).getTime();
const fmt = (ms) => { const d = new Date(ms); return p2(d.getHours()) + ':' + p2(d.getMinutes()); };
const iso = (ms) => new Date(ms).toISOString().replace('Z', '+0000');

// ---------------- (6.19) 3 trang ----------------
const TRANG = {
  vongtramhuongsonmochuong: { ten: 'Vòng Trầm Hương Sơn Mộc Hương .', id: '1196332230224812', so: '61590895435527' },
  tramhuongthuducsonmochuong: { ten: 'Trầm Hương Thủ Đức Sơn Mộc Hương', id: '2002002002', so: '61586752146281' },
  sonmochuongtramchuangiachuan: { ten: 'Sơn Mộc Hương - Trầm Chuẩn - Giá Chuẩn', id: '3003003003', so: '61575413185162' },
  tramhuonghaxa: { ten: 'Trầm Hương Hà Xá', id: '4004004004', so: '100092534930523' },
};
const trangCuaDuong = (path) => { const x = path.replace(/^\//, '').split('/')[0]; for (const [k, v] of Object.entries(TRANG)) if (x === k || x === v.so) return k; return null; };
const trangCuaId = (id) => Object.keys(TRANG).find((k) => TRANG[k].id === String(id)) || null;
// ---------------- dữ liệu ----------------
const T = {
  b1: 'Bai mot hom nay ve vong tram huong de moc khong keo khong sap', c1: 'Comment bai mot xem them tai sonmochuong com nhe',
  b2: 'Bai hai ve vong tram huong de moc hat tron deu gia cong chin chu de deo moi ngay', c2: 'Comment bai hai ghe showroom Thu Duc xem hang nhe',
  b3: 'Bai ba ve cach nhan biet tram nau dau qua mau sam va trong luong nang chua du de ket luan',
  v: ['Video mot ve cach chon size vong tram huong 108 hat cho nguoi moi', 'Video hai ve vi sao vong tram huong de moc khong phu keo sap', 'Video ba ve cach bao quan vong tram huong khi deo hang ngay'],
  m: ['#Manifest\nTien bac tu tim den\nNang luong tich cuc moi ngay\nCmt "don nhan" de don nhan nang luong\n#sonmochuong #manifest', '#Manifest\nBinh an trong tam hon\nMoi dieu tot dep dang den\nCmt "don nhan" nhe\n#sonmochuong', '#Manifest\nTai loc doi dao\nCong viec thuan loi\nCmt "don nhan" de nhan loc\n#sonmochuong'],
};
if (C.vTrung) { const than = 'Cung la vong 108 hat nhung gia co the khac rat nhieu vi ban chat phoi van dau va cach gia cong de moc khong keo sap'; T.v[1] = 'Vong tram huong 108 hat gia dat chua chac xin neu thieu 3 yeu to nay\n' + than; T.v[2] = 'Hay xem 2 dieu nay neu muon mua vong tram huong 108 hat dung gia\n' + than; }
const TM = { b1: 'Ngay mai bai mot moi', b2: 'Ngay mai bai hai moi co anh', b3: 'Ngay mai bai ba moi co anh', v: ['Ngay mai video mot', 'Ngay mai video hai', 'Ngay mai video ba'], m: ['#Manifest\nNgay mai mot\n#sonmochuong', '#Manifest\nNgay mai hai\n#sonmochuong', '#Manifest\nNgay mai ba\n#sonmochuong'] };
const img = (t) => ({ fileToken: t, type: 'embed-image', link: 'https://x/' + t, text: t + '.jpg', width: 100, height: 100 });
const vid = (t, size) => [{ fileToken: t, text: t + '.mp4', mimeType: 'video/mp4', size, type: 'attachment' }];
const hdrB = ['Từ khóa chính', 'Bài twist (không có ảnh)', 'Cmt bài 1', 'Bài 2', 'Cmt bài 2', 'Bài 3', 'Trạng thái', 'Ngày đăng', 'Ảnh 1 bài 2', 'Ảnh 2 bài 2', 'Ảnh 3 bài 2', 'Ảnh 1 bài 3', 'Ảnh 2 bài 3', 'Ảnh 3 bài 3', 'Ảnh cmt 1', 'Ảnh cmt 2', 'Ảnh cmt 3'];
const blank = (n) => Array(n).fill(null);
const r2 = blank(17); r2[7] = '01-01-2026'; r2[14] = img('tokO2'); r2[15] = img('tokP2'); r2[16] = img('tokQ2');
const r3 = blank(17); r3[7] = '02-01-2026'; r3[14] = img('tokO3'); r3[15] = img('tokP3'); r3[16] = img('tokQ3');
const hangBai = (ngay, t, sfx) => { const r = blank(17); r[0] = 'k'; r[1] = t.b1; r[2] = sfx ? T.c1 + sfx : T.c1; r[3] = t.b2; r[4] = T.c2; r[5] = t.b3; r[7] = ngay; r[8] = img('tokBIG' + sfx); r[9] = img('tokS1' + sfx); r[11] = img('tokL' + sfx); r[14] = img('tokC1' + sfx); return r; };
const TAB = { apU3Ne: [hdrB, r2, r3, hangBai(today, T, ''), hangBai(mai, TM, 'm')], e2f139: [['STT', 'Link', 'C', 'D', 'Chữ đăng video', 'F', 'Chữ manifest', 'Ảnh manifest', 'I', 'Trạng thái', 'Ngày đăng', 'L', 'M', 'Video']],
  em39qJ: [['STT', 'B', 'Kịch bản chi tiết', 'Đạo cụ + sản phẩm', 'Tiêu đề FB/Tiktok', 'Ngày quay dự kiến', 'Trạng thái', 'Ngày đăng', 'VIDEO', 'Link']],
  '4OtbFA': [['STT', 'B', 'C', 'Tiêu đề FB/Tiktok', 'Note Dương', 'Ngày quay', 'Trạng thái', 'Ngày đăng', 'VIDEO', 'Link']],
  ZSDDld: [['STT', 'Câu HOOK (dưới 100 ký tự)', 'KỊCH BẢN CHƯA DUYỆT', 'KỊCH BẢN SAU DUYỆT', 'Tiêu đề FB/Tiktok', 'Note Dương', 'Ngày quay', 'Trạng thái', 'Ngày đăng', 'VIDEO', null]] };
const THX = ['Ha Xa video mot cach phan biet nhang tram huong sach va nhang tam hoa chat', 'Ha Xa video hai dung chon nhang tram huong dau tan neu chua biet dieu nay', 'Ha Xa ngay mai chua co video'];
if (C.hx) { const hx = (cap, ngay, tt, tok) => { const r = blank(11); r[0] = 1; r[1] = 'hook'; r[4] = cap; r[7] = tt; r[8] = ngay; r[9] = tok ? vid(tok, 300070 + tok.length) : null; return r; };
  TAB.ZSDDld.push(hx(THX[0], today, 'ĐÃ QUAY', 'vkhxa'), hx(THX[1], today, 'ĐÃ DUYỆT', 'vkhxb'), hx(THX[2], mai, 'ĐÃ QUAY', null)); }
if (C.baiNhieu) { const t2 = { b1: 'Hang hai bai mot ve vong tram huong 108 hat cho nguoi moi bat dau', b2: 'Hang hai bai hai ve gia vong tram huong 108 hat va cach chon dung', b3: 'Hang hai bai ba ke chuyen nguoi mua vong tram lan dau va bai hoc rut ra' }; TAB.apU3Ne.push(hangBai(today, t2, 'h2')); }
const TK = { 2: ['Kenh hai video mot ve showroom tram huong Thu Duc cho nguoi moi', 'Kenh hai video hai ve cach chon vong tram huong tai showroom', 'Kenh hai ngay mai video'], 3: ['Kenh ba video mot ve nhang tram huong sach khong hoa chat', 'Kenh ba video hai chua duyet', 'Kenh ba ngay mai video mot'] };
if (C.kenh) { // kênh 2: 2 video hôm nay (ĐÃ DUYỆT) + 1 ngày mai · kênh 3: 1 video hôm nay ĐÃ DUYỆT + 1 dòng CHƯA DUYỆT; ngày mai kênh 3 chưa có dòng nào
  const hk = (c, cap, ngay, tt, tok) => { const r = blank(10); r[0] = 1; r[c === 2 ? 4 : 3] = cap; r[6] = tt; r[7] = ngay; r[8] = tok ? vid(tok, 300050 + tok.length) : null; return r; };
  TAB.em39qJ.push(hk(2, TK[2][0], today, 'ĐÃ DUYỆT', 'vk2a'), hk(2, TK[2][1], today, 'ĐÃ DUYỆT', 'vk2b'), hk(2, TK[2][2], mai, C.kenhMaiChuaDuyet ? 'ĐANG LÀM' : 'ĐÃ DUYỆT', C.kenhMaiThieuVideo ? null : 'vk2m'));
  TAB['4OtbFA'].push(hk(3, TK[3][0], today, 'ĐÃ DUYỆT', 'vk3a'), hk(3, TK[3][1], today, 'ĐANG LÀM', 'vk3x'));
  if (C.kenhBo3) TAB['4OtbFA'][1][6] = 'ĐANG LÀM';
}
const VSIZE = 300000;
for (let i = 0; i < 3; i++) { const r = blank(14); r[0] = 10 + i; r[4] = T.v[i]; r[6] = T.m[i]; r[7] = img('mf' + (i + 1)); r[10] = today; r[13] = vid('vid' + (i + 1), VSIZE + i); if (C.thieuVideo1 && i === 0) r[13] = null; if (C.thieuV2 && i === 1) r[13] = null; if (C.v1DaDang && i === 0) r[9] = 'ĐÃ ĐĂNG'; TAB.e2f139.push(r); }
const TV = ['Video bon ve cach nhan biet vong tram huong de moc that', 'Video nam ve vi sao nguoi moi nen chon vong 7 li', 'Video sau ve cach do tay chon size chuoi 108 hat', 'Video bay ve kinh nghiem mua vong tram lan dau'];
const hangThem = (i, mf) => { const r = blank(14); r[0] = 30 + i; r[4] = TV[i]; if (mf) { r[6] = '#Manifest\nLoc them so ' + (i + 1) + '\nNang luong moi\n#sonmochuong'; r[7] = img('mft' + (i + 1)); } r[10] = today; r[13] = vid('vidt' + (i + 1), VSIZE + 50 + i); return r; };
if (C.themV) for (let i = 0; i < C.themV; i++) TAB.e2f139.push(hangThem(i, i < (C.themMf || 0)));
for (let i = 0; i < 3; i++) { if (C.maiThieu && i > 0) continue; const r = blank(14); r[0] = 20 + i; r[4] = TM.v[i]; r[6] = TM.m[i]; r[7] = img('mfm' + (i + 1)); r[10] = mai; r[13] = vid('vidm' + (i + 1), VSIZE + 10 + i); TAB.e2f139.push(r); }
while (TAB.e2f139.length < 219) TAB.e2f139.push(blank(14));
TAB.e2f139[216][6] = [{ fileToken: 'nhac217', text: 'nhac-nen.wav', mimeType: 'audio/wav', size: 0, type: 'attachment' }]; // G217
if (C.vidCu) { while (TAB.e2f139.length < 232) TAB.e2f139.push(blank(14)); TAB.e2f139[231] = blank(14); TAB.e2f139[231][6] = 'Loi chuc tai loc doi dao den voi moi nha moi ngay binh an'; }
TAB.e2f139[219] = blank(14); TAB.e2f139[219][6] = '#Manifest\nTieu de thu nghiem tao anh\nDong than mot hai ba\nCmt "đón nhận" để đón nhận năng lượng\n#sonmochuong #manifest';
TAB.e2f139[220] = blank(14); TAB.e2f139[220][6] = '#Manifest\nTieu de thu hai dai hon mot chut de xem tu xuong dong\nNang luong tich cuc\n#sonmochuong';
TAB.e2f139[221] = blank(14); TAB.e2f139[221][6] = '#Manifest\nTieu de thu ba\nAnh thu ba de xem truoc\nCmt "đón nhận" nhé\n#sonmochuong';
TAB.apU3Ne[0][25] = null;
if (SCEN === 'phanhoi') { TAB.apU3Ne.push(hangBai(ngayS(new Date(T0 + 10 * 86400e3)), TM, 'xa')); const r = hangBai('', TM, 'kd'); r[7] = null; TAB.apU3Ne.push(r); }
if (C.chuaNgay) { // giống sheet thật: ngày ở cột K là số (kiểu Excel); hàng ngày mai đã duyệt nhưng CHƯA ghi ngày
  const serial = (ds) => { const [d, m, y] = ds.split('-').map(Number); return (Date.UTC(y, m - 1, d) - Date.UTC(1899, 11, 30)) / 864e5; };
  for (let i = 1; i <= 3; i++) TAB.e2f139[i][10] = serial(today);
  for (let i = 4; i <= 6; i++) { TAB.e2f139[i][10] = null; TAB.e2f139[i][9] = 'ĐÃ DUYỆT'; }
  TAB.apU3Ne[4][7] = null;
}
// file nhạc WAV 2 giây
function taoWav() { const sr = 8000, n = sr * 2, b = Buffer.alloc(44 + n * 2); b.write('RIFF', 0); b.writeUInt32LE(36 + n * 2, 4); b.write('WAVEfmt ', 8); b.writeUInt32LE(16, 16); b.writeUInt16LE(1, 20); b.writeUInt16LE(1, 22); b.writeUInt32LE(sr, 24); b.writeUInt32LE(sr * 2, 28); b.writeUInt16LE(2, 32); b.writeUInt16LE(16, 34); b.write('data', 36); b.writeUInt32LE(n * 2, 40); for (let i = 0; i < n; i++) b.writeInt16LE(Math.round(Math.sin(i / 10) * 8000), 44 + i * 2); return b; }
const WAV = taoWav(); TAB.e2f139[216][6][0].size = WAV.length;
fs.writeFileSync(OUT + '/nhac.wav', WAV);

const db = { posts: [], seq: 500, sent: [], dl: {}, likes: [], edits: [], drafts: [], writes: [], images: [], dem: {}, larkGoi: 0, imgBytes: {} };
db.posts.push({ id: 'old1', message: 'Bai cu hom qua van con tren trang nhe moi nguoi', luc: T0 - 20 * 3600e3, comments: [] });
const lkPost = (p) => p.reel ? 'https://www.facebook.com/reel/' + (p.kepCua || p.id) : 'https://www.facebook.com/' + (p.trang || 'vongtramhuongsonmochuong') + '/posts/' + p.id;
const cmtDu = (loai, so) => (loai === 'b1' ? [{ message: T.c1, cuaTrang: true }] : loai === 'b2' ? [{ message: T.c2, cuaTrang: true }] : [{ message: CMT3, cuaTrang: true }, { message: '', anh: true, cuaTrang: true }, { message: '', anh: true, cuaTrang: true }].concat(loai === 'b3' ? [{ message: '', anh: true, cuaTrang: true }] : []));
if (C.tayTrung) { const ds = [[T.b1, H(6, 46)], [T.b2, H(10, 16)], [T.b3, H(16, 45)], [T.v[0], H(8, 1), 1], [T.v[1], H(11, 46), 1], [T.v[0], H(18, 6), 1]]; ds.forEach(([m, luc, reel], i) => db.posts.push({ id: 'tt' + i, message: m, luc, reel: !!reel, comments: reel ? [{ message: CMT3, cuaTrang: true }] : [] })); }
if (C.tayHet) { const ds = [[T.b1, H(6, 46)], [T.b2, H(7, 16)], [T.b3, H(7, 45)], ['#Manifest\nChu khac sheet mot\n#sonmochuong', H(9, 44), 1], [T.v[0], H(11, 36), 1], [T.v[1], H(15, 26), 1], ['#Manifest\nChu khac sheet hai\n#sonmochuong', H(16, 24), 1], [T.v[2], H(20, 19), 1]]; ds.forEach(([m, luc, reel], i) => db.posts.push({ id: 't' + i, message: m, luc, reel: !!reel, comments: reel ? [{ message: CMT3, cuaTrang: true }] : [] })); for (let i = 1; i <= 3; i++) TAB.e2f139[i][6] = null; }
if (C.kTay) { const cm = (tg) => [{ message: CMT3, cuaTrang: true, tacGiaId: tg }, { message: '', anh: true, cuaTrang: true, tacGiaId: tg }, { message: '', anh: true, cuaTrang: true, tacGiaId: tg }];
  db.posts.push({ trang: 'tramhuongthuducsonmochuong', tacGia: 'Trầm Hương Thủ Đức Sơn Mộc Hương', id: 'tayk2', message: TK[2][0], luc: H(14, 33), reel: true, comments: cm('2002002002') });
  db.posts.push({ trang: 'sonmochuongtramchuangiachuan', tacGia: 'Sơn Mộc Hương - Trầm Chuẩn - Giá Chuẩn', id: 'tayk3', message: TK[3][0], luc: H(14, 38), reel: true, comments: cm('3003003003') }); }
if (C.k2Tay) db.posts.push({ trang: 'tramhuongthuducsonmochuong', tacGia: 'Trầm Hương Thủ Đức Sơn Mộc Hương', id: 'tay2', message: TK[2][0], luc: T0 - 40 * 60000, reel: true, comments: [] });
if (C.b1Xong) db.posts.push({ id: 'd_b1', message: T.b1, luc: H(6, 36), comments: cmtDu('b1') });
if (C.vid24) { [['Video hai muoi lam gio cach chon vong tram cho nguoi moi choi', 25], ['Video ba muoi gio vi sao tram de moc khong phu keo', 30]].forEach(([m, h], i) => db.posts.push({ id: 'v24' + i, message: m, luc: T0 - h * 3600e3, reel: true, comments: [] })); }
if (C.vidCu) { const ds = [['Video cu mot ve cach chon vong tram huong 108 hat cho nguoi moi', 2], ['Video cu hai vi sao vong tram de moc khong keo sap', 4], ['#Manifest\nTai loc doi dao moi ngay\n#sonmochuong', 3], ['Video cu ba cach do tay chon size chuoi 108 hat', 6], ['Video cu bon gia vong tram huong 108 hat bao nhieu la hop ly', 12], ['Video cu nam phan biet tram nau dau va tram tu nhien', 20], ['Video cu sau bao quan vong tram khi deo hang ngay', 26], ['Loi chuc tai loc doi dao den voi moi nha moi ngay binh an', 5]]; ds.forEach(([m, n], i) => db.posts.push({ id: 'vc' + i, message: m, luc: T0 - n * 864e5, reel: true, comments: [{ message: 'gia bao nhieu shop', cuaTrang: false }] })); }
if (C.z8Cu) { while (TAB.apU3Ne.length < 8) TAB.apU3Ne.push([]); while (TAB.apU3Ne[7].length < 26) TAB.apU3Ne[7].push(null); TAB.apU3Ne[7][25] = 'LICH6|' + JSON.stringify({ ngay: '01-01-2026', ban: '6.28.2', may: 'GIAO', luc: T0 - 86400e3, gio: { v4: 300 } }); }
if (C.z2Giao) { while (TAB.apU3Ne.length < 2) TAB.apU3Ne.push([]); while (TAB.apU3Ne[1].length < 26) TAB.apU3Ne[1].push(null); TAB.apU3Ne[1][25] = `BAOCAO|${today}|GIAO|${T0 - 3600e3}`; }
if (C.khoaGiao) { while (TAB.apU3Ne[0].length < 26) TAB.apU3Ne[0].push(null); TAB.apU3Ne[0][25] = `KHOA|${today}|${C.khoaGiao}|GIAO|${T0 - 5 * 60000}`; }
if (C.trungBai) db.posts.push({ id: 'trung1', message: T.b1, luc: H(6, 39), comments: [] });
if (C.daXong || C.gan9) { // các bài hôm nay đã đăng sẵn (để thử phần khác)
  const ds = [['b1', T.b1, H(6, 36)], ['v1', T.v[0], H(7, 51), 1], ['m1', T.m[0], H(9, 6), 1], ['b2', T.b2, H(10, 21)], ['v2', T.v[1], H(11, 36), 1], ['m2', T.m[1], H(12, 51), 1], ['b3', T.b3, H(16, 36)], ['v3', T.v[2], H(17, 51), 1]];
  if (!C.gan9) ds.push(['m3', T.m[2], H(19, 21), 1]);
  for (const [k, msg, luc, reel] of ds) if (luc <= T0) db.posts.push({ id: 'd_' + k, message: msg, luc, reel: !!reel, comments: cmtDu(k.slice(0, 1) === 'b' ? k : 'v') });
}

// ---------------- trang Facebook giả ----------------
function htmlPage(url) {
  const u = new URL(url); const path = u.pathname.replace(/\/+$/, '');
  if (/^\/(100063806572484|nhangtramnuquangnam)$/.test(path)) return trangKhanh();
  const tk = trangCuaDuong(path); const laTrang = !!tk && path.split('/').filter(Boolean).length === 1;
  const dash = path.match(/^\/professional_dashboard\/profile_insights\/(views|messaging|audience)$/);
  if (path === '/content/insights') { db.dem.ttct = (db.dem.ttct || 0) + 1; let bai = ''; try { bai = Buffer.from(decodeURIComponent(u.searchParams.get('content_id') || ''), 'base64').toString().split(':').pop(); } catch (e) { /* */ } const p = db.posts.find((x) => x.id === bai); let h = 0; for (const ch of bai) h = h * 31 + ch.charCodeAt(0); h = Math.abs(h); const xem = p ? 100 + h % 900 : 0;
    return `<!doctype html><html><head><title>Facebook</title></head><body><div id="nd"></div><script>setTimeout(() => { document.getElementById('nd').innerHTML = ${JSON.stringify(`<div>Lượt xem theo thời gian</div><div>1 giờ</div><div>${xem}</div><div>Lượt xem</div><div>${Math.floor(xem / 2)}</div><div>Người xem</div><div>${h % 9} Lượt tương tác</div><div>1</div><div>Cảm xúc</div><div>Lượt theo dõi</div><div>${h % 4}</div><div>Lượt theo dõi</div>`)}; }, 1200);</script></body></html>`; }
  let tvHtml = '';
  if (path === '/professional_dashboard/content/content_library') { db.dem.tv = (db.dem.tv || 0) + 1; const H = ['', 'Bản xem trước', '', 'Lượt xem', 'Người xem', 'Lượt tương tác', 'Lượt theo dõi', 'Lượt hiển thị', 'Bình luận'];
    const ds = db.posts.filter((p) => (p.trang || 'vongtramhuongsonmochuong') === 'vongtramhuongsonmochuong' && p.reel).sort((a, b) => b.luc - a.luc);
    const esc2 = (x) => String(x).replace(/&/g, '&amp;').replace(/</g, '&lt;');
    const rows = ds.flatMap((p, i) => { const xem = i === 0 ? '1,2K' : String(300 + i * 111); const cid = Buffer.from('S:_I61595055137817:' + p.id + ':' + p.id).toString('base64'); const r = (x, td, goc) => `<div role="row">${['', '<span>0:45</span>' + esc2(p.message) + (goc ? '<span>Đã đăng •</span>' : '<span>Nhóm cư dân •</span>'), '', x, '1', '3', td, '9', '0'].map((c) => `<div role="gridcell">${c}</div>`).join('')}${goc ? `<a href="https://www.facebook.com/content/insights/?content_id=${cid}">Xem</a>` : ''}</div>`; return [r(xem, String(i % 4), true)].concat(i === 1 ? [r('9999', '0', false)] : []); }).join('');
    tvHtml = `<div id="tvnd"></div><script>setTimeout(() => { document.getElementById('tvnd').innerHTML = ${JSON.stringify(`<div role="grid"><div role="row">${H.map((h) => `<div role="columnheader">${h}</div>`).join('')}</div>`)} + ${JSON.stringify(rows)} + '</div>'; }, 1500);</script>`; }
  if (C.loiTrang && laTrang && demLan('loitrang') <= C.loiTrang) return '<!doctype html><html><head><title>Facebook</title></head><body><div>Đã xảy ra lỗi</div><div>Rất tiếc, đã xảy ra sự cố. Chúng tôi đang khắc phục.</div></body></html>';
  const attr = (x) => x.replace(/&/g, '&amp;').replace(/"/g, '&quot;').replace(/</g, '&lt;');
  const cmtHtml = (c) => `<div role="article">${c.anh ? '<img style="width:80px;height:80px;display:block" src="data:image/gif;base64,R0lGODlhAQABAAAAACw=">' : ''}<span class="ct">${attr(c.message || '')}</span><div role="button" aria-label="Thích bình luận của Sơn Mộc" class="clk" style="width:60px;height:20px">Thích</div></div>`;
  const id0 = path.split('/').filter(Boolean).pop();
  let dashHtml = '';
  if (dash) { db.dem['cs_' + dash[1]] = (db.dem['cs_' + dash[1]] || 0) + 1; const ky = u.searchParams.get('date_range') === 'LAST_28D' ? '28D' : u.searchParams.get('date_range') === 'LAST_7D' ? '7D' : '28D';
    const SO = { '7D': { views: ['11.330', '23%', 'g'], msg: ['2', '+0,0%'], aud: ['5', '-28,6%'], ngay: '9 Tháng 10 - 15 Tháng 10' }, '28D': { views: ['41.337', '-81%', 'r'], msg: ['6', '-95,3%'], aud: ['29', '+107,1%'], ngay: '18 Tháng 9 - 15 Tháng 10' } }[ky];
    const n = ky === '7D' ? 7 : 28; const t = dash[1];
    const nd = t === 'views' ? `<div><div><span>${SO.views[0]}</span></div><div><span style="color:${SO.views[2] === 'g' ? 'rgb(63, 187, 70)' : 'rgb(240, 40, 73)'}">\ufeff${SO.views[1]}</span></div><div><span>Lượt xem</span></div></div><div><div><span>2.642</span></div><div><span>79%</span></div><div><span>Lượt xem trong tối thiểu 3 giây</span></div></div><div>Nội dung hàng đầu</div><div><div><span>4.550</span></div><div><span>Lượt xem</span></div></div>`
      : t === 'messaging' ? `<div>${SO.msg[0]} Lượt bắt đầu cuộc trò chuyện qua tin nhắn</div><div>${SO.msg[1]} từ ${n} ngày trước</div><div><span>0</span><span>1</span><span>9</span></div><div><div><span>${SO.msg[0]}</span></div><div><span>Số người liên hệ nhắn tin</span></div></div><div><div><span>${SO.msg[0]}</span></div><div><span>Người liên hệ mới</span></div></div>`
      : `<div>${SO.aud[0]} Lượt theo dõi</div><div>${SO.aud[1]} từ ${n} ngày trước</div><div><span>0</span><span>2</span></div><div><div><span>${SO.aud[0]}</span></div><div><span>Số người theo dõi thực</span></div></div><div><div><span>1.575</span></div><div><span>Tổng số người theo dõi</span></div></div><div>170 Lượt truy cập</div><div>+19,7% từ ${n} ngày trước</div>`;
    dashHtml = `<div role="navigation"><div><span>Lượt xem</span></div><div><span>Nhắn tin</span></div></div><div id="dashnd"></div><script>setTimeout(() => { const tc = localStorage.getItem('__tc') || ${JSON.stringify(C.tc0 || 'Vòng Trầm Hương Sơn Mộc Hương .')}; const d = document.getElementById('dashnd'); ${C.csHong ? "d.innerHTML = '<div>Đã xảy ra lỗi khi tải dữ liệu</div>';" : `if (tc !== 'Vòng Trầm Hương Sơn Mộc Hương .') { d.innerHTML = '<div>${n} ngày qua: ${SO.ngay}</div><div><div><span>9</span></div><div><span>Lượt xem</span></div><div><span>1%</span></div></div>'; window.__saiTC = 1; } else d.innerHTML = ${JSON.stringify(`<div>${n} ngày qua: ${SO.ngay}</div>`)} + ${JSON.stringify('')} + ${'`'}${'${'}window.__nd${'}'}${'`'};`} }, 3000); window.__nd = ${JSON.stringify(nd)};</script>`; }
  const solo = !laTrang ? db.posts.filter((p) => p.id === id0) : [];
  const feed = (solo.length ? solo : db.posts.filter((p) => (p.trang || 'vongtramhuongsonmochuong') === (tk || 'vongtramhuongsonmochuong'))).slice().sort((a, b) => b.luc - a.luc).map((p) => {
    const cms = (p.comments || []).map(cmtHtml).join('');
    const cw = `<form><div contenteditable="true" data-lexical-editor="true" aria-label="Bình luận dưới tên __TC__" style="min-height:30px;border:1px solid #999"></div><input type="file" accept="image/*,video/*"><div role="button" aria-label="Bình luận" class="gui" style="width:30px;height:20px">></div></form>`;
    const reel = p.reel ? `<div class="hdr"></div><a href="/reel/${p.id}/"><img style="width:120px;height:70px;display:block" src="data:image/gif;base64,R0lGODlhAQABAAAAACw="></a>` : '';
    const imgs = p.nImg && !(p.edit && p.edit.nImg === 0) ? Array.from({ length: p.nImg }, () => '<img style="width:150px;height:150px;display:inline-block" src="data:image/gif;base64,R0lGODlhAQABAAAAACw=">').join('') : '';
    return `<div class="post" data-id="${p.id}" data-ten="${attr(TRANG[p.trang || 'vongtramhuongsonmochuong'].ten)}" data-reel="${p.reel ? 1 : ''}" style="margin:100px 0;border:1px solid #ccc">${reel}<div class="txt">${attr(p.message)}</div><div class="imgs">${imgs}</div><div role="button" aria-label="Thích" class="lk" style="width:60px;height:20px">Thích</div><div role="button" aria-label="Bày tỏ cảm xúc" class="bt" style="width:60px;height:20px">x</div><div role="button" class="dots" aria-label="Hành động đối với bài viết này của Vòng Trầm Hương Sơn Mộc Hương ." style="width:30px;height:20px">...</div><div class="cms">${cms}</div><div class="cw">${cw}</div></div>`;
  }).join('');
  const init = { khongNhom: !!C.khongNhom, khongNutTrang: !!C.khongNutTrang, chuyenHoi: !!C.chuyenHoi, laTrang, tenTrang: TRANG[tk || 'vongtramhuongsonmochuong'].ten, menuChi: C.menuChi || null, trang: tk || 'vongtramhuongsonmochuong', trangs: Object.values(TRANG).map((x) => x.ten).concat(['Nguyễn Hoàng Giang', 'Phan Cao']), tc0: C.tc0 || '', loi: C.loi || {}, groups: 9, preTicked: 3, treo: false, kieuMoi: false, matChuReel: !!C.matChuReel, soanHong: !!C.soanHong, videoDung: C.videoDung || 0, hopLa: !!C.hopLa, cuonKhuat: !!C.cuonKhuat, nhomHong: !!C.nhomHong, hongSize: C.hongSize || 0, lucKhac: !!C.lucKhac, theHong: !!C.theHong, suKien: !!C.suKien, suaTiep: !!C.suaTiep, reelMoi: !!C.reelMoi, goiYKhongCo: !!C.goiYKhongCo, cdBaiViet: !!C.cdBaiViet, suaHongHet: !!C.suaHongHet, suaMoi: !!C.suaMoi, suaCu: !!C.suaCu, suaCuCham: !!C.suaCuCham, khongMucNhom: !!C.khongMucNhom };
  return `<!doctype html><html><head><title>Facebook</title></head><body style="height:4000px;background:#fff"><div role="navigation" aria-label="Cài đặt và kiểm soát tài khoản"><div id="acc" role="button" aria-label="${C.nhanCu ? 'Trang cá nhân của bạn' : 'Account, your profile'}" style="width:100px;height:30px"><svg aria-label="Trang cá nhân của bạn" role="img" width="20" height="20"></svg>acc</div></div>
${dash ? dashHtml : ''}${tvHtml}<div id="prompt" style="${dash || tvHtml ? 'display:none' : ''}"><div role="button" style="width:200px;height:30px">Bạn đang nghĩ gì?</div><div role="button" style="width:100px;height:30px">Ảnh/video</div></div><div id="feed">${dash || tvHtml ? '' : feed}</div>
<script id="init" type="application/json">${JSON.stringify(init)}</script><script>document.querySelectorAll('[aria-label="Bình luận dưới tên __TC__"]').forEach((e) => e.setAttribute('aria-label', 'Bình luận dưới tên ' + (localStorage.getItem('__tc') || ${JSON.stringify(C.tc0 || 'Vòng Trầm Hương Sơn Mộc Hương .')})));</script><script>${PAGE_JS}</script>${C.hopTrangMoi ? `<script>setTimeout(() => { if (localStorage.getItem('__trangmoi')) return; const o = document.createElement('div'); o.id = 'trangmoi'; o.setAttribute('role', 'dialog'); o.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,.4);z-index:99999'; o.innerHTML = '<div style="background:#fff;margin:100px auto;width:400px;padding:20px"><h2><span>Đã cập nhật Trang của bạn!</span></h2><div role="switch" aria-checked="false">Email</div><div role="button" id="dungtrang" style="width:200px;height:30px">Dùng Trang</div></div>'; document.body.appendChild(o); o.querySelector('#dungtrang').onclick = () => { localStorage.setItem('__trangmoi', '1'); window.__ev && window.__ev.push('DUNG_TRANG'); o.remove(); }; }, 3000);</script>` : ''}</body></html>`;
}
function trangKhanh() { // trang Khanh: mục "Đáng chú ý" (bài nổi bật cũ) + bài ghim + dòng thời gian
  let tid = 0;
  const hdr = (t, real) => `<div class="hd"><a href="/khanhtramhuongqn" style="display:inline-block;width:132px;height:20px">Khanh Trầm Hương</a> <a class="tsa" href="https://www.facebook.com${real}" style="display:inline-block;width:35px;height:16px"><span aria-labelledby="tid${++tid}"><span></span></span></a><span id="tid${tid}" style="display:none">${t.replace(' trước', '')}</span><span>${/trước$/.test(t) ? t : ''} ·</span><div role="button" aria-label="Hành động đối với bài viết này của Khanh Trầm Hương" style="width:30px;height:20px">...</div></div>`;
  const bai = (t, h, x, them) => `<div style="margin:300px 0 0;border:1px solid #ccc;min-height:200px">${them || ''}<div>${hdr(t, h)}<div>${x}</div></div></div>`;
  const noiBat = `<div class="nb"><h2>Đáng chú ý</h2><div style="display:flex">${bai('3 ngày trước', '/nhangtramnuquangnam/posts/pfbidNB1', 'Bai noi bat moi dang 3 ngay')}${bai('20 Tháng 8, 2026', '/nhangtramnuquangnam/posts/pfbidNB2', 'Bai noi bat cu')}</div></div>`;
  const feed = `<div class="fd"><h2>Bài viết</h2><div role="button" style="width:60px;height:20px">Bộ lọc</div>`
    + bai('2 tuần trước', '/nhangtramnuquangnam/posts/pfbidGHIM', 'Bai ghim cu tu lau', '<div>Bài viết đã ghim</div>')
    + bai('1 ngày trước', '/nhangtramnuquangnam/posts/pfbidA1', 'Bai moi mot ngay') + bai('2 ngày trước', '/nhangtramnuquangnam/posts/pfbidA2', 'Bai moi hai ngay')
    + bai('5 ngày trước', '/nhangtramnuquangnam/posts/pfbidA3', 'Bai moi nam ngay') + bai('8 ngày trước', '/nhangtramnuquangnam/posts/pfbidA4', 'Bai cu tam ngay')
    + bai('2 tuần trước', '/nhangtramnuquangnam/posts/pfbidA5', 'Bai cu hai tuan') + bai('3 tuần trước', '/nhangtramnuquangnam/posts/pfbidA6', 'Bai cu ba tuan') + '</div>';
  return `<!doctype html><html><body style="height:6000px;background:#fff"><div>Khanh Trầm Hương</div>${noiBat}${feed}</body></html>`;
}

// ---------------- Lark + Graph giả ----------------
const colIdx = (s) => { let n = 0; for (const ch of s) n = n * 26 + (ch.charCodeAt(0) - 64); return n - 1; };
function docVung(tab, vung) { const m = vung.match(/^([A-Z]+)(\d+)(?::([A-Z]+)(\d+))?$/); const c0 = colIdx(m[1]), r0 = +m[2] - 1, c1 = colIdx(m[3] || m[1]), r1 = +(m[4] || m[2]) - 1; const v = TAB[tab]; const out = []; for (let r = r0; r <= Math.min(r1, v.length - 1); r++) { const row = []; for (let c = c0; c <= c1; c++) row.push((v[r] || [])[c] == null ? null : v[r][c]); out.push(row); } return out; }
function ghiVung(range, val) { const [tab, vung] = range.split('!'); const m = vung.match(/^([A-Z]+)(\d+)/); const r = +m[2] - 1, c = colIdx(m[1]); while (TAB[tab].length <= r) TAB[tab].push([]); TAB[tab][r][c] = val; db.writes.push({ range, val: typeof val === 'string' ? val : JSON.stringify(val).slice(0, 60) }); }
const demLan = (k) => (db.dem[k] = (db.dem[k] || 0) + 1);
function xuLyXhr(req, may) {
  let u = req.url;
  if (C.quotaTu && db.now >= H(...C.quotaTu) && /open\.larksuite\.com\/open-apis/.test(u) && !/\/bot\/v2\/hook\//.test(u) && !/tenant_access_token/.test(u)) { db.quota = (db.quota || 0) + 1; const t = JSON.stringify({ code: 99991403, msg: 'request trigger frequency limit' }); return { status: 200, responseText: t, b64: Buffer.from(t).toString('base64'), ctype: 'application/json' }; }
  if (u.includes('/space/api/box/stream/download/all/')) { db.webDl = (db.webDl || 0) + 1; if (C.webHong === 'login') return { status: 200, b64: Buffer.from('<html><body>passport login '.padEnd(900, 'x') + '</body></html>').toString('base64'), ctype: 'text/html' }; const tk = decodeURIComponent(u.split('/download/all/')[1].split('/')[0]); u = 'https://open.larksuite.com/open-apis/drive/v1/medias/' + tk + '/download'; db.larkGoi--; }
  if (u.includes('graph.facebook.com')) {
    if (C.fb500 && demLan('fb') <= C.fb500) return { status: 500, responseText: '{"error":{"message":"tạm lỗi","code":2}}' };
    if (/\/comments/.test(u)) { db.dem.cmtApi = (db.dem.cmtApi || 0) + 1; const id = u.match(/graph\.facebook\.com\/(?:v[\d.]+\/)?([^/?]+)\/comments/)[1]; const p = db.posts.find((x) => x.id === id); const pid = TRANG[(p && p.trang) || 'vongtramhuongsonmochuong'].id; return { status: 200, responseText: JSON.stringify({ data: (p ? p.comments : []).map((c) => ({ message: c.message, from: { id: c.cuaTrang ? (c.tacGiaId || pid) : '555' }, ...(c.anh ? { attachment: { type: 'photo' } } : {}) })) }) }; }
    if (/\/me\/accounts/.test(u)) { if (C.maTrang) return { status: 400, responseText: JSON.stringify({ error: { message: 'Tried accessing nonexisting field (accounts) on node type (Page)', code: 100 } }) }; return { status: 200, responseText: JSON.stringify({ data: Object.values(TRANG).map((x, i) => ({ id: x.id, name: x.ten, access_token: 'EAA' + 'PQRS'[i].repeat(60) })) }) }; }
    { const m = u.match(/graph\.facebook\.com\/(?:v[\d.]+\/)?(\d+)\/posts/); if (m && m[1] !== '1196332230224812') { const k = trangCuaId(m[1]); db.dem['api_' + m[1]] = (db.dem['api_' + m[1]] || 0) + 1; const since = +((u.match(/since=(\d+)/) || [])[1] || 0) * 1000; return { status: 200, responseText: JSON.stringify({ data: db.posts.filter((p) => p.trang === k && p.luc >= since && !p.chuaLen).sort((a, b) => b.luc - a.luc).map((p) => ({ id: p.id, message: p.message, created_time: iso(p.luc), permalink_url: lkPost(p), ...(C.vidCu && p.comments ? { comments: { data: p.comments.map((c) => ({ message: c.message, from: { id: c.cuaTrang ? m[1] : '555' } })) } } : {}) })) }) }; } }
    { const m = u.match(/graph\.facebook\.com\/(?:v[\d.]+\/)?([^/?]+)\/video_insights/); if (m) { db.dem.vins = (db.dem.vins || 0) + 1; if (C.vinsNull) return { status: 400, responseText: JSON.stringify({ error: { message: '(#10) Application does not have permission for this action', code: 10 } }) }; let h = 0; for (const ch of m[1]) h = h * 31 + ch.charCodeAt(0); h = Math.abs(h); return { status: 200, responseText: JSON.stringify({ data: [{ name: 'blue_reels_play_count', values: [{ value: 100 + h % 900 }] }, { name: 'post_video_followers', values: [{ value: h % 7 }] }] }) }; } }
    if (/1196332230224812\?fields=name/.test(u)) return { status: 200, responseText: JSON.stringify({ name: 'Vòng Trầm Hương Sơn Mộc Hương .', id: '1196332230224812' }) };
    const since = +((u.match(/since=(\d+)/) || [])[1] || 0) * 1000; const lim = /limit=1(&|$)/.test(u) ? 1 : 50;
    return { status: 200, responseText: JSON.stringify({ data: db.posts.filter((p) => (p.trang || 'vongtramhuongsonmochuong') === 'vongtramhuongsonmochuong' && p.luc >= since && !p.chuaLen).sort((a, b) => b.luc - a.luc).slice(0, lim).flatMap((p) => [{ id: p.id, message: p.message, created_time: iso(p.luc), permalink_url: lkPost(p), ...(C.vidCu && p.comments && /comments\.filter/.test(decodeURIComponent(u)) ? { comments: { data: p.comments.map((c) => ({ message: c.message, from: { id: c.cuaTrang ? '1196332230224812' : '555' } })) } } : {}) }].concat(C.reelKep && p.reel ? [{ id: p.id + '_kep', message: p.message, created_time: iso(p.luc), permalink_url: lkPost(p) }] : [])) }) };
  }
  if (u.includes('drive.usercontent.google.com')) { db.drive = (db.drive || 0) + 1; return { status: 200, responseText: C.driveOk ? '// ==UserScript==\n// @version      0.0\n// ==/UserScript==' : '<html>Google Drive không thể quét vi-rút cho tệp này</html>' }; }
  if (u.includes('raw.githubusercontent.com') && /smh\.user\.js/.test(u)) { return { status: 200, responseText: '// ==UserScript==\n// @version      ' + (C.banMoi || '6.18') + '\n// ==/UserScript==' }; }
  if (u.includes('raw.githubusercontent.com')) { db.git = (db.git || 0) + 1; return { status: 200, responseText: JSON.stringify({ chinhThuc: '6.16', choDuyet: C.gitCho ? { ban: C.gitCho, tomTat: 'Sửa lỗi thử nghiệm A\nTối ưu: kiểm comment 3 → 1 lần', luc: Date.now() } : null }) }; }
  if (u.includes('tenant_access_token')) { if (/"app_id":""/.test(req.data || '')) { db.larkSaiMa = (db.larkSaiMa || 0) + 1; return { status: 200, responseText: JSON.stringify({ code: 10003, msg: 'invalid app_id' }) }; } return { status: 200, responseText: JSON.stringify({ code: 0, tenant_access_token: 't', expire: 7200 }) }; }
  if (u.includes('tenant_access_token_cu')) return { status: 200, responseText: JSON.stringify({ code: 0, tenant_access_token: 't', expire: 7200 }) };
  if (u.includes('/root_folder/meta')) return { status: 200, responseText: JSON.stringify({ code: 0, data: { token: 'fldROOT' } }) };
  if (u.includes('/files/upload_all')) { db.tepLark = db.tepLark || {}; const tk = 'boxTHU' + (db.seq++); db.tepLark[tk] = (req.fd || {}).text || ''; db.tepTen = (req.fd || {}).ten; return { status: 200, responseText: JSON.stringify({ code: 0, data: { file_token: tk } }) }; }
  if (/\/drive\/v1\/files\/[^/]+\/download/.test(u)) { const tk = u.match(/files\/([^/]+)\/download/)[1]; return { status: 200, responseText: (db.tepLark || {})[tk] || '' }; }
  if (u.includes('/medias/batch_get_tmp_download_url')) { db.larkGoi++; db.batch = (db.batch || 0) + 1; if (C.batchHong) return { status: 200, responseText: JSON.stringify({ code: 1069902, msg: 'no permission' }) }; const tks = (u.split('?')[1] || '').split('&').map((p) => decodeURIComponent(p.split('=')[1] || '')); return { status: 200, responseText: JSON.stringify({ code: 0, data: { tmp_download_urls: tks.map((t) => ({ file_token: t, tmp_download_url: 'https://internal-api-drive-stream.larksuite.com/tmp/' + encodeURIComponent(t) })) } }) }; }
  if (u.includes('internal-api-drive-stream.larksuite.com/tmp/')) { db.tmpDl = (db.tmpDl || 0) + 1; u = 'https://open.larksuite.com/open-apis/drive/v1/medias/' + u.split('/tmp/')[1] + '/download'; db.larkGoi--; }
  if (u.includes('/medias/')) {
    db.larkGoi++; const tk = decodeURIComponent(u.match(/medias\/([^/]+)\/download/)[1]); db.dl[tk] = (db.dl[tk] || 0) + 1;
    if (/^vk/.test(tk)) { const r = TAB.em39qJ.concat(TAB['4OtbFA']).find((x) => x && Array.isArray(x[8]) && x[8][0].fileToken === tk) || (TAB.ZSDDld.find((x) => x && Array.isArray(x[9]) && x[9][0].fileToken === tk) || []).slice(1); return { status: 200, b64: Buffer.alloc(r && r[8] ? r[8][0].size : 1000, 5).toString('base64'), ctype: 'video/mp4' }; }
    if (/^vid/.test(tk)) { const r = TAB.e2f139.find((x) => x && Array.isArray(x[13]) && x[13][0].fileToken === tk); return { status: 200, b64: Buffer.alloc(r ? r[13][0].size : 1000, 7).toString('base64'), ctype: 'video/mp4' }; }
    if (tk === 'nhac217') return { status: 200, b64: WAV.toString('base64'), ctype: 'audio/wav' };
    if (db.imgBytes[tk]) return { status: 200, b64: db.imgBytes[tk], ctype: 'image/jpeg' };
    return { status: 200, b64: /BIG/.test(tk) ? BIG : SMALL, ctype: 'image/jpeg' };
  }
  if (u.includes('/values_image')) { db.larkGoi++; const b = JSON.parse(req.data); const tk = 'img_' + (db.seq++); db.imgBytes[tk] = Buffer.from(b.image).toString('base64'); db.images.push({ range: b.range, size: b.image.length, name: b.name }); ghiVung(b.range.split(':')[0], { fileToken: tk, type: 'embed-image', text: b.name }); return { status: 200, responseText: '{"code":0,"data":{}}' }; }
  if (u.includes('/values_batch_update')) { db.larkGoi++; const b = JSON.parse(req.data); for (const vr of b.valueRanges) ghiVung(vr.range.split(':')[0], vr.values[0][0]); return { status: 200, responseText: '{"code":0,"data":{}}' }; }
  if (/\/values$/.test(u.split('?')[0]) && req.method === 'PUT') { db.larkGoi++; const b = JSON.parse(req.data); ghiVung(b.valueRange.range.split(':')[0], b.valueRange.values[0][0]); return { status: 200, responseText: '{"code":0,"data":{}}' }; }
  if (u.includes('/values_batch_get')) { db.larkGoi++; db.dem['doc_' + may] = (db.dem['doc_' + may] || 0) + 1; const q = decodeURIComponent((u.split('ranges=')[1] || '').split('&')[0]); const vr = q.split(',').map((r) => { const [tab, vung] = r.split('!'); return { range: r, values: docVung(tab, vung) }; }); return { status: 200, responseText: JSON.stringify({ code: 0, data: { valueRanges: vr } }) }; }
  if (u.includes('/values/')) { db.larkGoi++; const m = decodeURIComponent(u.split('/values/')[1]).split('?')[0]; const [tab, vung] = m.split('!'); db.dem['doc_' + may] = (db.dem['doc_' + may] || 0) + 1; return { status: 200, responseText: JSON.stringify({ code: 0, data: { valueRange: { values: docVung(tab, vung) } } }) }; }
  if (u.includes('/bot/v2/hook/')) { const nhom = /CSKQ/.test(u) ? 'CSKQ' : /CSLOI/.test(u) ? 'CSLOI' : u.includes(BIMAT.hookBaoCao.split('/').pop()) ? 'BAOCAO' : 'LOI'; const b = JSON.parse(req.data); db.sent.push({ nhom, may, card: b.card || null, luc: db.now ? fmt(db.now) : '', text: b.content ? b.content.text : '[THẺ] ' + (((b.card.header||{}).title||{}).content||'') + ' ⏎ ' + b.card.elements.map((e) => (e.text ? e.text.content : e.content || '')).filter(Boolean).join(' ⏎ ') }); return { status: 200, responseText: JSON.stringify({ code: 0 }) }; }
  return { status: 200, responseText: '{"code":0}' };
}

// ---------------- 1 máy = 1 trình duyệt riêng (Tampermonkey riêng) ----------------
const GIO_LICH = { b1: 395, v1: 470, m1: 545, b2: 620, v2: 695, m2: 770, b3: 995, v3: 1070, m3: 1160 }; // 6:35 7:50 9:05 10:20 11:35 12:50 16:35 17:50 19:20
let browser;
async function moMay(may, tuLuc, gmCu) {
  const ctx = await browser.newContext({ acceptDownloads: true, viewport: { width: 1500, height: 1000 } });
  const page = await ctx.newPage();
  const m = { may, ctx, page, errors: [], song: true };
  page.on('pageerror', (e) => m.errors.push('PAGEERR ' + e.message + ' @ ' + String(e.stack || '').split('\n').slice(1, 4).join(' | ')));
  page.on('console', (x) => { if ((x.type() === 'error' && !/Failed to load resource|favicon/.test(x.text())) || /vẽ popup lỗi/.test(x.text())) m.errors.push('CONSOLE ' + x.text().slice(0, 300) + ' ' + (x.args()[2] ? '' : '')); });
  page.on('dialog', (d) => { m.hoi = (m.hoi || []).concat(d.message().slice(0, 80)); d.accept(m.traLoi || '').catch(() => {}); });
  await page.clock.install({ time: tuLuc });
  await page.route('https://www.facebook.com/**', (r) => r.fulfill({ status: 200, headers: C.csp ? { 'Content-Security-Policy': "script-src 'self' 'unsafe-inline' blob: https:" } : {}, contentType: 'text/html; charset=utf-8', body: htmlPage(r.request().url()).normalize('NFC') }));
  await page.exposeFunction('__dbPost', (o) => { const id = (o.reel ? '9' : 'n') + (db.seq++); db.posts.push({ trang: o.trang || 'vongtramhuongsonmochuong', tacGia: o.tacGia, id, message: o.text, luc: o.ts, nImg: o.nImg, nhom: o.nhom, loc: o.loc, red: o.red, reel: !!o.reel, tags: o.tags, thumb: o.thumb, may, comments: [], chuaLen: !!C.reelKhongLen }); return id; });
  await page.exposeFunction('__dbDraft', (o) => { db.drafts.push(o); });
  await page.exposeFunction('__dbSwitch', (o) => { db.chuyen = (db.chuyen || []).concat([{ may, luc: db.now ? fmt(db.now) : '', tu: o.tu, sang: o.sang }]); });
  await page.exposeFunction('__dbLike', (o) => { db.likes.push(o); });
  await page.exposeFunction('__dbEdit', (o) => { db.edits.push(o); const p = db.posts.find((x) => x.id === o.id); if (p) { p.edit = Object.assign({}, p.edit || {}, o); if ('nImg' in o) p.nImg = o.nImg; if (o.red) p.red = true; } });
  await page.exposeFunction('__dbComment', (o) => { const p = db.posts.find((x) => x.id === o.id); if (!p) return; if (C.cmtMat && p.reel && p.message === T.v[0] && o.anh && db.now < p.luc + 9 * 60000) { db.matCmt = (db.matCmt || 0) + 1; console.log('>>> Facebook làm mất 1 comment ảnh của Video 1 lúc', fmt(db.now)); return; } const tg = Object.values(TRANG).find((x) => x.ten === o.tacGia); p.comments.push({ message: o.message, anh: o.anh, cuaTrang: true, tacGiaId: tg ? tg.id : '999', tacGia: o.tacGia }); });
  await page.exposeFunction('__xhr', (req) => xuLyXhr(req, may));
  const seed = Object.assign(C.khongMa ? {} : { that_fb_token: 'EAA' + 'T'.repeat(60), that_fb_token_luc: T0 - 86400e3 }, may ? { that_may6: may } : {});
  if (may && !C.khongLich) seed['that_ngay6_' + today] = { gio: GIO_LICH, s: {}, ngoai: {}, tao: T0 };
  if (C.chayThu) seed.that_chay_thu6 = true;
  if (C.tamDung) seed.that_tam_dung = true;
  if (C.tuDongTat) seed.that_tu_dong6 = false;
  if (!C.k1moi) { seed.that_k1_cu = true; seed.that_k1_trang6 = 'cu'; } // (6.21) kịch bản cũ chạy với kênh 1 cũ
  if (C.csBuoc7) { const nb = { tu: '09/10/2026', den: '15/10/2026' }, nb2 = { tu: '18/09/2026', den: '15/10/2026' }; seed.that_cs6 = { tuan: '16-10-2026', chay: { loai: 'soan', buoc: 7, f5: 0, batDau: T0, kq: { '7Dviews': { so: 11330, pct: null, ngay: nb }, '7Dmessaging': { so: 2, pct: null, ngay: nb }, '7Daudience': { so: 5, pct: null, ngay: nb }, '28Dviews': { so: 41337, pct: null, ngay: nb2 }, '28Dmessaging': { so: 6, pct: null, ngay: nb2 }, '28Daudience': { so: 29, pct: null, ngay: nb2 } } } }; }
  if (C.csHook) seed.that_bimat6 = { appId: BIMAT.appId, appSecret: BIMAT.appSecret, hookLoi: BIMAT.hookLoi, hookBaoCao: BIMAT.hookBaoCao, csKQ: 'https://open.larksuite.com/open-apis/bot/v2/hook/CSKQ-0000-0000-0000-000000000000', csLoi: 'https://open.larksuite.com/open-apis/bot/v2/hook/CSLOI-000-0000-0000-000000000000' };
  if (C.cmtKenh) seed.that_cmt6 = { kenh: C.cmtKenh, luc: 1 };
  if (C.mayCu && may === 'CAO') { const st = seed['that_ngay6_' + today]; for (const k of ['v1', 'm1']) st.s[k] = { tt: 'bo', lyDo: 'thử' }; st.s.b2 = { tt: 'cho', may: 'CAO', batDau: T0 - 9 * 3600e3 }; }
  if (C.mayCu && may === 'GIAO') { const st = seed['that_ngay6_' + today]; for (const k of ['v1', 'm1']) st.s[k] = { tt: 'bo', lyDo: 'thử' }; }
  if (C.duLieuCu) seed.that_du_lieu6 = { luc: T0 - 8 * 3600e3, loai: 'chot', ban: 1, chung: { co: '', pool: [] }, ngay: { [today]: { bai: null, soHangBai: 0, v: [], m: [] } }, chuaNgayB: [5, 6], chuaNgayV: [] };
  if (may && !C.khongNhac) seed.that_nhac6_info = { ten: 'co-san.mp3', size: 1000, luc: T0 - 86400e3, tu: 'tay' }; // (không dùng tới: video manifest đã tạo sẵn trong kho)
  if (C.daXong || C.gan9 || C.b1Xong) { const s = {}; for (const p of db.posts.filter((x) => x.id.startsWith('d_'))) { const k = p.id.slice(2); s[k] = { tt: 'xong', suaXong: 1, luc: p.luc, id: p.id, link: lkPost(p), may: 'GIAO', kiem: [{ luc: p.luc + 120000, ok: true }], cmtOk: true, can: { text: [], anh: [] } }; } seed['that_ngay6_' + today] = { gio: GIO_LICH, s, ngoai: {}, tao: T0 }; }
  if (C.mayCao && seed['that_ngay6_' + today]) { const st = seed['that_ngay6_' + today]; const k = Object.keys(st.s).pop(); st.s[k].may = 'CAO'; }
  if (C.lichLech && may === 'GIAO') seed['that_ngay6_' + today] = { gio: Object.assign({}, GIO_LICH, { v4: 420, v5: 520 }), s: {}, ngoai: {}, tao: T0, thuTu27: 1 }; // lịch cũ (bản trước) của Máy Giao
  if (C.lichLech && may === 'CAO') seed['that_ngay6_' + today] = { gio: Object.assign({}, GIO_LICH, { v4: 1110, v5: 1250 }), s: {}, ngoai: {}, tao: T0, thuTu27: 2, banLich: '6.28.2' };
  if (C.webData) seed.that_lark_webdata6 = { luc: T0, token: 'x', tabs: JSON.parse(JSON.stringify(TAB)) };
  if (C.tranCung) seed.that_lark_dem = { ngay: today, so: 60, loai: {} };
  if (C.ketDang && seed['that_ngay6_' + today]) seed['that_ngay6_' + today].s.b1 = { tt: 'dang', batDau: T0 - 20 * 60000, may: 'GIAO' };
  if (C.gioV1 && seed['that_ngay6_' + today]) seed['that_ngay6_' + today].gio = Object.assign({}, GIO_LICH, { v1: C.gioV1[0] * 60 + C.gioV1[1] });
  if (C.cmt19) { const st = seed['that_ngay6_' + today]; st.s.v3 = Object.assign(st.s.v3, { cmtOk: false, kiem: [{ luc: H(17, 53), ok: false }, { luc: H(18, 1), ok: false }, { luc: H(18, 11), ok: false }], guiBu: 1, can: { text: [CMT3], anh: ['tokO2', 'tokP2'] } }); const p = db.posts.find((x) => x.id === 'd_v3'); p.comments = p.comments.slice(0, 1); }
  if (C.khanh) seed.that_khanh = {};
  await page.addInitScript(({ src, seed, gmCu, mfKeys }) => {
    window.__SRC_THU = src;
    const store = JSON.parse(localStorage.getItem('__gm') || 'null') || gmCu || Object.assign({}, seed);
    const save = () => localStorage.setItem('__gm', JSON.stringify(store)); save();
    try { Object.defineProperty(Document.prototype, 'visibilityState', { configurable: true, get() { return localStorage.getItem('__an') === '1' ? 'hidden' : 'visible'; } }); } catch (e) { /* */ }
    try { Document.prototype.hasFocus = function () { return localStorage.getItem('__an') !== '1'; }; window.focus = () => { (window.__ev = window.__ev || []).push('FOCUS ' + new Date().toTimeString().slice(0, 5)); if (localStorage.getItem('__focusHong') !== '1') localStorage.setItem('__an', '0'); }; } catch (e) { /* */ }
    window.GM_getValue = (k, d) => (k in store && store[k] !== undefined ? JSON.parse(JSON.stringify(store[k])) : d);
    window.GM_setValue = (k, v) => { store[k] = v === undefined ? undefined : JSON.parse(JSON.stringify(v)); save(); };
    window.GM_deleteValue = (k) => { delete store[k]; save(); };
    window.GM_listValues = () => Object.keys(store);
    window.GM_registerMenuCommand = () => {}; window.GM_openInTab = () => {}; window.GM_addElement = () => {}; window.GM_info = { script: { version: '6.0' }, scriptSource: window.__SRC_THU || '' }; window.unsafeWindow = window;
    window.GM_notification = (o) => { const a = JSON.parse(localStorage.getItem('__notif') || '[]'); a.push(o.title); localStorage.setItem('__notif', JSON.stringify(a)); };
    window.GM_xmlhttpRequest = async (o) => {
      let fd = null; if (typeof FormData !== 'undefined' && o.data instanceof FormData) { const t = o.data.get('file'); fd = { ten: o.data.get('file_name'), text: t ? await t.text() : '' }; }
      window.__xhr({ url: o.url, method: o.method, data: fd ? null : o.data, fd }).then((r) => {
        if (o.responseType === 'text' && r.responseText != null) r.response = r.responseText;
        if (r.mang === 'network') { o.onerror && o.onerror({}); return; }
        if (o.responseType === 'blob' && r.b64) { const bin = atob(r.b64); const u8 = new Uint8Array(bin.length); for (let i = 0; i < bin.length; i++) u8[i] = bin.charCodeAt(i); o.onload({ status: r.status, response: new Blob([u8], { type: r.ctype }) }); }
        else o.onload(r);
      });
    };
    // video manifest tạo sẵn trong kho (trình duyệt thử không mã hoá được H.264)
    const q = indexedDB.open('smh6_kho', 1); q.onupgradeneeded = () => q.result.createObjectStore('tep');
    q.onsuccess = () => { const dbi = q.result; const t = dbi.transaction('tep', 'readwrite'); const os = t.objectStore('tep'); for (const k of mfKeys) { const g = os.get(k); g.onsuccess = () => { if (!g.result) os.put({ blob: new Blob([new Uint8Array(90000).fill(3)], { type: 'video/mp4' }), luc: Date.now(), size: 90000, type: 'video/mp4' }, k); }; } };
  }, { src: SCRIPT, seed, gmCu: gmCu || null, mfKeys: [1, 2, 3].map((i) => `mf|${today}|${i - 1}|mf${i}`).concat([1, 2, 3, 4].map((i) => `mf|${today}|${i + 2}|mft${i}`)).concat([1, 2, 3].map((i) => `mf|${mai}|${i - 1}|mfm${i}`)) });
  page.on('domcontentloaded', () => { page.addScriptTag({ content: SCRIPT }).catch(() => {}); });
  await page.goto('https://www.facebook.com/vongtramhuongsonmochuong', { waitUntil: 'domcontentloaded', timeout: 30000 });
  m.ev = async (f, a) => { for (let i = 0; i < 12; i++) { try { return await page.evaluate(f, a); } catch (e) { await page.waitForTimeout(250); } } return null; };
  m.gm = async () => (await m.ev(() => JSON.parse(localStorage.getItem('__gm')))) || {};
  m.lay = async (k) => (await m.gm())['that_' + k];
  m.nk = async () => { const g = await m.gm(); return Object.keys(g).filter((k) => k.startsWith('that_nk6_')).sort().map((k) => g[k]).flat().sort((a, b) => a.luc - b.luc).map((x) => fmt(x.luc) + ' ' + x.msg.replace(/\s*\[tab [^\]]+\]$/, '') + (x.so > 1 ? ` [x${x.so}]` : '')); };
  m.bay = async () => (await m.ev(() => Date.now())) || 0;
  return m;
}
async function tatMay(m) { m.gmLuu = await m.gm(); m.song = false; await m.ctx.close().catch(() => {}); }

// tua thời gian cho mọi máy đang bật (cùng nhịp)
let MAYS = [];
async function ban(m) { const g = await m.ev(() => { const k = JSON.parse(localStorage.getItem('__gm') || '{}').khoa_dang_bai_that; return { ban: !!(k && k.ban), dn: !!document.querySelector('#smhfb .hdg.dem') }; }); return !g || g.ban || g.dn; }
async function tua(denMs, moiBuoc) {
  for (let lan = 0; lan < 100000; lan++) {
    const song = MAYS.filter((m) => m.song); if (!song.length) return;
    const now = await song[0].bay(); db.now = now; if (now >= denMs) return;
    let b = false; for (const m of song) if (await ban(m)) { b = true; break; }
    const buoc = b ? 1000 : Math.min(30000, Math.max(1000, denMs - now));
    for (const m of song) { if (b) await m.page.clock.runFor(buoc).catch(() => {}); else await m.page.clock.fastForward(buoc).catch(() => {}); }
    await song[0].page.waitForTimeout(b ? 60 : 25);
    if (moiBuoc) { const dung = await moiBuoc(now); if (dung) return; }
  }
}

(async () => {
  browser = await chromium.launch({ ...(fs.existsSync('/opt/pw-browsers/chromium-1194/chrome-linux/chrome') ? { executablePath: '/opt/pw-browsers/chromium-1194/chrome-linux/chrome' } : {}), args: ['--no-sandbox', '--autoplay-policy=no-user-gesture-required'] });
  const KQ = { scen: SCEN };
  const chup = async (m, ten, h) => { await m.page.screenshot({ path: `${OUT}/${SCEN}_${ten}.png`, clip: { x: 0, y: 0, width: 1500, height: h || 260 } }).catch(() => {}); };
  const bam = async (m, sel) => { const ok = await m.ev((s) => { const e = document.querySelector(s); if (!e) return false; e.click(); return true; }, sel); await m.page.waitForTimeout(150); return ok; };
  const moRong = async (m, tab) => { await m.ev(() => { const b = document.querySelector('#smhfb [data-a="morong"]'); if (b && !document.querySelector('#smhfb .tabs')) b.click(); }); await m.page.waitForTimeout(300); if (tab) { await bam(m, `#smhfb [data-tab="${tab}"]`); await m.page.waitForTimeout(300); } };
  const txt = async (m, sel) => (await m.ev((s) => { const e = document.querySelector(s); return e ? e.innerText.replace(/\s+/g, ' ').trim() : ''; }, sel)) || '';

  const giao = C.may.includes('GIAO') ? await moMay('GIAO', T0) : null;
  const cao = C.may.includes('CAO') ? await moMay('CAO', T0) : null;
  const may0 = C.may[0] === '' ? await moMay('', T0) : null;
  MAYS = [giao, cao, may0].filter(Boolean);
  const M = giao || cao || may0;
  await M.page.waitForTimeout(800);

  if (['webdoc', 'webkhong', 'quotadang', 'quotaweb', 'quotalogin', 'taisan2', 'bccaoz2', 'bccao', 'bccaomuon', 'trancung', 'z1cao', 'chendong', 'hxkhongmuc', 'trungtt', 'suamoi', 'suacu', 'suacucham', 'hxnhom', 'hxmenu', 'hxchuyen', 'chisovid', 'bai4', 'hx', 'tatdang', 'trungbai', 'tong12', 'taibh', 'ngay2may', 'ngay', 'bu', 'chot', 'haimay', 'thieu', 'baocao', 'cmt19', 'cuonkhuat', 'nhomhong', 'hongv1', 'luckhac', 'thehong', 'sukien', 'sualoi', 'suatiep', 'reelmoi', 'reelmoitim', 'reelmoibv', 'suahong', 'trungcmt', 'khongan', 'khonganmai', 'videodung', 'hopla', 'moanh', 'treo', 'loitrang', 'loitrang3', 'vtrung', 'nhacsheet', 'chuanbi', 'hb21', 'capnhat', 'thunap', 'thunapcsp', 'kenh', 'kenhcta', 'kenhnhac', 'kenhmatrang', 'kenhnick', 'mf1', 'kenhtay', 'giaomuon', 'giaomuonma', 'bucao', 'bugiao', 'bucaomenu', 'themvideo', 'chiso', 'chisoloi', 'chisoban', 'chisoloi10', 'chisotv'].includes(SCEN)) {
    if (SCEN === 'ngay' || SCEN === 'bu') { for (const m of MAYS) await moRong(m, 'homnay'); } // popup mở rộng suốt ngày (che giữa màn hình) như lúc nhân sự hay để
    await tua(H(C.den[0], C.den[1]), async (now) => { if (C.banPhim && now >= H(...C.banPhim[0]) && now < H(...C.banPhim[1])) await M.page.keyboard.press('Shift').catch(() => {}); return (SCEN === 'ngay' || SCEN === 'baocao') && db.sent.some((x) => x.nhom === 'BAOCAO' && /^Báo cáo/.test(x.text)) && !(await M.lay('dang_do')) && (await M.bay()) > H(19, 50); });
  } else if (SCEN === 'caothay' || SCEN === 'tranh' || SCEN === 'kenhcao' || SCEN === 'kenhcaomt') {
    await tua(H(...C.giaoTat)); await tatMay(giao); console.log('>>> tắt Máy Giao lúc', fmt(H(...C.giaoTat)));
    await tua(H(...C.giaoMo));
    const g2 = await moMay('GIAO', await cao.bay(), giao.gmLuu); MAYS = [g2, cao]; KQ.giaoMoLai = fmt(await cao.bay()); KQ.errG1 = giao.errors; Object.assign(giao, g2);
    await tua(H(C.den[0], C.den[1]));
  } else if (SCEN === 'cmt') {
    await tua(H(C.den[0], C.den[1]));
    await moRong(M, 'homnay'); KQ.homnay = (await txt(M, '#smhfb .nd')).slice(0, 900);
    // bấm tay 3 nút kiểm comment
    for (const a of ['kiem1', 'kiem3', 'kiem24']) { await bam(M, `#smhfb [data-a="${a}"]`); await tua((await M.bay()) + 60000); KQ['nut_' + a] = await txt(M, '#smhfb .tb-quet') + ' | ' + await txt(M, '#smhfb .tn3'); }
  } else if (SCEN === 'nhansu') {
    KQ.choDong = []; 
    // nhân sự thao tác liên tục từ 6:30 → script chờ tối đa 10 phút rồi vẫn đăng
    await tua(H(C.den[0], C.den[1]), async (now) => { if (now < H(6, 52)) await M.page.keyboard.press('Shift').catch(() => {}); const t = await txt(M, '#smhfb .hdg.cho'); if (t && !KQ.choDong.includes(t.slice(0, 90))) { KQ.choDong.push(t.slice(0, 90)); if (KQ.choDong.length === 1) await chup(M, 'cho', 160); } return false; });
  } else if (SCEN === 'demnguoc') {
    let daDung = 0; KQ.tieuDe = []; KQ.banner = [];
    await tua(H(C.den[0], C.den[1]), async () => {
      const b = await txt(M, '#smhfb .hdg.dem'); if (b) { const t = await M.ev(() => document.title); if (KQ.tieuDe.length < 6) { KQ.tieuDe.push(t); KQ.banner.push(b.slice(0, 90)); } if (!daDung) { daDung = 1; await chup(M, 'dem', 200); await bam(M, '#smhfb [data-a="dndung"]'); KQ.sauDung = await txt(M, '#smhfb .hdg.dem'); await chup(M, 'dung', 200); for (let i = 0; i < 20; i++) { await M.page.clock.runFor(1000); await M.page.waitForTimeout(40); } KQ.van_dung_sau20s = !!(await txt(M, '#smhfb .hdg.dem')); await bam(M, '#smhfb [data-a="dntiep"]'); KQ.sauTiep = await txt(M, '#smhfb .hdg.dem'); }
        else if (daDung === 1 && /Bài 1/.test(b) === false) { /* */ } }
      return false;
    });
    // lần 2: Hoãn 10 phút (bài kế tiếp Video 1 lúc 7:50 → đổi lịch cho nhanh)
  } else if (SCEN === 'chendong') { // (6.28) Bài 1 đã đăng → 08:00 nhân sự chèn 1 dòng bài viết hôm nay phía TRÊN dòng cũ → Bài 2 vẫn phải lấy chữ của dòng cũ, không đăng lại Bài 1
    await tua(H(8, 0));
    const t9 = { b1: 'Dong chen moi bai mot khac han noi dung de kiem tra ghim dong', b2: 'Dong chen moi bai hai khac han noi dung de kiem tra ghim dong', b3: 'Dong chen moi bai ba khac han noi dung de kiem tra ghim dong' };
    const iHom = TAB.apU3Ne.findIndex((r, i) => i > 0 && r && r[7] === today); TAB.apU3Ne.splice(iHom, 0, hangBai(today, t9, 'chen'));
    KQ.chenO = iHom + 1; await bam(M, '#smhfb [data-a="docsheet"]');
    await tua(H(C.den[0], C.den[1]));
  } else if (SCEN === 'uicmt') { // (6.27.1) tab Comment & Thẻ tách 2 phần
    await moRong(M, 'comment'); await M.page.waitForTimeout(600);
    const e1 = await M.page.$('#smhfb'); if (e1) await e1.screenshot({ path: __dirname + '/kq/uicmt_cmt.png' });
    KQ.bamThe = await bam(M, '#smhfb [data-a="cmtphan"][data-k="the"]'); await M.page.waitForTimeout(600);
    if (e1) await e1.screenshot({ path: __dirname + '/kq/uicmt_the.png' });
    KQ.coKhoThe = !!(await M.page.$('#smhfb [data-a="luuthe"]')); KQ.coCmt = !!(await M.page.$('#smhfb [data-a="luucmt"]'));
  } else if (SCEN === 'uitre') {
    await moRong(M, 'homnay'); await bam(M, '#smhfb [data-a="tamdung"]'); await M.page.waitForTimeout(500);
    await bam(M, '#smhfb .it[data-k="m1"]'); await M.page.waitForTimeout(500);
    const el7 = await M.page.$('#smhfb .tlay'); if (el7) await el7.screenshot({ path: __dirname + '/kq/uitre_lich.png' });
    KQ.lich = await txt(M, '#smhfb .tl'); KQ.kq = await txt(M, '#smhfb .ct .kq');
    await tua(H(C.den[0], C.den[1]));
  } else if (SCEN === 'tamdung') {
    await moRong(M, 'homnay'); await bam(M, '#smhfb [data-a="tamdung"]'); KQ.lucDung = fmt(await M.bay()); KQ.sauDung = await txt(M, '#smhfb .foot');
    await tua(H(7, 44)); console.log('>>> F5 lúc', fmt(await M.bay())); await M.page.reload(); await M.page.waitForTimeout(1500);
    await tua(H(7, 48)); KQ.van_dung_7_48 = await M.lay('tam_dung');
    await tua(H(C.den[0], C.den[1])); KQ.cuoi_tam_dung = await M.lay('tam_dung');
  } else if (SCEN === 'hoan') {
    let daHoan = false;
    await tua(H(C.den[0], C.den[1]), async () => { if (!daHoan && await txt(M, '#smhfb .hdg.dem')) { daHoan = true; KQ.lucHoan = fmt(await M.bay()); await bam(M, '#smhfb [data-a="dndung"]'); KQ.sauHoan = await txt(M, '#smhfb .bar'); } return false; });
  } else if (SCEN === 'chaythu' || SCEN === 'chaythuv') {
    await tua(H(SCEN === 'chaythuv' ? 8 : 7, 58), async () => !!(await M.lay('cho_tay6')));
    KQ.choTay = JSON.stringify(await M.lay('cho_tay6')).slice(0, 120); KQ.nutDangVien = await M.ev(() => { const b = document.querySelector('[aria-label="Đăng"]'); return b ? b.style.outline : 'khong'; });
    await chup(M, 'soan', 700);
    console.log('>>> người bấm Đăng lúc', fmt(await M.bay()));
    await M.ev(() => { const b = Array.from(document.querySelectorAll('[aria-label="Đăng"]')).find((x) => x.offsetParent); b && b.click(); });
    await tua(H(C.den[0], C.den[1]));
  } else if (SCEN === 'khanh') {
    await tua(H(C.den[0], C.den[1]), async () => db.sent.some((x) => /Khanh Trầm Hương 7 ngày/.test(x.text)));
    await tua((await M.bay()) + 30000);
    KQ.url = await M.ev(() => location.pathname);
  } else if (SCEN === 'taoanh') {
    await moRong(M, 'manifest'); await chup(M, 'tab0', 700);
    await M.page.click('#smhfb [data-a="taoanh"]').catch((e) => { KQ.loiBam0 = e.message; }); await M.page.waitForTimeout(400); KQ.khongNen = M.hoi; KQ.canhNen = await txt(M, '#smhfb .nd .the-nd'); await chup(M, 'khongnen', 500);
    const inp = await M.page.$('#smhfb input[data-a="chonnen"]');
    await inp.setInputFiles([{ name: 'nen1.jpg', mimeType: 'image/jpeg', buffer: NEN }, { name: 'nen2.jpg', mimeType: 'image/jpeg', buffer: NEN }]);
    await M.page.waitForTimeout(500);
    await M.page.fill('#smhfb input[data-o="vung"]', 'G220:G222'); await M.page.waitForTimeout(200);
    await M.page.click('#smhfb [data-a="taoanh"]').catch((e) => { KQ.loiBam = e.message; });
    KQ.tienTrinh = []; await M.page.waitForTimeout(300); KQ.hoatDong = await M.lay('hoat_dong'); KQ.hdgLuc = await txt(M, '#smhfb .hdg'); KQ.denLuc = await M.ev(() => document.querySelector('#smhfb .bar .den').className); await M.page.screenshot({ path: `${OUT}/taoanh_hdg.png`, clip: { x: 0, y: 0, width: 1500, height: 300 } });
    for (let i = 0; i < 200; i++) { await M.page.clock.runFor(500); await M.page.waitForTimeout(80); const t = await txt(M, '#smhfb .mfp'); if (t && KQ.tienTrinh[KQ.tienTrinh.length - 1] !== t) { KQ.tienTrinh.push(t); if (KQ.tienTrinh.length === 2) await chup(M, 'dangtao', 760); } if ((await M.ev(() => document.querySelectorAll('#smhfb .mfo').length)) >= 2 && /Đã tạo/.test(await txt(M, '#smhfb .nd'))) break; }
    KQ.soAnh = await M.ev(() => document.querySelectorAll('#smhfb .mfo img').length); KQ.anhLarkTruocDan = db.images.length;
    await chup(M, 'luoi', 900);
    await bam(M, '#smhfb .mfo img[data-i="0"]'); await M.page.waitForTimeout(300); KQ.modal = await txt(M, '#smhfb .mfxd'); await M.page.screenshot({ path: `${OUT}/taoanh_xem.png` });
    await bam(M, '#smhfb .mfxa [data-a="xemanh"]:last-child'); KQ.modal2 = await txt(M, '#smhfb .mfxd');
    await M.page.click('#smhfb .mfxa img').catch(() => {}); KQ.vanMo = !!(await M.ev(() => document.querySelector('#smhfb .mfxem')));
    await bam(M, '#smhfb .mfxd [data-a="dongxem"]'); KQ.daDong = !(await M.ev(() => document.querySelector('#smhfb .mfxem')));
    await bam(M, '#smhfb .mfo [data-a="taolai"][data-i="1"]'); for (let i = 0; i < 40; i++) { await M.page.clock.runFor(500); await M.page.waitForTimeout(60); }
    await bam(M, '#smhfb .mfo [data-a="chonanh"][data-i="1"]');
    KQ.nutDan = await txt(M, '#smhfb [data-a="dananh"]');
    await bam(M, '#smhfb [data-a="dananh"]');
    for (let i = 0; i < 100; i++) { await M.page.clock.runFor(500); await M.page.waitForTimeout(80); if (/Xong: đã dán/.test(await txt(M, '#smhfb .nd'))) break; }
    KQ.sauDan = await txt(M, '#smhfb .mfp') + ' | ' + (await txt(M, '#smhfb .mfluoi')).slice(0, 200); KQ.images = db.images; KQ.hd = await txt(M, '#smhfb .tb-quet, #smhfb .hdg'); await chup(M, 'dan', 900);
  } else if (SCEN === 'taoanhtay') {
    M.taiVe = []; M.page.on('download', (d) => M.taiVe.push(d.suggestedFilename()));
    await moRong(M, 'manifest'); await chup(M, 'tab0', 700);
    KQ.macDinhTay = await M.ev(() => !!document.querySelector('#smhfb textarea[data-o="mfchu"]'));
    if (!KQ.macDinhTay) { await bam(M, '#smhfb [data-a="mfnguon"][data-k="tay"]'); await M.page.waitForTimeout(300); }
    const inp = await M.page.$('#smhfb input[data-a="chonnen"]');
    await inp.setInputFiles([{ name: 'nen1.jpg', mimeType: 'image/jpeg', buffer: NEN }, { name: 'nen2.jpg', mimeType: 'image/jpeg', buffer: NEN }]); await M.page.waitForTimeout(400);
    await M.page.fill('#smhfb textarea[data-o="mfchu"]', 'Đón nhận tài lộc\nNăng lượng tốt đang tìm đến bạn.\nCmt "đón nhận" để đón nhận năng lượng\n\nTháng này đủ đầy\nKhông thiếu việc, không thiếu tiền.\nCmt "đủ đầy" nếu bạn muốn điều này\n\n\nMong cuối tháng vẫn còn tiền\nCó khoản dự phòng.\nCmt "còn dư" nếu đây là mục tiêu của bạn');
    await M.page.waitForTimeout(300); KQ.dem = await txt(M, '#smhfb [data-mfdem]'); KQ.nutTao = await txt(M, '#smhfb [data-a="taoanh"]'); await chup(M, 'nhap', 900);
    const goiTruoc = db.larkGoi; await M.page.click('#smhfb [data-a="taoanh"]');
    for (let i = 0; i < 200; i++) { await M.page.clock.runFor(500); await M.page.waitForTimeout(80); if (/Đã tạo \d+\/\d+ ảnh/.test(await txt(M, '#smhfb .mfp + .mo, #smhfb .nd'))) break; }
    KQ.larkKhiTao = db.larkGoi - goiTruoc; KQ.soAnh = await M.ev(() => document.querySelectorAll('#smhfb .mfo img').length); KQ.luoi = (await txt(M, '#smhfb .mfluoi')).slice(0, 300); KQ.coNutDan = await M.ev(() => !!document.querySelector('#smhfb [data-a="dananh"]'));
    await chup(M, 'luoi', 900);
    await bam(M, '#smhfb .mfo [data-a="taianhmf"][data-i="1"]'); await M.page.waitForTimeout(800);
    await bam(M, '#smhfb [data-a="taiallmf"]'); for (let i = 0; i < 10; i++) { await M.page.clock.runFor(800); await M.page.waitForTimeout(150); }
    await M.page.waitForTimeout(1500); KQ.taiVe = M.taiVe; KQ.chuSau = await M.lay('mf_chu6');
  } else if (SCEN === 'ngaymai' || SCEN === 'ngaymaihuy') {
    await tua((await M.bay()) + 20000); await moRong(M, 'ngaymai'); await chup(M, 'tab', 900);
    KQ.lichMai = await M.ev(() => Array.from(document.querySelectorAll('#smhfb .it')).map((x) => x.innerText.replace(/\s+/g, ' ').slice(0, 70)));
    KQ.nutHomNay = await (async () => { await moRong(M, 'homnay'); const r = await M.ev(() => Array.from(document.querySelectorAll('#smhfb .it .tk')).map((x) => x.innerText.trim())); await moRong(M, 'ngaymai'); return r; })();
    M.traLoi = ''; const ok = await bam(M, '#smhfb .it[data-k="b2"] [data-a="soan"]'); KQ.bamSoan = ok;
    await tua(H(14, 30), async () => !!(await M.lay('cho_tay6')));
    KQ.choTay = JSON.stringify(await M.lay('cho_tay6')).slice(0, 160); await chup(M, 'dasoan', 760);
    KQ.chuTrongHop = await M.ev(() => { const e = document.querySelector('[contenteditable="true"][data-lexical-editor="true"]'); return e ? e.innerText.slice(0, 40) : 'không có hộp'; });
    if (SCEN === 'ngaymaihuy') {
      await M.ev(() => { document.querySelector('[aria-label="Đóng hộp thoại của công cụ tạo"]').click(); }); await M.page.waitForTimeout(200); await M.ev(() => { Array.from(document.querySelectorAll('[role=dialog] [role=button]')).find((b) => b.innerText === 'Bỏ bài viết').click(); });
    } else await M.ev(() => { const b = Array.from(document.querySelectorAll('[aria-label="Đăng"]')).find((x) => x.offsetParent); b && b.click(); });
    await tua(H(C.den[0], C.den[1]));
    KQ.choTaySau = await M.lay('cho_tay6'); KQ.maiB2 = (((await M.lay('ngay6_' + mai)) || { s: {} }).s.b2 || {}); KQ.ngoai = Object.values(((await M.lay('ngay6_' + today)) || {}).ngoai || {}).map((x) => ({ id: x.id, giu: x.giu, cmtOk: x.cmtOk, kiem: (x.kiem || []).length, guiBu: x.guiBu }));
    await moRong(M, 'ngaymai'); await chup(M, 'sau', 900);
  } else if (SCEN === 'themgiua') { // (6.19.3) 14:30 sheet thêm 2 video; 14:40 nhân sự đăng tay video thêm thứ 1 (đúng chữ trong sheet); 14:45 bấm Đọc lại sheet
    await tua(H(14, 30)); while (TAB.e2f139.length < 225) TAB.e2f139.push(blank(14)); TAB.e2f139.push(hangThem(0, false), hangThem(1, false));
    await tua(H(14, 40)); db.posts.push({ id: 'tayv4', message: TV[0], luc: H(14, 40), reel: true, comments: [] });
    await tua(H(14, 45)); await moRong(giao, 'saptoi'); KQ.bamDoc = await bam(giao, '#smhfb [data-a="docsheet"]');
    await tua(H(15, 0)); await moRong(giao, 'homnay'); KQ.homnay1500 = (await txt(giao, '#smhfb .tl')).replace(/\s+/g, ' ').slice(0, 900);
    await tua(H(C.den[0], C.den[1]));
  } else if (SCEN === 'chisoan' || SCEN === 'chisoanhong') { // (6.27) thứ 6 tab ẩn: tự chuyển tab / không được thì thông báo + chuông 15 phút
    for (const m of MAYS) await m.ev((h) => { localStorage.setItem('__an', '1'); if (h) localStorage.setItem('__focusHong', '1'); }, SCEN === 'chisoanhong');
    await tua(H(C.den[0], C.den[1]));
    KQ.anCuoi = {}; for (const m of MAYS) KQ.anCuoi[m.may] = await m.ev(() => localStorage.getItem('__an') + ' | ' + (window.__ev || []).filter((x) => /FOCUS/.test(x)).join(',') + ' | notif: ' + localStorage.getItem('__notif'));
  } else if (SCEN === 'nhaytab' || SCEN === 'nhaytab2') { // (6.25) 5:00 / 12:30 tab ẩn → tự đưa tab fb lên; Máy Cao không nhảy
    for (const m of MAYS) await m.ev(() => localStorage.setItem('__an', '1'));
    await tua(H(C.den[0], C.den[1]));
    KQ.anCuoi = {}; for (const m of MAYS) KQ.anCuoi[m.may] = await m.ev(() => localStorage.getItem('__an') + ' ' + (window.__ev || []).filter((x) => /FOCUS/.test(x)).join(','));
  } else if (SCEN === 'soanan') { // (6.19.3) bấm Soạn Video 1 rồi tab bị ẩn giữa chừng → vẫn chỉ SOẠN (không thành đăng thật)
    await tua((await M.bay()) + 20000); await moRong(M, 'homnay');
    KQ.bamSoan = await bam(M, '#smhfb .it[data-k="v1"] [data-a="soan"]');
    let daAn = 0; await tua(H(7, 5), async () => { const nk = (await M.nk()).join('\n'); if (!daAn && /Video 1: V2\./.test(nk)) { daAn = 1; await M.ev(() => localStorage.setItem('__an', '1')); KQ.anLuc = fmt(await M.bay()); } return false; });
    await M.ev(() => localStorage.setItem('__an', '0')); KQ.hienLuc = fmt(await M.bay());
    await tua(H(C.den[0], C.den[1]));
    KQ.choTay = String(JSON.stringify(await M.lay('cho_tay6'))).slice(0, 120); KQ.v1 = JSON.stringify((((await M.lay('ngay6_' + today)) || { s: {} }).s.v1) || {}).slice(0, 200);
  } else if (SCEN === 'chisolai') { // (6.28.1) Soạn thử → xem trước đầy đủ; Gửi thử / Gửi ngay trong 30 phút dùng lại bản soạn + ghi chú
    await tua((await M.bay()) + 20000); await moRong(M, 'homnay'); await bam(M, '#smhfb [data-tab="chiso"]'); await M.page.waitForTimeout(300);
    const cho = async (h) => { await tua((await M.bay()) + 30000); for (let i = 0; i < 40; i++) { const c = await M.lay('cs6'); if (c && !c.chay && !c.yc) break; await tua((await M.bay()) + 15000); } await tua((await M.bay()) + 30000); await moRong(M, 'homnay'); await bam(M, '#smhfb [data-tab="chiso"]'); await M.page.waitForTimeout(300); KQ['sau_' + h] = (await txt(M, '#smhfb .nd')).replace(/\s+/g, ' ').slice(0, 2600); KQ['lark_' + h] = db.sent.map((x) => x.nhom).join(','); KQ['trang_' + h] = [db.dem.cs_views || 0, db.dem.tv || 0].join('/'); };
    await bam(M, '#smhfb [data-a="cs_soan"]'); await cho('soan'); await chup(M, 'chisolai', 1400);
    await M.page.fill('#smhfb [data-o="cs_ghichu"]', 'Tuần này chạy thêm quảng cáo'); await M.page.waitForTimeout(200); KQ.ghichu = await M.lay('csghichu6');
    await bam(M, '#smhfb [data-a="cs_thu"]'); await cho('thu');
    await bam(M, '#smhfb [data-a="cs_ngay"]'); await cho('ngay');
    KQ.ghichuSau = await M.lay('csghichu6'); KQ.tin = db.sent.map((x) => x.nhom + ': ' + x.text.slice(0, 1500));
  } else if (SCEN === 'cach20') { // (6.28.2) trong lúc soạn Video 1, trang có bài kênh 1 khác lên (đăng tay) → không bấm Đăng, chờ đủ 20 phút
    let chen = 0; await tua(H(C.den[0], C.den[1]), async (now) => { if (!chen) { const st = await M.lay('ngay6_' + today); const v1 = st && st.s && st.s.v1; if (v1 && v1.tt === 'dang') { chen = now; db.posts.push({ id: 'chen1', message: 'Bai dang tay chen ngang luc dang soan', luc: now, comments: [] }); KQ.chenLuc = fmt(now); } } return false; });
    const st = await M.lay('ngay6_' + today); KQ.v1 = JSON.stringify((st.s || {}).v1 || {}).slice(0, 220); KQ.nk = (await M.nk()).filter((x) => /Video 1|chen|20 phút/.test(x)).slice(-10);
  } else if (SCEN === 'xep9' || SCEN === 'xep16' || SCEN === 'xeptre' || SCEN === 'xepanh') { // (6.28.3) xếp đều lịch kênh 1 + 3 khung Sáng/Chiều/Tối
    await tua(H(C.den[0], C.den[1]));
    for (const m of MAYS.filter((x) => x.song)) { const st = await m.lay('ngay6_' + today); KQ['gio_' + m.may] = Object.entries(st.gio || {}).filter(([k]) => /^[bvm]\d$/.test(k)).sort((a, b) => a[1] - b[1]).map(([k, v]) => k + ' ' + p2(Math.floor(v / 60)) + ':' + p2(v % 60)).join(' · '); KQ['nk_' + m.may] = (await m.nk()).filter((x) => /Xếp đều|Lịch 2 máy|15 phút/.test(x)).slice(-6); }
    await moRong(M, 'homnay'); await M.page.waitForTimeout(300); KQ.khung = (await txt(M, '#smhfb .tl')).replace(/\s+/g, ' ').slice(0, 900); await M.page.locator('#smhfb .tl').screenshot({ path: `${OUT}/${SCEN}_khung.png` }).catch((e) => { KQ.chupLoi = e.message; });
    if (SCEN === 'xeptre') { const L = db.posts.filter((p) => p.trang === undefined || p.trang === 'vongtramhuongsonmochuong').filter((p) => /^\d+$|^n/.test(p.id)).sort((a, b) => a.luc - b.luc); KQ.dang = L.map((p) => fmt(p.luc) + ' ' + String(p.message).slice(0, 18)).join(' | '); }
  } else if (SCEN === 'lich2may' || SCEN === 'lich1may') { // (6.28.2)
    await tua(H(C.den[0], C.den[1]));
    for (const m of MAYS) { const st = await m.lay('ngay6_' + today); KQ['gio_' + m.may] = JSON.stringify({ v3: st.gio.v3, v4: st.gio.v4, v5: st.gio.v5, ban: st.banLich }); KQ['nk_' + m.may] = (await m.nk()).filter((x) => /Lịch 2 máy|Xếp lại giờ/.test(x)).slice(-8); }
    KQ.Z8 = String((TAB.apU3Ne[7] || [])[25] || '').slice(0, 300);
  } else if (SCEN === 'trangmoi' || SCEN === 'ketdang') { // (6.28.7)
    await tua(H(C.den[0], C.den[1]));
    KQ.nk = (await M.nk()).filter((x) => /Dùng Trang|Gỡ kẹt|Đã đăng Bài 1|Bắt đầu đăng Bài 1/.test(x)).slice(-8); KQ.b1 = JSON.stringify(((await M.lay('ngay6_' + today)) || { s: {} }).s.b1 || {}).slice(0, 160); KQ.ev = await M.ev(() => (window.__ev || []).filter((x) => /DUNG_TRANG/.test(x)));
  } else if (SCEN === 'tv24' || SCEN === 'chisobuoc7') { // (6.28.1)
    await tua(H(C.den[0], C.den[1]));
  } else if (SCEN === 'chisonut') { // (6.20) nút tab Chỉ số tuần
    await tua((await M.bay()) + 20000); await moRong(M, 'homnay'); await bam(M, '#smhfb [data-tab="chiso"]'); await M.page.waitForTimeout(300); KQ.tab0 = (await txt(M, '#smhfb .nd')).replace(/\s+/g, ' ').slice(0, 600);
    const cho = async (h) => { await tua((await M.bay()) + 30000); for (let i = 0; i < 40; i++) { const c = await M.lay('cs6'); if (c && !c.chay && !c.yc) break; await tua((await M.bay()) + 15000); } await tua((await M.bay()) + 30000); await moRong(M, 'homnay'); await bam(M, '#smhfb [data-tab="chiso"]'); await M.page.waitForTimeout(300); KQ['sau_' + h] = (await txt(M, '#smhfb .nd')).replace(/\s+/g, ' ').slice(0, 700); KQ['lark_' + h] = db.sent.map((x) => x.nhom).join(','); };
    await bam(M, '#smhfb [data-a="cs_soan"]'); await cho('soan'); await chup(M, 'chiso', 900);
    await bam(M, '#smhfb [data-a="cs_thu"]'); await cho('thu');
    await bam(M, '#smhfb [data-a="cs_ngay"]'); await cho('ngay');
    M.hoi = []; await bam(M, '#smhfb [data-a="cs_ngay"]'); await cho('ngay2'); KQ.hoi = M.hoi;
    KQ.urlCuoi = await M.ev(() => location.pathname);
  } else if (SCEN === 'soanmaik') { // (6.19.3) soạn thử video kênh 2 của ngày mai khi đang ở trang kênh 1 (phải đổi trang + đổi tư cách)
    await tua((await M.bay()) + 20000); await moRong(M, 'ngaymai');
    KQ.lichMai = await M.ev(() => Array.from(document.querySelectorAll('#smhfb .it')).map((x) => x.innerText.replace(/\s+/g, ' ').slice(0, 60)));
    KQ.bamSoan = await bam(M, '#smhfb .it[data-k="k2a"] [data-a="soan"]');
    await tua(H(21, 58), async () => !!(await M.lay('cho_tay6')));
    KQ.choTay = String(JSON.stringify(await M.lay('cho_tay6'))).slice(0, 200); KQ.url = await M.ev(() => location.pathname);
    KQ.hop = await M.ev(() => { const d = Array.from(document.querySelectorAll('[role=dialog]')).map((x) => x.innerText.replace(/\s+/g, ' ').slice(0, 80)); return d; });
    KQ.chuyen = db.chuyen || [];
  } else if (SCEN === 'soanf5') {
    await tua((await M.bay()) + 20000); await moRong(M, 'homnay');
    M.traLoi = ''; await bam(M, '#smhfb .it[data-k="b1"] [data-a="soan"]');
    KQ.soanWDang = []; await tua(H(6, 30), async () => { const t = await txt(M, '#smhfb-soan-w'); if (t && KQ.soanWDang[KQ.soanWDang.length - 1] !== t) KQ.soanWDang.push(t.slice(0, 120)); return !!(await M.lay('cho_tay6')) || !!(await M.ev(() => document.querySelector('#smhfb.anim.dong'))); }); KQ.tuThu = await M.ev(() => document.getElementById('smhfb').className);
    await tua(H(6, 30), async () => !!(await M.lay('cho_tay6'))); KQ.soanW = await txt(M, '#smhfb-soan-w'); KQ.soanWLop = await M.ev(() => (document.getElementById('smhfb-soan-w') || {}).className); await M.page.screenshot({ path: `${OUT}/soanf5_soanw.png` }); KQ.sauSoanThuGon = !(await M.ev(() => !!document.querySelector('#smhfb .tabs'))); KQ.nhoThu = await txt(M, '#smhfb-nho');
    KQ.b1SauSoan = (((await M.lay('ngay6_' + today)) || { s: {} }).s.b1 || {}).tt; await moRong(M, 'homnay'); KQ.nutB1 = await txt(M, '#smhfb .it[data-k="b1"] .tk'); KQ.moB1 = await txt(M, '#smhfb .it[data-k="b1"] .t');
    await chup(M, 'dasoan', 700);
    console.log('>>> F5 lúc', fmt(await M.bay())); await M.page.reload(); await M.page.waitForTimeout(1500);
    await tua((await M.bay()) + 20000); await moRong(M, 'homnay'); KQ.sauF5 = await txt(M, '#smhfb .it[data-k="b1"]'); KQ.choTaySauF5 = !!(await M.lay('cho_tay6'));
    await tua((await M.bay()) + 75000); await moRong(M, 'homnay'); KQ.sau95s = await txt(M, '#smhfb .it[data-k="b1"]'); KQ.choTaySau95s = !!(await M.lay('cho_tay6')); KQ.thongBao = await M.ev(() => localStorage.getItem('__notif'));
    // bấm Soạn Video 1 ngay khi bản soạn Bài 1 còn treo → hỏi bỏ bản cũ
    M.hoi = []; M.traLoi = ''; await bam(M, '#smhfb .it[data-k="v1"] [data-a="soan"]'); KQ.hoiV1 = M.hoi;
    await tua(H(6, 50), async () => { const p = await M.lay('cho_tay6'); return !!(p && p.slot === 'v1'); });
    KQ.choTayV1 = ((await M.lay('cho_tay6')) || {}).slot; KQ.b1Cuoi = (((await M.lay('ngay6_' + today)) || { s: {} }).s.b1 || {}).tt; await chup(M, 'v1', 700);
    await tua((await M.bay()) + 30000); await M.page.reload(); await M.page.waitForTimeout(1500); await tua((await M.bay()) + 120000);
    KQ.dbg = await M.ev(() => ({ popup: !!document.getElementById('smhfb'), bar: (document.querySelector('#smhfb .bar') || {}).innerText, hd: localStorage.getItem('__gm').slice(0, 0) })); KQ.nkCuoi = ((await M.lay('nk6_' + today)) || []).slice(-6).map((x) => x.msg.slice(0, 90)); KQ.hoatDong = await M.lay('hoat_dong'); KQ.gioLuc = fmt(await M.bay());
    KQ.dom = await M.ev(() => ({ dialog: document.querySelectorAll('[role=dialog]').length, caidat: document.body.innerText.includes('Cài đặt thước phim'), the: !!document.querySelector('[aria-label="Thêm thẻ"]'), vitri: !!document.querySelector('[aria-label="Vị trí"]'), dangdo: localStorage.getItem('__gm').includes('"that_dang_do":{'), khoa: JSON.parse(localStorage.getItem('__gm')).khoa_dang_bai_that }));
    KQ.v1SauF5 = { choTay: !!(await M.lay('cho_tay6')), tt: (((await M.lay('ngay6_' + today)) || { s: {} }).s.v1 || {}).tt }; await moRong(M, 'homnay'); KQ.dongV1 = await txt(M, '#smhfb .it[data-k="v1"]');
  } else if (SCEN === 'lamngaycao' || SCEN === 'sheetdadang') {
    let bam1 = 0; KQ.lan = [];
    await tua(H(C.den[0], C.den[1]), async () => { await M.page.keyboard.press('Shift').catch(() => {}); if (bam1 < 3 && await M.ev(() => !!document.querySelector('#smhfb [data-a="lamngay"]'))) { bam1++; KQ.lan.push(fmt(await M.bay())); await bam(M, '#smhfb [data-a="lamngay"]'); } return false; });
  } else if (SCEN === 'lamngay') {
    await tua(H(6, 37), async () => { await M.page.keyboard.press('Shift').catch(() => {}); return !!(await M.ev(() => document.querySelector('#smhfb [data-a="lamngay"]'))); });
    KQ.truoc = await txt(M, '#smhfb .hdg'); await bam(M, '#smhfb [data-a="lamngay"]'); KQ.nho = await txt(M, '#smhfb-nho');
    await tua(H(C.den[0], C.den[1]));
  } else if (SCEN === 'suavid') {
    KQ.hd = []; KQ.vien = [];
    await tua(H(C.den[0], C.den[1]), async () => { const t = await txt(M, '#smhfb .hdg'); if (t && !KQ.hd.includes(t.slice(0, 80))) KQ.hd.push(t.slice(0, 80)); const c = await M.ev(() => document.getElementById('smhfb').className); if (/banviec/.test(c) && !KQ.vien.length) { KQ.vien.push(c); await chup(M, 'vien', 200); } return false; });
  } else if (SCEN === 'baocao6') {
    let daBam = false;
    await tua(H(C.den[0], C.den[1]), async (now) => { if (!daBam && now > H(7, 52)) { daBam = true; await moRong(cao, 'homnay'); KQ.nutCao = await txt(cao, '#smhfb [data-a="baoclaude"]'); KQ.nutGiao = await txt(giao, '#smhfb [data-a="baoclaude"]'); await bam(cao, '#smhfb [data-a="baoclaude"]'); KQ.nhoCao = await txt(cao, '#smhfb-nho'); } return false; });
    const z = (o) => { const v = (TAB.apU3Ne[o[1] - 1] || [])[25]; return v ? String(v) : ''; };
    KQ.Z5 = z('Z5').slice(0, 300); KQ.Z5dai = z('Z5').length; KQ.Z6 = z('Z6').slice(0, 300); KQ.Z6dai = z('Z6').length;
    try { const j = JSON.parse(z('Z6').slice(4)); KQ.uuTien = j.uuTien.length; KQ.uuTienNk = (j.uuTien[0] || {}).nk ? j.uuTien[0].nk.length : 0; } catch (e) { KQ.loiZ6 = e.message; }
    try { const j = JSON.parse(z('Z5').slice(4)); KQ.loiGiao = Object.values(Object.values(j.d)[0].loi).map((x) => x.n + 'x ' + x.vd.slice(0, 80)).slice(0, 8); KQ.tk = Object.values(j.tk)[0]; } catch (e) { KQ.loiZ5 = e.message; }
    KQ.ghiZ = db.writes.filter((w) => /Z[567]/.test(w.range)).map((w) => w.range + '@' + (w.val || '').length);
    await giao.ev(() => window.postMessage({ smhLayBaoCao: 1 }, location.origin)); await tua((await giao.bay()) + 4000); KQ.layBC = await giao.ev(() => { const e = document.getElementById('smhfb-bc'); if (!e) return 'KHONG CO'; const j = JSON.parse(e.value); return { ok: j.ok, giao: j.giao.length, cao: j.cao.length, duyet: j.duyet, loi: j.loi }; });
  } else if (SCEN === 'duyet') {
    await tua((await M.bay()) + 20000); KQ.git = db.git; KQ.bar = await txt(M, '#smhfb .bar'); await chup(M, 'chip', 120);
    await bam(M, '#smhfb [data-a="moduyet"]'); await M.page.waitForTimeout(400); KQ.khung = (await txt(M, '#smhfb .nd')).slice(-600); await chup(M, 'hethong', 900);
    M.traLoi = ''; await bam(M, '#smhfb [data-a="duyetban"]'); await tua((await M.bay()) + 6000);
    KQ.hoi = M.hoi; KQ.Z7 = db.writes.filter((w) => /Z7/.test(w.range)); KQ.barSau = await txt(M, '#smhfb .bar'); KQ.khungSau = (await txt(M, '#smhfb .nd')).slice(-300);
  } else if (SCEN === 'nhay') {
    KQ.lop = []; KQ.dem = [];
    await tua(H(C.den[0], C.den[1]), async () => { const c = await M.ev(() => document.getElementById('smhfb').className.split(' ').filter((x) => x === 'sap' || x === 'dang').join(',')); const d = await txt(M, '#smhfb .hdg'); if (c && KQ.lop[KQ.lop.length - 1] !== c) KQ.lop.push(c); if (d && /Sắp/.test(d) && KQ.dem.length < 2) { KQ.dem.push(d.slice(0, 200)); await chup(M, 'dem', 200); } return false; });
  } else if (SCEN === 'bimat') {
    await tua(H(6, 24)); KQ.truocNap = { saiMa: db.larkSaiMa || 0, hethong: '' }; await moRong(M, 'hethong'); KQ.truocNap.hethong = (await txt(M, '#smhfb .nd')).match(/Mã bí mật[^·]{0,80}/)?.[0];
    await M.ev((b) => window.postMessage({ smhBiMat: b }, location.origin), BIMAT); await M.page.waitForTimeout(500);
    await tua(H(C.den[0], C.den[1])); KQ.daCo = !!(await M.lay('bimat6')); KQ.sauNap = db.larkSaiMa || 0;
    await M.ev((b) => window.postMessage({ smhBiMat: Object.assign({}, b, { appId: 'cli_GIAMAO' }) }, location.origin), BIMAT); await M.page.waitForTimeout(500); KQ.khongThay = ((await M.lay('bimat6')) || {}).appId;
  } else if (SCEN === 'suckhoe') {
    await tua(H(C.den[0], C.den[1])); KQ.sk6 = await M.lay('sk6'); await moRong(M, 'homnay'); KQ.banner = (await txt(M, '#smhfb .ghichu')).slice(0, 300); await chup(M, 'banner', 500);
    KQ.notif = await M.ev(() => localStorage.getItem('__notif'));
  } else if (SCEN === 'thetab') {
    await moRong(M, 'comment'); KQ.tenTab = await txt(M, '#smhfb [data-tab="comment"]');
    await M.page.fill('#smhfb textarea[data-o="the_manifest"]', 'The moi mot\nThe moi hai\nThe moi ba');
    await bam(M, '#smhfb [data-a="xemthe"]'); await M.page.waitForTimeout(300); KQ.xem = (await txt(M, '#smhfb .cmtxem')).slice(0, 400); await chup(M, 'xem', 900);
    await bam(M, '#smhfb [data-a="luuthe"]'); await tua((await M.bay()) + 4000);
    KQ.luu = await M.lay('the6'); KQ.z4 = db.writes.filter((w) => /Z4/.test(w.range)).length; KQ.nho = await txt(M, '#smhfb-nho');
  } else if (SCEN === 'cmtcta') {
    await moRong(M, 'comment'); await chup(M, 'tab', 900);
    KQ.tab = (await txt(M, '#smhfb .nd')).slice(0, 300);
    await M.page.fill('#smhfb textarea[data-o="cmt_cta"]', 'Câu thử một vào nhóm Zalo\nCâu thử hai vào nhóm Zalo\nCâu thử ba vào nhóm Zalo');
    await M.page.fill('#smhfb input[data-o="cmt_link"]', 'https://zalo.me/g/thunghiem');
    await M.page.click('#smhfb .cmtck input[data-k="b2"]'); await M.page.waitForTimeout(300);
    KQ.coThayDoi = await txt(M, '#smhfb .cmtluu');
    await bam(M, '#smhfb [data-a="xemcmt"]'); await M.page.waitForTimeout(300); KQ.xemThu = (await txt(M, '#smhfb .cmtxem')).slice(0, 500); await chup(M, 'xemthu', 900);
    await bam(M, '#smhfb [data-a="luucmt"]'); await tua((await M.bay()) + 5000);
    KQ.sauLuu = await M.lay('cmt6'); KQ.ghiZ3 = db.writes.filter((w) => /Z3/.test(w.range)).map((w) => w.val.slice(0, 80)); KQ.nho = await txt(M, '#smhfb-nho');
    await tua(H(C.den[0], C.den[1]));
  } else if (SCEN === 'phanhoi') {
    await moRong(M, 'saptoi'); await bam(M, '#smhfb [data-a="docsheet"]');
    await M.page.clock.runFor(1500); await M.page.waitForTimeout(300);
    KQ.nho = await txt(M, '#smhfb-nho'); KQ.nhoHien = await M.ev(() => document.querySelector('#smhfb-nho').className);
    KQ.hdg = await txt(M, '#smhfb .hdg'); KQ.den = await M.ev(() => document.querySelector('#smhfb .bar .den').className);
    await M.page.screenshot({ path: `${OUT}/phanhoi_dangdoc.png`, clip: { x: 0, y: 0, width: 1500, height: 400 } });
    await tua((await M.bay()) + 25000); await moRong(M, 'saptoi'); KQ.sauXong = await txt(M, '#smhfb .tb-quet'); KQ.hoc = await M.lay('tg_hoc6');
    await bam(M, '#smhfb [data-a="chuto"]'); await M.page.waitForTimeout(200); KQ.nho2 = await txt(M, '#smhfb-nho');
    KQ.nhoSauNhip = []; for (let i = 0; i < 20; i++) { await M.page.clock.runFor(1000); await M.page.waitForTimeout(50); const t = await txt(M, '#smhfb-nho'); if (t && !KQ.nhoSauNhip.includes(t)) KQ.nhoSauNhip.push(t); }
    await M.page.screenshot({ path: `${OUT}/phanhoi_xong.png`, clip: { x: 0, y: 0, width: 1500, height: 400 } });
    await M.page.clock.runFor(6000); await M.page.waitForTimeout(300); KQ.nhoTat = await M.ev(() => document.querySelector('#smhfb-nho').className);
    KQ.canhXa = (await txt(M, '#smhfb .viec')).includes('cột H (Ngày đăng) còn trống'); KQ.chuaNgayB = (await M.lay('du_lieu6') || {}).chuaNgayB;
    await moRong(M, 'homnay'); await bam(M, '#smhfb .it[data-k="b3"]'); await bam(M, '#smhfb .bai [data-a="boqua"][data-k="b3"]'); await M.page.waitForTimeout(200); KQ.nho3 = await txt(M, '#smhfb-nho');
    await bam(M, '#smhfb .bai [data-a="khoiphuc"][data-k="b3"]'); await M.page.waitForTimeout(200); KQ.nho4 = await txt(M, '#smhfb-nho');
  } else if (SCEN === 'chuangay') {
    await moRong(M, 'saptoi'); await bam(M, '#smhfb [data-a="docsheet"]'); await tua((await M.bay()) + 20000);
    await moRong(M, 'saptoi'); KQ.sapToi = (await txt(M, '#smhfb .nd')).slice(0, 900); await chup(M, 'saptoi', 800);
    await bam(M, '#smhfb [data-a="moviec"]'); await M.page.waitForTimeout(300); KQ.viec = (await txt(M, '#smhfb .viec')).slice(0, 700); await chup(M, 'viec', 800);
    KQ.homNayTT = Object.values(((await M.lay('ngay6_' + today)) || { s: {} }).s).map((x) => x.tt).join(',');
  } else if (SCEN === 'font') {
    const b64 = SCRIPT.match(/'UTM Aptima': '([^']+)'/)[1]; const TTF = Buffer.from(b64, 'base64');
    await moRong(M, 'manifest'); await M.page.waitForTimeout(600); await chup(M, 'tab0', 760);
    KQ.chon0 = await M.ev(() => Array.from(document.querySelectorAll('#smhfb select[data-o^="font_"]')).map((x) => x.getAttribute('data-o') + '=' + x.value + ' [' + Array.from(x.options).map((o) => o.value).join('|') + ']'));
    await (await M.page.$('#smhfb input[data-a="themfont"]')).setInputFiles({ name: 'ghichu.txt', mimeType: 'text/plain', buffer: Buffer.from('abc') }); await M.page.waitForTimeout(500); KQ.hoiSai = M.hoi; M.hoi = [];
    await (await M.page.$('#smhfb input[data-a="themfont"]')).setInputFiles({ name: 'hong.ttf', mimeType: 'font/ttf', buffer: Buffer.from('khong phai font') }); await M.page.waitForTimeout(500); KQ.hoiHong = M.hoi; M.hoi = [];
    await (await M.page.$('#smhfb input[data-a="themfont"]')).setInputFiles({ name: 'Font Thu Nghiem.ttf', mimeType: 'font/ttf', buffer: TTF }); await M.page.waitForTimeout(800); KQ.hoiTot = M.hoi;
    KQ.fontLuu = Object.keys((await M.lay('mf_fonts6')) || {}); KQ.toastFont = await txt(M, '#smhfb .hdg');
    await M.page.selectOption('#smhfb select[data-o="font_td"]', 'Font Thu Nghiem'); await M.page.waitForTimeout(400);
    KQ.fontChon = await M.lay('mf_font6'); KQ.mau = await M.ev(() => document.querySelector('#smhfb .mffont div').getAttribute('style'));
    KQ.fontDaNapTrinhDuyet = await M.ev(() => document.fonts.check('20px "Font Thu Nghiem"'));
    await chup(M, 'dachon', 760);
    await (await M.page.$('#smhfb input[data-a="chonnen"]')).setInputFiles([{ name: 'nen1.jpg', mimeType: 'image/jpeg', buffer: NEN }]); await M.page.waitForTimeout(400);
    await M.page.fill('#smhfb input[data-o="vung"]', 'G220:G221'); await M.page.waitForTimeout(200);
    await M.page.click('#smhfb [data-a="taoanh"]');
    for (let i = 0; i < 200; i++) { await M.page.clock.runFor(500); await M.page.waitForTimeout(80); if ((await M.ev(() => document.querySelectorAll('#smhfb .mfo img').length)) >= 2 && /Đã tạo/.test(await txt(M, '#smhfb .nd'))) break; }
    const kichThuoc = () => M.ev(async () => Promise.all(Array.from(document.querySelectorAll('#smhfb .mfo img')).map(async (im) => (await (await fetch(im.src)).blob()).size)));
    KQ.anh1 = await kichThuoc(); await chup(M, 'luoi1', 900);
    await M.page.selectOption('#smhfb select[data-o="font_than"]', 'UTM Aptima'); await M.page.waitForTimeout(300);
    KQ.coNutVeLai = await txt(M, '#smhfb [data-a="velaifont"]');
    await bam(M, '#smhfb [data-a="velaifont"]');
    for (let i = 0; i < 100; i++) { await M.page.clock.runFor(500); await M.page.waitForTimeout(80); if (/Đã vẽ lại/.test(await txt(M, '#smhfb .nd'))) break; }
    KQ.anh2 = await kichThuoc(); KQ.sauVeLai = await txt(M, '#smhfb .mfp + .thanh + .mo, #smhfb .mfp ~ .mo'); await chup(M, 'luoi2', 900);
    await bam(M, '#smhfb .mfo img[data-i="0"]'); await M.page.waitForTimeout(300); await M.page.screenshot({ path: `${OUT}/font_xem.png` }); await bam(M, '#smhfb .mfxd [data-a="dongxem"]');
    M.hoi = []; await bam(M, '#smhfb [data-a="xoafont"]'); await M.page.waitForTimeout(400); KQ.hoiXoa = M.hoi;
    KQ.sauXoa = { fonts: Object.keys((await M.lay('mf_fonts6')) || {}), chon: await M.lay('mf_font6'), td: await M.ev(() => document.querySelector('#smhfb select[data-o="font_td"]').value) };
  } else if (SCEN === 'nhac') {
    await moRong(M, 'manifest');
    const inp = await M.page.$('#smhfb input[data-a="chonnhac"]');
    await inp.setInputFiles({ name: 'nhac-moi.wav', mimeType: 'audio/wav', buffer: WAV }); await M.page.waitForTimeout(1500);
    KQ.info1 = JSON.stringify(await M.lay('nhac6_info')); KQ.hoi = M.hoi;
    await M.page.fill('#smhfb input[data-o="onhac"]', 'G217'); await bam(M, '#smhfb [data-a="laynhac"]');
    await tua((await M.bay()) + 20000); for (let i = 0; i < 20; i++) { await M.page.waitForTimeout(150); }
    KQ.info2 = JSON.stringify(await M.lay('nhac6_info')); KQ.hoi2 = M.hoi; await bam(M, '#smhfb [data-a="nghenhac"]');
    await chup(M, 'tab', 700);
  } else if (SCEN === 'gantay') {
    await tua((await M.bay()) + 8000);
    await M.ev(() => { const b = Array.from(document.querySelectorAll('[role=button]')).find((x) => x.innerText === 'Bạn đang nghĩ gì?'); b.click(); });
    await M.page.waitForTimeout(300);
    await M.page.setInputFiles('#cmp input[type=file]', { name: 'tay.mp4', mimeType: 'video/mp4', buffer: Buffer.alloc(200000, 1) });
    await tua((await M.bay()) + 3000);
    KQ.widget0 = await txt(M, '#smhfb-gan-w');
    await bam(M, '#smhfb-gan');
    for (let i = 0; i < 120; i++) { await M.page.clock.runFor(1000); await M.page.waitForTimeout(50); const w = await txt(M, '#smhfb-gan'); if (/^✅|Xong:|Lỗi/.test(w) || /Xong:|Lỗi khi/.test(w)) break; }
    KQ.widget1 = await txt(M, '#smhfb-gan'); KQ.draft = db.drafts.length; await chup(M, 'xong', 1000);
    KQ.thumbDong = await M.ev(() => !document.getElementById('rthumb')); KQ.nutDang = await M.ev(() => !!document.querySelector('#rset .post'));
  } else if (SCEN === 'soan') {
    await tua((await M.bay()) + 20000); await moRong(M, 'homnay'); await chup(M, 'truoc', 760);
    M.traLoi = ''; const ok = await bam(M, '#smhfb .it[data-k="v1"] [data-a="soan"]'); KQ.bamSoan = ok; KQ.sauBam = await txt(M, '#smhfb .it[data-k="v1"]');
    await tua(H(7, 30), async () => !!(await M.lay('cho_tay6')));
    KQ.choTay = JSON.stringify(await M.lay('cho_tay6')).slice(0, 80); await chup(M, 'dasoan', 760);
    await M.ev(() => { const b = Array.from(document.querySelectorAll('[aria-label="Đăng"]')).find((x) => x.offsetParent); b && b.click(); });
    await tua(H(C.den[0], C.den[1]));
  } else if (SCEN === 'tay') {
    await tua(H(C.den[0], C.den[1]));
    await moRong(M, 'homnay'); await chup(M, 'homnay', 900);
  } else if (SCEN === 'khongnhac') {
    await tua((await M.bay()) + 20000); KQ.bar = await txt(M, '#smhfb .bar'); KQ.lop = await M.ev(() => document.getElementById('smhfb').className); await chup(M, 'thugon', 90); await moRong(M, 'manifest'); await chup(M, 'manifest', 700);
  } else if (SCEN === 'ghide') { // (6.26.4) Máy Giao giữ chỗ Video 1 → Máy Cao bấm Đăng ngay, xác nhận → vẫn đăng
    await tua((await M.bay()) + 30000);
    await M.ev(() => { window.confirm = (m) => { (window.__ev = window.__ev || []).push('CONFIRM ' + m.slice(0, 90)); return true; }; });
    await moRong(M, 'homnay'); await bam(M, '#smhfb .it[data-k="v1"]'); await M.page.waitForTimeout(500);
    KQ.ghichu = (await txt(M, '#smhfb .nd')).match(/🔒[^\n]*/) ? 'co' : 'khong';
    await bam(M, '#smhfb [data-a="dangngay"][data-k="v1"]'); await M.page.waitForTimeout(2000);
    await tua(H(C.den[0], C.den[1]));
    KQ.conf = await M.ev(() => (window.__ev || []).filter((x) => /CONFIRM/.test(x)));
  } else if (SCEN === 'danhdau') { // (6.26.3) bấm Đã đăng tay cho bài chưa lên: Facebook chưa thấy → hỏi lại (giả lập bấm Huỷ)
    await tua((await M.bay()) + 30000);
    await M.ev(() => { window.confirm = (m) => { (window.__ev = window.__ev || []).push('CONFIRM ' + m.slice(0, 60)); return false; }; });
    await moRong(M, 'homnay'); await bam(M, '#smhfb .it[data-k="v1"]'); await M.page.waitForTimeout(500);
    await bam(M, '#smhfb [data-a="danhdau"][data-k="v1"]'); await M.page.waitForTimeout(3000);
    KQ.conf = await M.ev(() => (window.__ev || []).filter((x) => /CONFIRM/.test(x)));
    KQ.v1 = JSON.stringify((((await M.lay('ngay6_' + today)) || { s: {} }).s.v1) || {}).slice(0, 150);
  } else if (SCEN === 'bangthieu') { // (6.26) bảng thiếu nội dung 2 ngày tới + tab Comment & Thẻ có kênh Hà Xá
    await tua((await M.bay()) + 60000);
    await moRong(M, 'homnay'); await M.page.waitForTimeout(500);
    try { const el = await M.page.$('#smhfb .viec'); if (el) await el.screenshot({ path: __dirname + '/kq/bangthieu_viec.png' }); } catch (e) { KQ.loiChup = e.message; }
    KQ.viec = (await txt(M, '#smhfb .viec')).slice(0, 900);
    await bam(M, '#smhfb [data-tab="comment"]'); await M.page.waitForTimeout(500);
    KQ.cmtHx = await M.ev(() => { const t = document.querySelector('#smhfb [data-o="cmt_gochx"]'); return t ? t.value : 'KHONG'; });
    KQ.nutThe = await M.ev(() => Array.from(document.querySelectorAll('#smhfb [data-a="chonkenhthe"]')).map((x) => x.innerText.replace(/\s+/g, ' ')).join(' / '));
  } else if (SCEN === 'kenhui') {
    await tua((await M.bay()) + 60000);
    await moRong(M, 'homnay'); await bam(M, '#smhfb .it[data-k="k2a"]'); KQ.k2a = (await txt(M, '#smhfb .nd')).slice(0, 900);
    for (const tab of ['ngaymai', 'saptoi', 'comment', 'hethong', 'homqua', 'lichsu']) { await bam(M, `#smhfb [data-tab="${tab}"]`); await M.page.waitForTimeout(400); KQ['tab_' + tab] = (await txt(M, '#smhfb .nd')).slice(0, 700); }
    await bam(M, '#smhfb [data-tab="comment"]'); KQ.tickK = await M.ev(() => Array.from(document.querySelectorAll('#smhfb [data-o="cmt_kenh"]')).map((x) => x.getAttribute('data-k') + ':' + x.checked).join(','));
    // (6.19.3) kho thẻ video theo kênh
    const theTa = async () => M.ev(() => { const t = document.querySelector('#smhfb [data-o="the_video"]'); return t ? t.value.split('\n')[0] + ' | ' + t.value.split('\n').length : 'KHONG'; });
    KQ.the1 = await theTa(); await bam(M, '#smhfb [data-a="chonkenhthe"][data-k="3"]'); await M.page.waitForTimeout(300); KQ.the3 = await theTa();
    await bam(M, '#smhfb [data-a="chonkenhthe"][data-k="2"]'); await M.page.waitForTimeout(300); KQ.the2 = await theTa();
    KQ.nutThe = await M.ev(() => Array.from(document.querySelectorAll('#smhfb [data-a="chonkenhthe"]')).map((x) => x.innerText.replace(/\s+/g, ' ')).join(' / '));
    await M.ev(() => { const t = document.querySelector('#smhfb [data-a="chonkenhthe"]'); t && t.scrollIntoView({ block: 'start' }); }); await M.page.waitForTimeout(300); await chup(M, 'theK', 1000); await bam(M, '#smhfb [data-a="xemthe"]'); await M.page.waitForTimeout(300); KQ.xemThe = (await txt(M, '#smhfb .cmtxem')).replace(/\s+/g, ' ').slice(0, 700); await chup(M, 'the', 1000);
    } else if (SCEN === 'ui' || SCEN === 'chonmay') {
    await tua((await M.bay()) + 20000);
    KQ.thuGon = await txt(M, '#smhfb .bar'); await chup(M, 'thugon', 90);
    if (SCEN === 'chonmay') { await bam(M, '#smhfb [data-a="chonmay"][data-may="GIAO"]'); await M.page.waitForTimeout(2500); KQ.sauChon = await M.lay('may6'); KQ.bar2 = await txt(M, '#smhfb .bar'); }
    else {
      await moRong(M, 'homnay'); await chup(M, 'homnay', 760);
      KQ.nutTren = await M.ev(() => Array.from(document.querySelectorAll('#smhfb .acts button')).map((b) => b.innerText.replace(/\s+/g, ' ') + '@' + Math.round(b.getBoundingClientRect().top)));
      for (const tab of ['saptoi', 'manifest', 'nhatky', 'hethong']) { await bam(M, `#smhfb [data-tab="${tab}"]`); await M.page.waitForTimeout(400); await chup(M, tab, 760); KQ['tab_' + tab] = (await txt(M, '#smhfb .nd')).slice(0, 300); }
      // bấm hết các nút (trừ chọn máy / dùng tab)
      const nut = ['docsheet', 'kiem1', 'kiem3', 'kiem24', 'lammoi', 'tinthu', 'taisan', 'chuto', 'chunho', 'tudong', 'tudong', 'chaythu', 'chaythu', 'kiemma', 'tamdung', 'tamdung'];
      KQ.bam = [];
      for (const a of nut) { await bam(M, `#smhfb [data-tab="${['tinthu', 'taisan', 'chaythu', 'kiemma'].includes(a) ? 'hethong' : 'homnay'}"]`); const ok = await bam(M, `#smhfb [data-a="${a}"]`); await tua((await M.bay()) + 16000); KQ.bam.push(a + ':' + (ok ? 'ok' : 'KHÔNG THẤY')); }
      await bam(M, '#smhfb [data-tab="nhatky"]'); for (const v of ['loi', 'tatca', 'quan']) await bam(M, `#smhfb [data-a="locnk"][data-k="${v}"]`);
      await bam(M, '#smhfb [data-tab="homnay"]');
      M.traLoi = ''; await moRong(M, 'homnay'); await bam(M, '#smhfb .it[data-k="m3"]'); await bam(M, '#smhfb .bai [data-a="dangngay"][data-k="m3"]'); await tua((await M.bay()) + 6 * 60000); KQ.epM3 = (((await M.lay('ngay6_' + today)) || { s: {} }).s.m3 || {}).tt;
      KQ.canhXa = (await txt(M, '#smhfb .viec')).includes('cột H (Ngày đăng) còn trống'); KQ.chuaNgayB = (await M.lay('du_lieu6') || {}).chuaNgayB;
    await moRong(M, 'homnay'); await bam(M, '#smhfb .it[data-k="b3"]'); await bam(M, '#smhfb .bai [data-a="boqua"][data-k="b3"]'); KQ.boB3 = (((await M.lay('ngay6_' + today)) || { s: {} }).s.b3 || {}).tt;
      await bam(M, '#smhfb .bai [data-a="khoiphuc"][data-k="b3"]'); KQ.khoiPhucB3 = (((await M.lay('ngay6_' + today)) || { s: {} }).s.b3 || {}).tt;
      await moRong(M, 'homnay'); await chup(M, 'homnay2', 760); try { const el6 = await M.page.$('#smhfb .tlay'); if (el6) await el6.screenshot({ path: __dirname + '/kq/' + SCEN + '_lich.png' }); } catch (e) { KQ.loiLich = e.message; }
      await bam(M, '#smhfb [data-a="morong"]'); KQ.caoDangThu = await M.ev(() => document.getElementById('smhfb').className + ' h=' + document.getElementById('smhfb').style.height); await M.page.waitForTimeout(700); KQ.thuGon2 = !(await M.ev(() => !!document.querySelector('#smhfb .tabs')));
    }
  }

  // ---------------- tổng kết ----------------
  for (const m of MAYS.filter((x) => x.song)) { m.gmLuu = await m.gm(); }
  const ttNgay = (m) => ((m.gmLuu || {})['that_ngay6_' + today] || {}).s || {};
  KQ.gio = fmt(db.now || T0);
  const moi = db.posts.filter((p) => p.id !== 'old1' && !p.id.startsWith('d_'));
  if (SCEN === 'thunap' || SCEN === 'thunapcsp') { KQ.thunapCao = (cao.gmLuu || {}).that_thunap6b; KQ.thunapGiao = (giao.gmLuu || {}).that_thunap6b || null; KQ.Z20_29 = [19,20,21,22,23,24,25,26,27,28].map((r) => String((TAB.apU3Ne[r] || [])[25] || '').slice(0, 12)); KQ.tepTen = db.tepTen; await moRong(cao, 'hethong'); KQ.khung = ((await txt(cao, '#smhfb .nd')).match(/🧪.*?(Thử lại|Thử ngay)/) || [''])[0]; }
  if (['nhacsheet', 'chuanbi', 'hb21', 'capnhat'].includes(SCEN)) { const z = (r) => String((TAB.apU3Ne[r - 1] || [])[25] || ''); KQ.Z5 = z(5).slice(0, 400); KQ.Z6 = z(6).slice(0, 200); KQ.bar = await txt(M, '#smhfb .bar'); if (cao) KQ.barCao = await txt(cao, '#smhfb .bar'); await moRong(M, 'hethong'); KQ.tuNang = (await txt(M, '#smhfb .nd')).split('TỰ NÂNG CẤP')[1] || ''; KQ.tuNang = KQ.tuNang.slice(0, 500); KQ.drive = db.drive || 0; }
  if (SCEN === 'tv24') { KQ.v24 = JSON.stringify((M.gmLuu || {}).that_v24_6 || null).slice(0, 600); KQ.tv24 = JSON.stringify((M.gmLuu || {}).that_tv24_6 || null).slice(0, 400); KQ.demTV = (db.dem.tv || 0) + '/' + (db.dem.ttct || 0); KQ.urlCuoi = await M.ev(() => location.pathname); KQ.nk = (await M.nk()).filter((x) => /24h|Thư viện/.test(x)).slice(-12); }
  if (/^chiso/.test(SCEN)) { KQ.cs6 = JSON.stringify((M.gmLuu || {}).that_cs6 || null).slice(0, 900); KQ.trangCS = { v: db.dem.cs_views || 0, m: db.dem.cs_messaging || 0, a: db.dem.cs_audience || 0, tv: db.dem.tv || 0, ttct: db.dem.ttct || 0 }; KQ.tinCS = KQ.tinCS || db.sent.filter((x) => /CS/.test(x.nhom)).map((x) => x.nhom + ': ' + x.text.slice(0, 1800)); KQ.urlCuoi = KQ.urlCuoi || await M.ev(() => location.pathname); }
  KQ.ev = (await M.ev(() => window.__ev.filter((x) => /BOQUA|SOAN_HONG|ANHVIDEO|VIDEO_DUNG|HOPLA|DANG_BI_CHAN|DANGREEL/.test(x)))) || [];
  if (C.kenh) {
    KQ.kenhTab = { K2: TAB.em39qJ.slice(1).map((r) => [r[6], String(r[9] || '').slice(0, 50)]), K3: TAB['4OtbFA'].slice(1).map((r) => [r[6], String(r[9] || '').slice(0, 50)]), HX: TAB.ZSDDld.slice(1).map((r) => [r[7], String(r[10] || '').slice(0, 50)]) };
    KQ.chuyen = db.chuyen || []; KQ.cmtApi = db.dem.cmtApi || 0; KQ.apiK = { k2: db.dem.api_2002002002 || 0, k3: db.dem.api_3003003003 || 0 };
    const gm = (M.gmLuu || {}); KQ.maKenh = { ids: gm.that_kenh_id6, n: Object.keys(gm.that_fb_tok_trang6 || {}).length, kenhMa: gm.that_kenh_ma6 };
    const st = (gm['that_ngay6_' + today] || {}); KQ.gioK = Object.fromEntries(Object.entries(st.gio || {}).filter(([k]) => /^k|^b/.test(k)).map(([k, v]) => [k, p2(Math.floor(v / 60)) + ':' + p2(v % 60)]));
    KQ.ttK = Object.fromEntries(Object.entries(st.s || {}).filter(([k]) => /^k/.test(k)).map(([k, v]) => [k, [v.tt, v.may, v.cmtOk, v.suaXong ? 'sua' : '', v.suaLoi || '', v.loi || ''].join('|')]));
    KQ.viec = (await txt(M, '#smhfb')).slice(0, 600);
  }
  console.log('KQ:', JSON.stringify(KQ, null, 0));
  console.log('SỬA REEL:', JSON.stringify(db.edits.filter((e) => 'tag' in e)));
  console.log('CẢM XÚC:', JSON.stringify(db.likes.filter((x) => x.kind === 'post')));
  console.log('CMT ĐỦ:'); for (const p of db.posts.filter((x) => x.id !== 'old1' && !x.id.startsWith('d_'))) for (const c of (p.comments || [])) if (c.message) console.log('  ' + p.id + ' » ' + c.message.replace(/\n/g, ' ⏎ ').slice(0, 300));
  console.log('POSTS:'); for (const p of db.posts.filter((x) => x.id !== 'old1').sort((a, b) => a.luc - b.luc)) console.log(`  ${fmt(p.luc)} ${p.id} [${p.may || 'có sẵn'}] {${p.trang || '-'} / ${p.tacGia || '-'}} ${p.reel ? 'REEL' : 'BÀI'} "${p.message.replace(/\n/g, ' / ').slice(0, 40)}" nhom=${p.nhom} loc=${p.loc} the=${p.tags} thumb=${p.thumb} anh=${p.nImg} red=${!!p.red} | cmt: ${p.comments.map((c) => (c.anh ? 'ẢNH' : c.message === CMT3 ? 'CMT3' : 'T:' + c.message.slice(0, 14)) + (c.tacGia && c.tacGia !== TRANG[p.trang || 'vongtramhuongsonmochuong'].ten ? '(SAI TÊN:' + c.tacGia + ')' : '')).join(', ')} | sua: ${JSON.stringify(p.edit || {})}`);
  if (process.env.DBG) for (const p of db.posts.filter((x) => /#manifest/i.test(x.message || ''))) console.log('MSG:', JSON.stringify(p.message), 'SHEET:', JSON.stringify(T.m[0]));
  console.log('SỐ BÀI MỚI:', moi.length, ' TRÙNG:', moi.length - new Set(moi.map((p) => p.message)).size, ' NHÁP:', db.drafts.length);
  console.log('GHI SHEET:', JSON.stringify(db.writes));
  console.log('LARK GỌI:', db.larkGoi, ' TẢI FILE:', JSON.stringify(db.dl), ' WEB:', db.webDl || 0, ' QUOTA:', db.quota || 0);
  for (const m of MAYS.filter((x) => x.song)) { const st = ((m.gmLuu || {})['that_ngay6_' + today] || {}); console.log('GIỜ ' + m.may + ':', JSON.stringify(Object.fromEntries(Object.entries(st.gio || {}).map(([k, v]) => [k, p2(Math.floor(v / 60)) + ':' + p2(v % 60)])))); }
  console.log('ĐỌC SHEET THEO MÁY:', JSON.stringify(Object.fromEntries(Object.entries(db.dem).filter(([k]) => /^doc_/.test(k)))), ' BATCH:', db.batch || 0);
  for (const x of db.sent.filter((y) => y.nhom === 'CSKQ' || y.nhom === 'CSLOI')) console.log('THẺ ĐẦY ĐỦ [' + x.nhom + ']:\n' + x.text.replace(/ ⏎ /g, '\n'));
  console.log('TIN LARK:'); for (const x of db.sent) console.log(`  [${x.nhom}][${x.may}] ${x.luc} ${x.text.replace(/\n/g, ' ⏎ ').slice(0, 400)}`);
  for (const m of MAYS) {
    const s = ttNgay(m);
    console.log(`=== ${m.may || 'chưa chọn'}: trạng thái ===`); for (const k of Object.keys(s)) console.log(`  ${k}: ${s[k].tt} ${s[k].luc ? fmt(s[k].luc) : ''} may=${s[k].may || ''} kiem=${(s[k].kiem || []).length} cmtOk=${s[k].cmtOk} guiBu=${s[k].guiBu || 0} ${s[k].lyDo || s[k].loi || ''}`);
    console.log('  dang_do:', JSON.stringify((m.gmLuu || {}).that_dang_do || null).slice(0, 600), ' hoat_dong:', JSON.stringify((m.gmLuu || {}).that_hoat_dong || null).slice(0, 300), ' cho_nguoi:', JSON.stringify((m.gmLuu || {}).that_cho_nguoi || null));
    console.log('  baoCao:', ((m.gmLuu || {})['that_ngay6_' + today] || {}).baoCao ? 'đã gửi' : 'chưa', ' lark_dem:', JSON.stringify((m.gmLuu || {}).that_lark_dem));
    const nk = Object.keys(m.gmLuu || {}).filter((k) => k.startsWith('that_nk6_')).map((k) => m.gmLuu[k]).flat().sort((a, b) => a.luc - b.luc).map((x) => fmt(x.luc) + ' ' + x.msg.replace(/\s*\[tab [^\]]+\]$/, '') + (x.so > 1 ? ` [x${x.so}]` : ''));
    console.log(`=== ${m.may} NHẬT KÝ (${nk.length} dòng) ===\n` + nk.slice(-(+process.env.NK || 60)).join('\n'));
    console.log(`=== ${m.may} LỖI TRANG:`, JSON.stringify(m.errors.slice(0, 8)));
  }
  await browser.close();
})().catch((e) => { console.log('SIM LỖI', e); process.exit(2); });
