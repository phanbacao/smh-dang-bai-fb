# (6.32.4) gắn thẻ: kết quả tìm Trang về chậm → lần 1 hay hụt. So khớp không phân biệt hoa thường + gõ lại 1 lần, chờ thêm
_A = """    const hang = await cho(() => Array.from(document.querySelectorAll('li[role="option"]')).find((li) => dangHien(li) && /Trang\\s*·/.test(chuan(li.innerText)) && chuan(li.innerText).startsWith(chuan(CAI_DAT.TAG_TEN))), 9000, 400);
    if (!hang) throw new Error(`không thấy Trang "${CAI_DAT.TAG_TEN}" trong kết quả tìm`);"""
_B = """    const timHang = () => Array.from(document.querySelectorAll('li[role="option"]')).find((li) => dangHien(li) && /Trang\\s*·/.test(chuan(li.innerText)) && thuong(li.innerText).startsWith(thuong(CAI_DAT.TAG_TEN)));
    let hang = await cho(timHang, 9000, 400);
    if (!hang && inp.isConnected) { // (6.32.4) kết quả tìm chưa về → gõ lại tên rồi chờ thêm (không phải mở lại cả bảng)
      ghi(`Gắn thẻ: chưa thấy Trang "${CAI_DAT.TAG_TEN}" trong kết quả tìm → gõ lại tên, chờ thêm`);
      try { const set = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value').set; set.call(inp, ''); inp.dispatchEvent(new Event('input', { bubbles: true })); await sleep(600); inp.focus(); document.execCommand('insertText', false, CAI_DAT.TAG_TEN); if (!inp.value) { set.call(inp, CAI_DAT.TAG_TEN); inp.dispatchEvent(new Event('input', { bubbles: true })); } } catch (e) { /* */ }
      hang = await cho(timHang, 12000, 400);
    }
    if (!hang) throw new Error(`không thấy Trang "${CAI_DAT.TAG_TEN}" trong kết quả tìm`);"""
assert out.count(_A) == 1, 'gan the tim hang'
out = out.replace(_A, _B)
