
  // =====================================================================
  //  Đọc dữ liệu sheet (2 tab) — chỉ đọc 13:30 + 18:30 (và khi bấm nút)
  // =====================================================================
  function chuO(cell) {
    if (cell == null) return '';
    if (typeof cell === 'string') return cell;
    if (typeof cell === 'number') return String(cell);
    if (Array.isArray(cell)) return cell.map((s) => (typeof s === 'string' ? s : (s && !s.fileToken && (s.text != null ? s.text : (s.link || ''))) || '')).join('');
    if (typeof cell === 'object' && cell.text != null && !cell.fileToken) return String(cell.text);
    return '';
  }
  const coTep = (c) => !!c && (Array.isArray(c) ? c.some((x) => x && x.fileToken) : !!c.fileToken);
  function ngayO(cell) {
    if (typeof cell === 'number' && cell > 20000 && cell < 80000) {
      const d = new Date(Date.UTC(1899, 11, 30) + Math.floor(cell + 1e-6) * 86400000);
      return `${pad(d.getUTCDate())}-${pad(d.getUTCMonth() + 1)}-${d.getUTCFullYear()}`;
    }
    const s = chuO(cell);
    const m = s.match(/(\d{1,2})\s*[-\/.]\s*(\d{1,2})\s*[-\/.]\s*(\d{4})/);
    if (!m) { const q = s.match(/(\d{4})\s*[-\/.]\s*(\d{1,2})\s*[-\/.]\s*(\d{1,2})/); if (q) return `${pad(q[3])}-${pad(q[2])}-${q[1]}`; } // (6.19.3) dạng năm-tháng-ngày
    return m ? `${pad(m[1])}-${pad(m[2])}-${m[3]}` : '';
  }
  const COT_BAT_BUOC = [
    { cot: 'A', chiSo: 0, chua: 'từ khóa', ten: 'Từ khóa chính' },
    { cot: 'B', chiSo: 1, chua: 'không có ảnh', ten: 'Bài twist (không có ảnh)' },
    { cot: 'C', chiSo: 2, chua: 'cmt bài 1', ten: 'Cmt bài 1' },
    { cot: 'H', chiSo: 7, chua: 'ngày đăng', ten: 'Ngày đăng' },
  ];
  function kiemTenCot(values) {
    const h = values[0] || [];
    for (const c of COT_BAT_BUOC) {
      if (!thuong(chuO(h[c.chiSo])).includes(c.chua)) return `Tên cột ${c.cot} tab "Bài viết kênh 1" không còn là "${c.ten}" (đang là "${chuan(chuO(h[c.chiSo])) || 'trống'}") — script không đọc để tránh đăng nhầm cột`;
    }
    return null;
  }
  // ô ảnh của Lark: { fileToken, ... } hoặc danh sách → danh sách mã ảnh
  function tokenAnh(c) {
    if (!c) return [];
    if (Array.isArray(c)) return c.reduce((a, x) => a.concat(tokenAnh(x)), []);
    if (typeof c === 'object' && c.fileToken && (c.type === 'embed-image' || /^image\//.test(c.mimeType || '') || /\.(jpe?g|png|webp|heic|gif)$/i.test(c.text || '') || !c.mimeType)) return [String(c.fileToken)];
    return [];
  }
  const anhNhieuO = (r, tu, den) => { let a = []; for (let i = tu; i <= den; i++) a = a.concat(tokenAnh(r[i])); return a; };
  function tepVideo(c) {
    const ds = Array.isArray(c) ? c : (c && c.fileToken ? [c] : []);
    const t = ds.find((x) => x && x.fileToken && (/^video\//.test(x.mimeType || '') || /\.(mp4|mov|m4v|webm)$/i.test(x.text || '')));
    return t ? { fileToken: t.fileToken, size: t.size || 0, ten: t.text || 'video.mp4', mime: t.mimeType || 'video/mp4' } : null;
  }
  function tepNhac(c) {
    const ds = Array.isArray(c) ? c : (c && c.fileToken ? [c] : []);
    const t = ds.find((x) => x && x.fileToken && (/^audio\//.test(x.mimeType || '') || /\.(mp3|m4a|aac|wav|ogg)$/i.test(x.text || '')));
    return t ? { fileToken: t.fileToken, size: t.size || 0, ten: t.text || 'nhac.mp3', mime: t.mimeType || 'audio/mpeg' } : null;
  }
  // (6.20.2) ảnh cố định cho comment (tab Bài viết kênh 1): ô O2 (cả 3 kênh) + 1 ảnh ngẫu nhiên: kênh 1 lấy trong P2:P10, kênh 2 & 3 lấy trong Q2:Q10 (ô trống bỏ qua)
  function anhChung(v) {
    const r2 = v[1] || []; const cot = (c) => { const o = []; for (let i = 1; i <= 9; i++) o.push(...tokenAnh((v[i] || [])[c])); return o; };
    return { co: tokenAnh(r2[14])[0] || '', pool: cot(15), poolK: cot(16) };
  }
  // (6.37.1) ĐĂNG BÙ: hàng "Đã duyệt" của các ngày trong CAI_DAT.BU_K1 (tu..den) — chỉ trong ngày BU_K1.ngay; còn bài nào chưa lên trang thì thêm vào lịch hôm nay
  const soNgayBu = (n) => { const m = String(n || '').match(/^(\d{2})-(\d{2})-(\d{4})$/); return m ? +(m[3] + m[2] + m[1]) : 0; };
  function hangBuTho(values) {
    const B = CAI_DAT.BU_K1; if (!B || !(B.ngay || []).includes(homNay())) return [];
    const tu = soNgayBu(B.tu), den = soNgayBu(B.den), out = [];
    for (let i = 1; i < values.length; i++) { const r = values[i] || []; const ng = ngayO(r[7]); const s = soNgayBu(ng); if (!s || s < tu || s > den) continue;
      for (const x of hangCuaNgay([[], r], ng)) if (x.duyet && !x.daDang) out.push(Object.assign(x, { hang: i + 1, bu: { ngay: ng, can: [1, 2, 3] } })); }
    return out;
  }
  function hangCuaNgay(values, ngay) {
    const out = [];
    for (let i = 1; i < values.length; i++) {
      const r = values[i] || [];
      if (ngayO(r[7]) === ngay) {
        out.push({ hang: i + 1, bai: chuO(r[1]).trim(), cmt: chuO(r[2]).trim(), bai2: chuO(r[3]).trim(), cmt2: chuO(r[4]).trim(), bai3: chuO(r[5]).trim(),
          anh2: anhNhieuO(r, 8, 10), anh3: anhNhieuO(r, 11, 13), anhCmt: anhNhieuO(r, 14, 16), trangThai: chuO(r[6]).trim(), duyet: /đã\s*duyệt/i.test(chuO(r[6])), daDang: /đã\s*đăng/i.test(chuO(r[6])) }); // (6.37.1) cột G: Chờ làm / Đã duyệt / Đã đăng
      }
    }
    return out;
  }
  // tab "Kênh 1 Vòng Trầm Hương SMH": K = ngày đăng, N = file video, E = chữ đăng video, G = chữ manifest, H = ảnh manifest, J = trạng thái, B = link
  function videoCuaNgay(values, ngay) {
    const v = [], m = [];
    for (let i = 1; i < values.length; i++) {
      const r = values[i] || [];
      if (ngayO(r[10]) !== ngay) continue;
      const tep = tepVideo(r[CAI_DAT.COT_VIDEO_K1]); const cap = chuO(r[4]).trim();
      const tt = chuO(r[9]).trim();
      const lk = chuO(r[1]).trim(); const daDang = /đã đăng/i.test(tt);
      if (daDang && !tep && !/facebook\.com|fb\.watch/i.test(lk)) { (m.cu = m.cu || []).push(i + 1); continue; } // (6.32.4) dòng cũ đã đăng từ trước (không file, không link bài) mà Ngày đăng lại ghi ngày này → nhiều khả năng ghi nhầm ngày: không coi là video của ngày
      if (tep || cap) v.push({ hang: i + 1, cap, tep, tt, duyet: /đã duyệt/i.test(tt), daDang, link: lk });
      const chu = coTep(r[6]) ? '' : chuO(r[6]).trim(); const anh = tokenAnh(r[7])[0] || '';
      if (chu && anh) m.push({ hang: i + 1, chu, anh }); // (6.32) manifest: chỉ đăng dòng có đủ chữ + ảnh, không báo thiếu
    }
    return { v, m };
  }
  // hàng mới (nằm dưới hàng cuối cùng có ngày) đã có nội dung nhưng CHƯA ghi ngày đăng → script chưa biết đăng ngày nào
  function hangChuaNgay(values, cotNgay, coNoiDung, cotTT) {
    let cuoi = 0, ngayXa = '';
    const soNgay = (n) => { const m = n.match(/^(\d{2})-(\d{2})-(\d{4})$/); return m ? `${m[3]}${m[2]}${m[1]}` : ''; };
    for (let i = 1; i < values.length; i++) { const n = ngayO((values[i] || [])[cotNgay]); if (n) { cuoi = i; if (soNgay(n) > ngayXa) ngayXa = soNgay(n); } }
    // sheet đã ghi ngày cho hơn 3 ngày tới → chưa cần nhắc (các hàng chưa ghi ngày còn lâu mới tới lượt)
    if (ngayXa && ngayXa > soNgay(ngayStr(congNgay(3)))) return [];
    const out = [];
    for (let i = cuoi + 1; i < values.length; i++) {
      const r = values[i] || [];
      if (ngayO(r[cotNgay]) || /đã đăng/i.test(chuO(r[cotTT]))) continue;
      if (coNoiDung(r)) out.push(i + 1);
    }
    return out;
  }
  function gonHang(ds) { // [220,221,222,223,230] → "220–223, 230"
    const out = []; let a = null, b = null;
    for (const x of ds) { if (b !== null && x === b + 1) { b = x; continue; } if (a !== null) out.push(a === b ? String(a) : `${a}–${b}`); a = b = x; }
    if (a !== null) out.push(a === b ? String(a) : `${a}–${b}`);
    return out.join(', ');
  }

  // dữ liệu đã đọc (lưu trong Tampermonkey) — dùng cho cả ngày, không đọc lại
  const duLieu = () => lay('du_lieu6', null);
  // ---- (6.19) kênh 2, 3: tab riêng — mỗi dòng có Ngày đăng (H) + Trạng thái (G) + video (I) + caption (E/D) ----
  const vungKenh = (c) => 'A1:' + String.fromCharCode(65 + Math.max(19, ...Object.values(CAI_DAT.KENH[c].cot))) + '3000'; // (6.32.3) đọc rộng tới cột T để dò cột theo tiêu đề khi tab chèn thêm cột
  function doCotKenh(h) { // (6.32.3) dò vị trí cột theo chữ tiêu đề hàng 1
    const t = (i) => thuong(chuan(chuO(h[i]))); const tim = (f) => { for (let i = 0; i < h.length; i++) if (f(t(i))) return i; return -1; };
    const ngay = tim((x) => x.includes('ngày đăng')), tt = tim((x) => x.includes('trạng thái')), video = tim((x) => x.includes('video') && !x.includes('link'));
    let cap = tim((x) => x.includes('tiêu đề')); if (cap < 0) cap = tim((x) => x.includes('caption'));
    let link = tim((x) => x.includes('link')); if (link < 0 && video >= 0) link = video + 1;
    if ([ngay, tt, video, cap, link].some((x) => x < 0 || x > 25)) return null;
    return { cap, tt, ngay, video, link };
  }
  function kiemCotKenh(values, c) {
    const h = (values || [])[0] || []; const cfg = CAI_DAT.KENH[c]; const t = (i) => thuong(chuO(h[i]));
    const moi = doCotKenh(h);
    if (moi && ['cap', 'tt', 'ngay', 'video', 'link'].some((k) => moi[k] !== cfg.cot[k])) {
      const L = (i) => String.fromCharCode(65 + i);
      ghi(`Tab "${cfg.tenTab}" đổi vị trí cột → script tự theo: Tiêu đề ${L(moi.cap)}, Trạng thái ${L(moi.tt)}, Ngày đăng ${L(moi.ngay)}, VIDEO ${L(moi.video)}, Link ${L(moi.link)}`);
      cfg.cot = moi; const cl = lay('cot_kenh6', {}) || {}; cl[c] = moi; luu('cot_kenh6', cl);
    }
    const sai = [];
    if (!t(cfg.cot.ngay).includes('ngày đăng')) sai.push(`cột ${String.fromCharCode(65 + cfg.cot.ngay)} không phải "Ngày đăng" (đang là "${chuan(chuO(h[cfg.cot.ngay])) || 'trống'}")`);
    if (!t(cfg.cot.tt).includes('trạng thái')) sai.push(`cột ${String.fromCharCode(65 + cfg.cot.tt)} không phải "Trạng thái"`);
    if (!t(cfg.cot.video).includes('video')) sai.push(`cột ${String.fromCharCode(65 + cfg.cot.video)} không phải "VIDEO"`);
    if (!/tiêu đề|caption|fb/.test(t(cfg.cot.cap))) sai.push(`cột ${String.fromCharCode(65 + cfg.cot.cap)} không phải "Tiêu đề FB/Tiktok"`);
    return sai.length ? `Tab "${cfg.tenTab}": ${sai.join('; ')} — script không đọc ${tenKenh(c)} để tránh đăng nhầm cột` : null;
  }
  function hangKenh(values, c, ngay) { // mọi dòng ghi ngày này (kể cả chưa duyệt — để cảnh báo)
    const cfg = CAI_DAT.KENH[c]; const out = [];
    for (let i = 1; i < (values || []).length; i++) {
      const r = values[i] || []; if (ngayO(r[cfg.cot.ngay]) !== ngay) continue;
      const tt = chuan(chuO(r[cfg.cot.tt]));
      const tep = tepVideo(r[cfg.cot.video]); const daDang = /đã đăng/i.test(tt);
      out.push({ hang: i + 1, cap: chuO(r[cfg.cot.cap]).trim(), tep, tt, duyet: cfg.khongDuyet ? (!!tep && !daDang) : /đã duyệt/i.test(tt), daDang, link: chuO(r[cfg.cot.link]).trim() }); // (6.26) kênh Hà Xá: có video là đăng
    }
    return out;
  }
  function phanTich(vB, vV, loai, vK) {
    vK = vK || {};
    const loiCot = kiemTenCot(vB);
    const out = { luc: Date.now(), loai, ban: 2, loiCot, chung: anhChung(vB), ngay: {}, loiKenh: {},
      chuaNgayV: hangChuaNgay(vV, 10, (r) => !!(tepVideo(r[CAI_DAT.COT_VIDEO_K1]) || tokenAnh(r[7]).length || (!coTep(r[6]) && chuO(r[6]).trim())), 9),
      chuaNgayB: loiCot ? [] : hangChuaNgay(vB, 7, (r) => !!(chuO(r[1]).trim() || chuO(r[3]).trim() || chuO(r[5]).trim()), 6) };
    for (let i = 0; i <= 3; i++) {
      const ngay = ngayStr(congNgay(i));
      const hs = loiCot ? [] : hangCuaNgay(vB, ngay);
      const vm = videoCuaNgay(vV, ngay);
      out.ngay[ngay] = { bai: hs[0] || null, bais: hs, soHangBai: hs.length, v: vm.v, m: vm.m, cuNham: vm.m.cu || [] };
    }
    try { out.buTho = loiCot ? [] : hangBuTho(vB); } catch (e) { out.buTho = []; } // (6.37.1)
    for (const c of KENH_PHU) {
      const x = vK[c]; if (!x) continue;
      if (x.loi) { out.loiKenh[c] = x.loi; continue; }
      const lc = kiemCotKenh(x.values, c); if (lc) { out.loiKenh[c] = lc; continue; }
      for (let i = 0; i <= 3; i++) { const ngay = ngayStr(congNgay(i)); out.ngay[ngay]['k' + c] = hangKenh(x.values, c, ngay); }
    }
    return out;
  }
  let docDLCho = null;
  async function docDuLieu(loai) {
    if (docDLCho) return docDLCho;
    docDLCho = (async () => {
      let vB, vV, vZ = null, vL, vM, vG; const vK = {};
      try { // (6.20.8) đọc 4 tab + ô Z3:Z4 (cài comment, kho thẻ) trong 1 lượt gọi
        const g = await docNhieu([[CAI_DAT.TAB_BAI, 'A1:Q3000'], [CAI_DAT.TAB_VIDEO, 'A1:N3000'], [CAI_DAT.TAB_BAI, CAI_DAT.O_CMT + ':' + CAI_DAT.O_THE]].concat(KENH_PHU.map((c) => [CAI_DAT.KENH[c].tab, vungKenh(c)])).concat([[CAI_DAT.TAB_BAI, CAI_DAT.O_LICH + ':' + CAI_DAT.O_GIO]])); // (6.32) Z8 lịch + Z9 mức đặt
        vB = g[0]; vV = g[1]; vZ = g[2]; KENH_PHU.forEach((c, i) => { vK[c] = { values: g[3 + i] }; }); vL = ((g[3 + KENH_PHU.length] || [])[0] || [])[0] ?? ''; vM = ((g[3 + KENH_PHU.length] || [])[1] || [])[0] ?? ''; vG = ((g[3 + KENH_PHU.length] || [])[2] || [])[0] ?? ''; // (6.26) gộp cả tab kênh Hà Xá trong cùng 1 lượt đọc
      } catch (e0) {
        if (e0 instanceof LoiLark) throw e0;
        ghi('Đọc gộp sheet chưa được (' + e0.message + ') → đọc từng tab');
        vB = await docBang(CAI_DAT.TAB_BAI, 'A1:Q3000');
        vV = await docBang(CAI_DAT.TAB_VIDEO, 'A1:N3000');
        for (const c of KENH_PHU) { // (6.19) kênh 2, 3, Hà Xá — đọc lỗi thì kênh 1 vẫn chạy bình thường
          try { vK[c] = { values: await docBang(CAI_DAT.KENH[c].tab, vungKenh(c)) }; } catch (e) { if (e instanceof LoiLark) throw e; vK[c] = { loi: `chưa đọc được tab "${CAI_DAT.KENH[c].tenTab}" (${e.message})` }; }
        }
        try { vL = (await docO(CAI_DAT.TAB_BAI, CAI_DAT.O_LICH)) ?? ''; } catch (e) { vL = undefined; }
        try { vM = (await docO(CAI_DAT.TAB_BAI, CAI_DAT.O_MUC)) ?? ''; } catch (e) { vM = undefined; }
        try { vG = (await docO(CAI_DAT.TAB_BAI, CAI_DAT.O_GIO)) ?? ''; } catch (e) { vG = undefined; } // (6.28.2) không đọc được → máy này tự xếp lịch như cũ
      }
      const d = phanTich(vB, vV, loai, vK);
      try { await locBuK1(d); } catch (e) { ghi('Đăng bù: lỗi ' + e.message); } // (6.37.1)
      luu('du_lieu6', d);
      await dongBoCmt(vZ ? (vZ[0] || [])[0] : undefined);
      await dongBoThe(vZ ? (vZ[1] || [])[0] : undefined);
      try { dongBoMuc(vM); } catch (e) { /* */ } // (6.33) mức đặt + giờ đăng trước khi dựng lịch (mức 0 bỏ ô, khung giờ mới)
      try { dongBoGio(vG); } catch (e) { /* */ }
      try { dongBoLich(); } catch (e) { ghi('Cập nhật lịch kênh 2, 3 lỗi: ' + e.message); }
      try { await dongBoLichThem(vL); } catch (e) { ghi('Lịch 2 máy: chưa đồng bộ được giờ bài thêm (' + e.message + ') → máy này dùng lịch tự xếp'); }
      try { thuLaiBaiThieu(d); } catch (e) { /* */ }
      const n = d.ngay[homNay()] || {};
      ghi(`Đọc Lark sheet (${({ nhe: 'lượt 13:30', chot: 'lượt 18:30', tay: 'bấm tay', thieu: 'chưa có dữ liệu hôm nay', thieuGio: 'có bài thiếu nội dung, đọc lại mỗi giờ', sang: 'đầu ngày, dữ liệu cũ từ hôm qua', suckhoe: 'tự kiểm tra sáng', nhacmai: 'trước khi nhắc điền sheet ngày mai' })[loai] || loai}): hôm nay có ${n.bai ? 'bài viết' : 'CHƯA có bài viết'}, ${(n.v || []).length} video, ${(n.m || []).length} manifest${d.chuaNgayV.length + d.chuaNgayB.length ? ` · ${d.chuaNgayV.length + d.chuaNgayB.length} hàng có nội dung nhưng chưa ghi ngày đăng (${[d.chuaNgayV.length ? 'tab Kênh 1 hàng ' + gonHang(d.chuaNgayV) : '', d.chuaNgayB.length ? 'tab Bài viết hàng ' + gonHang(d.chuaNgayB) : ''].filter(Boolean).join('; ')})` : ''}${d.loiCot ? ' — ' + d.loiCot : ''}${KENH_PHU.map((c) => d.loiKenh && d.loiKenh[c] ? ` — ${tenKenh(c)}: ${d.loiKenh[c]}` : ` · ${tenKenh(c)}: ${((n['k' + c] || []).filter((x) => x.duyet || x.daDang)).length} video hôm nay`).join('')}`);
      return d;
    })();
    try { return await docDLCho; } finally { docDLCho = null; }
  }
  // (6.28.2) LỊCH 2 MÁY — (6.28.3) giờ của TOÀN BỘ bài kênh 1 (lịch xếp đều) ghi ở ô O_LICH (Z8), kèm danh sách bài (sig).
  //  Máy nào xếp lịch trước thì ghi; máy kia cùng danh sách bài thì làm theo cho bài CHƯA đăng. Máy Giao (máy chính) được ưu tiên.
  //  1 máy tắt / ô trống / ô của hôm khác / đọc ô lỗi → máy còn lại tự xếp như cũ và ghi ô (Máy Cao chờ lịch Máy Giao tối đa 60 phút khi danh sách bài khác nhau).
  const TIEN_TO_LICH = 'LICH6|';
  const lichThemMinh = (ngay, s) => lichNgay(ngay).filter((x) => (x.kenh || 1) === 1 && typeof s.gio[x.k] === 'number').reduce((o, x) => { o[x.k] = s.gio[x.k]; return o; }, {});
  const docOLich = (raw) => { const t = chuO(raw).trim(); if (!t) return { o: null }; if (!t.startsWith(TIEN_TO_LICH)) return { khac: true }; try { return { o: JSON.parse(t.slice(TIEN_TO_LICH.length)) }; } catch (e) { return { o: null }; } };
  async function dongBoLichThem(raw, xacNhan) {
    if (raw === undefined || !MAY) return;
    const ngay = homNay(); try { trangThai(ngay); } catch (e) { /* */ } // xếp đều lịch (nếu cần) TRƯỚC khi so / ghi
    const s = lay('ngay6_' + ngay, null); if (!s || !s.gio) return;
    const d = docOLich(raw);
    if (d.khac) { if (!window.__lichOKhac) { window.__lichOKhac = 1; ghi(`Lịch 2 máy: ô ${CAI_DAT.O_LICH} (tab Bài viết kênh 1) đang có chữ khác → không dùng ô này, mỗi máy tự xếp lịch`); } return; }
    const o = d.o; const mine = lichThemMinh(ngay, s); if (!Object.keys(mine).length) return;
    const sig = s.sigK1 || '';
    const dd0 = lay('dang_do', null);
    const daLam = (k) => { const x = (s.s || {})[k]; return !!((x && x.tt && x.tt !== 'cho') || (dd0 && dd0.slot === k) || (demNguoc && demNguoc.ten && demNguoc.ten.includes(tenSlot(k)))); };
    const homNayOk = !!(o && o.ngay === ngay && o.gio && typeof o.gio === 'object');
    const cuaMinh = homNayOk && o.may === MAY;
    const banCu = homNayOk && cuHon(o.ban || '0', PHIEN_BAN); // ô do bản cũ hơn ghi
    const giaoDaGhi = LA_GIAO && lay('lichghi6', '') === ngay + '|' + sig;
    const theoO = homNayOk && !cuaMinh && !banCu && o.sig === sig && (o.gd || '') === sigGio() && !(giaoDaGhi && !cuHon(PHIEN_BAN, o.ban || '0'));
    const doi = [];
    if (theoO) for (const [k, v] of Object.entries(o.gio)) { if (!(k in mine) || typeof v !== 'number' || daLam(k) || mine[k] === v) continue; doi.push(`${tenSlot(k)} ${phutStr(mine[k])} → ${phutStr(v)}`); s.gio[k] = v; }
    if (doi.length) { luu('ngay6_' + ngay, s); ghi(`Lịch 2 máy: theo lịch ${o.may === 'CAO' ? 'Máy Cao' : 'Máy Giao'} ghi lúc ${gioStr(new Date(o.luc))} — ${doi.join(' · ')}`); try { veBang(); } catch (e) { /* */ } }
    if (theoO || chanLark()) return;
    if (larkTietKiem() && homNayOk) { if (!window.__lichTK) { window.__lichTK = 1; ghi('Lịch 2 máy: hôm nay đã chạm trần lượt Lark → không ghi lại ô lịch (lịch trong ô vẫn dùng được)'); } return; } // (6.28.5)
    const gioGhi = lichThemMinh(ngay, s);
    const khacO = !homNayOk || JSON.stringify(gioGhi) !== JSON.stringify(o.gio);
    let lyDo = '';
    if (!homNayOk) lyDo = 'ô chưa có lịch hôm nay';
    else if (cuaMinh) lyDo = khacO ? 'cập nhật lịch của máy này' : '';
    else if (banCu) lyDo = 'lịch trong ô là của bản cũ ' + (o.ban || '?');
    else if ((o.gd || '') !== sigGio() && !cuaMinh) lyDo = (o.luc || 0) < (gioDang().luc || 0) ? 'khung giờ đăng đã đổi' : '';
    else if (o.sig !== sig) lyDo = LA_GIAO || Date.now() - (o.luc || 0) > 60 * 60000 ? 'danh sách bài trong ngày đã đổi' : '';
    else if (LA_GIAO) lyDo = 'Máy Giao giữ lịch của mình';
    if (!lyDo || (xacNhan && LA_CAO)) return;
    await ghiO(CAI_DAT.TAB_BAI, CAI_DAT.O_LICH, TIEN_TO_LICH + JSON.stringify({ ngay, ban: PHIEN_BAN, may: MAY, luc: Date.now(), sig, gd: sigGio(), gio: gioGhi }));
    if (LA_GIAO) luu('lichghi6', ngay + '|' + sig);
    ghi(`Lịch 2 máy: ${TEN_MAY} ghi lịch kênh 1 hôm nay vào ô ${CAI_DAT.O_LICH} (${lyDo}) — ${Object.entries(gioGhi).sort((a, b) => a[1] - b[1]).map(([k, v]) => tenSlot(k) + ' ' + phutStr(v)).join(' · ')}`);
    if (!xacNhan) setTimeout(async () => { // 2 máy có thể ghi cùng lúc → 20–30 giây sau đọc lại ô 1 lần (chạy nền, không chặn việc đăng bài)
      try { const r2 = await docO(CAI_DAT.TAB_BAI, CAI_DAT.O_LICH); const o2 = docOLich(r2).o;
        if (o2 && o2.may !== MAY && o2.ngay === ngay) { ghi(`Lịch 2 máy: ${o2.may === 'CAO' ? 'Máy Cao' : 'Máy Giao'} vừa ghi ô cùng lúc → ${LA_GIAO ? 'Máy Giao ghi lại lịch của mình (máy chính được ưu tiên)' : 'Máy Cao làm theo lịch Máy Giao'}`); await dongBoLichThem(r2, true); }
      } catch (e) { ghi('Lịch 2 máy: đọc lại ô lịch chưa được (' + e.message + ')'); }
    }, 20000 + Math.floor(Math.random() * 10000));
  }
  // nội dung của 1 bài trong lịch (k = b1…m3) theo dữ liệu đã đọc
  // (6.28) mỗi hàng bài viết trong ngày được GHIM theo số dòng + 40 ký tự đầu (giống video): giữa ngày chèn / đổi ngày 1 dòng khác thì Bài 4 không lấy nhầm chữ Bài 1 đã đăng
  const khoaHangBai = (x) => khoaSo((x && (x.bai || x.bai2 || x.bai3)) || '').slice(0, 40);
  function hangBaiGhim(ngay, r, n) {
    const hs = (n && n.bais) || []; const s = lay('ngay6_' + ngay, null); const ganB = (s && s.ganB) || {};
    const pin = ganB[r];
    if (pin) { const x = hs.find((y) => y.hang === pin.hang && khoaHangBai(y) === pin.khoa) || hs.find((y) => khoaHangBai(y) === pin.khoa); if (x) return x; }
    const cuaKhac = new Set(Object.entries(ganB).filter(([rr]) => +rr !== r).map(([, v]) => v.khoa));
    if (pin) { const x = hs.find((y) => y.hang === pin.hang && !cuaKhac.has(khoaHangBai(y))); return x || null; } // dòng ghim bị sửa chữ → cùng số dòng
    const x = hs[r]; if (x && !cuaKhac.has(khoaHangBai(x))) return x;
    return hs.find((y) => !cuaKhac.has(khoaHangBai(y)) && !Object.values(ganB).some((v) => v.khoa === khoaHangBai(y))) || null;
  }
  function noiDungSlot(ngay, k, d = duLieu()) {
    const it = LICH.find((x) => x.k === k) || lichNgay(ngay, d).find((x) => x.k === k) || { k, loai: 'video', so: 0, kenh: kenhCua(k), ten: tenSlot(k) }; const n = d && d.ngay && d.ngay[ngay];
    if (!n) return { thieu: ['chưa đọc được sheet của ngày này'] };
    const gd = laSlotDong(it) ? ganDong(ngay, d) : null; // (6.19.3) video / manifest / kênh 2, 3: bài nào gắn với DÒNG nào trong sheet (không theo thứ tự)
    const matDong = gd && gd.map[k] === null; // dòng của bài này đã bị xoá / đổi chữ trong sheet sau khi bài đã làm
    if ((it.kenh || 1) > 1) { // (6.19) video kênh 2, 3
      const c = it.kenh; const cfg = CAI_DAT.KENH[c]; const th = [];
      if (d.loiKenh && d.loiKenh[c]) return { thieu: [d.loiKenh[c]], text: '' };
      const x = gd && k in gd.map ? gd.map[k] : videoKenh(n, c)[it.so];
      if (matDong) return { thieu: ['dòng của video này không còn trong sheet (đã xoá / đổi caption / đổi trạng thái)'], text: '', kenh: c, matDong: true };
      const cot = (i) => String.fromCharCode(65 + i);
      if (!x) th.push(`video ${tenKenh(c)} thứ ${it.so + 1} (tab "${cfg.tenTab}" chưa có dòng ghi ngày này với Trạng thái "ĐÃ DUYỆT")`);
      else { if (!x.tep) th.push(`file video ${it.ten} (cột ${cot(cfg.cot.video)} hàng ${x.hang})`); if (!x.cap) th.push(`caption ${it.ten} (cột ${cot(cfg.cot.cap)} hàng ${x.hang})`); }
      return { thieu: th, text: x ? x.cap : '', tep: x ? x.tep : null, hang: x ? x.hang : 0, daDang: x ? x.daDang : false, link: x ? x.link : '', kenh: c };
    }
    const b = hangBaiGhim(ngay, it.hangSo || 0, n); const th = []; // (6.26) bài của hàng thứ 2, 3… trong ngày
    if (b && /^b[123]$/.test(it.loai)) { // (6.37.1) cột G: chỉ đăng hàng "Đã duyệt"; "Đã đăng" = coi như đã xong; còn lại (Chờ làm / Chưa đăng / trống) → báo thiếu, không đăng (vẫn giữ chỗ)
      const tx = it.loai === 'b1' ? b.bai : it.loai === 'b2' ? b.bai2 : b.bai3;
      if (b.daDang && !b.bu) return { thieu: [], daDangSheet: true, daDang: true, text: tx, cmt: it.loai === 'b1' ? b.cmt : it.loai === 'b2' ? b.cmt2 : '', anh: it.loai === 'b2' ? b.anh2 : it.loai === 'b3' ? b.anh3 : [], hang: b.hang };
      if (!b.duyet && !b.daDang) th.push(`hàng ${b.hang} cột G chưa "Đã duyệt" (đang: "${b.trangThai || 'trống'}")`);
    }
    if (it.loai === 'b1') { if (!b) th.push('bài viết (cột H chưa có hàng ghi ngày này)'); else if (!b.bai) th.push('chữ Bài 1 (cột B)'); if (b && b.bai && !b.cmt) th.push('comment Bài 1 (cột C)'); return { thieu: th, text: b ? b.bai : '', cmt: b ? b.cmt : '', hang: b ? b.hang : 0 }; }
    if (it.loai === 'b2') { if (!b) th.push('bài viết (cột H chưa có hàng ghi ngày này)'); else if (!b.bai2) th.push('chữ Bài 2 (cột D)'); else { if (!b.anh2.length) th.push('ảnh Bài 2 (cột I–K)'); if (!b.cmt2) th.push('comment Bài 2 (cột E)'); } return { thieu: th, text: b ? b.bai2 : '', cmt: b ? b.cmt2 : '', anh: b ? b.anh2 : [], hang: b ? b.hang : 0 }; }
    if (it.loai === 'b3') { if (!b) th.push('bài viết (cột H chưa có hàng ghi ngày này)'); else if (!b.bai3) th.push('chữ Bài 3 (cột F)'); else { if (!b.anh3.length) th.push('ảnh Bài 3 (cột L–N)'); } return { thieu: th, text: b ? b.bai3 : '', anh: b ? b.anh3 : [], /* (6.37.1) bỏ ảnh comment theo ngày (cột O–Q hàng hôm nay) */ hang: b ? b.hang : 0 }; }
    if (matDong) return { thieu: [`dòng của ${it.ten} không còn trong sheet (đã xoá / đổi chữ)`], text: '', matDong: true };
    if (it.loai === 'video') { const x = gd && k in gd.map ? gd.map[k] : n.v[it.so]; if (!x) th.push(`video (cột K chưa có hàng thứ ${it.so + 1} ghi ngày này)`); else { if (!x.tep) th.push(`file video ${it.ten} (cột ${String.fromCharCode(65 + CAI_DAT.COT_VIDEO_K1)} hàng ${x.hang})`); if (!x.cap) th.push(`chữ đăng ${it.ten} (cột E hàng ${x.hang})`); } return { thieu: th, text: x ? x.cap : '', tep: x ? x.tep : null, hang: x ? x.hang : 0, daDang: x ? x.daDang : false }; }
    const x = gd && k in gd.map ? gd.map[k] : n.m[it.so]; if (!x) th.push(`manifest (cột K chưa có hàng thứ ${it.so + 1} ghi ngày này)`); else { if (!x.chu) th.push(`chữ ${it.ten} (cột G hàng ${x.hang})`); if (!x.anh) th.push(`ảnh ${it.ten} (cột H hàng ${x.hang})`); }
    return { thieu: th, text: x ? x.chu : '', anh: x ? x.anh : '', hang: x ? x.hang : 0 };
  }
  // ---- (6.32) MỨC ĐẶT số bài mỗi ngày (chỉnh bằng nút ⚙ trên bảng, đồng bộ 2 máy qua ô Z9) ----
  const MUC_MD = { k1v: 1, k1b: 1, k1m: 1, k2: 0, k3: 1, k4: 1 }; // (6.33) thêm k1m: manifest kênh 1
  const TEN_MUC = { k1v: 'Video kênh 1 / ngày', k1b: 'Hàng bài viết kênh 1 / ngày (1 hàng = 3 bài)', k1m: 'Manifest kênh 1 / ngày', k2: 'Video kênh 2 / ngày', k3: 'Video kênh 3 / ngày', k4: 'Video Hà Xá / ngày' };
  const tatK1 = (loai) => { const m = mucDat(); return loai === 'video' ? m.k1v === 0 : loai === 'manifest' ? m.k1m === 0 : /^b\d$/.test(loai || '') ? m.k1b === 0 : false; }; // (6.33) mức 0 = kênh 1 đăng tay loại này: script không tự đăng, không báo
  function mucDat() { const m = lay('muc_dat6', null) || {}; const o = {}; for (const k of Object.keys(MUC_MD)) { const v = m[k]; o[k] = Number.isInteger(v) && v >= 0 && v <= 20 ? v : MUC_MD[k]; } o.luc = m.luc || 0; o.may = m.may || ''; return o; }
  function demMuc(ngay, d = duLieu()) { // số dòng sheet ghi ngày này của từng loại
    const n = d && d.ngay && d.ngay[ngay]; if (!n) return null;
    const o = { k1v: (n.v || []).filter((x) => x.tep).length, k1b: n.soHangBai || 0, k1m: (n.m || []).length }; // (6.32.1) chỉ đếm dòng SẴN SÀNG đăng: kênh 1 có file video; kênh 2, 3, Hà Xá: ĐÃ DUYỆT (Hà Xá: có video) hoặc đã đăng
    for (const c of KENH_PHU) o['k' + c] = d.loiKenh && d.loiKenh[c] ? null : videoKenh(n, c).length;
    o.tong = { k1v: (n.v || []).length, k1b: n.soHangBai || 0, k1m: (n.m || []).length }; for (const c of KENH_PHU) o.tong['k' + c] = (n['k' + c] || []).length; // tổng số dòng ghi ngày này (kể cả chưa xong)
    return o;
  }
  function canhBaoMuc(ngay, d = duLieu(), homNayChe) { // homNayChe: hôm nay — so theo dòng sẵn sàng (dòng chưa xong không còn kịp) // ít hơn mức đặt → thiếu · từ 3 lần mức đặt trở lên → quá nhiều (dễ là nhập nhầm cột Ngày đăng)
    const dm = demMuc(ngay, d); if (!dm) return []; const m = mucDat(); const out = [];
    const ten = { k1v: ['kenh1', 'video', 'tab "Kênh 1 Vòng Trầm Hương SMH" cột K'], k1b: ['kenh1', 'hàng bài viết', 'tab "Bài viết kênh 1" cột H'], k1m: ['kenh1', 'manifest (đủ chữ cột G + ảnh cột H)', 'tab "Kênh 1 Vòng Trầm Hương SMH" cột K'] };
    for (const c of KENH_PHU) ten['k' + c] = ['kenh' + c, 'video', `tab "${CAI_DAT.KENH[c].tenTab}" cột ${String.fromCharCode(65 + CAI_DAT.KENH[c].cot.ngay)}`];
    for (const k of Object.keys(ten)) {
      const so = dm[k], muc = m[k]; if (so == null || !muc) continue; const [kk, loai, cho] = ten[k];
      const sanSang = k === 'k1b' ? '' : ' sẵn sàng đăng';
      if (so < muc && (homNayChe || (dm.tong[k] || 0) < muc)) out.push({ k: kk + '_muc' + k, ten: tenKenhDai(+kk.slice(4)), muc: true, thieu: [`thiếu ${muc - so} ${loai} (mức đặt ${muc}, ${cho} mới có ${homNayChe ? so + ' dòng sẵn sàng' : (dm.tong[k] || 0) + ' dòng'} ghi ngày này)`] });
      else if (so >= 3 * muc) out.push({ k: kk + '_nhieu' + k, ten: tenKenhDai(+kk.slice(4)), nhieu: true, thieu: [`quá nhiều: ${so} ${loai}${sanSang} cùng ngày (mức đặt ${muc}) — kiểm tra ${cho} có nhập nhầm ngày không`] });
    }
    return out;
  }
  async function luuMucDat(moi) { // lưu trên máy này + ghi ô Z9 cho máy kia (Lark hết lượt / ô đang có chữ khác → chỉ lưu máy này)
    const o = {}; for (const k of Object.keys(MUC_MD)) { const v = parseInt(moi[k], 10); o[k] = Number.isInteger(v) && v >= 0 && v <= 20 ? v : MUC_MD[k]; } o.luc = Date.now(); o.may = MAY;
    luu('muc_dat6', o); ghi(`Mức đặt số bài/ngày: K1 ${o.k1v} video + ${o.k1b} hàng bài + ${o.k1m} manifest · K2 ${o.k2} · K3 ${o.k3} · Hà Xá ${o.k4}`);
    const cu = lay('muc_o6', ''); if (cu && !/^MUCDAT\|/.test(cu)) throw new Error(`ô ${CAI_DAT.O_MUC} đang có chữ khác — chỉ lưu trên máy này`);
    if (chanLark()) throw new Error('Lark đang hết lượt — chỉ lưu trên máy này, máy kia cần chỉnh tay');
    await ghiO(CAI_DAT.TAB_BAI, CAI_DAT.O_MUC, 'MUCDAT|' + JSON.stringify(o)); luu('muc_o6', 'MUCDAT|');
    return true;
  }
  function dongBoMuc(raw) { // đọc ô Z9 (cùng lượt đọc sheet): máy kia chỉnh mới hơn → làm theo
    if (raw === undefined) return; const t = chuO(raw).trim(); luu('muc_o6', t.slice(0, 20));
    if (!/^MUCDAT\|/.test(t)) return; let o = null; try { o = JSON.parse(t.slice(7)); } catch (e) { return; }
    if (o && o.luc > (mucDat().luc || 0)) { luu('muc_dat6', o); ghi(`Mức đặt số bài/ngày: theo ${o.may === 'GIAO' ? 'Máy Giao' : o.may === 'CAO' ? 'Máy Cao' : 'máy kia'} (K1 ${o.k1v} video + ${o.k1b} hàng bài + ${o.k1m ?? 1} manifest · K2 ${o.k2} · K3 ${o.k3} · Hà Xá ${o.k4})`); }
  }
  // ---- (6.33) GIỜ ĐĂNG từng kênh (tab Mức đặt, đồng bộ 2 máy qua ô Z10): kênh 1 = giờ bài đầu – bài cuối (script rải đều trong khung);
  //  kênh 2, 3 để trống = như cũ (trước bài đầu kênh 1 khoảng 5–15 phút); Hà Xá mặc định 13:30–14:00
  const GIO_MD = { k1: ['06:30', '20:00'], k2: ['', ''], k3: ['', ''], k4: ['13:30', '14:00'] };
  const laGio = (t) => /^([01]\d|2[0-3]):[0-5]\d$/.test(String(t || ''));
  function gioDang() { const m = lay('gio_dang6', null) || {}; const o = {}; for (const k of Object.keys(GIO_MD)) { const v = m[k]; o[k] = Array.isArray(v) && ((laGio(v[0]) && laGio(v[1]) && docGio(v[0]) < docGio(v[1])) || (k !== 'k1' && !v[0] && !v[1])) ? [v[0], v[1]] : GIO_MD[k].slice(); } o.luc = m.luc || 0; o.may = m.may || ''; return o; }
  const khungKenh = (c) => { const g = gioDang()['k' + c]; return g && laGio(g[0]) && laGio(g[1]) ? [docGio(g[0]), docGio(g[1])] : null; };
  const sigGio = () => { const g = gioDang(); return Object.keys(GIO_MD).map((k) => g[k].join('-')).join('|'); };
  const moTaGio = (g) => `K1 ${g.k1.join('–')} · K2 ${g.k2[0] ? g.k2.join('–') : 'như cũ'} · K3 ${g.k3[0] ? g.k3.join('–') : 'như cũ'} · Hà Xá ${g.k4[0] ? g.k4.join('–') : 'như cũ'}`;
  function kiemGioNhap(moi) { // → { o, loi }
    const o = {}; const loi = [];
    for (const k of Object.keys(GIO_MD)) { const v = moi[k] || ['', '']; const a = String(v[0] || '').trim(), b = String(v[1] || '').trim(); const ten = k === 'k1' ? 'Kênh 1' : k === 'k4' ? 'Hà Xá' : 'Kênh ' + k.slice(1);
      if (!a && !b && k !== 'k1') { o[k] = ['', '']; continue; }
      if (!laGio(a) || !laGio(b)) { loi.push(`${ten}: cần điền đủ giờ "từ" và "đến"${k === 'k1' ? '' : ' (hoặc để trống cả hai = như cũ)'}`); continue; }
      if (docGio(a) >= docGio(b)) { loi.push(`${ten}: giờ "từ" phải sớm hơn giờ "đến"`); continue; }
      if (k === 'k1' && docGio(b) - docGio(a) < 60) { loi.push('Kênh 1: khung cần dài ít nhất 1 tiếng'); continue; }
      o[k] = [a, b]; }
    return { o, loi };
  }
  function apGioMoi(lyDo) { // xếp lại giờ các bài CHƯA đăng của hôm nay + ngày mai theo khung mới
    for (const ng of [homNay(), ngayMai()]) {
      const s = lay('ngay6_' + ng, null); if (!s || !s.gio) continue; const S = s.s || {};
      for (const k of Object.keys(s.gio)) { const g = nhomSlot(k); if (g && /^k\d$/.test(g.nhom) && !(S[k] && S[k].tt && S[k].tt !== 'cho')) delete s.gio[k]; }
      s.banXep = ''; luu('ngay6_' + ng, s);
    }
    try { trangThai(homNay()); } catch (e) { /* */ }
    ghi(`Giờ đăng: ${lyDo} → đã xếp lại giờ các bài chưa đăng hôm nay`);
  }
  async function luuGioDang(moi) {
    const o = Object.assign({}, moi, { luc: Date.now(), may: MAY });
    luu('gio_dang6', o); ghi(`Giờ đăng mới: ${moTaGio(gioDang())}`); apGioMoi('vừa lưu khung giờ mới');
    const cu = lay('gio_o6', ''); if (cu && !/^GIODANG\|/.test(cu)) throw new Error(`ô ${CAI_DAT.O_GIO} đang có chữ khác — chỉ lưu trên máy này`);
    if (chanLark()) throw new Error('Lark đang hết lượt — chỉ lưu trên máy này, máy kia cần chỉnh tay');
    await ghiO(CAI_DAT.TAB_BAI, CAI_DAT.O_GIO, 'GIODANG|' + JSON.stringify(o)); luu('gio_o6', 'GIODANG|');
    return true;
  }
  function dongBoGio(raw) { // đọc ô Z10 cùng lượt đọc sheet: máy kia chỉnh mới hơn → làm theo
    if (raw === undefined) return; const t = chuO(raw).trim(); luu('gio_o6', t.slice(0, 20));
    if (!/^GIODANG\|/.test(t)) return; let o = null; try { o = JSON.parse(t.slice(8)); } catch (e) { return; }
    if (o && o.luc > (gioDang().luc || 0)) { luu('gio_dang6', o); ghi(`Giờ đăng: theo ${o.may === 'GIAO' ? 'Máy Giao' : o.may === 'CAO' ? 'Máy Cao' : 'máy kia'} (${moTaGio(gioDang())})`); apGioMoi('máy kia vừa đổi khung giờ'); }
  }
  // danh sách thiếu của 1 ngày (cho cảnh báo vàng/đỏ trên popup)
  function thieuCuaNgay(ngay, d = duLieu()) {
    if (!d || !d.ngay || !d.ngay[ngay]) return null;
    const ds = [];
    const dm = demMuc(ngay, d) || {}; const du1 = (dm.k1v || 0) >= (mucDat().k1v || 0); // (6.32.1) kênh 1 đã đủ số video sẵn sàng → dòng chưa có file chỉ là dòng dự phòng, không báo
    for (const it of lichNgay(ngay, d)) { if (it.loai === 'manifest') continue; const nd = noiDungSlot(ngay, it.k, d); if (!nd.thieu.length) continue; if (it.loai === 'video' && du1 && nd.hang && !nd.tep) continue; ds.push({ k: it.k, ten: it.ten, thieu: nd.thieu }); } // (6.32) manifest không báo thiếu
    if (!tatK1('video')) for (const x of d.ngay[ngay].v || []) if (x.tep && !x.duyet && !x.daDang) ds.push({ k: 'kenh1_j' + x.hang, ten: 'Video kênh 1', nhac: true, thieu: [`hàng ${x.hang} cột J chưa "ĐÃ DUYỆT" (đang: "${x.tt || 'trống'}") — script vẫn đăng`] }); // (6.32) có file mà chưa duyệt → vẫn đăng, nhắc duyệt
    if (!tatK1('video')) for (const h of d.ngay[ngay].cuNham || []) ds.push({ k: 'kenh1_cu' + h, ten: 'Video kênh 1', nhac: true, thieu: [`hàng ${h} (tab Kênh 1) đã "ĐÃ ĐĂNG" từ trước, không có file video, nhưng cột K Ngày đăng lại ghi ${ngay.slice(0, 5).replace('-', '/')} — có thể ghi nhầm ngày, script bỏ qua dòng này`] }); // (6.32.4)
    for (const w of canhBaoMuc(ngay, d)) ds.push(w);
    for (const w of canhBaoKenh(ngay, d)) ds.push(w);
    return ds;
  }
  // ---- (6.19) lịch theo ngày: 9 bài kênh 1 + video kênh 2, 3 (dòng có Ngày đăng = ngày đó VÀ Trạng thái "ĐÃ DUYỆT"; dòng đã "ĐÃ ĐĂNG" vẫn giữ chỗ) ----
  const videoKenh = (n, c) => ((n && n['k' + c]) || []).filter((x) => x.duyet || x.daDang);
  const CHU_SO = 'abcdefgh';
  // ---- (6.19.3) GHIM DÒNG: mỗi bài video / manifest / kênh 2, 3 gắn với 1 dòng cụ thể của sheet (số dòng + 40 ký tự đầu của chữ).
  //  Sheet thêm / xoá / đổi thứ tự dòng giữa ngày thì bài đã làm vẫn giữ đúng dòng của nó; dòng mới → bài mới (Video 4, Manifest 4, Kênh 2 · Video 3…)
  const SO_TOI_DA = { v: 9, m: 9 };
  const khoaDong = (x) => khoaSo(x ? (x.cap || x.chu || (x.anh ? 'anh' + x.anh : '')) : '').slice(0, 40);
  const nhomSlot = (k) => { const m = String(k || '').match(/^(v|m)(\d)$/); if (m) return { nhom: m[1], so: +m[2] - 1 }; const q = String(k || '').match(/^k([2-4])([a-h])$/); return q ? { nhom: 'k' + q[1], so: CHU_SO.indexOf(q[2]) } : null; };
  const laSlotDong = (it) => !!(it && nhomSlot(it.k));
  const keySlot = (nhom, i) => (nhom === 'v' || nhom === 'm' ? nhom + (i + 1) : nhom + CHU_SO[i]);
  function itSlot(nhom, i) {
    if (nhom === 'v' || nhom === 'm') { const goc = LICH_GOC.find((x) => x.k === keySlot(nhom, i)); if (goc) return goc; const vd = nhom === 'v'; return { k: keySlot(nhom, i), ten: `${vd ? 'Video' : 'Manifest'} ${i + 1}`, tenBC: `${vd ? 'Video' : 'Manifest'} ${i + 1} (thêm)`, loai: vd ? 'video' : 'manifest', so: i, kenh: 1, them: true }; }
    const c = +nhom[1]; return { k: keySlot(nhom, i), ten: `${tenKenh(c)} · Video ${i + 1}`, tenBC: `${tenKenhDai(c)} · Video ${i + 1}`, nhan: `${CAI_DAT.KENH[c].hx ? 'HX' : 'K' + c}·${i + 1}`, loai: 'video', so: i, kenh: c };
  }
  let ganDongNho = null;
  function ganDong(ngay, d = duLieu()) { // → { map: { key: dòng | null (mất dòng) }, keys: { v: [...], m: [...], k2: [...], k3: [...] }, gan: {...} }
    const n = d && d.ngay && d.ngay[ngay]; const s = lay('ngay6_' + ngay, null) || {}; const ss = s.s || {}; const ganCu = s.gan || {};
    const dau = ngay + '|' + ((d && d.luc) || 0) + '|' + JSON.stringify(ganCu) + '|' + Object.keys(ss).map((k) => k + ss[k].tt).join(',');
    if (ganDongNho && ganDongNho.dau === dau) return ganDongNho.kq;
    const map = {}, keys = {}, gan = {};
    const nhoms = [['v', n ? n.v || [] : []], ['m', n ? n.m || [] : []]];
    for (const c of KENH_PHU) if (!(d && d.loiKenh && d.loiKenh[c])) nhoms.push(['k' + c, videoKenh(n, c)]);
    for (const [nhom, rows] of nhoms) {
      const toiDa = SO_TOI_DA[nhom] || CHU_SO.length;
      // các ô đang có của nhóm này: ô cố định (3 ô kênh 1) + ô đã có trạng thái / đã ghim
      const co = new Set(nhom === 'v' || nhom === 'm' ? (n ? [] : [0, 1, 2]) : []); // (6.32) kênh 1: sheet có bao nhiêu dòng thì bấy nhiêu ô (chưa có dữ liệu ngày đó → giữ 3 ô cũ để báo 'chưa đọc được')
      for (const k of Object.keys(ss).concat(Object.keys(ganCu))) { const g = nhomSlot(k); if (g && g.nhom === nhom && g.so < toiDa) co.add(g.so); }
      const dung = new Set(); const oMap = {};
      // 1) ô đã ghim: tìm lại đúng dòng theo chữ (ưu tiên cùng số dòng)
      for (const i of [...co].sort((a, b) => a - b)) {
        const k = keySlot(nhom, i); const b = ganCu[k]; if (!b || !b.khoa) continue;
        let j = rows.findIndex((x, jj) => !dung.has(jj) && x.hang === b.hang && khoaDong(x) === b.khoa);
        if (j < 0) j = rows.findIndex((x, jj) => !dung.has(jj) && khoaDong(x) === b.khoa);
        if (j >= 0) { dung.add(j); oMap[i] = j; }
      }
      // 2) dòng chưa có ô → ô trống (chưa ghim, hoặc mất dòng mà chưa làm) theo thứ tự; hết ô thì mở ô mới
      const daLam = (i) => { const r = ss[keySlot(nhom, i)]; return !!(r && r.tt && r.tt !== 'cho'); };
      const trong = [...co].sort((a, b) => a - b).filter((i) => !(i in oMap) && !(ganCu[keySlot(nhom, i)] && daLam(i)));
      for (let j = 0; j < rows.length; j++) {
        if (dung.has(j)) continue;
        let i = trong.shift();
        if (i === undefined) { i = 0; while (co.has(i)) i++; if (i >= toiDa) break; co.add(i); }
        dung.add(j); oMap[i] = j;
      }
      keys[nhom] = [...co].sort((a, b) => a - b).map((i) => keySlot(nhom, i));
      for (const i of co) {
        const k = keySlot(nhom, i);
        if (i in oMap) { const x = rows[oMap[i]]; map[k] = x; gan[k] = { hang: x.hang, khoa: khoaDong(x) }; }
        else if (ganCu[k] && daLam(i)) { map[k] = null; gan[k] = ganCu[k]; } // bài đã làm nhưng dòng của nó không còn → giữ ô, không gán dòng khác
        else map[k] = undefined;
      }
      // ô kênh 2, 3 / ô thêm của kênh 1 không còn dòng nào và chưa làm → bỏ khỏi lịch
      keys[nhom] = keys[nhom].filter((k) => { const g = nhomSlot(k); return map[k] !== undefined || (nhom === 'v' || nhom === 'm' ? !n && g.so < 3 : false) || daLam(g.so); });
    }
    const kq = { map, keys, gan };
    ganDongNho = { dau, kq }; return kq;
  }
  // (6.26) ngày có nhiều hàng bài viết: hàng thứ r (từ 0) → Bài 3r+1 (twist), 3r+2 (twist + ảnh), 3r+3 (storytelling)
  const TEN_LOAI_BAI = { 1: 'twist', 2: 'twist + ảnh', 3: 'storytelling' };
  const itBai = (r, j) => ({ k: 'b' + (3 * r + j), ten: `Bài ${3 * r + j}`, tenBC: `Bài ${3 * r + j} ${TEN_LOAI_BAI[j]}`, loai: 'b' + j, hangSo: r, kenh: 1, baiThem: true });
  function lichNgay(ngay, d = duLieu()) {
    const gd = ganDong(ngay, d); const out = [];
    const nN = d && d.ngay && d.ngay[ngay]; // (6.32) bài viết: chỉ có ô Bài 1–3 khi sheet có hàng ghi ngày này (chưa có dữ liệu ngày đó → giữ ô để báo 'chưa đọc được')
    for (const it of LICH_GOC) if (!laSlotDong(it)) { if (!nN || (nN.soHangBai || 0) >= 1) out.push(it); } else { const g = nhomSlot(it.k); if ((gd.keys[g.nhom] || []).includes(it.k)) out.push(it); }
    { const nn = d && d.ngay && d.ngay[ngay]; const hs = (nn && nn.bais) || []; const nh = Math.min(6, Math.max((nn && nn.soHangBai) || 0, hs.length)); for (let r = (nn && nn.soHangBai) ? 1 : 0; r < nh; r++) for (let j = 1; j <= 3; j++) { const x = hs[r]; if (x && x.bu && !(x.bu.can || []).includes(j)) continue; out.push(Object.assign(itBai(r, j), x && x.bu ? { bu: x.bu.ngay, ten: `Bài ${3 * r + j} (bù ${x.bu.ngay.slice(0, 5).replace('-', '/')})`, tenBC: `Bài ${3 * r + j} ${TEN_LOAI_BAI[j]} — bù bài ${['', 'Bài 1', 'Bài 2', 'Bài 3'][j]} ngày ${x.bu.ngay.slice(0, 5).replace('-', '/')}` } : {})); } } // (6.37.1) hàng bù (bài ngày trước chưa lên) chỉ thêm đúng bài còn thiếu // (6.26) mỗi hàng bài viết thêm = 3 bài
    for (const nhom of ['v', 'm']) for (const k of gd.keys[nhom] || []) { const g = nhomSlot(k); if (g.so >= 3) out.push(itSlot(nhom, g.so)); }
    for (const c of KENH_PHU) for (const k of gd.keys['k' + c] || []) out.push(itSlot('k' + c, nhomSlot(k).so));
    return out.filter((it) => (it.kenh || 1) > 1 || !tatK1(it.loai)); // (6.33) kênh 1 loại nào mức 0 → không có trong lịch tự đăng
  }
  function dongBoLich() { // LICH = lịch hôm nay (giữ chỗ cho video đã có trạng thái trong ngày, kể cả khi sheet đổi trạng thái sau đó)
    const ngay = homNay(); const moi = lichNgay(ngay); const s = lay('ngay6_' + ngay, null);
    if (s && s.s) for (const k of Object.keys(s.s)) { const g = nhomSlot(k); if (g && !moi.some((x) => x.k === k) && s.s[k] && s.s[k].tt !== 'cho') moi.push(itSlot(g.nhom, g.so)); const bm = /^b(\d+)$/.exec(k); if (bm && +bm[1] >= 1 && !moi.some((x) => x.k === k) && s.s[k] && s.s[k].tt !== 'cho') moi.push(itBai(Math.floor((+bm[1] - 1) / 3), ((+bm[1] - 1) % 3) + 1)); } // bài đã làm vẫn giữ chỗ
    { const d0 = duLieu(); if (s && d0 && d0.ngay && d0.ngay[ngay]) { const gd = ganDong(ngay, d0); const giuK = {}; for (const [k0, v0] of Object.entries(s.gan || {})) { const g0 = nhomSlot(k0); if (g0 && /^k\d$/.test(g0.nhom) && d0.loiKenh && d0.loiKenh[+g0.nhom.slice(1)] && !(k0 in gd.gan)) giuK[k0] = v0; } const ganMoi = Object.assign({}, giuK, gd.gan); /* (6.28) kênh đang đọc tab lỗi: giữ ghim cũ */ { const hs = d0.ngay[ngay].bais || []; const ganB = Object.assign({}, s.ganB || {}); let doiB = false; for (let r = 0; r < hs.length; r++) if (!ganB[r]) { const x = hangBaiGhim(ngay, r, d0.ngay[ngay]); if (x) { ganB[r] = { hang: x.hang, khoa: khoaHangBai(x) }; doiB = true; } } if (doiB) { const s3 = lay('ngay6_' + ngay, null); if (s3) { s3.ganB = ganB; luu('ngay6_' + ngay, s3); s.ganB = ganB; } } } if (JSON.stringify(ganMoi) !== JSON.stringify(s.gan || {})) { const s2 = lay('ngay6_' + ngay, null); if (s2) { s2.gan = ganMoi; luu('ngay6_' + ngay, s2); } } } } // (6.19.3) lưu ghim dòng
    { const S0 = (s && s.s) || {}; for (let i = moi.length - 1; i >= 0; i--) { const it = moi[i]; if ((it.kenh || 1) === 1 && tatK1(it.loai) && !XONG.includes((S0[it.k] || {}).tt)) moi.splice(i, 1); } } // (6.33) mức 0: bỏ cả ô đang chờ/thiếu của loại đó (chỉ giữ bài đã lên)
    const cu = LICH.map((x) => x.k).join(',');
    LICH.length = 0; for (const it of moi) LICH.push(it);
    if (LICH.map((x) => x.k).join(',') !== cu) { const tm = LICH.filter((x) => x.them); const dauT = ngay + '|' + tm.map((x) => x.k).join(','); if (tm.length && lay('lich_t6', '') !== dauT) { luu('lich_t6', dauT); ghi(`Sheet hôm nay có thêm ${tm.length} bài kênh 1 ngoài 9 bài thường lệ: ${tm.map((x) => x.ten).join(', ')} → đã xếp lịch`); } }
    if (LICH.map((x) => x.k).join(',') !== cu) { const them = LICH.filter((x) => x.kenh > 1); const dau = ngay + '|' + them.map((x) => x.k).join(','); if (lay('lich_k6', '') !== dau) { luu('lich_k6', dau); ghi(`Lịch hôm nay có ${them.length} video kênh 2, 3, Hà Xá: ${them.map((x) => x.ten).join(', ') || '(không có)'}`); } }
    return LICH;
  }
  // cảnh báo cho nhân sự sửa sheet kênh 2, 3 (popup + 16:00 hôm trước)
  function canhBaoKenh(ngay, d = duLieu()) {
    const out = []; const n = d && d.ngay && d.ngay[ngay]; if (!n) return out;
    for (const c of KENH_PHU) {
      const cfg = CAI_DAT.KENH[c]; const ten = tenKenhDai(c);
      if (d.loiKenh && d.loiKenh[c]) { if (mucDat()['k' + c]) out.push({ k: 'kenh' + c, ten, thieu: [d.loiKenh[c]] }); continue; }
      const ds = n['k' + c]; if (!ds) continue;
      if (!ds.length) continue; // (6.32) thiếu dòng → tính theo mức đặt (canhBaoMuc)
      if (!mucDat()['k' + c]) continue; // (6.32) mức đặt 0 (kênh tạm dừng) → không nhắc dòng chưa có video / chưa duyệt; dòng nào đủ thì vẫn đăng
      if (videoKenh(n, c).length >= mucDat()['k' + c]) continue; // (6.32.1) đã đủ số video sẵn sàng → các dòng chưa xong là dự phòng, không báo
      for (const x of ds) if (!x.duyet && !x.daDang && cfg.khongDuyet) out.push({ k: 'kenh' + c + '_' + x.hang, ten, thieu: [`hàng ${x.hang} có Ngày đăng nhưng chưa có video (cột ${String.fromCharCode(65 + cfg.cot.video)})`] });
        else if (!x.duyet && !x.daDang) out.push({ k: 'kenh' + c + '_' + x.hang, ten, thieu: [`hàng ${x.hang} có Ngày đăng nhưng Trạng thái (cột ${String.fromCharCode(65 + cfg.cot.tt)}) chưa "ĐÃ DUYỆT" (đang: "${x.tt || 'trống'}")${x.tep ? '' : ', chưa có video'}${x.cap ? '' : ', chưa có caption'}`] });
    }
    return out;
  }
