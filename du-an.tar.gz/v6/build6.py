#!/usr/bin/env python3
# Ghép bản 6.0: các phần mới (p*.js) + các hàm dùng lại từ bản 5.9.7 (out70_cao.js) và phần Gắn từ bản Giao (out62_giao.js)
import re, sys, os
D = os.path.dirname(os.path.abspath(__file__))
CAO = open(os.path.join(D, '..', 'out70_cao.js'), encoding='utf-8').read().split('\n')
GIAO = open(os.path.join(D, '..', 'out62_giao.js'), encoding='utf-8').read().split('\n')

START = re.compile(r'^  (?:async function|function|const|let|var) ([A-Za-z_$][\w$]*)')
TOP = re.compile(r'^  [^ }\)\]]')

def items(lines):
    starts = [i for i, l in enumerate(lines) if TOP.match(l)]
    out = {}
    for n, i in enumerate(starts):
        m = START.match(lines[i])
        if not m:
            continue
        j = starts[n + 1] if n + 1 < len(starts) else len(lines)
        blk = lines[i:j]
        while blk and (blk[-1].strip() == '' or blk[-1].strip().startswith('//')):
            blk.pop()
        name = m.group(1)
        if name in out:
            continue  # lấy định nghĩa đầu tiên
        out[name] = '\n'.join(blk)
    return out

IC = items(CAO)

def lay(names, src=IC):
    res = []
    for nm in names:
        if nm not in src:
            sys.exit('THIẾU hàm trong bản cũ: ' + nm)
        res.append(src[nm])
    return '\n'.join(res) + '\n'

def thay(txt, cu, moi, lan=1):
    n = txt.count(cu)
    if n != lan:
        sys.exit(f'Vá không khớp ({n} chỗ, cần {lan}): {cu[:90]!r}')
    return txt.replace(cu, moi)

def phan(ten):
    return open(os.path.join(D, ten), encoding='utf-8').read()

# ---------- các khối dùng lại ----------
A = lay(['dangHien', 'tieuDeHien', 'laCaiDat', 'laNhom', 'hopThoai', 'nutTheoChu', 'nutTaiKhoan', 'moMenuTaiKhoan', 'dongMenuTaiKhoan', 'damBaoTuCach',
         'dungTrang', 'veTrang', 'hopSoanBai', 'timNutSoanBai', 'datChu', 'hopDangDo', 'choTabAn', 'hetChoTabAn'])
A = '\n  // =====================================================================\n  //  Facebook: tư cách, đúng trang, hộp soạn bài (dùng lại từ bản 5.9)\n  // =====================================================================\n' + A
A = thay(A, "const dungTrang = () => location.pathname.toLowerCase().replace(/\\/+$/, '') === CAI_DAT.DUONG_DAN_TRANG;", "const dungTrang = () => kenhHT().duong.includes(duongNay()); // (6.19) theo kênh đang làm · (6.26) trang không có tên riêng (profile.php?id=)")

MF = lay(['FONT_MF', 'fontMFXong', 'napFontMF', 'taoAnhManifest', 'Mp4Muxer', 'HIEU_UNG_MF', 'ngauMF', 'HAT_MF', 'LAP_MF', 'DOM_MF', 'KHOI_MF', 'ROI_MF', 'BOK_MF', 'dotMF', 'veKhungMF', 'ghepManifestWC'])
MF = '\n  // =====================================================================\n  //  Manifest: font chữ, tạo ảnh, ghép video (dùng lại từ bản 5.9.7)\n  // =====================================================================\n' + MF

# (6.4) chọn font riêng cho tiêu đề / thân / lời kêu gọi
MF = thay(MF, 'async function taoAnhManifest(nenBlob, chuO, font, fontCmt) {', 'async function taoAnhManifest(nenBlob, chuO, font, fontCmt, fontTd, fontThan) {')
MF = thay(MF, "const F = font || 'UTM American Sans', FC = fontCmt || 'UTM Aptima';", "const F = font || 'UTM American Sans', FC = fontCmt || 'UTM Aptima', FT = fontTd || F, FB = fontThan || F;")
MF = thay(MF, "{ ds: ngat(tieuDe, 73 * tl), px: 73 * tl, mau: '#f8ef3b', cach: 87 * tl, dong: 84 * tl },", "{ ds: ngat(tieuDe, 73 * tl, FT), px: 73 * tl, mau: '#f8ef3b', cach: 87 * tl, dong: 84 * tl, ff: FT },")
MF = thay(MF, "kh.push({ ds: than.flatMap((s) => ngat(s, 68 * tl)), px: 68 * tl, mau: '#ffffff', cach: 156 * tl, dong: 77 * tl });", "kh.push({ ds: than.flatMap((s) => ngat(s, 68 * tl, FB)), px: 68 * tl, mau: '#ffffff', cach: 156 * tl, dong: 77 * tl, ff: FB });")

POST = lay(['dangLenFacebook', 'nutCuaBai', 'nutCuaCmt', 'nhanArt', 'laCmtArt', 'taoTimArt', 'thichMotCmt', 'DA_CO_CAM_XUC', 'thaCamXuc', 'thaCamXucBai', 'thaCamXucCmt',
            'oCuaNguoiKhac', 'timBai', 'linkBai', 'loiTuFacebook', 'xoaO', 'dienCmt', 'binhLuan',
            'demAnhLon', 'xoaAnhCu', 'ganAnhVaoHop', 'coHopDang', 'dongHopSoan', 'binhLuanAnh',
            'cmtDaCoApi', 'suaNenDo', 'dongHopSua', 'lenLaiCmtThieu', 'chayComment'])

A = thay(A, "    if (!nut) { await dongMenuTaiKhoan(); throw new LoiMem(`Đang dùng tư cách \"${ten}\", không tìm thấy nút chuyển sang \"${CAI_DAT.TEN_TRANG}\"`); }",
  """    if (!nut) { // (6.18) menu không có nút chuyển (Facebook chỉ hiện vài trang) → dùng nút "Chuyển ngay" ngay trên trang Vòng Trầm Hương
      await dongMenuTaiKhoan();
      if (await xacNhanChuyen(500)) return false; // (6.26.1) hộp "Chuyển trang cá nhân" còn mở từ lần trước → bấm Chuyển
      const nutTrang = dungTrang() && Array.from(document.querySelectorAll('[role="button"],button')).find((b) => /^(Chuyển ngay|Chuyển|Switch now|Switch)$/i.test(chuan(b.innerText || b.getAttribute('aria-label') || '')) && !b.closest('[role="dialog"]') && !b.closest('#smhfb') && (dangHien(b) || /^Chuyển/.test(b.getAttribute('aria-label') || ''))); // (6.26.2) cửa sổ hẹp: khung trái thu lại, nút vẫn có trong trang
      if (nutTrang && Date.now() - ((lay('tc_trang6', {}) || {})[CAI_DAT.TEN_NGAN] || 0) > 5 * 60000) { luu('tc_trang6', Object.assign({}, lay('tc_trang6', {}) || {}, { [CAI_DAT.TEN_NGAN]: Date.now() })); ghi(`Menu không có nút chuyển sang "${CAI_DAT.TEN_TRANG}" → bấm nút "${chuan(nutTrang.innerText || nutTrang.getAttribute('aria-label'))}" ngay trên trang`); try { ganBam(nutTrang); } catch (e) { nutTrang.click(); } await xacNhanChuyen(); return false; }
      if (!dungTrang() && Date.now() - ((lay('tc_mo_trang6', {}) || {})[CAI_DAT.TEN_NGAN] || 0) > 5 * 60000) { luu('tc_mo_trang6', Object.assign({}, lay('tc_mo_trang6', {}) || {}, { [CAI_DAT.TEN_NGAN]: Date.now() })); ghi('Menu không có nút chuyển trang → mở trang ' + CAI_DAT.TEN_NGAN + ' để dùng nút "Chuyển ngay" trên trang'); veTrang(); return false; }
      throw new LoiMem(`Đang dùng tư cách "${ten}", không tìm thấy nút chuyển sang "${CAI_DAT.TEN_TRANG}" (cả trong menu lẫn trên trang)`);
    }""")
POST = '\n  // =====================================================================\n  //  Facebook: đăng bài chữ/ảnh, comment, sửa nền đỏ (dùng lại từ bản 5.9)\n  // =====================================================================\n' + POST
POST = thay(POST, 'await hoanTatB23(dd, ', 'await hoanTatSlot(dd, ', 2)
# (6.8) hộp soạn vừa mở có thể chưa kịp hiện tên trang → chờ tới 8 giây rồi mới kết luận "không đứng tên"
POST = POST.replace("if (!chuan(dlg.innerText.split('\\n').slice(0, 3).join(' ')).includes(chuan(CAI_DAT.TEN_TRANG))) throw new LoiMem('Hộp soạn bài không đứng tên ' + CAI_DAT.TEN_TRANG);", 'await choTenHop(() => hopSoanBai() || dlg);')
POST = POST.replace("  async function dangVideoFb(v, { soanThu = false } = {}) {", '''  const tenHopDung = (d) => !!d && chuan(d.innerText.split('\\n').slice(0, 4).join(' ')).includes(chuan(CAI_DAT.TEN_TRANG));
  async function choTenHop(layHop) { // hộp soạn phải đứng tên trang; mới mở có thể chưa hiện tên → đợi tối đa 8 giây
    const ok = await cho(() => tenHopDung(layHop()), 8000, 400);
    if (ok) return;
    const d = layHop(); const dau = d ? chuan(d.innerText.split('\\n').slice(0, 4).join(' | ')) : '(không có hộp)';
    ghi('Hộp soạn đang hiện: ' + dau.slice(0, 120));
    throw new LoiMem('Hộp soạn bài không đứng tên ' + CAI_DAT.TEN_TRANG + ' (đang hiện: ' + dau.slice(0, 60) + ')');
  }
  async function dangVideoFb(v, { soanThu = false } = {}) {''', 1)
# (6.7) timBai: không leo lên tới khung chứa popup của script (popup có hiện chữ bài → nhận nhầm bài cũ là bài vừa đăng)
POST = thay(POST, "        const t = p.innerText;\n        if (t && (chuan(t).includes(khoa)", "        if (p === document.body || p === document.documentElement || p.querySelector('#smhfb')) break;\n        const t = p.innerText;\n        if (t && (chuan(t).includes(khoa)")
POST = thay(POST, 'await taiAnhLark(it.v, ', 'await taiAnhKho(it.v, ')
# (6.13) trước mỗi comment chữ: hỏi Facebook xem dưới bài đã có comment này chưa (máy kia / tab khác / đăng tay đã gửi) → có rồi thì bỏ qua, không gửi trùng
POST = thay(POST, "        if (it.k === 'text') await binhLuan(dd.bai, it.v);", "        if (it.k === 'text' && coApi()) { let coSan = false; try { if (!dd.id) { const p0 = baiGiongNhat(await baiTrenTrangApi(Date.now() - 6 * 3600e3), dd.bai); if (p0) { dd.id = p0.id; dd.link = dd.link || p0.link; } } if (dd.id) coSan = (await cmtChiTietApi(dd.id)).msgs.some((c) => khopCmt(c, it.v)); } catch (e) { /* */ } if (coSan) { ghi(`Comment thứ ${dd.cmtIdx + 1} đã có sẵn dưới bài (máy khác / tab khác đã gửi) → không gửi trùng`); dd.cmtIdx++; dd.dangGui = null; luu('dang_do', dd); continue; } }\n        if (it.k === 'text') await binhLuan(dd.bai, it.v);")
# (6.12) có thể có 2 comment chữ (comment chính + comment CTA) → kiểm và gửi bù từng cái
POST = thay(POST, "      const textCan = goc.find((x) => x.k === 'text');", "      const textCans = goc.filter((x) => x.k === 'text');")
POST = thay(POST, "        thieuText = !!(textCan && !cs.msgs.some((c) => khopCmt(c, textCan.v)));", "        thieuText = textCans.filter((t) => !cs.msgs.some((c) => khopCmt(c, t.v)));\n        if (!thieuText.length) thieuText = false;")
POST = thay(POST, "      const ds = []; if (thieuText) ds.push(textCan);", "      const ds = []; if (thieuText) ds.push(...thieuText);")
POST = POST.replace("ghi(`Kiểm tra: thiếu ${thieuText ? '1 comment chữ' : ''}", "ghi(`Kiểm tra: thiếu ${thieuText ? thieuText.length + ' comment chữ' : ''}")
POST = thay(POST, "    const CHU_BO_QUA = ['Lúc khác', 'Để sau', 'Không phải bây giờ', 'Không phải lúc này', 'Bỏ qua', 'Không, cảm ơn', 'Không cảm ơn'];", "    const CHU_BO_QUA = ['Lúc khác', 'Để sau', 'Không phải bây giờ', 'Không phải lúc này', 'Bỏ qua', 'Không, cảm ơn', 'Không cảm ơn', 'Đăng bài viết gốc', 'Đăng bài gốc'];")
# (6.11) sửa nền đỏ: trang chưa vẽ lại / ảnh khác lọt vào khung bài → hỏi Facebook (API) xem bài còn ảnh không trước khi kết luận lỗi
POST = thay(POST, "if (!(await cho(() => !conAnhF(), 25000, 1500))) throw new Error('đã Lưu nhưng trên bài vẫn còn ảnh'); }",
  "if (!(await cho(() => !conAnhF(), 25000, 1500))) { const api = await baiConAnhApi(b.bai || ''); if (api === false) { ghi('Sửa nền: trang chưa cập nhật nhưng Facebook (API) xác nhận bài KHÔNG còn ảnh → coi như đã sửa xong'); } else { try { const b2 = timBai(b.bai || '') || b; const ds = Array.from(b2.khung.querySelectorAll('img')).filter((im) => im.getBoundingClientRect().width > 100).map((im) => Math.round(im.getBoundingClientRect().width) + 'x' + Math.round(im.getBoundingClientRect().height) + ':' + (im.alt || '').slice(0, 30)); ghi('Sửa nền: ảnh còn thấy trên bài: ' + (ds.join(' | ') || 'không rõ') + (api === null ? ' · chưa hỏi được Facebook (API)' : ' · Facebook (API) cũng báo còn ảnh')); } catch (e) { /* */ } throw new Error('đã Lưu nhưng trên bài vẫn còn ảnh'); } } }")
# (6.10) video/manifest cũng thả cảm xúc (Thích hoặc Yêu thích ngẫu nhiên) cho bài vừa đăng
POST = thay(POST, "    if (dd.ngoai) { dd.daThaBai = true; dd.camXucCmt = dd.camXucCmt || { tt: 'bo' }; }", "    if (dd.ngoai) { dd.camXucCmt = dd.camXucCmt || { tt: 'bo' }; if (!dd.daThaBai) { dd.camXucBai = await thaCamXucReel(dd.bai); dd.daThaBai = true; luu('dang_do', dd); } }")
# (6.10) bài chữ: từ lần thử lại, bước phụ (nền đỏ, vị trí, chọn nhóm) lỗi thì bỏ qua bước đó và vẫn đăng
POST = thay(POST, """    if (!nen) throw new LoiMem('Không thấy nền "' + CAI_DAT.NEN + '" (bài có thể dài quá ' + CAI_DAT.GIOI_HAN_KY_TU_NEN + ' ký tự)');
    nen.click(); await sleep(900);
    ghi('B3. Đã chọn nền ' + CAI_DAT.NEN);""", """    if (!nen && !thuNhe()) throw new LoiMem('Không thấy nền "' + CAI_DAT.NEN + '" (bài có thể dài quá ' + CAI_DAT.GIOI_HAN_KY_TU_NEN + ' ký tự)');
    if (!nen) boQuaBuoc('nền đỏ', { message: 'không thấy nền ' + CAI_DAT.NEN });
    else { nen.click(); await sleep(900);
    ghi('B3. Đã chọn nền ' + CAI_DAT.NEN); }""")
i0 = POST.index("    // vị trí\n    const coViTri = ")
i1 = POST.index("    ghi('B4. Vị trí: đang ở ' + CAI_DAT.VI_TRI);\n", i0) + len("    ghi('B4. Vị trí: đang ở ' + CAI_DAT.VI_TRI);\n")
khoiVT = POST[i0:i1]
POST = POST[:i0] + "    try {\n" + khoiVT + """    } catch (eVT) {
      if (!thuNhe() || eVT instanceof LoiDung) throw eVT;
      boQuaBuoc('vị trí', eVT);
      for (let k = 0; k < 2 && !hopSoanBai(); k++) { document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', code: 'Escape', keyCode: 27, which: 27, bubbles: true })); await sleep(1200); }
      if (!hopSoanBai()) throw eVT;
    }
""" + POST[i1:]
j0 = POST.index("    // chia sẻ lên nhóm\n")
j1 = POST.index("    ghi('B8. Màn Cài đặt xác nhận ' + soNhom + ' nhóm');\n", j0) + len("    ghi('B8. Màn Cài đặt xác nhận ' + soNhom + ' nhóm');\n")
khoiN = POST[j0:j1]
assert khoiN.count("    const soNhom = ") == 1 and khoiN.count("    let caiDat2 = ") == 1
khoiN = khoiN.replace("    const soNhom = ", "    soNhom = ").replace("    let caiDat2 = ", "    caiDat2 = ")
POST = POST[:j0] + "    let soNhom = 0, caiDat2 = null;\n    try {\n" + khoiN + """    } catch (eN) {
      if (!thuNhe() || eN instanceof LoiDung) throw eN;
      boQuaBuoc('chọn nhóm', eN);
      const hn = hopThoai((d) => laNhom(d)); if (hn) { const x = nutTheoChu(hn, 'Xong'); if (x) x.click(); else document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', code: 'Escape', keyCode: 27, which: 27, bubbles: true })); await sleep(1500); }
      caiDat2 = await cho(() => hopThoai((d) => laCaiDat(d)), 10000); soNhom = 0;
      if (!caiDat2) throw eN;
    }
""" + POST[j1:]

# (6.15) bài chữ/ảnh: mở hộp soạn bằng nhiều đường (ô "Bạn đang nghĩ gì?" → nút "Ảnh/video" → tải lại trang); hộp đứng sai tên → đóng, chuyển tư cách, mở lại 1 lần
POST = thay(POST, """    let dlg = hopSoanBai();
    if (!dlg) {
      const nut = timNutSoanBai();
      if (!nut) throw new LoiMem('Không tìm thấy ô "Bạn đang nghĩ gì?" trên trang');
      nut.click();
      dlg = await cho(hopSoanBai, 10000);
      if (!dlg) { ghi('B1. Bấm mở hộp soạn lần 1 chưa ăn → bấm lại'); const n2 = timNutSoanBai() || nut; try { ganBam(n2); } catch (e) { n2.click(); } dlg = await cho(hopSoanBai, 12000); }
    }
    if (!dlg) throw new LoiMem('Không mở được hộp soạn bài');
    ghi('B1. Đã mở hộp soạn bài: ' + chuan(dlg.innerText.split('\\n').slice(0, 3).join(' | ')));
    await choTenHop(() => hopSoanBai() || dlg);
""", """    let dlg = await moHopSoanNhieuDuong((m) => ghi('B1. ' + m));
    ghi('B1. Đã mở hộp soạn bài: ' + chuan(dlg.innerText.split('\\n').slice(0, 3).join(' | ')));
    try { await choTenHop(() => hopSoanBai() || dlg); }
    catch (eT) {
      if (!(eT instanceof LoiMem)) throw eT;
      ghi('B1. Hộp soạn không đứng tên ' + CAI_DAT.TEN_TRANG + ' → đóng hộp, chuyển tư cách rồi mở lại');
      await dongHopSoan();
      if (!(await damBaoTuCach())) throw new LoiDung('đang chuyển sang tư cách ' + CAI_DAT.TEN_TRANG + ' — trang tải lại xong sẽ đăng tiếp');
      dlg = await moHopSoanNhieuDuong((m) => ghi('B1. ' + m));
      await choTenHop(() => hopSoanBai() || dlg);
      ghi('B1. Mở lại hộp soạn: đã đứng tên ' + CAI_DAT.TEN_TRANG);
    }
""")
POST = thay(POST, " — lượt quét sẽ thả bù'", "'")
POST = POST.replace('lượt rà soát sẽ kiểm tra', 'lượt kiểm comment sau sẽ xem lại').replace('lượt rà soát sẽ thử lại', 'lượt kiểm comment sau sẽ xem lại')

API = lay(['fbToken', 'coApi', 'tuCua', 'linkCua', 'doGiong', 'doDaiHop', 'khopBai', 'khopCmt', 'baiGiongNhat', 'goiFbMot', 'goiFb', 'caiMaKhoa', 'kiemMaKhoa',
           'nhacGiaHanMa', 'baiTrenTrangApi', 'cmtChiTietApi', 'cmtCuaBaiApi'])
API = '\n  // =====================================================================\n  //  Facebook Graph API — CHỈ ĐỌC (dùng lại từ bản 5.9)\n  // =====================================================================\n' + API
# (6.19) 3 kênh: mã khoá / mã số trang theo kênh đang làm
API = thay(API, "const coApi = () => !!(fbToken() && CAI_DAT.FB_PAGE_ID);", "const coApi = () => !!(tokenKenh() && CAI_DAT.FB_PAGE_ID);")
API = thay(API, "headers: { Authorization: 'OAuth ' + (token || fbToken()) }", "headers: { Authorization: 'OAuth ' + (token || tokenKenh()) }")
API = thay(API, "        if (pg && pg.access_token) { maTrang = pg.access_token; ghi('Mã dán vào là mã người dùng → đã đổi sang mã của trang ' + pg.name); }",
  "        if (pg && pg.access_token) { maTrang = pg.access_token; ghi('Mã dán vào là mã người dùng → đã đổi sang mã của trang ' + pg.name); }\n        try { if ((acc.data || []).length) { luu('fb_token_nguoi', t); luu('fb_token_nguoi_luc', Date.now()); } const kq = luuMaKenh(acc.data || []); if (kq.length) ghi('Đã lấy thêm mã đọc trang ' + kq.join(', ')); } catch (e2) { /* */ }")
API = thay(API, "      alert(`Đã kết nối: \"${j.name}\".\\nĐọc bài: được · Đọc comment: ${cmtOk === false ? 'CHƯA được (mã khoá thiếu quyền đọc comment)' : 'được'}.`);",
  "      alert(`Đã kết nối: \"${j.name}\".\\nĐọc bài: được · Đọc comment: ${cmtOk === false ? 'CHƯA được (mã khoá thiếu quyền đọc comment)' : 'được'}.\\n\\n${moTaMaKenh()}${[2, 3].some((c) => !coApiKenh(c)) ? '\\n(Kênh chưa đọc được: dán mã NGƯỜI DÙNG của nick quản lý cả 3 trang)' : ''}`);")
API = thay(API, "    const luc = lay('fb_token_luc', 0);\n    if (luc) {", "    kq.push(moTaMaKenh());\n    const luc = lay('fb_token_luc', 0);\n    if (luc) {")
API = thay(API, "const s = trangThaiNgay(homNay()); s.doLuc = 0; s.apiBao = 0; luuNgay(homNay(), s);\n", '')
API = thay(API, "yeuCauViec('dobai');", "yeuCau('dotrang');")
# (6.9) so comment bỏ khối CTA ở cuối (comment cũ chưa có CTA vẫn tính đủ; không gửi bù trùng)
API = thay(API, "  const khopCmt = (msg, text) => {", "  const khopCmt = (msg, text0) => { const text = boCTA(text0);")
API = thay(API, 'await baoLark(`Mã khoá Facebook', 'await baoLoi(`Mã khoá Facebook')
API = thay(API, "— cần đổi mã mới (\"Đổi mã khoá\" trên popup)`);", "— cần đổi mã mới (\"Đổi mã khoá\" ở tab Hệ thống trên popup)`, 'giahan');")


# (6.19.2) mã khoá: luôn làm việc với trang KÊNH 1 (không theo "kênh đang làm" — bấm nút lúc script đang đăng kênh 2 từng làm mã kênh 1 bị thay bằng mã trang kênh 2)
API = thay(API, "        const pg = (acc.data || []).find((x) => x.id === CAI_DAT.FB_PAGE_ID);", "        const pg = (acc.data || []).find((x) => String(x.id) === String(idTrangKenh(1)));")
API = thay(API, "      const j = await goiFb(`/${CAI_DAT.FB_PAGE_ID}?fields=name`, maTrang);",
  """      if (maTrang === t) { // (6.19.2) dán nhầm mã riêng của trang kênh 2/3 → chỉ dùng cho kênh đó, mã kênh 1 giữ nguyên
        try { const me = await goiFb('/me?fields=id,name', t); const c = [2, 3].find((k) => String(me.id) === String(idTrangKenh(k)) || chuanTenTrang(me.name || '') === chuanTenTrang(CAI_DAT.KENH[k].ten));
          if (c) { const ids = Object.assign({}, lay('kenh_id6', {}) || {}); ids[c] = String(me.id); luu('kenh_id6', ids); const ma = Object.assign({}, maCacTrang()); ma[String(me.id)] = t; luu('fb_tok_trang6', ma);
            ghi(`Mã dán vào là mã riêng của trang kênh ${c} "${me.name}" → chỉ dùng cho kênh ${c} (mã kênh 1 giữ nguyên)`); alert(`Đã cài mã cho kênh ${c}: "${me.name}" (mã kênh 1 giữ nguyên).\\n\\n${moTaMaKenh()}`); veBang(); return; } } catch (e) { /* */ }
      }
      const j = await goiFb(`/${idTrangKenh(1)}?fields=name`, maTrang);""")
API = thay(API, "      try { const ps = await goiFb(`/${CAI_DAT.FB_PAGE_ID}/posts?fields=id&limit=1`, maTrang);", "      try { const ps = await goiFb(`/${idTrangKenh(1)}/posts?fields=id&limit=1`, maTrang);")
API = thay(API, "    if (!coApi()) { alert('Chưa cài mã khoá Facebook.'); return; }", "    if (!fbToken()) { alert('Chưa cài mã khoá Facebook.'); return; }\n    const P1 = idTrangKenh(1) || CAI_DAT.KENH[1].pageId, T1 = fbToken(); // (6.19.2) luôn kiểm mã kênh 1")
API = thay(API, "    try { const j = await goiFb(`/${CAI_DAT.FB_PAGE_ID}?fields=name`); kq.push(", "    try { const j = await goiFb(`/${P1}?fields=name`, T1); kq.push(")
API = thay(API, "    try { const ps = await goiFb(`/${CAI_DAT.FB_PAGE_ID}/posts?fields=id&limit=1`); if (ps.data && ps.data[0]) await cmtCuaBaiApi(ps.data[0].id);", "    try { const ps = await goiFb(`/${P1}/posts?fields=id&limit=1`, T1); if (ps.data && ps.data[0]) await goiFb(`/${ps.data[0].id}/comments?fields=message&limit=1`, T1);")

# (6.19.2) gửi bù / comment: ô bình luận đứng tên nick khác → chuyển tư cách trang của bài rồi mở lại bài (trước đây chỉ tải lại 4 lần rồi bỏ)
POST = thay(POST, """    const b = await cho(() => timBai(dd.bai), 25000, 1000);
    if (!b) {
      // (4.5) đếm số lần (không tính giờ): tải lại → mở thẳng link bài → tải lại trang bài → mới chốt""",
"""    if (dd.doiTC && dd.viaLink && (dd.veLink || 0) < 4) { // vừa chuyển tư cách (Facebook đưa về trang chủ) → mở lại đúng bài
      const idL = (String(dd.viaLink).match(/\\/(?:reel|reels|videos|posts)\\/([^/?#]+)/) || [])[1];
      if (idL && !location.pathname.includes(idL)) {
        if (dungTrang() && Date.now() - ((lay('tc_mo_trang6', {}) || {})[CAI_DAT.TEN_NGAN] || 0) < 3 * 60000 && !dd.daChuyenNgay) { dd.daChuyenNgay = true; luu('dang_do', dd); try { if (!(await damBaoTuCach())) return true; } catch (eT) { ghi('Chưa chuyển được tư cách: ' + eT.message); } }
        dd.veLink = (dd.veLink || 0) + 1; luu('dang_do', dd); ghi('Mở lại bài để comment: ' + dd.viaLink); await sleep(800); roiTrang(dd.viaLink); return true;
      }
    }
    window.__smhSaiTuCach = 0;
    const b = await cho(() => timBai(dd.bai), 25000, 1000);
    if (!b) {
      // (6.19.2) ô bình luận đang đứng tên tài khoản khác (vd nick cá nhân, trang kênh khác) → chuyển sang tư cách trang của bài
      if (window.__smhSaiTuCach) {
        if ((dd.doiTC || 0) >= 2) { await hoanTatSlot(dd, [`ô bình luận vẫn đứng tên tài khoản khác, đã thử chuyển sang "${CAI_DAT.TEN_TRANG}" 2 lần chưa được`]); return true; }
        dd.doiTC = (dd.doiTC || 0) + 1; dd.veLink = 0; dd.daChuyenNgay = false; luu('dang_do', dd);
        ghi(`Ô bình luận đang đứng tên tài khoản khác → chuyển sang tư cách "${CAI_DAT.TEN_TRANG}" rồi comment (lần ${dd.doiTC}/2)`);
        let ok = false; try { ok = await damBaoTuCach(); } catch (eT) { ghi('Chưa chuyển được tư cách: ' + eT.message); }
        if (ok) { await sleep(800); if (dd.viaLink) roiTrang(dd.viaLink); else roiTrang(); }
        return true;
      }
      // (4.5) đếm số lần (không tính giờ): tải lại → mở thẳng link bài → tải lại trang bài → mới chốt""")


# (6.19.3) comment ẢNH: trước khi gửi hỏi Facebook xem dưới bài đã đủ ảnh chưa (máy kia / lần trước đã gửi) → không gửi trùng ảnh
POST = thay(POST, "        if (it.k === 'text') await binhLuan(dd.bai, it.v);",
  """        if (it.k === 'anh' && coApi() && dd.id) { let du = false; try { const anhCmts = dd.cmts.filter((x) => x.k === 'anh'); const tong = (dd.anhCoSan != null ? dd.anhCoSan : 0) + anhCmts.length; const conSau = dd.cmts.slice(dd.cmtIdx + 1).filter((x) => x.k === 'anh').length; const co = (await cmtChiTietApi(dd.id)).anh; du = co >= tong - conSau; } catch (e) { /* */ } if (du) { ghi(`Comment ảnh thứ ${dd.cmtIdx + 1}: dưới bài đã đủ ảnh (máy khác / lần trước đã gửi) → không gửi trùng`); dd.cmtIdx++; dd.dangGui = null; luu('dang_do', dd); continue; } }
        if (it.k === 'text') await binhLuan(dd.bai, it.v);""")
API = thay(API, "      luu('fb_token', maTrang); luu('fb_token_luc', Date.now()); luu('fb_token_nhac', 0);", "      luu('fb_token', maTrang); luu('fb_token_luc', Date.now()); luu('fb_token_nhac', 0); luu('fb_hong1', 0); // (6.19.3) dán mã mới → bỏ dấu \"mã hỏng\"")
KH = lay(['dangODuongKhanh', 'moc0Khanh', 'gioKhanh', 'KHANH_LINK_BAI', 'sachLinkKhanh', 'gioTuNeoKhanh', 'idMenuKhanh', 'docKhungKhanh', 'docTrangKhanh',
          'ngayThangKhanh', 'tinKhanh', 'khanhDenHan', 'khanhTuan', 'khanhThuNgay', 'tiepKhanh'])
KH = '\n  // =====================================================================\n  //  Báo cáo tuần Khanh Trầm Hương (chỉ Máy Cao) — dùng lại từ bản 5.9, sửa: bỏ bài ghim / "Đáng chú ý"\n  // =====================================================================\n' + KH
KH = thay(KH, "    for (const { khung, menu } of cacKhungBai()) {\n", "    const neoFeed = neoFeedKhanh();\n    for (const { khung, menu } of cacKhungBai()) {\n      if (laKhungNoiBat(khung, neoFeed)) continue; // (6.0) bài ghim / mục nổi bật: không đếm\n")
KH = thay(KH, "    if (khanhBan() || !trongGioNhan()) return false;\n", "    if (khanhBan() || !trongGioNhan() || dangHoan()) return false;\n    if ((await batDemNguoc('mở trang ' + CAI_DAT.KHANH_TEN + ' (báo cáo tuần)')) !== 'ok') { ghi(`${CAI_DAT.KHANH_TEN}: nhân sự bấm Hoãn → để lượt sau`); return false; }\n")
KH = thay(KH, "if (lay('dang_do', null) || dangBan || dangQuet) {", "if (lay('dang_do', null) || dangBan) {")
KH = thay(KH, "huy('có việc đăng bài/quét đang chạy → nhường, thử lại sau', true)", "huy('có việc đăng bài đang chạy → nhường, thử lại sau', true)")
KH = thay(KH, "const ok = await baoLark('\\n' + nd, { toiDa: 1, loai: 'khanh' });", "const ok = await guiLark('baocao', nd, { khoa: 'khanh_' + kd.t0 });")
KH = thay(KH, "ghi(`${CAI_DAT.KHANH_TEN}: tuần này không đọc được trang sau", "if ((s.lan || 0) > 0) ghi(`${CAI_DAT.KHANH_TEN}: tuần này không đọc được trang sau")

# ---------- phần Gắn vị trí & thẻ: lấy bản Giao (chờ kỹ hơn) ----------
gtxt = '\n'.join(GIAO)
i0 = gtxt.index('  // ===== 2.6: nút "Gắn vị trí & thẻ"')
i1 = gtxt.index("  setInterval(() => { try { ganVe(); } catch (e) { /* */ } }, 1000);")
GAN = gtxt[i0:i1]
# hình thu nhỏ: KHÔNG được bấm nhầm nút "Lưu thước phim làm bản nháp" (chữ cũng là "Lưu") → lấy nút Lưu không phải bản nháp, nằm trên cùng (cuối danh sách)
GAN = thay(GAN, "  const ganNut = (txt) => [...document.querySelectorAll('[role=button],button')].find((b) => ganThay(b) && (chuan(b.innerText) === txt || b.getAttribute('aria-label') === txt));\n",
           "  const ganNut = (txt) => [...document.querySelectorAll('[role=button],button')].find((b) => ganThay(b) && (chuan(b.innerText) === txt || b.getAttribute('aria-label') === txt));\n"
           "  const ganNutLuuAnh = () => { const ds = [...document.querySelectorAll('[role=button],button')].filter((b) => ganThay(b) && !b.closest('#smhfb') && (chuan(b.innerText) === 'Lưu' || b.getAttribute('aria-label') === 'Lưu') && !/nháp/i.test(b.getAttribute('aria-label') || '')); return ds[ds.length - 1] || null; };\n")
GAN = thay(GAN, "await ganCho(() => ganNut('Lưu'), 8000); if (!luuNut)", "await ganCho(() => ganNutLuuAnh(), 8000); if (!luuNut)")
GAN = thay(GAN, "const nutLuu = (luuNut.isConnected && ganThay(luuNut)) ? luuNut : (ganNut('Lưu') || luuNut);", "const nutLuu = (luuNut.isConnected && ganThay(luuNut)) ? luuNut : (ganNutLuuAnh() || luuNut);")
# bấm kiểu cũ: nếu tại điểm giữa nút là thứ khác che (popup của script, khung khác) → bắn sự kiện thẳng vào nút
GAN = thay(GAN, "const t = document.elementFromPoint(x, y) || el; const base", "const t0 = document.elementFromPoint(x, y); const t = t0 && (el.contains(t0) || t0.contains(el)) && !(t0.closest && t0.closest('#smhfb,#smhfb-gan-w')) ? t0 : el; const base")
GAN = thay(GAN, "    const t = t0 && (el.contains(t0) || t0.contains(el)) ? t0 : el;", "    const t = t0 && (el.contains(t0) || t0.contains(el)) && !(t0.closest && t0.closest('#smhfb,#smhfb-gan-w')) ? t0 : el;")
# script đang tự đăng thì ẩn nút "Gắn vị trí & thẻ" (nút này dành cho lúc đăng tay)
GAN = thay(GAN, "    const hien = !!ganManHinh();", "    const hien = !!ganManHinh() && !dangBan;")
# (6.9) màn Cài đặt thước phim bị cuộn xuống sau khi chọn nhóm → nút "Chỉnh sửa" hình thu nhỏ ra ngoài màn hình → cuộn lên / cuộn tới nút rồi mới bấm; vẫn không thấy thì giữ hình mặc định, KHÔNG bỏ cả bài
GAN = thay(GAN, "  async function ganThuNho(bao) {\n    bao('Chỉnh hình thu nhỏ…');\n    const sua = await ganCho(() => ganNut('Chỉnh sửa'), 8000); if (!sua) throw new Error('không thấy nút Chỉnh sửa hình thu nhỏ');\n",
  """  function ganCuonLenDau() { // cuộn mọi khung cuộn trong hộp Cài đặt lên đầu
    let n = 0;
    for (const d of document.querySelectorAll('[role=dialog]')) for (const e of [d, ...d.querySelectorAll('*')]) { if (e.scrollTop > 0 && e.scrollHeight > e.clientHeight + 10) { e.scrollTop = 0; n++; } }
    return n;
  }
  function ganNutKhuat(txt) { // nút có thật nhưng đang nằm ngoài màn hình (bị cuộn khuất) → cuộn tới giữa màn hình
    const ds = [...document.querySelectorAll('[role=button],button')].filter((b) => (chuan(b.innerText) === txt || b.getAttribute('aria-label') === txt) && b.getClientRects().length && getComputedStyle(b).visibility !== 'hidden' && !b.closest('[aria-hidden="true"]') && !b.closest('#smhfb') && b.closest('[role=dialog]'));
    for (const b of ds) { try { b.scrollIntoView({ block: 'center', inline: 'nearest' }); } catch (e) { /* */ } if (ganThay(b)) return b; }
    return null;
  }
  async function ganThuNho(bao) {
    bao('Chỉnh hình thu nhỏ…');
    let sua = await ganCho(() => ganNut('Chỉnh sửa'), 3000, 300);
    if (!sua) { const n = ganCuonLenDau(); if (n) ghi('Gắn thẻ: màn Cài đặt đang bị cuộn xuống → cuộn lên đầu để tìm nút Chỉnh sửa hình thu nhỏ'); await ganCham(700); sua = await ganCho(() => ganNut('Chỉnh sửa') || ganNutKhuat('Chỉnh sửa'), 5000, 300); }
    if (!sua) { await ganCham(1500); sua = ganNut('Chỉnh sửa') || ganNutKhuat('Chỉnh sửa'); }
    if (!sua) { ghi('Gắn thẻ: không thấy nút Chỉnh sửa hình thu nhỏ (đã cuộn tìm) → giữ hình thu nhỏ mặc định của Facebook, đăng tiếp'); return null; }
""")
GAN = thay(GAN, "    const hang = await ganCho(() => ganNutChua('Chia sẻ lên nhóm'), 8000); if (!hang) throw new Error('không thấy mục Chia sẻ lên nhóm');",
  "    const chuaKhuat = () => { const b = [...document.querySelectorAll('[role=button]')].find((x) => chuan(x.innerText).startsWith('Chia sẻ lên nhóm') && x.getClientRects().length && !x.closest('[aria-hidden=\"true\"]') && x.closest('[role=dialog]')); if (b) { try { b.scrollIntoView({ block: 'center' }); } catch (e) { /* */ } } return b && ganThay(b) ? b : null; };\n    let hang = await ganCho(() => ganNutChua('Chia sẻ lên nhóm'), 5000);\n    if (!hang) { hang = await ganCho(() => ganNutChua('Chia sẻ lên nhóm') || chuaKhuat(), 6000, 400); if (hang) ghi('Gắn thẻ: mục Chia sẻ lên nhóm bị cuộn khuất → đã cuộn tới'); }\n    if (!hang) throw new Error('không thấy mục Chia sẻ lên nhóm');")
# (6.11) bộ thẻ theo bài (kho thẻ bốc 8) + gắn từng thẻ chắc hơn: thẻ nào không nhận thì thử lại 3 cách, vẫn không được thì bỏ thẻ đó, gắn tiếp thẻ sau
GAN = thay(GAN, "  const ganDsThe = () => { const v = lay('gan_the', null); return Array.isArray(v) && v.length ? v : GAN.THE; };",
  "  const ganDsThe = () => { if (Array.isArray(window.__smhThe) && window.__smhThe.length) return window.__smhThe; const v = lay('gan_the', null); return Array.isArray(v) && v.length ? v : GAN.THE; };")
GAN = thay(GAN, """    for (const the of dsThe) {
      i++; bao(`Gắn thẻ ${i}/${dsThe.length}…`);
      const o = ganO('Thêm thẻ'); if (!o) throw new Error('mất ô Thêm thẻ ở thẻ ' + i);
      ganGo(o, the); await ganCham(500); ganPhim(o, 'Enter');
      let xong = await ganCho(() => { const x = ganO('Thêm thẻ'); return x && x.value === ''; }, 2000, 150);
      if (!xong) { ganGo(o, the); await ganCham(300); ganPhim(o, ','); xong = await ganCho(() => { const x = ganO('Thêm thẻ'); return x && x.value === ''; }, 2000, 150); }
      if (!xong) throw new Error('thẻ ' + i + ' không được nhận (đã thử Enter và dấu phẩy)');
      await ganCham(350);
    }""", """    let duoc = 0; const hong = [];
    await ganCham(800); // ô thẻ vừa hiện: chờ Facebook sẵn sàng nhận chữ
    for (const the of dsThe) {
      i++; bao(`Gắn thẻ ${i}/${dsThe.length}…`);
      const rong = () => { const x = ganO('Thêm thẻ'); return x && x.value === ''; };
      let xong = false;
      for (let cach = 0; cach < 3 && !xong; cach++) {
        const o = ganO('Thêm thẻ') || (await ganCho(() => ganO('Thêm thẻ'), 4000)); if (!o) throw new Error('mất ô Thêm thẻ ở thẻ ' + i);
        if (cach === 2) { try { ganBamCu(o); } catch (e) { o.click(); } await ganCham(400); ganGan(o, ''); await ganCham(200); ganGan(o, the); } // cách 3: bấm vào ô, gán chữ trực tiếp
        else { if (cach) { ganGan(o, ''); await ganCham(300); } ganGo(o, the); }
        await ganCham(cach ? 800 : 500); ganPhim(o, cach === 1 ? ',' : 'Enter');
        xong = await ganCho(rong, cach ? 3000 : 2000, 150);
      }
      if (!xong) { hong.push(i); const o = ganO('Thêm thẻ'); if (o) { ganGan(o, ''); await ganCham(300); } ghi(`Gắn thẻ: thẻ ${i} («${String(the).slice(0, 40)}») không được nhận sau 3 cách → bỏ thẻ này, gắn tiếp thẻ sau`); }
      else duoc++;
      await ganCham(350);
    }
    if (!duoc) throw new Error('không gắn được thẻ nào (' + dsThe.length + ' thẻ đều không được nhận)');
    if (hong.length) ghi(`Gắn thẻ: đã gắn ${duoc}/${dsThe.length} thẻ (bỏ thẻ ${hong.join(', ')})`);
    window.__smhTheDuoc = duoc;""")
GAN = '\n' + GAN

ctxt = '\n'.join(CAO)
def khoang(bd, kt):
    i = ctxt.index(bd); j = ctxt.index(kt, i) + len(kt); return ctxt[i:j]
CSSOLD = '  ' + khoang('function taoCSS(Z) {', '\n  `;\n  }') + '\n  ' + khoang('const CSS_THEM = `', '`;') + '\n'
UIOLD = CSSOLD + lay(['CO_CHU_MAC_DINH', 'coChu', 'vt', 'uiTab', 'rongKhung', 'viTriMacDinh', 'datViTri', 'fbToi', 'linkHoaKhanh', 'tabKhanh'])
UIOLD = '\n  // ===== giao diện bản 5.9 (dùng lại nguyên: màu, khung, kéo thả, tab Khanh TH) =====\n' + UIOLD
# (6.11) sửa thước phim sau khi đăng: gắn thẻ Trang Sơn Mộc Hương + cảm xúc (dùng lại từ bản 5.9)
SUA = lay(['khungKhop', 'idVideo', 'khungKhopP', 'dauBai', 'baiDaGan', 'chipsSua', 'daGanThe', 'chuaCamXuc', 'moManHinhSua', 'ganTheSuaMot', 'ganTheSua', 'camXucSua'])
# (6.24) trang mới: menu ⋯ → "Chỉnh sửa bài viết" mở hộp kiểu mới (Tiếp → Lưu) thay cho màn "Chỉnh sửa thước phim"
SUA = thay(SUA, "hopSua() || (!dungTrang() && !dangODuongSua() ? 'roi' : null), 10000, 400)", "hopSua() || hopSuaMoi() || (!dungTrang() && !dangODuongSua() ? 'roi' : null), 10000, 400)", 2)
SUA = thay(SUA, "    if (!d) throw new Error('không mở được màn hình chỉnh sửa');\n", "    if (!d) { if (hopSuaMoi() || hopCaiDatMoi()) await dongHopMoi(); throw new Error('không mở được màn hình chỉnh sửa'); }\n    if (laHopMoi(d)) { ghi('Mở sửa bài: Facebook hiện hộp \"Chỉnh sửa bài viết\" kiểu mới (Tiếp → Lưu)'); return d; }\n")

SUA = thay(SUA, "const khungKhop = (k, text) => { const kk = chuan(text).slice(0, 40); if (!kk) return false; if (chuan(k.khung.innerText).includes(kk)) return true; const k2 = khoaSo(text).slice(0, 35); return k2.length >= 12 && khoaSo(k.khung.innerText).includes(k2); };",
  "const khungKhop = (k, text) => { // (6.20.2) so chặt từ đầu chú thích bài (xem soChat)\n    const a = khoaSo(text); if (a.length < 8) return false; const b = khoaSo(k.khung.innerText); const dau = a.slice(0, Math.min(20, a.length)); let tot = 0;\n    for (let i = b.indexOf(dau); i >= 0; i = b.indexOf(dau, i + 1)) { const doan = b.slice(i, i + a.length + 12); const cat = /(xemthêm|xemthem|seemore)/.exec(doan); const r = cat ? soChat(text, doan.slice(0, cat.index) + 'xemthêm', true) : soChat(text, b.slice(i, i + a.length)); if (r.ok) return true; tot = Math.max(tot, r.trung); }\n    if (tot >= 20) ghiNaNa(dauBai0(text), tot, 'trên trang'); return false; };")
SUA = '\n  // ===== sửa thước phim sau khi đăng: thẻ + cảm xúc (dùng lại từ bản 5.9) =====\n' + SUA
parts = [phan('p1_dau.js'), phan('p0_larkweb.js'), phan('p2_lark.js'), phan('p13_kenh.js'), phan('p3_sheet.js'), A, API, POST, phan('p5_kho.js'), MF, phan('p6_core.js'), GAN, SUA, phan('p16_suamoi.js'),
         phan('p7_khanh_them.js'), KH, phan('p8_nhip.js'), UIOLD, phan('p9_ui.js'), phan('p11_tunang.js'), phan('p12_thunap.js'), phan('p15_chiso.js'), phan('p10_cuoi.js')]
out = '\n'.join(p.rstrip('\n') for p in parts) + '\n'
import json
BM = json.load(open(os.path.join(D, 'bimat.json'), encoding='utf-8'))
LINK_CN = open(os.path.join(D, 'link_cap_nhat.txt'), encoding='utf-8').read().strip() if os.path.exists(os.path.join(D, 'link_cap_nhat.txt')) else 'https://raw.githubusercontent.com/phanbacao/smh-dang-bai-fb/main/smh.user.js'
assert out.count('/*LINK_CAP_NHAT*/') == 3
out = thay(out, "throw new Error('đã Lưu nhưng trên bài vẫn còn ảnh'); } } }", "ghi('Sửa nền: đã Lưu, hộp sửa đã đóng — bài vẫn hiện ảnh (Facebook vẫn giữ ảnh khi có nền, bình thường) → coi như xong'); return; } } }") # (6.20.5)
out = thay(out, "&& (dd.taiLaiTong || 0) < 8) {", "&& (dd.taiLaiTong || 0) < 3) { // (6.20.5) comment: thử tối đa 3 lần rồi bỏ qua, không thử lại")
out = thay(out, "  async function damBaoTuCach() {\n    kiemDung();\n", """  async function damBaoTuCach() {
    kiemDung();
    { // (6.20.9) Facebook đang mở hộp xác nhận "Chuyển trang cá nhân" (từ lần bấm trước) → bấm "Chuyển" nếu đúng trang cần sang, sai trang thì đóng
      const hx = hopThoai((d) => /Chuyển trang cá nhân/.test(d.innerText || ''));
      if (hx) {
        const dung = chuanTen(hx.innerText || '').includes(chuanTen(CAI_DAT.TEN_TRANG));
        const nutX = Array.from(hx.querySelectorAll('[role="button"],button')).find((b) => dangHien(b) && (dung ? /^(Chuyển|Chuyển ngay|Switch)$/i.test(chuan(b.innerText || b.getAttribute('aria-label') || '')) || chuanTen(b.getAttribute('aria-label') || '') === chuanTen('Chuyển sang ' + CAI_DAT.TEN_TRANG) : /^(Hủy|Huỷ|Đóng|Cancel)$/i.test(chuan(b.innerText || b.getAttribute('aria-label') || ''))));
        ghi(dung ? `Thấy hộp xác nhận "Chuyển trang cá nhân" sang "${CAI_DAT.TEN_TRANG}" → ${nutX ? 'bấm Chuyển' : 'chưa thấy nút Chuyển'}` : 'Thấy hộp "Chuyển trang cá nhân" của trang khác → đóng');
        if (nutX) { try { ganBam(nutX); } catch (e) { nutX.click(); } if (dung) { await cho(() => document.readyState === 'loading' || !document.contains(nutX), 10000, 400); return false; } await sleep(800); }
      }
    }
""")
out = thay(out, "        const dung = chuanTen(hx.innerText || '').includes(chuanTen(CAI_DAT.TEN_TRANG));", "        const dung = chuaTenTrang(hx.innerText || ''); // (6.21)")
out = thay(out, "if (tenOCmt && tenOCmt.startsWith(chuan('Bình luận dưới tên ' + CAI_DAT.TEN_TRANG))) {", "if (tenOCmt && chuanTen(tenOCmt.replace(/^Bình luận dưới tên\\s*/, '')) === chuanTen(CAI_DAT.TEN_TRANG)) { // (6.21) so cả dấu chấm cuối")
out = thay(out, "    const dungTen = chuanTen(ten) === chuanTen(CAI_DAT.TEN_TRANG);", "    let dungTen = chuanTen(ten) === chuanTen(CAI_DAT.TEN_TRANG);\n    if (dungTen && kenhHT().moi) { const uid = (document.documentElement.innerHTML.match(/\"userID\":\"(\\d+)\"/) || [])[1]; if (uid === '61590895435527') { dungTen = false; ghi('Tên giống kênh 1 mới nhưng Facebook đang dùng tư cách kênh 1 CŨ → chuyển'); } } // (6.21)")
out = thay(out, "    let b = await cho(() => timBai(text), 15000);\n", "    let b = await cho(() => timBai(text), 10000);\n    if (!b && Array.from(document.querySelectorAll('[role=\"progressbar\"],[aria-label^=\"Đang tải\"],[aria-busy=\"true\"]')).some((x) => { const r = x.getBoundingClientRect(); return r.width > 0 && r.height > 0; })) throw new LoiChuaGui('khu comment cứ hiện 3 chấm đang tải (quá 10 giây) → tải lại trang thử lại'); // (6.22)\n    if (!b) b = await cho(() => timBai(text), 5000);\n")
# (6.23) sửa nền đỏ: hộp "Chỉnh sửa bài viết" kiểu mới có 2 bước Tiếp → Cài đặt bài viết → Lưu (đã thử trực tiếp trên trang kênh 1 mới)
out = thay(out, "const nl = await thuLai(luuNut, 8000); if (!nl) throw new Error('không thấy nút Lưu');",
  "const luuNut2 = () => luuNut() || Array.from(document.querySelectorAll('[role=\"dialog\"]')).filter((d) => dangHien(d) && /Cài đặt bài viết/.test(d.innerText)).map((d) => Array.from(d.querySelectorAll('[role=\"button\"],[aria-label=\"Lưu\"]')).find((x) => dangHien(x) && (chuan(x.innerText) === 'Lưu' || x.getAttribute('aria-label') === 'Lưu') && x.getAttribute('aria-disabled') !== 'true')).find(Boolean);\n"
  "    const nutTiep = () => Array.from(hop.querySelectorAll('[aria-label=\"Tiếp\"],[role=\"button\"]')).find((x) => dangHien(x) && (x.getAttribute('aria-label') === 'Tiếp' || chuan(x.innerText) === 'Tiếp') && x.getAttribute('aria-disabled') !== 'true');\n"
  "    const hopMo = () => (hop.isConnected && dangHien(hop)) || Array.from(document.querySelectorAll('[role=\"dialog\"]')).some((d) => dangHien(d) && /Cài đặt bài viết/.test(d.innerText));\n"
  "    let nl = await thuLai(() => luuNut2() || nutTiep(), 8000);\n"
  "    if (nl && !luuNut2()) { ganBam(nl); ghi('Sửa nền: hộp sửa kiểu mới → đã bấm Tiếp, chờ màn Cài đặt bài viết'); nl = await thuLai(luuNut2, 12000); }\n"
  "    if (!nl) throw new Error('không thấy nút Lưu (cả kiểu cũ lẫn kiểu Tiếp → Lưu)');")
out = thay(out, "if (!(await cho(() => !hop.isConnected || !dangHien(hop), 15000))) { // (4.5)", "if (!(await cho(() => !hopMo(), 15000))) { // (4.5)")
out = thay(out, "const nl2 = luuNut(); if (nl2) { ghi('Sửa nền: bấm Lưu lần 1 chưa ăn → bấm lại'); nl2.click(); }", "const nl2 = luuNut2(); if (nl2) { ghi('Sửa nền: bấm Lưu lần 1 chưa ăn → bấm lại'); nl2.click(); }")
out = thay(out, "if (!(await cho(() => !hop.isConnected || !dangHien(hop), 20000))) throw new Error('bấm Lưu nhưng hộp chưa đóng');", "if (!(await cho(() => !hopMo(), 20000))) throw new Error('bấm Lưu nhưng hộp chưa đóng');")
out = thay(out, "const x = h.querySelector('[aria-label=\"Đóng\"]'); if (x) ganBam(x);",
  "const cd = Array.from(document.querySelectorAll('[role=\"dialog\"]')).find((d) => dangHien(d) && /Cài đặt bài viết/.test(d.innerText)); const ql = cd && cd.querySelector('[aria-label=\"Quay lại\"]'); if (ql) ql.click(); const dong = () => { const x = h.querySelector('[aria-label=\"Đóng\"],[aria-label=\"Đóng hộp thoại của công cụ tạo\"]'); if (x) ganBam(x); }; if (ql) setTimeout(dong, 900); else dong();")
# (6.24) đo thời gian sửa nền đỏ (ngưỡng 60 giây)
out = thay(out, "        try { await suaNenDo(b); }\n", "        try { const t0n = Date.now(); try { await suaNenDo(b); } finally { const gn = Math.round((Date.now() - t0n) / 1000); ghi(`⏱ Sửa nền đỏ: ${gn} giây`); if (gn > NGUONG_GIAY.suanen) ghiCham('Sửa nền đỏ ' + (dd.ten || ''), gn, NGUONG_GIAY.suanen); } }\n")
# (6.24) Lịch hôm nay: trái 60% / phải 40%, bài đã đăng gọn 1 dòng, bài kế tiếp nổi bật, nhiều bài thì thu nhỏ
out = thay(out, "  #smhfb .viec .vr.dau{border-top:0}", "  #smhfb .viec .vr.dau{border-top:0}\n  #smhfb .bthieu{border-collapse:collapse;margin-top:${p(6)};font-size:${p(13)};width:100%}\n  #smhfb .bthieu th,#smhfb .bthieu td{border:1px solid var(--vien);padding:${p(4)} ${p(8)};text-align:center}\n  #smhfb .bthieu th{font-weight:700;color:var(--phu)}\n  #smhfb .bthieu .bt-k{text-align:left;font-weight:700}\n  #smhfb .bthieu .bt-du{color:#2e9e4f;font-weight:700;background:#2e9e4f14}\n  #smhfb .bthieu .bt-thieu{color:#e5484d;font-weight:800;background:#e5484d1a;cursor:help}\n  #smhfb .bthieu .bt-ct{font-size:${p(11)};font-weight:500;opacity:.85}\n  #smhfb .bthieu .bt-x{color:var(--phu)}")
out = thay(out, "#smhfb .tlay{display:grid;grid-template-columns:${p(400)} minmax(0,1fr);gap:${p(16)};align-items:start}",
  "#smhfb .tlay{display:grid;grid-template-columns:minmax(0,3fr) minmax(0,2fr);gap:${p(16)};align-items:start}\n"
  "  #smhfb .it.gon{padding:${p(3)} ${p(34)} ${p(4)} ${p(44)}}#smhfb .it.gon:before{display:none}#smhfb .it.gon .dm{width:${p(22)};height:${p(22)};font-size:${p(11)};top:${p(4)};left:${p(12)}}#smhfb .it.gon .h{font-size:${p(13.5)};font-weight:700;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}#smhfb .it.gon .h .t{font-weight:400;font-size:${p(12)}}#smhfb .it.gon .tk{top:${p(3)};text-decoration:none;padding:0 ${p(6)};border-radius:99px}\n"
  "  #smhfb .tl-moc{margin:${p(8)} ${p(8)} ${p(4)};font-size:${p(11.5)};font-weight:800;color:var(--phu);text-transform:uppercase;letter-spacing:.6px;border-top:1px dashed var(--vien);padding-top:${p(6)}}\n"
  "  #smhfb .it.ketiep{background:var(--the);border-color:#e0a21a}#smhfb .it.ketiep:before{display:none}#smhfb .it.ketiep .h{font-size:${p(17)}}\n"
  "  #smhfb .tl.nho .it:not(.gon){padding-top:${p(4)};padding-bottom:${p(8)}}#smhfb .tl.nho .it:not(.gon) .h{font-size:${p(14)}}#smhfb .tl.nho .it:not(.gon) .t{font-size:${p(12)}}#smhfb .tl.nho .it .dm{width:${p(28)};height:${p(28)}}#smhfb .tl.nho .it:before{top:${p(34)}}")
# (6.26) dán mã riêng của trang: nhận cả kênh Hà Xá
out = thay(out, "const c = [2, 3].find((k) => String(me.id) === String(idTrangKenh(k))", "const c = KENH_PHU.find((k) => String(me.id) === String(idTrangKenh(k))")
out = thay(out, "${[2, 3].some((c) => !coApiKenh(c)) ? '\\n(Kênh chưa đọc", "${KENH_PHU.some((c) => !coApiKenh(c)) ? '\\n(Kênh chưa đọc")
# (6.26.1) bấm "Chuyển" trên trang xong, Facebook hỏi lại hộp "Chuyển trang cá nhân" → phải bấm "Chuyển" trong hộp (trước đây bỏ qua → treo ở bước đổi tư cách)
out = thay(out, "  async function damBaoTuCach(", '''  async function xacNhanChuyen(cho0 = 6000) {
    const timNut = () => { const d = Array.from(document.querySelectorAll('[role="dialog"]')).find((x) => dangHien(x) && /Chuyển trang cá nhân|Switch profiles?/i.test(x.innerText || '')); return d && Array.from(d.querySelectorAll('[role="button"],button')).find((b) => /^(Chuyển|Switch)$/i.test(chuan(b.innerText || b.getAttribute('aria-label') || '')) && dangHien(b)); };
    const n = await cho(timNut, cho0, 300); if (!n) return false;
    ghi('Facebook hỏi "Chuyển trang cá nhân" → bấm Chuyển'); try { ganBam(n); } catch (e) { n.click(); }
    await cho(() => !timNut(), 8000, 400); return true;
  }
  async function damBaoTuCach(''')
out = thay(out, "    if (cachKhac) { try { ganBam(nut); } catch (e) { nut.click(); } } else nut.click();\n", "    if (cachKhac) { try { ganBam(nut); } catch (e) { nut.click(); } } else nut.click();\n    if (await xacNhanChuyen(3000)) return false; // (6.26.1) Facebook hỏi lại «Chuyển trang cá nhân»\n")
# (6.26.2) menu tài khoản: trang không nằm trong 2 mục chuyển nhanh → "Xem tất cả trang cá nhân" (nút chỉ có aria-label, không có chữ) → danh sách "Chọn trang cá nhân" (nút aria-label "Tên trang, N thông báo")
out = thay(out, "    const timNutChuyen = () => Array.from(document.querySelectorAll('[aria-label^=\"Chuyển sang\"]')).find((e) => chuanTen(e.getAttribute('aria-label')) === chuanTen('Chuyển sang ' + CAI_DAT.TEN_TRANG));",
  "    const timNutChuyen = () => Array.from(document.querySelectorAll('[aria-label^=\"Chuyển sang\"]')).find((e) => chuanTen(e.getAttribute('aria-label')) === chuanTen('Chuyển sang ' + CAI_DAT.TEN_TRANG))\n      || Array.from(document.querySelectorAll('[role=\"dialog\"] [role=\"button\"][aria-label]')).find((e) => dangHien(e) && /Chọn trang cá nhân|Chọn một mục/.test((e.closest('[role=\"dialog\"]') || {}).innerText || '') && chuanTen(String(e.getAttribute('aria-label')).replace(/,\\s*[\\d.]+\\+?\\s*thông báo.*$/i, '')) === chuanTen(CAI_DAT.TEN_TRANG)); // (6.26.2)")
out = thay(out, "      const xem = Array.from(menu.querySelectorAll('[role=\"button\"], a')).find((b) => /^Xem tất cả trang cá nhân/.test(chuan(b.innerText)));\n      if (xem) { xem.click(); nut = await cho(timNutChuyen, 6000, 400); }",
  "      const xem = Array.from(document.querySelectorAll('[role=\"button\"], a')).find((b) => /^Xem tất cả trang cá nhân/.test(chuan(b.innerText || '') || chuan(b.getAttribute('aria-label') || '')) && dangHien(b)); // (6.26.2) nút chỉ có aria-label\n      if (xem) { ghi('Menu chuyển nhanh không có \"' + CAI_DAT.TEN_TRANG + '\" → mở \"Xem tất cả trang cá nhân\"'); try { xem.click(); } catch (e) { /* */ } nut = await cho(timNutChuyen, 6000, 400); if (!nut) { try { ganBam(xem); } catch (e) { /* */ } nut = await cho(timNutChuyen, 6000, 400); } ghi(nut ? 'Đã thấy \"' + CAI_DAT.TEN_TRANG + '\" trong danh sách trang cá nhân' : 'Danh sách trang cá nhân không có \"' + CAI_DAT.TEN_TRANG + '\"'); }\n      else ghi('Menu tài khoản không có nút \"Xem tất cả trang cá nhân\"');")
# (6.26.4) bài viết: máy này đã giữ chỗ → đọc lại ô giữ chỗ ngay trước khi bấm Đăng
out = thay(out, "      if (trung) throw new LoiTrung('Phát hiện bài đã có ngay trước khi Đăng — không bấm Đăng', trung);\n    }", "      if (trung) throw new LoiTrung('Phát hiện bài đã có ngay trước khi Đăng — không bấm Đăng', trung);\n    }\n    if (bai.ddThem && bai.ddThem.slot) await kiemKhoaTruocDang(bai.ddThem.slot); // (6.26.4)")
# (6.26.5) trang chưa tham gia nhóm nào: hộp "Chia sẻ lên nhóm" hiện "Không tìm thấy nhóm nào" → bấm Xong, bỏ qua bước nhóm, vẫn đăng; nhớ 3 ngày để lần sau khỏi mở
out = thay(out, "    if (!hang) throw new Error('không thấy mục Chia sẻ lên nhóm');\n    const timDs = () =>",
  "    if (!hang) throw new Error('không thấy mục Chia sẻ lên nhóm');\n    const nhomTrong = () => [...document.querySelectorAll('[role=dialog]')].find((d) => ganThay(d) && /Không tìm thấy nhóm nào|No groups found/i.test(d.innerText || ''));\n    { const kn = lay('khong_nhom6', {}) || {}; if (kn[CAI_DAT.TEN_TRANG] && Date.now() - kn[CAI_DAT.TEN_TRANG] < 3 * 864e5) { ghi(`Gắn thẻ: trang ${CAI_DAT.TEN_NGAN} chưa tham gia nhóm nào → bỏ qua bước chọn nhóm`); return { moi: 0, tong: 0, trong: true }; } }\n    const timDs = () =>")
out = thay(out, "      ds = await ganCho(timDs, i === 0 ? 8000 : 5000);\n    }\n    if (!ds) throw new Error('không thấy danh sách nhóm');",
  """      ds = await ganCho(() => timDs() || (nhomTrong() ? 'trong' : null), i === 0 ? 8000 : 5000);
    }
    if (ds === 'trong' || (!ds && nhomTrong())) { // (6.26.5)
      ghi(`Gắn thẻ: trang ${CAI_DAT.TEN_NGAN} chưa tham gia nhóm nào ("Không tìm thấy nhóm nào") → bỏ qua bước nhóm, vẫn đăng`);
      luu('khong_nhom6', Object.assign({}, lay('khong_nhom6', {}) || {}, { [CAI_DAT.TEN_TRANG]: Date.now() }));
      for (let lan = 0; lan < 3 && nhomTrong(); lan++) { const d = nhomTrong(); const n = [...d.querySelectorAll('[role=button],button')].find((b) => /^(Xong|Done)$/i.test(chuan(b.innerText || b.getAttribute('aria-label') || '')) && ganThay(b)) || [...d.querySelectorAll('[aria-label="Quay lại"],[aria-label="Back"]')].find(ganThay); if (n) { if (lan) { try { ganBam(n); } catch (e) { n.click(); } } else ganBamCu(n); } else document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', code: 'Escape', keyCode: 27, which: 27, bubbles: true })); await ganCham(1200); }
      return { moi: 0, tong: 0, trong: true };
    }
    if (!ds) throw new Error('không thấy danh sách nhóm');""")

# (6.26.6) sửa nền đỏ: 2 kiểu màn sửa (kênh 1 mới: hộp nổi; kênh 1 cũ: màn toàn trang /post/edit/)
_i = out.index('  async function suaNenDo(b) {'); _j = out.index('  async function lenLaiCmtThieu(dd) {')
out = out[:_i] + open('p17_suanen.js', encoding='utf-8').read() + out[_j:]
out = thay(out, "    datKenh(kenhCua(dd.slot)); // (6.19) việc dở thuộc kênh nào", "    if (await suaNenSauTaiLai(dd)) return true; // (6.26.6)\n    datKenh(kenhCua(dd.slot)); // (6.19) việc dở thuộc kênh nào")
out = thay(out, "    const sua = dangODuongSua();\n", "    const sua = dangODuongSua();\n    if (Date.now() - (window.__smhMoSua || 0) < 4 * 60000 || (sua && Date.now() - ((lay('suanen_url6', null) || {}).t || 0) < 3 * 60000)) { window.__smhNguoi = null; return false; } // (6.26.6) màn sửa do script mở (sửa nền đỏ)\n")
# (6.26.6) mọi đếm ngược 3 giây
out = out.replace('đếm ngược 10 giây', 'đếm ngược 3 giây')
out = thay(out, "    giay = giay || CAI_DAT.DEM_NGUOC_GIAY;\n", "    giay = 3; // (6.26.6) mọi đếm ngược của script: 3 giây\n")
# (6.26.6) ô bình luận tìm được → cập nhật dòng "Tư cách Facebook" trên bảng theo tên ô bình luận (không để tên cũ của lần kiểm trước)
out = thay(out, "          if (p.querySelectorAll('div[contenteditable=\"true\"][aria-label^=\"Bình luận\"]').length === 1) return { ed, khung: p };", "          if (p.querySelectorAll('div[contenteditable=\"true\"][aria-label^=\"Bình luận\"]').length === 1) { ghiTuCachO(ed); return { ed, khung: p }; }")
out = thay(out, "  function timBai(text) {\n", "  function ghiTuCachO(ed) { try { const m = chuan(ed.getAttribute('aria-label') || '').match(/dưới tên (.+)$/); if (!m || Date.now() - (window.__smhTcO || 0) < 30000) return; window.__smhTcO = Date.now(); capNhat('suc_khoe', { tuCach: m[1] + ' (ô bình luận)', tuCachLuc: Date.now(), tuCachDung: chuanTen(m[1]) === chuanTen(CAI_DAT.TEN_TRANG) }); } catch (e) { /* */ } }\n  function timBai(text) {\n")

# (6.26.7) ghi cột G tab Bài viết kênh 1
out = thay(out, "  async function ghiKetQuaVideoNgay(dd, laThuLai) {", open('p18_them.js', encoding='utf-8').read() + "  async function ghiKetQuaVideoNgay(dd, laThuLai) {")
out = thay(out, "      await ghiGomKetQua().catch((e) => ghi('Ghi gom kết quả lỗi: ' + e.message)); // (6.20.8)", "      await ghiGomKetQua().catch((e) => ghi('Ghi gom kết quả lỗi: ' + e.message)); // (6.20.8)\n      await ghiTTBai().catch((e) => ghi('Ghi trạng thái tab Bài viết kênh 1 lỗi: ' + e.message)); // (6.26.7)")
# (6.26.7) không comment khi màn sửa bài (sửa nền đỏ) còn mở — đóng hẳn trước
out = thay(out, "    // trang vừa tải lại giữa lúc đang gửi 1 comment", "    { const conSua = () => !!(gocSuaNen() || hopCaiDatNen() || dangODuongSua()); // (6.26.7) sửa nền và comment không bao giờ chạy chồng nhau\n      if (conSua()) { ghi('Màn sửa bài còn mở → đóng hẳn trước khi comment'); dongHopSua(); await cho(() => !conSua(), 12000, 500); if (conSua()) { ghi('Chưa đóng được màn sửa bài → tải lại trang rồi mới comment'); luu('dang_do', dd); roiTrang(); return true; } await sleep(1500); } }\n    // trang vừa tải lại giữa lúc đang gửi 1 comment")
# (6.26.7) Hà Xá gắn thẻ chính trang mình: Facebook không hiện thẻ tự gắn trên bài → đã Lưu 1 lần + có cảm xúc là xong (hết vòng làm lại 4 lần)
out = thay(out, "        if (dg.du || (laKenhPhu && dg.cx)) {", "        const tuGan = !laKenhPhu && (it.kenh || 1) > 1 && chuanTen(CAI_DAT.TAG_TEN) === chuanTen(CAI_DAT.TEN_TRANG);\n        if (dg.du || ((laKenhPhu || (tuGan && r.suaDaLuu)) && dg.cx)) {")
# (6.26.7) thẻ video: 2 thẻ đầu đều không nhận → bỏ các thẻ còn lại (đỡ mất 2 phút)
out = thay(out, "      i++; bao(`Gắn thẻ ${i}/${dsThe.length}…`);", "      if (!duoc && hong.length >= 2) { ghi(`Gắn thẻ: 2 thẻ đầu đều không được nhận → bỏ ${dsThe.length - 2} thẻ còn lại cho nhanh`); break; }\n      i++; bao(`Gắn thẻ ${i}/${dsThe.length}…`);")
# (6.26.7) vừa chuyển tư cách (trang tải lại) → làm tiếp đúng bài đang làm, không nhảy sang bài khác rồi chuyển tư cách lần nữa
out = thay(out, "    ghi(`Bắt đầu ${thu ? 'soạn' : 'đăng'} ${it.ten}", "    if (!mai) luu('dang_tiep6', { k: it.k, t: Date.now() });\n    ghi(`Bắt đầu ${thu ? 'soạn' : 'đăng'} ${it.ten}")
out = thay(out, "    if (!it.den) it.den = Date.now();\n", "    { const tp = lay('dang_tiep6', null); if (!epIt && tp && Date.now() - (tp.t || 0) < 6 * 60000 && tp.k !== it.k) { const x = L.find((y) => y.k === tp.k && sanSang(y) && Date.now() >= Math.max(lucPhut(y.gioKH), lucBuKenh(L, y))); if (x) { if (!window['__tiep_' + x.k]) { window['__tiep_' + x.k] = 1; ghi(`Làm tiếp ${x.ten} (vừa chuyển tư cách cho bài này) trước ${it.ten}`); } it = Object.assign({}, x, { den: Math.max(lucPhut(x.gioKH), lucBuKenh(L, x)) }); } } }\n    if (!it.den) it.den = Date.now();\n")

exec(open(os.path.join(D, 'vu6268.py'), encoding='utf-8').read())  # (6.26.8)
exec(open(os.path.join(D, 'vu6269.py'), encoding='utf-8').read())  # (6.26.9)
exec(open(os.path.join(D, 'vu628.py'), encoding='utf-8').read())  # (6.28)
exec(open(os.path.join(D, 'vu6286.py'), encoding='utf-8').read())  # (6.28.6)
exec(open(os.path.join(D, 'vu6324.py'), encoding='utf-8').read())  # (6.32.4)
exec(open(os.path.join(D, 'vu634.py'), encoding='utf-8').read())  # (6.34) kênh 5 page phụ (GitHub)
exec(open(os.path.join(D, 'vu6342.py'), encoding='utf-8').read())  # (6.34.2) timBai đoạn đầu ngắn
exec(open(os.path.join(D, 'vu635.py'), encoding='utf-8').read())  # (6.35) tự trả lời bình luận page phụ
exec(open(os.path.join(D, 'vu636.py'), encoding='utf-8').read())  # (6.36) bình luận đầu page phụ
exec(open(os.path.join(D, 'vu637.py'), encoding='utf-8').read())  # (6.37) sửa vòng lặp /people, page phụ đúng giờ, canh nick
out = out.replace('/*LINK_CAP_NHAT*/', LINK_CN)
# (6.28.1) @version luôn = PHIEN_BAN → Tampermonkey thấy bản mới và tự cập nhật (trước đây kẹt ở 6.22); @name giữ nguyên
_pb = re.search(r"const PHIEN_BAN = '([\d.]+)'", out).group(1)
out, _n = re.subn(r'^// @version +\S+$', '// @version      ' + _pb, out, count=1, flags=re.M)
assert _n == 1, '@version'
CHO = {'/*BM_HOOK_BC*/': 'hookBaoCao', '/*BM_HOOK_LOI*/': 'hookLoi', '/*BM_APP_ID*/': 'appId', '/*BM_APP_SECRET*/': 'appSecret'}
rieng, congkhai = out, out
for k, v in CHO.items():
    assert out.count(k) == 1, k
    rieng = rieng.replace(k, BM[v]); congkhai = congkhai.replace(k, '')
for v in BM.values():
    assert v not in congkhai, 'LỘ MÃ BÍ MẬT trong bản công khai'
dst = sys.argv[1] if len(sys.argv) > 1 else os.path.join(D, 'smh6.user.js')
open(dst, 'w', encoding='utf-8').write(rieng)
open(os.path.join(D, 'smh6.public.user.js'), 'w', encoding='utf-8').write(congkhai)
print('Đã ghép', dst, len(out.split('\n')), 'dòng', len(out.encode()) // 1024, 'KB (bản riêng + bản công khai không mã bí mật)')
