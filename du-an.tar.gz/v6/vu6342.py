# (6.34.2) timBai: bài có đoạn đầu ngắn (VD "Trầm Hương Mỗi Ngày – mỗi ngày một chút trầm.") bị Facebook cắt "… Xem thêm" ngay sau đoạn đầu
# → khoá tìm 60 ký tự không khớp, script tưởng bài chưa lên. Nay: nếu đoạn (dòng) đầu ngắn hơn khoá thì chỉ dùng đoạn đầu (≥ 18 ký tự).
out = thay(out, "    const khoa = chuan(text).slice(0, 60);\n    const khoa2 = khoaSo(text).slice(0, 45);",
"""    const _d1 = chuan(String(text || '').split('\\n').map((x) => x.trim()).find((x) => x) || '');
    const _kd = _d1.length >= 18 && _d1.length < 60 ? _d1 : '';
    const khoa = _kd || chuan(text).slice(0, 60);
    const khoa2 = (_kd ? khoaSo(_kd) : khoaSo(text)).slice(0, 45);""")
