
  // =====================================================================
  //  (6.16) TỰ NÂNG CẤP
  //  · gom lỗi + thống kê từng việc → ghi báo cáo kỹ thuật lên Lark sheet (Z5 Máy Giao / Z6 Máy Cao) để Claude đọc mỗi tối
  //  · tự điều chỉnh việc lặp lại mà không có kết quả (giữ mức tối thiểu)
  //  · Máy Cao: nút "🛟 Báo lỗi này cho Claude" + chip "🆕 Bản mới chờ duyệt" (✅ Duyệt → ô Z7)
  //  · nạp mã bí mật (mã Lark, nhóm Lark) — file công khai không chứa mã
  // =====================================================================
  const coBiMat = () => !!(CAI_DAT.LARK_APP_ID && CAI_DAT.LARK_APP_SECRET && CAI_DAT.WEBHOOK_LOI);
  // bản cài tay lần đầu (có sẵn mã) → tự cất mã vào máy, để các bản tự cập nhật sau (không chứa mã) vẫn chạy được
  try { if (!lay('bimat6', null) && coBiMat() && CAI_DAT.WEBHOOK_BAO_CAO) luu('bimat6', { appId: CAI_DAT.LARK_APP_ID, appSecret: CAI_DAT.LARK_APP_SECRET, hookLoi: CAI_DAT.WEBHOOK_LOI, hookBaoCao: CAI_DAT.WEBHOOK_BAO_CAO, luc: Date.now(), tu: 'ban-cai-tay' }); } catch (e) { /* */ }
  window.addEventListener('message', (e) => { // Claude nạp mã qua Chrome lúc cài đặt; chỉ nhận khi máy CHƯA có mã
    try {
      const d = e && e.data; if (!d || !d.smhBiMat || e.origin !== location.origin) return;
      const b = d.smhBiMat; if (!b.appId || !b.appSecret || !b.hookLoi || !b.hookBaoCao) return;
      const cu = lay('bimat6', null); if (cu && cu.appId) { ghi('Có yêu cầu nạp mã bí mật nhưng máy này đã có mã → bỏ qua'); return; }
      luu('bimat6', { appId: String(b.appId), appSecret: String(b.appSecret), hookLoi: String(b.hookLoi), hookBaoCao: String(b.hookBaoCao), luc: Date.now() });
      ghi('Đã nạp mã bí mật (mã Lark, nhóm Lark) vào máy này → tải lại trang để dùng');
      setTimeout(() => { if (!dangBan && !lay('dang_do', null)) roiTrang(); }, 2000);
    } catch (er) { /* */ }
  });

  // ---------- gom lỗi ----------
  const BC_LOI_RE = /lỗi|Lỗi|kẹt|treo|không ăn|hộp lạ|Bỏ qua bước|chưa được|không được|thất bại|không thấy|không mở được|không sang được|chưa nhận|đứng yên|trắng trang|❌|⚠️|❓|🚨|bấm Đăng nhưng/;
  const BC_BO_RE = /^(Đã báo Lark|Lỗi chi tiết|Đã hiện thông báo|Khởi động bản|Đã nạp mã|Đã ghi báo cáo lỗi|Ghi báo cáo lỗi|🛟)|lần thử \d+ — bước phụ/;
  const BC_DC_RE = /^Tự điều chỉnh:/;
  const khoaBC = (m) => String(m).replace(/\s*\[tab [^\]]+\]\s*$/, '').replace(/\d{1,2}:\d{2}(:\d{2})?/g, '#').replace(/\d+([.,]\d+)?/g, '#').slice(0, 150);
  const ngayGanDay = (n) => Array.from({ length: n }, (_, i) => ngayStr(congNgay(-i)));
  function layBC() { const b = lay('bc6', null) || {}; b.d = b.d || {}; b.uuTien = b.uuTien || []; return b; }
  function catBC(b) { const giu = new Set(ngayGanDay(3)); for (const n of Object.keys(b.d)) if (!giu.has(n)) delete b.d[n]; b.uuTien = b.uuTien.filter((x) => Date.now() - x.luc < 3 * 864e5).slice(-5); return b; }
  function thuBaoCao(msg) {
    if (!MAY || BC_BO_RE.test(msg)) return;
    const laDC = BC_DC_RE.test(msg); if (!laDC && !BC_LOI_RE.test(msg)) return;
    const b = layBC(); const ng = homNay(); const d = b.d[ng] || (b.d[ng] = { loi: {}, dc: [] });
    d.loi = d.loi || {}; d.dc = d.dc || [];
    if (laDC) { d.dc.push(gioStr(new Date()) + ' ' + String(msg).slice(0, 200)); d.dc = d.dc.slice(-20); }
    else {
      const k = khoaBC(msg); const x = d.loi[k];
      if (x) { x.n++; x.cuoi = Date.now(); }
      else { if (Object.keys(d.loi).length >= 80) return; d.loi[k] = { n: 1, dau: Date.now(), cuoi: Date.now(), vd: String(msg).replace(/\s*\[tab [^\]]+\]\s*$/, '').slice(0, 300) }; }
    }
    b.ban = PHIEN_BAN; b.doi = Date.now();
    luu('bc6', catBC(b));
  }
  // ---------- thống kê từng việc (theoDoi gọi sau mỗi lần chạy) ----------
  const TK_KQ_RE = /thiếu|gửi bù|lỗi|thử lại|Bỏ qua|kẹt|máy khác|đăng tay|ngoài lịch|đã có trên trang|đọc lại|bổ sung/i;
  function demViec(key, ms, coKQ) {
    if (!MAY || !key) return;
    const t = lay('tk6', {}) || {}; const ng = homNay(); const d = t[ng] || (t[ng] = {});
    const x = d[key] || (d[key] = { c: 0, ms: 0, kq: 0 }); x.c++; x.ms += Math.max(0, Math.round(ms)); if (coKQ) x.kq++;
    const giu = new Set(ngayGanDay(14)); for (const n of Object.keys(t)) if (!giu.has(n)) delete t[n];
    luu('tk6', t);
  }
  function tkTong(key, soNgay) { const t = lay('tk6', {}) || {}; let c = 0, kq = 0, ms = 0; for (const n of ngayGanDay(soNgay)) { const x = (t[n] || {})[key]; if (x) { c += x.c; kq += x.kq; ms += x.ms; } } return { c, kq, ms }; }
  // ---------- tự điều chỉnh (tầng 1): việc chạy nhiều mà 7 ngày không ra kết quả → giãn ra; có kết quả lại → về mức cũ ----------
  function phutDoTrang() {
    const s = tkTong('dotrang', 7); const goc = CAI_DAT.DO_TRANG_PHUT;
    const thua = s.c >= 200 && s.kq === 0;
    const v = thua ? goc * 2 : goc;
    if ((lay('tn_dotrang', goc) || goc) !== v) { luu('tn_dotrang', v); ghi(`Tự điều chỉnh: dò bài trên trang ${goc} → ${v} phút/lần (${thua ? '7 ngày qua chạy ' + s.c + ' lần không phát hiện gì mới' : 'vừa có phát hiện mới → về mức cũ'})`); }
    return v;
  }

  // ---------- ghi báo cáo lên Lark (khi có lỗi mới; tối đa 30 phút/lần; nút 🛟 thì ghi ngay) ----------
  const oBC = () => (LA_CAO ? CAI_DAT.O_BC_CAO : CAI_DAT.O_BC_GIAO);
  const canGhiBC = () => { if (!MAY || !coBiMat() || lay('bc6_kiem', '') === 'khoa') return false; const b = layBC(); if (!b.doi || b.doi <= (b.daGhi || 0)) return false; return b.gap || Date.now() - (b.daGhi || 0) >= 30 * 60000; };
  function tomTatSlot() { const s = trangThai(); const o = {}; for (const it of LICH) { const r = s.s[it.k]; if (r) o[it.k] = [r.tt, r.may || '', r.lan || 0, r.vong || 0, String(r.loi || r.lyDo || '').slice(0, 80)].join('|'); } return o; }
  async function ghiBaoCaoLark() {
    if (!canGhiBC() || chanLark()) return false;
    const o = oBC();
    if (lay('bc6_kiem', '') !== homNay()) {
      const c = String(chuO(await docO(CAI_DAT.TAB_BAI, o)) || '').trim();
      if (c && !/^BC6\|/.test(c)) { ghi(`Ô ${o} (tab Bài viết kênh 1) đang có chữ khác — script không ghi báo cáo lỗi vào ô này`); luu('bc6_kiem', 'khoa'); return false; }
      luu('bc6_kiem', homNay());
    }
    const b = catBC(layBC()); const t = lay('tk6', {}) || {}; const tk = {}; for (const n of ngayGanDay(3)) if (t[n]) tk[n] = t[n];
    const goi = { may: MAY, ban: PHIEN_BAN, luc: Date.now(), d: b.d, uuTien: b.uuTien, tk, tn: { dotrang: lay('tn_dotrang', CAI_DAT.DO_TRANG_PHUT) }, slot: tomTatSlot() };
    let s = 'BC6|' + JSON.stringify(goi);
    if (s.length > 40000) { for (const n of Object.keys(goi.d)) for (const k of Object.keys(goi.d[n].loi || {})) goi.d[n].loi[k].vd = String(goi.d[n].loi[k].vd).slice(0, 120); s = 'BC6|' + JSON.stringify(goi); }
    while (s.length > 40000 && goi.uuTien.length) { goi.uuTien.shift(); s = 'BC6|' + JSON.stringify(goi); }
    if (s.length > 40000) { goi.tk = {}; s = 'BC6|' + JSON.stringify(goi).slice(0, 39990); }
    await ghiO(CAI_DAT.TAB_BAI, o, s);
    const b2 = layBC(); b2.daGhi = Date.now(); b2.gap = false; luu('bc6', b2);
    ghi(`Đã ghi báo cáo lỗi kỹ thuật lên Lark sheet (ô ${o}) cho Claude kiểm tra tối nay`);
    return true;
  }

  // ---------- Máy Cao: 🛟 báo lỗi này cho Claude ----------
  function chupHienTruong() {
    const hop = Array.from(document.querySelectorAll('[role="dialog"],[role="alertdialog"]')).filter((d) => dangHien(d) && !d.closest('#smhfb,#smhfb-nho,#smhfb-soan-w')).slice(0, 6)
      .map((d) => ({ chu: chuan(d.innerText).slice(0, 300), nut: Array.from(d.querySelectorAll('[role="button"],button')).filter(dangHien).map((x) => chuan(x.innerText || x.getAttribute('aria-label') || '')).filter((t) => t && t.length < 30).slice(0, 12) }));
    const nk = (lay(khoaNK(new Date()), []) || []).filter((e) => Date.now() - e.cuoi < 40 * 60000).slice(-80).map((e) => gioStr(new Date(e.luc)) + ' ' + String(e.msg).replace(/\s*\[tab [^\]]+\]$/, '').slice(0, 220) + (e.so > 1 ? ' [x' + e.so + ']' : ''));
    const dd = lay('dang_do', null);
    return { luc: Date.now(), may: MAY, ban: PHIEN_BAN, url: location.pathname, hd: (lay('hoat_dong', null) || {}).ten || '', dangDo: dd ? { ten: dd.ten, buoc: dd.buoc, luc: dd.luc } : null, hop, nk };
  }
  function baoLoiChoClaude() {
    const x = chupHienTruong();
    const b = layBC(); b.uuTien.push(x); b.doi = Date.now(); b.gap = true; b.ban = PHIEN_BAN; luu('bc6', catBC(b));
    ghi(`🛟 Bạn bấm "Báo lỗi này cho Claude" — đã chụp lại tình trạng (${x.hop.length} hộp đang mở, ${x.nk.length} dòng nhật ký) → ưu tiên kiểm tra tối nay`);
    nhacNho('Đã ghi lại lỗi — tối nay Claude kiểm tra lỗi này trước tiên. Script vẫn tự xử lý tiếp để không bỏ bài.', 'ok', 7000);
    setTimeout(() => { if (!dangBan) nhip(); }, 500);
  }

  // ---------- Máy Cao: bản mới chờ duyệt (đọc trangthai.json trên GitHub, 3 giờ/lần) ----------
  const ttGit = () => lay('tt_git6', null) || {};
  function docTrangThaiGit(ep) {
    if (!LA_CAO || (!ep && Date.now() - (ttGit().hoi || 0) < 3 * 3600e3)) return;
    luu('tt_git6', Object.assign({}, ttGit(), { hoi: Date.now() }));
    try {
      GM_xmlhttpRequest({ method: 'GET', url: CAI_DAT.LINK_TRANG_THAI + '?t=' + Date.now(), timeout: 20000,
        onload: (r) => { try { if (r.status !== 200) return; const j = JSON.parse(r.responseText); luu('tt_git6', Object.assign(j, { hoi: Date.now() })); veBang(); } catch (e) { /* */ } } });
    } catch (e) { /* */ }
  }
  const banChoDuyet = () => { const c = ttGit().choDuyet; if (!c || !c.ban || !cuHon(PHIEN_BAN, c.ban)) return null; if (lay('duyet6', '') === c.ban) return null; return c; };
  const anChip = () => { const a = lay('desau6', null); const c = banChoDuyet(); return !!(a && c && a.ban === c.ban && a.ngay === homNay()); };
  async function duyetBanMoi(ban) {
    await ghiO(CAI_DAT.TAB_BAI, CAI_DAT.O_DUYET, `DUYET|${ban}|${Date.now()}|CAO`);
    luu('duyet6', ban);
    ghi(`✅ Đã duyệt bản ${ban} — tối nay Claude chuyển thành bản chính thức, 2 máy tự cập nhật`);
    nhacNho(`Đã duyệt bản ${ban}. Tối nay Claude chuyển thành bản chính thức, Tampermonkey trên 2 máy tự cập nhật.`, 'ok', 7000);
  }
  // nút trên thanh popup (chỉ Máy Cao)
  function nutTuNangBar() {
    if (!LA_CAO) return '';
    const c = banChoDuyet();
    return (c && !anChip() ? `<button class="tg chip-duyet" data-a="moduyet" title="${esc(c.tomTat || '')}">🆕 Bản ${esc(c.ban)} chờ duyệt</button>` : '')
      + `<button class="tg" data-a="baoclaude" title="Thấy lỗi? Bấm để script chụp lại tình trạng lúc này — tối nay Claude kiểm tra lỗi này trước tiên (script vẫn tự xử lý tiếp)">🛟</button>`;
  }
  // khung trong tab Hệ thống
  function khungTuNang() {
    const b = layBC(); const ng = b.d[homNay()] || {}; const soLoi = Object.values(ng.loi || {}).reduce((a, x) => a + x.n, 0);
    const c = banChoDuyet(); const tt = ttGit();
    let h = `<div class="the-nd" style="margin-top:10px"><div class="nhan">🔄 Tự nâng cấp</div>`;
    h += `<div class="dong"><span>Đang chạy</span><span><b>bản ${PHIEN_BAN}</b>${tt.chinhThuc ? ' · bản chính thức trên GitHub: ' + esc(tt.chinhThuc) : ''}</span></div>`;
    h += `<div class="dong"><span>Mã bí mật</span><span>${coBiMat() ? '🟢 đã có trong máy' : '🔴 máy này chưa có mã Lark — Claude sẽ nạp khi kiểm tra tối'}</span></div>`;
    h += `<div class="dong"><span>Báo cáo lỗi hôm nay</span><span>${soLoi} dòng lỗi · ${b.uuTien.length ? b.uuTien.length + ' lần bấm 🛟 · ' : ''}${b.daGhi ? 'ghi lên Lark lúc ' + gioStr(new Date(b.daGhi)) : 'chưa cần ghi'}</span></div>`;
    if ((ng.dc || []).length) h += `<div class="dong"><span>Tự điều chỉnh</span><span>${ng.dc.map(esc).join('<br>')}</span></div>`;
    if (LA_CAO && c) h += `<div class="dong" style="flex-direction:column;align-items:flex-start;gap:6px"><b>🆕 Bản ${esc(c.ban)} đang chờ anh duyệt</b><span class="mo" style="white-space:pre-wrap">${esc(c.tomTat || '(không có tóm tắt)')}</span><span><button class="nut chinh" data-a="duyetban" data-ban="${esc(c.ban)}">✅ Duyệt</button> <button class="nut" data-a="desau" data-ban="${esc(c.ban)}">Để sau</button></span></div>`;
    else if (LA_CAO && lay('duyet6', '') && cuHon(PHIEN_BAN, lay('duyet6', ''))) h += `<div class="dong"><span>Đã duyệt</span><span>bản ${esc(lay('duyet6', ''))} — chờ Claude chuyển thành bản chính thức tối nay, sau đó Tampermonkey tự cập nhật</span></div>`;
    if (LA_CAO) h += `<div class="dong"><span>Thấy lỗi?</span><span><button class="nut" data-a="baoclaude">🛟 Báo lỗi này cho Claude</button></span></div>`;
    return h + '</div>';
  }
  document.addEventListener('click', async (ev) => {
    const a = ev.target.closest && ev.target.closest('#smhfb [data-a]'); if (!a) return;
    const hd = a.getAttribute('data-a'); const ban = a.getAttribute('data-ban');
    if (hd === 'baoclaude') { if (!LA_CAO) return; baoLoiChoClaude(); veBangNgay(); return; }
    if (hd === 'moduyet') { uiTab.moRong = true; uiTab.moLuc = Date.now(); luu('ui_tab6', 'hethong'); nhacNho('Xem bản mới ở tab Hệ thống → mục Tự nâng cấp'); veBangNgay(); return; }
    if (hd === 'desau' && ban) { luu('desau6', { ban, ngay: homNay() }); nhacNho(`Để sau — mai nhắc lại bản ${ban}`); veBangNgay(); return; }
    if (hd === 'duyetban' && ban) {
      if (!LA_CAO) return;
      if (!confirm(`Duyệt bản ${ban}?\n\nTối nay Claude chuyển bản này thành bản chính thức, Tampermonkey trên cả 2 máy tự cập nhật.`)) return;
      try { await theoDoi('duyet', () => duyetBanMoi(ban), 'Đang ghi duyệt bản ' + ban); } catch (e) { ghi('Ghi duyệt chưa được: ' + e.message); nhacNho('Ghi duyệt chưa được (' + e.message + ') — thử lại sau ít phút', 'vang', 7000); }
      veBangNgay();
    }
  });
  // ---------- Claude (lượt kiểm tra tối) lấy báo cáo của CẢ 2 máy qua máy đang bật: đọc ô Z5:Z7 (1 lượt Lark) → để vào khung ẩn #smhfb-bc ----------
  window.addEventListener('message', async (e) => {
    try {
      const d = e && e.data; if (!d || !d.smhLayBaoCao || e.origin !== location.origin) return;
      let out;
      try { const v = await docBang(CAI_DAT.TAB_BAI, CAI_DAT.O_BC_GIAO + ':' + CAI_DAT.O_DUYET); out = { ok: true, luc: Date.now(), may: MAY, ban: PHIEN_BAN, giao: chuO((v[0] || [])[0]) || '', cao: chuO((v[1] || [])[0]) || '', duyet: chuO((v[2] || [])[0]) || '', sk: lay('sk6', null), coBiMat: coBiMat() }; }
      catch (er) { out = { ok: false, loi: er.message, may: MAY, ban: PHIEN_BAN, coBiMat: coBiMat() }; }
      let el = document.getElementById('smhfb-bc'); if (!el) { el = document.createElement('textarea'); el.id = 'smhfb-bc'; el.style.display = 'none'; document.body.appendChild(el); }
      el.value = JSON.stringify(out);
      ghi('Claude đã lấy báo cáo lỗi của 2 máy để kiểm tra');
    } catch (er) { /* */ }
  });
