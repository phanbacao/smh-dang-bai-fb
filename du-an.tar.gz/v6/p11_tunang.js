
  // =====================================================================
  //  (6.16) TỰ NÂNG CẤP
  //  · gom lỗi + thống kê từng việc → ghi báo cáo kỹ thuật lên Lark sheet (Z5 Máy Giao / Z6 Máy Cao) để Claude đọc mỗi tối
  //  · tự điều chỉnh việc lặp lại mà không có kết quả (giữ mức tối thiểu)
  //  · Máy Cao: nút "🛟 Báo lỗi này cho Claude" + chip "🆕 Bản mới chờ duyệt" (✅ Duyệt → ô Z7)
  //  · nạp mã bí mật (mã Lark, nhóm Lark) — file công khai không chứa mã
  // =====================================================================
  const coBiMat = () => !!(CAI_DAT.LARK_APP_ID && CAI_DAT.LARK_APP_SECRET && CAI_DAT.WEBHOOK_LOI);
  // bản cài tay lần đầu (có sẵn mã) → tự cất mã vào máy, để các bản tự cập nhật sau (không chứa mã) vẫn chạy được
  try { if (!(lay('bimat6', null) || {}).appId && coBiMat() && CAI_DAT.WEBHOOK_BAO_CAO) luu('bimat6', { ...(lay('bimat6', null) || {}), appId: CAI_DAT.LARK_APP_ID, appSecret: CAI_DAT.LARK_APP_SECRET, hookLoi: CAI_DAT.WEBHOOK_LOI, hookBaoCao: CAI_DAT.WEBHOOK_BAO_CAO, luc: Date.now(), tu: 'ban-cai-tay' }); } catch (e) { /* */ }
  try { const g = lay('lark_gate', null); if (g && coBiMat() && /chưa có mã Lark|10003/.test(g.msg || '') && g.loai !== 'quota') { luu('lark_gate', null); ghi('Máy đã có mã Lark → thử Lark lại ngay'); } } catch (e) { /* */ } // (6.20.2)
  window.addEventListener('message', (e) => { // Claude nạp mã qua Chrome lúc cài đặt; chỉ nhận khi máy CHƯA có mã
    try {
      const d = e && e.data; if (!d || !d.smhBiMat || e.origin !== location.origin) return;
      const b = d.smhBiMat; if (!b.appId || !b.appSecret || !b.hookLoi || !b.hookBaoCao) return;
      const cu = lay('bimat6', null); if (cu && cu.appId) { ghi('Có yêu cầu nạp mã bí mật nhưng máy này đã có mã → bỏ qua'); return; }
      luu('bimat6', { appId: String(b.appId), appSecret: String(b.appSecret), hookLoi: String(b.hookLoi), hookBaoCao: String(b.hookBaoCao), luc: Date.now() });
      ghi('Đã nạp mã bí mật (mã Lark, nhóm Lark) vào máy này → tải lại trang để dùng');
      setTimeout(() => { if (!dangBan && !lay('dang_do', null)) roiTrang(); }, 2000);
    } catch (er) { /* */ }
  });

  // ---------- gom lỗi ----------
  const BC_LOI_RE = /lỗi|Lỗi|kẹt|treo|không ăn|hộp lạ|Bỏ qua bước|chưa được|không được|thất bại|không thấy|không mở được|không sang được|chưa nhận|đứng yên|trắng trang|❌|⚠️|❓|🚨|bấm Đăng nhưng/;
  const BC_BO_RE = /^(Đã báo Lark|Lỗi chi tiết|Đã hiện thông báo|Khởi động bản|Đã nạp mã|Đã ghi báo cáo lỗi|Ghi báo cáo lỗi|🛟|Báo cáo tối:|Tự chụp hiện trường|Chuẩn bị cho .*: ổn|Đối chiếu .*: đúng)|lần thử \d+ — bước phụ/;
  const BC_DC_RE = /^Tự điều chỉnh:/;
  const khoaBC = (m) => String(m).replace(/\s*\[tab [^\]]+\]\s*$/, '').replace(/\d{1,2}:\d{2}(:\d{2})?/g, '#').replace(/\d+([.,]\d+)?/g, '#').slice(0, 150);
  const ngayGanDay = (n) => Array.from({ length: n }, (_, i) => ngayStr(congNgay(-i)));
  function layBC() { const b = lay('bc6', null) || {}; b.d = b.d || {}; b.uuTien = b.uuTien || []; return b; }
  function catBC(b) { const giu = new Set(ngayGanDay(3)); for (const n of Object.keys(b.d)) if (!giu.has(n)) delete b.d[n]; b.uuTien = b.uuTien.filter((x) => Date.now() - x.luc < 3 * 864e5).slice(-5); return b; }
  function thuBaoCao(msg) {
    if (!MAY || BC_BO_RE.test(msg)) return;
    const laDC = BC_DC_RE.test(msg); if (!laDC && !BC_LOI_RE.test(msg)) return;
    const b = layBC(); const ng = homNay(); const d = b.d[ng] || (b.d[ng] = { loi: {}, dc: [] });
    d.loi = d.loi || {}; d.dc = d.dc || [];
    if (laDC) { d.dc.push(gioStr(new Date()) + ' ' + String(msg).slice(0, 200)); d.dc = d.dc.slice(-20); }
    else {
      const k = khoaBC(msg); const x = d.loi[k];
      if (x) { x.n++; x.cuoi = Date.now(); }
      else { if (Object.keys(d.loi).length >= 80) return; d.loi[k] = { n: 1, dau: Date.now(), cuoi: Date.now(), vd: String(msg).replace(/\s*\[tab [^\]]+\]\s*$/, '').slice(0, 300) }; }
    }
    b.ban = PHIEN_BAN; b.doi = Date.now();
    luu('bc6', catBC(b));
  }
  // ---------- thống kê từng việc (theoDoi gọi sau mỗi lần chạy) ----------
  const TK_KQ_RE = /thiếu|gửi bù|lỗi|thử lại|Bỏ qua|kẹt|máy khác|đăng tay|ngoài lịch|đã có trên trang|đọc lại|bổ sung/i;
  function demViec(key, ms, coKQ) {
    if (!MAY || !key) return;
    const t = lay('tk6', {}) || {}; const ng = homNay(); const d = t[ng] || (t[ng] = {});
    const x = d[key] || (d[key] = { c: 0, ms: 0, kq: 0 }); x.c++; x.ms += Math.max(0, Math.round(ms)); if (coKQ) x.kq++;
    const giu = new Set(ngayGanDay(14)); for (const n of Object.keys(t)) if (!giu.has(n)) delete t[n];
    luu('tk6', t);
  }
  function tkTong(key, soNgay) { const t = lay('tk6', {}) || {}; let c = 0, kq = 0, ms = 0; for (const n of ngayGanDay(soNgay)) { const x = (t[n] || {})[key]; if (x) { c += x.c; kq += x.kq; ms += x.ms; } } return { c, kq, ms }; }
  // ---------- tự điều chỉnh (tầng 1): việc chạy nhiều mà 7 ngày không ra kết quả → giãn ra; có kết quả lại → về mức cũ ----------
  function phutDoTrang() {
    const s = tkTong('dotrang', 7); const goc = CAI_DAT.DO_TRANG_PHUT;
    const thua = s.c >= 200 && s.kq === 0;
    const v = thua ? goc * 2 : goc;
    if ((lay('tn_dotrang', goc) || goc) !== v) { luu('tn_dotrang', v); ghi(`Tự điều chỉnh: dò bài trên trang ${goc} → ${v} phút/lần (${thua ? '7 ngày qua chạy ' + s.c + ' lần không phát hiện gì mới' : 'vừa có phát hiện mới → về mức cũ'})`); }
    return v;
  }

  // ---------- ghi báo cáo lên Lark (khi có lỗi mới; tối đa 30 phút/lần; nút 🛟 thì ghi ngay) ----------
  const oBC = () => (LA_CAO ? CAI_DAT.O_BC_CAO : CAI_DAT.O_BC_GIAO);
  const canGhiBC = () => { if (!MAY || !coBiMat() || lay('bc6_kiem', '') === 'khoa') return false; if (larkHomNay() >= TRAN_CUNG_LARK()) { if (!window.__bcTranCung) { window.__bcTranCung = 1; ghi('Báo cáo lỗi kỹ thuật: hôm nay đã chạm trần cứng lượt Lark → để sang hôm sau mới ghi lên Lark (không thử lại liên tục)'); } return false; } const b = layBC(); if (!b.doi || b.doi <= (b.daGhi || 0)) return false; return b.gap || (!larkTietKiem() && Date.now() - (b.daGhi || 0) >= 8 * 3600000); }; // (6.28.5) 8 tiếng/lần, quá trần lượt Lark ngày thì chỉ ghi khi bấm 🛟 // (6.25) 6 tiếng/lần (6.20.8: 4 tiếng) báo cáo lỗi ghi lên sheet tối đa 4 tiếng/lần (trước 30 phút)
  function tomTatSlot() { const s = trangThai(); const o = {}; for (const it of LICH) { const r = s.s[it.k]; if (r) o[it.k] = [r.tt, r.may || '', r.lan || 0, r.vong || 0, String(r.loi || r.lyDo || '').slice(0, 80)].join('|'); } return o; }
  async function ghiBaoCaoLark() {
    if (!canGhiBC() || chanLark()) return false;
    const o = oBC();
    if (lay('bc6_kiem', '') !== homNay()) {
      const c = String(chuO(await docO(CAI_DAT.TAB_BAI, o)) || '').trim();
      if (c && !/^BC6\|/.test(c)) { ghi(`Ô ${o} (tab Bài viết kênh 1) đang có chữ khác — script không ghi báo cáo lỗi vào ô này`); luu('bc6_kiem', 'khoa'); return false; }
      luu('bc6_kiem', homNay());
    }
    const b = catBC(layBC()); const t = lay('tk6', {}) || {}; const tk = {}; for (const n of ngayGanDay(3)) if (t[n]) tk[n] = t[n];
    const goi = { may: MAY, ban: PHIEN_BAN, luc: Date.now(), d: b.d, uuTien: b.uuTien, drive: lay('drive6', null), tk, tn: { dotrang: lay('tn_dotrang', CAI_DAT.DO_TRANG_PHUT) }, slot: tomTatSlot() };
    let s = 'BC6|' + JSON.stringify(goi);
    if (s.length > 40000) { for (const n of Object.keys(goi.d)) for (const k of Object.keys(goi.d[n].loi || {})) goi.d[n].loi[k].vd = String(goi.d[n].loi[k].vd).slice(0, 120); s = 'BC6|' + JSON.stringify(goi); }
    while (s.length > 40000 && goi.uuTien.length) { goi.uuTien.shift(); s = 'BC6|' + JSON.stringify(goi); }
    if (s.length > 40000) { goi.tk = {}; s = 'BC6|' + JSON.stringify(goi).slice(0, 39990); }
    await ghiO(CAI_DAT.TAB_BAI, o, s);
    const b2 = layBC(); b2.daGhi = Date.now(); b2.gap = false; luu('bc6', b2);
    ghi(`Đã ghi báo cáo lỗi kỹ thuật lên Lark sheet (ô ${o}) cho Claude kiểm tra tối nay`);
    return true;
  }

  // ---------- Máy Cao: 🛟 báo lỗi này cho Claude ----------
  function chupHienTruong() {
    const hop = Array.from(document.querySelectorAll('[role="dialog"],[role="alertdialog"]')).filter((d) => dangHien(d) && !d.closest('#smhfb,#smhfb-nho,#smhfb-soan-w')).slice(0, 6)
      .map((d) => ({ chu: chuan(d.innerText).slice(0, 300), nut: Array.from(d.querySelectorAll('[role="button"],button')).filter(dangHien).map((x) => chuan(x.innerText || x.getAttribute('aria-label') || '')).filter((t) => t && t.length < 30).slice(0, 12) }));
    const nk = (lay(khoaNK(new Date()), []) || []).filter((e) => Date.now() - e.cuoi < 40 * 60000).slice(-80).map((e) => gioStr(new Date(e.luc)) + ' ' + String(e.msg).replace(/\s*\[tab [^\]]+\]$/, '').slice(0, 220) + (e.so > 1 ? ' [x' + e.so + ']' : ''));
    const dd = lay('dang_do', null);
    return { luc: Date.now(), may: MAY, ban: PHIEN_BAN, url: location.pathname, hd: (lay('hoat_dong', null) || {}).ten || '', dangDo: dd ? { ten: dd.ten, buoc: dd.buoc, luc: dd.luc } : null, hop, nk };
  }
  function baoLoiChoClaude() {
    const x = chupHienTruong();
    const b = layBC(); b.uuTien.push(x); b.doi = Date.now(); b.gap = true; b.ban = PHIEN_BAN; luu('bc6', catBC(b));
    ghi(`🛟 Bạn bấm "Báo lỗi này cho Claude" — đã chụp lại tình trạng (${x.hop.length} hộp đang mở, ${x.nk.length} dòng nhật ký) → ưu tiên kiểm tra tối nay`);
    nhacNho('Đã ghi lại lỗi — tối nay Claude kiểm tra lỗi này trước tiên. Script vẫn tự xử lý tiếp để không bỏ bài.', 'ok', 7000);
    setTimeout(() => { if (!dangBan) nhip(); }, 500);
  }

  // ---------- Máy Cao: bản mới chờ duyệt (đọc trangthai.json trên GitHub, 3 giờ/lần) ----------
  const ttGit = () => lay('tt_git6', null) || {};
  function docTrangThaiGit(ep) {
    if (!LA_CAO || (!ep && Date.now() - (ttGit().hoi || 0) < 3 * 3600e3)) return;
    luu('tt_git6', Object.assign({}, ttGit(), { hoi: Date.now() }));
    try {
      GM_xmlhttpRequest({ method: 'GET', url: CAI_DAT.LINK_TRANG_THAI + '?t=' + Date.now(), timeout: 20000,
        onload: (r) => { try { if (r.status !== 200) return; const j = JSON.parse(r.responseText); luu('tt_git6', Object.assign(j, { hoi: Date.now() })); veBang(); } catch (e) { /* */ } } });
    } catch (e) { /* */ }
  }
  const banChoDuyet = () => { const c = ttGit().choDuyet; if (!c || !c.ban || !cuHon(PHIEN_BAN, c.ban)) return null; if (lay('duyet6', '') === c.ban) return null; return c; };
  const anChip = () => { const a = lay('desau6', null); const c = banChoDuyet(); return !!(a && c && a.ban === c.ban && a.ngay === homNay()); };
  async function duyetBanMoi(ban) {
    await ghiO(CAI_DAT.TAB_BAI, CAI_DAT.O_DUYET, `DUYET|${ban}|${Date.now()}|CAO`);
    luu('duyet6', ban);
    ghi(`✅ Đã duyệt bản ${ban} — tối nay Claude chuyển thành bản chính thức, 2 máy tự cập nhật`);
    nhacNho(`Đã duyệt bản ${ban}. Tối nay Claude chuyển thành bản chính thức, Tampermonkey trên 2 máy tự cập nhật.`, 'ok', 7000);
  }
  // nút trên thanh popup (chỉ Máy Cao)
  function nutTuNangBar() {
    const c = LA_CAO ? banChoDuyet() : null;
    return nutCapNhatNgay() + `<button class="tg" data-a="kiemcapnhat" title="Kiểm tra bản mới trên GitHub ngay (không chờ 3–6 tiếng) — có bản mới thì mở trang cài">⬆</button>` + (c && !anChip() ? `<button class="tg chip-duyet" data-a="moduyet" title="${esc(c.tomTat || '')}">🆕 Bản ${esc(c.ban)} chờ duyệt</button>` : '')
      + `<button class="tg" data-a="baoclaude" title="Thấy lỗi? Bấm để script chụp lại tình trạng lúc này — tối nay Claude kiểm tra lỗi này trước tiên (script vẫn tự xử lý tiếp)">🛟</button>`;
  }
  // khung trong tab Hệ thống
  function khungTuNang() {
    const b = layBC(); const ng = b.d[homNay()] || {}; const soLoi = Object.values(ng.loi || {}).reduce((a, x) => a + x.n, 0);
    const c = banChoDuyet(); const tt = ttGit();
    let h = `<div class="the-nd" style="margin-top:10px"><div class="nhan">🔄 Tự nâng cấp</div>`;
    h += `<div class="dong"><span>Đang chạy</span><span><b>bản ${PHIEN_BAN}</b>${tt.chinhThuc ? ' · bản chính thức trên GitHub: ' + esc(tt.chinhThuc) : ''}</span></div>`;
    h += `<div class="dong"><span>Kênh 1 đang đăng</span><span>${CAI_DAT.KENH[1].moi ? '🟢 Kênh 1 mới (' + esc(CAI_DAT.KENH[1].ten) + ') · kênh 1 cũ: tạm dừng' : '🟠 Kênh 1 CŨ (' + esc(CAI_DAT.KENH[1].ten) + ')'} <button class="nut nho" data-a="k1cu">${CAI_DAT.KENH[1].moi ? 'Bật lại kênh 1 cũ' : 'Về kênh 1 mới'}</button></span></div>`; // (6.21)
    { const w = lay('lark_web6', null) || {}; h += `<div class="dong"><span>Tải video/ảnh qua Lark web (không tốn lượt)</span><span>${w.hong && (!w.ok || w.hong > w.ok) ? '✗ ' + esc(String(w.ly || 'lỗi')) + ' · ' + gioStr(new Date(w.hong)) : w.ok ? '✓ lần cuối ' + gioStr(new Date(w.ok)) + ' · ' + (w.soOk || 0) + ' file' : 'chưa dùng'}</span></div>`; }
    { const lm = lay('lark_thang6', null); if (lm) h += `<div class="dong"><span>Lượt gọi Lark tháng này (máy này)</span><span><b>${lm.so || 0}</b> · trần mềm mỗi ngày ${TRAN_LARK_NGAY()} lượt${larkTietKiem() ? ' — <b style="color:#d93a3a">hôm nay đã chạm trần, đang bỏ việc phụ</b>' : ''} (hạn mức cả tổ chức 10.000/tháng gồm cả bot KPI)</span></div>`; }
    { const ld = lay('lark_dem', {}) || {}; if (ld.ngay === homNay()) { const ds = Object.entries(ld.loai || {}).sort((a, b) => b[1] - a[1]).map(([k, n]) => `${esc(k)}: ${n}`).join(' · '); h += `<div class="dong"><span>Lượt gọi Lark hôm nay</span><span><b>${ld.so || 0}</b>${ds ? ' — ' + ds : ''}</span></div>`; } } // (6.20.8)
    { const c = lay('cham6', null); const ds = c && c.ngay === homNay() ? c.ds : []; h += `<div class="dong"><span>Bước quá lâu hôm nay</span><span>${ds.length ? ds.slice(-8).reverse().map((x) => `<b>${gioStr(new Date(x.luc))}</b> ${esc(x.ten)} ${x.giay}s (ngưỡng ${x.nguong}s)`).join('<br>') : 'chưa có'}</span></div>`; } // (6.24)
    h += `<div class="dong"><span>Mã bí mật</span><span>${coBiMat() ? '🟢 đã có trong máy' : '🔴 máy này chưa có mã Lark — Claude sẽ nạp khi kiểm tra tối'}</span></div>`;
    h += `<div class="dong"><span>Báo cáo lỗi hôm nay</span><span>${soLoi} dòng lỗi · ${b.uuTien.length ? b.uuTien.length + ' lần bấm 🛟 · ' : ''}${b.daGhi ? 'ghi lên Lark lúc ' + gioStr(new Date(b.daGhi)) : 'chưa cần ghi'}</span></div>`;
    if ((ng.dc || []).length) h += `<div class="dong"><span>Tự điều chỉnh</span><span>${ng.dc.map(esc).join('<br>')}</span></div>`;
    if (LA_CAO && c) h += `<div class="dong" style="flex-direction:column;align-items:flex-start;gap:6px"><b>🆕 Bản ${esc(c.ban)} đang chờ anh duyệt</b><span class="mo" style="white-space:pre-wrap">${esc(c.tomTat || '(không có tóm tắt)')}</span><span><button class="nut chinh" data-a="duyetban" data-ban="${esc(c.ban)}">✅ Duyệt</button> <button class="nut" data-a="desau" data-ban="${esc(c.ban)}">Để sau</button></span></div>`;
    else if (LA_CAO && lay('duyet6', '') && cuHon(PHIEN_BAN, lay('duyet6', ''))) h += `<div class="dong"><span>Đã duyệt</span><span>bản ${esc(lay('duyet6', ''))} — chờ Claude chuyển thành bản chính thức tối nay, sau đó Tampermonkey tự cập nhật</span></div>`;
    { const cn = lay('capnhat6', null); h += `<div class="dong"><span>Nguồn cập nhật</span><span>${cn ? (cn.ok ? '🟢 đọc được · bản trên nguồn: ' + esc(cn.ban || '?') + ' (kiểm lúc ' + gioStr(new Date(cn.luc)) + ')' : '🔴 chưa đọc được (' + esc(cn.loi || '') + ')') : 'chưa kiểm'}</span></div>`; }
    { const dv = lay('drive6', null); h += `<div class="dong"><span>Thử nguồn Google Drive</span><span>${dv ? (dv.ok ? '🟢 Tampermonkey đọc được file trên Drive (bản ' + esc(dv.ban) + ')' : '🔴 chưa đọc được: ' + esc(dv.loi || '')) : 'chưa thử'}</span></div>`; }
    h += `<div class="dong"><span>Mã đọc các trang</span><span>${KENH_ALL.map((c) => `${c === 4 ? 'HX' : 'K' + c} ${coApiKenh(c) ? '🟢' : '⚪'}`).join(' · ')}${KENH_PHU.some((c) => !coApiKenh(c)) ? '<br><span class="mo">⚪ = chưa đọc được trang đó qua Facebook: script vẫn đăng, tự mở trang nhìn để tránh đăng trùng (chỉ chưa tự kiểm comment được)</span>' : ''}</span></div>`;
    h += khungThuNap();
    h += `<div class="dong"><span>Thấy lỗi?</span><span><button class="nut" data-a="baoclaude">🛟 Báo lỗi này cho Claude</button></span></div>`;
    return h + '</div>';
  }
  document.addEventListener('click', async (ev) => {
    const a = ev.target.closest && ev.target.closest('#smhfb [data-a]'); if (!a) return;
    const hd = a.getAttribute('data-a'); const ban = a.getAttribute('data-ban');
    if (hd === 'baoclaude') { baoLoiChoClaude(); veBangNgay(); return; }
    if (hd === 'k1cu') { const bat = !!CAI_DAT.KENH[1].moi; if (!confirm(bat ? 'Bật lại KÊNH 1 CŨ ("Vòng Trầm Hương Sơn Mộc Hương .") và dừng kênh 1 mới?\nLịch kênh 1 hôm nay sẽ đặt lại. Trang sẽ tải lại.' : 'Quay về KÊNH 1 MỚI và dừng kênh 1 cũ?\nLịch kênh 1 hôm nay sẽ đặt lại. Trang sẽ tải lại.')) return; luu('k1_cu', bat); ghi(bat ? 'Bấm: bật lại kênh 1 cũ' : 'Bấm: về kênh 1 mới'); roiTrang(); return; }
    if (hd === 'kiemcapnhat') { kiemCapNhatTay(); return; }
    if (hd === 'capnhatngay') { const u = a.getAttribute('data-link'); ghi('Bấm Cập nhật ngay → mở trang cài bản mới của Tampermonkey'); nhacNho('Đang mở trang cập nhật — bấm "Cập nhật" trên trang Tampermonkey vừa mở'); window.open(u, '_blank'); return; }
    if (hd === 'moduyet') { uiTab.moRong = true; uiTab.moLuc = Date.now(); luu('ui_tab6', 'hethong'); nhacNho('Xem bản mới ở tab Hệ thống → mục Tự nâng cấp'); veBangNgay(); return; }
    if (hd === 'desau' && ban) { luu('desau6', { ban, ngay: homNay() }); nhacNho(`Để sau — mai nhắc lại bản ${ban}`); veBangNgay(); return; }
    if (hd === 'duyetban' && ban) {
      if (!LA_CAO) return;
      if (!confirm(`Duyệt bản ${ban}?\n\nTối nay Claude chuyển bản này thành bản chính thức, Tampermonkey trên cả 2 máy tự cập nhật.`)) return;
      try { await theoDoi('duyet', () => duyetBanMoi(ban), 'Đang ghi duyệt bản ' + ban); } catch (e) { ghi('Ghi duyệt chưa được: ' + e.message); nhacNho('Ghi duyệt chưa được (' + e.message + ') — thử lại sau ít phút', 'vang', 7000); }
      veBangNgay();
    }
  });
  // ---------- Claude (lượt kiểm tra tối) lấy báo cáo của CẢ 2 máy qua máy đang bật: đọc ô Z5:Z7 (1 lượt Lark) → để vào khung ẩn #smhfb-bc ----------
  window.addEventListener('message', async (e) => {
    try {
      const d = e && e.data; if (!d || !d.smhLayBaoCao || e.origin !== location.origin) return;
      let out;
      try { const v = await docBang(CAI_DAT.TAB_BAI, CAI_DAT.O_BC_GIAO + ':' + CAI_DAT.O_DUYET); out = { ok: true, luc: Date.now(), may: MAY, ban: PHIEN_BAN, giao: chuO((v[0] || [])[0]) || '', cao: chuO((v[1] || [])[0]) || '', duyet: chuO((v[2] || [])[0]) || '', sk: lay('sk6', null), coBiMat: coBiMat() }; }
      catch (er) { out = { ok: false, loi: er.message, may: MAY, ban: PHIEN_BAN, coBiMat: coBiMat() }; }
      let el = document.getElementById('smhfb-bc'); if (!el) { el = document.createElement('textarea'); el.id = 'smhfb-bc'; el.style.display = 'none'; document.body.appendChild(el); }
      el.value = JSON.stringify(out);
      ghi('Claude đã lấy báo cáo lỗi của 2 máy để kiểm tra');
    } catch (er) { /* */ }
  });

  // =====================================================================
  //  (6.18) TỰ CHỤP HIỆN TRƯỜNG khi một bước lỗi / kẹt (giống bấm 🛟, tối đa 4 lần/ngày/máy)
  // =====================================================================
  function tuChupHienTruong(ly) {
    try {
      const b = layBC(); const hn = homNay();
      const daChup = b.uuTien.filter((x) => x.tu && ngayStr(new Date(x.luc)) === hn).length; if (daChup >= 4) return;
      const x = chupHienTruong(); x.tu = true; x.ly = String(ly || '').slice(0, 200);
      b.uuTien.push(x); b.doi = Date.now(); b.ban = PHIEN_BAN; luu('bc6', catBC(b));
      luuNK(`Tự chụp hiện trường (${x.hop.length} hộp đang mở, ${x.nk.length} dòng nhật ký) để Claude kiểm tra tối nay: ${x.ly}`, true);
    } catch (e) { /* */ }
  }
  // =====================================================================
  //  (6.18) MỖI TỐI 21:30 mỗi máy ghi 1 dòng "đã chạy" lên Lark (kể cả ngày không có lỗi)
  // =====================================================================
  function nhipBaoCaoToi() {
    if (!MAY || phutTrongNgay(new Date()) < 21 * 60 + 30 || lay('bc6_hb', '') === homNay()) return;
    const s = trangThai(); const xong = LICH.filter((it) => XONG.includes((s.s[it.k] || {}).tt)).length;
    const b = layBC(); const d = b.d[homNay()] || (b.d[homNay()] = { loi: {}, dc: [] });
    const soLoi = Object.values(d.loi || {}).reduce((a, x) => a + x.n, 0);
    d.hb = { luc: Date.now(), xong, soLoi };
    b.doi = Date.now(); b.gap = true; b.ban = PHIEN_BAN; luu('bc6', catBC(b)); luu('bc6_hb', homNay());
    ghi(`Báo cáo tối: ${TEN_MAY} đã chạy cả ngày — ${xong}/${LICH.length} bài đã lên, ${soLoi} dòng lỗi → ghi lên Lark cho Claude`);
  }
  // =====================================================================
  //  (6.18) 16:00 NHẮC ĐIỀN SHEET — chỉ cho bài của NGÀY MAI (Máy Giao gửi, nhóm Marketing)
  // =====================================================================
  async function nhacSheetMai() {
    if (!LA_GIAO || !coBiMat() || phutTrongNgay(new Date()) < 16 * 60 || lay('nhacsheet6', '') === homNay()) return false;
    if (dangBan || lay('dang_do', null)) return false;
    if (Date.now() - (lay('nhacsheet6_thu', 0) || 0) < 30 * 60000) return false; // (6.19.3) gửi lỗi thì 30 phút sau thử lại (trước đây hỏng là cả ngày không nhắc)
    luu('nhacsheet6_thu', Date.now());
    try { if (!chanLark()) await docDuLieu('nhacmai'); } catch (e) { ghi('Nhắc điền sheet: đọc sheet chưa được (' + e.message + ') → dùng dữ liệu đọc gần nhất'); }
    const mai = ngayMai(); const d = duLieu(); if (!d) return false;
    const ds = [];
    const LM = lichNgay(mai, d);
    for (const it of LM) { const nd = noiDungSlot(mai, it.k, d); if (nd.thieu && nd.thieu.length) ds.push(`• ${it.ten}: thiếu ${nd.thieu.join(', ')}`); }
    for (const w of canhBaoKenh(mai, d)) ds.push(`• ${w.ten}: ${w.thieu.join(', ')}`); // (6.19) kênh 2, 3: chưa có dòng / chưa ĐÃ DUYỆT
    if (!ds.length) { luu('nhacsheet6', homNay()); ghi(`Nhắc điền sheet: ngày mai ${mai} đã đủ nội dung ${LM.length} bài → không cần nhắc`); return true; }
    const coK = LM.some((x) => x.kenh > 1) || canhBaoKenh(mai, d).length;
    const nd = `📝 Nhắc bổ sung sheet cho NGÀY MAI ${mai.replace(/-/g, '/')} (${ds.length} mục còn thiếu):\n${ds.join('\n')}\nSheet: ${CAI_DAT.LINK_SHEET}${coK ? `\nKênh 2: ${CAI_DAT.KENH[2].link}\nKênh 3: ${CAI_DAT.KENH[3].link}` : ''}`;
    const okGui = await guiLark('loi', nd, { khoa: 'nhacsheet_' + mai }) /* (6.25) nhắc sheet ngày mai → nhóm báo lỗi */;
    if (okGui) { luu('nhacsheet6', homNay()); ghi(`Đã nhắc nhóm Marketing bổ sung sheet cho ngày mai (${ds.length} bài còn thiếu)`); } else ghi('Nhắc điền sheet ngày mai: gửi Lark chưa được → 30 phút sau thử lại');
    return true;
  }
  // =====================================================================
  //  (6.18) CHUẨN BỊ TRƯỚC GIỜ ĐĂNG ~10 PHÚT: sheet đủ chưa, file đã tải sẵn chưa, đúng trang chưa, có ô soạn bài không
  // =====================================================================
  async function chuanBiTruoc() {
    if (!MAY || !tuDong() || tamDung() || dangBan || lay('dang_do', null) || lay('cho_tay6', null) || !laTabChinh()) return false;
    const L = tinhLich(); const it = L.find((x) => x.keTiep); if (!it || !it.den) return false;
    const con = it.den - Date.now(); if (con < 6 * 60000 || con > 12 * 60000 || it.r.cbLuc === it.den) return false;
    datKenh(it.kenh);
    if (LA_CAO && it.r.may !== 'CAO') return false; // Máy Cao chỉ chuẩn bị khi nó là máy đăng (dự phòng)
    capNhatTT((s) => { ttSlot(s, it.k).cbLuc = it.den; });
    const loi = []; const ok = [];
    let nd = noiDungSlot(homNay(), it.k);
    if (nd.thieu.length && LA_GIAO && Date.now() - ((duLieu() || {}).luc || 0) > 30 * 60000) { try { if (!chanLark()) { await docDuLieu('thieu'); nd = noiDungSlot(homNay(), it.k); } } catch (e) { /* */ } }
    if (nd.thieu.length) loi.push('sheet còn thiếu ' + nd.thieu.join(', ')); else ok.push('sheet đủ nội dung');
    if (it.loai === 'video' && nd.tep) { const c0 = await khoLay('tep|' + nd.tep.fileToken); ok.push(c0 && c0.blob && c0.blob.size > 500 ? 'video đã tải sẵn' : 'video chưa có trong kho → tải 1 lần lúc đăng'); } // (6.25) không tải thêm ở bước chuẩn bị (tiết kiệm lượt Lark)
    if (document.visibilityState === 'visible' && dungTrang() && !nhanSuDangDung() && !hopSoanBai() && !ganManHinh()) {
      try { const tc = await damBaoTuCach(); if (tc) ok.push('đang đúng trang ' + CAI_DAT.TEN_NGAN); else ok.push('đang chuyển sang đúng trang (trang tải lại)'); }
      catch (e) { if (e instanceof LoiDung) throw e; loi.push('chưa chuyển được sang trang ' + CAI_DAT.TEN_NGAN + ' (' + String(e.message).slice(0, 80) + ')'); }
      if (!timNutSoanBai() && !Array.from(document.querySelectorAll('[role="button"]')).some((b) => chuan(b.innerText) === 'Ảnh/video')) loi.push('không thấy ô soạn bài trên trang');
      else ok.push('có ô soạn bài');
    }
    ghi(`Chuẩn bị cho ${it.ten} (đăng lúc ${gioStr(new Date(it.den))}): ${loi.length ? '⚠ ' + loi.join(' · ') + (ok.length ? ' | ổn: ' + ok.join(', ') : '') : 'ổn — ' + ok.join(', ')}`);
    if (loi.length) await baoLoi(`⚠️ Còn khoảng ${Math.round(con / 60000)} phút nữa đăng ${it.ten} nhưng: ${loi.join(' · ')} — script sẽ vẫn thử đăng đúng giờ`, 'cb_' + it.k);
    return true;
  }
  // =====================================================================
  //  (6.18) ĐỐI CHIẾU BÀI SAU KHI ĐĂNG ~15 PHÚT (chỉ hỏi Facebook, không chạm trang)
  // =====================================================================
  async function doiChieuSauDang() {
    if (!MAY || !coApi() || tamDung()) return false;
    const s = trangThai(); const now = Date.now();
    const it = LICH.find((x) => { const r = s.s[x.k]; return r && coApiKenh(x.kenh || 1) && XONG.includes(r.tt) && r.id && !r.dcLuc && now - (r.luc || 0) > 15 * 60000 && now - (r.luc || 0) < 6 * 3600e3 && (r.may === MAY || (LA_GIAO && ['khac', 'tay'].includes(r.may))); });
    if (!it) return false;
    datKenh(it.kenh); if (!coApi()) { datKenh(1); return false; }
    const r = s.s[it.k]; const nd = noiDungSlot(homNay(), it.k);
    capNhatTT((s1) => { ttSlot(s1, it.k).dcLuc = Date.now(); });
    let ds; try { ds = await baiTrenTrangApi((r.luc || now) - 30 * 60000); } catch (e) { capNhatTT((s1) => { ttSlot(s1, it.k).dcLuc = 0; }); return false; }
    const p = ds.find((x) => x.id === r.id);
    const loi = [];
    if (!p) loi.push('Facebook không còn thấy bài này trên trang');
    else {
      if (nd.text && !(dauKhop(p, nd.text) && (doGiong(p.text, nd.text) >= CAI_DAT.NGUONG_BAI || khoaSo(p.text).includes(khoaSo(nd.text).slice(0, 40))))) loi.push('chữ trên bài không khớp với sheet');
      if ((it.loai === 'video' || it.loai === 'manifest') && laVideoApi(p) === false) loi.push('bài không phải thước phim/video');
      const trungLink = LICH.find((x) => x.k !== it.k && s.s[x.k] && s.s[x.k].link && r.link && linkGon(s.s[x.k].link) === linkGon(r.link));
      if (trungLink) loi.push('trùng link với ' + trungLink.ten);
    }
    capNhatTT((s1) => { Object.assign(ttSlot(s1, it.k), { dcLuc: Date.now(), dcLoi: loi.join(' · ') }); });
    ghi(`Đối chiếu ${it.ten} sau khi đăng: ${loi.length ? '⚠ ' + loi.join(' · ') : 'đúng chữ, đúng loại bài, không trùng link'}`);
    if (loi.length) await baoLoi(`⚠️ Đối chiếu ${it.ten} sau khi đăng: ${loi.join(' · ')}${r.link ? ' — ' + r.link : ''} — cần xem lại`, 'dc_' + it.k);
    return true;
  }
  // =====================================================================
  //  (6.18) NÚT "CẬP NHẬT NGAY": 3 giờ/lần hỏi nguồn cập nhật xem có bản mới hơn bản đang chạy không
  // =====================================================================
  function docNguonCapNhat(ep) {
    const cn = lay('capnhat6', null);
    if (!MAY || (!ep && cn && Date.now() - cn.luc < 3 * 3600e3)) return;
    luu('capnhat6', Object.assign({}, cn || {}, { luc: Date.now() }));
    try {
      GM_xmlhttpRequest({ method: 'GET', url: CAI_DAT.LINK_CAP_NHAT + (CAI_DAT.LINK_CAP_NHAT.includes('?') ? '&' : '?') + 't=' + Date.now(), timeout: 30000,
        onload: (r) => { const m = String(r.responseText || '').match(/@version\s+([\d.]+)/); luu('capnhat6', m && r.status < 400 ? { luc: Date.now(), ok: true, ban: m[1] } : { luc: Date.now(), ok: false, loi: 'mã ' + r.status }); veBang(); },
        onerror: () => { luu('capnhat6', { luc: Date.now(), ok: false, loi: 'mất kết nối' }); },
        ontimeout: () => { luu('capnhat6', { luc: Date.now(), ok: false, loi: 'quá lâu' }); } });
    } catch (e) { luu('capnhat6', { luc: Date.now(), ok: false, loi: e.message }); }
    // thử đọc file phát hành trên Google Drive (để quyết định có chuyển nguồn cập nhật sang Drive không)
    try {
      GM_xmlhttpRequest({ method: 'GET', url: CAI_DAT.LINK_THU_DRIVE + '&t=' + Date.now(), timeout: 30000,
        onload: (r) => { const tx = String(r.responseText || ''); const m = tx.match(/@version\s+([\d.]+)/); const kq = m ? { luc: Date.now(), ok: true, ban: m[1] } : { luc: Date.now(), ok: false, loi: /quét vi-rút|virus/i.test(tx) ? 'Drive hiện trang cảnh báo vi-rút' : /accounts\.google|Đăng nhập|Sign in/i.test(tx) ? 'file chưa chia sẻ công khai' : 'mã ' + r.status }; luu('drive6', kq); try { const b = layBC(); b.drive = kq; luu('bc6', b); } catch (e) { /* */ } veBang(); },
        onerror: () => luu('drive6', { luc: Date.now(), ok: false, loi: 'mất kết nối' }), ontimeout: () => luu('drive6', { luc: Date.now(), ok: false, loi: 'quá lâu' }) });
    } catch (e) { /* */ }
  }
  // (6.20.1) nút ⬆ trên popup: hỏi GitHub ngay, có bản mới thì mở trang cài của Tampermonkey
  let kiemCNDang = false;
  function moTrangCai() { const u = CAI_DAT.LINK_CAP_NHAT + (CAI_DAT.LINK_CAP_NHAT.includes('?') ? '&' : '?') + 't=' + Date.now(); try { GM_openInTab(u, { active: true }); } catch (e) { window.open(u, '_blank'); } }
  function kiemCapNhatTay() {
    if (kiemCNDang) return; kiemCNDang = true;
    ghi('Bấm ⬆ Kiểm tra bản mới'); nhacNho('Đang kiểm tra bản mới trên GitHub…');
    const ketThuc = (ok, ban, loi) => {
      kiemCNDang = false;
      if (ok) luu('capnhat6', { luc: Date.now(), ok: true, ban });
      const dang = dangBan || !!lay('dang_do', null) || !!lay('cho_tay6', null);
      const nhacF5 = dang ? ' Máy đang đăng/soạn bài — chờ xong rồi mới F5 trang Facebook.' : ' Cài xong thì F5 trang Facebook.';
      if (ok && cuHon(PHIEN_BAN, ban)) { ghi(`Có bản ${ban} (đang chạy ${PHIEN_BAN}) → mở trang cài`); nhacNho(`Có bản ${ban} — đang mở trang cài, bấm "Cập nhật" trên trang Tampermonkey.` + nhacF5, 'ok', 9000); moTrangCai(); }
      else if (ok) { ghi(`Kiểm tra bản mới: đang dùng bản mới nhất ${PHIEN_BAN}`); nhacNho(`Đang dùng bản mới nhất ${PHIEN_BAN}. Nếu vừa bấm Commit trên GitHub thì chờ 2–3 phút rồi bấm lại.`, 'ok', 8000); }
      else { ghi('Kiểm tra bản mới: không đọc được GitHub (' + loi + ') → mở thẳng trang cài'); nhacNho('Không kiểm tra được GitHub (' + loi + ') — mở thẳng trang cài để bạn tự xem bản.' + nhacF5, 'loi', 9000); moTrangCai(); }
      veBangNgay();
    };
    try {
      GM_xmlhttpRequest({ method: 'GET', url: CAI_DAT.LINK_CAP_NHAT + (CAI_DAT.LINK_CAP_NHAT.includes('?') ? '&' : '?') + 't=' + Date.now(), timeout: 20000, headers: { 'Cache-Control': 'no-cache' },
        onload: (r) => { const m = String(r.responseText || '').match(/@version\s+([\d.]+)/); if (m && r.status < 400) ketThuc(true, m[1]); else ketThuc(false, '', 'mã ' + r.status); },
        onerror: () => ketThuc(false, '', 'mất kết nối'), ontimeout: () => ketThuc(false, '', 'quá lâu') });
    } catch (e) { ketThuc(false, '', e.message); }
  }
  function nutCapNhatNgay() {
    const cn = lay('capnhat6', null); if (!cn || !cn.ok || !cn.ban || !cuHon(PHIEN_BAN, cn.ban)) return '';
    return `<button class="tg chip-duyet" data-a="capnhatngay" data-link="${esc(CAI_DAT.LINK_CAP_NHAT)}" title="Bản ${esc(cn.ban)} đã được duyệt. Tampermonkey sẽ tự cập nhật trong vòng 6 tiếng — bấm để cập nhật ngay">⬆ Bản ${esc(cn.ban)} — Cập nhật ngay</button>`;
  }
