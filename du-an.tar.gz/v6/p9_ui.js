
  // =====================================================================
  //  GIAO DIỆN — giữ đúng giao diện bản 5.9 (thanh màu kéo thả + tab), chỉ bổ sung tính năng 6.0
  //  (taoCSS, CSS_THEM, datViTri, fbToi, tabKhanh… lấy nguyên từ bản 5.9)
  // =====================================================================
  const CSS_MOI = `
#smhfb .lu2{display:grid;grid-template-columns:1fr 1fr;gap:0 16px;align-items:start}
@media (max-width:1100px){#smhfb .lu2{display:block}}
#smhfb .md-wrap{max-width:1100px}
#smhfb .mdt{width:100%;border-collapse:collapse;margin-top:8px}
#smhfb .mdt td{vertical-align:middle}
#smhfb .mdt tr.md-moi td{background:rgba(217,139,11,.12)}
#smhfb .md-k{font-weight:800;white-space:nowrap}
#smhfb .md-y{font-size:13px;line-height:1.45}
#smhfb .md-tay{display:inline-block;font-weight:800;color:#b5651d;margin-right:4px}
#smhfb .md-tu{display:inline-block;font-weight:800;color:#2e9d57;margin-right:4px}
#smhfb .md-so{display:inline-flex;align-items:center;border:1.5px solid var(--vien);border-radius:10px;overflow:hidden}
#smhfb .md-so input{width:52px;text-align:center;border:0;background:var(--the);color:var(--chu);font:inherit;font-weight:800;padding:6px 2px;-moz-appearance:textfield}
#smhfb .md-so input::-webkit-inner-spin-button{-webkit-appearance:none;margin:0}
#smhfb .md-b{width:34px;height:34px;border:0;background:var(--nut);color:var(--nut-chu);font-size:18px;font-weight:800;cursor:pointer}
#smhfb .md-b:disabled{opacity:.35;cursor:default}
#smhfb .md-b:hover:not(:disabled){filter:brightness(1.15)}
#smhfb .mdt input.md-gio{font:inherit;font-weight:700;width:76px;text-align:center;padding:6px 8px;border:1.5px solid var(--vien);border-radius:8px;background:var(--the);color:var(--chu)}
#smhfb .mdt input.md-gio:focus{outline:2px solid #2e9d57;border-color:#2e9d57}
#smhfb .md-l{display:flex;gap:10px;align-items:flex-start;padding:6px 0;border-top:1px dashed var(--vien)}
#smhfb .md-l>b{min-width:210px;flex:none}
#smhfb .md-chan{position:sticky;bottom:-4px;display:flex;flex-wrap:wrap;gap:8px;align-items:center;padding:10px 12px 10px;background:var(--the);border:1px solid var(--the-vien);border-radius:12px;box-shadow:0 -4px 12px rgba(0,0,0,.12);border-top:1px solid var(--vien2);margin-top:4px;z-index:2}
#smhfb .md-chan .nut:disabled,#smhfb .md-chan .nut.md-mo{opacity:.5}
#smhfb .hdg.dem{background:#fff1d6;color:#7a4a05;animation:smh6Vien 1s step-end infinite}
#smhfb .hdg.dem .hd-so{flex:none;font-size:30px;font-weight:900;min-width:44px;text-align:center;color:#a5560a}
@keyframes smh6Vien{0%{background:#fff1d6}50%{background:#ffd98a}}
#smhfb .hdg.dem.dung{animation:none;background:#fff1d6}
#smhfb.toi .the-nd h4{color:#f2f3f5}
#smhfb .ctabs{display:flex;gap:8px;align-items:center;flex-wrap:wrap;margin:0 0 12px}
#smhfb .ctab{border:1px solid rgba(127,127,127,.45);border-radius:999px;padding:7px 18px;font-weight:800;font-size:14px;background:transparent;color:inherit;cursor:pointer}
#smhfb .ctab.on{background:#2e9d57;color:#fff;border-color:#2e9d57}
#smhfb .ctab .ctab-do{color:#e5484d;margin-left:4px}
#smhfb .ctabs .mo{margin-left:6px}
#smhfb .it .tk.soan{background:#7c5cd6;color:#fff;font-weight:800}
#smhfb .it .tk.soan:hover{filter:brightness(1.1)}
#smhfb .nut.tim{background:#7c5cd6;color:#fff}
#smhfb .chay{opacity:.75;pointer-events:none}
#smhfb .nut .xoay,#smhfb .tg .xoay,#smhfb .seg .xoay{display:inline-block;vertical-align:-3px;margin-right:6px;width:16px;height:16px}
#smhfb .anhs{display:flex;gap:4px;flex-wrap:wrap;margin-top:6px}#smhfb .anhs img{width:34px;height:60px;object-fit:cover;border-radius:5px;border:1px solid var(--vien)}
#smhfb .xem{width:110px;aspect-ratio:9/16;object-fit:cover;border-radius:8px;border:1px solid var(--vien)}
#smhfb .thanh{height:8px;background:var(--vien2);border-radius:6px;overflow:hidden;margin:6px 0}#smhfb .thanh i{display:block;height:100%;background:#2e9d57}
#smhfb input[type=text]{font:inherit;font-size:15px;padding:7px 10px;border:1.5px solid var(--vien);border-radius:10px;width:160px;background:var(--the);color:var(--chu)}
#smhfb .hang{display:flex;gap:8px;align-items:center;flex-wrap:wrap;margin:6px 0}
#smhfb.tudong{pointer-events:none}#smhfb.tudong .tabs,#smhfb.tudong .nd,#smhfb.tudong .foot{display:none}#smhfb.tudong .hdg button,#smhfb.tudong .bar .cdang{pointer-events:auto}
#smhfb table.st .mk{white-space:normal}
#smhfb .mfp{display:flex;flex-wrap:wrap;gap:8px;margin:10px 0 2px}
#smhfb .mfb{display:inline-flex;align-items:center;gap:6px;padding:5px 12px;border-radius:999px;background:var(--xam-nen);color:var(--xam-chu);font-weight:700;font-size:14px}
#smhfb .mfb.dang{background:var(--vang-nen);color:var(--vang-chu)}#smhfb .mfb.xong{background:var(--xanh-nen);color:var(--xanh-chu)}#smhfb .mfb.loi{background:var(--do-nen);color:var(--do-chu)}
#smhfb .mfb .xoay{width:14px;height:14px;margin:0}
#smhfb-nho{position:fixed;z-index:2147483647;left:50%;bottom:28px;transform:translateX(-50%) translateY(20px);opacity:0;pointer-events:none;transition:opacity .25s,transform .25s;background:#1d1a17;color:#fff;font:600 14px/1.35 system-ui,Segoe UI,Arial,sans-serif;padding:10px 16px;border-radius:12px;box-shadow:0 8px 24px rgba(0,0,0,.35);max-width:min(560px,90vw);display:flex;gap:10px;align-items:center;white-space:pre-line}
#smhfb-nho.hien{opacity:1;transform:translateX(-50%) translateY(0)}
#smhfb-nho .d{flex:none;width:10px;height:10px;border-radius:50%;background:#3fbf5a}
#smhfb-nho.cho .d{background:#f0b429;animation:smhHdDen 1s ease-out infinite}
#smhfb-nho.vang .d{background:#e55b3c}
#smhfb .hd-tien{position:absolute;left:0;bottom:0;height:4px;background:#e0a21a;border-radius:0 2px 2px 0;transition:width 1s linear;max-width:100%}
#smhfb .hdg.chay{position:relative;overflow:hidden}
#smhfb .hd-gio small{display:block;font-weight:600;opacity:.75;font-size:.85em}
#smhfb-soan-w{position:fixed;left:50%;transform:translateX(-50%);bottom:16px;z-index:2147483100;display:none;flex-direction:column;gap:8px;min-width:min(320px,90vw);max-width:min(820px,calc(100vw - 40px));padding:12px 18px;border-radius:14px;border:2px solid #e0a21a;background:#fff9e8;color:#7a5410;font:700 14px/1.35 "Segoe UI Variable Text","Segoe UI",system-ui,sans-serif;box-shadow:0 8px 26px rgba(0,0,0,.22);pointer-events:none}
#smhfb-soan-w.cho{border-color:#7c5cd6;background:#f3efff;color:#3f2a86}
#smhfb-soan-w.xong{border-color:#2e9d57;background:#eefaf2;color:#1c6b3a}
#smhfb-soan-w.loi{border-color:#d93a3a;background:#fff1f0;color:#9c2323}
#smhfb-soan-w .gh{display:flex;align-items:center;gap:12px;justify-content:space-between}#smhfb-soan-w .gt{font-weight:600;opacity:.8;font-variant-numeric:tabular-nums}
#smhfb-soan-w .gb{display:flex;flex-wrap:wrap;gap:6px;justify-content:center}
#smhfb-soan-w .gc{display:inline-flex;align-items:center;gap:6px;padding:4px 10px 4px 6px;border-radius:999px;border:1.5px solid #d8d2c4;background:#faf8f3;color:#6b665a;font-size:12.5px;font-weight:700;white-space:nowrap}
#smhfb-soan-w .gc .ic{width:18px;height:18px;border-radius:50%;flex:none;display:inline-flex;align-items:center;justify-content:center;font-size:11px;line-height:1;color:#6b665a;border:1.5px solid #cfc8b8;background:#fff}
#smhfb-soan-w .gc.xong{border-color:#2e9d57;background:#e6f6ec;color:#1c6b3a}#smhfb-soan-w .gc.xong .ic{background:#2e9d57;border-color:#2e9d57;color:#fff}
#smhfb-soan-w .gc.chay{border-color:#e0a21a;background:#fff3d1;color:#7a5410}#smhfb-soan-w .gc.chay .ic{border:2.5px solid #f1d38a;border-top-color:#e0a21a;background:transparent;animation:smhfbGan .9s linear infinite;color:transparent}
#smhfb-soan-w .gc.cho{border-color:#7c5cd6;background:#ebe4ff;color:#3f2a86}#smhfb-soan-w .gc.cho .ic{background:#7c5cd6;border-color:#7c5cd6;color:#fff}
#smhfb-soan-w .gc.loi{border-color:#d93a3a;background:#fdeaea;color:#9c2323}#smhfb-soan-w .gc.loi .ic{background:#d93a3a;border-color:#d93a3a;color:#fff}
#smhfb-soan-w .gd{font-size:13px;font-weight:600;text-align:center;white-space:normal}
#smhfb-soan-w.chay .gd:after{content:"";display:inline-block;width:1.4em;text-align:left;animation:smhfbCham 1.2s steps(4,end) infinite}
@keyframes smh6VienNhay{0%,100%{border-color:var(--khung,#e0a21a);box-shadow:0 18px 48px var(--bong,rgba(0,0,0,.2)),0 0 0 0 rgba(240,180,41,0)}50%{border-color:#f0b429;box-shadow:0 18px 48px var(--bong,rgba(0,0,0,.2)),0 0 0 4px rgba(240,180,41,.45)}}
#smhfb.banviec{animation:smh6VienNhay 1.4s ease-in-out infinite}
@keyframes smh6NhaySap{0%,100%{box-shadow:0 18px 48px var(--bong,rgba(0,0,0,.2)),0 0 0 0 rgba(240,180,41,0);border-color:var(--khung,#e0a21a)}50%{box-shadow:0 18px 48px var(--bong,rgba(0,0,0,.2)),0 0 0 7px rgba(240,180,41,.55),inset 0 0 0 9999px rgba(255,214,90,.16);border-color:#f0b429}}
@keyframes smh6NhayDang{0%,100%{box-shadow:0 18px 48px var(--bong,rgba(0,0,0,.2)),0 0 0 0 rgba(46,157,87,0);border-color:var(--khung,#2e9d57)}50%{box-shadow:0 18px 48px var(--bong,rgba(0,0,0,.2)),0 0 0 7px rgba(46,157,87,.5),inset 0 0 0 9999px rgba(80,200,120,.13);border-color:#2e9d57}}
#smhfb.sap{animation:smh6NhaySap 1.1s ease-in-out infinite!important}
#smhfb.dang{animation:smh6NhayDang 1.3s ease-in-out infinite!important}
#smhfb .chip-duyet{background:#fff3d1;border-color:#e0a21a;color:#7a5410;font-weight:800}
#smhfb .hd-uoc{display:inline-block;margin-left:6px;padding:1px 8px;border-radius:999px;background:rgba(0,0,0,.07);font-weight:700;font-size:.92em}
#smhfb .it .tk.link{background:#e8f3ec;color:#1f6b3a;font-weight:800}
#smhfb .it .tk.soan,#smhfb .it .tk.rong{min-width:84px;text-align:center;justify-content:center;box-sizing:border-box}
#smhfb .it .tk.rong{padding:4px 10px;border-radius:6px;cursor:pointer;border:0;text-decoration:none;display:inline-flex;align-items:center}
#smhfb .khung3{border:2px solid var(--m);border-radius:10px;margin:0 0 10px;overflow:hidden}
#smhfb .khung3 .k3d{display:flex;align-items:center;gap:8px;padding:7px 10px;background:color-mix(in srgb,var(--m) 14%,transparent);font-weight:800;font-size:13px}
#smhfb .khung3 .k3d .mo{font-weight:600}
#smhfb .khung3 .k3d .k3so{margin-left:auto;font-size:12.5px}
#smhfb .khung3 .k3d .k3so.du{color:#2e9d57}
#smhfb .khung3 .k3t{height:5px;background:rgba(127,127,127,.25);margin:0 10px 4px;border-radius:3px;overflow:hidden}
#smhfb .khung3 .k3t i{display:block;height:100%;background:var(--m)}
#smhfb .khung3 .k3b{padding:0 8px 6px}
#smhfb .khung3 .k3rong{padding:4px 2px 2px;font-size:12px;opacity:.7}
#smhfb textarea.cmtta{width:100%;box-sizing:border-box;font:13.5px/1.5 "Segoe UI",system-ui,sans-serif;padding:10px 12px;border-radius:10px;border:1px solid var(--vien,#ccc);background:var(--the,#fff);color:inherit;resize:vertical;user-select:text}
#smhfb input.cmtlink{flex:1;min-width:240px;font-size:13.5px;padding:6px 10px;border-radius:8px;border:1px solid var(--vien,#ccc)}
#smhfb .cmtck{display:inline-flex;align-items:center;gap:4px;font-weight:600;margin-right:10px;cursor:pointer}
#smhfb .cmtluu{position:sticky;bottom:0;z-index:2;box-shadow:0 -6px 16px rgba(0,0,0,.06)}
#smhfb .cmt2cot{display:grid;grid-template-columns:1fr 1fr;gap:12px}
#smhfb .cmtxem{display:grid;grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:10px}
#smhfb .cmtmau{border:1px solid var(--vien2,#eee);border-radius:10px;padding:8px 10px;background:var(--the,#fff)}
#smhfb .cmtmau pre{white-space:pre-wrap;font:12.5px/1.45 "Segoe UI",system-ui,sans-serif;margin:4px 0 0;user-select:text}
#smhfb .mfchon{display:inline-flex;flex-direction:column;gap:2px;font-size:11px;font-weight:700;opacity:.95}
#smhfb .mfchon select{font-size:13px;padding:5px 6px;border-radius:8px;border:1px solid var(--vien,#ccc);background:var(--nen,#fff);color:inherit;max-width:190px;cursor:pointer}
#smhfb .mffont{background:#1d1a17;color:#fff;border-radius:10px;padding:10px 14px;margin:6px 0 8px;line-height:1.45;display:flex;flex-direction:column;gap:4px}
#smhfb .bthieu .bt-vang{color:var(--vang-chu);font-weight:700;background:var(--vang-nen);cursor:help}#smhfb .viec.nhe{background:var(--vang-nen);border-color:#e0a21a55}#smhfb .viec.nhe h3{color:var(--vang-chu)}#smhfb .mucdat input{font:inherit;padding:5px 8px;border:1.5px solid var(--vien);border-radius:8px;background:var(--the);color:var(--chu)}
#smhfb .mfseg{display:inline-flex;border:1.5px solid var(--vien,#4a4840);border-radius:8px;overflow:hidden;margin:0 6px}#smhfb .mfseg button{background:transparent;color:inherit;border:0;padding:7px 14px;font:inherit;font-size:14px;cursor:pointer}#smhfb .mfseg button.on{background:#4caf6e;color:#10200f;font-weight:700}
#smhfb textarea.mfnhap{width:100%;box-sizing:border-box;min-height:220px;resize:vertical;background:var(--the,#fff);color:var(--chu,inherit);border:1.5px solid var(--vien,#ccc);border-radius:10px;padding:10px 12px;font:14px/1.55 "Segoe UI",system-ui,sans-serif;margin:4px 0;user-select:text}
#smhfb .nut.cam{background:#e0a33a;color:#1d1405;border-color:#e0a33a;margin-left:8px}#smhfb .phu-nut.xanh{background:#4caf6e;color:#10200f;font-weight:700}
#smhfb .mfluoi{display:grid;grid-template-columns:repeat(auto-fill,minmax(200px,1fr));gap:10px;margin:10px 0}
#smhfb .mfo{border:2px solid var(--vien);border-radius:12px;padding:6px;background:var(--the);display:flex;flex-direction:column;gap:4px}
#smhfb .mfo.chon{border-color:#2e9d57}
#smhfb .mfo img{width:100%;aspect-ratio:9/16;object-fit:cover;border-radius:8px;cursor:zoom-in;display:block}
#smhfb .mfrong{aspect-ratio:9/16;display:flex;align-items:center;justify-content:center;background:var(--do-nen);color:var(--do-chu);border-radius:8px}
#smhfb .mft{display:flex;justify-content:space-between;align-items:center;gap:4px;font-size:13px}#smhfb .mft .chip{margin:0;white-space:nowrap}#smhfb .mft b{white-space:nowrap}#smhfb .mfn .phu-nut{white-space:nowrap}
#smhfb .mfc{font-size:12px;color:var(--phu);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
#smhfb .mfn{display:flex;justify-content:space-between}
#smhfb .mfxem{position:fixed;inset:0;z-index:2147483647;background:rgba(0,0,0,.6);display:flex;align-items:center;justify-content:center;pointer-events:auto}
#smhfb .mfxk{background:var(--nen);border-radius:16px;padding:14px 16px;max-height:96vh;display:flex;flex-direction:column;gap:8px;box-shadow:0 20px 60px rgba(0,0,0,.5)}
#smhfb .mfxd{display:flex;align-items:center;gap:10px}
#smhfb .mfxa{display:flex;align-items:center;gap:12px}#smhfb .mfxa img{height:min(78vh,900px);aspect-ratio:9/16;object-fit:contain;border-radius:10px;background:#000}
#smhfb .mfxa .nut{font-size:28px;padding:8px 16px}
#smhfb .seg.nho button{min-height:0;font-size:15px;padding:10px 6px}
`;
  const ui6 = { nhan: false, htmlCu: '', locNK: 'quan', xem: null };
  let veHen = 0, gocTitle = document.title;
  function veBang() { if (veHen) return; veHen = setTimeout(() => { veHen = 0; try { veBangNgay(); } catch (e) { console.log('[smh6] vẽ popup lỗi', e); } }, 120); }
  const dangSap = () => (!!demNguoc && !demNguoc.dung) || (() => { const c = lay('cho_nguoi', null); return !!(c && Date.now() - c.luc < 11 * 60000 && nhanSuDangDung()); })();
  const hdHien = () => { const h = lay('hoat_dong', null); return h && Date.now() - (h.cap || 0) < 4 * 60000 ? h : null; };
  const dongHo = (ms) => { const g = Math.max(0, Math.round(ms / 1000)); return Math.floor(g / 60) + ':' + pad(g % 60); };
  const boTab = (m) => String(m || '').replace(/\s*\[tab [^\]]+\]\s*$/, '');
  const cat = (t, n) => { t = String(t || ''); return t.length > n ? t.slice(0, n) + '…' : t; };
  const hang_ = (nhan, nd) => `<div class="r"><div class="rl">${nhan}</div><div class="rv">${nd}</div></div>`;
  const KY = (it) => it.nhan || it.k.toUpperCase();
  const MAU = { b1: 'b1', b2: 'b2', b3: 'b3', video: 'bv', manifest: 'bm' };
  const tenMay = (m) => (m === MAY ? 'máy này' : m === 'CAO' ? 'Máy Cao' : m === 'GIAO' ? 'Máy Giao' : m === 'tay' ? 'đánh dấu tay' : 'máy khác / đăng tay');

  // trạng thái 1 nút bấm (yêu cầu gửi cho tab làm việc): '' | 'run' | 'xong' | 'vang'
  function ttYC(loai) {
    const k = lay('yc6_kq_' + loai, null); if (!k) return { tt: '' };
    if ((k.tt === 'cho' || k.tt === 'dang') && Date.now() - k.luc < 6 * 60000) return { tt: 'run', k };
    if ((k.tt === 'xong' || k.tt === 'loi') && Date.now() - k.luc < 15000) return { tt: k.tt === 'loi' ? 'vang' : 'xong', k };
    return { tt: '', k };
  }
  const kqYC = (loai) => { const k = lay('yc6_kq_' + loai, null); return k && k.kq && Date.now() - k.luc < 6 * 3600e3 ? `${k.tt === 'loi' ? '⚠' : '✓'} ${gioStr(new Date(k.luc))} · ${k.kq}` : ''; };

  // ---------------- trạng thái chung (đèn + chữ trên thanh) ----------------
  function trangThaiChung() {
    if (!MAY) return { den: 'vang', chu: 'Chọn máy này là Máy Giao hay Máy Cao →' };
    const L = tinhLich(); const nXong = L.filter((x) => x.xong).length; const kt = L.find((x) => x.keTiep);
    const dd = lay('dang_do', null); const ct = lay('cho_tay6', null);
    if (tamDung()) return { den: 'xam', chu: `⏸ Đang tạm dừng — tự chạy lại sau ${conTamDung()} (hoặc bấm Chạy lại) · đã lên ${nXong}/${L.length} bài` };
    if (demNguoc) return { den: 'vang', nhay: true, chu: `Sắp ${esc(demNguoc.ten)}…` };
    if (dd) return { den: 'vang', nhay: true, chu: esc(tenDangDo(dd)) + (dd.cmts && dd.buoc !== 'kiem_bai' ? ` · comment ${Math.min((dd.cmtIdx || 0) + 1, dd.cmts.length)}/${dd.cmts.length}` : '') + '…' };
    if (ct) return { den: 'vang', nhay: true, chu: ct.mai ? `Đã soạn thử ${esc(ct.ten)} — xem xong bấm Huỷ (bấm Đăng thì bài lên trang ngay hôm nay)` : `Đã soạn sẵn ${esc(ct.ten)} — kiểm tra rồi bấm Đăng, script sẽ tự comment` };
    if (dangBan) return { den: 'vang', nhay: true, chu: 'Đang làm việc trên trang…' };
    const hdx = hdHien(); if (hdx) return { den: 'vang', nhay: true, chu: esc(hdx.ten) + '…' };
    const loi = L.filter((x) => ['loi', 'khong_ro', 'thieu'].includes(x.r.tt));
    if (!kt) return { den: loi.length ? 'vang' : 'xanh', chu: nXong === L.length ? `✅ Đã lên đủ ${L.length}/${L.length} bài hôm nay` : `Hôm nay xong lịch · đã lên <b>${nXong}/${L.length}</b> bài` };
    let bd = kt.den; if (LA_CAO) bd = Math.max(kt.den + CAI_DAT.CAO_TRE_PHUT * 60000, moLuc + CAI_DAT.CAO_CHO_MO_PHUT * 60000);
    const dau = `<b>${nXong}/${L.length}</b> bài · `;
    if (!tuDong()) return { den: 'xam', chu: dau + `⏸ ĐĂNG BÀI đang TẮT trên máy này (chỉ dò bài + báo cáo) · bài kế tiếp ${kt.ten}` };
    if (dangHoan()) return { den: 'vang', chu: dau + `Đang hoãn đến ${gioStr(new Date(lay('hoan6', 0)))}` };
    if (kt.r.loi && kt.r.thuLai > Date.now()) return { den: 'do', chu: dau + `⚠ ${kt.ten} lỗi — thử lại lúc ${gioStr(new Date(kt.r.thuLai))}` };
    if (Date.now() < bd) return { den: loi.length ? 'vang' : 'xanh', chu: dau + `${kt.ten} lúc <b>${gioStr(new Date(bd))}</b>${LA_CAO ? ' (nếu Máy Giao chưa đăng)' : ''} · còn <b data-hen="${bd}"></b>` };
    return { den: 'vang', nhay: true, chu: dau + `Đến giờ ${kt.ten} — đang chuẩn bị…` };
  }
  function thieuNgay() { // (6.26) chỉ 2 ngày tới (ngày mai + ngày kia) còn thiếu nội dung — hôm nay đã có báo lỗi từng bài
    const d = duLieu(); if (!d) return [];
    const out = []; const s = trangThai();
    for (let i = 1; i <= 2; i++) {
      const ngay = ngayStr(congNgay(i)); let t = thieuCuaNgay(ngay, d); if (!t) continue;
      if (i === 0) t = t.filter((x) => !KET.includes((s.s[x.k] || {}).tt));
      if (t.length) out.push({ ngay, i, t });
    }
    return out;
  }
  // hàng đã có nội dung nhưng chưa ghi ngày đăng (lý do hay gặp khiến popup báo "thiếu")
  function chuaNgay(d = duLieu()) {
    const out = [];
    if (d && (d.ban || 0) < 2) return out; // dữ liệu đọc bằng bản cũ (chưa lọc "còn xa") → không nhắc, đợi lần đọc kế
    if (d && (d.chuaNgayV || []).length) out.push({ k: 'v', chu: `Tab "Kênh 1 Vòng Trầm Hương SMH": hàng ${gonHang(d.chuaNgayV)} đã có video/manifest nhưng cột K (Ngày đăng) còn trống`, nut: 'mosheetvideo' });
    if (d && (d.chuaNgayB || []).length) out.push({ k: 'b', chu: `Tab "Bài viết kênh 1": hàng ${gonHang(d.chuaNgayB)} đã có bài nhưng cột H (Ngày đăng) còn trống`, nut: 'mosheet' });
    return out;
  }
  // ---------------- việc cần bạn xử lý ----------------
  function viecCanXuLy() {
    const ds = []; const s = trangThai();
    for (const it of LICH) {
      const r = s.s[it.k] || {};
      if (['loi', 'khong_ro', 'thieu'].includes(r.tt)) ds.push({ k: 'sl|' + it.k + r.tt, chu: `${it.ten} chưa đăng được: ${r.lyDo || r.loi || r.tt}`, nut: [['✎ Soạn', 'soan', `data-k="${it.k}"`, 'tim'], ['↺ Đăng lại', 'khoiphuc', `data-k="${it.k}"`], ['✓ Đã đăng tay', 'danhdau', `data-k="${it.k}"`]] });
      if (XONG.includes(r.tt) && !r.cmtOk && ((r.kiem || []).length >= CAI_DAT.KIEM_CMT_TOI_DA || r.baoBu)) ds.push({ k: 'cm|' + it.k, chu: `${it.ten}: ${r.baoBu ? 'gửi bù chưa được, cần comment tay' : 'đã kiểm ' + (r.kiem || []).length + ' lần vẫn thiếu comment'}`, nut: [r.link ? ['↗ Mở bài', 'mobai', `data-link="${esc(r.link)}"`] : null, ['💬 Kiểm lại', 'kiemlai', `data-k="${it.k}"`, 'chinh']].filter(Boolean) });
    }
    if (false) for (const c of chuaNgay()) ds.push({ k: 'cn|' + c.chu, chu: c.chu + ' → script chưa biết đăng ngày nào, hãy điền ngày', nut: [['▦ Mở sheet', c.nut, '', 'chinh']] });
    const tn = thieuNgay();
    { const hn = canhBaoMuc(homNay(), duLieu(), true); if (hn.length) ds.push({ k: 'hn|' + hn.map((x) => x.k).join(), chu: 'Hôm nay: ' + hn.map((x) => x.ten + ' ' + x.thieu[0]).join(' · '), nut: [['▦ Mở sheet', 'mosheet', ''], ['⚙ Mức đặt', 'mucdat', '']] }); } // (6.32) hôm nay ít / quá nhiều so với mức đặt
    if (tn.length) { const mai = tn.find((x) => x.i === 1), kia = tn.find((x) => x.i === 2); // (6.32) ngày mai = đỏ, tính vào việc · ngày kia = vàng nhạt, nhắc sớm, không tính
      ds.push({ k: 'thieu|' + tn.map((x) => x.ngay + x.t.length).join(), khongDem: !mai, bang: bangThieu(tn), chu: mai ? `Ngày mai còn thiếu ${mai.t.length} mục${kia ? ` · ngày kia ${kia.t.length} mục (nhắc sớm)` : ''} — sửa sheet xong bấm Đọc lại` : `Ngày kia còn thiếu ${kia.t.length} mục (nhắc sớm, chưa gấp) — sửa sheet xong bấm Đọc lại`, tip: tn.map((x) => x.ngay + ': ' + x.t.map((y) => y.ten + ' ' + y.thieu.join(', ')).join('; ')).join('\n'), nut: [['▦ Mở sheet', 'mosheet', ''], ['Xem', 'xemsaptoi', ''], ['⚙ Mức đặt', 'mucdat', '']] }); }
    { const hk = hanKiemThe(); if (MAY && hk.den) ds.push({ k: 'the7|' + Math.floor(hk.luc / 864e5), chu: `🏷 Đã ${hk.qua} ngày chưa kiểm tra thẻ (Kênh 1, 2, 3, Hà Xá, Manifest) — mở xem, sửa nếu cần, hoặc bấm Xác nhận nếu vẫn dùng thẻ cũ`, nut: [['🏷 Kiểm tra thẻ', 'motabthe', '', 'chinh']] }); } // (6.26.9)
    if (MAY && !nhacInfo()) ds.push({ k: 'nhac', chu: 'Máy này chưa có nhạc nền cho video manifest', nut: [['🎵 Tải nhạc', 'xemmanifest', '', 'chinh']] });
    if (!coApi()) ds.push({ k: 'chuama', chu: 'Chưa cài mã khoá Facebook (script chưa dò được bài trên trang)', nut: [['🔑 Cài mã khoá', 'caima', '', 'chinh']] });
    else { const luc = lay('fb_token_luc', 0); const n = luc ? Math.floor((Date.now() - luc) / 864e5) : 0; if (n >= CAI_DAT.MA_KHOA_HAN_NGAY - 10) ds.push({ k: 'hetma', chu: `Mã khoá Facebook đã dùng ${n} ngày — nên lấy mã mới`, nut: [['🔑 Đổi mã khoá', 'caima', '', 'chinh']] }); }
    const g = chanLark(); if (g) { const w = webData(); ds.push({ k: 'lark', chu: g.msg + (w ? ` — đang đọc sheet qua tab Lark web (lúc ${gioStr(new Date(w.luc))}), tải video qua Lark web` : ' — script vẫn đăng bằng dữ liệu đã tải sẵn · ' + webLyDo() + ': mở sheet MKT 10 trên Chrome máy này và giữ tab đó mở'), nut: [] }); }
    else if (!duLieu()) ds.push({ k: 'chuadoc', chu: 'Chưa đọc được Lark sheet lần nào', nut: [['📥 Đọc sheet', 'docsheet', '', 'chinh']] });
    return ds;
  }
  // (6.26) bảng thiếu nội dung: mỗi kênh 1 dòng, mỗi ngày 1 cột — xanh = đủ, đỏ = thiếu N (rê chuột xem chi tiết)
  function kenhMuc(x) { const m = /^kenh(\d)/.exec(x.k || ''); if (m) return +m[1]; return kenhCua(x.k); }
  function nhanNgan(y) { const t = y.thieu[0] || ''; if (y.muc) return (t.match(/^thiếu \d+ [^(]+/) || [t])[0].trim(); if (y.nhieu) return 'quá nhiều ' + ((t.match(/^quá nhiều: (\d+)/) || [])[1] || ''); if (/^kenh/.test(y.k || '')) { const h = t.match(/^hàng \d+/); if (h) return h[0] + (/chưa có video/.test(t) ? ' chưa có video' : ' chưa duyệt'); return 'lỗi đọc tab'; } return y.ten; }
  function bangThieu(tn) {
    const d = duLieu(); const ngays = [1, 2].map((i) => ngayStr(congNgay(i))); const m = mucDat();
    const o = (ng, c, i) => { const x = tn.find((y) => y.ngay === ng); const ds = (x ? x.t.filter((y) => kenhMuc(y) === c) : []).sort((p, q) => (q.nhieu ? 2 : q.muc ? 1 : 0) - (p.nhieu ? 2 : p.muc ? 1 : 0)); if (!d || !d.ngay || !d.ngay[ng]) return '<td class="bt-x">?</td>';
      if (!ds.length && c > 1 && !m['k' + c]) return '<td class="bt-x">tạm dừng</td>';
      if (!ds.length && c === 1 && !m.k1v && !m.k1b && !m.k1m) return '<td class="bt-x">đăng tay</td>'; // (6.33)
      return ds.length ? `<td class="${i ? 'bt-vang' : 'bt-thieu'}" title="${esc(ds.map((y) => y.ten + ': ' + y.thieu.join(', ')).join('\n'))}">${(() => { const th = ds.filter((y) => !y.nhieu && !y.nhac).length, nh = ds.filter((y) => y.nhac).length; return [ds.some((y) => y.nhieu) ? '⚠ quá nhiều' : '', th ? `thiếu ${th}` : '', nh ? `${nh} chưa duyệt` : ''].filter(Boolean).join(' · '); })()}<div class="bt-ct">${esc(ds.slice(0, 3).map(nhanNgan).join(', '))}${ds.length > 3 ? '…' : ''}</div></td>` : '<td class="bt-du">✓ đủ</td>'; };
    const mucChu = (c) => (c === 1 ? [m.k1v ? m.k1v + ' video' : 'video đăng tay', m.k1b ? m.k1b * 3 + ' bài' : 'bài đăng tay', m.k1m ? m.k1m + ' manifest' : 'manifest đăng tay'].join(' · ') : m['k' + c] ? `${m['k' + c]} video` : 'tạm dừng'); // (6.33)
    return `<table class="bthieu"><tr><th></th>${ngays.map((ng, i) => `<th>${i ? 'Ngày kia' : 'Ngày mai'} ${ng.slice(0, 5).replace('-', '/')}${i ? ' <span style="font-weight:400">(nhắc sớm)</span>' : ''}</th>`).join('')}</tr>${KENH_ALL.map((c) => `<tr><td class="bt-k">${esc(tenKenhDai(c))}<div class="bt-ct">mức: ${esc(mucChu(c))}/ngày</div></td>${ngays.map((ng, i) => o(ng, c, i)).join('')}</tr>`).join('')}</table>`;
  }
  function khungMucDat() { // (6.32) nút ⚙ Mức đặt
    if (!ui6.mucDat) return ''; const m = ui6.mucDat;
    return `<div class="the-nd mucdat"><h4>⚙ Mức đặt số bài mỗi ngày</h4><div class="mo">Ít hơn mức đặt → báo thiếu · từ 3 lần mức đặt trở lên → cảnh báo quá nhiều (dễ là nhập nhầm cột Ngày đăng) · sheet có bao nhiêu dòng thì script vẫn đăng bấy nhiêu. Lưu ở máy này và ô ${CAI_DAT.O_MUC} tab Bài viết để máy kia làm theo.</div>
      ${Object.keys(MUC_MD).map((k) => `<div class="hang"><label style="min-width:300px">${esc(TEN_MUC[k])}</label><input type="number" min="0" max="20" data-o="muc_${k}" value="${esc(m[k])}" style="width:70px"></div>`).join('')}
      <div class="hang"><button class="nut chinh" data-a="luumuc">💾 Lưu mức đặt</button><button class="nut" data-a="huymuc">Huỷ</button>${m.luc ? `<span class="mo">Lần chỉnh gần nhất: ${gioStr(new Date(m.luc))} ${ngayStr(new Date(m.luc)).slice(0, 5).replace('-', '/')}${m.may ? ' · ' + (m.may === 'GIAO' ? 'Máy Giao' : 'Máy Cao') : ''}</span>` : '<span class="mo">Đang dùng mức mặc định</span>'}</div></div>`;
  }
  function theViec() {
    const ds = viecCanXuLy(); const dem = ds.filter((v) => !v.khongDem).length; const km = '';
    if (!ds.length) return km + '<div class="viec ok">✓ Không có việc nào cần bạn xử lý</div>';
    return km + `<div class="viec${dem ? '' : ' nhe'}"><h3>${dem ? `⚠ ${dem} việc cần bạn xử lý` : '💡 Nhắc sớm (chưa gấp)'}</h3>${ds.map((v, i) => `<div class="vr${i ? '' : ' dau'}" title="${esc(v.tip || '')}"><span class="vt">${esc(v.chu)}${v.bang || ''}</span><span class="vn">${v.nut.map(([t, a, x, l]) => `<button class="nut nho ${l || ''}" data-a="${a}" ${x}>${t}</button>`).join(' ')}</span></div>`).join('')}</div>`;
  }

  // ---------------- thanh trên cùng ----------------
  const lopTt = (x) => (x.xong ? 'ok' : ['loi', 'khong_ro', 'thieu'].includes(x.r.tt) ? 'loi' : x.r.tt === 'dang' || (x.keTiep && Date.now() >= (x.den || 0)) ? 'cho' : '');
  function chips() {
    return tinhLich().map((x) => {
      const coLink = x.xong && /^https?:/.test(x.r.link || '');
      const mo = x.xong ? `đã lên lúc ${gioStr(new Date(x.r.luc))} (${tenMay(x.r.may)})` : x.r.tt === 'bo' ? 'đã bỏ' : `dự kiến ${phutStr(x.gioKH)}`;
      return `<button class="tg ${lopTt(x)}" style="${x.r.tt === 'bo' ? 'text-decoration:line-through;opacity:.6' : ''}" data-a="${coLink ? 'mobai' : 'chon'}" data-k="${x.k}"${coLink ? ` data-link="${esc(x.r.link)}"` : ''} title="${esc(x.ten + ' · ' + mo + (coLink ? ' · bấm để mở bài' : ''))}">${x.xong ? '✓ ' : ''}${KY(x)}</button>`;
    }).join('');
  }
  // thông báo nhỏ nổi dưới màn hình (4 giây) — mọi thao tác bấm nút đều có 1 dòng báo
  function nhacNho(chu, mau, ms) { ui6.nho = { chu: String(chu || '').replace(/\s*\[tab [^\]]+\]\s*$/, ''), mau: mau || 'ok', den: Date.now() + (ms || 4000) }; veNhacNho(); }
  function veNhacNho() {
    let el = document.getElementById('smhfb-nho'); const n = ui6.nho;
    if (!n || Date.now() > n.den) { if (el) el.classList.remove('hien'); return; }
    if (!el) { el = document.createElement('div'); el.id = 'smhfb-nho'; document.body.appendChild(el); }
    const html = `<span class="d"></span><span>${esc(n.chu)}</span>`; if (el.innerHTML !== html) el.innerHTML = html;
    el.className = n.mau + ' hien';
  }
  function thanhHoatDong() {
    if (demNguoc) {
      const con = Math.max(0, Math.ceil((demNguoc.den - Date.now()) / 1000));
      const u = uocDem(demNguoc.ten);
      return `<div class="hdg dem${demNguoc.dung ? ' dung' : ''}"><span class="hd-so" data-demso>${demNguoc.dung ? '⏸' : con}</span><div class="hd-noi"><div class="hd-ten">⏳ Sắp ${esc(demNguoc.ten)} — ${demNguoc.dung ? 'đã tạm dừng' : 'bắt đầu sau <span data-demchu>' + con + '</span> giây'}<span class="hd-uoc">dự kiến ~${dongHo(u)}</span></div><div class="hd-chi">${demNguoc.dung ? 'Bấm Tiếp tục khi bạn dùng trang xong — nếu không, script tự tiếp tục lúc ' + gioStr(new Date((demNguoc.dungLuc || Date.now()) + 10 * 60000)) : (u >= 60000 ? 'Việc này dùng trang Facebook khoảng ' + Math.round(u / 60000) + ' phút — đang cần dùng trang thì bấm Tạm dừng' : 'Việc nhanh trên trang Facebook — để script làm, hoặc bấm Hoãn nếu đang cần trang')}</div></div><button class="nut ${demNguoc.dung ? 'chinh' : 'vang'}" data-a="${demNguoc.dung ? 'dntiep' : 'dndung'}">${demNguoc.dung ? '▶ Tiếp tục' : '⏸ Tạm dừng'}</button>${demNguoc.dung ? '' : '<button class="nut chinh" data-a="dnngay">▶ Làm ngay</button>'}</div>`; // (6.27.1) đang tạm dừng: chỉ 1 nút Tiếp tục
    }
    const hd = hdHien();
    if (hd) { const uoc = uocLuong(hd.key, hd.ten); return `<div class="hdg chay"><span class="hd-den"></span><div class="hd-noi"><div class="hd-ten">${esc(hd.ten)}<span class="hd-cham"></span></div>${hd.chi ? `<div class="hd-chi">${esc(boTab(hd.chi))}</div>` : ''}</div><div class="hd-gio" data-hdbd="${hd.bd}" data-uoc="${uoc}"></div><i class="hd-tien" data-tien="1" style="width:${Math.min(96, Math.round(((Date.now() - hd.bd) / uoc) * 100))}%"></i>${dangBan && !tamDung() ? '<button class="phu-nut do" data-a="tamdung">⏸ Tạm dừng</button>' : ''}</div>`; }
    const c = lay('cho_nguoi', null);
    if (c && Date.now() - c.luc < 11 * 60000 && nhanSuDangDung()) { const con = Math.max(0, c.luc + CAI_DAT.CHO_NGUOI_TOI_DA_PHUT * 60000 - Date.now()); return `<div class="hdg cho"><span class="hd-den cho"></span><div class="hd-noi"><div class="hd-ten">⏳ Sắp ${esc(c.ten || 'làm việc trên trang')} — đang chờ bạn dùng xong trang<span class="hd-uoc">dự kiến ~${dongHo(uocDem(c.ten || ''))}</span></div><div class="hd-chi">${esc(c.ly)} → còn tối đa <b data-hen="${c.luc + CAI_DAT.CHO_NGUOI_TOI_DA_PHUT * 60000}">${dongHo(con)}</b>, hết giờ sẽ đếm ngược 10 giây rồi mới làm</div></div><button class="nut chinh" data-a="lamngay">▶ Làm ngay</button></div>`; }
    const k = lay('hd_ket', null);
    if (k && k.ngan && !k.dong && Date.now() - k.luc < 60000) return `<div class="tb-quet ok"><span>✓ <b>Xong: ${esc(String(k.ten).replace(/^Đang /, ''))}</b> <span class="mo">(mất ${dongHo(k.tg)})</span>${k.chu ? ' — ' + esc(boTab(k.chu)).slice(0, 140) : ''}</span></div>`;
    if (k && !k.ngan && !k.dong && Date.now() - k.luc < 60000) return `<div class="tb-quet ${k.mau}"><span>${k.mau === 'ok' ? '✅' : '⚠️'} <b>Xong: ${esc(String(k.ten).replace(/^Đang /, ''))} lúc ${gioStr(new Date(k.luc))}</b> <span class="mo">(mất ${dongHo(k.tg)})</span>${k.chu ? ' — ' + esc(boTab(k.chu)) : ''} <span class="mo">· tự ẩn sau 1 phút</span></span><button class="phu-nut" data-a="donghd" title="Ẩn ngay">✕</button></div>`;
    return '';
  }

  // ---------------- tab Hôm nay ----------------
  function oThaoTac(loai, ic, ten, tt, mo, nut, bam) {
    const { tt: st } = ttYC(loai); const hd = hdHien();
    const live = st === 'run' ? ((hd && hd.key === 'yeucau' && hd.chi) ? boTab(hd.chi) : 'Đang làm…') : '';
    const kq = kqYC(loai);
    const icon = st === 'run' ? '<span class="xoay"></span>' : st === 'xong' ? '✓' : st === 'vang' ? '!' : ic;
    const dong = live || kq || mo;
    return `<div class="tn ${st}${bam ? ' bam' : ''}"${bam ? ` data-a="${bam}" role="button" tabindex="0"` : ''}><div class="tn-dau"><span class="tn-ic">${icon}</span><div class="tn-ten"><b>${ten}</b><span>${esc(tt)}</span></div></div><div class="tn-mo${live ? ' live' : ''}" title="${esc(dong)}">${esc(dong)}</div><div class="tn-nut">${nut}</div></div>`;
  }
  function khuThaoTac() {
    const L = tinhLich(); const nX = L.filter((x) => x.xong).length; const d = duLieu(); const tr = lay('trang6', null) || {};
    const kiem = ['kiem1', 'kiem3', 'kiem24'].map((k) => ttYC(k)).find((x) => x.tt) || { tt: '' };
    const o1 = oThaoTac('docsheet', '📥', 'Đọc lại sheet', d ? `Đọc lúc ${gioStr(new Date(d.luc))} ${ngayStr(new Date(d.luc)).slice(0, 5).replace('-', '/')}` : 'Chưa đọc lần nào', `Tự đọc ${CAI_DAT.GIO_DOC_NHE} và ${CAI_DAT.GIO_DOC_CHOT} · bấm khi vừa sửa sheet`, '<span class="nut nho chinh">Đọc ngay</span>', 'docsheet');
    const rs = LICH.map((it) => trangThai().s[it.k]).filter((r) => r && XONG.includes(r.tt)); const du = rs.filter((r) => r.cmtOk).length;
    const o2 = `<div class="tn ${kiem.tt}"><div class="tn-dau"><span class="tn-ic">${kiem.tt === 'run' ? '<span class="xoay"></span>' : kiem.tt === 'xong' ? '✓' : '💬'}</span><div class="tn-ten"><b>Kiểm comment</b><span>${du}/${rs.length} bài đã đủ comment</span></div></div><div class="tn-mo${kiem.tt === 'run' ? ' live' : ''}">${esc(kiem.tt === 'run' ? 'Đang kiểm…' : kqYC('kiem1') || kqYC('kiem3') || kqYC('kiem24') || `Tự kiểm sau đăng ~2, 10, 20 phút và lúc ${CAI_DAT.GIO_KIEM_CMT_CUOI} · thiếu thì gửi bù`)}</div><div class="tn-nut"><div class="seg nho"><button data-a="kiem1" title="Kiểm comment bài mới nhất trên trang">Bài mới nhất</button><button data-a="kiem3" title="Kiểm comment 3 bài gần nhất hôm nay">3 bài</button><button data-a="kiem24" title="Kiểm comment video/manifest trong 24 giờ qua">Video 24 giờ</button></div></div></div>`;
    const o3 = oThaoTac('dotrang', '🔍', 'Kiểm tra bài đã đăng', `${nX}/${LICH.length} bài hôm nay đã lên trang`, tr.luc ? `Dò lần cuối ${gioStr(new Date(tr.luc))} · tự dò ${CAI_DAT.DO_TRANG_PHUT} phút/lần` : `Tự dò ${CAI_DAT.DO_TRANG_PHUT} phút/lần`, '<span class="nut nho chinh">Kiểm ngay</span>', 'lammoi');
    return `<div class="tn3">${o1}${o2}${o3}</div>`;
  }
  function nhanSlot(x) {
    const r = x.r;
    if (x.xong) return { gio: gioStr(new Date(r.luc)), mo: `Đã lên lúc ${gioStr(new Date(r.luc))} · ${tenMay(r.may)}${r.cmtOk ? ' · comment ✓' : r.id ? ` · comment ${(r.kiem || []).length ? 'còn thiếu' : 'chờ kiểm'}` : ''}` };
    const g = x.keTiep && x.den && x.den > lucPhut(x.gioKH) + 60000 ? gioStr(new Date(x.den)) : phutStr(x.gioKH);
    if (r.tt === 'dang') return { gio: g, mo: 'Đang đăng…' };
    if (r.daSoan && (lay('cho_tay6', null) || {}).slot === x.k) return { gio: g, mo: `Đã soạn sẵn lúc ${gioStr(new Date(r.daSoan))} — chờ bạn bấm Đăng` };
    if (r.tt === 'bo') return { gio: g, mo: 'Đã bỏ: ' + (r.lyDo || '') };
    if (['loi', 'khong_ro', 'thieu'].includes(r.tt)) return { gio: g, mo: '⚠ ' + (r.lyDo || r.loi || 'lỗi') };
    if (r.loi) return { gio: g, mo: `Lỗi, thử lại lúc ${gioStr(new Date(r.thuLai || Date.now()))}` };
    if (x.keTiep && x.den && x.den < Date.now() - 60000 && lucPhut(x.gioKH) < Date.now() - 60000) return { gio: 'Ngay', mo: `Bài kế tiếp · trễ giờ (hẹn ${phutStr(x.gioKH)}) → đăng ngay khi trang rảnh` }; // (6.24)
    if (!x.keTiep) { const dk = (window.__smhDK || {})[x.k]; if (dk && dk.tre) return { gio: '~' + gioStr(new Date(dk.luc)), mo: `Trễ giờ · xếp hàng thứ ${dk.thu}${dk.sau ? ' (sau ' + dk.sau + ')' : ''} · hẹn ${phutStr(x.gioKH)}` }; } // (6.24)
    return { gio: g, mo: x.keTiep ? (g !== phutStr(x.gioKH) ? `Bài kế tiếp · dời ${g} (cách bài trước ${cachK1()} phút) · hẹn ${phutStr(x.gioKH)}` : `Bài kế tiếp · tự động ${g}`) : `Tự động · hẹn ${g}` };
  }
  function theSlot(x) {
    const r = x.r; const nd = noiDungSlot(homNay(), x.k);
    const kq = x.xong ? ['ok', `✓ Đã lên ${gioStr(new Date(r.luc))}`] : r.tt === 'dang' ? ['cho', 'Đang đăng…'] : r.tt === 'bo' ? ['xam', 'Đã bỏ'] : ['loi', 'khong_ro', 'thieu'].includes(r.tt) ? ['loi', r.tt === 'thieu' ? 'Thiếu nội dung' : r.tt === 'khong_ro' ? 'Chưa rõ đã lên chưa' : 'Lỗi — đã bỏ qua'] : x.keTiep ? ['cho', 'Bài kế tiếp'] : (() => { const dk = (window.__smhDK || {})[x.k]; return dk && dk.tre ? ['xam', `Xếp hàng${dk.sau ? ' sau ' + dk.sau : ''} · dự kiến ~${gioStr(new Date(dk.luc))}`] : ['xam', `Chờ đến giờ ${phutStr(x.gioKH)}`]; })();
    const kp = (x.kenh || 1) > 1 ? CAI_DAT.KENH[x.kenh] : null; const cotK = (i) => String.fromCharCode(65 + i);
    let h = `<div class="bai ${MAU[x.loai]}"><div class="bai-h"><span class="bai-t">${esc(x.ten)}<small>${kp ? 'trang ' + esc(kp.ngan) + ' · trước kênh 1 5–15 phút' : (x.them || x.baiThem || !x.tu) ? 'bài thêm theo sheet · hẹn ' + (typeof x.gioKH === 'number' ? phutStr(x.gioKH) : (typeof (trangThai().gio || {})[x.k] === 'number' ? phutStr(trangThai().gio[x.k]) : 'chưa xếp')) : 'xếp đều trong ngày · hẹn ' + (typeof x.gioKH === 'number' ? phutStr(x.gioKH) : 'chưa xếp')}</small></span><span class="kq ${kq[0]}">${kq[1]}</span></div>`;
    h += hang_('Giờ đăng', x.xong ? `<b>${gioStr(new Date(r.luc))}</b> · ${tenMay(r.may)}` : `<b>${nhanSlot(x).gio}</b>`);
    const cot = kp ? `cột ${cotK(kp.cot.cap)} (tab ${kp.tenTab}${nd.hang ? ' hàng ' + nd.hang : ''})` : { b1: 'cột B', b2: 'cột D', b3: 'cột F', video: 'cột E (tab Kênh 1)', manifest: 'cột G (tab Kênh 1)' }[x.loai];
    h += hang_(`Nội dung · ${cot}`, nd.text ? `<span class="rv phu">${esc(cat(nd.text, 160))}</span>` : '<span class="chip loi">Trống</span>');
    if (x.loai === 'b2' || x.loai === 'b3') h += hang_('Ảnh của bài', (nd.anh || []).length ? `<span class="chip ok">${nd.anh.length} ảnh</span>` : '<span class="chip loi">Chưa có ảnh</span>');
    if (x.loai === 'video') h += hang_(`File video · cột ${kp ? cotK(kp.cot.video) : cotK(CAI_DAT.COT_VIDEO_K1)}`, nd.tep ? `<span class="chip ok">${esc(nd.tep.ten)} · ${(nd.tep.size / 1048576).toFixed(1)} MB</span>` : (x.xong ? '<span class="chip xam">—</span>' : '<span class="chip loi">Chưa có file</span>'));
    if (x.loai === 'manifest') h += hang_('Ảnh manifest · cột H', nd.anh ? '<span class="chip ok">Có ảnh — script tự ghép video 15 giây + nhạc</span>' : (x.xong ? '<span class="chip xam">—</span>' : '<span class="chip loi">Chưa có ảnh</span>'));
    const can = r.can || (nd.text ? canCmt(x, nd) : null);
    const cm = !x.xong ? '<span class="chip xam">Chờ đăng bài</span>' : r.cmtOk ? `<span class="chip ok">✓ Đủ comment</span><span class="mo">kiểm ${(r.kiem || []).length} lần</span>` : `<span class="chip cho">${(r.kiem || []).length ? 'Còn thiếu' : 'Chưa kiểm'}</span><span class="mo">kiểm ${(r.kiem || []).length}/${CAI_DAT.KIEM_CMT_TOI_DA}${r.guiBu ? ' · đã gửi bù ' + r.guiBu : ''}</span>`;
    h += hang_(`Comment${can ? ` · ${can.text.length} chữ + ${can.anh.length} ảnh` : ''}`, cm);
    if (!x.xong && nd.thieu && nd.thieu.length) h += `<div class="ghichu">⚠ Thiếu: ${esc(nd.thieu.join(', '))}</div>`;
    if (!x.xong && (r.lyDo || r.loi)) h += `<div class="ghichu">⚠ ${esc(r.lyDo || r.loi)}</div>`;
    if (!x.xong && r.khoaKhac && Date.now() - r.khoaKhac.luc < CAI_DAT.NHUONG_PHUT * 60000) h += `<div class="ghichu">🔒 ${r.khoaKhac.may === 'CAO' ? 'Máy Cao' : 'Máy Giao'} đang giữ chỗ từ ${gioStr(new Date(r.khoaKhac.luc))} — vẫn bấm <b>Đăng ngay</b> được (script sẽ hỏi lại)</div>`; // (6.26.4)
    const nut = [];
    if (x.xong && r.link) nut.push(`<a href="#" data-a="mobai" data-link="${esc(r.link)}">Mở bài ↗</a>`);
    if (!x.xong && r.tt !== 'dang') nut.push(`<button class="nut nho tim" data-a="soan" data-k="${x.k}" title="Làm hết mọi thứ (chữ, ảnh/video, vị trí, thẻ, nhóm…) rồi DỪNG trước nút Đăng — bạn bấm Đăng, script tự comment">✎ Soạn</button>`, `<button class="nut nho chinh" data-a="dangngay" data-k="${x.k}" title="Đăng ngay, không chờ giờ hẹn">▶ Đăng ngay</button>`);
    if (!x.ket && r.tt !== 'dang') nut.push(`<button class="phu-nut" data-a="boqua" data-k="${x.k}">Bỏ qua hôm nay</button>`);
    if (['bo', 'loi', 'thieu', 'khong_ro'].includes(r.tt)) nut.push(`<button class="phu-nut" data-a="khoiphuc" data-k="${x.k}">↺ Đưa lại vào hàng chờ</button>`);
    else if (r.tt === 'co_san' && r.may !== 'tay') nut.push(`<button class="phu-nut" data-a="khoiphuc" data-k="${x.k}" title="Script tưởng bài đã có trên trang (máy khác / đăng tay) nhưng thật ra chưa lên → đưa lại vào hàng chờ để đăng">↺ Thật ra chưa đăng — đăng lại</button>`); // (6.20.1)
    if (!x.xong && r.tt !== 'dang') nut.push(`<button class="phu-nut" data-a="danhdau" data-k="${x.k}" title="Bài đã lên trang mà script chưa nhận ra">✓ Đánh dấu đã đăng</button>`);
    if (r.may === 'tay') nut.push(`<button class="phu-nut" data-a="bodanhdau" data-k="${x.k}">Bỏ đánh dấu</button>`);
    if (nut.length) h += `<div class="r">${nut.join(' ')}</div>`;
    return h + '</div>';
  }
  // nút bên phải mỗi dòng trong lịch: chưa đăng → "Soạn" · đã đăng → "Mở link"
  function nutTimeline(x, ngay) {
    if (x.xong) return x.r.link ? `<button class="phu-nut tk link" data-a="mobai" data-link="${esc(x.r.link)}" title="Mở bài đã đăng ở tab mới">↗ Mở link</button>` : '';
    if (x.r.tt === 'dang') return '<span class="phu-nut tk dang"><span class="xoay"></span>Đang làm…</span>';
    if (x.r.daSoan && (lay('cho_tay6', null) || {}).slot === x.k) return '<span class="phu-nut tk dang">✎ Đã soạn — chờ bấm Đăng</span>';
    if (x.ket && !ngay) return '';
    return `<button class="phu-nut tk soan" data-a="soan" data-k="${x.k}"${ngay ? ` data-ngay="${ngay}"` : ''} title="${ngay ? 'Soạn thử bài của ngày mai ngay bây giờ (dừng trước nút Đăng)' : `Soạn sẵn ${esc(x.ten)} (dừng trước nút Đăng)`}">✎ Soạn</button>`;
  }
  // ---------------- tab Ngày mai ----------------
  function tabNgayMai() {
    const nm = ngayMai(); const dt = congNgay(1); const d = duLieu(); const s = trangThai(nm);
    const L = (() => { const cu = LICH.slice(); LICH.length = 0; lichNgay(nm, d).forEach((x) => LICH.push(x)); try { return tinhLich(s); } finally { LICH.length = 0; cu.forEach((x) => LICH.push(x)); } })();
    const ct = lay('cho_tay6', null);
    let html = `<div class="mo" style="margin:0 0 10px"><b>${THU[dt.getDay()]} ${nm.replace(/-/g, '/')}</b> · giờ dự kiến đã bốc ngẫu nhiên trong khung (ngày mai script tự đăng đúng giờ này). Bấm <b>✎ Soạn</b> để soạn thử ngay bây giờ: script làm hết mọi bước rồi dừng trước nút Đăng — bạn xem kỹ rồi bấm <b>Huỷ</b>.</div>`;
    if (ct && ct.mai) html += `<div class="ghichu">⚠ Đang có ${esc(ct.ten)} soạn thử dở trên trang — xem xong bấm Huỷ / đóng hộp. Nếu bấm Đăng thì bài lên trang NGAY HÔM NAY và ngày mai không đăng lại.</div>`;
    if (!d || !d.ngay || !d.ngay[nm]) html += '<div class="ghichu">Chưa đọc được nội dung ngày mai trong sheet — bấm "Đọc lại Lark sheet" ở tab Sắp tới.</div>';
    const tl = L.map((x) => {
      const nd = noiDungSlot(nm, x.k, d); const r = x.r;
      const lop = x.xong ? 'ok' : nd.thieu.length ? 'loi' : 'xam';
      const mo = x.xong ? `Đã lên ${gioStr(new Date(r.luc))}${r.lyDo ? ' · ' + r.lyDo : ''}` : nd.thieu.length ? '⚠ thiếu ' + nd.thieu.join(', ') : r.soanThu ? `Đã soạn thử lúc ${gioStr(new Date(r.soanThu))} · đủ nội dung` : '✓ đủ nội dung · tự động ' + phutStr(x.gioKH);
      return `<div class="it" data-a="chonmai" data-k="${x.k}"><div class="dm ${lop}">${x.xong ? '✓' : KY(x)}</div><div class="h">${phutStr(x.gioKH)} · ${esc(x.ten)}</div><div class="t">${esc(mo)}</div>${nd.thieu.length && !x.xong ? '' : nutTimeline(x, nm)}</div>`;
    }).join('');
    const chon = L.find((x) => x.k === uiTab.chonMai) || L[0];
    return html + `<div class="tlay"><div class="tl"><h4>Lịch ngày mai</h4>${tl}</div><div class="ct">${theSlotMai(chon, nm, d)}</div></div>`;
  }
  function theSlotMai(x, nm, d) {
    const nd = noiDungSlot(nm, x.k, d); const r = x.r;
    const kp = (x.kenh || 1) > 1 ? CAI_DAT.KENH[x.kenh] : null; const cotK = (i) => String.fromCharCode(65 + i);
    const cot = kp ? `cột ${cotK(kp.cot.cap)} (tab ${kp.tenTab}${nd.hang ? ' hàng ' + nd.hang : ''})` : { b1: 'cột B', b2: 'cột D', b3: 'cột F', video: 'cột E (tab Kênh 1)', manifest: 'cột G (tab Kênh 1)' }[x.loai];
    let h = `<div class="bai ${MAU[x.loai]}"><div class="bai-h"><span class="bai-t">${esc(x.ten)}<small>ngày mai · ${kp ? 'trang ' + esc(kp.ngan) : 'hẹn ' + phutStr(x.gioKH)}</small></span><span class="kq ${x.xong ? 'ok' : nd.thieu.length ? 'loi' : 'xam'}">${x.xong ? '✓ Đã lên' : nd.thieu.length ? 'Thiếu nội dung' : 'Chờ ngày mai'}</span></div>`;
    h += hang_('Giờ dự kiến', `<b>${phutStr(x.gioKH)}</b>`);
    h += hang_(`Nội dung · ${cot}`, nd.text ? `<span class="rv phu">${esc(cat(nd.text, 160))}</span>` : '<span class="chip loi">Trống</span>');
    if (x.loai === 'b2' || x.loai === 'b3') h += hang_('Ảnh của bài', (nd.anh || []).length ? `<span class="chip ok">${nd.anh.length} ảnh</span>` : '<span class="chip loi">Chưa có ảnh</span>');
    if (x.loai === 'video') h += hang_(`File video · cột ${kp ? cotK(kp.cot.video) : cotK(CAI_DAT.COT_VIDEO_K1)}`, nd.tep ? `<span class="chip ok">${esc(nd.tep.ten)} · ${(nd.tep.size / 1048576).toFixed(1)} MB</span>` : '<span class="chip loi">Chưa có file</span>');
    if (x.loai === 'manifest') h += hang_('Ảnh manifest · cột H', nd.anh ? '<span class="chip ok">Có ảnh</span>' : '<span class="chip loi">Chưa có ảnh</span>');
    if (nd.thieu.length) h += `<div class="ghichu">⚠ Thiếu: ${esc(nd.thieu.join(', '))} — bổ sung trong sheet rồi bấm Đọc lại Lark sheet</div>`;
    if (r.lyDo) h += `<div class="ghichu">${esc(r.lyDo)}</div>`;
    const nut = [];
    if (x.xong && r.link) nut.push(`<a href="#" data-a="mobai" data-link="${esc(r.link)}">Mở bài ↗</a>`);
    if (!x.xong && !nd.thieu.length && r.tt !== 'dang') nut.push(`<button class="nut nho tim" data-a="soan" data-k="${x.k}" data-ngay="${nm}">✎ Soạn thử ngay (không đăng)</button>`);
    if (x.xong && r.may === 'tay') nut.push(`<button class="phu-nut" data-a="bodanhdau" data-k="${x.k}" data-ngay="${nm}">Bỏ đánh dấu (ngày mai đăng lại)</button>`);
    return h + `<div class="hang" style="margin-top:8px">${nut.join('')}</div></div>`;
  }
  function tabHomNay() {
    const L = tinhLich(); const t = trangThaiChung(); const xongN = L.filter((x) => x.xong).length;
    const chon = L.find((x) => x.k === uiTab.chon) || L.find((x) => x.keTiep) || L[L.length - 1];
    let html = theViec() + khuThaoTac();
    html += `<div class="strip s-${t.den}"><span class="den ${t.den}${t.nhay ? ' nhay' : ''}"></span><span style="flex:1">${t.chu}</span><span class="kq ${xongN === L.length ? 'ok' : 'xam'}">${xongN}/${L.length} bài đã lên trang</span></div>`;
    { const sk = lay('sk6', null); if (sk && sk.ngay === homNay() && sk.loi && sk.loi.length) html += `<div class="ghichu" style="border-color:#e0245e;color:#e0245e"><b>🩺 Tự kiểm tra sáng ${gioStr(new Date(sk.luc))} phát hiện:</b> ${sk.loi.map(esc).join(' · ')}</div>`; } // (6.15)
    // (6.24) đã đăng (và đã bỏ/lỗi) ở trên, mỗi bài 1 dòng gọn → bài kế tiếp nổi bật → bài chưa đăng theo giờ dự kiến thật
    const DK = window.__smhDK = duKienLich(L);
    const xongDs = L.filter((x) => x.ket).sort((a, b) => (a.xong && a.r.luc ? a.r.luc : lucPhut(a.gioKH)) - (b.xong && b.r.luc ? b.r.luc : lucPhut(b.gioKH)));
    const kt0 = L.find((x) => x.keTiep && !x.ket);
    const choDs = L.filter((x) => !x.ket && x !== kt0).sort((a, b) => ((DK[a.k] || {}).luc || lucPhut(a.gioKH)) - ((DK[b.k] || {}).luc || lucPhut(b.gioKH)));
    const dongIt = (x, gon) => {
      const nl = nhanSlot(x); const lop = lopTt(x) || 'xam';
      const nutSoan = gon ? (x.xong && x.r.link ? `<button class="phu-nut tk link rong" data-a="mobai" data-link="${esc(x.r.link)}" title="Mở bài đã đăng ở tab mới để kiểm tra">↗ Mở bài</button>` : '') : nutTimeline(x, ''); // (6.28.3) nút mở bài rộng bằng nút Soạn
      return `<div class="it${gon ? ' gon' : ''}${x === kt0 ? ' ketiep' : ''}${x.k === chon.k ? ' sel' : ''}" data-a="chon" data-k="${x.k}"><div class="dm ${lop}">${x.xong ? '✓' : KY(x)}</div><div class="h">${nl.gio} · ${esc(x.ten)}${gon ? ` <span class="t">${esc(nl.mo.replace(/^Đã lên lúc \d{1,2}:\d{2} · /, ''))}</span>` : ''}</div>${gon ? '' : `<div class="t">${esc(nl.mo)}</div>`}${nutSoan}</div>`;
    };
    // (6.28.3) chia 3 khung Sáng / Chiều / Tối, mỗi khung 1 viền màu + số bài đã đăng + thanh tiến độ (giờ = giờ đã lên, chưa lên thì giờ dự kiến)
    const gioIt = (x) => { const t = x.xong && x.r.luc ? x.r.luc : ((DK[x.k] || {}).luc || lucPhut(x.gioKH)); const d0 = new Date(t); return d0.getHours() * 60 + d0.getMinutes(); };
    const KHUNG3 = [['sang', '☀️ SÁNG', '06:00–12:00', '#e0a21a', 0, 720], ['chieu', '🌤 CHIỀU', '12:00–18:00', '#3ea6ff', 720, 1080], ['toi', '🌙 TỐI', '18:00–22:30', '#9b7bf0', 1080, 1e9]];
    const thuTu = xongDs.concat(kt0 ? [kt0] : [], choDs);
    const tl = KHUNG3.map(([k3, ten, gio, mau, a0, b0]) => {
      const ds = thuTu.filter((x) => { const g = gioIt(x); return g >= a0 && g < b0; }); const xn = ds.filter((x) => x.xong).length; const du = ds.length && xn === ds.length;
      return `<div class="khung3" data-k3="${k3}" style="--m:${mau}"><div class="k3d">${ten} <span class="mo">${gio}</span><span class="k3so${du ? ' du' : ''}">${xn}/${ds.length} đã đăng${du ? ' ✓' : ''}</span></div><div class="k3t"><i style="width:${ds.length ? Math.round(xn / ds.length * 100) : 0}%"></i></div><div class="k3b">${ds.length ? ds.map((x) => (x === kt0 ? '<div class="tl-moc">▶ Bài kế tiếp</div>' : '') + dongIt(x, !!x.ket)).join('') : '<div class="k3rong">Không có bài trong khung này</div>'}</div></div>`;
    }).join('');
    const ng = Object.values(trangThai().ngoai || {});
    const ngoai = ng.length ? `<div class="the-nd"><div class="nhan">Video/manifest đăng ngoài lịch hôm nay (${ng.length})</div>${ng.map((r) => `<div class="dong"><span>${gioStr(new Date(r.luc))}</span><span>${esc(cat(r.text, 60) || '(không có chữ)')} · ${r.cmtOk ? '<span class="chip ok">đủ comment</span>' : `<span class="chip cho">kiểm ${(r.kiem || []).length}/3</span>`}${r.link ? ` <a href="#" data-a="mobai" data-link="${esc(r.link)}">Mở ↗</a>` : ''}</span></div>`).join('')}</div>` : '';
    const d = new Date(); const dl = duLieu();
    const mo = `<div class="mo" style="margin:0 0 10px">${THU[d.getDay()]} ${homNay().replace(/-/g, '/')} · ${LICH.filter((x) => (x.kenh || 1) === 1).length} bài kênh 1${LICH.some((x) => x.them) ? ` (có ${LICH.filter((x) => x.them).length} bài thêm theo sheet)` : ''}${LICH.some((x) => x.kenh > 1) ? ` + ${LICH.filter((x) => x.kenh > 1).length} video kênh 2, 3` : ''}, kênh 1 rải đều 06:30–20:00 (nhiều bài thì tới 21:00) · bài trễ cách nhau ${CAI_DAT.CACH_BU_PHUT} phút, sát giờ còn nhiều bài thì 15 phút · quá ${CAI_DAT.GIO_CHOT} thì bỏ${dl ? ` · sheet đọc lúc ${gioStr(new Date(dl.luc))}` : ''}</div>`;
    return html + `<div class="tlay"><div class="tl${L.length > 12 ? ' nho' : ''}"><h4>Lịch hôm nay · ${xongN}/${L.length} đã đăng</h4>${tl}</div><div class="ct">${mo}${chon ? theSlot(chon) : '<div class="the-nd"><div class="mo">Hôm nay không có bài nào script tự đăng (kênh 1 đặt mức 0 = đăng tay, hoặc sheet chưa có bài). Bài đăng tay trên trang kênh 1 vẫn được tự comment + gắn thẻ.</div></div>'}${ngoai}</div></div>`;
  }

  // ---------------- tab Sắp tới ----------------
  function nutLon(loai, ic, ten, tt, mo, tip) {
    const { tt: st } = ttYC(loai);
    return `<button class="big${st === 'run' ? ' run' : st === 'xong' ? ' xong' : ''}" data-a="${loai}" title="${esc(tip)}"><span class="bi"><span>${st === 'run' ? '↻' : st === 'xong' ? '✓' : ic}</span></span><span class="bt"><b>${st === 'run' ? tt.dang : st === 'xong' ? tt.xong : ten}</b><small>${mo}</small></span></button>`;
  }
  function tabSapToi() {
    const d = duLieu();
    let html = `<div class="acts">${nutLon('docsheet', '↻', 'Đọc lại Lark sheet', { dang: 'Đang đọc sheet…', xong: 'Đã đọc xong!' }, d ? `Đọc lúc <b>${gioStr(new Date(d.luc))}</b> · tự đọc ${CAI_DAT.GIO_DOC_NHE} và ${CAI_DAT.GIO_DOC_CHOT}` : 'Chưa đọc — bấm để đọc', 'Đọc lại cả 2 tab trong Lark sheet (2 lượt gọi Lark)')}
      <button class="big sheet" data-a="mosheet"><span class="bi"><span>▦</span></span><span class="bt"><b>Mở sheet Bài viết</b><small>Tab "Bài viết kênh 1" (Bài 1/2/3)</small></span></button>
      <button class="big sheet" data-a="mosheetvideo"><span class="bi"><span>▦</span></span><span class="bt"><b>Mở sheet Video/Manifest</b><small>Tab "Kênh 1 Vòng Trầm Hương SMH"</small></span></button></div>`;
    if (!d) return html;
    if (d.loiCot) html += `<div class="ghichu">${esc(d.loiCot)}</div>`;
    if (false) for (const c of chuaNgay(d)) html += `<div class="ghichu"><b>⚠ ${esc(c.chu)}.</b> Script chỉ đăng những hàng có ghi ngày đăng, nên các hàng này đang bị tính là "thiếu". Điền ngày vào ô đó rồi bấm "Đọc lại Lark sheet". <button class="nut nho chinh" data-a="${c.nut}">▦ Mở sheet</button></div>`;
    html += '<div class="ghi">Đỏ = còn thiếu (hôm nay / ngày mai cần bổ sung sớm) · vàng = ngày xa hơn.</div><table class="st"><tr><th>Ngày</th><th>Bài viết</th><th>Video</th><th>Manifest</th></tr>';
    const s = trangThai();
    for (let i = 0; i <= 3; i++) {
      const dt = congNgay(i); const ngay = ngayStr(dt); if (!d.ngay[ngay]) continue;
      const lop = i <= 1 ? 'loi' : 'cho';
      const o = (loais) => lichNgay(ngay, d).filter((it) => loais.includes(it.loai)).map((it) => {
        if (i === 0 && XONG.includes((s.s[it.k] || {}).tt)) return `<div class="mk ok">✓ ${it.ten}: đã lên</div>`;
        const nd = noiDungSlot(ngay, it.k, d); return nd.thieu.length ? `<div class="mk ${lop}" title="${esc(nd.thieu.join(', '))}">✕ ${it.ten}: thiếu ${esc(cat(nd.thieu.join(', '), 40))}</div>` : `<div class="mk ok">✓ ${it.ten}</div>`;
      }).join('');
      let t = thieuCuaNgay(ngay, d) || []; if (i === 0) t = t.filter((x) => !XONG.includes((s.s[x.k] || {}).tt));
      const tag = i === 0 ? ' <span class="chip ok" style="margin:0">Hôm nay</span>' : i === 1 ? ' <span class="chip xam" style="margin:0">Ngày mai</span>' : '';
      if (t.length >= 9 && t.filter((x) => /^k[2-4]|^kenh/.test(x.k)).length < t.length - 8) { html += `<tr class="dau ${i <= 1 ? 'thieu' : 'xa'}"><td class="ng"><b>${THU[dt.getDay()]}</b> ${ngay.slice(0, 5).replace('-', '/')}${tag}</td><td colspan="3"><div class="mk ${lop}">✕ Chưa nhập bài nào cho ngày này (tab Bài viết cột H / tab Kênh 1 cột K)</div></td></tr>`; continue; }
      html += `<tr class="dau ${t.length ? (i <= 1 ? 'thieu' : 'xa') : ''}"><td class="ng"><b>${THU[dt.getDay()]}</b> ${ngay.slice(0, 5).replace('-', '/')}${tag}<div class="mk ${t.length ? lop : 'ok'}">${t.length ? '⚠ Thiếu ' + t.length + ' bài' : '✓ Đủ'}</div></td><td>${o(['b1', 'b2', 'b3'])}</td><td>${o(['video'])}</td><td>${o(['manifest'])}</td></tr>`;
    }
    return html + '</table>';
  }

  // ---------------- tab Hôm qua / Lịch sử ----------------
  function tabHomQua() {
    const d = congNgay(-1); const ngay = ngayStr(d); const s = lay('ngay6_' + ngay, null);
    let h = `<div class="mo" style="margin:0 0 10px"><b>${THU[d.getDay()]} ${ngay.replace(/-/g, '/')}</b> — các bài hôm qua</div>`;
    if (!s) return h + '<div class="the-nd"><div class="mo">Hôm qua bản 6.0 chưa chạy nên chưa có dữ liệu.</div></div>';
    h += '<table class="ls"><tr><th>Giờ</th><th>Bài</th><th>Kết quả</th></tr>';
    LICH_GOC.concat(Object.keys(s.s || {}).filter((k) => /^(k[2-4][a-h]|[vm][4-9])$/.test(k)).sort().map((k) => ({ k, ten: tenSlot(k) }))).map((it) => ({ it, r: (s.s || {})[it.k] || { tt: 'cho' } })).sort((a, b) => (a.r.luc || 9e15) - (b.r.luc || 9e15)).forEach(({ it, r }) => {
      const ok = XONG.includes(r.tt);
      h += `<tr><td>${ok ? gioStr(new Date(r.luc)) : '—'}</td><td><b>${it.ten}</b></td><td>${ok ? `<span class="chip ok" style="margin:0">Đã lên</span> ${tenMay(r.may)} · ${r.cmtOk ? 'đủ comment' : 'comment chưa xác nhận'}${r.link ? ` · <a href="#" data-a="mobai" data-link="${esc(r.link)}">Mở ↗</a>` : ''}` : `<span class="chip loi" style="margin:0">Chưa lên</span> ${esc(r.lyDo || r.loi || '')}`}</td></tr>`;
    });
    return h + `</table><div class="mo" style="margin-top:8px">Báo cáo cuối ngày: ${s.baoCao ? 'đã gửi lúc ' + gioStr(new Date(s.baoCao)) + (s.baoCaoMay ? ' (' + tenMay(s.baoCaoMay) + ')' : '') : 'chưa gửi'}</div>`;
  }
  function tabLichSu() {
    let h = '<table class="ls"><tr><th>Ngày</th><th>Kết quả</th><th>Chi tiết</th></tr>';
    for (let i = 0; i < 7; i++) {
      const d = congNgay(-i); const ngay = ngayStr(d); const s = lay('ngay6_' + ngay, null);
      const nh = `<b>${THU[d.getDay()]}</b> ${ngay.slice(0, 5)}${i ? '' : '<br><span class="mo">hôm nay</span>'}`;
      if (!s) { h += `<tr><td>${nh}</td><td><span class="chip xam" style="margin:0">Chưa có dữ liệu</span></td><td class="mo">bản 6.0 chưa chạy ngày này</td></tr>`; continue; }
      const LN = LICH_GOC.concat(Object.keys(s.s || {}).filter((k) => /^(k[2-4][a-h]|[vm][4-9])$/.test(k)).sort().map((k) => ({ k, ten: tenSlot(k) })));
      const xong = LN.filter((it) => XONG.includes(((s.s || {})[it.k] || {}).tt));
      const chua = LN.filter((it) => !XONG.includes(((s.s || {})[it.k] || {}).tt));
      h += `<tr><td>${nh}</td><td><span class="chip ${xong.length === LN.length ? 'ok' : i ? 'loi' : 'cho'}" style="margin:0">${xong.length}/${LN.length} bài</span></td><td>${chua.length ? (i ? 'Chưa lên: ' : 'Còn chờ: ') + chua.map((x) => x.ten).join(', ') : 'Đủ cả ' + LN.length + ' bài'}${s.baoCao ? '<div class="mo">Đã gửi báo cáo ' + gioStr(new Date(s.baoCao)) + '</div>' : ''}</td></tr>`;
    }
    return h + '</table>';
  }

  // ---------------- tab Manifest ----------------
  function buocMF(ten, trangThai) { // trangThai: '' chưa · 'dang' · 'xong' · 'loi'
    const ic = trangThai === 'xong' ? '✓' : trangThai === 'dang' ? '<span class="xoay"></span>' : trangThai === 'loi' ? '✕' : '○';
    return `<div class="mfb ${trangThai}"><span class="mfi">${ic}</span><span>${ten}</span></div>`;
  }
  let fontNapUI = null;
  function khuFont() {
    if (!fontNapUI) fontNapUI = napFontChon().catch(() => { fontNapUI = null; }); // nạp font để xem mẫu
    const c = fontChon(); const ds = dsFont(); const them = Object.keys(fontThem());
    const chon = (vai, nhan) => `<label class="mfchon"><span>${nhan}</span><select data-o="font_${vai}">${ds.map((f) => `<option value="${esc(f)}"${f === c[vai] ? ' selected' : ''}>${esc(f)}${FONT_GOC.includes(f) ? '' : ' (tải thêm)'}</option>`).join('')}</select></label>`;
    const ff = (f) => `font-family:'${esc(f).replace(/'/g, '')}',sans-serif`;
    const veLai = mf.ds.some((x) => x.nen && x.tt !== 'xong');
    return `<div class="hang"><b>3.</b> Font chữ ${chon('td', 'Tiêu đề')}${chon('than', 'Thân bài')}${chon('cmt', 'Lời kêu gọi (Cmt…)')}<label class="nut nho">⬆ Thêm font…<input type="file" accept=".ttf,.otf,.woff,.woff2" data-a="themfont" style="display:none"></label></div>
      <div class="mffont"><div style="${ff(c.td)};color:#f8ef3b;font-size:22px">TIÊU ĐỀ MẪU: ĐÓN NHẬN TÀI LỘC</div><div style="${ff(c.than)};font-size:19px">Thân bài mẫu: năng lượng tốt đang tìm đến bạn</div><div style="${ff(c.cmt)};font-size:17px">Cmt "đón nhận" để đón nhận năng lượng</div></div>
      ${them.length ? `<div class="hang"><span class="mo">Font đã tải thêm:</span>${them.map((f) => `<span class="chip xam">${esc(f)} <button class="phu-nut" data-a="xoafont" data-ten="${esc(f)}" title="Xoá font này">✕</button></span>`).join(' ')}</div>` : ''}
      ${veLai ? `<div class="hang"><button class="nut nho${mf.chay ? ' chay' : ''}" data-a="velaifont" ${mf.chay || mf.dan ? 'disabled' : ''}>🔤 Vẽ lại các ảnh bên dưới bằng font đang chọn (giữ ảnh nền)</button></div>` : ''}`;
  }
  const nguonMF = () => { const v = lay('mf_nguon6', ''); return v === 'tay' || v === 'sheet' ? v : (chanLark() ? 'tay' : 'sheet'); }; // (6.31) chưa chọn: Lark hết lượt thì mặc định nhập trực tiếp
  function tabManifest() {
    const ni = nhacInfo(); const vung = lay('mf_vung6', 'G220:G223'); const t = mf.tien || {};
    const ban = mf.chay || mf.dan;
    let cotKQ = 'H'; try { cotKQ = docVungMF(vung).cotKQ; } catch (e) { /* */ }
    const tayMF = nguonMF() === 'tay'; const chuMF = lay('mf_chu6', '') || ''; const soKhoi = tachKhoiMF(chuMF).length; // (6.31)
    let h = `<div class="the-nd"><h4>🖼 Tạo ảnh manifest</h4><div class="mo">Tạo ảnh xem trước ngay trong popup → bấm từng ảnh để xem → chọn ảnh ưng ý → bấm Dán vào sheet (tab "Kênh 1 Vòng Trầm Hương SMH", cột bên phải ô chữ, ghi đè ảnh cũ).</div>
      <div class="hang"><b>1.</b><label class="nut nho${ui6.canhNen && !anhNenTam.length ? ' do' : ''}">📂 Chọn ảnh nền…<input type="file" accept="image/*" multiple data-a="chonnen" style="display:none"></label>${anhNenTam.length ? `<b>${anhNenTam.length} ảnh nền</b>` : '<span class="mo">chưa chọn (chọn nhiều ảnh một lúc, script dùng ngẫu nhiên)</span>'}</div>
      ${anhNenTam.length ? `<div class="anhs">${anhNenTam.slice(0, 30).map((f) => `<img src="${f.__url || (f.__url = URL.createObjectURL(f))}">`).join('')}</div>` : ''}
      <div class="hang"><b>2.</b> Nội dung <span class="mfseg"><button class="${tayMF ? 'on' : ''}" data-a="mfnguon" data-k="tay">✍ Nhập trực tiếp</button><button class="${tayMF ? '' : 'on'}" data-a="mfnguon" data-k="sheet">▦ Lấy từ sheet (${esc(vung)})</button></span>${tayMF ? `<span class="chip ok" data-mfdem>${soKhoi} khối → ${soKhoi} ảnh</span>` : ''}</div>
      ${tayMF ? `<textarea class="mfnhap" data-o="mfchu" rows="9" placeholder="Dán chữ y như ô sheet:\nDòng 1 = tiêu đề\nCác dòng giữa = thân bài\nDòng cuối = lời kêu gọi (Cmt…)\n\nCách 1 dòng trống = ảnh tiếp theo">${esc(chuMF)}</textarea><div class="mo">Dòng 1 = tiêu đề · dòng giữa = thân bài · dòng cuối = lời kêu gọi · cách nhau 1 dòng trống = ảnh mới · không cần Lark</div>`
        : `<div class="hang">Vùng ô chữ <input type="text" data-o="vung" value="${esc(vung)}" placeholder="G220:G223"><span class="mo">→ ảnh sẽ dán vào cột ${esc(cotKQ)} cùng hàng</span>${chanLark() ? '<span class="mo" style="color:var(--do-chu)">· Lark đang hết lượt — dùng "✍ Nhập trực tiếp" nếu chưa mở tab sheet Lark</span>' : ''}</div>`}
      ${khuFont()}
      <div class="hang"><b>4.</b><button class="nut chinh${ban ? ' chay' : ''}" data-a="taoanh" ${ban ? 'disabled' : ''}>${mf.chay ? '<span class="xoay"></span>Đang tạo ảnh…' : (tayMF ? `🖼 Tạo ${soKhoi || ''} ảnh` : '🖼 Tạo ảnh xem trước')}</button>${mf.ds.some((x) => x.blob && x.tt !== 'loi') ? `<button class="nut cam" data-a="taiallmf" ${ban ? 'disabled' : ''}>⬇ Tải tất cả (${mf.ds.filter((x) => x.blob && x.tt !== 'loi').length})</button>` : ''}${ui6.canhNen && !anhNenTam.length ? '<b style="color:var(--do-chu)">⚠ Bạn chưa chọn ảnh nền — bấm "📂 Chọn ảnh nền…" ở bước 1 trước</b>' : ''}</div>`;
    if (mf.tien) {
      const st = (b) => { const thu = ['doc', 'font', 'tao', 'xong']; const ti = thu.indexOf(t.buoc), bi = thu.indexOf(b); if (t.buoc === 'loi') return b === 'doc' && !mf.ds.length ? 'loi' : ''; if (t.buoc === 'dan' || t.buoc === 'daxong') return 'xong'; return ti > bi ? 'xong' : ti === bi ? (b === 'xong' ? 'xong' : 'dang') : ''; };
      const pt = t.n ? Math.round(((t.buoc === 'xong' || t.buoc === 'daxong' ? t.n : t.i) / t.n) * 100) : 0;
      h += `<div class="mfp">${buocMF(mf.tay ? 'Tách chữ đã nhập' : 'Đọc chữ trong sheet', st('doc'))}${buocMF('Nạp font chữ', st('font'))}${buocMF(`Tạo ảnh${t.n && (t.buoc === 'tao' || t.buoc === 'xong') ? ` ${t.buoc === 'xong' ? t.n : t.i + 1}/${t.n}` : ''}`, st('tao'))}${t.buoc === 'dan' || t.buoc === 'daxong' ? buocMF(`Dán vào sheet ${t.buoc === 'daxong' ? t.n : t.i + 1}/${t.n}`, t.buoc === 'daxong' ? 'xong' : 'dang') : ''}</div>
        ${t.n ? `<div class="thanh"><i style="width:${pt}%"></i></div>` : ''}<div class="mo" style="font-weight:700;color:${t.buoc === 'loi' ? 'var(--do-chu)' : 'var(--chu)'}">${esc(t.chu || '')}</div>`;
    }
    if (mf.ds.length) {
      const chon = mf.ds.filter((x) => x.chon && x.blob && x.tt !== 'xong').length; const daDan = mf.ds.filter((x) => x.tt === 'xong').length;
      h += `<div class="mfluoi">${mf.ds.map((x, i) => {
        const chip = x.tay && x.blob && x.tt !== 'loi' && x.tt !== 'dangtao' ? '<span class="chip ok">✓ Đã tạo</span>' : x.tt === 'xong' ? '<span class="chip ok">✓ Đã dán</span>' : x.tt === 'dang' ? '<span class="chip cho">Đang dán…</span>' : x.tt === 'dangtao' ? '<span class="chip cho">Đang tạo lại…</span>' : x.tt === 'loi' ? `<span class="chip loi" title="${esc(x.loi)}">⚠ ${esc(cat(x.loi, 30))}</span>` : '<span class="chip xam">Chưa dán</span>';
        return `<div class="mfo${x.chon ? ' chon' : ''}">${x.url ? `<img src="${x.url}" data-a="xemanh" data-i="${i}" title="Bấm để xem lớn">` : '<div class="mfrong">Lỗi</div>'}<div class="mft"><b>${x.tay ? "" : "Ô "}${x.oKQ}</b>${chip}</div><div class="mfc" title="${esc(x.chu)}">${esc(cat(x.chu.split('\n').find((l) => l && !/^#manifest$/i.test(l.trim())) || '', 40))}</div><div class="mfn">${x.blob && x.tt !== 'loi' ? `<button class="phu-nut xanh" data-a="taianhmf" data-i="${i}">⬇ Tải</button>` : ''}${x.blob && x.tt !== 'xong' && !x.tay ? `<button class="phu-nut" data-a="chonanh" data-i="${i}">${x.chon ? '☑ Dán' : '☐ Không dán'}</button>` : ''}<button class="phu-nut" data-a="taolai" data-i="${i}" ${ban ? 'disabled' : ''}>↻ Tạo lại</button></div></div>`;
      }).join('')}</div>
      ${mf.tay ? '<div class="hang"><span class="mo">Ảnh tạo từ chữ nhập trực tiếp: bấm ⬇ Tải trên từng ảnh hoặc "⬇ Tải tất cả" · bấm ảnh để xem lớn · ↻ Tạo lại = đổi ảnh nền khác</span></div>' : `<div class="hang"><button class="nut chinh${mf.dan ? ' chay' : ''}" data-a="dananh" ${chon && !ban ? '' : 'disabled'}>${mf.dan ? '<span class="xoay"></span>Đang dán vào sheet…' : `📋 Dán ${chon} ảnh đã chọn vào sheet`}</button><span class="mo">${daDan ? `Đã dán ${daDan} ảnh · ` : ''}Bấm ảnh để xem lớn · ↻ Tạo lại = đổi ảnh nền khác</span></div>`}`;
    }
    h += '</div>';
    h += `<div class="the-nd"><h4>🎵 Nhạc nền video manifest ${ni ? '<span class="chip ok">đã có</span>' : '<span class="chip loi">chưa có</span>'}</h4>
      ${ni ? `<div><b>${esc(ni.ten)}</b> · ${(ni.size / 1024).toFixed(0)} KB · lưu ${gioStr(new Date(ni.luc))} ${ngayStr(new Date(ni.luc)).slice(0, 5).replace('-', '/')}${ni.tu === 'o' ? ' (lấy từ ô dự phòng)' : ''}</div>` : '<div class="ghichu">Máy này chưa có nhạc — tới giờ đăng manifest script sẽ lấy nhạc ở ô dự phòng.</div>'}
      <div class="hang"><label class="nut nho chinh">⬆ Tải nhạc lên…<input type="file" accept="audio/*,.mp3,.m4a,.wav" data-a="chonnhac" style="display:none"></label>${ni ? `<button class="nut nho${ui6.nhac ? ' do' : ''}" data-a="nghenhac">${ui6.nhac ? '■ Dừng' : '▶ Nghe thử'}</button>` : ''}<span class="mo">Ô nhạc dự phòng</span><input type="text" data-o="onhac" value="${esc(lay('o_nhac6', CAI_DAT.O_NHAC_DU_PHONG))}"><button class="nut nho" data-a="laynhac">Lấy nhạc từ ô này</button></div>
      <div class="mo">Nhạc lưu trong Tampermonkey của máy này (khởi động lại máy vẫn còn). Mỗi máy cần tải 1 lần.</div></div>`;
    return h;
  }
  // ---------------- tab Comment (6.9): sửa comment mặc định + câu CTA nhóm Zalo ----------------
  const TEN_LOAI_CMT = { b1: 'Bài 1', b2: 'Bài 2', b3: 'Bài 3', video: 'Video', manifest: 'Manifest' };
  function nhapCmt() { if (!ui6.cmt) { const c = cauHinhCmt(); ui6.cmt = { goc: c.goc, gocHx: c.gocHx, link: c.link, cta: c.cta.join('\n'), bat: c.bat, loai: Object.assign({}, c.loai), kenh: Object.assign({}, c.kenh), sua: false }; } return ui6.cmt; }
  function cmtTuNhap(n) { return { goc: n.goc.replace(/\s+$/, ''), gocHx: String(n.gocHx || '').replace(/\s+$/, ''), link: n.link.trim(), cta: n.cta.split('\n').map((x) => x.trim()).filter(Boolean), bat: !!n.bat, loai: n.loai, kenh: n.kenh }; }
  function nhapThe() { if (!ui6.the) { const k = khoThe(); ui6.the = { video: k.video.join('\n'), video2: k.video2.join('\n'), video3: k.video3.join('\n'), video4: k.video4.join('\n'), manifest: k.manifest.join('\n'), sua: false }; } return ui6.the; }
  const truongThe = () => ((ui6.kenhThe || 1) === 1 ? 'video' : 'video' + ui6.kenhThe); // (6.19.3) ô thẻ video đang sửa của kênh nào
  const dsThe = (x) => String(x || '').split('\n').map((y) => y.trim()).filter(Boolean);
  function tabComment() {
    const n = nhapCmt(); const c = cauHinhCmt(); const db = lay('cmt6_dongbo', 0);
    const soCau = n.cta.split('\n').map((x) => x.trim()).filter(Boolean).length;
    let h = `<div class="the-nd"><h4>💬 Comment mặc định <span class="mo">(Bài 3 · Video · Manifest)</span></h4>
      <textarea class="cmtta" rows="9" data-o="cmt_goc">${esc(n.goc)}</textarea>
      <div class="hang"><button class="nut nho" data-a="cmtgoc">↺ Về bản gốc</button><span class="mo">Bài 1 / Bài 2 vẫn lấy comment trong sheet (cột C / cột E)</span></div></div>`;
    h += `<div class="the-nd"><h4>📕 Comment kênh Trầm Hương Hà Xá <span class="mo">(video Hà Xá chỉ comment khung này, không CTA Zalo / ảnh của Sơn Mộc Hương)</span></h4>
      <textarea class="cmtta" rows="5" data-o="cmt_gochx">${esc(n.gocHx || '')}</textarea>
      <div class="hang"><button class="nut nho" data-a="cmtgochx">↺ Về bản gốc</button></div></div>`; // (6.26)
    h += `<div class="the-nd"><h4>📣 Lời kêu gọi vào nhóm Zalo <span class="chip ${n.bat ? 'ok' : 'xam'}">${n.bat ? 'đang BẬT' : 'đang TẮT'}</span></h4>
      <div class="hang"><label class="nut nho ${n.bat ? 'chinh' : ''}"><input type="checkbox" data-o="cmt_bat" ${n.bat ? 'checked' : ''}> Đăng thêm 1 comment CTA riêng</label></div>
      <div class="hang"><b>Link:</b><input type="text" class="cmtlink" data-o="cmt_link" value="${esc(n.link)}"></div>
      <div class="hang"><b>Áp cho:</b>${Object.keys(TEN_LOAI_CMT).map((k) => `<label class="cmtck"><input type="checkbox" data-o="cmt_loai" data-k="${k}" ${n.loai[k] ? 'checked' : ''}> ${TEN_LOAI_CMT[k]}</label>`).join('')}</div>
      <div class="hang"><b>Theo kênh:</b>${[1, 2, 3].map((c) => `<label class="cmtck" title="${esc(CAI_DAT.KENH[c].ten)} — bỏ tick thì kênh này không comment CTA Zalo (các comment khác vẫn làm)" style="font-size:11px"><input type="checkbox" data-o="cmt_kenh" data-k="${c}" ${(n.kenh || {})[c] !== false ? 'checked' : ''}> K${c}</label>`).join('')}</div>
      <div class="mo" style="margin:6px 0 4px"><b>Câu CTA</b> — mỗi dòng 1 câu (${soCau} câu). Mỗi bài trong ngày tự lấy 1 câu khác nhau, hết câu thì quay vòng.</div>
      <textarea class="cmtta" rows="12" data-o="cmt_cta">${esc(n.cta)}</textarea>
      <div class="hang"><button class="nut nho" data-a="ctamd">↺ Dùng lại 12 câu mẫu</button></div></div>`;
    h += `<div class="the-nd cmtluu"><div class="hang"><button class="nut chinh${n.dangLuu ? ' chay' : ''}" data-a="luucmt" ${n.dangLuu ? 'disabled' : ''}>${n.dangLuu ? '<span class="xoay"></span>Đang lưu…' : '💾 Lưu (áp dụng cho bài kế tiếp)'}</button><button class="nut nho" data-a="xemcmt">🎲 Xem thử</button>${n.sua ? '<button class="nut nho" data-a="huycmt">Huỷ thay đổi</button><b style="color:var(--do-chu)">● Có thay đổi chưa lưu</b>' : ''}</div>
      <div class="mo">Bản đang dùng: lưu lúc ${c.luc ? gioStr(new Date(c.luc)) + ' ' + ngayStr(new Date(c.luc)).slice(0, 5).replace('-', '/') + (c.may ? ' (' + (c.may === MAY ? 'máy này' : c.may === 'GIAO' ? 'Máy Giao' : 'Máy Cao') + ')' : '') : '— chưa sửa lần nào (đang dùng mặc định)'} · ${db ? 'đã đồng bộ với sheet (ô ' + CAI_DAT.O_CMT + ') lúc ' + gioStr(new Date(db)) : 'chưa đồng bộ với sheet'}. Lưu ở máy nào thì máy kia nhận bản mới ở lần đọc sheet kế tiếp (hoặc bấm Đọc lại Lark sheet).</div></div>`;
    const hCmt = h; h = ''; // (6.27.1) tách phần Comment / phần Thẻ
    // ---- kho thẻ video / manifest ----
    const t = nhapThe(); const kt = khoThe(); const dbt = lay('the6_dongbo', 0);
    const dem = (x) => x.split('\n').map((y) => y.trim()).filter(Boolean).length;
    h += `<div class="the-nd"><h4>🏷 Kho thẻ <span class="mo">(Video · Manifest — mỗi bài tự bốc ${CAI_DAT.SO_THE} thẻ, các bài trong ngày lấy bộ khác nhau)</span></h4>
      <div class="cmt2cot"><div><div class="mo"><b>Thẻ cho Video</b> — mỗi kênh 1 kho riêng, mỗi dòng 1 thẻ</div>
        <div style="display:flex;gap:6px;flex-wrap:wrap;margin:4px 0 6px">${KENH_ALL.map((c) => `<button class="tg ${(ui6.kenhThe || 1) === c ? 'ok' : ''}" data-a="chonkenhthe" data-k="${c}" title="${esc(CAI_DAT.KENH[c].ten)}">${CAI_DAT.KENH[c].anSo ? '' : 'Kênh ' + c + ' · '}${esc(CAI_DAT.KENH[c].ngan)} <b>${dem(t[c === 1 ? 'video' : 'video' + c])}</b></button>`).join('')}</div>
        <textarea class="cmtta" rows="12" data-o="the_video" placeholder="Để trống = video kênh này không gắn thẻ">${esc(t[truongThe()])}</textarea><button class="nut nho" data-a="themd" data-k="video">↺ Dùng lại kho mẫu (kênh ${ui6.kenhThe || 1})</button></div>
      <div><div class="mo"><b>Thẻ cho Manifest</b> — mỗi dòng 1 thẻ (${dem(t.manifest)} thẻ)</div><textarea class="cmtta" rows="12" data-o="the_manifest">${esc(t.manifest)}</textarea><button class="nut nho" data-a="themd" data-k="manifest">↺ Dùng lại kho mẫu</button></div></div>
      <div class="hang"><button class="nut chinh${t.dangLuu ? ' chay' : ''}" data-a="luuthe" ${t.dangLuu ? 'disabled' : ''}>${t.dangLuu ? '<span class="xoay"></span>Đang lưu…' : '💾 Lưu kho thẻ'}</button><button class="nut nho" data-a="xemthe">🎲 Xem thử thẻ hôm nay</button><button class="nut nho${hanKiemThe().den ? ' chinh' : ''}" data-a="xacnhanthe" title="Đã xem, vẫn dùng bộ thẻ này — tắt nhắc, 7 ngày sau nhắc lại">✓ Xác nhận vẫn dùng</button>${t.sua ? '<button class="nut nho" data-a="huythe">Huỷ thay đổi</button><b style="color:var(--do-chu)">● Có thay đổi chưa lưu</b>' : ''}</div>
      <div class="mo">Bản đang dùng: ${kt.luc ? 'lưu lúc ' + gioStr(new Date(kt.luc)) + ' ' + ngayStr(new Date(kt.luc)).slice(0, 5).replace('-', '/') : 'kho mẫu (chưa sửa)'} · ${dbt ? 'đã đồng bộ với sheet (ô ' + CAI_DAT.O_THE + ') lúc ' + gioStr(new Date(dbt)) : 'chưa đồng bộ với sheet'}. Thẻ nào Facebook không nhận thì script bỏ thẻ đó, gắn tiếp thẻ sau. ${(() => { const hk = hanKiemThe(); return hk.den ? '<b style="color:var(--do-chu)">● Đến hạn kiểm tra thẻ (' + hk.qua + ' ngày)</b>' : 'Kiểm tra thẻ gần nhất: ' + ngayStr(new Date(hk.luc)).slice(0, 5).replace('-', '/') + ' — 7 ngày sau sẽ nhắc lại.'; })()}</div>`;
    if (ui6.xemThe) { const kho = { video: dsThe(t.video), video2: dsThe(t.video2), video3: dsThe(t.video3), video4: dsThe(t.video4), manifest: dsThe(t.manifest) }; h += `<div class="cmtxem">${LICH.filter((it) => it.loai === 'video' || it.loai === 'manifest').map((it) => { const th = chonThe(it.loai, it.so, homNay(), kho, it.kenh || 1); return `<div class="cmtmau"><b>${esc(it.ten)}</b>${(it.kenh || 1) > 1 ? ` <span class="mo">(${esc(CAI_DAT.KENH[it.kenh].ngan)})</span>` : ''}<pre>${esc(th.length ? th.map((x, i) => (i + 1) + '. ' + x).join('\n') : '(kho thẻ kênh này đang trống — không gắn thẻ)')}</pre></div>`; }).join('')}</div><button class="phu-nut" data-a="dongxemthe">✕ Đóng xem thử</button>`; }
    h += '</div>';
    const hThe = h; h = hCmt;
    if (ui6.xemCmt) {
      const c2 = Object.assign(cauHinhCmt(), cmtTuNhap(n)); const ngay = homNay(); const d = duLieu(); const nd0 = d && d.ngay && d.ngay[ngay];
      const mau = (it) => { const goc = it.loai === 'b1' ? ((nd0 && nd0.bai && nd0.bai.cmt) || '(comment cột C trong sheet)') : it.loai === 'b2' ? ((nd0 && nd0.bai && nd0.bai.cmt2) || '(comment cột E trong sheet)') : c2.goc;
        if (!c2.bat || !c2.loai[it.loai] || !c2.cta.length) return goc;
        let seed = 0; for (const ch of ngay) seed = seed * 31 + ch.charCodeAt(0); const r = soNgau(seed); const thu = c2.cta.map((x, i) => [r(), i]).sort((a, b) => a[0] - b[0]).map((x) => x[1]);
        return `${goc}\n\n——— comment riêng ———\n${c2.cta[thu[LICH.findIndex((x) => x.k === it.k) % thu.length]]}\n>>> ${c2.link}`; };
      h += `<div class="the-nd"><h4>🎲 Xem thử comment hôm nay <button class="phu-nut" data-a="dongxemcmt">✕ Đóng</button></h4><div class="cmtxem">${LICH.map((it) => `<div class="cmtmau"><b>${esc(it.ten)}</b><pre>${esc(mau(it))}</pre></div>`).join('')}</div></div>`;
    }
    const phan = ui6.cmtPhan || 'cmt'; const hk2 = hanKiemThe();
    const bar = `<div class="ctabs"><button class="ctab ${phan === 'cmt' ? 'on' : ''}" data-a="cmtphan" data-k="cmt">💬 Comment</button><button class="ctab ${phan === 'the' ? 'on' : ''}" data-a="cmtphan" data-k="the">🏷 Thẻ${hk2.den ? '<span class="ctab-do">● đến hạn kiểm tra</span>' : ''}</button><span class="mo">${phan === 'cmt' ? 'Comment script tự gửi sau khi đăng bài' : 'Thẻ script gắn khi đăng video / manifest (mỗi kênh 1 kho)'}</span></div>`;
    return bar + (phan === 'the' ? hThe : h);
  }
  function khungXemAnh() {
    const i = ui6.xem; const x = mf.ds[i]; if (i == null || !x || !x.url) return '';
    return `<div class="mfxem" data-a="dongxem"><div class="mfxk"><div class="mfxd"><b>Ảnh ${i + 1}/${mf.ds.length} · dán vào ô ${x.oKQ}</b>${x.tt === 'xong' ? '<span class="chip ok">✓ Đã dán</span>' : ''}<span style="flex:1"></span><button class="nut nho" data-a="dongxem">✕ Đóng</button></div>
      <div class="mfxa"><button class="nut" data-a="xemanh" data-i="${(i - 1 + mf.ds.length) % mf.ds.length}">‹</button><img src="${x.url}"><button class="nut" data-a="xemanh" data-i="${(i + 1) % mf.ds.length}">›</button></div>
      <div class="hang" style="justify-content:center">${x.blob && x.tt !== 'xong' ? `<button class="nut nho ${x.chon ? 'chinh' : ''}" data-a="chonanh" data-i="${i}">${x.chon ? '☑ Sẽ dán ảnh này' : '☐ Không dán ảnh này'}</button>` : ''}<button class="nut nho" data-a="taolai" data-i="${i}" ${mf.chay || mf.dan ? 'disabled' : ''}>${x.tt === 'dangtao' ? '<span class="xoay"></span>Đang tạo lại…' : '↻ Tạo lại (đổi ảnh nền)'}</button>${x.tl < 1 ? `<span class="mo">chữ dài nên thu nhỏ còn ${Math.round(x.tl * 100)}%</span>` : ''}</div></div></div>`;
  }

  // ---------------- tab Hệ thống / Nhật ký ----------------
  function tabHeThong() {
    const sk = lay('suc_khoe', {}) || {}; const g = chanLark(); const ld = lay('lark_dem', {}) || {}; const d = duLieu();
    const hien = document.visibilityState === 'visible';
    const o = (ten, ok, chu) => `<div>${ok === null ? '⚪' : ok ? '🟢' : '🔴'} <b>${ten}</b><br><span class="mo">${chu}</span></div>`;
    const k = GM_getValue('khoa_dang_bai_that', {}) || {};
    const tai = lay('tai6', null) || {};
    const trai = `<div class="cot">
      <div class="the-nd"><h4>${g || sk.larkOk === false ? '🔴' : '🟢'} Lark: ${esc(g ? g.msg + (g.loai === 'quota' && g.thuLai ? ' — tự gọi thử lại lúc ' + gioStr(new Date(g.thuLai)) : '') : sk.larkOk === false ? (sk.larkLoi || 'lỗi') : 'hoạt động bình thường')}</h4><div class="mo">Sheet đọc lúc ${d ? ngayStr(new Date(d.luc)) + ' ' + gioStr(new Date(d.luc)) : 'chưa có'} · hôm nay đã gọi ${ld.ngay === homNay() ? ld.so || 0 : 0} lượt</div></div>
      <div class="the-nd"><h4>Kiểm tra hệ thống</h4><div class="skhoe">
      ${o('Tư cách Facebook', sk.tuCach ? !!sk.tuCachDung : null, sk.tuCach ? `${esc(sk.tuCach)} · ${gioStr(new Date(sk.tuCachLuc))}` : 'chưa kiểm')}
      ${o('Đúng trang', dungTrang(), dungTrang() ? CAI_DAT.TEN_NGAN : 'đang ở trang khác (đến giờ sẽ tự chuyển)')}
      ${o('Tab đang hiện', hien, hien ? 'tốt' : 'bị ẩn — đến giờ đăng sẽ không đăng được')}
      ${o('Tab làm việc', laTabChinh(), laTabChinh() ? (k.ghim ? 'tab này · ⭐ Main' : 'tab này <button class="phu-nut" data-a="dungtab">⭐ Đặt làm Main</button>') : 'một tab Facebook khác đang làm <button class="phu-nut" data-a="dungtab">Dùng tab này</button>')}
      ${o('Gửi tin Lark', sk.tinLuc ? !!sk.tinOk : null, sk.tinLuc ? `${sk.tinOk ? 'ổn' : esc(sk.tinLoi)} · ${gioStr(new Date(sk.tinLuc))}` : 'chưa gửi')}
      ${o('Đọc bài qua Facebook API', !coApi() ? false : sk.apiLuc ? !!sk.apiOk : null, (!coApi() ? 'chưa cài mã khoá' : sk.apiLuc ? `${sk.apiOk ? 'ổn' : esc(sk.apiLoi)} · ${gioStr(new Date(sk.apiLuc))}` : 'chưa đọc') + (coApi() && lay('fb_token_luc', 0) ? ` · mã dùng ${Math.floor((Date.now() - lay('fb_token_luc', 0)) / 864e5)}/${CAI_DAT.MA_KHOA_HAN_NGAY} ngày` : ''))}
      ${o('Nhạc nền manifest', !!nhacInfo(), nhacInfo() ? esc(nhacInfo().ten) : 'chưa có (tab Manifest)')}
      ${o('Tải sẵn đồ đăng', LA_GIAO ? !!tai.xongLuc : null, LA_GIAO ? (tai.xongLuc ? 'xong lúc ' + gioStr(new Date(tai.xongLuc)) : 'đang/chưa tải') : 'chỉ Máy Giao tải sẵn')}
      </div></div></div>`;
    const yc = (l) => ttYC(l).tt === 'run';
    const phai = `<div class="cot">
      <div class="the-nd"><h4>Máy này</h4><div class="hang"><button class="nut nho ${LA_GIAO ? 'chinh' : ''}" data-a="chonmay" data-may="GIAO">${LA_GIAO ? '● ' : ''}Máy Giao (chính)</button><button class="nut nho ${LA_CAO ? 'chinh' : ''}" data-a="chonmay" data-may="CAO">${LA_CAO ? '● ' : ''}Máy Cao (dự phòng)</button></div><div class="mo">Máy Giao đăng đúng giờ. Máy Cao chỉ đăng thay khi quá ${CAI_DAT.CAO_TRE_PHUT} phút mà trang vẫn chưa có bài (giữ chỗ ở ô ${CAI_DAT.O_KHOA} để 2 máy không đăng trùng).</div>
        <div class="hang"><button class="nut nho ${chayThu() ? 'vang' : ''}" data-a="chaythu" title="Bật: mọi bài đều chỉ soạn sẵn, dừng trước nút Đăng">${chayThu() ? '🧪 Chạy thử (mọi bài chỉ soạn): BẬT' : '🧪 Chạy thử (mọi bài chỉ soạn): TẮT'}</button>${dangHoan() ? '<button class="nut nho" data-a="bohoan">Bỏ hoãn</button>' : ''}</div></div>
      <div class="the-nd"><h4>Công cụ</h4><div style="display:flex;flex-wrap:wrap;gap:8px">
        <button class="nut nho${yc('tinthu') ? ' chay' : ''}" data-a="tinthu">${yc('tinthu') ? '<span class="xoay"></span>' : '✉ '}Gửi tin thử</button>
        <button class="nut nho${yc('taisan') ? ' chay' : ''}" data-a="taisan">${yc('taisan') ? '<span class="xoay"></span>' : '⬇ '}Tải sẵn đồ đăng</button>
        <button class="nut nho${coApi() ? '' : ' do'}" data-a="caima">🔑 ${coApi() ? 'Đổi mã khoá FB' : 'Cài mã khoá FB'}</button>
        ${coApi() ? '<button class="nut nho" data-a="kiemma">Kiểm tra mã khoá</button>' : ''}
        <button class="nut nho do" data-a="baoloi">📋 Báo lỗi</button></div>
        <div class="mo" style="margin-top:6px">${esc(kqYC('tinthu') || kqYC('taisan') || '')}</div></div>
      <div class="mo">Báo cáo cuối ngày → nhóm Marketing · lỗi khi đăng → nhóm Đăng bài fb · Bản ${PHIEN_BAN} · ${TEN_MAY}</div></div>`;
    return `<div class="lu2">${trai}${phai}</div>` + khungTuNang();
  }
  function tabHeThongGop() { // (6.33) gộp Hệ thống + Nhật ký: 2 nút chuyển
    const phan = ui6.htPhan === 'nk' ? 'nk' : 'tt';
    const bar = `<div class="ctabs"><button class="ctab ${phan === 'tt' ? 'on' : ''}" data-a="htphan" data-k="tt">🩺 Tình trạng</button><button class="ctab ${phan === 'nk' ? 'on' : ''}" data-a="htphan" data-k="nk">📜 Nhật ký</button><span class="mo">${phan === 'tt' ? 'Kết nối Lark / Facebook, máy này, công cụ' : 'Mọi bước script đã làm · giữ 7 ngày'}</span></div>`;
    return bar + (phan === 'nk' ? tabNhatKy() : tabHeThong());
  }
  // ---- (6.33) tab MỨC ĐẶT: số bài mỗi ngày + giờ đăng từng kênh (bản nháp giữ trong ui6.md tới khi bấm Lưu) ----
  const MD_DONG = [['k1v', 1, 'Video'], ['k1b', 1, 'Bài viết (hàng)'], ['k1m', 1, 'Manifest'], ['k2', 2, 'Video'], ['k3', 3, 'Video'], ['k4', 4, 'Video']];
  function nhapMD() { if (!ui6.md) { const m = mucDat(); const g = gioDang(); ui6.md = { muc: {}, gio: {} }; for (const k of Object.keys(MUC_MD)) ui6.md.muc[k] = m[k]; for (const k of Object.keys(GIO_MD)) ui6.md.gio[k] = g[k].slice(); } return ui6.md; }
  function mdDoi() { if (!ui6.md) return false; const m = mucDat(); const g = gioDang(); return Object.keys(MUC_MD).some((k) => +ui6.md.muc[k] !== m[k]) || Object.keys(GIO_MD).some((k) => ui6.md.gio[k].join('-') !== g[k].join('-')); }
  function tabMucDat() {
    const n = nhapMD(); const m = mucDat(); const g = gioDang(); const doi = mdDoi();
    const yNghia = (k, v) => { if (k === 'k1v' || k === 'k1b' || k === 'k1m') return +v === 0 ? '<span class="md-tay">✋ Đăng tay</span> script không tự đăng, không báo thiếu; bài đăng tay trên trang được tự comment' + (k === 'k1b' ? '' : ' + gắn thẻ, cảm xúc') : `<span class="md-tu">⚙ Tự đăng</span> ít hơn ${v} ${k === 'k1b' ? 'hàng (' + (+v * 3) + ' bài)' : k === 'k1m' ? 'manifest đủ chữ + ảnh' : 'video có file'} → báo thiếu`;
      return +v === 0 ? '<span class="md-tay">⏸ Tạm dừng</span> không báo thiếu; dòng nào đủ (đã duyệt, có video) vẫn đăng' : `<span class="md-tu">⚙ Tự đăng</span> ít hơn ${v} video sẵn sàng → báo thiếu`; };
    const oSo = (k) => `<div class="md-so"><button class="md-b" data-a="mdcong" data-k="${k}" data-d="-1" ${+n.muc[k] <= 0 ? 'disabled' : ''}>−</button><input type="number" min="0" max="20" data-o="md_${k}" value="${esc(n.muc[k])}"><button class="md-b" data-a="mdcong" data-k="${k}" data-d="1" ${+n.muc[k] >= 20 ? 'disabled' : ''}>+</button></div>`;
    let h = `<div class="md-wrap"><div class="the-nd md"><h4>📊 Số bài mỗi ngày</h4><div class="mo">Đặt <b>0</b> cho loại kênh 1 đăng tay bằng điện thoại. Từ 3 lần mức đặt trở lên → cảnh báo "quá nhiều" (dễ là nhập nhầm cột Ngày đăng).</div>
      <table class="mdt"><tr><th>Kênh</th><th>Loại</th><th>Mức / ngày</th><th>Script sẽ làm</th></tr>`;
    let cu = 0;
    for (const [k, c, loai] of MD_DONG) { h += `<tr class="${+n.muc[k] !== m[k] ? 'md-moi' : ''}">${c !== cu ? `<td rowspan="${MD_DONG.filter((x) => x[1] === c).length}" class="md-k">${esc(tenKenhDai(c))}</td>` : ''}<td>${loai}</td><td>${oSo(k)}</td><td class="md-y">${yNghia(k, n.muc[k])}</td></tr>`; cu = c; }
    h += '</table></div>';
    const oGio = (k, i) => `<input type="text" class="md-gio" inputmode="numeric" maxlength="5" placeholder="${k === 'k1' ? (i ? '20:00' : '06:30') : 'hh:mm'}" data-o="mdg_${k}_${i}" value="${esc(n.gio[k][i] || '')}">`;
    const ghiChu = { k1: 'Script rải đều các bài kênh 1 trong khung (bài đầu – bài cuối)', k2: 'Để trống = như cũ: trước bài đầu kênh 1 khoảng 5–15 phút', k3: 'Để trống = như cũ: trước bài đầu kênh 1 khoảng 5–15 phút', k4: 'Luôn đăng trong khung; lỡ khung thì đăng bù ngay khi được (tới 21:30)' };
    h += `<div class="the-nd md"><h4>⏰ Giờ đăng</h4><div class="mo">Giờ chọn ngẫu nhiên trong khung, 2 máy ra cùng giờ. Lưu xong thì các bài <b>chưa đăng</b> hôm nay được xếp lại ngay.</div><table class="mdt"><tr><th>Kênh</th><th>Từ</th><th>Đến</th><th>Ghi chú</th></tr>`;
    for (const k of Object.keys(GIO_MD)) { const c = +k.slice(1); const trong = !n.gio[k][0] && !n.gio[k][1];
      h += `<tr class="${n.gio[k].join('-') !== g[k].join('-') ? 'md-moi' : ''}"><td class="md-k">${esc(tenKenhDai(c))}</td><td>${oGio(k, 0)}</td><td>${oGio(k, 1)}</td><td class="md-y">${trong ? '<span class="md-tay">như cũ</span> ' : ''}${ghiChu[k]}${k !== 'k1' && !trong ? ` <button class="phu-nut" data-a="mdxoagio" data-k="${k}">✕ Bỏ khung</button>` : ''}${k === 'k4' && (n.gio[k][0] !== '13:30' || n.gio[k][1] !== '14:00') ? ' <button class="phu-nut" data-a="mdgiohx">↺ 13:30–14:00</button>' : ''}</td></tr>`; }
    h += '</table></div>';
    { const L = tinhLich(); const theo = (c) => L.filter((x) => (x.kenh || 1) === c); const chip = (x) => `<span class="chip ${x.xong ? 'ok' : x.r.tt === 'bo' ? 'xam' : ''}" style="margin:2px 4px 2px 0">${esc(x.ten.replace(/^.*· /, ''))} ${x.xong && x.r.luc ? '✓ ' + gioStr(new Date(x.r.luc)) : typeof x.gioKH === 'number' ? phutStr(x.gioKH) : '—'}</span>`;
      h += `<div class="the-nd md"><h4>📅 Lịch hôm nay (theo cài đặt đang dùng)</h4>${KENH_ALL.map((c) => { const ds = theo(c); return `<div class="md-l"><b>${esc(tenKenhDai(c))}</b><span>${ds.length ? ds.map(chip).join('') : '<span class="mo">không có bài tự đăng</span>'}</span></div>`; }).join('')}</div>`; }
    const loiGio = kiemGioNhap(n.gio).loi;
    h += `<div class="md-chan"><button class="nut chinh${doi && !loiGio.length ? '' : ' md-mo'}" data-a="luumd">💾 Lưu cài đặt</button><button class="nut" data-a="huymd" ${doi ? '' : 'disabled'}>Huỷ thay đổi</button><button class="nut" data-a="mdmacdinh">↺ Về mặc định</button>
      <span class="mo">${loiGio.length ? '<b style="color:#e5484d">⚠ ' + esc(loiGio.join(' · ')) + '</b>' : doi ? '<b style="color:#d98b0b">● Có thay đổi chưa lưu</b>' : '✓ Đang dùng cài đặt đã lưu'} · Mức: ${m.luc ? gioStr(new Date(m.luc)) + ' ' + ngayStr(new Date(m.luc)).slice(0, 5).replace('-', '/') + (m.may ? ' (' + tenMay(m.may) + ')' : '') : 'mặc định'} · Giờ: ${g.luc ? gioStr(new Date(g.luc)) + ' ' + ngayStr(new Date(g.luc)).slice(0, 5).replace('-', '/') + (g.may ? ' (' + tenMay(g.may) + ')' : '') : 'mặc định'} · lưu ở máy này + ô ${CAI_DAT.O_MUC}, ${CAI_DAT.O_GIO} cho máy kia</span></div></div>`;
    return h;
  }
  function tabNhatKy() {
    const loc = ui6.locNK;
    const laLoi = (m) => /lỗi|Lỗi|không (thấy|đọc|mở|được|tìm)|chưa (thấy|đọc|xác nhận)|⚠|❌|❓/.test(m);
    const ds = docNhatKy(7).filter((e) => (loc === 'quan' ? e.quanTrong : loc === 'loi' ? laLoi(e.msg) : true)).slice(-150).reverse().map(dongNK);
    const nutLoc = (k, ten) => `<button class="tg ${loc === k ? 'ok' : ''}" data-a="locnk" data-k="${k}">${ten}</button>`;
    return `<div style="display:flex;gap:6px;margin-bottom:6px">${nutLoc('tatca', 'Tất cả')}${nutLoc('quan', 'Quan trọng')}${nutLoc('loi', 'Lỗi')}<button class="tg" data-a="baoloi">📋 Báo lỗi</button></div><div class="mo" style="margin-bottom:6px">Mới nhất ở trên · giữ 7 ngày</div><div class="nk">${esc(ds.join('\n')) || '(không có dòng nào)'}</div>`;
  }

  // ---------------- vẽ toàn bộ khung ----------------
  function veBangNgay() {
    if (!document.body || vt.keo) return;
    if (ui6.nhan || Date.now() < (ui6.nhanDen || 0)) { veBang(); return; } // đang nhấn chuột trong khung → vẽ sau (tránh mất cú bấm)
    const Z = coChu();
    let css = document.getElementById('smhfb-css');
    if (!css) { css = document.createElement('style'); css.id = 'smhfb-css'; document.head.appendChild(css); }
    if (css.getAttribute('data-z') !== String(Z)) { css.textContent = taoCSS(Z) + CSS_THEM + CSS_MOI; css.setAttribute('data-z', String(Z)); }
    let el = document.getElementById('smhfb');
    if (!el) { el = document.createElement('div'); el.id = 'smhfb'; document.body.appendChild(el); }
    const dangGo = el.contains(document.activeElement) && /INPUT|TEXTAREA|SELECT/.test(document.activeElement.tagName) && !/^(checkbox|file|radio|button)$/.test(document.activeElement.type || '');
    const moRong = uiTab.moRong && !!MAY;
    const tabs = [['homnay', 'Hôm nay'], ['ngaymai', 'Ngày mai'], ['saptoi', 'Sắp tới'], ['homqua', 'Hôm qua'], ['manifest', 'Manifest'], ['comment', 'Comment & Thẻ'], ['mucdat', 'Mức đặt'], ['hethong', 'Hệ thống'], ['khanh', 'Khanh TH'], ['chiso', 'Chỉ số tuần']].filter(([k]) => !((k === 'khanh' || k === 'chiso') && !LA_CAO)); // (6.20) tab Chỉ số tuần (Máy Cao)
    const tabLuu = ({ nhatky: 'hethong', lichsu: 'homnay' })[lay('ui_tab6', 'homnay')] || lay('ui_tab6', 'homnay'); const tab = tabs.some(([k]) => k === tabLuu) ? tabLuu : 'homnay';
    const t = trangThaiChung(); const dsViec = MAY ? viecCanXuLy() : [];
    if (t.den === 'xanh' && dsViec.length) t.den = 'vang';
    el.className = `k-${t.den}${fbToi() ? ' toi' : ''}${moRong ? ' mo-rong' : ''}${dangBan ? ' tudong' : ''}${dangSap() ? ' sap' : (dangBan || hdHien() || lay('dang_do', null)) ? ' dang' : ''}`;
    const tn = MAY ? thieuNgay() : [];
    let html = `<div class="bar" data-keo="1"><div class="h1">
        <span class="den ${t.den}${t.nhay ? ' nhay' : ''}"></span>
        <span class="ten" title="Đăng bài fb kênh 1 · bản ${PHIEN_BAN}">${LA_GIAO ? 'GIAO' : LA_CAO ? 'CAO' : '?'}<small style="font-weight:600;opacity:.6;margin-left:4px">${PHIEN_BAN}</small></span>`;
    if (!MAY) html += `<span class="tt">${t.chu}</span><button class="cdang" data-a="chonmay" data-may="GIAO">Máy Giao (chính)</button><button class="cdang tat" data-a="chonmay" data-may="CAO">Máy Cao (dự phòng)</button>`;
    else html += `<button class="cdang ${tuDong() ? 'bat' : 'tat'}" data-a="tudong" title="Công tắc của máy này. TẮT = không đăng, không comment, không gắn thẻ/cảm xúc, không tải tệp; chỉ còn đọc sheet, dò bài 10 phút/lần, báo cáo nhóm và báo thiếu bài">${tuDong() ? '⏻ ĐĂNG BÀI: BẬT' : '⏻ ĐĂNG BÀI: TẮT'}</button>
        ${dsViec.length ? `<button class="tg viec-pill" data-a="moviec" title="${esc(dsViec.map((v) => '• ' + v.chu).join('\n'))}">⚠ ${dsViec.length} việc</button>` : ''}
        <span class="tt">${t.chu}</span>
        <div class="h2 chips">${chips()}</div>
        <button class="nsheet${tn.length ? ' canh' : ''}" data-a="mosheet" title="${tn.length ? esc('Mở Lark sheet — còn thiếu:\n' + tn.map((x) => x.ngay + ': ' + x.t.map((y) => y.ten).join(', ')).join('\n')) : 'Mở Lark sheet'}">▦ Mở sheet${tn.length ? ` · ${tn.reduce((a, x) => a + x.t.length, 0)} thiếu` : ''}</button>`;
    if (MAY) html += nutTuNangBar();
    html += `<div class="act"><button class="icon lon" data-a="morong" title="${moRong ? 'Thu gọn' : 'Mở rộng'}">${moRong ? '▴' : '▾'}</button></div></div></div>`;
    html += thanhHoatDong();
    if (moRong && tab === 'manifest') html += khungXemAnh();
    if (moRong) {
      const huy = (n) => (n ? ` <span class="chip loi">${n}</span>` : '');
      const dem = { homnay: dsViec.length, saptoi: tn.filter((x) => x.i > 0).length, manifest: nhacInfo() ? 0 : '!' };
      const noiDung = tab === 'saptoi' ? tabSapToi() : tab === 'ngaymai' ? tabNgayMai() : tab === 'homqua' ? tabHomQua() : tab === 'manifest' ? tabManifest() : tab === 'comment' ? tabComment() : tab === 'mucdat' ? tabMucDat() : tab === 'hethong' ? tabHeThongGop() : tab === 'khanh' ? tabKhanh() : tab === 'chiso' ? tabChiSo() : tabHomNay();
      html += `<div class="tabs">${tabs.map(([k, ten]) => `<button class="tab ${tab === k ? 'chon' : ''}" data-tab="${k}">${ten}${huy(dem[k])}</button>`).join('')}</div>
        <div class="nd">${noiDung}</div>
        <div class="foot"><div class="chan"><button class="nut ${tamDung() ? 'vang' : ''}" data-a="tamdung">${tamDung() ? '▶ Chạy lại (' + conTamDung() + ')' : '⏸ Tạm dừng'}</button></div>
        <div class="chan vua"><button class="nut nho chinh" data-a="xemmanifest">🖼 Tạo ảnh manifest</button><button class="nut nho" data-a="xemmanifest">🎵 Nhạc nền</button><button class="nut nho" data-a="docsheet">📥 Đọc lại sheet</button></div>
        <div class="chan2"><span class="co">Cỡ chữ <button class="phu-nut" data-a="chunho">A−</button><b>${Math.round(Z * 100)}%</b><button class="phu-nut" data-a="chuto">A+</button></span></div></div>`;
    }
    if (dangGo && el.querySelector('.nd')) { const b = el.querySelector('.bar'); const tmp = document.createElement('div'); tmp.innerHTML = html; const b2 = tmp.querySelector('.bar'); if (b && b2 && b.innerHTML !== b2.innerHTML) b.innerHTML = b2.innerHTML; capNhatDongHo(); return; }
    if (html !== ui6.htmlCu) { const cuon = el.querySelector('.nd') ? el.querySelector('.nd').scrollTop : 0; el.innerHTML = html; ui6.htmlCu = html; if (el.querySelector('.nd')) el.querySelector('.nd').scrollTop = cuon; }
    datViTri(el, uiTab.viTri || viTriMacDinh());
    try { el.classList.remove('gon1'); const c = el.querySelector('.bar .h2.chips'); if (c && c.scrollWidth > c.clientWidth + 1) el.classList.add('gon1'); } catch (e) { /* */ }
    capNhatDongHo();
  }
  // cập nhật đồng hồ mỗi giây tại chỗ (không vẽ lại cả khung → bấm nút không bị mất)
  function capNhatDongHo() {
    const el = document.getElementById('smhfb'); if (!el) return;
    el.querySelectorAll('[data-hen]').forEach((x) => { x.textContent = conLai(+x.getAttribute('data-hen') - Date.now()); });
    el.querySelectorAll('[data-hdbd]').forEach((x) => { const tg = Date.now() - +x.getAttribute('data-hdbd'); const uoc = +x.getAttribute('data-uoc') || 0; x.innerHTML = '⏱ ' + dongHo(tg) + (uoc ? `<small>${tg > uoc * 1.5 ? 'lâu hơn dự kiến (~' + dongHo(uoc) + ')' : 'dự kiến ~' + dongHo(uoc)}</small>` : ''); const tien = x.parentElement && x.parentElement.querySelector('[data-tien]'); if (tien && uoc) tien.style.width = Math.min(96, Math.round((tg / uoc) * 100)) + '%'; });
    veNhacNho(); try { veSoanW(); } catch (e) { /* */ }
    if (demNguoc) {
      const con = Math.max(0, Math.ceil((demNguoc.den - Date.now()) / 1000));
      const so = el.querySelector('[data-demso]'); if (so && !demNguoc.dung) so.textContent = con;
      const ch = el.querySelector('[data-demchu]'); if (ch) ch.textContent = con;
      if (!el.querySelector('.hdg.dem')) veBang();
      if (!document.title.startsWith('⏳')) gocTitle = document.title;
      document.title = demNguoc.dung ? '⏳ ⏸ Đã tạm dừng · Sắp ' + demNguoc.ten : (Math.floor(Date.now() / 600) % 2 ? '⏳ ' + con + 's · ' : '⏳ ⚠ ') + 'Sắp ' + demNguoc.ten; // (6.27.1) tạm dừng: tiêu đề tab đứng yên
    } else { if (/^⏳/.test(document.title)) document.title = gocTitle; if (el.querySelector('.hdg.dem')) veBang(); }
  }
  const veDemNguoc = () => capNhatDongHo();
  const veHoatDong = () => veBang();

  // ---------------- kéo thả · tự thu gọn (như bản 5.9) ----------------
  document.addEventListener('mousedown', (ev) => {
    if (ev.target.closest && ev.target.closest('#smhfb')) { ui6.nhan = true; uiTab.moLuc = Date.now(); }
    const bar = ev.target.closest && ev.target.closest('#smhfb [data-keo]');
    if (!bar || ev.target.closest('button,a,input,label') || ev.button !== 0) return;
    const el = document.getElementById('smhfb'); const r = el.getBoundingClientRect();
    vt.keo = { dx: ev.clientX - (parseInt(el.dataset.bx, 10) || r.left), dy: ev.clientY - r.top }; el.classList.add('keo'); ev.preventDefault();
  }, true);
  document.addEventListener('mousemove', (ev) => { if (!vt.keo) return; datViTri(document.getElementById('smhfb'), { x: ev.clientX - vt.keo.dx, y: ev.clientY - vt.keo.dy }); }, true);
  document.addEventListener('mouseup', () => {
    if (ui6.nhan) { ui6.nhan = false; ui6.nhanDen = Date.now() + 300; }
    if (!vt.keo) return;
    const el = document.getElementById('smhfb'); el.classList.remove('keo');
    uiTab.viTri = { x: parseInt(el.dataset.bx, 10) || 0, y: parseInt(el.style.top, 10) };
    vt.keo = null; veBang();
  }, true);
  document.addEventListener('dblclick', (ev) => { if (!(ev.target.closest && ev.target.closest('#smhfb [data-keo]')) || ev.target.closest('button,a')) return; uiTab.viTri = null; veBang(); }, true);
  ['mousemove', 'keydown', 'wheel', 'touchstart', 'click'].forEach((e) => document.addEventListener(e, (ev) => { if (ev.target && ev.target.closest && ev.target.closest('#smhfb')) uiTab.moLuc = Date.now(); }, true));
  // ---------------- thẻ tiến trình soạn/đăng bài (giống thẻ "Gắn vị trí & thẻ"): hiện dưới màn hình từng bước đang làm ----------------
  let soanTT = null;
  const BUOC_BAI = ['Mở hộp soạn', 'Điền chữ', 'Nền đỏ / ảnh', 'Vị trí', 'Tiếp', 'Chọn nhóm', 'Xác nhận', 'Đăng'];
  const BUOC_VIDEO = ['Điền chữ', 'Gắn video', 'Vị trí', 'Thẻ', 'Nhóm', 'Hình thu nhỏ', 'Đăng'];
  const MAP_B = { 1: 0, 2: 1, 3: 2, 4: 3, 5: 4, 6: 5, 7: 5, 8: 6, 9: 7 }, MAP_V = { 1: 0, 2: 1, 3: 2, 4: 3, 5: 4, 6: 5, 7: 6, 8: 6 };
  function theoDoiSoan(msg) {
    const bd = msg.match(/^Bắt đầu (soạn|đăng) (.+?)(?: \(|$)/);
    if (bd) { soanTT = { ten: bd[2], soan: bd[1] === 'soạn', loai: '', buoc: -1, tt: 'chay', chi: 'Đang chuẩn bị (tải ảnh/video, kiểm tư cách)…', luc: Date.now(), bd: Date.now() }; return; }
    if (!soanTT) return;
    const m = msg.match(/^(?:[^:]{1,40}: )?([BV])(\d)\. (.*)$/);
    if (m) { soanTT.loai = m[1]; soanTT.buoc = (m[1] === 'B' ? MAP_B : MAP_V)[+m[2]] || 0; soanTT.chi = m[3]; soanTT.luc = Date.now(); if (/chưa ăn|chưa khớp|chưa mở được|chưa đủ|lỗi/i.test(m[3])) soanTT.thu = m[3]; else soanTT.thu = ''; return; }
    if (/Soạn thử xong|đã soạn xong, dừng/.test(msg)) { soanTT.tt = 'cho'; soanTT.buoc = (soanTT.loai === 'V' ? BUOC_VIDEO : BUOC_BAI).length - 1; soanTT.chi = 'Đã dừng trước nút Đăng — bạn kiểm tra rồi tự bấm Đăng (hoặc đóng hộp để huỷ)'; soanTT.luc = Date.now(); return; }
    if (/^Đã đăng /.test(msg) || /^Thấy .* đã được bấm Đăng/.test(msg)) { soanTT.tt = 'xong'; soanTT.buoc = 99; soanTT.chi = msg; soanTT.luc = Date.now(); return; }
    if (/^(Lỗi khi đăng|Hoãn đăng|Soạn thử .* lỗi|Chưa đăng được)/.test(msg)) { soanTT.tt = 'loi'; soanTT.chi = msg; soanTT.luc = Date.now(); return; }
    if (/Bỏ bản soạn dở|hộp soạn không còn|hộp soạn đã đóng|đã có trên trang/.test(msg)) { soanTT = null; }
  }
  function veSoanW() {
    let w = document.getElementById('smhfb-soan-w');
    const s = soanTT; const het = s && (s.tt === 'xong' || s.tt === 'loi') && Date.now() - s.luc > 90000;
    const hien = s && !het && (s.tt !== 'cho' || lay('cho_tay6', null)) && !(s.tt === 'chay' && !dangBan && Date.now() - s.luc > 120000);
    if (!hien) { if (w) w.style.display = 'none'; return; }
    if (!w) { w = document.createElement('div'); w.id = 'smhfb-soan-w'; document.body.appendChild(w); }
    const ds = s.loai === 'V' ? BUOC_VIDEO : BUOC_BAI;
    const chips = ds.map((t, i) => { const lop = s.tt === 'xong' || i < s.buoc ? 'xong' : i === s.buoc ? (s.tt === 'loi' ? 'loi' : s.tt === 'cho' ? 'cho' : 'chay') : ''; return `<span class="gc ${lop}"><span class="ic">${lop === 'xong' ? '✓' : lop === 'loi' ? '!' : lop === 'cho' ? '⏸' : i + 1}</span>${t}</span>`; }).join('');
    const tieu = s.tt === 'xong' ? `✅ ${esc(s.ten)} đã đăng xong` : s.tt === 'loi' ? `⚠ ${esc(s.ten)}: chưa xong` : s.tt === 'cho' ? `⏸ ${esc(s.ten)} đã soạn xong — chờ bạn bấm Đăng` : `${s.soan ? '✎ Đang soạn' : '▶ Đang đăng'} ${esc(s.ten)}`;
    const html = `<div class="gh"><b>${tieu}</b><span class="gt">⏱ ${dongHo(Date.now() - s.bd)}</span></div><div class="gb">${chips}</div><div class="gd">${esc(s.thu || s.chi || '')}</div>`;
    if (w.innerHTML !== html) w.innerHTML = html;
    w.className = s.tt; w.style.display = 'flex';
  }
  // mở rộng / thu gọn có chuyển động mượt (kiểu Apple: ease-out nhanh đầu, chậm cuối)
  function datMoRong(mo, lyDo) { // (6.9) bỏ chuyển động: đóng/mở ngay
    uiTab.moRong = mo; uiTab.moLuc = mo ? Date.now() : 0; veBangNgay(); if (!mo && lyDo) nhacNho(lyDo);
  }
  const dangChoNut = () => mf.chay || mf.dan || ui6.xem != null || !!(ui6.cmt && (ui6.cmt.sua || ui6.cmt.dangLuu)) || !!(ui6.the && (ui6.the.sua || ui6.the.dangLuu)) || ['docsheet', 'kiem1', 'kiem3', 'kiem24', 'dotrang', 'tinthu', 'taisan', 'khanhthu'].some((l) => ttYC(l).tt === 'run');
  setInterval(() => { // mở rộng xong 60 giây không đụng tới thì tự thu gọn (không thu khi đang chờ kết quả nút vừa bấm)
    if (!uiTab.moRong) { uiTab.moLuc = 0; return; }
    const el = document.getElementById('smhfb'); if (!el) return;
    if (!uiTab.moLuc || vt.keo || (el.contains(document.activeElement) && /INPUT|TEXTAREA/.test(document.activeElement.tagName)) || dangChoNut()) { uiTab.moLuc = Date.now(); return; }
    if (Date.now() - uiTab.moLuc > 60000) datMoRong(false);
  }, 1000);
  setInterval(() => { // script bắt đầu soạn/đăng bài trên trang → tự thu gọn popup để không che hộp soạn (bạn vẫn mở lại được)
    const ban = dangBan || !!lay('dang_do', null);
    if (!ban) { uiTab.daThuVi = false; return; }
    if (uiTab.moRong && !uiTab.daThuVi && !vt.keo) { uiTab.daThuVi = true; datMoRong(false, 'Script đang làm việc trên trang → popup tự thu gọn (bấm ▾ để mở lại)'); }
  }, 500);
  window.addEventListener('resize', () => { const el = document.getElementById('smhfb'); if (el) datViTri(el, uiTab.viTri || viTriMacDinh()); });

  // ---------------- các nút ----------------
  // bấm xong là có phản hồi ngay: nút quay vòng "đang làm" → thanh "Xong: …" khi làm xong
  function phanHoi(a) { try { if (a.classList.contains('chay')) return; a.classList.add('chay'); a.insertAdjacentHTML('afterbegin', '<span class="xoay"></span>'); } catch (e) { /* */ } }
  document.addEventListener('change', async (e) => {
    const a = e.target.closest && e.target.closest('#smhfb') && e.target.getAttribute('data-a'); if (!a) return;
    if (a === 'chonnen') { anhNenTam = Array.from(e.target.files || []).filter((f) => /^image\//.test(f.type)); ghi(`Đã chọn ${anhNenTam.length} ảnh nền cho manifest`); veBang(); }
    if (a === 'themfont') { const f = (e.target.files || [])[0]; e.target.value = ''; if (!f) return; try { const ten = await themFont(f); luu('hd_ket', { key: 'font', ten: 'Đang thêm font', chu: `Đã thêm font "${ten}" — chọn nó ở ô Tiêu đề / Thân bài / Lời kêu gọi`, luc: Date.now(), tg: 0, mau: 'ok' }); } catch (er) { alert('Chưa thêm được font: ' + er.message); } veBangNgay(); return; }
    if (a === 'chonnhac') { const f = (e.target.files || [])[0]; if (!f) return; try { await luuNhac(f, f.name, 'tay'); luu('hd_ket', { key: 'nhac', ten: 'Đang lưu nhạc nền', chu: f.name, luc: Date.now(), tg: 0, mau: 'ok' }); } catch (er) { alert('Chưa lưu được nhạc: ' + er.message); } veBang(); }
  }, true);
  document.addEventListener('change', (e) => { if (!(e.target.closest && e.target.closest('#smhfb'))) return; const o = e.target.getAttribute('data-o') || ''; const m = o.match(/^font_(td|than|cmt)$/); if (!m) return; datFont(m[1], e.target.value); ghi(`Chọn font ${({ td: 'tiêu đề', than: 'thân bài', cmt: 'lời kêu gọi' })[m[1]]}: ${e.target.value}`); e.target.blur(); veBangNgay(); }, true);
  document.addEventListener('focusout', (e) => { if (ui6.mdVe && e.target.closest && e.target.closest('#smhfb')) { ui6.mdVe = 0; setTimeout(() => veBangNgay(), 0); } }, true); // (6.33) rời ô nhập → vẽ lại (cập nhật nút Lưu, ghi chú)
  document.addEventListener('input', (e) => { if (!(e.target.closest && e.target.closest('#smhfb'))) return; const o = e.target.getAttribute('data-o') || ''; if (o === 'cs_ghichu') { luu('csghichu6', e.target.value); return; } if (/^md_/.test(o)) { const n = nhapMD(); n.muc[o.slice(3)] = Math.max(0, Math.min(20, parseInt(e.target.value, 10) || 0)); ui6.mdVe = 1; return; } if (/^mdg_/.test(o)) { const n = nhapMD(); const [, kk, i] = o.split('_'); let v = String(e.target.value || '').trim().replace(/[hH.]/, ':'); if (/^\d{3,4}$/.test(v)) v = v.padStart(4, '0').replace(/^(\d\d)(\d\d)$/, '$1:$2'); if (/^\d:\d\d$/.test(v)) v = '0' + v; n.gio[kk][+i] = v; ui6.mdVe = 1; return; } /* (6.33) nháp tab Mức đặt */ if (o === 'the_video' || o === 'the_manifest') { const t = nhapThe(); t[o === 'the_video' ? truongThe() : 'manifest'] = e.target.value; t.sua = true; const b = document.querySelector(`#smhfb [data-a="chonkenhthe"][data-k="${ui6.kenhThe || 1}"] b`); if (b && o === 'the_video') b.textContent = dsThe(e.target.value).length; return; }
    if (/^cmt_/.test(o)) { const n = nhapCmt(); if (o === 'cmt_goc') n.goc = e.target.value; if (o === 'cmt_gochx') n.gocHx = e.target.value; if (o === 'cmt_link') n.link = e.target.value; if (o === 'cmt_cta') n.cta = e.target.value; if (o === 'cmt_bat') n.bat = e.target.checked; if (o === 'cmt_loai') n.loai[e.target.getAttribute('data-k')] = e.target.checked; if (o === 'cmt_kenh') { n.kenh = n.kenh || {}; n.kenh[e.target.getAttribute('data-k')] = e.target.checked; } n.sua = true; if (e.target.type === 'checkbox') veBangNgay(); return; } if (o === 'mfchu') { luu('mf_chu6', e.target.value); const n = tachKhoiMF(e.target.value).length; const b = document.querySelector('#smhfb [data-mfdem]'); if (b) b.textContent = `${n} khối → ${n} ảnh`; const t = document.querySelector('#smhfb [data-a="taoanh"]'); if (t && !t.disabled) t.textContent = `🖼 Tạo ${n || ''} ảnh`; return; } if (o === 'vung') luu('mf_vung6', e.target.value.trim()); if (o === 'onhac') luu('o_nhac6', e.target.value.trim().toUpperCase()); }, true);
  document.addEventListener('click', async (ev) => {
    const tabBtn = ev.target.closest && ev.target.closest('#smhfb [data-tab]');
    if (tabBtn) { luu('ui_tab6', tabBtn.getAttribute('data-tab')); uiTab.moLuc = Date.now(); veBangNgay(); return; }
    const a = ev.target.closest && ev.target.closest('#smhfb [data-a]'); if (!a || a.tagName === 'INPUT') return;
    const hd = a.getAttribute('data-a'); const k = a.getAttribute('data-k'); ui6.nhanDen = 0; bamNutLuc = Date.now();
    try { const ae = document.activeElement; if (ae && ae !== a && /INPUT|TEXTAREA|SELECT/.test(ae.tagName) && ae.closest('#smhfb')) ae.blur(); } catch (e) { /* */ } // bấm nút → bỏ con trỏ khỏi ô chữ để popup vẽ lại ngay
    const NHO = { morong: () => (uiTab.moRong ? 'Đã thu gọn' : 'Đã mở rộng'), chon: () => 'Xem chi tiết ' + tenSlot(k), moviec: 'Mở danh sách việc cần xử lý', xemsaptoi: 'Mở tab Sắp tới', xemmanifest: 'Mở tab Manifest', mobai: 'Đang mở bài ở tab mới…', mosheet: 'Đang mở Lark sheet ở tab mới…', mosheetvideo: 'Đang mở Lark sheet Video/Manifest ở tab mới…', locnk: 'Đã lọc nhật ký', donghd: 'Đã ẩn thông báo', bohoan: 'Đã bỏ hoãn — script làm tiếp theo lịch', xemanh: 'Xem ảnh lớn — bấm ‹ › để xem ảnh khác', dongxem: 'Đã đóng ảnh',  chuto: 'Chữ to hơn', chunho: 'Chữ nhỏ hơn', caima: 'Mở hộp cài mã khoá', kiemma: 'Đang kiểm tra mã khoá…', baoloi: 'Đang tạo file báo lỗi…' };
    if (NHO[hd]) nhacNho(typeof NHO[hd] === 'function' ? NHO[hd]() : NHO[hd]);
    if (a.tagName === 'A') ev.preventDefault();
    if (hd === 'morong') { datMoRong(!uiTab.moRong); return; }
    if (/^cs_/.test(hd)) { phanHoi(a); await bamChiSo(hd); return; } // (6.20) nút tab Chỉ số tuần
    if (hd === 'chon') { uiTab.chon = k; uiTab.moRong = true; uiTab.moLuc = Date.now(); luu('ui_tab6', 'homnay'); veBangNgay(); return; }
    if (hd === 'moviec') { uiTab.moRong = true; uiTab.moLuc = Date.now(); luu('ui_tab6', 'homnay'); veBangNgay(); return; }
    if (hd === 'xemsaptoi' || hd === 'xemmanifest') { uiTab.moRong = true; uiTab.moLuc = Date.now(); luu('ui_tab6', hd === 'xemsaptoi' ? 'saptoi' : 'manifest'); veBangNgay(); return; }
    if (hd === 'mobai') { window.open(a.getAttribute('data-link'), '_blank', 'noopener'); return; }
    if (hd === 'mosheet') { window.open(CAI_DAT.LINK_SHEET, '_blank', 'noopener'); return; }
    if (hd === 'mosheetvideo') { window.open(CAI_DAT.LINK_SHEET_VIDEO, '_blank', 'noopener'); return; }
    if (hd === 'locnk') { ui6.locNK = k; veBangNgay(); return; }
    if (hd === 'donghd') { const x = lay('hd_ket', null); if (x) { x.dong = true; luu('hd_ket', x); } veBangNgay(); return; }
    if (hd === 'chonmay') { const m = a.getAttribute('data-may'); if (m === MAY) return; if (!confirm(`Đặt máy này là ${m === 'GIAO' ? 'MÁY GIAO (máy chính, đăng đúng giờ)' : 'MÁY CAO (máy dự phòng, chỉ đăng thay khi Máy Giao trễ)'}?\n\nTrang sẽ tải lại.`)) return; luu('may6', m); ghi('Đặt máy này là ' + (m === 'GIAO' ? 'Máy Giao' : 'Máy Cao')); roiTrang(); return; }
    if (hd === 'lamngay') { luu('lam_ngay6', Date.now()); luu('cho_nguoi', null); nhacNho('Script sẽ làm ngay (đếm ngược 10 giây)', 'cho'); setTimeout(nhip, 300); veBangNgay(); return; }
    if (hd === 'dndung') { if (demNguoc) { demNguoc.dung = true; demNguoc.dungLuc = Date.now(); ghi('Nhân sự bấm Tạm dừng đếm ngược'); } veBangNgay(); return; }
    if (hd === 'dntiep') { if (demNguoc) { demNguoc.dung = false; demNguoc.den = Date.now() + 3000; ghi('Nhân sự bấm Tiếp tục'); } veBangNgay(); return; }
    if (hd === 'dnngay') { if (demNguoc) { demNguoc.dung = false; demNguoc.den = Date.now(); ghi('Bấm Làm ngay: ' + demNguoc.ten); } veBangNgay(); return; } // (6.22)
    if (hd === 'dnhoan') { luu('hoan6', Date.now() + 10 * 60000); if (demNguoc) demNguoc.hoan = true; ghi('Nhân sự bấm Hoãn 10 phút'); veBangNgay(); return; }
    if (hd === 'bohoan') { luu('hoan6', 0); veBangNgay(); return; }
    if (hd === 'lammoi') { phanHoi(a); yeuCau('dotrang'); return; }
    if (['docsheet', 'kiem1', 'kiem3', 'kiem24', 'tinthu', 'taisan', 'khanhthu'].includes(hd)) { phanHoi(a); yeuCau(hd); return; }
    if (hd === 'kiemlai' && k) { capNhatTT((s) => { const x = ttSlot(s, k); x.kiem = (x.kiem || []).slice(0, CAI_DAT.KIEM_CMT_TOI_DA - 1); x.cmtOk = false; x.baoBu = 0; x.buHong = 0; x.buCho = null; x.guiBu = 0; }); luu('hang_bu6', (lay('hang_bu6', []) || []).concat([{ key: k }])); ghi('Bấm Kiểm lại comment: ' + tenSlot(k)); phanHoi(a); setTimeout(nhip, 300); return; }
    if (hd === 'tamdung') { const v = !tamDung(); luu('tam_dung', v); luu('tam_dung_luc', v ? Date.now() : 0); if (v) luu('dung_moc', Math.max(Date.now(), lay('dung_moc', 0) + 1)); ghi(v ? 'Bấm Tạm dừng — script ngừng mọi việc trên máy này, tự chạy lại sau 10 phút' : 'Bấm Chạy lại'); veBangNgay(); if (!v) setTimeout(nhip, 300); return; }
    if (hd === 'tudong') { const moi = !tuDong(); if (moi && !confirm('Bật tự đăng trên máy này?')) return; luu('tu_dong6', moi); ghi('Tự đăng: ' + (moi ? 'BẬT' : 'TẮT')); veBangNgay(); if (moi) setTimeout(nhip, 300); return; }
    if (hd === 'chaythu') { luu('chay_thu6', !chayThu()); ghi('Chạy thử: ' + (chayThu() ? 'BẬT (mọi bài chỉ soạn sẵn, dừng trước nút Đăng)' : 'TẮT')); veBangNgay(); return; }
    if (hd === 'chonmai') { uiTab.chonMai = k; veBangNgay(); return; }
    if (hd === 'soan' && k && a.getAttribute('data-ngay') && a.getAttribute('data-ngay') !== homNay()) {
      const nm = a.getAttribute('data-ngay');
      if (!boSoanDo()) return;
      if (!confirm(`Soạn thử ${tenSlot(k)} của NGÀY MAI ngay bây giờ?\n\nScript làm hết mọi bước (chữ, ảnh/video, vị trí, thẻ, nhóm…) rồi DỪNG trước nút Đăng.\nBạn xem kỹ rồi bấm Huỷ / đóng hộp.\n\n⚠ Nếu bạn bấm Đăng thì bài lên trang NGAY HÔM NAY (ngày mai sẽ không đăng lại).`)) return;
      if (tamDung()) luu('tam_dung', false);
      capNhatTT((s) => { const x = ttSlot(s, k); x.ep = Date.now(); x.soan = true; }, nm);
      if (!laTabChinh()) { const kh = GM_getValue('khoa_dang_bai_that', null); if (!(kh && kh.ban)) GM_setValue('khoa_dang_bai_that', { id: MA_TAB, ts: Date.now(), hien: document.visibilityState === 'visible', anTu: 0, ban: false, v: PHIEN_BAN }); }
      ghi(`Bấm Soạn thử bài ngày mai: ${tenSlot(k)}`); phanHoi(a); setTimeout(nhip, 300); return;
    }
    if (hd === 'bodanhdau' && k && a.getAttribute('data-ngay')) { capNhatTT((s) => { const x = ttSlot(s, k); x.tt = 'cho'; x.may = ''; x.luc = 0; x.cmtOk = false; x.lyDo = ''; }, a.getAttribute('data-ngay')); ghi('Bỏ đánh dấu (ngày mai): ' + tenSlot(k)); veBangNgay(); return; }
    if ((hd === 'dangngay' || hd === 'soan') && k) {
      const soan = hd === 'soan';
      if (!boSoanDo()) return;
      let ghiDe = false; // (6.26.4) máy kia đang giữ chỗ bài này → vẫn cho đăng, hỏi lại
      if (!chanLark() && !lay('cho_tay6', null)) { try { nhacNho('Đang xem ô giữ chỗ…', 'cho'); const kx = docKhoa(chuO(await docO(CAI_DAT.TAB_BAI, CAI_DAT.O_KHOA)), k); if (kx && kx.ngay === homNay() && kx.slot === k && kx.may !== MAY && Date.now() - kx.luc < CAI_DAT.NHUONG_PHUT * 60000) {
        const tenM = kx.may === 'CAO' ? 'Máy Cao' : 'Máy Giao';
        if (!confirm(`⚠ ${tenM} đã giữ chỗ ${tenSlot(k)} lúc ${gioStr(new Date(kx.luc))} (có thể đang đăng hoặc đã đăng lỗi).\n\nBạn có muốn ${soan ? 'soạn' : 'đăng'} không?\n(Trước khi bấm Đăng script vẫn hỏi Facebook — bài đã có trên trang thì không đăng trùng)`)) { ghi(`Bấm ${soan ? 'Soạn' : 'Đăng ngay'} ${tenSlot(k)}: ${tenM} đang giữ chỗ → người bấm Huỷ`); veBangNgay(); return; }
        ghiDe = true; ghi(`Người bấm ${soan ? 'Soạn' : 'Đăng ngay'} ${tenSlot(k)} dù ${tenM} đang giữ chỗ (từ ${gioStr(new Date(kx.luc))})`); } } catch (e) { ghi('Chưa đọc được ô giữ chỗ (' + e.message + ') — vẫn làm theo nút bấm'); } }
      if (!ghiDe && !confirm(soan ? `Soạn sẵn ${tenSlot(k)} ngay bây giờ?\n\nScript làm hết mọi bước (chữ, ảnh/video, vị trí, thẻ, nhóm, hình thu nhỏ…) rồi DỪNG trước nút Đăng.\nBạn kiểm tra rồi tự bấm Đăng — script sẽ tự comment tiếp.` : `Đăng ${tenSlot(k)} ngay bây giờ (không chờ giờ hẹn)?`)) return;
      if (tamDung()) luu('tam_dung', false);
      capNhatTT((s) => { const x = ttSlot(s, k); x.ep = Date.now(); x.soan = soan; x.thuLai = 0; x.choDen = 0; x.ghiDe = ghiDe ? Date.now() : 0; if (KET.includes(x.tt) && !XONG.includes(x.tt)) { x.tt = 'cho'; x.lan = 0; x.lyDo = ''; } });
      if (!laTabChinh()) { const kh = GM_getValue('khoa_dang_bai_that', null); if (!(kh && kh.ban)) GM_setValue('khoa_dang_bai_that', { id: MA_TAB, ts: Date.now(), hien: document.visibilityState === 'visible', anTu: 0, ban: false, v: PHIEN_BAN }); }
      ghi(`Bấm ${soan ? 'Soạn' : 'Đăng ngay'}: ${tenSlot(k)}`); phanHoi(a); setTimeout(nhip, 300); return;
    }
    if (hd === 'boqua' && k) { if (!confirm(`Bỏ qua ${tenSlot(k)} hôm nay?`)) return; capNhatTT((s) => { Object.assign(ttSlot(s, k), { tt: 'bo', lyDo: 'bấm Bỏ qua trên popup' }); }); ghi('Bấm Bỏ qua: ' + tenSlot(k)); veBangNgay(); return; }
    if (hd === 'khoiphuc' && k) { const quaChot = phutTrongNgay(new Date()) >= docGio(((LICH.find((x) => x.k === k) || {}).them || (LICH.find((x) => x.k === k) || {}).baiThem) ? CAI_DAT.GIO_CHOT_THEM : CAI_DAT.GIO_CHOT); capNhatTT((s) => { const x = ttSlot(s, k); if (x.tt === 'co_san') { x.link = ''; x.may = ''; } x.tt = 'cho'; x.lan = 0; x.loi = ''; x.lyDo = ''; x.thuLai = 0; if (quaChot) x.ep = Date.now(); }); ghi('Bấm Đưa lại vào hàng chờ: ' + tenSlot(k) + (quaChot ? ' (đã quá giờ chốt → đăng ngay)' : '')); if (quaChot) nhacNho('Đã quá giờ chốt nên bài sẽ được đăng ngay'); veBangNgay(); setTimeout(nhip, 300); return; } // (6.19.3) sau giờ chốt trước đây bấm xong không làm gì
    if (hd === 'danhdau' && k) { // (6.26.3) hỏi Facebook trước: không thấy bài trên trang thì cảnh báo, tránh đánh dấu nhầm
      const c = kenhCua(k); let p = null, daHoi = false;
      if (coApiKenh(c)) { nhacNho(`Đang hỏi Facebook xem ${tenSlot(k)} đã lên trang chưa…`, 'cho'); datKenh(c); try { const nd0 = noiDungSlot(homNay(), k); p = nd0.text ? baiKhop(await baiTrenTrangApi(new Date(new Date().setHours(0, 0, 0, 0)).getTime()), nd0.text) : null; daHoi = true; } catch (e) { ghi('Đánh dấu đã đăng: chưa hỏi được Facebook (' + e.message + ')'); } finally { datKenh(1); } }
      if (daHoi && !p) { ghi(`Bấm Đánh dấu đã đăng ${tenSlot(k)}: Facebook chưa thấy bài trên trang ${tenKenhDai(c)} hôm nay`); if (!confirm(`⚠ Facebook CHƯA thấy ${tenSlot(k)} trên trang ${tenKenhDai(c)} hôm nay.\n\nNếu bài chưa đăng thật, bấm Huỷ (script sẽ đăng lại).\nChỉ bấm OK khi chắc chắn bài đã lên trang.`)) { veBangNgay(); return; } }
      else if (!p && !confirm(`Đánh dấu ${tenSlot(k)} hôm nay ĐÃ ĐĂNG?\n(Dùng khi bài đã lên trang mà script không nhận ra)`)) return;
      capNhatTT((s) => { Object.assign(ttSlot(s, k), { tt: 'xong', luc: p ? p.luc : Date.now(), may: 'tay', lyDo: '', cmtOk: !p, link: p ? p.link : '', id: p ? p.id : '' }); });
      ghi('Bấm Đánh dấu đã đăng: ' + tenSlot(k) + (p ? ' — Facebook xác nhận bài đã lên lúc ' + gioStr(new Date(p.luc)) + ' (script sẽ kiểm comment)' : daHoi ? ' — người bấm xác nhận dù Facebook chưa thấy bài' : '')); veBangNgay(); return; }
    if (hd === 'bodanhdau' && k) { capNhatTT((s) => { const x = ttSlot(s, k); x.tt = 'cho'; x.may = ''; x.luc = 0; x.cmtOk = false; }); ghi('Bỏ đánh dấu: ' + tenSlot(k)); veBangNgay(); return; }
    if (hd === 'mucdat') { luu('ui_tab6', 'mucdat'); uiTab.moRong = true; uiTab.moLuc = Date.now(); veBangNgay(); return; } // (6.33) nút ⚙ Mức đặt → mở tab Mức đặt
    if (hd === 'htphan') { ui6.htPhan = k === 'nk' ? 'nk' : 'tt'; veBangNgay(); return; }
    if (hd === 'mdcong') { const n = nhapMD(); const kk = a.getAttribute('data-k'); n.muc[kk] = Math.max(0, Math.min(20, (parseInt(n.muc[kk], 10) || 0) + (+a.getAttribute('data-d') || 0))); veBangNgay(); return; }
    if (hd === 'mdxoagio') { const n = nhapMD(); n.gio[a.getAttribute('data-k')] = ['', '']; veBangNgay(); return; }
    if (hd === 'mdgiohx') { const n = nhapMD(); n.gio.k4 = GIO_MD.k4.slice(); veBangNgay(); return; }
    if (hd === 'mdmacdinh') { const n = nhapMD(); for (const kk of Object.keys(MUC_MD)) n.muc[kk] = MUC_MD[kk]; for (const kk of Object.keys(GIO_MD)) n.gio[kk] = GIO_MD[kk].slice(); nhacNho('Đã điền giá trị mặc định — bấm 💾 Lưu cài đặt để áp dụng', 'vang'); veBangNgay(); return; }
    if (hd === 'huymd') { ui6.md = null; nhacNho('Đã huỷ thay đổi'); veBangNgay(); return; }
    if (hd === 'luumd') {
      for (const el of document.querySelectorAll('#smhfb [data-o^="md_"], #smhfb [data-o^="mdg_"]')) el.dispatchEvent(new Event('input', { bubbles: true })); // lấy luôn giá trị đang gõ dở
      const n = nhapMD(); const kq = kiemGioNhap(n.gio); if (kq.loi.length) { nhacNho(kq.loi.join(' · '), 'vang', 8000); veBangNgay(); return; }
      if (!mdDoi()) { nhacNho('Chưa có thay đổi nào để lưu'); return; }
      phanHoi(a); nhacNho('Đang lưu cài đặt…', 'cho', 20000);
      const m0 = mucDat(); const g0 = gioDang(); const doiMuc = Object.keys(MUC_MD).some((kk) => +n.muc[kk] !== m0[kk]); const doiGio = Object.keys(GIO_MD).some((kk) => kq.o[kk].join('-') !== g0[kk].join('-'));
      const loi = [];
      if (doiMuc) { try { await luuMucDat(n.muc); } catch (er) { loi.push(er.message); } try { dongBoLich(); } catch (e2) { /* */ } }
      if (doiGio) { try { await luuGioDang(kq.o); } catch (er) { loi.push(er.message); } }
      if (doiMuc || doiGio) { try { trangThai(homNay()); } catch (e3) { /* */ } }
      ui6.md = null; nhacNho(loi.length ? 'Đã lưu trên máy này · ' + [...new Set(loi)].join(' · ') : `Đã lưu ${[doiMuc ? 'mức đặt' : '', doiGio ? 'giờ đăng' : ''].filter(Boolean).join(' + ')} (máy này + ô sheet cho máy kia) · lịch hôm nay đã xếp lại`, loi.length ? 'vang' : 'ok', 8000); veBangNgay(); return;
    }
    if (hd === 'luumuc') { const m = ui6.mucDat || mucDat(); for (const k of Object.keys(MUC_MD)) { const el = document.querySelector(`#smhfb [data-o="muc_${k}"]`); if (el) m[k] = el.value; } phanHoi(a); ui6.mucDat = null; try { await luuMucDat(m); nhacNho('Đã lưu mức đặt (máy này + ô ' + CAI_DAT.O_MUC + ' cho máy kia)'); } catch (er) { nhacNho('Đã lưu mức đặt trên máy này · ' + er.message, 'vang', 8000); } veBangNgay(); return; }
    if (hd === 'mfnguon') { luu('mf_nguon6', k === 'tay' ? 'tay' : 'sheet'); ghi('Tạo ảnh manifest: chọn nguồn chữ ' + (k === 'tay' ? 'nhập trực tiếp' : 'lấy từ sheet')); veBangNgay(); return; } // (6.31)
    if (hd === 'taianhmf') { const i = +a.getAttribute('data-i'); if (taiAnhMF(mf.ds[i], i + 1)) { ghi(`Tải ảnh manifest ${i + 1} về máy`); nhacNho(`Đang tải ảnh ${i + 1} — xem ở thư mục Tải xuống`); } return; }
    if (hd === 'taiallmf') { phanHoi(a); taiTatCaMF().then((n) => nhacNho(`Đã tải ${n} ảnh — xem ở thư mục Tải xuống (Chrome hỏi "tải nhiều tệp" thì bấm Cho phép)`, 'ok', 8000)).catch((er) => alert(er.message)); return; }
    if (hd === 'taoanh' && nguonMF() === 'tay') { const chu = lay('mf_chu6', '') || ''; if (!anhNenTam.length) { ui6.canhNen = true; veBangNgay(); alert('Bạn chưa chọn ảnh nền.\n\nBấm "📂 Chọn ảnh nền…" ở bước 1, chọn 1 hoặc nhiều ảnh, rồi bấm Tạo ảnh lại.'); return; } if (!tachKhoiMF(chu).length) { alert('Ô nội dung chưa có chữ.\n\nDán chữ vào ô ở bước 2 (mỗi ảnh cách nhau 1 dòng trống) rồi bấm Tạo ảnh.'); return; }
      phanHoi(a); ghi('Bấm Tạo ảnh manifest (nhập trực tiếp)'); theoDoi('taoanh', async () => { const bd = Date.now(); try { const kq = await taoAnhXemTruoc('', chu); luu('hd_ket', { key: 'taoanh', ten: 'Đang tạo ảnh manifest', chu: kq + ' — bấm ⬇ Tải hoặc Tải tất cả', luc: Date.now(), tg: Date.now() - bd, mau: 'ok' }); } catch (er) { ghi('Tạo ảnh manifest chưa được: ' + er.message); luu('hd_ket', { key: 'taoanh', ten: 'Đang tạo ảnh manifest', chu: 'Lỗi: ' + er.message, luc: Date.now(), tg: Date.now() - bd, mau: 'vang' }); } veBang(); }, 'Đang tạo ảnh manifest'); return; }
    if (hd === 'taoanh') { const vung = lay('mf_vung6', 'G220:G223'); if (!anhNenTam.length) { ui6.canhNen = true; veBangNgay(); alert('Bạn chưa chọn ảnh nền.\n\nBấm "📂 Chọn ảnh nền…" ở bước 1, chọn 1 hoặc nhiều ảnh, rồi bấm Tạo ảnh lại.'); return; } try { docVungMF(vung); } catch (er) { alert(er.message); return; } phanHoi(a); ghi(`Bấm Tạo ảnh manifest (${vung})`); theoDoi('taoanh', async () => { const bd = Date.now(); try { const kq = await taoAnhXemTruoc(vung); luu('hd_ket', { key: 'taoanh', ten: 'Đang tạo ảnh manifest', chu: kq + ' — bấm từng ảnh để xem, rồi bấm Dán vào sheet', luc: Date.now(), tg: Date.now() - bd, mau: 'ok' }); } catch (er) { ghi('Tạo ảnh manifest chưa được: ' + er.message); luu('hd_ket', { key: 'taoanh', ten: 'Đang tạo ảnh manifest', chu: 'Lỗi: ' + er.message, luc: Date.now(), tg: Date.now() - bd, mau: 'vang' }); } veBang(); }, 'Đang tạo ảnh manifest'); return; }
    if (hd === 'chonkenhthe') { ui6.kenhThe = +k || 1; veBangNgay(); return; } // (6.19.3) chọn kênh để sửa thẻ video (chưa lưu thì vẫn giữ chữ đang sửa của từng kênh)
    if (hd === 'themd') { const t = nhapThe(); const c = ui6.kenhThe || 1; if (k === 'manifest') t.manifest = CAI_DAT.THE_MANIFEST.join('\n'); else t[truongThe()] = (c === 1 ? CAI_DAT.THE_VIDEO : CAI_DAT['THE_VIDEO_K' + c]).join('\n'); t.sua = true; nhacNho('Đã điền lại kho thẻ mẫu cho ' + (k === 'manifest' ? 'Manifest' : 'Video kênh ' + c) + ' — bấm Lưu kho thẻ để áp dụng'); veBangNgay(); return; }
    if (hd === 'huythe') { ui6.the = null; nhacNho('Đã huỷ thay đổi kho thẻ'); veBangNgay(); return; }
    if (hd === 'xemthe') { ui6.xemThe = true; nhacNho('Xem thử 8 thẻ mỗi video / manifest hôm nay (chưa lưu)'); veBangNgay(); return; }
    if (hd === 'dongxemthe') { ui6.xemThe = false; veBangNgay(); return; }
    if (hd === 'cmtphan') { ui6.cmtPhan = k === 'the' ? 'the' : 'cmt'; veBangNgay(); return; } // (6.27.1)
    if (hd === 'motabthe') { ui6.cmtPhan = 'the'; luu('ui_tab6', 'comment'); uiTab.moRong = true; veBangNgay(); setTimeout(() => { try { const x = document.querySelector('#smhfb [data-a="xacnhanthe"]'); if (x) x.scrollIntoView({ block: 'center' }); } catch (e) { /* */ } }, 300); return; } // (6.26.9)
    if (hd === 'xacnhanthe') { phanHoi(a); try { const k = khoThe(); await luuKhoThe({ video: k.video, video2: k.video2, video3: k.video3, video4: k.video4, manifest: k.manifest }); ghi('Bấm Xác nhận vẫn dùng bộ thẻ hiện tại'); nhacNho('Đã xác nhận bộ thẻ — 7 ngày sau sẽ nhắc kiểm tra lại'); } catch (er) { nhacNho('Đã xác nhận trên máy này, chưa lưu lên sheet (' + er.message + ')', 'vang', 8000); } ui6.the = null; veBangNgay(); return; }
    if (hd === 'luuthe') {
      const t = nhapThe(); const c = { video: dsThe(t.video), video2: dsThe(t.video2), video3: dsThe(t.video3), video4: dsThe(t.video4), manifest: dsThe(t.manifest) };
      if (!c.video.length || !c.manifest.length) { alert('Kho thẻ Video kênh 1 và kho thẻ Manifest cần ít nhất 1 thẻ (mỗi dòng 1 thẻ). Kho kênh 2, 3 để trống = không gắn thẻ.'); return; }
      t.dangLuu = true; phanHoi(a); veBangNgay();
      try { await luuKhoThe(c); ui6.the = null; nhacNho(`Đã lưu kho thẻ (video K1 ${c.video.length} · K2 ${c.video2.length} · K3 ${c.video3.length}, manifest ${c.manifest.length}) và đồng bộ lên sheet — áp dụng từ bài kế tiếp`); }
      catch (er) { ui6.the = null; nhacNho('Đã lưu trên máy này, nhưng chưa lưu được lên sheet (' + er.message + ')', 'vang', 8000); }
      veBangNgay(); return;
    }
    if (hd === 'cmtgochx') { const n = nhapCmt(); n.gocHx = CAI_DAT.CMT_HX; n.sua = true; nhacNho('Đã đưa comment Hà Xá về bản gốc — bấm Lưu để áp dụng'); veBangNgay(); return; }
    if (hd === 'cmtgoc') { const n = nhapCmt(); n.goc = CAI_DAT.CMT_BAI3; n.sua = true; nhacNho('Đã đưa comment mặc định về bản gốc — bấm Lưu để áp dụng'); veBangNgay(); return; }
    if (hd === 'ctamd') { const n = nhapCmt(); n.cta = CAI_DAT.CTA_MAC_DINH.join('\n'); n.sua = true; nhacNho('Đã điền lại 12 câu CTA mẫu — bấm Lưu để áp dụng'); veBangNgay(); return; }
    if (hd === 'huycmt') { ui6.cmt = null; nhacNho('Đã huỷ thay đổi, quay về bản đang dùng'); veBangNgay(); return; }
    if (hd === 'xemcmt') { ui6.xemCmt = true; nhacNho('Xem thử comment của các bài hôm nay (chưa lưu)'); veBangNgay(); return; }
    if (hd === 'dongxemcmt') { ui6.xemCmt = false; veBangNgay(); return; }
    if (hd === 'luucmt') {
      const n = nhapCmt(); const c = cmtTuNhap(n);
      if (!c.goc.trim()) { alert('Comment mặc định đang trống — điền nội dung rồi Lưu lại.'); return; }
      if (c.bat && !/^https?:\/\//i.test(c.link)) { alert('Link nhóm Zalo chưa đúng (phải bắt đầu bằng https://).'); return; }
      if (c.bat && !c.cta.length) { alert('Chưa có câu CTA nào — mỗi dòng 1 câu.'); return; }
      n.dangLuu = true; phanHoi(a); veBangNgay();
      try { await luuCauHinhCmt(c); ui6.cmt = null; nhacNho(`Đã lưu comment (${c.cta.length} câu CTA) và đồng bộ lên sheet — áp dụng từ bài kế tiếp`); }
      catch (er) { ui6.cmt = null; nhacNho('Đã lưu trên máy này, nhưng chưa lưu được lên sheet (' + er.message + ') — máy kia chưa nhận bản mới', 'vang', 8000); }
      veBangNgay(); return;
    }
    if (hd === 'xoafont') { const ten = a.getAttribute('data-ten'); if (!confirm(`Xoá font "${ten}" khỏi máy này?`)) return; xoaFont(ten); veBangNgay(); return; }
    if (hd === 'velaifont') { phanHoi(a); theoDoi('taoanh', async () => { const bd = Date.now(); try { const kq = await veLaiFont(); luu('hd_ket', { key: 'taoanh', ten: 'Đang vẽ lại ảnh với font mới', chu: kq, luc: Date.now(), tg: Date.now() - bd, mau: 'ok' }); } catch (er) { luu('hd_ket', { key: 'taoanh', ten: 'Đang vẽ lại ảnh với font mới', chu: 'Lỗi: ' + er.message, luc: Date.now(), tg: Date.now() - bd, mau: 'vang' }); } veBang(); }, 'Đang vẽ lại ảnh với font mới'); return; }
    if (hd === 'xemanh') { ui6.xem = +a.getAttribute('data-i'); veBangNgay(); return; }
    if (hd === 'dongxem') { if (ev.target.closest('.mfxk') && a.classList.contains('mfxem')) return; ui6.xem = null; veBangNgay(); return; }
    if (hd === 'chonanh') { const x = mf.ds[+a.getAttribute('data-i')]; if (x) { x.chon = !x.chon; nhacNho(x.chon ? `Sẽ dán ảnh ô ${x.oKQ}` : `Không dán ảnh ô ${x.oKQ}`); } veBangNgay(); return; }
    if (hd === 'taolai') { phanHoi(a); theoDoi('taoanh', () => taoLaiAnh(+a.getAttribute('data-i')), 'Đang tạo lại ảnh manifest'); veBangNgay(); return; }
    if (hd === 'dananh') { const n = mf.ds.filter((x) => x.chon && x.blob && x.tt !== 'xong').length; if (!n) return; if (!confirm(`Dán ${n} ảnh vào sheet (tab "Kênh 1 Vòng Trầm Hương SMH", ghi đè ảnh cũ trong các ô ${mf.ds.filter((x) => x.chon && x.blob && x.tt !== 'xong').map((x) => x.oKQ).join(', ')})?`)) return; phanHoi(a); theoDoi('danmf', async () => { const bd = Date.now(); try { const kq = await danAnhVaoSheet(); luu('hd_ket', { key: 'danmf', ten: 'Đang dán ảnh manifest vào sheet', chu: kq, luc: Date.now(), tg: Date.now() - bd, mau: /\/(\d+)/.test(kq) && kq.match(/đã dán (\d+)\/(\d+)/) && kq.match(/đã dán (\d+)\/(\d+)/)[1] === kq.match(/đã dán (\d+)\/(\d+)/)[2] ? 'ok' : 'vang' }); } catch (er) { alert('Dán chưa được: ' + er.message); } veBang(); }, 'Đang dán ảnh manifest vào sheet'); return; }
    if (hd === 'nghenhac') {
      if (ui6.nhac) { ui6.nhac.pause(); ui6.nhac = null; nhacNho('Đã dừng nhạc'); veBangNgay(); return; }
      const b = nhacBlob(); if (!b) return;
      const au = new Audio(URL.createObjectURL(b)); ui6.nhac = au; au.play().catch(() => {}); nhacNho('Đang phát thử 15 giây nhạc nền — bấm lại để dừng');
      const dung = () => { if (ui6.nhac === au) { au.pause(); ui6.nhac = null; veBangNgay(); } };
      au.onended = dung; setTimeout(dung, 15000); veBangNgay(); return;
    }
    if (hd === 'laynhac') { phanHoi(a); const cu = lay('nhac6', ''), cuI = lay('nhac6_info', null); luu('nhac6', ''); luu('nhac6_info', null); theoDoi('nhac', async () => { try { await damBaoNhac(); if (hdChay) hdChay.cuoi = 'đã lấy nhạc từ ô ' + lay('o_nhac6', CAI_DAT.O_NHAC_DU_PHONG); } catch (er) { luu('nhac6', cu); luu('nhac6_info', cuI); alert('Chưa lấy được nhạc: ' + er.message); } veBang(); }, 'Đang lấy nhạc từ ô dự phòng'); return; }
    if (hd === 'baoloi') { await xuatBaoLoi(); return; }
    if (hd === 'caima') { await caiMaKhoa(); return; }
    if (hd === 'kiemma') { await kiemMaKhoa(); return; }
    if (hd === 'chuto' || hd === 'chunho') { luu('ui_co_chu', Math.min(1.6, Math.max(0.9, Math.round((coChu() + (hd === 'chuto' ? 0.1 : -0.1)) * 10) / 10))); veBangNgay(); return; }
    if (hd === 'dungtab') { const kh = GM_getValue('khoa_dang_bai_that', null); if (kh && kh.ban && kh.id !== MA_TAB) { alert('Tab kia đang làm dở — đợi xong rồi bấm lại.'); return; } GM_setValue('khoa_dang_bai_that', { id: MA_TAB, ts: Date.now(), hien: true, anTu: 0, ban: false, v: PHIEN_BAN, ghim: true }); ghi('Đặt tab này làm Main (tab chính)'); veBangNgay(); setTimeout(nhip, 300); return; }
  }, true);
  // đang có bài soạn dở (chờ bấm Đăng) mà bấm Soạn/Đăng bài khác → hỏi bỏ bản cũ
  function boSoanDo() {
    if (dangBan) { alert('Script đang đăng/comment dở một bài — đợi xong (xem thanh hoạt động) rồi bấm lại.'); return false; }
    { const dd = lay('dang_do', null); // (6.20.2) bài dở còn ghi lại nhưng không có gì đang chạy (vd đang Tạm dừng nên script không làm tiếp) → nói rõ và cho bỏ
      if (dd) {
        const ten = dd.ten || tenSlot(dd.slot) || 'một bài'; const luc = dd.luc ? gioStr(new Date(dd.luc)) : '?';
        ghi(`Bấm Soạn nhưng còn ghi "${ten}" làm dở từ ${luc}${tamDung() ? ' (máy đang Tạm dừng nên chưa làm tiếp)' : ''}`);
        if (!confirm(`Còn ghi "${ten}" đang làm dở (đăng/comment) từ ${luc}${tamDung() ? ' — máy đang TẠM DỪNG nên script chưa làm tiếp' : ''}.\n\nOK = bỏ phần dở đó (nếu bài đã lên trang, nút Kiểm tra bài sẽ nhận lại và comment bù) rồi soạn bài mới.\nHuỷ = giữ lại, bấm "Chạy lại" để script làm nốt.`)) return false;
        luu('dang_do', null); ghi(`Bỏ phần làm dở của "${ten}" (người dùng chọn) để soạn bài mới`);
      } }
    const p = lay('cho_tay6', null); if (!p) return true;
    if (!confirm(`Đang có ${p.ten} soạn sẵn từ ${gioStr(new Date(p.luc))} (chưa bấm Đăng).\n\nBỏ bản soạn đó để làm bài mới?\n(Nếu hộp soạn còn mở trên trang, script sẽ đóng nó.)`)) return false;
    luu('cho_tay6', null);
    capNhatTT((s) => { const x = ttSlot(s, p.slot); if (!XONG.includes(x.tt)) { x.tt = 'cho'; x.thuLai = 0; x.daSoan = 0; } }, p.mai || homNay());
    ghi(`Bỏ bản soạn dở ${p.ten} (bạn bấm làm bài khác)`);
    dongHopSoan().catch(() => {});
    return true;
  }
  async function xuatBaoLoi() {
    const s = trangThai();
    const txt = anBiMat([`BÁO LỖI — ${TEN_HE_THONG} bản ${PHIEN_BAN} · ${TEN_MAY} · ${ngayStr(new Date())} ${gioStr(new Date())}`, `Trang: ${location.pathname} · tab ${laTabChinh() ? 'làm việc' : 'phụ'} · ${document.visibilityState}`, 'Lịch hôm nay: ' + JSON.stringify(s), 'Việc dở: ' + JSON.stringify(lay('dang_do', null)), 'Soạn chờ: ' + JSON.stringify(lay('cho_tay6', null)), 'Sức khoẻ: ' + JSON.stringify(lay('suc_khoe', {})), 'Lark: ' + JSON.stringify(lay('lark_gate', null)) + ' ' + JSON.stringify(lay('lark_dem', null)), '— NHẬT KÝ —', ...docNhatKy(3).map(dongNK)].join('\n'));
    let daCopy = false;
    try { await navigator.clipboard.writeText(txt); daCopy = true; } catch (e) { /* */ }
    const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([txt], { type: 'text/plain;charset=utf-8' })); a.download = `bao-loi-dang-bai-6.0-${homNay()}-${gioStr(new Date()).replace(':', 'h')}.txt`; document.body.appendChild(a); a.click(); a.remove();
    alert((daCopy ? 'Đã copy bản báo lỗi và ' : '') + 'đã tải file báo lỗi về máy — gửi file đó để kiểm tra.');
  }
