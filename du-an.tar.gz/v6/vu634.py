# (6.34) KÊNH 5 — PAGE PHỤ "Trầm Hương Mỗi Ngày - SMH": lịch + ảnh/video từ GitHub (page-phu/lich.json), không dùng Lark; chỉ Máy Cao đăng
# Bài 'anh' (1 ảnh) / 'cuon' (nhiều ảnh) đăng như Bài 3 kênh 1 (ảnh, không nền đỏ, không comment); bài 'reel' (video 9:16) đăng như video kênh phụ.
# Không gắn vị trí, không chia sẻ nhóm, không gắn thẻ, không comment; vẫn thả cảm xúc. "Đã đăng" ghi trong máy (gh_xong6), không ghi sheet.

# ---- đọc dữ liệu: chỉ các kênh Lark mới đọc tab; kênh GitHub đọc lich.json ----
out = thay(out, "KENH_PHU.map((c) => [CAI_DAT.KENH[c].tab, vungKenh(c)])", "KENH_LARK.map((c) => [CAI_DAT.KENH[c].tab, vungKenh(c)])")
out = thay(out, "KENH_PHU.forEach((c, i) => { vK[c] = { values: g[3 + i] }; });", "KENH_LARK.forEach((c, i) => { vK[c] = { values: g[3 + i] }; });")
out = thay(out, "g[3 + KENH_PHU.length]", "g[3 + KENH_LARK.length]", 3)
out = thay(out, "for (const c of KENH_PHU) { // (6.19) kênh 2, 3, Hà Xá — đọc lỗi", "for (const c of KENH_LARK) { // (6.19) kênh 2, 3, Hà Xá — đọc lỗi")
out = thay(out, "      const d = phanTich(vB, vV, loai, vK);",
  """      for (const c of KENH_PHU) if (laGh(c)) { try { vK[c] = { gh: await docLichGh(c) }; } catch (e) { vK[c] = { loi: `chưa đọc được lich.json trên GitHub (${e.message})` }; ghi(`${tenKenh(c)}: ${vK[c].loi}`); } } // (6.34)
      const d = phanTich(vB, vV, loai, vK);""")
out = thay(out, "    for (const c of KENH_PHU) {\n      const x = vK[c]; if (!x) continue;\n      if (x.loi) { out.loiKenh[c] = x.loi; continue; }",
  "    for (const c of KENH_PHU) {\n      const x = vK[c]; if (!x) continue;\n      if (x.loi) { out.loiKenh[c] = x.loi; continue; }\n      if (x.gh) { for (let i = 0; i <= 3; i++) { const ngay = ngayStr(congNgay(i)); out.ngay[ngay]['k' + c] = hangGh(x.gh, c, ngay); } continue; } // (6.34)")
out = thay(out, "  function phanTich(vB, vV, loai, vK) {", """  // ---- (6.34) kênh GitHub: lich.json = { bai: [{ id, ngay 'dd-mm-yyyy', gio 'HH:MM', loai 'anh'|'cuon'|'reel', caption, tep: [tên file] }] } ----
  function docLichGh(c) {
    const cfg = CAI_DAT.KENH[c];
    return new Promise((res, rej) => {
      GM_xmlhttpRequest({ method: 'GET', url: cfg.gh + 'lich.json?t=' + Date.now(), timeout: 30000, headers: { 'Cache-Control': 'no-cache' },
        onload: (r) => { if (r.status !== 200) return rej(new Error('GitHub trả về ' + r.status)); try { const j = JSON.parse(r.responseText); if (!j || !Array.isArray(j.bai)) throw new Error('thiếu danh sách bai'); res(j); } catch (e) { rej(new Error('lich.json sai định dạng: ' + e.message)); } },
        onerror: () => rej(new Error('không kết nối được GitHub')), ontimeout: () => rej(new Error('GitHub quá lâu không trả lời')) });
    });
  }
  const ghXongDs = () => lay('gh_xong6', {}) || {};
  function hangGh(j, c, ngay) {
    const cfg = CAI_DAT.KENH[c]; const xong = ghXongDs(); const out = [];
    (j.bai || []).forEach((b, i) => {
      if (!b || String(b.ngay || '').trim() !== ngay) return;
      const tepDs = (Array.isArray(b.tep) ? b.tep : []).map((t) => String(t || '').trim()).filter(Boolean).map((t) => (/^https?:/.test(t) ? t : cfg.gh + encodeURIComponent(t)));
      const loaiBai = /reel|video/i.test(b.loai || '') ? 'reel' : (tepDs.length > 1 ? 'cuon' : 'anh');
      const id = String(b.id || ('gh' + (i + 1))); const daDang = !!(xong[id] || xong[ngay + '|' + id]);
      out.push({ hang: i + 2, id, cap: String(b.caption || '').trim(), tep: tepDs.length ? { gh: tepDs, loaiBai, ten: id } : null, tt: daDang ? 'ĐÃ ĐĂNG' : '', duyet: !!tepDs.length && !daDang, daDang, link: '', gio: String(b.gio || '').trim() });
    });
    return out;
  }
  function ghXong(dd) { // (6.34) đánh dấu bài page phụ đã đăng (lưu trong máy; lich.json không ghi ngược được)
    try { const c = kenhCua(dd.slot); if (!laGh(c)) return; const ngay = dd.ngay || homNay(); const nd = noiDungSlot(ngay, dd.slot); const id = (nd && nd.id) || (ngay + '|' + dd.slot);
      const st = ghXongDs(); st[id] = { luc: Date.now(), ngay, link: dd.link || '' }; for (const k of Object.keys(st)) if (Date.now() - (st[k].luc || 0) > 60 * 86400000) delete st[k]; luu('gh_xong6', st); } catch (e) { /* */ }
  }
  function phanTich(vB, vV, loai, vK) {""")
out = thay(out, "return { thieu: th, text: x ? x.cap : '', tep: x ? x.tep : null, hang: x ? x.hang : 0, daDang: x ? x.daDang : false, link: x ? x.link : '', kenh: c };",
  "return { thieu: th, text: x ? x.cap : '', tep: x ? x.tep : null, hang: x ? x.hang : 0, daDang: x ? x.daDang : false, link: x ? x.link : '', kenh: c, loaiBai: x && x.tep ? x.tep.loaiBai || '' : '', gio: x ? x.gio || '' : '', id: x ? x.id || '' : '' }; // (6.34) kênh GitHub: loại bài + giờ + mã bài")
# ---- ô lịch k5a… (nhóm k2–k5) ----
out = thay(out, "const q = String(k || '').match(/^k([2-4])([a-h])$/)", "const q = String(k || '').match(/^k([2-5])([a-h])$/)")
out = thay(out, "nhan: `${CAI_DAT.KENH[c].hx ? 'HX' : 'K' + c}·${i + 1}`, loai: 'video', so: i, kenh: c };",
  "nhan: `${CAI_DAT.KENH[c].hx ? 'HX' : laGh(c) ? 'P' + c : 'K' + c}·${i + 1}`, loai: 'video', so: i, kenh: c, gh: laGh(c) }; // (6.34)")
out = thay(out, "ten: `${tenKenh(c)} · Video ${i + 1}`, tenBC: `${tenKenhDai(c)} · Video ${i + 1}`, nhan:", "ten: `${tenKenh(c)} · ${laGh(c) ? 'Bài' : 'Video'} ${i + 1}`, tenBC: `${tenKenhDai(c)} · ${laGh(c) ? 'Bài' : 'Video'} ${i + 1}`, nhan:")
out = thay(out, "for (const c of KENH_PHU) for (const k of gd.keys['k' + c] || []) out.push(itSlot('k' + c, nhomSlot(k).so));",
  "for (const c of KENH_PHU) { if (laGh(c) && CAI_DAT.KENH[c].chiCao && !LA_CAO) continue; for (const k of gd.keys['k' + c] || []) out.push(itSlot('k' + c, nhomSlot(k).so)); } // (6.34) page phụ chỉ Máy Cao đăng")
out = thay(out, "    for (const c of KENH_PHU) {\n      const cfg = CAI_DAT.KENH[c]; const ten = tenKenhDai(c);", "    for (const c of KENH_PHU) {\n      if (laGh(c)) continue; // (6.34) kênh GitHub: không nhắc nhân sự\n      const cfg = CAI_DAT.KENH[c]; const ten = tenKenhDai(c);")
for _a in ["/^k[2-4]|^kenh/", "/^(k[2-4][a-h]|[vm][4-9])$/", "/^k[2-4]/"]:
    out = out.replace(_a, _a.replace('2-4', '2-5'))
assert 'k[2-4]' not in out and 'k([2-4])' not in out, 'còn chỗ [2-4]'
# ---- giờ đăng: theo giờ trong lich.json ± 10 phút (ngẫu nhiên theo ngày) ----
out = thay(out, "      const co = ds.filter((x) => typeof s.gio[x.k] === 'number');\n      const kh = khungKenh(c);",
  """      if (laGh(c)) { // (6.34) page phụ: giờ ghi trong lich.json (± 10 phút, ngẫu nhiên theo ngày); thiếu giờ → 11:30
        const gd = ganDong(ngay); const r5 = ngauTheoNgay(ngay, 'gh' + c);
        for (const x of ds) { if (typeof s.gio[x.k] === 'number') continue; const row = gd.map[x.k]; const g0 = row && laGio(row.gio) ? docGio(row.gio) : 11 * 60 + 30; s.gio[x.k] = g0 + Math.round(r5() * 20) - 10; }
        doi = true; continue;
      }
      const co = ds.filter((x) => typeof s.gio[x.k] === 'number');
      const kh = khungKenh(c);""")
# ---- tải tệp từ GitHub (kho đệm như Lark) ----
out = thay(out, "  async function taiAnhKho(token, ten)", """  async function taiTepGh(url, loai, ten) { // (6.34) tải ảnh/video từ GitHub raw (có kho đệm, dọn sau 3 ngày như tệp Lark)
    const k = 'tep|gh|' + url; const c = await khoLay(k); if (c && c.blob && c.blob.size > 500) return c.blob;
    const blob = await new Promise((res, rej) => {
      GM_xmlhttpRequest({ method: 'GET', url, responseType: 'blob', timeout: 300000,
        onload: (r) => (r.status === 200 && r.response && r.response.size > 500 ? res(r.response) : rej(new Error(`GitHub trả về ${r.status} khi tải ${ten}`))),
        onerror: () => rej(new Error('không tải được ' + ten + ' từ GitHub')), ontimeout: () => rej(new Error('tải ' + ten + ' từ GitHub quá lâu')) });
    });
    await khoLuu(k, blob, { loai, gh: 1 }); ghi(`Đã tải ${ten} từ GitHub (${(blob.size / 1048576).toFixed(1)} MB)`); return blob;
  }
  async function taiAnhKho(token, ten)""")
# ---- đăng bài page phụ ----
out = thay(out, "  async function dangSlot(it, nd, thu, ngayBai) {", """  async function dangGh(it, nd, thu, ngayTT, ngay, luiCho, choTay) { // (6.34) page phụ: 'anh' / 'cuon' → đăng ảnh như Bài 3; 'reel' → đăng video
    const loaiBai = nd.loaiBai || 'anh'; const urls = (nd.tep && nd.tep.gh) || [];
    if (!urls.length) throw new LoiMem('Bài page phụ chưa có tệp ảnh/video');
    const cfg = CAI_DAT.KENH[it.kenh] || {};
    window.__smhBoViTri = !!cfg.boViTri; window.__smhBoThe = !!cfg.boThe; window.__smhBoNhom = !!cfg.boNhom; window.__smhNhe = true; window.__smhThe = []; window.__smhTheDuoc = 0;
    if (loaiBai === 'reel') {
      const b = await taiTepGh(urls[0], 'video', it.ten); const tenTep = decodeURIComponent(urls[0].split('/').pop() || 'video.mp4');
      const file = new File([b], /\\.(mp4|mov|m4v|webm)$/i.test(tenTep) ? tenTep : tenTep + '.mp4', { type: (b.type && /^video\\//.test(b.type)) ? b.type : 'video/mp4' });
      if (!(await damBaoTuCach())) { luiCho(); return; }
      if (!dungTrang()) { luiCho(); veTrang(); return; }
      if (hopDangDo() || hopSoanBai() || ganManHinh()) { ghi('Có hộp đăng bài mở dở → đóng lại'); if (!(await dongHopSoan()) || ganManHinh()) { await dongHopVideo(); if (ganManHinh() || hopSoanBai()) { luiCho(); roiTrang(); return; } } }
      const kq = await dangVideoFb({ slot: it.k, ten: it.ten, loai: 4, text: nd.text, file, cmts: [], hang: nd.hang, ngay }, { soanThu: thu });
      if (thu) { choTay({ video: true }); return; }
      void kq; return;
    }
    const files = [];
    for (let i = 0; i < urls.length; i++) { kiemDung(); files.push(await thuNhoAnh(await taiTepGh(urls[i], 'anh', `${it.ten} ảnh ${i + 1}`), 'anh-' + (i + 1))); }
    if (!(await damBaoTuCach())) { luiCho(); return; }
    if (!dungTrang()) { luiCho(); veTrang(); return; }
    if (hopDangDo() || hopSoanBai()) { ghi('Có hộp đăng bài mở dở → đóng lại'); if (!(await dongHopSoan())) { luiCho(); roiTrang(); return; } }
    const bai = { ngay, hang: nd.hang, khoa: ngay + '|' + it.k, bai: nd.text, cmt: '', files,
      ddThem: { slot: it.k, loai: 3, ten: it.ten, cmts: [], cmtIdx: 0, soAnh: files.length, ghiChuTruoc: window.__smhBoQua || [] } };
    const soNhom = await dangLenFacebook(bai, { soanThu: thu });
    if (thu) { choTay({}); return; }
    const thay = await cho(() => timBai(nd.text), 60000, 1000);
    if (!thay) { ghi('Chưa thấy bài trên trang → tải lại để kiểm tra'); roiTrang(CAI_DAT.URL_TRANG); return; }
    ghi('B10. Đã thấy bài trên trang');
    const dd = lay('dang_do', null) || Object.assign({ ngay, hang: nd.hang, khoa: bai.khoa, bai: nd.text, soNhom }, bai.ddThem);
    await sauKhiDangSlot(dd);
  }
  async function dangSlot(it, nd, thu, ngayBai) {""")
out = thay(out, "  async function sauKhiDangSlot(dd) {\n", "  async function sauKhiDangSlot(dd) {\n    ghXong(dd); // (6.34) page phụ: ghi nhớ đã đăng (trong máy)\n")
out = thay(out, "if (dd.loai !== 4 || !dd.hang) return true;", "if (laGh(kenhCua(dd.slot))) { ghXong(dd); return true; } // (6.34) không có sheet để ghi\n    if (dd.loai !== 4 || !dd.hang) return true;", 2)
# không comment
out = thay(out, "  function canCmt(it, nd, chung, ngay) { // các comment cần có dưới bài (để kiểm và gửi bù)\n",
  "  function canCmt(it, nd, chung, ngay) { // các comment cần có dưới bài (để kiểm và gửi bù)\n    if (it && it.k && (CAI_DAT.KENH[kenhCua(it.k)] || {}).khongCmt) return { text: [], anh: [] }; // (6.34) page phụ: không comment\n")
# bài ảnh: bỏ bước vị trí + bỏ chia sẻ nhóm khi kênh yêu cầu
out = thay(out, "    kiemDung();\n    try {\n    // vị trí", "    kiemDung();\n    if (window.__smhBoViTri) ghi('B4. Kênh này không gắn vị trí → bỏ qua'); else try { // (6.34)\n    // vị trí")
out = thay(out, "let soNhom = 0, caiDat2 = null;\n    try {", "let soNhom = 0, caiDat2 = null;\n    if (window.__smhBoNhom) { caiDat2 = caiDat; ghi('B6. Kênh này không chia sẻ lên nhóm → bỏ qua'); } else try { // (6.34)")
# bài kênh 1 vẫn gắn vị trí / nhóm như cũ: xoá cờ khi bắt đầu đăng bài kênh 1 (dangSlot nhánh b1/b2/b3)
out = thay(out, "    if (it.loai === 'b1' || it.loai === 'b2' || it.loai === 'b3') {\n      const files = [];", "    if (it.loai === 'b1' || it.loai === 'b2' || it.loai === 'b3') {\n      window.__smhBoViTri = false; window.__smhBoNhom = false; // (6.34) bài kênh 1: vị trí + nhóm như cũ\n      const files = [];")
out = thay(out, "    if (it.loai === 'b1' || it.loai === 'b2' || it.loai === 'b3') {\n      window.__smhBoViTri = false;", "    if (laGh(it.kenh || 1)) { await dangGh(it, nd, thu, ngayTT, ngay, luiCho, choTay); return; } // (6.34) page phụ: tự tải từ GitHub, không qua Lark\n    if (it.loai === 'b1' || it.loai === 'b2' || it.loai === 'b3') {\n      window.__smhBoViTri = false;")

# ---- video page phụ: không chọn nhóm (khi kênh yêu cầu) ----
out = thay(out, """    const n = (await phu('chọn nhóm', async () => {
      const k = await ganNhom(bao);""", """    const n = window.__smhBoNhom ? { tong: 0, moi: 0, boQua: true } : (await phu('chọn nhóm', async () => { // (6.34) page phụ: không chia sẻ nhóm
      const k = await ganNhom(bao);""")
out = thay(out, "    if (n.tong) B('V5. Đã chọn ' + n.tong + ' nhóm'); else if (n.trong)", "    if (n.boQua) B('V5. Kênh này không chia sẻ lên nhóm → bỏ qua'); else if (n.tong) B('V5. Đã chọn ' + n.tong + ' nhóm'); else if (n.trong)")
# video/manifest kênh 1 + kênh 2–4: xoá cờ bỏ nhóm (chỉ page phụ bật)
out = thay(out, "    window.__smhNhe = true; // (6.26.9) mọi kênh:", "    window.__smhBoNhom = false; // (6.34) chỉ page phụ mới bỏ nhóm\n    window.__smhNhe = true; // (6.26.9) mọi kênh:")
# ---- Máy Cao: bài page phụ đăng đúng giờ hẹn (không chờ Máy Giao như bài kênh 1) ----
out = thay(out, "    if (LA_CAO && !ep) batDau = Math.max(it.den + CAI_DAT.CAO_TRE_PHUT * 60000, moLuc + CAI_DAT.CAO_CHO_MO_PHUT * 60000);",
  "    if (LA_CAO && !ep && !laGh(it.kenh || 1)) batDau = Math.max(it.den + CAI_DAT.CAO_TRE_PHUT * 60000, moLuc + CAI_DAT.CAO_CHO_MO_PHUT * 60000); // (6.34) page phụ chỉ Máy Cao đăng → không chờ Máy Giao")

# ---- ô page phụ: loại bài theo dòng (ảnh → như Bài 3, reel → video) ----
out = thay(out, "  function itSlot(nhom, i) {", "  function itSlot(nhom, i, ngay) {")
out = thay(out, "    const c = +nhom[1]; return { k: keySlot(nhom, i), ten:", "    const c = +nhom[1];\n    if (laGh(c)) { const row = (ganDong(ngay || homNay()).map || {})[keySlot(nhom, i)]; const reel = !!(row && row.tep && row.tep.loaiBai === 'reel'); return { k: keySlot(nhom, i), ten: `${tenKenh(c)} · Bài ${i + 1}`, tenBC: `${tenKenhDai(c)} · Bài ${i + 1}`, nhan: `P${c}·${i + 1}`, loai: reel ? 'video' : 'b3', so: i, kenh: c, gh: true }; } // (6.34)\n    return { k: keySlot(nhom, i), ten:")
out = thay(out, "for (const k of gd.keys['k' + c] || []) out.push(itSlot('k' + c, nhomSlot(k).so)); } // (6.34) page phụ chỉ Máy Cao đăng", "for (const k of gd.keys['k' + c] || []) out.push(itSlot('k' + c, nhomSlot(k).so, ngay)); } // (6.34) page phụ chỉ Máy Cao đăng")
# ---- Máy Cao: bài page phụ là việc của chính nó → không đọc lại sheet, không giữ chỗ Z1, không báo "đăng thay" ----
out = thay(out, "    if (LA_CAO && !ep && !chanDocLark() && Date.now() - ((duLieu() || {}).luc || 0) > 20 * 60000 && it.r.caoDoc !== it.den) {", "    if (laGh(it.kenh || 1)) { /* (6.34) page phụ: không giữ chỗ, không đọc lại sheet, không báo đăng thay */ }\n    else if (LA_CAO && !ep && !chanDocLark() && Date.now() - ((duLieu() || {}).luc || 0) > 20 * 60000 && it.r.caoDoc !== it.den) {")

# ---- (6.34.1) đọc lại lich.json RIÊNG, không chờ lượt đọc Lark (Máy Cao hiếm khi đọc Lark → page phụ không có ô lịch) ----
out = thay(out, "  async function docDuLieu(loai) {", """  async function lamMoiGh(lyDo) { // (6.34.1) đọc lich.json (GitHub, không tốn lượt Lark) và trộn vào dữ liệu đang có, dựng lại lịch
    const ds = KENH_PHU.filter((c) => laGh(c) && !(CAI_DAT.KENH[c].chiCao && !LA_CAO)); if (!ds.length) return;
    const d = duLieu(); if (!d || !d.ngay) return; // chưa có dữ liệu → lượt đọc sheet đầu tiên sẽ đọc luôn lich.json
    const t0 = Date.now(); let doi = false;
    for (const c of ds) {
      let j; try { j = await docLichGh(c); } catch (e) { (d.loiKenh = d.loiKenh || {})[c] = `chưa đọc được lich.json trên GitHub (${e.message})`; ghi(`${tenKenh(c)}: ${d.loiKenh[c]} — thử lại sau`); doi = true; continue; }
      if (d.loiKenh) delete d.loiKenh[c];
      for (let i = 0; i <= 3; i++) { const ngay = ngayStr(congNgay(i)); if (!d.ngay[ngay]) continue; const cu = JSON.stringify(d.ngay[ngay]['k' + c] || []); d.ngay[ngay]['k' + c] = hangGh(j, c, ngay); if (JSON.stringify(d.ngay[ngay]['k' + c]) !== cu) doi = true; }
    }
    luu('gh_doc6', Date.now());
    if (!doi) return;
    luu('du_lieu6', d);
    try { dongBoLich(); } catch (e) { ghi('Page phụ: dựng lịch lỗi ' + e.message); }
    const n = (d.ngay[homNay()] || {}); ghi(`Page phụ: đã đọc lich.json (${lyDo}) — hôm nay ${ds.map((c) => (n['k' + c] || []).length).join('+')} bài · ${((Date.now() - t0) / 1000).toFixed(1)} giây`);
  }
  async function nhipGh() { // mở trang sau ~25 giây; sau đó 60–100 phút/lần (ngẫu nhiên); hôm nay chưa có bài page phụ → 20 phút/lần
    try {
      if (!LA_CAO || !laTabChinh()) return;
      const d = duLieu(); const n = d && d.ngay && d.ngay[homNay()]; const coBai = KENH_PHU.some((c) => laGh(c) && n && (n['k' + c] || []).length);
      const cach = coBai ? (60 + Math.floor(Math.random() * 40)) * 60000 : 20 * 60000;
      if (Date.now() - (lay('gh_doc6', 0) || 0) < cach) return;
      await lamMoiGh(coBai ? 'định kỳ' : 'hôm nay chưa có bài page phụ');
    } catch (e) { ghi('Page phụ: đọc lich.json lỗi ' + e.message); }
  }
  setTimeout(nhipGh, 25000);
  setInterval(nhipGh, 5 * 60000);
  async function docDuLieu(loai) {""")
