  // =====================================================================
  //  (6.30) TRỢ LÝ LARK WEB — chạy trên tab sheet Lark (MKT 10) đang mở trên Chrome của máy đăng.
  //  Khi Lark hết lượt API, tab Facebook đặt cờ "lark_webcan6" → trợ lý đọc sheet bằng tài khoản Lark đang đăng nhập
  //  (giống trang Lark tự tải), giải mã dữ liệu ô, lưu vào bộ nhớ chung của script để tab Facebook dùng như đọc API.
  //  Không bấm, không sửa gì trên sheet. Tự chạy 20–30 phút/lần khi cần, hoặc ngay khi tab Facebook bấm "Đọc ngay".
  // =====================================================================
  function larkWebHelper() {
    const gl = (k, d) => GM_getValue('that_' + k, d);
    const gs = (k, v) => GM_setValue('that_' + k, v);
    const TOKEN_MD = 'WPhusx4UJhvTbstKQHFlNkWHggd';
    const TABS_MD = ['apU3Ne', 't79PeC', 'em39qJ', '4OtbFA', 'ZSDDld'];
    const PB = {
      rv(b, p) { let x = 0, s = 0, c; do { c = b[p++]; x += (c & 127) * Math.pow(2, s); s += 7; } while (c & 128); return [x, p]; },
      fields(b, st = 0, en = b.length) { const out = []; let p = st; while (p < en) { let k; [k, p] = this.rv(b, p); const f = Math.floor(k / 8), w = k & 7;
        if (w === 0) { let v; [v, p] = this.rv(b, p); out.push({ f, w, v }); } else if (w === 2) { let L; [L, p] = this.rv(b, p); if (p + L > en) throw new Error('độ dài sai'); out.push({ f, w, s: p, e: p + L }); p += L; }
        else if (w === 1) { out.push({ f, w, v: new DataView(b.buffer, b.byteOffset + p, 8).getFloat64(0, true) }); p += 8; } else if (w === 5) { out.push({ f, w, v: new DataView(b.buffer, b.byteOffset + p, 4).getFloat32(0, true) }); p += 4; }
        else throw new Error('kiểu ' + w); } return out; },
      sub(b, x) { return b.subarray(x.s, x.e); },
      str(b, x) { return new TextDecoder().decode(b.subarray(x.s, x.e)); },
      packed(b, x) { const a = []; let p = x.s; while (p < x.e) { let v; [v, p] = this.rv(b, p); a.push(v); } return a; },
    };
    async function gun(b64) {
      const bin = Uint8Array.from(atob(b64), (c) => c.charCodeAt(0));
      if (!(bin[0] === 0x1f && bin[1] === 0x8b)) return bin;
      return new Uint8Array(await new Response(new Blob([bin]).stream().pipeThrough(new DecompressionStream('gzip'))).arrayBuffer());
    }
    function giaiMa(u8) { // khối ô → { hd: {1: hàng đầu, 2: cột đầu, 3: số hàng, 4: số cột}, ... }
      const L1 = PB.fields(u8); const m1 = PB.sub(u8, L1.find((x) => x.f === 1)); const L2 = PB.fields(m1); const m2 = PB.sub(m1, L2.find((x) => x.f === 2));
      const L3 = PB.fields(m2); const m = PB.sub(m2, L3.find((x) => x.f === 12)); const L = PB.fields(m);
      const g = (f) => { const x = L.find((y) => y.f === f); return x ? PB.sub(m, x) : null; };
      const hd = {}; PB.fields(g(1)).forEach((x) => { hd[x.f] = x.w === 2 ? PB.str(g(1), x) : x.v; });
      const mv = g(2); const LV = mv ? PB.fields(mv) : [];
      const nums = []; const nb = LV.find((x) => x.f === 1); if (nb) { const b = PB.sub(mv, nb); const dv = new DataView(b.buffer, b.byteOffset, b.byteLength); for (let i = 0; i + 8 <= b.length; i += 8) nums.push(dv.getFloat64(i, true)); }
      const strs = LV.filter((x) => x.f === 2).map((x) => PB.str(mv, x));
      const rich = LV.filter((x) => x.f === 3).map((x) => { const o = { t: 0, seg: [] }; PB.fields(mv, x.s, x.e).forEach((y) => { if (y.f === 1) o.t = y.v; if (y.f === 2) { const s = {}; PB.fields(mv, y.s, y.e).forEach((z) => { if (z.w !== 2) s[z.f] = z.v; }); o.seg.push(s); } }); return o; });
      const ms = g(3); const bang = {};
      if (ms) PB.fields(ms).forEach((x) => { if (x.w !== 2) return; let fz; try { fz = PB.fields(ms, x.s, x.e); } catch (e) { return; } const o = {}; fz.forEach((y) => { let v = y.v; if (y.w === 2) { try { v = new TextDecoder('utf-8', { fatal: true }).decode(PB.sub(ms, y)); } catch (e) { v = null; } } o[y.f] = v; }); (bang[x.f] = bang[x.f] || []).push(o); });
      const mg = g(6); const LG = PB.fields(mg); const luoi = PB.packed(mg, LG.find((x) => x.f === 1));
      const recs = LG.filter((x) => x.f === 2).map((x) => { const o = {}; PB.fields(mg, x.s, x.e).forEach((y) => { if (y.w !== 2) o[y.f] = y.v; }); return o; });
      if (luoi.length !== (hd[3] || 0) * (hd[4] || 0)) throw new Error(`khối ${hd[5]}: lưới ${luoi.length} ô ≠ ${hd[3]}×${hd[4]}`);
      return { hd, nums, strs, rich, bang, luoi, recs };
    }
    function thanhGiaTri(D) { // → mảng 2 chiều đúng dạng API Lark trả về (chữ, số, [{type:'url'|'text'|'attachment'}], {type:'embed-image'})
      const R = D.hd[3], C = D.hd[4], T = D.bang; const vals = [];
      for (let r = 0; r < R; r++) {
        const row = [];
        for (let c = 0; c < C; c++) {
          const rc = D.recs[D.luoi[r * C + c]] || {}; const t = rc[1], i = rc[2] || 0; let v = null;
          if (t === 3) v = D.strs[i] != null ? D.strs[i] : null;
          else if (t === 2) v = D.nums[i] != null ? D.nums[i] : null;
          else if (t === 7) { const im = (T[1] || [])[i]; v = im && im[1] ? { type: 'embed-image', fileToken: im[1] } : null; }
          else if (t === 6) {
            const ri = D.rich[i]; const txt = (ri && D.strs[ri.t]) || ''; let p = 0; const segs = [];
            for (const sg of (ri ? ri.seg : [])) { const len = sg[2] || 0; const phan = txt.slice(p, p + len); p += len;
              if (sg[1] === 3) { const a = (T[6] || [])[sg[4] || 0]; segs.push(a && a[1] ? { type: 'attachment', fileToken: a[1], mimeType: a[2] || '', size: a[3] || 0, text: phan } : { type: 'text', text: phan }); }
              else if (sg[1] === 4) { const l = (T[5] || [])[sg[4] || 0]; segs.push({ type: 'url', text: phan, link: (l && l[1]) || phan }); }
              else segs.push({ type: 'text', text: phan }); }
            if (p < txt.length) segs.push({ type: 'text', text: txt.slice(p) });
            v = segs.length === 1 && segs[0].type === 'text' ? segs[0].text : segs.length === 1 && segs[0].type === 'attachment' ? segs[0] : segs;
          }
          row.push(v);
        }
        while (row.length && row[row.length - 1] == null) row.pop();
        vals.push(row);
      }
      return vals;
    }
    const csrf = () => (document.cookie.match(/_csrf_token=([^;]+)/) || [])[1] || '';
    async function layJson(url, opt, lan = 0) {
      try { const r = await fetch(url, Object.assign({ credentials: 'include' }, opt)); if (r.status === 401 || r.status === 403) throw new Error('Lark web từ chối (mã ' + r.status + ') — có thể đã đăng xuất'); const j = await r.json(); if (j.code !== 0) throw new Error('Lark web báo mã ' + j.code + (j.msg ? ' ' + j.msg : '')); return j; }
      catch (e) { if (lan < 1) { await new Promise((ok) => setTimeout(ok, 3000 + Math.random() * 3000)); return layJson(url, opt, lan + 1); } throw e; }
    }
    async function docTab(token, sid) {
      const j = await layJson('/space/api/v3/sheet/client_vars', { method: 'POST', headers: { 'Content-Type': 'application/json', 'x-command': 'api.sheet.rce.message', 'x-csrftoken': csrf() },
        body: JSON.stringify({ sheetRange: { sheetId: sid }, openType: 0, memberId: Math.floor(Math.random() * 1e13), token, schemaVersion: 9, clientVersion: 'v0.0.1' }) });
      const snap = (j.data && j.data.snapshot) || {}; const khoi = snap.blocks || {};
      const meta = snap.gzipBlockMeta ? JSON.parse(new TextDecoder().decode(await gun(snap.gzipBlockMeta))) : {};
      const ds = ((meta[sid] || {}).cellBlockMetas || []).slice().sort((a, b) => a.range.rowStart - b.range.rowStart);
      if (!ds.length) throw new Error('tab ' + sid + ' không có khối dữ liệu');
      const out = [];
      for (const bm of ds) {
        let b64 = khoi[bm.blockId];
        if (!b64) { const k = await layJson(`/space/api/v3/sheet/block?token=${encodeURIComponent(token)}&block_token=${encodeURIComponent(bm.blockId)}&schema_version=9&blockIds=${encodeURIComponent(bm.blockId)}`, {}); b64 = ((k.data || {}).blocks || {})[bm.blockId]; }
        if (!b64) throw new Error('chưa tải được khối ' + bm.blockId.slice(-12));
        const D = giaiMa(await gun(b64)); const v = thanhGiaTri(D);
        const r0 = D.hd[1] || bm.range.rowStart || 0, c0 = D.hd[2] || bm.range.colStart || 0;
        v.forEach((row, i) => { const R = out[r0 + i] = out[r0 + i] || []; row.forEach((x, k) => { if (x != null) R[c0 + k] = x; }); });
      }
      for (let i = 0; i < out.length; i++) if (!out[i]) out[i] = [];
      while (out.length && !out[out.length - 1].length) out.pop();
      return { values: out, rev: j.data.revision || 0 };
    }
    let dang = false;
    async function capNhat(ly) {
      if (dang) return; dang = true; const t0 = Date.now();
      const can = gl('lark_webcan6', null) || {}; const token = can.token || TOKEN_MD; const tabs = (can.tabs && can.tabs.length ? can.tabs : TABS_MD);
      try {
        const kq = {}; const rev = {};
        for (const sid of tabs) { const x = await docTab(token, sid); kq[sid] = x.values; rev[sid] = x.rev; }
        gs('lark_webdata6', { luc: Date.now(), token, tabs: kq, rev });
        gs('lark_webtt6', { luc: Date.now(), ok: true, ms: Date.now() - t0, ly, soTab: tabs.length, hang: tabs.map((s) => s + ':' + kq[s].length).join(' ') });
        bieuTuong(`✓ SMH đã đọc sheet lúc ${new Date().toTimeString().slice(0, 5)} (giữ tab này mở để script đăng bài khi Lark hết lượt)`, '#1b5e20');
      } catch (e) {
        gs('lark_webtt6', { luc: Date.now(), ok: false, loi: String(e.message || e).slice(0, 200), ly });
        bieuTuong('✗ SMH chưa đọc được sheet: ' + String(e.message || e).slice(0, 90), '#b71c1c');
      } finally { dang = false; }
    }
    let nhan = null;
    function bieuTuong(chu, mau) {
      try { if (!nhan) { nhan = document.createElement('div'); nhan.style.cssText = 'position:fixed;left:8px;bottom:8px;z-index:2147483647;font:12px/1.4 Arial,sans-serif;color:#fff;padding:4px 8px;border-radius:6px;opacity:.85;max-width:420px;pointer-events:none'; document.body.appendChild(nhan); }
        nhan.textContent = chu; nhan.style.background = mau; } catch (e) { /* */ }
    }
    let hanKe = Date.now() + 5000;
    function nhipTroLy() {
      try {
        const can = gl('lark_webcan6', null); const yc = gl('lark_webyc6', 0) || 0; const d = gl('lark_webdata6', null);
        const canTuoi = can && Date.now() - (can.luc || 0) < 3 * 3600e3;
        const cu = !d || Date.now() - (d.luc || 0) > 20 * 60000;
        if ((yc && (!d || yc > d.luc) && Date.now() - yc < 30 * 60000) || (canTuoi && cu && Date.now() >= hanKe)) {
          hanKe = Date.now() + (20 + Math.random() * 10) * 60000;
          capNhat(yc && (!d || yc > d.luc) ? 'bấm Đọc ngay' : 'định kỳ');
        } else if (canTuoi && !nhan) bieuTuong('SMH: Lark hết lượt API — tab này đang giúp script đọc sheet, vui lòng giữ tab mở', '#e65100');
      } catch (e) { /* */ }
    }
    setInterval(nhipTroLy, 30000); setTimeout(nhipTroLy, 4000);
  }
