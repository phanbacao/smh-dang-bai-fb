
  // =====================================================================
  //  Gọi API Lark (sheet + webhook) — gọi càng ít càng tốt
  // =====================================================================
  function thangHienTai() { const d = new Date(); return d.getFullYear() + '-' + (d.getMonth() + 1); }
  function chanLark() {
    const g = lay('lark_gate', null);
    if (!g) return null;
    if (g.loai === 'quota' && g.thang !== thangHienTai()) return null;
    if (g.loai === 'quota' && Date.now() >= (g.thuLai || 0)) return null; // (6.32.4) hết lượt tháng: không khoá cứng tới cuối tháng — tới giờ thử lại thì cho gọi thử 1 lượt (Lark có thể mở lượt tháng mới trễ hơn 0 giờ ngày 1)
    return g.den > Date.now() ? g : null;
  }
  const khoangThuLark = () => (new Date().getDate() <= 3 ? 25 + Math.random() * 10 : 100 + Math.random() * 40) * 60000; // (6.32.4) 3 ngày đầu tháng thử ~30 phút/lần, sau đó ~2 giờ/lần (giờ ngẫu nhiên)
  const MA_TOKEN_LARK = ['99991663', '99991664', '99991665', '99991661'];
  function loiLark(ma, msg) {
    const g0 = lay('lark_gate', {}) || {};
    const lan = (g0.lan || 0) + 1;
    const code = String(ma), d = new Date();
    let loai = 'tam', moTa = 'Lark tạm lỗi kết nối/dịch vụ', den = Date.now() + Math.min(30, Math.pow(2, Math.min(lan - 1, 5))) * 60000;
    if (typeof coBiMat === 'function' && !coBiMat()) { loai = 'quyen'; moTa = 'Máy này chưa có mã Lark (bị mất mã) — cần cài lại bản riêng có mã'; den = Date.now() + 60 * 60000; }
    else if (code === '99991403') { loai = 'quota'; moTa = 'Lark đã hết hạn mức API tháng'; den = new Date(d.getFullYear(), d.getMonth() + 1, 1).getTime(); }
    else if (['91403', '99991672', '99991676', '99991679', '99991668', '10014'].includes(code)) { loai = 'quyen'; moTa = 'Lark từ chối quyền truy cập hoặc thông tin ứng dụng'; den = Date.now() + 60 * 60000; }
    else if (MA_TOKEN_LARK.includes(code)) { moTa = 'Mã truy cập Lark cần làm mới'; boTokenLark(); }
    else if (code === '99991400' || code === '429') { moTa = 'Lark giới hạn tốc độ gọi API'; den = Date.now() + Math.min(60, 5 * lan) * 60000; }
    const thuLai = loai === 'quota' ? Date.now() + khoangThuLark() : 0;
    const g = { loai, ma: code, msg: moTa + ' (mã ' + code + ')', detail: anBiMat(msg || '').slice(0, 350), den, thuLai, lan, luc: Date.now(), tu: (g0.loai === loai && g0.tu) ? g0.tu : Date.now(), thang: thangHienTai(), bao: g0.ma === code && g0.thang === thangHienTai() ? g0.bao : false };
    luu('lark_gate', g);
    capNhat('suc_khoe', { larkOk: false, larkLuc: Date.now(), larkLoi: g.msg });
    if (!g0.msg || g0.ma !== code) ghi('Lark tạm ngừng: ' + g.msg);
    else if (loai === 'quota') ghi(`Gọi thử Lark: vẫn hết lượt tháng → thử lại lúc ${gioStr(new Date(thuLai))}`); // (6.32.4)
    return new LoiLark(g.msg);
  }
  async function baoTinhTrangLark() {
    const g = lay('lark_gate', null);
    if (!g || g.bao || !trongGioNhan() || !laTabChinh()) return;
    if (!(g.loai === 'quota' || g.loai === 'quyen' || Date.now() - (g.tu || g.luc) >= 30 * 60000)) return;
    luu('lark_gate', Object.assign({}, g, { bao: true }));
    await baoLoi(`${g.msg} — script vẫn đăng bằng dữ liệu đã tải sẵn; cần kiểm tra hạn mức/quyền Lark`, 'lark_' + g.ma);
  }
  function goiTho(method, url, body, headers, timeout = 25000) {
    return new Promise((resolve) => {
      GM_xmlhttpRequest({
        method, url,
        headers: Object.assign({ 'Content-Type': 'application/json; charset=utf-8' }, headers),
        data: body ? JSON.stringify(body) : undefined,
        timeout,
        onload: (r) => { let j = null; try { j = JSON.parse(r.responseText); } catch (e) { /* */ } resolve({ status: r.status, json: j }); },
        onerror: () => resolve({ status: 0, json: null, mang: 'network' }),
        ontimeout: () => resolve({ status: 0, json: null, mang: 'timeout' }),
      });
    });
  }
  let LARK_VIEC = ''; // (6.20.8) đếm lượt gọi Lark theo từng loại việc (tab Hệ thống)
  const demLark = (url) => { try { demLark0(url); } catch (e) { /* đếm lượt không bao giờ được làm hỏng việc chính */ } };
  // (6.28.5) TIẾT KIỆM LƯỢT LARK: hạn mức cả tổ chức 10.000 lượt/tháng (gồm cả bot KPI). Mỗi máy có trần mềm/ngày — vượt trần thì bỏ việc phụ (đồng bộ lịch Z8, ghi báo cáo lỗi, ghi cột G, kiểm khoá khi đăng đúng giờ); việc chính (đọc sheet, tải tệp, ghi ĐÃ ĐĂNG, giữ chỗ khi đăng thay) vẫn chạy
  const TRAN_LARK_NGAY = () => (LA_CAO ? 15 : 35);
  const larkHomNay = () => { const c = lay('lark_dem', {}) || {}; return c.ngay === homNay() ? (c.so || 0) : 0; };
  const larkTietKiem = () => larkHomNay() >= TRAN_LARK_NGAY();
  const demThangLark = () => { try { const th = homNay().slice(3); const m = lay('lark_thang6', null) || {}; const moi = m.th === th ? m : { th, so: 0 }; moi.so = (moi.so || 0) + 1; luu('lark_thang6', moi); if (moi.so === (LA_CAO ? 700 : 1500)) setTimeout(() => { try { baoLoi(`📈 ${TEN_MAY}: tháng này script đã gọi Lark ${moi.so} lượt — cả công ty chỉ có 10.000 lượt/tháng (gồm cả bot KPI), cần xem bảng lượt gọi trong trang quản trị Lark`, 'tranthang_' + th).catch(() => {}); } catch (e) { /* */ } }, 0); } catch (e) { /* */ } };
  const demLark0 = (url) => { demThangLark(); const c = lay('lark_dem', {}) || {}; const moi = c.ngay === homNay() ? c : { ngay: homNay(), so: 0, loai: {} }; moi.so = (moi.so || 0) + 1; if (moi.so === TRAN_LARK_NGAY()) setTimeout(() => { try { baoLoi(`📈 ${TEN_MAY}: hôm nay đã gọi Lark ${moi.so} lượt (mức bình thường) — từ giờ script bỏ bớt việc phụ để giữ lượt; nếu ngày nào cũng báo thì cần kiểm tra`, 'tranmem_' + homNay()).catch(() => {}); } catch (e) { /* */ } }, 0); const k = LARK_VIEC || (!url ? 'tải tệp (video/ảnh)' : /tenant_access_token/.test(url) ? 'lấy mã Lark' : 'khác ' + (String(url).split('/open-apis/')[1] || '').split('?')[0].replace(/[A-Za-z0-9]{20,}/g, '…').slice(0, 40)); moi.loai = moi.loai || {}; moi.loai[k] = (moi.loai[k] || 0) + 1; capNhat('lark_dem', moi); };
  // lỗi mạng / quá lâu / máy chủ 5xx / giới hạn tốc độ: tự thử lại tối đa 2 lần (cách 3–8 giây) rồi mới tính là lỗi
  async function goi(method, url, body, headers = {}, timeout) {
    const duLieu = url.startsWith('https://open.larksuite.com/open-apis/') && !url.includes('/bot/v2/hook/');
    const gate = duLieu && chanLark();
    if (gate) { const w = method === 'GET' ? webDocUrl(url) : null; if (w) return w; throw new LoiLark(gate.msg + (method === 'GET' && /\/values/.test(url) ? ' · ' + webLyDo() : '') + ' — đang chờ kiểm tra lại'); } // (6.30) hết lượt API: đọc sheet qua tab Lark web
    for (let lan = 0; ; lan++) {
      if (duLieu) demLark(url);
      const r = await goiTho(method, url, body, headers, timeout);
      const j = r.json;
      if (!duLieu) {
        if (r.mang) throw new LoiMem(r.mang === 'timeout' ? 'Gửi tin Lark quá lâu' : 'Mất kết nối khi gửi tin Lark');
        return r;
      }
      const loi = r.mang || !j || r.status >= 400 || (j.code != null && j.code !== 0);
      if (!loi) { if (/tenant_access_token/.test(url)) return r; /* (6.32.4) lấy mã thành công chưa chứng tỏ Lark còn lượt */ if (lay('lark_gate', null)) { luu('lark_gate', null); ghi('Kết nối Lark phục hồi'); } capNhat('suc_khoe', { larkOk: true, larkLuc: Date.now(), larkLoi: '' }); return r; }
      const ma = String(r.mang || (j && j.code) || r.status || 'network');
      if (MA_TOKEN_LARK.includes(ma)) { boTokenLark(); throw new LoiLarkToken('Mã truy cập Lark cần làm mới (mã ' + ma + ')'); }
      const tam = r.mang || r.status >= 500 || ma === '99991400' || ma === '429' || !j;
      if (tam && lan < 2) { await sleepThat(3000 + Math.floor(Math.random() * 5000)); continue; }
      { const eL = loiLark(ma, r.mang ? (r.mang === 'timeout' ? 'Phản hồi quá lâu' : 'Mất kết nối') : (j && j.msg)); if (method === 'GET' && chanLark()) { const w = webDocUrl(url); if (w) return w; } throw eL; } // (6.30) vừa bị chặn: đọc ngay từ dữ liệu Lark web nếu có
    }
  }

  // =====================================================================
  //  (6.30) ĐỌC SHEET QUA LARK WEB khi API hết lượt: dữ liệu do "trợ lý" trên tab sheet Lark (p0_larkweb) đọc và lưu
  // =====================================================================
  const WEB_TUOI_PHUT = 6 * 60;
  const webData = () => { const d = lay('lark_webdata6', null); return d && d.tabs && Date.now() - (d.luc || 0) < WEB_TUOI_PHUT * 60000 ? d : null; };
  const chanDocLark = () => { const g = chanLark(); return g && !webData() ? g : null; }; // chặn ĐỌC sheet: chỉ khi API bị chặn VÀ không có dữ liệu Lark web còn mới
  function webLyDo() { const t = lay('lark_webtt6', null); if (!t) return 'chưa có tab sheet Lark nào mở trên Chrome máy này để đọc thay'; return t.ok ? `dữ liệu Lark web cũ (đọc lúc ${gioStr(new Date(t.luc))})` : `tab Lark web đọc lỗi: ${t.loi}`; }
  function webCatVung(values, vung) {
    const m = String(vung).match(/^([A-Z]+)(\d+)(?::([A-Z]+)(\d+))?$/); if (!m) return null;
    const col = (s) => { let n = 0; for (const ch of s) n = n * 26 + (ch.charCodeAt(0) - 64); return n - 1; };
    const c0 = col(m[1]), r0 = +m[2] - 1, c1 = col(m[3] || m[1]), r1 = +(m[4] || m[2]) - 1; const out = [];
    for (let r = r0; r <= Math.min(r1, values.length - 1); r++) { const row = (values[r] || []).slice(c0, c1 + 1); while (row.length < c1 - c0 + 1) row.push(null); out.push(row); }
    return out;
  }
  function webDocUrl(url) {
    const d = webData(); if (!d) return null;
    const lay1 = (rg) => { const i = rg.indexOf('!'); const tab = rg.slice(0, i), vung = rg.slice(i + 1); const v = d.tabs[tab]; if (!v) return null; return webCatVung(v, vung); };
    let data = null;
    if (url.includes('/values_batch_get')) { const q = decodeURIComponent((url.split('ranges=')[1] || '').split('&')[0]); const ds = q.split(','); const vr = ds.map((rg) => ({ range: rg, values: lay1(rg) })); if (vr.some((x) => !x.values)) return null; data = { valueRanges: vr }; }
    else if (/\/values\/[^?]+/.test(url)) { const rg = decodeURIComponent(url.split('/values/')[1].split('?')[0]); const v = lay1(rg); if (!v) return null; data = { valueRange: { range: rg, values: v } }; }
    else return null;
    if (!window.__webDocGhi || Date.now() - window.__webDocGhi > 10 * 60000) { window.__webDocGhi = Date.now(); ghi(`Đọc sheet qua Lark web (Lark hết lượt API) — dữ liệu tab Lark đọc lúc ${gioStr(new Date(d.luc))}`); }
    return { status: 200, json: { code: 0, data }, web: true };
  }
  function datCoLarkWeb(ngay) { // tab Facebook báo cho trợ lý trên tab Lark biết cần đọc thay (ngay = bấm Đọc ngay)
    try { const c = lay('lark_webcan6', null); if (!c || Date.now() - (c.luc || 0) > 5 * 60000) luu('lark_webcan6', { luc: Date.now(), token: CAI_DAT.SHEET_TOKEN, tabs: [CAI_DAT.TAB_BAI, CAI_DAT.TAB_VIDEO].concat(KENH_PHU.map((c) => CAI_DAT.KENH[c].tab)) }); if (ngay) luu('lark_webyc6', Date.now()); } catch (e) { /* */ }
  }
  const TRAN_CUNG_LARK = () => (LA_CAO ? 60 : 100); // (6.28.8) trần cứng/ngày: vượt thì chỉ còn việc chính (đọc sheet, tải ảnh/video, ghi ĐÃ ĐĂNG, lấy mã)
  // (6.28.9) việc chính = không bị trần cứng chặn: đọc sheet, tải tệp, lấy mã, ghi "ĐÃ ĐĂNG" vào mọi tab kênh (kể cả Hà Xá), đọc/ghi ô Z2 (dấu báo cáo ngày — chống 2 máy gửi trùng)
  //  việc phụ (bị chặn khi chạm trần): các ô Z khác (giữ chỗ Z1, comment Z3, thẻ Z4, báo cáo lỗi Z5/Z6, lịch Z8, thử nạp) + ghi cột G tab Bài viết (gộp)
  const laViecChinhLark = (viec, url) => { const v = viec || ''; if (!url || /tenant_access_token/.test(url || '')) return true; if (/đọc sheet|tải|lấy mã/.test(v)) return true; if (new RegExp(' ô ' + CAI_DAT.O_BAO_CAO + '$').test(v)) return true; if (/^ghi Bài viết \(gộp/.test(v)) return false; return /^(đọc|ghi) /.test(v) && !/ ô Z/.test(v); };
  async function goiLark(method, url, body, timeout) {
    if (method === 'GET' && chanLark()) { const w = webDocUrl(url); if (w) return w; } // (6.31.1) hết lượt: đọc qua Lark web TRƯỚC khi xin mã Lark (xin mã cũng bị chặn khi mã cũ hết hạn)
    if (larkHomNay() >= TRAN_CUNG_LARK() && !laViecChinhLark(LARK_VIEC, url)) {
      if (!window.__tranCungBao) { window.__tranCungBao = 1; ghi(`⛔ Lượt gọi Lark hôm nay đã chạm trần cứng ${TRAN_CUNG_LARK()} (${TEN_MAY}) → dừng mọi việc phụ tới hôm sau (giữ chỗ ô Z1 chuyển sang kiểm trang Facebook)`); baoLoi(`⛔ ${TEN_MAY}: lượt gọi Lark hôm nay đã chạm trần cứng ${TRAN_CUNG_LARK()} lượt → dừng việc phụ tới hôm sau, việc đăng bài vẫn chạy (kiểm trang trước khi đăng)`, 'trancung_' + homNay()).catch(() => {}); }
      const e = new LoiMem('đã chạm trần cứng lượt Lark hôm nay (' + (LARK_VIEC || 'việc phụ') + ')'); e.tranCung = true; throw e;
    }
    for (let lan = 0; ; lan++) {
      const t = await larkToken();
      try { return await goi(method, url, body, { Authorization: 'Bearer ' + t }, timeout); }
      catch (e) { if (e instanceof LoiLarkToken && lan === 0) continue; throw e; }
    }
  }
  function boTokenLark() { tokenCache = null; try { luu('lark_tok', null); } catch (e) { /* */ } }
  let tokenCache = null, tokenCho = null;
  async function larkToken() {
    if (tokenCho) return tokenCho;
    tokenCho = layLarkToken();
    try { return await tokenCho; } finally { tokenCho = null; }
  }
  async function layLarkToken() {
    if (!tokenCache) { const c = lay('lark_tok', null); if (c && c.t && c.het > Date.now() + 5 * 60000) tokenCache = c; }
    if (tokenCache && tokenCache.het > Date.now() + 60000) return tokenCache.t;
    const r = await goi('POST', 'https://open.larksuite.com/open-apis/auth/v3/tenant_access_token/internal', { app_id: CAI_DAT.LARK_APP_ID, app_secret: CAI_DAT.LARK_APP_SECRET });
    if (!r.json || r.json.code !== 0) throw new LoiMem('Không lấy được quyền đọc Lark (mã ' + (r.json ? r.json.code : r.status) + ')');
    tokenCache = { t: r.json.tenant_access_token, het: Date.now() + r.json.expire * 1000 };
    luu('lark_tok', tokenCache);
    return tokenCache.t;
  }
  const URL_SHEET = () => 'https://open.larksuite.com/open-apis/sheets/v2/spreadsheets/' + CAI_DAT.SHEET_TOKEN;
  // đọc 1 vùng ô → mảng 2 chiều
  const TEN_TAB_DEM = (tab) => ({ [CAI_DAT.TAB_BAI]: 'Bài viết', [CAI_DAT.TAB_VIDEO]: 'Kênh 1', [CAI_DAT.KENH[2].tab]: 'Kênh 2', [CAI_DAT.KENH[3].tab]: 'Kênh 3', [(CAI_DAT.KENH[4] || {}).tab || '-']: 'Hà Xá' })[tab] || tab;
  const nhanDem = (kieu, tab, vung) => kieu + ' ' + TEN_TAB_DEM(tab) + (/^[A-Z]+\d+(:[A-Z]+\d+)?$/.test(vung) && !/3000/.test(vung) && /^Z/.test(vung) ? ' ô ' + vung.split(':')[0] : '');
  async function docNhieu(ds) { // (6.20.8) ds: [[tab, vùng], ...] → đọc tất cả trong 1 lượt gọi; trả về mảng giá trị theo đúng thứ tự
    LARK_VIEC = 'đọc sheet (gộp ' + ds.length + ' vùng)';
    try {
      const r = await goiLark('GET', `${URL_SHEET()}/values_batch_get?ranges=${encodeURIComponent(ds.map(([t, v]) => t + '!' + v).join(','))}`, null, 60000);
      const vr = r.json && r.json.code === 0 && r.json.data && r.json.data.valueRanges; if (!Array.isArray(vr) || vr.length !== ds.length) throw new LoiMem('Không đọc gộp được sheet (mã ' + (r.json ? r.json.code : r.status) + ')');
      return vr.map((x) => x.values || []);
    } finally { LARK_VIEC = ''; }
  }
  async function docBang(tab, vung) {
    LARK_VIEC = LARK_VIEC || nhanDem('đọc', tab, vung);
    try { return await docBang0(tab, vung); } finally { LARK_VIEC = ''; }
  }
  async function docBang0(tab, vung) {
    const r = await goiLark('GET', `${URL_SHEET()}/values/${tab}!${vung}`, null, 60000);
    if (!r.json || r.json.code !== 0 || !r.json.data || !r.json.data.valueRange) throw new LoiMem('Không đọc được sheet (' + tab + '!' + vung + ')');
    return r.json.data.valueRange.values || [];
  }
  async function docO(tab, o) { const v = await docBang(tab, o + ':' + o); return (v[0] || [])[0]; }
  async function ghiO(tab, o, giaTri) {
    LARK_VIEC = 'ghi ' + TEN_TAB_DEM(tab) + ' ô ' + o; try { return await ghiO0(tab, o, giaTri); } finally { LARK_VIEC = ''; }
  }
  async function ghiO0(tab, o, giaTri) {
    const r = await goiLark('PUT', `${URL_SHEET()}/values`, { valueRange: { range: `${tab}!${o}:${o}`, values: [[giaTri]] } });
    if (!r.json || r.json.code !== 0) throw new LoiMem('Ghi ô ' + o + ' chưa được (mã ' + (r.json ? r.json.code : r.status) + ')');
  }
  async function ghiNhieuO(tab, ds) { // ds: [[ô, giá trị], ...] — gộp 1 lượt gọi
    LARK_VIEC = 'ghi ' + TEN_TAB_DEM(tab) + ' (gộp ' + ds.length + ' ô)'; try { return await ghiNhieuO0(tab, ds); } finally { LARK_VIEC = ''; }
  }
  async function ghiNhieuO0(tab, ds) {
    const r = await goiLark('POST', `${URL_SHEET()}/values_batch_update`, { valueRanges: ds.map(([o, v]) => ({ range: `${tab}!${o}:${o}`, values: [[v]] })) });
    if (!r.json || r.json.code !== 0) throw new LoiMem('Ghi ô ' + ds.map((x) => x[0]).join(', ') + ' chưa được (mã ' + (r.json ? r.json.code : r.status) + ')');
  }
  // dán ảnh vào ô (ảnh nằm trong ô, giống dán tay)
  async function ghiAnhVaoO(tab, o, blob, ten) {
    const u8 = new Uint8Array(await blob.arrayBuffer());
    const r = await goiLark('POST', `${URL_SHEET()}/values_image`, { range: `${tab}!${o}:${o}`, image: Array.from(u8), name: ten || ('manifest-' + homNay() + '.jpg') }, 120000);
    if (!r.json || r.json.code !== 0) throw new LoiMem('Lark không nhận ảnh ô ' + o + ' (mã ' + (r.json ? r.json.code : r.status) + ')');
  }

  // ---------------- tin nhắn Lark: chỉ 2 loại ----------------
  //  'baocao' → nhóm Marketing (báo cáo cuối ngày + báo cáo tuần Khanh)   'loi' → nhóm "Đăng bài fb" (lỗi khi đăng, ghi rõ máy nào)
  async function guiLark(nhom, noiDung, { khoa = '', toiDa = 1, the = null } = {}) {
    const hook = nhom === 'baocao' ? CAI_DAT.WEBHOOK_BAO_CAO : CAI_DAT.WEBHOOK_LOI;
    let tin = String(noiDung).replace(/^\n/, '');
    if (!/fb/i.test(tin)) tin = (tin.includes('\n') ? `${CAI_DAT.TIEN_TO_TIN}\n` : `${CAI_DAT.TIEN_TO_TIN} `) + tin;
    const kk = 'tin6_' + homNay(); const k = khoa || bam(tin.replace(/\d{1,2}[:h]\d{2}/g, ''));
    const dem = lay(kk, {}) || {};
    if ((dem[k] || 0) >= toiDa) { ghi('(hôm nay đã gửi tin này rồi, không gửi lại) ' + tin.replace(/\s+/g, ' ').slice(0, 120)); return true; }
    dem[k] = (dem[k] || 0) + 1; luu(kk, dem);
    let loiCuoi = '';
    for (let lan = 0; lan < 3; lan++) {
      try {
        let r = null; if (the && lan === 0) { try { r = await goi('POST', hook, the); } catch (e) { r = null; } if (!(r && r.json && (r.json.code === 0 || r.json.StatusCode === 0))) { ghi('Gửi dạng thẻ chưa được → gửi dạng chữ'); r = null; } } // (6.20.7)
        if (!r) r = await goi('POST', hook, { msg_type: 'text', content: { text: tin } });
        if (r.json && (r.json.code === 0 || r.json.StatusCode === 0)) { capNhat('suc_khoe', { tinOk: true, tinLuc: Date.now(), tinLoi: '' }); ghi('Đã báo Lark (' + (nhom === 'baocao' ? 'nhóm Marketing' : 'nhóm Đăng bài fb') + '): ' + tin.replace(/\s+/g, ' ').slice(0, 300)); return true; }
        loiCuoi = 'mã ' + (r.json ? (r.json.code || r.json.StatusCode) : r.status);
        if (!(r.status >= 500 || !r.json)) break;
      } catch (e) {
        loiCuoi = e.message;
        if (/quá lâu/.test(e.message)) { ghi('Gửi tin Lark phản hồi quá lâu (tin có thể đã tới nhóm) → không gửi lặp'); return true; }
      }
      if (lan < 2) await sleepThat(4000 + Math.floor(Math.random() * 6000));
    }
    const d2 = lay(kk, {}) || {}; if (d2[k]) d2[k]--; luu(kk, d2);
    capNhat('suc_khoe', { tinOk: false, tinLuc: Date.now(), tinLoi: loiCuoi });
    ghi('Báo Lark lỗi: ' + loiCuoi + ' — ' + tin.replace(/\s+/g, ' ').slice(0, 160));
    return false;
  }
  // báo lỗi vào nhóm "Đăng bài fb" — luôn ghi rõ máy nào; mỗi khoá tối đa 1 lần/ngày
  // (6.25) chỉ lỗi NGUY CẤP mới gửi nhóm Lark báo lỗi: thiếu nội dung (bài bị bỏ), mã khoá/Lark/trang hỏng, trễ > 2 tiếng, Máy Cao đăng thay,
  //  bài bị bỏ sau mọi lần thử, trang có 2 bài trùng, tổng kết 12:00 / cuối ngày, nhắc sheet ngày mai. Còn lại chỉ ghi nhật ký + Báo lỗi cho Claude
  const KHOA_NGUY_CAP = /^(thieu_|lark_|suckhoe|loitrang|giahan|tab_an_|thay_|loi_|trung_|tong12_|tongtoi_|nhacsheet_)/;
  async function baoLoi(noiDung, khoa, toiDa = 1) {
    if (!laTabChinh()) return false;
    if (!KHOA_NGUY_CAP.test(khoa || '')) { ghi('⚠️ (không báo Lark) ' + noiDung); return false; }
    if (!trongGioNhan()) { ghi('(ngoài giờ gửi tin) ' + noiDung); return false; }
    return guiLark('loi', `[fb][${TEN_MAY}] ${noiDung}`, { khoa: khoa || '', toiDa });
  }
