# (6.36) KÊNH 5 — BÌNH LUẬN ĐẦU TIÊN dưới bài page phụ: lấy từ lich.json trường "cmt": [{"anh": "tên.jpg"}, {"text": "…"}]
# (Cao 07/11: nhiều người bấm vào phần bình luận để đọc → luôn để ảnh + câu nhắc minigame). Bài không có "cmt" → không bình luận như cũ.
out = thay(out, "      out.push({ hang: i + 2, id, cap: String(b.caption || '').trim(), tep:",
"      const cmtGh = (Array.isArray(b.cmt) ? b.cmt : []).map((x) => (x && x.anh ? { k: 'anh', v: /^https?:/.test(x.anh) ? x.anh : cfg.gh + encodeURIComponent(String(x.anh).trim()) } : x && x.text ? { k: 'text', v: String(x.text).trim() } : null)).filter(Boolean); // (6.36)\n      out.push({ cmtGh, hang: i + 2, id, cap: String(b.caption || '').trim(), tep:")
out = thay(out, "      return { thieu: th, text: x ? x.cap : '', tep: x ", "      return { cmtGh: x ? x.cmtGh || [] : [], thieu: th, text: x ? x.cap : '', tep: x ")
out = thay(out, "    if (it && it.k && (CAI_DAT.KENH[kenhCua(it.k)] || {}).khongCmt) return { text: [], anh: [] }; // (6.34) page phụ: không comment",
"    if (it && it.k && (CAI_DAT.KENH[kenhCua(it.k)] || {}).khongCmt) { const g = (nd && nd.cmtGh) || []; return { text: g.filter((x) => x.k === 'text').map((x) => x.v), anh: g.filter((x) => x.k === 'anh').map((x) => x.v) }; } // (6.34) page phụ: chỉ comment theo lich.json (6.36)")
out = thay(out, "      const kq = await dangVideoFb({ slot: it.k, ten: it.ten, loai: 4, text: nd.text, file, cmts: [], hang: nd.hang, ngay }, { soanThu: thu });",
"      const kq = await dangVideoFb({ slot: it.k, ten: it.ten, loai: 4, text: nd.text, file, cmts: nd.cmtGh || [], hang: nd.hang, ngay }, { soanThu: thu });")
out = thay(out, "      ddThem: { slot: it.k, loai: 3, ten: it.ten, cmts: [], cmtIdx: 0, soAnh: files.length,",
"      ddThem: { slot: it.k, loai: 3, ten: it.ten, cmts: nd.cmtGh || [], cmtIdx: 0, soAnh: files.length,")
out = thay(out, "  async function taiAnhKho(token, ten) { return thuNhoAnh(await taiTepLark(token, { ten: 'ảnh ' + ten, loai: 'anh' }), ten); }",
"  async function taiAnhKho(token, ten) { if (/^https?:/.test(String(token))) return thuNhoAnh(await taiTepGh(token, 'anh', 'ảnh ' + ten), ten); return thuNhoAnh(await taiTepLark(token, { ten: 'ảnh ' + ten, loai: 'anh' }), ten); } // (6.36) ảnh comment page phụ từ GitHub")
