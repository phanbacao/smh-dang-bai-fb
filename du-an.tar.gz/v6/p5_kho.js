
  // =====================================================================
  //  Kho tải sẵn (trên ổ cứng của trình duyệt — không chiếm RAM) + tải file từ Lark
  // =====================================================================
  let khoDb = null;
  const khoMo = () => khoDb || (khoDb = new Promise((res, rej) => { const q = indexedDB.open('smh6_kho', 1); q.onupgradeneeded = () => q.result.createObjectStore('tep'); q.onsuccess = () => res(q.result); q.onerror = () => { khoDb = null; rej(q.error); }; }));
  async function khoLay(k) { try { const d = await khoMo(); return await new Promise((res) => { const r = d.transaction('tep').objectStore('tep').get(k); r.onsuccess = () => res(r.result || null); r.onerror = () => res(null); }); } catch (e) { return null; } }
  async function khoLuu(k, blob, them) { try { const d = await khoMo(); await new Promise((res) => { const t = d.transaction('tep', 'readwrite'); t.objectStore('tep').put(Object.assign({ blob, luc: Date.now(), size: blob.size, type: blob.type }, them || {}), k); t.oncomplete = () => res(); t.onerror = () => res(); t.onabort = () => res(); }); } catch (e) { /* kho lỗi thì thôi, lúc dùng tải trực tiếp */ } }
  async function khoXoa(k) { try { const d = await khoMo(); await new Promise((res) => { const t = d.transaction('tep', 'readwrite'); t.objectStore('tep').delete(k); t.oncomplete = () => res(); t.onerror = () => res(); }); } catch (e) { /* */ } }
  async function khoDon(giuGio = 72) { // xoá đồ cũ hơn 3 ngày
    try {
      const d = await khoMo(); let tong = 0, xoa = 0, n = 0;
      await new Promise((res) => { const t = d.transaction('tep', 'readwrite'); const cur = t.objectStore('tep').openCursor();
        cur.onsuccess = () => { const c = cur.result; if (!c) return; if (Date.now() - (c.value.luc || 0) > giuGio * 3600e3) { c.delete(); xoa++; } else { tong += c.value.size || 0; n++; } c.continue(); };
        t.oncomplete = () => res(); t.onerror = () => res(); t.onabort = () => res(); });
      return { tong, xoa, n };
    } catch (e) { return { tong: 0, xoa: 0, n: 0 }; }
  }
  const MA_KHOA_LARK = ['99991403', '99991400', '429', '91403', '99991672', '99991676', '99991679', '99991668', '10014'];
  // (6.29) TẢI QUA LARK WEB: dùng tài khoản Lark đang đăng nhập trên Chrome của máy này (như khi bấm xem/tải video trong sheet)
  //  → KHÔNG tính lượt gọi API Lark. Ưu tiên cách này; hỏng (chưa đăng nhập Lark web, mất mạng…) thì mới dùng API như cũ.
  const LARK_WEB_HOST = ['https://internal-api-drive-stream-sg.larksuite.com', (CAI_DAT.LINK_SHEET.match(/^https:\/\/[^/]+/) || [''])[0]].filter(Boolean);
  const LARK_WEB_NGHI_PHUT = 30;
  const larkWeb = () => lay('lark_web6', null) || {};
  const larkWebNghi = () => { const w = larkWeb(); return w.hong && Date.now() - w.hong < LARK_WEB_NGHI_PHUT * 60000 ? w : null; };
  async function taiTepWeb(token, { ten = 'tep', loai = '', size = 0, timeout = 180000 } = {}) {
    const t0 = Date.now(); let loiCuoi = '', dangNhap = false;
    for (const host of LARK_WEB_HOST) {
      const url = host + '/space/api/box/stream/download/all/' + encodeURIComponent(token) + '/?mount_point=sheet';
      const r = await new Promise((resolve) => GM_xmlhttpRequest({ method: 'GET', url, responseType: 'blob', timeout, anonymous: false,
        onload: (x) => resolve({ status: x.status, blob: x.response }), onerror: () => resolve({ mang: 'mất kết nối' }), ontimeout: () => resolve({ mang: 'quá lâu' }) }));
      if (r.mang) { loiCuoi = r.mang; continue; }
      const b = r.blob; const ty = (b && b.type) || '';
      if (r.status === 401 || r.status === 403 || /text\/html|json/.test(ty) || (b && b.size < 500)) { let chu = ''; try { chu = b ? (await b.slice(0, 300).text()) : ''; } catch (e) { /* */ }
        if (r.status === 401 || r.status === 403 || /login|passport|accounts|"code":\s*(4|9)/i.test(chu) || /text\/html/.test(ty)) { dangNhap = true; loiCuoi = 'Chrome máy này chưa đăng nhập Lark web (mã ' + r.status + ')'; continue; }
        loiCuoi = 'Lark web trả về ' + (b ? b.size : 0) + ' byte (mã ' + r.status + ')'; continue; }
      if (r.status !== 200) { loiCuoi = 'mã ' + r.status; continue; }
      if (size && Math.abs(b.size - size) > 1024) { loiCuoi = `chưa đủ (${b.size}/${size} byte)`; continue; }
      luu('lark_web6', { ok: Date.now(), soOk: (larkWeb().soOk || 0) + 1 });
      ghi(`Tải ${ten} qua Lark web (không tốn lượt Lark): ${(b.size / 1048576).toFixed(1)} MB trong ${((Date.now() - t0) / 1000).toFixed(0)} giây`);
      return b;
    }
    luu('lark_web6', Object.assign(larkWeb(), { hong: Date.now(), ly: loiCuoi, dangNhap }));
    const e = new LoiMem('tải qua Lark web chưa được: ' + loiCuoi); e.dangNhap = dangNhap; throw e;
  }
  // tải 1 file trong ô sheet (ảnh / video / nhạc) — có trong kho thì lấy kho, không gọi Lark
  async function taiTepLark(token, { ten = 'tep', loai = '', size = 0, timeout = 180000, lanToiDa = 1 } = {}) { // (6.25) mặc định chỉ tải 1 lần (không tự thử lại nhiều lần tốn lượt Lark); mã Lark hết hạn thì được lấy mã mới thử thêm 1 lần
    const trongKho = await khoLay('tep|' + token);
    if (trongKho && trongKho.blob && trongKho.blob.size > 500) return trongKho.blob;
    let loiWeb = '';
    if (!larkWebNghi() || chanLark()) { // (6.29) Lark web trước (miễn phí lượt); hết lượt API thì luôn thử Lark web
      try { const b = await taiTepWeb(token, { ten, loai, size, timeout }); await khoLuu('tep|' + token, b, { loai, web: 1 }); return b; }
      catch (e) { loiWeb = e.message; ghi(`Tải ${ten}: ${e.message}${chanLark() ? '' : ' → tải bằng API Lark'}`);
        if (e.dangNhap && chanLark()) baoLoi(`⚠️ ${TEN_MAY}: Lark đã hết lượt API, và Chrome máy này chưa đăng nhập Lark web nên không tải được video/ảnh — mở ${LARK_WEB_HOST[1] || 'larksuite.com'} trên Chrome máy này, đăng nhập Lark rồi để script tự thử lại`, 'larkweb_' + homNay()).catch(() => {}); }
    }
    const gate = chanLark(); if (gate) throw new LoiLark(gate.msg + (loiWeb ? ' · ' + loiWeb : '') + ' — đang chờ kiểm tra lại');
    let loiCuoi = null;
    let soLan = lanToiDa;
    for (let lan = 0; lan < soLan; lan++) {
      if (lan) await sleepThat(3000 + Math.floor(Math.random() * 4000));
      const t = await larkToken(); demLark();
      const t0 = Date.now();
      const r = await new Promise((resolve) => GM_xmlhttpRequest({ method: 'GET', url: 'https://open.larksuite.com/open-apis/drive/v1/medias/' + encodeURIComponent(token) + '/download', headers: { Authorization: 'Bearer ' + t }, responseType: 'blob', timeout,
        onload: (x) => resolve({ status: x.status, blob: x.response }), onerror: () => resolve({ mang: 'mất kết nối' }), ontimeout: () => resolve({ mang: 'quá lâu' }) }));
      if (r.mang) { loiCuoi = new LoiMem(`tải ${ten} lỗi: ${r.mang}`); continue; }
      const blob = r.blob;
      const laJson = !blob || blob.size < 2000 || /json/.test(blob.type || '');
      if (laJson) { let j = null; try { j = JSON.parse(await blob.text()); } catch (e) { /* */ }
        if (j && j.code != null && j.code !== 0) { const ma = String(j.code); if (MA_TOKEN_LARK.includes(ma)) { boTokenLark(); loiCuoi = new LoiMem('Mã truy cập Lark hết hạn'); if (soLan < lanToiDa + 1) soLan++; continue; } if (MA_KHOA_LARK.includes(ma)) throw loiLark(ma, j.msg); throw new LoiMem(`Lark báo lỗi khi tải ${ten} (mã ${ma}) — file có thể đã bị xoá`); }
        if (!blob || blob.size < 500) { loiCuoi = new LoiMem(`tải ${ten} chưa được (${blob ? blob.size : 0} byte)`); continue; } }
      if (r.status >= 500) { loiCuoi = new LoiMem(`tải ${ten} lỗi máy chủ (mã ${r.status})`); continue; }
      if (size && Math.abs(blob.size - size) > 1024) { loiCuoi = new LoiMem(`tải ${ten} chưa đủ (${blob.size}/${size} byte)`); continue; }
      if (loai && blob.size > 1e6) ghi(`Đã tải ${ten} (${(blob.size / 1048576).toFixed(1)} MB) trong ${((Date.now() - t0) / 1000).toFixed(0)} giây`);
      if (loai === 'video' && Date.now() - t0 > 90000) ghi(`⚠️ Tải ${ten} chậm: ${((Date.now() - t0) / 1000).toFixed(0)} giây`);
      await khoLuu('tep|' + token, blob, { loai });
      return blob;
    }
    throw loiCuoi || new LoiMem('Không tải được ' + ten);
  }
  // (6.25) tải nhiều file bằng 1 lượt gọi Lark: xin "link tải tạm" cho tối đa 5 file, rồi tải từng link (link tạm không tính lượt gọi Lark)
  //  lỗi thì trả về các file chưa tải để tải lẻ lúc đăng; Lark báo không hỗ trợ thì tắt cách này cả ngày
  async function taiNhieuTepLark(ds) { // ds: [{ token, ten, loai, size }]
    const ok = [], hong = [];
    if (!ds.length) return { ok, hong };
    if (lay('lo_batch6', '') === homNay()) return { ok, hong: ds.slice() };
    const gate = chanLark(); if (gate) return { ok, hong: ds.slice() };
    const t0 = Date.now();
    let urls = {};
    try {
      const t = await larkToken();
      const LV = LARK_VIEC; LARK_VIEC = 'tải nhiều tệp (link tạm, ' + ds.length + ' file)'; demLark(); LARK_VIEC = LV;
      const q = ds.map((x) => 'file_tokens=' + encodeURIComponent(x.token)).join('&');
      const r = await new Promise((resolve) => GM_xmlhttpRequest({ method: 'GET', url: 'https://open.larksuite.com/open-apis/drive/v1/medias/batch_get_tmp_download_url?' + q, headers: { Authorization: 'Bearer ' + t }, timeout: 30000,
        onload: (x) => resolve({ status: x.status, text: x.responseText }), onerror: () => resolve({ mang: 'mất kết nối' }), ontimeout: () => resolve({ mang: 'quá lâu' }) }));
      if (r.mang) throw new Error(r.mang);
      const j = JSON.parse(r.text || '{}');
      if (j.code !== 0) { if (MA_TOKEN_LARK.includes(String(j.code))) boTokenLark(); else luu('lo_batch6', homNay()); throw new Error('Lark mã ' + j.code + ' ' + (j.msg || '')); }
      for (const u of ((j.data || {}).tmp_download_urls || [])) urls[u.file_token] = u.tmp_download_url;
    } catch (e) { ghi(`Tải nhiều tệp: chưa xin được link tạm (${e.message}) → chuyển sang tải lẻ từng file`); return { ok, hong: ds.slice(), loiBatch: true }; }
    for (const x of ds) {
      const u = urls[x.token]; if (!u) { hong.push(x); continue; }
      const t1 = Date.now();
      const r = await new Promise((resolve) => GM_xmlhttpRequest({ method: 'GET', url: u, responseType: 'blob', timeout: x.loai === 'video' ? 300000 : 120000,
        onload: (y) => resolve({ status: y.status, blob: y.response }), onerror: () => resolve({ mang: 'mất kết nối' }), ontimeout: () => resolve({ mang: 'quá lâu' }) }));
      const b = r.blob;
      if (r.mang || !b || b.size < 500 || r.status >= 400 || (x.size && Math.abs(b.size - x.size) > 1024)) { hong.push(x); ghi(`Tải nhiều tệp: ${x.ten} chưa tải được (${r.mang || 'mã ' + r.status + ', ' + (b ? b.size : 0) + ' byte'}) → tải lẻ lúc đăng`); continue; }
      await khoLuu('tep|' + x.token, b, { loai: x.loai }); ok.push(x);
      if (b.size > 1e6) ghi(`Đã tải ${x.ten} (${(b.size / 1048576).toFixed(1)} MB) trong ${((Date.now() - t1) / 1000).toFixed(0)} giây (link tạm)`);
    }
    ghi(`⏱ Tải nhiều tệp: ${ok.length}/${ds.length} file bằng 1 lượt Lark, ${((Date.now() - t0) / 1000).toFixed(0)} giây`);
    return { ok, hong };
  }
  async function thuNhoAnh(blob, ten) { // ảnh quá lớn (ảnh gốc điện thoại ~5MB) thì thu nhỏ cho Facebook tải lên nhanh
    const duoi = /png/.test(blob.type) ? 'png' : 'jpg';
    try {
      const bm = await createImageBitmap(blob);
      const lon = Math.max(bm.width, bm.height); const cap = CAI_DAT.ANH_CANH_TOI_DA;
      if (lon <= cap && blob.size <= 3.5e6) { if (bm.close) bm.close(); return new File([blob], ten + '.' + duoi, { type: blob.type || 'image/jpeg' }); }
      const k = Math.min(1, cap / lon);
      const c = document.createElement('canvas'); c.width = Math.max(1, Math.round(bm.width * k)); c.height = Math.max(1, Math.round(bm.height * k));
      c.getContext('2d').drawImage(bm, 0, 0, c.width, c.height); if (bm.close) bm.close();
      const out = await new Promise((r) => c.toBlob(r, 'image/jpeg', 0.9));
      if (out && out.size > 500) return new File([out], ten + '.jpg', { type: 'image/jpeg' });
    } catch (e) { /* dùng ảnh gốc */ }
    return new File([blob], ten + '.' + duoi, { type: blob.type || 'image/jpeg' });
  }
  async function taiAnhKho(token, ten) { return thuNhoAnh(await taiTepLark(token, { ten: 'ảnh ' + ten, loai: 'anh' }), ten); }
  async function taiVideoKho(tep) {
    const b = await taiTepLark(tep.fileToken, { ten: 'video "' + tep.ten + '"', loai: 'video', size: tep.size, timeout: 300000 });
    const ten = /\.(mp4|mov|m4v|webm)$/i.test(tep.ten || '') ? tep.ten : (tep.ten || 'video') + '.mp4';
    return new File([b], ten, { type: (b.type && /^video\//.test(b.type)) ? b.type : (tep.mime || 'video/mp4') });
  }

  // ---------------- nhạc nền manifest: lưu trong Tampermonkey (khởi động lại máy / Chrome vẫn còn) ----------------
  const nhacInfo = () => lay('nhac6_info', null); // { ten, size, luc, tu }
  function nhacBlob() {
    const b64 = lay('nhac6', ''); if (!b64) return null;
    try { const bin = atob(b64); const u8 = new Uint8Array(bin.length); for (let i = 0; i < bin.length; i++) u8[i] = bin.charCodeAt(i); return new Blob([u8], { type: (nhacInfo() || {}).mime || 'audio/mpeg' }); } catch (e) { return null; }
  }
  async function luuNhac(blob, ten, tu) {
    if (blob.size > 4 * 1048576) throw new Error('file nhạc lớn quá (' + (blob.size / 1048576).toFixed(1) + ' MB) — dùng bài ~15–30 giây, dưới 4 MB');
    try { const ac = new OfflineAudioContext(1, 44100, 44100); await ac.decodeAudioData(await blob.arrayBuffer()); } catch (e) { throw new Error('file này không đọc được như nhạc (mp3/m4a/wav)'); }
    const u8 = new Uint8Array(await blob.arrayBuffer()); let s = ''; for (let i = 0; i < u8.length; i += 8192) s += String.fromCharCode.apply(null, u8.subarray(i, i + 8192));
    luu('nhac6', btoa(s)); luu('nhac6_info', { ten, size: blob.size, luc: Date.now(), tu, mime: blob.type || 'audio/mpeg' });
    ghi(`Đã lưu nhạc nền manifest "${ten}" (${(blob.size / 1024).toFixed(0)} KB, ${tu === 'o' ? 'lấy từ ô dự phòng' : 'tải lên trên popup'})`);
  }
  // máy chưa có nhạc → lấy file ở ô dự phòng (1 lần), lưu lại
  async function damBaoNhac() {
    const b = nhacBlob(); if (b) return b;
    const o = lay('o_nhac6', CAI_DAT.O_NHAC_DU_PHONG);
    ghi(`Máy này chưa có nhạc nền manifest → lấy nhạc ở ô dự phòng ${o}`);
    const c = await docO(CAI_DAT.TAB_VIDEO, o); const t = tepNhac(c);
    if (!t) throw new LoiThieu(`chưa có nhạc nền: máy này chưa tải nhạc lên, và ô ${o} (tab Kênh 1) không có file mp3`);
    const blob = await taiTepLark(t.fileToken, { ten: 'nhạc ' + t.ten, loai: 'nhac', size: t.size });
    await luuNhac(blob, t.ten, 'o');
    return nhacBlob();
  }

  // ---------------- video manifest: ảnh cột H + nhạc → video 15 giây (tạo sẵn, cất kho) ----------------
  async function videoManifest(ngay, so, anhToken, bao = () => {}) {
    const k = `mf|${ngay}|${so}|${anhToken}`;
    const c = await khoLay(k);
    if (c && c.blob && c.blob.size > 50000) return new File([c.blob], `manifest-${so + 1}.mp4`, { type: 'video/mp4' });
    const nhac = await damBaoNhac();
    const anh = await taiTepLark(anhToken, { ten: 'ảnh manifest', loai: 'anh' });
    const f = await ghepManifestWC(anh, nhac, CAI_DAT.MF_GIAY, bao, '');
    await khoLuu(k, f, { loai: 'mf' });
    ghi(`Đã tạo video manifest ${so + 1} ngày ${ngay.slice(0, 5)} (${(f.size / 1048576).toFixed(1)} MB · hiệu ứng ${f.hieuUng || '?'})`);
    return f;
  }
