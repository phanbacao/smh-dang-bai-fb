# (6.37) 1) nhận địa chỉ page dạng /people/<tên>/<id> (hết vòng lặp tải lại trang)  2) page phụ không chờ Máy Giao (cả bảng hiển thị)
# 3) đọc lich.json page phụ 30–45 phút/lần  4) báo Lark khi Facebook bị đăng xuất / đang dùng sai nick  5) bỏ câu trả lời minigame ("tham gia", size)
out = thay(out, "  const duongNay = () => { const p = location.pathname.toLowerCase().replace(/\\/+$/, ''); if (p === '/profile.php') { const id = new URLSearchParams(location.search).get('id'); if (id) return '/' + id; } return p; };",
"  const duongNay = () => { const p = location.pathname.toLowerCase().replace(/\\/+$/, ''); if (p === '/profile.php') { const id = new URLSearchParams(location.search).get('id'); if (id) return '/' + id; } const mp = p.match(/^\\/people\\/[^/]+\\/(\\d{6,})$/); if (mp) return '/' + mp[1]; return p; }; // (6.37) /people/<tên>/<id>")
out = thay(out, "    let bd = kt.den; if (LA_CAO) bd = Math.max(kt.den + CAI_DAT.CAO_TRE_PHUT * 60000, moLuc + CAI_DAT.CAO_CHO_MO_PHUT * 60000);",
"    const _gh = laGh(kt.kenh || 1); let bd = kt.den; if (LA_CAO && !_gh) bd = Math.max(kt.den + CAI_DAT.CAO_TRE_PHUT * 60000, moLuc + CAI_DAT.CAO_CHO_MO_PHUT * 60000); // (6.37) page phụ: đúng giờ")
out = thay(out, "${LA_CAO ? ' (nếu Máy Giao chưa đăng)' : ''} · còn <b data-hen=", "${LA_CAO && !_gh ? ' (nếu Máy Giao chưa đăng)' : ''} · còn <b data-hen=")
out = thay(out, "      const cach = coBai ? (60 + Math.floor(Math.random() * 40)) * 60000 : 20 * 60000;", "      const cach = coBai ? (30 + Math.floor(Math.random() * 15)) * 60000 : 20 * 60000; // (6.37) 30–45 phút/lần")
import re as _re
_m = _re.search(r"    \{ ten: 'thamgia', re: .*?\n    \{ ten: 'size', re: .*?\n", out)
assert _m, 'khong thay TL_NHOM thamgia/size'
out = out[:_m.start()] + "    // (6.37) đã bỏ nhóm 'tham gia' + 'size' (minigame dừng 11/11) → trả lời như bình luận thường\n" + out[_m.end():]
out = thay(out, "  async function nhip() {", r"""  // (6.37) canh tài khoản Facebook: bị đăng xuất / đang dùng nick khác → báo Lark (mỗi loại tối đa 1 lần/ngày) + ghi nhật ký
  const NICK_DUNG = () => ['Nguyễn Hoàng Giang', ...KENH_ALL.map((c) => CAI_DAT.KENH[c].ten)];
  function canhTaiKhoan() {
    try {
      if (!MAY || !laTabChinh()) return;
      if (Date.now() - (window.__smhCanhTK || 0) < 3 * 60000) return; window.__smhCanhTK = Date.now();
      const p = location.pathname;
      const dx = /^\/(login|checkpoint|auth_platform|recover)/.test(p) || (!!document.querySelector('input[name="pass"]') && !document.querySelector('[aria-label="Tài khoản, trang cá nhân của bạn"]'));
      if (dx) { ghi('⚠️ Facebook trên máy này đang bị ĐĂNG XUẤT / chờ xác minh đăng nhập → script không đăng được'); baoLoi(`⚠️ ${TEN_MAY}: Facebook đang bị đăng xuất hoặc chờ xác minh đăng nhập → không đăng bài được. Đăng nhập lại nick Nguyễn Hoàng Giang trên Chrome máy này.`, 'loitrang_dangxuat_' + homNay()); return; }
      const ed = Array.from(document.querySelectorAll('div[role="textbox"][aria-label*="dưới tên "]')).map((e) => chuan(e.getAttribute('aria-label') || '').match(/dưới tên (.+)$/)).find(Boolean);
      if (!ed) return;
      const ten = ed[1].trim(); const dung = NICK_DUNG().some((x) => chuanTen(x) === chuanTen(ten));
      if (!dung) { ghi(`⚠️ Facebook trên máy này đang dùng nick "${ten}" (không phải Nguyễn Hoàng Giang / tên trang)`); baoLoi(`⚠️ ${TEN_MAY}: Facebook đang dùng nick "${ten}" — script cần nick Nguyễn Hoàng Giang để đăng đúng tư cách. Đăng nhập lại nick Giang.`, 'loitrang_nick_' + homNay() + '_' + chuanTen(ten).slice(0, 20)); }
    } catch (e) { ghi('Canh tài khoản lỗi: ' + e.message); }
  }
  async function nhip() {
    canhTaiKhoan();""")
