
  // =====================================================================
  //  LỊCH 9 BÀI / NGÀY + TRẠNG THÁI
  // =====================================================================
  const XONG = ['xong', 'co_san'];                                   // đã lên trang
  const KET = XONG.concat(['bo', 'thieu', 'loi', 'khong_ro']);        // đã kết thúc (không đăng nữa)
  // (6.19.3) số ngẫu nhiên "theo ngày": 2 máy bốc ra CÙNG giờ đăng (trước đây mỗi máy tự bốc → Máy Cao có thể ra tay khi Máy Giao vẫn đúng giờ)
  const ngauTheoNgay = (ngay, khoa) => { let seed = 17; for (const ch of String(ngay) + '|' + khoa) seed = (seed * 31 + ch.charCodeAt(0)) >>> 0; return soNgau(seed); };
  function taoGio(ngay = homNay()) { // giờ ngẫu nhiên trong khung, 2 bài liền nhau cách ít nhất 1 tiếng
    let truoc = -1e9; const g = {}; const rnd = ngauTheoNgay(ngay, 'gio');
    for (const it of LICH_GOC) { const a = docGio(it.tu), b = docGio(it.den); let x = a + Math.floor(rnd() * (b - a + 1)); x = Math.max(x, truoc + CAI_DAT.CACH_LICH_PHUT); g[it.k] = x; truoc = x; }
    return g;
  }
  // (6.28.3) XẾP ĐỀU LỊCH KÊNH 1: mọi bài kênh 1 trong ngày (kể cả bài thêm) rải đều 06:30–20:00 theo thứ tự xen kẽ
  //  Bài 1 → Video 1 → Manifest 1 → Bài 2 → … → Bài 4 → Video 4 → Manifest 4 …; chỉ xếp lại bài CHƯA đăng.
  //  Không đủ chỗ với khoảng ≥ 30 phút → rút dần tới 15 phút; vẫn không đủ → kéo tới 21:00 (cách 15 phút). Ngẫu nhiên theo ngày → 2 máy ra cùng giờ.
  const BAN_XEP = '6.28.3';
  const XEP_DAU = '06:30', XEP_CUOI = '20:00', XEP_CUOI_MUON = '21:00';
  const soThuTuK1 = (k) => { const m = /^([bvm])(\d+)$/.exec(k); if (!m) return 999; return (+m[2] - 1) * 3 + ({ b: 0, v: 1, m: 2 })[m[1]]; };
  function xepDeuK1(s, ngay, ep) {
    const d = duLieu(); if (!(d && d.ngay && d.ngay[ngay])) return false; // chưa đọc sheet ngày này → chưa biết có bao nhiêu bài
    const K = lichNgay(ngay).filter((x) => (x.kenh || 1) === 1).sort((a, b) => soThuTuK1(a.k) - soThuTuK1(b.k));
    const sig = K.map((x) => x.k).join(',');
    if (!ep && s.sigK1 === sig && s.banXep === BAN_XEP && K.every((x) => typeof s.gio[x.k] === 'number')) return false; // bài nào mất giờ (xếp lại khi đổi bản) → xếp lại
    const dd0 = lay('dang_do', null);
    const daLam = (k) => { const x = (s.s || {})[k]; return !!((x && x.tt && x.tt !== 'cho') || (dd0 && dd0.slot === k)); };
    const lam = K.filter((x) => daLam(x.k)); const con = K.filter((x) => !daLam(x.k));
    s.sigK1 = sig; s.banXep = BAN_XEP;
    if (!con.length) return true;
    const homNayLa = ngay === homNay(); const now = new Date(); const phutNay = homNayLa ? now.getHours() * 60 + now.getMinutes() : 0;
    const DAU = docGio(XEP_DAU), CUOI = docGio(XEP_CUOI), MUON = docGio(XEP_CUOI_MUON);
    const truoc = Math.max(-1, ...lam.map((x) => { const r = s.s[x.k]; if (r && r.luc && homNayLa) { const t = new Date(r.luc); return t.getHours() * 60 + t.getMinutes(); } return typeof s.gio[x.k] === 'number' ? s.gio[x.k] : -1; }));
    const rnd = ngauTheoNgay(ngay, 'xepdeu|' + sig);
    const m = con.length; let tg = [];
    const batDauMoi = !lam.length && phutNay < DAU;
    if (batDauMoi) { // đầu ngày: bài đầu 06:30, bài cuối 20:00
      let buoc = m > 1 ? (CUOI - DAU) / (m - 1) : 0;
      if (m > 1 && buoc < 15) buoc = Math.max(15, (MUON - DAU) / (m - 1));
      tg = con.map((x, i) => DAU + i * buoc);
      const lech = Math.min(10, buoc / 4); tg = tg.map((t, i) => Math.round(i === 0 ? t + rnd() * lech : t - rnd() * lech));
    } else { // giữa ngày (thêm bài / lên bản mới): từ giờ hiện tại (cách bài vừa đăng ≥ 30 phút) tới 20:00
      const tu = Math.max(phutNay + 5, truoc >= 0 ? truoc + 30 : 0, DAU);
      let buoc = (CUOI - tu) / m;
      if (buoc >= 30) { const lech = Math.min(8, buoc / 5); tg = con.map((x, i) => Math.round(tu + (i + 0.5) * buoc - rnd() * lech)); }
      else {
        buoc = m > 1 ? (CUOI - tu) / (m - 1) : 0;
        if (m > 1 && buoc < 15) buoc = Math.max(15, (MUON - tu) / (m - 1));
        tg = con.map((x, i) => Math.round(tu + i * Math.max(15, buoc)));
      }
    }
    for (let i = 1; i < tg.length; i++) tg[i] = Math.max(tg[i], tg[i - 1] + 15); // giờ luôn tăng, cách ≥ 15 phút
    const doi = [];
    con.forEach((x, i) => { if (s.gio[x.k] !== tg[i]) doi.push(`${x.ten} ${phutStr(tg[i])}`); s.gio[x.k] = tg[i]; });
    if (doi.length) ghi(`Xếp đều lịch kênh 1 (${K.length} bài, ${lam.length} đã đăng/đang làm): ${doi.join(' · ')}`);
    return true;
  }
  // (6.28.3) khoảng cách giữa 2 bài kênh 1 lúc chạy: còn nhiều bài so với thời gian tới 20:00 (số bài × 30 phút vượt 20:00) → 15 phút, còn lại 30 phút
  function cachK1(L) {
    const con = (L || tinhLichNhe()).filter((x) => (x.kenh || 1) === 1 && !x.ket).length;
    return Date.now() + con * CAI_DAT.CACH_BU_PHUT * 60000 > lucPhut(docGio(XEP_CUOI)) ? 15 : CAI_DAT.CACH_BU_PHUT;
  }
  const tinhLichNhe = () => { const s = lay('ngay6_' + homNay(), null) || { s: {} }; return LICH.map((it) => ({ kenh: it.kenh, ket: KET.includes(((s.s || {})[it.k] || {}).tt) })); };
  // (6.19) giờ cho video kênh 2, 3: video cuối của mỗi kênh đăng trước bài đầu tiên kênh 1 khoảng 5–15 phút; video trước đó cách ≥ 30 phút (cùng trang)
  let ngauNhien = (a, b) => a + Math.floor(Math.random() * (b - a + 1));
  function ganGioKenh(s, ngay) {
    const rnd = ngauTheoNgay(ngay, 'kenh'); ngauNhien = (a, b) => a + Math.floor(rnd() * (b - a + 1));
    let doi = xepDeuK1(s, ngay); // (6.28.3)
    if (ganGioThem(s, ngay)) doi = true;
    if (ganGioBaiThem(s, ngay)) doi = true; // (6.26)
    const L = lichNgay(ngay).filter((x) => x.kenh > 1); if (!L.length) return doi;
    const goc = LICH_GOC.map((x) => s.gio[x.k]).filter((v) => typeof v === 'number'); if (!goc.length) return doi;
    const dau = Math.min(...goc);
    for (const c of KENH_PHU) {
      const ds = L.filter((x) => x.kenh === c).sort((a, b) => a.so - b.so); if (!ds.length || ds.every((x) => typeof s.gio[x.k] === 'number')) continue;
      const co = ds.filter((x) => typeof s.gio[x.k] === 'number');
      if (!co.length) { // chưa có giờ nào → tính lùi từ trước bài đầu kênh 1
        let t = dau - ngauNhien(CAI_DAT.KENH_TRUOC_PHUT[0], CAI_DAT.KENH_TRUOC_PHUT[1]);
        for (let i = ds.length - 1; i >= 0; i--) { s.gio[ds[i].k] = t; t -= CAI_DAT.KENH_CACH_PHUT + ngauNhien(0, 5); }
      } else { // sheet thêm video giữa ngày → xếp sau video cuối của kênh đó ≥ 30 phút
        let truoc = Math.max(...co.map((x) => s.gio[x.k]));
        for (const x of ds) if (typeof s.gio[x.k] !== 'number') { truoc += CAI_DAT.KENH_CACH_PHUT + ngauNhien(0, 5); s.gio[x.k] = truoc; }
      }
      doi = true;
    }
    return doi;
  }
  // (6.19.3) bài kênh 1 THÊM (sheet có hơn 3 video / 3 manifest trong ngày): xen vào khoảng trống trong ngày, xa các bài khác nhất (≥ 20 phút nếu được);
  //  đọc sheet giữa ngày thì chỉ xếp từ giờ hiện tại trở đi; chậm nhất 22:00 (bài thêm được đăng tới GIO_CHOT_THEM)
  function ganGioThem(s, ngay) { // (6.25) bài thêm: cách GIỜ HẸN bài trước 30–45 phút, mỗi khoảng giữa 2 bài thường lệ tối đa 1 bài thêm, muộn nhất 21:00
    //  không phụ thuộc giờ đọc sheet + ngẫu nhiên theo ngày → Máy Giao và Máy Cao luôn ra CÙNG giờ (bài thêm rơi vào giờ đã qua thì đăng bù ngay, giữ giãn cách)
    const T = lichNgay(ngay).filter((x) => x.them && typeof s.gio[x.k] !== 'number').sort((a, b) => ((nhomSlot(a.k) || {}).so || 0) - ((nhomSlot(b.k) || {}).so || 0)); if (!T.length) return false; // (6.27.1) Video 4 trước Video 5…
    const R = LICH_GOC.filter((x) => (x.kenh || 1) === 1).map((x) => s.gio[x.k]).filter((v) => typeof v === 'number').sort((a, b) => a - b);
    const daCo = lichNgay(ngay).filter((x) => (x.them || x.baiThem) && typeof s.gio[x.k] === 'number').map((x) => s.gio[x.k]); // (6.28) tính cả Bài 4–6
    const MUON = docGio(CAI_DAT.GIO_THEM_MUON_NHAT || '21:00');
    const khe = R.map((g, i) => [g, i + 1 < R.length ? R[i + 1] : MUON + 30]);
    for (const it of T) {
      const rnd = ngauTheoNgay(ngay, 'them|' + it.k); const cach = 30 + Math.floor(rnd() * 16);
      const gs = nhomSlot(it.k); const tk = gs ? keySlot(gs.nhom, gs.so - 1) : ''; const minT = typeof s.gio[tk] === 'number' ? s.gio[tk] + cach : 0; // (6.27.1) giữ số thứ tự: sau bài số liền trước cùng loại
      let gan = null;
      for (let toiDa = 1; toiDa <= 3 && gan == null; toiDa++) { // lượt 1: khoảng chưa có bài thêm; hết chỗ mới cho 2, 3 bài/khoảng
        for (const k of khe) {
          const co = daCo.filter((t) => t > k[0] && t < k[1]).sort((a, b) => a - b); if (co.length >= toiDa) continue;
          const t = Math.max((co.length ? co[co.length - 1] : k[0]) + cach, minT);
          if (t + 30 <= k[1] && t <= MUON) { gan = t; break; }
        }
      }
      if (gan == null) gan = Math.min(docGio(CAI_DAT.GIO_CHOT_THEM) - 30, Math.max(MUON + cach, minT, ...daCo.map((t) => t + cach)));
      s.gio[it.k] = gan; daCo.push(gan);
    }
    return true;
  }

  // (6.26) bài viết của hàng thứ 2, 3… trong ngày: rải đều 06:30–21:00, cách mọi bài khác ≥ 30 phút, ngẫu nhiên theo ngày (2 máy cùng giờ)
  function ganGioBaiThem(s, ngay) {
    const T = lichNgay(ngay).filter((x) => x.baiThem && typeof s.gio[x.k] !== 'number').sort((a, b) => +a.k.slice(1) - +b.k.slice(1)); if (!T.length) return false;
    const DAU = docGio('06:30'), CUOI = docGio(CAI_DAT.GIO_THEM_MUON_NHAT || '21:00'), CACH = 30;
    const co = lichNgay(ngay).filter((x) => (x.kenh || 1) === 1 && typeof s.gio[x.k] === 'number').map((x) => s.gio[x.k]);
    let truoc = typeof s.gio.b3 === 'number' ? s.gio.b3 : DAU - CACH; // (6.27.1) Bài 4 sau Bài 3, Bài 5 sau Bài 4…
    for (const it of T) {
      const rnd = ngauTheoNgay(ngay, 'baithem|' + it.k);
      { const kt = 'b' + (+it.k.slice(1) - 1); if (typeof s.gio[kt] === 'number') truoc = Math.max(truoc, s.gio[kt]); }
      const tu = Math.max(DAU, truoc + CACH);
      const moc = [tu - CACH, ...co.filter((t) => t >= tu && t <= CUOI), CUOI + CACH].sort((a, b) => a - b);
      let tot = null; // (6.28) khoảng trống SỚM NHẤT sau bài liền trước (cách 2 đầu ≥ 30 phút) → bài thêm không bị dồn hết về tối rồi bị bỏ
      for (let i = 0; i + 1 < moc.length && !tot; i++) { const a = moc[i] + CACH, b = moc[i + 1] - CACH; if (b >= a) tot = [a, b]; }
      let gan;
      if (tot) gan = Math.round(tot[0] + rnd() * Math.min(20, tot[1] - tot[0]));
      else gan = Math.max(truoc + 10, Math.min(docGio(CAI_DAT.GIO_CHOT_THEM) - 15, Math.max(...co, CUOI, truoc) + CACH)); // hết chỗ trống: xếp cuối ngày (bài thêm được tới GIO_CHOT_THEM), giờ luôn tăng dần
      s.gio[it.k] = gan; co.push(gan); truoc = gan;
    }
    { const g = T.map((x) => s.gio[x.k]).sort((a, b) => a - b); T.forEach((x, i) => { s.gio[x.k] = g[i]; }); } // Bài 4 trước Bài 5 trước Bài 6…
    return true;
  }
  let NGAY_VIEC = '';
  function trangThai(ngay = NGAY_VIEC || homNay()) {
    let s = lay('ngay6_' + ngay, null);
    if (!s || !s.gio) { s = { gio: taoGio(ngay), s: {}, ngoai: {}, tao: Date.now(), thuTu27: 2, banLich: PHIEN_BAN }; ganGioKenh(s, ngay); luu('ngay6_' + ngay, s); ghi(`Lịch đăng ${ngay === homNay() ? 'hôm nay' : ngay}: ` + lichNgay(ngay).filter((it) => typeof s.gio[it.k] === 'number').sort((a, b) => s.gio[a.k] - s.gio[b.k]).map((it) => it.ten + ' ' + phutStr(s.gio[it.k])).join(' · ')); }
    else if ((!s.thuTu27 || (s.banLich && cuHon(s.banLich, PHIEN_BAN)) || (!s.banLich && s.thuTu27 !== 2)) && ((duLieu() || {}).ngay || {})[ngay]) { /* (6.28.2) chỉ xếp lại khi đã có dữ liệu sheet của ngày (mới biết có những bài thêm nào) */ s.thuTu27 = 2; s.banLich = PHIEN_BAN; const dd0 = lay('dang_do', null); const xep = lichNgay(ngay).filter((x) => (x.them || x.baiThem) && typeof s.gio[x.k] === 'number' && !(s.s && s.s[x.k] && s.s[x.k].tt && s.s[x.k].tt !== 'cho') && !(dd0 && dd0.slot === x.k)); for (const x of xep) delete s.gio[x.k]; ganGioKenh(s, ngay); luu('ngay6_' + ngay, s); if (xep.length) ghi(`(${PHIEN_BAN}) Xếp lại giờ bài thêm chưa đăng theo luật mới (đúng số thứ tự): ` + xep.map((x) => x.ten + ' ' + phutStr(s.gio[x.k])).join(' · ')); } // (6.27.1)
    else if (ganGioKenh(s, ngay)) { luu('ngay6_' + ngay, s); ghi(`Giờ đăng ${ngay === homNay() ? 'hôm nay' : ngay} (bài kênh 2, 3 / bài thêm): ` + lichNgay(ngay).filter((it) => it.kenh > 1 || it.them || it.baiThem).map((it) => it.ten + ' ' + phutStr(s.gio[it.k])).join(' · ')); }
    s.s = s.s || {}; s.ngoai = s.ngoai || {};
    return s;
  }
  const capNhatTT = (f, ngay = NGAY_VIEC || homNay()) => { const s = trangThai(ngay); f(s); luu('ngay6_' + ngay, s); return s; };
  const ttSlot = (s, k) => s.s[k] || (s.s[k] = { tt: 'cho' });
  function tinhLich(s = trangThai()) { // (6.19) xếp theo giờ; giãn cách bài bù chỉ tính trong CÙNG 1 kênh (mỗi trang riêng)
    const g = (it) => (typeof s.gio[it.k] === 'number' ? s.gio[it.k] : 9e9);
    const L = LICH.slice().sort((a, b) => g(a) - g(b)).map((it) => { const r = s.s[it.k] || { tt: 'cho' }; return Object.assign({}, it, { r, gioKH: s.gio[it.k], ket: KET.includes(r.tt), xong: XONG.includes(r.tt) }); });
    // kênh 1: bài kế tiếp là bài chưa xong đầu tiên theo thứ tự (như cũ); kênh 2, 3: video kênh khác tới giờ thì không phải chờ kênh này
    const conLai = L.filter((x) => !x.ket); if (!conLai.length) return L;
    const den = (x) => Math.max(lucPhut(g(x)), lucBuKenh(L, x));
    // mỗi kênh lấy bài chưa xong đầu tiên của kênh đó → chọn bài tới giờ sớm nhất (bằng nhau thì theo thứ tự lịch)
    const dau = []; for (const x of conLai) if (!dau.some((y) => (y.kenh || 1) === (x.kenh || 1))) dau.push(x);
    let kt = dau[0]; for (const x of dau.slice(1)) if (den(x) < den(kt) && den(kt) > Date.now()) kt = x;
    kt.keTiep = true; kt.den = den(kt);
    return L;
  }
  // (6.24) giờ dự kiến từng bài chưa đăng + thứ tự xếp hàng (để popup hiện "xếp hàng thứ N · dự kiến ~HH:MM")
  function duKienLich(L) {
    const out = {}; const now = Date.now();
    for (const c of KENH_ALL) {
      const ds = L.filter((x) => (x.kenh || 1) === c);
      const gap = (c > 1 ? CAI_DAT.KENH_CACH_PHUT : cachK1(L)) * 60000;
      let truoc = Math.max(0, ...ds.filter((x) => x.xong && x.r.luc).map((x) => x.r.luc)); let thu = 0, tenTruoc = '';
      for (const x of ds.filter((y) => !y.ket && typeof y.gioKH === 'number').sort((a, b) => a.gioKH - b.gioKH)) {
        let t = Math.max(lucPhut(x.gioKH), truoc ? truoc + gap : 0); if (x.keTiep && x.den) t = Math.max(t, x.den);
        thu++; out[x.k] = { luc: Math.max(t, x.keTiep ? 0 : now), thu, sau: tenTruoc, tre: t > lucPhut(x.gioKH) + 60000 || lucPhut(x.gioKH) < now };
        truoc = Math.max(t, now); tenTruoc = x.ten;
      }
    }
    return out;
  }
  // (6.19) nhìn trang (không cần mã khoá): bài có chữ này đã có trên trang chưa → { link } | null
  async function daCoTrenTrangDom(text, boQuaSlot) { // boQuaSlot: bỏ qua các bài đã thuộc ô khác (2 video cùng chữ)
    if (!text) return null;
    const boQua = new Set(); if (boQuaSlot) { const s0 = trangThai(); for (const [k0, r0] of Object.entries(s0.s || {})) if (k0 !== boQuaSlot && r0 && r0.link) boQua.add(linkGon(r0.link)); }
    window.scrollTo(0, 0); await sleep(1200);
    for (let i = 0; i < 6; i++) {
      const ds = cacKhungBai().filter((x) => khungKhop(x, text));
      for (const k of ds) { const a = Array.from(k.khung.querySelectorAll('a[href]')).map((x) => x.href).find((h) => /\/(reel|videos|posts)\//.test(h)) || ''; const lk = a.replace(/[?#].*$/, '').replace(/\/+$/, ''); if (lk && boQua.has(linkGon(lk))) continue; window.scrollTo(0, 0); return { link: lk }; }
      window.scrollBy(0, 1200); await sleep(1500);
    }
    window.scrollTo(0, 0); return null;
  }
  const lucBuKenh = (L, x) => { const c = x.kenh || 1; const t = Math.max(0, ...L.filter((y) => y.xong && y.r.luc && (y.kenh || 1) === c).map((y) => y.r.luc)); return t ? t + (c > 1 ? CAI_DAT.KENH_CACH_PHUT : cachK1(L)) * 60000 : 0; };
  // trang đang mở thuộc kênh nào (0 = không phải trang nào trong 3 kênh)
  const kenhCuaDuong = () => {
    const p = duongNay(); for (const c of KENH_ALL) if (CAI_DAT.KENH[c].duong.includes(p)) return c;
    if (p === '/profile.php') { // (6.26.9b) Facebook mở trang dạng /profile.php KHÔNG kèm mã trang (đang ở tư cách trang đó) → nhận kênh theo tên trang trên màn hình, rồi theo tư cách vừa kiểm
      const tenTrenTrang = [...document.querySelectorAll('h1, h2')].map((x) => chuanTen(x.innerText || '')).filter(Boolean);
      for (const c of KENH_ALL) if (tenTrenTrang.includes(chuanTen(CAI_DAT.KENH[c].ten))) return c;
      const tc = String((lay('suc_khoe', {}) || {}).tuCach || '').replace(/\s*\(.*\)\s*$/, '');
      for (const c of KENH_ALL) if (tc && chuanTen(tc) === chuanTen(CAI_DAT.KENH[c].ten)) return c;
    }
    return 0;
  };
  // video kênh 2, 3 vừa đăng (≤ 12 phút) còn chờ thả cảm xúc trên trang đang mở → đừng chuyển sang trang khác vội
  function coSuaKenhCho(c) {
    if (!c || c === 1 || !CAI_DAT.SUA_VIDEO_SAU_DANG) return false; const s = trangThai(); const now = Date.now();
    return LICH.some((x) => x.kenh === c && (() => { const r = s.s[x.k]; return r && XONG.includes(r.tt) && r.may === MAY && r.link && !r.suaXong && (r.suaLan || 0) < CAI_DAT.KENH_SUA_TOI_DA && now - (r.luc || 0) < 12 * 60000; })());
  }
  const keTiep = () => tinhLich().find((x) => x.keTiep) || null;
  // "máy mở lại lúc nào" (để Máy Cao chờ Máy Giao làm trước khi cả hai cùng có mạng lại)
  let moLuc = Date.now();
  { const song = lay('song6', 0); const m0 = lay('mo6', 0); moLuc = Date.now() - song < 5 * 60000 && m0 ? m0 : Date.now(); luu('mo6', moLuc); }
  const tamDung = () => !!lay('tam_dung', false);
  // (6.23) mọi nút Tạm dừng tự chạy lại sau 10 phút (giữ cả khi tải lại trang)
  const TAM_DUNG_PHUT = 10;
  const conTamDung = () => { const l = lay('tam_dung_luc', 0) || Date.now(); const m = Math.max(0, Math.ceil((l + TAM_DUNG_PHUT * 60000 - Date.now()) / 60000)); return m + ' phút'; };
  function tuChayLaiTamDung() {
    if (!tamDung()) return false;
    const l = lay('tam_dung_luc', 0);
    if (!l) { luu('tam_dung_luc', Date.now()); return false; } // tạm dừng từ bản cũ → tính 10 phút từ bây giờ
    if (Date.now() - l < TAM_DUNG_PHUT * 60000) return false;
    luu('tam_dung', false); luu('tam_dung_luc', 0);
    ghi(`Tạm dừng đã ${TAM_DUNG_PHUT} phút → tự chạy lại`);
    return true;
  }
  const tuDong = () => lay('tu_dong6', true) !== false;
  const chayThu = () => !!lay('chay_thu6', false);
  const dangHoan = () => lay('hoan6', 0) > Date.now();

  // =====================================================================
  //  DÒ BÀI TRÊN TRANG (qua Facebook — không tốn lượt Lark)
  // =====================================================================
  const loaiSo = { b1: 1, b2: 2, b3: 3, video: 4, manifest: 5 };
  // khớp bài trên trang với chữ trong sheet: so từng từ (≥ 90%); dự phòng khi Facebook dính chữ ở chỗ xuống dòng → so chuỗi chữ-số liền (40 ký tự đầu)
  // (6.17) 2 video khác nhau có thể giống nhau gần hết phần thân (chỉ khác câu mở đầu) → bắt buộc câu mở đầu cũng phải khớp;
  // 1 thước phim có thể hiện 2 lần trong danh sách Facebook (2 mã khác nhau, cùng 1 link) → coi là 1 bài, không gán cho 2 ô
  const linkGon = (l) => String(l || '').replace(/[?#].*$/, '').replace(/\/+$/, '').replace(/^https?:\/\/(www\.|m\.|web\.)?/, '').toLowerCase();
  const dongDau = (s) => (String(s || '').split('\n').map((x) => x.trim()).find((x) => tuCua(x).length >= 2) || '');
  // (6.20.2) SO KHỚP CHẶT: chỉ bỏ qua xuống dòng, khoảng trắng, dấu câu, icon, hoa/thường + sai tối đa 2 ký tự.
  // Hai kịch bản na ná (cùng mở đầu, khác nội dung) = 2 bài khác nhau. biCat: chữ trên trang bị Facebook cắt "Xem thêm" → so phần đang hiện (≥ 80 ký tự)
  function lechToiDa(a, b, k) { // khoảng cách sửa chữ (Levenshtein) có giới hạn k; trả về k+1 nếu vượt
    if (Math.abs(a.length - b.length) > k) return k + 1;
    let truoc = Array.from({ length: b.length + 1 }, (_, j) => j);
    for (let i = 1; i <= a.length; i++) {
      const nay = [i]; let nho = i;
      for (let j = 1; j <= b.length; j++) { const v = Math.min(truoc[j] + 1, nay[j - 1] + 1, truoc[j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1)); nay.push(v); if (v < nho) nho = v; }
      if (nho > k) return k + 1; truoc = nay;
    }
    return truoc[b.length];
  }
  // (6.24.1) trang mới chỉ hiện ~2 dòng trước "Xem thêm" → phần chữ bị cắt chỉ cần ≥ 30 ký tự (trước đây ≥ 60 nên không nhận ra bài)
  function soChat(text, chuBai, biCat) {
    const A = khoaSo(text), B0 = khoaSo(chuBai); if (A.length < 8 || !B0) return { ok: false, trung: 0 };
    let B = B0; if (biCat) B = B.replace(/(xemthêm|xemthem|seemore)$/, '');
    let L = 0; while (L < A.length && L < B.length && A[L] === B[L]) L++;
    if (biCat && B.length < A.length) { if (B.length < Math.min(30, A.length)) return { ok: false, trung: L }; return { ok: lechToiDa(A.slice(0, B.length), B, 1) <= 1, trung: L }; }
    if (B.length > A.length + 2 && A.length >= 30 && lechToiDa(A, B.slice(0, A.length), 1) <= 1) return { ok: true, trung: L }; // (6.20.11) chữ ngắn (manifest) trùng trọn vẹn phần đầu, Facebook/nhân sự thêm chữ ở cuối (hashtag…) → vẫn là bài này
    if (B.length > A.length + 2 && A.length >= 80) return { ok: lechToiDa(A, B.slice(0, A.length), 2) <= 2, trung: L }; // bài trên trang có thêm hashtag/chữ ở cuối
    return { ok: lechToiDa(A, B, 2) <= 2, trung: L };
  }
  const daGhiNaNa = new Set();
  function ghiNaNa(ten, trung, nguon) { const k = ten + '|' + trung + '|' + nguon; if (daGhiNaNa.has(k) || trung < 20) return; daGhiNaNa.add(k); ghi(`So khớp: ${ten} — bài trên trang (${nguon}) giống phần đầu ${trung} ký tự nhưng khác nội dung → tính là 2 bài khác nhau`); }
  function dauKhop(p, text) { return soChat(text, p.text).ok; }
  function dauKhopCu(p, text) {
    const d = dongDau(text); const a = tuCua(d); if (a.length < 3) return true;
    { const kd = khoaSo(d); if (kd.length >= 8 && khoaSo(p.text).slice(0, kd.length + 40).includes(kd)) return true; } // (6.19.3) câu mở đầu ngắn (manifest) cũng so được // (6.19) Facebook dính chữ ở chỗ xuống dòng ("denNang") → so chuỗi chữ-số liền của câu mở đầu
    const b = tuCua(p.text).slice(0, a.length + 8).join(' ');
    return doGiong(b, d) >= 0.75;
  }
  function baiKhop(ds, text, daDung) {
    const ok = ds.filter((x) => !(daDung && (daDung.has(x.id) || (x.link && daDung.has('L:' + linkGon(x.link))))) && dauKhop(x, text));
    if (!ok.length) { for (const x of ds) { const r = soChat(text, x.text); if (r.trung >= 20) ghiNaNa(dauBai0(text), r.trung, 'API'); } return null; }
    return baiGiongNhat(ok, text) || ok[0];
  }
  const dauBai0 = (t) => '"' + chuan(t).slice(0, 40) + '…"';
  const dungBai = (set, p) => { set.add(p.id); if (p.link) set.add('L:' + linkGon(p.link)); };
  // ---- (6.9) cài đặt comment: comment mặc định + link Zalo + danh sách câu CTA (lưu trong máy + ô Z3 của sheet cho cả 2 máy) ----
  function cauHinhCmt() {
    const c = lay('cmt6', null) || {};
    const cta = Array.isArray(c.cta) ? c.cta.map((x) => String(x).trim()).filter(Boolean) : CAI_DAT.CTA_MAC_DINH.slice();
    return { gocHx: typeof c.gocHx === 'string' && c.gocHx.trim() ? c.gocHx : CAI_DAT.CMT_HX, goc: typeof c.goc === 'string' && c.goc.trim() ? c.goc : CAI_DAT.CMT_BAI3, link: (c.link || CAI_DAT.LINK_ZALO).trim(), cta, bat: c.bat !== false,
      loai: Object.assign({ b1: true, b2: true, b3: true, video: true, manifest: true }, c.loai || {}), kenh: Object.assign({ 1: true, 2: true, 3: true, 4: false }, c.kenh || {}), luc: c.luc || 0, may: c.may || '' };
  }
  function soNgau(seed) { let a = seed >>> 0; return () => { a = (a + 0x6D2B79F5) >>> 0; let t = a; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }
  function chonCTA(k, ngay = homNay()) { // mỗi bài trong ngày 1 câu khác nhau (xáo theo ngày), hết câu thì quay vòng
    const c = cauHinhCmt(); if (!c.cta.length) return '';
    let seed = 0; for (const ch of ngay) seed = seed * 31 + ch.charCodeAt(0);
    const r = soNgau(seed); const thu = c.cta.map((x, i) => [r(), i]).sort((a, b) => a[0] - b[0]).map((x) => x[1]);
    const vt = LICH.findIndex((x) => x.k === k);
    return c.cta[thu[(vt >= 0 ? vt : Math.floor(Math.random() * 9)) % thu.length]];
  }
  // (6.12) CTA nhóm Zalo là 1 comment RIÊNG, đăng ngay sau comment chữ chính (trước các comment ảnh)
  function cmtCTA(it, ngay) {
    const c = cauHinhCmt(); if (!c.bat || !c.loai[it.loai] || !c.link || !c.cta.length) return '';
    if (it.k && c.kenh[kenhCua(it.k)] === false) return ''; // (6.19) bỏ tick CTA Zalo của kênh nào thì kênh đó không comment CTA
    return `${chonCTA(it.k, ngay)}\n>>> ${c.link}`; // (6.12) không ghi chữ "CTA:" / "Link:"
  }
  function canCmt(it, nd, chung, ngay) { // các comment cần có dưới bài (để kiểm và gửi bù)
    chung = chung || ((duLieu() || {}).chung) || { co: '', pool: [] };
    const it2 = it.k ? it : { loai: it.loai || 'video' };
    if (it.k && (CAI_DAT.KENH[kenhCua(it.k)] || {}).hx) { const g = (cauHinhCmt().gocHx || CAI_DAT.CMT_HX).trim(); return { text: g ? [g] : [], anh: [] }; } // (6.26) kênh Hà Xá: chỉ 1 comment thông tin riêng (không CTA Zalo SMH, không ảnh SMH)
    const cta = cmtCTA(it2, ngay);
    if (it.loai === 'b1' || it.loai === 'b2') return { text: nd.cmt ? [nd.cmt].concat(cta ? [cta] : []) : [], anh: [] };
    const anh = []; if (chung.co) anh.push(chung.co); { const pl = (it.k && kenhCua(it.k) > 1) ? (chung.poolK || []) : (chung.pool || []); if (pl.length) anh.push(pl[Math.floor(Math.random() * pl.length)]); } // (6.20.2) K1: P2:P10 · K2/K3: Q2:Q10
    if (it.loai === 'b3') (nd.anhCmt || []).forEach((t) => anh.push(t));
    return { text: [cauHinhCmt().goc].concat(cta ? [cta] : []), anh };
  }
  async function luuCauHinhCmt(c) {
    const moi = { goc: c.goc, gocHx: c.gocHx || CAI_DAT.CMT_HX, link: c.link, cta: c.cta, bat: c.bat, loai: c.loai, kenh: c.kenh || { 1: true, 2: true, 3: true, 4: false }, luc: Date.now(), may: MAY };
    luu('cmt6', moi);
    ghi(`Đã lưu cài đặt comment (${moi.cta.length} câu CTA, CTA ${moi.bat ? 'BẬT' : 'TẮT'})`);
    await ghiO(CAI_DAT.TAB_BAI, CAI_DAT.O_CMT, JSON.stringify(moi));
    luu('cmt6_dongbo', Date.now());
    return moi;
  }
  // ---- (6.11) kho thẻ: video / manifest — mỗi bài bốc 8 thẻ, các bài cùng loại trong ngày lấy bộ khác nhau ----
  function khoThe() {
    const c = lay('the6', null) || {}; const sach = (a, md) => (Array.isArray(a) ? a.map((x) => String(x).trim()).filter(Boolean) : md.slice());
    return { video: sach(c.video, CAI_DAT.THE_VIDEO), video2: sach(c.video2, CAI_DAT.THE_VIDEO_K2), video3: sach(c.video3, CAI_DAT.THE_VIDEO_K3), video4: (() => { const v = sach(c.video4, CAI_DAT.THE_VIDEO_K4); return v.length ? v : CAI_DAT.THE_VIDEO_K4.slice(); })(), manifest: sach(c.manifest, CAI_DAT.THE_MANIFEST), luc: c.luc || 0, may: c.may || '' }; // (6.19.3) mỗi kênh 1 kho thẻ video
  }
  function chonThe(loai, so, ngay = homNay(), kho, kenh = 1) {
    kenh = +kenh || 1; const K = kho || khoThe();
    const ds = loai === 'manifest' ? K.manifest : (kenh > 1 ? (K['video' + kenh] || []) : K.video); const n = Math.min(CAI_DAT.SO_THE, ds.length); if (!n) return [];
    let seed = 7; for (const ch of ngay + loai + (kenh > 1 ? 'k' + kenh : '')) seed = seed * 31 + ch.charCodeAt(0);
    const r = soNgau(seed); const thu = ds.map((x, i) => [r(), i]).sort((a, b) => a[0] - b[0]).map((x) => x[1]);
    const out = []; for (let j = 0; j < n; j++) out.push(ds[thu[((so || 0) * n + j) % thu.length]]);
    return [...new Set(out)];
  }
  function hanKiemThe() { // (6.26.9) → { luc: lần sửa / xác nhận gần nhất, qua: số ngày, den: true nếu đến hạn }
    let luc = khoThe().luc || 0; if (!luc) { luc = lay('the6_bd', 0); if (!luc) { luc = Date.now(); luu('the6_bd', luc); } }
    const qua = Math.floor((Date.now() - luc) / 864e5); return { luc, qua, den: qua >= (CAI_DAT.THE_NHAC_NGAY || 7) };
  }
  async function luuKhoThe(c) {
    const moi = { video: c.video, video2: c.video2 || [], video3: c.video3 || [], video4: c.video4 || [], manifest: c.manifest, luc: Date.now(), may: MAY };
    luu('the6', moi); ghi(`Đã lưu kho thẻ (video kênh 1: ${moi.video.length}, kênh 2: ${moi.video2.length}, kênh 3: ${moi.video3.length}, Hà Xá: ${moi.video4.length} thẻ; manifest ${moi.manifest.length} thẻ)`);
    await ghiO(CAI_DAT.TAB_BAI, CAI_DAT.O_THE, JSON.stringify(moi)); luu('the6_dongbo', Date.now());
    return moi;
  }
  async function dongBoThe(san) {
    try {
      const t = chuO(san !== undefined ? san : await docO(CAI_DAT.TAB_BAI, CAI_DAT.O_THE)).trim(); if (!t || t[0] !== '{') return false;
      const z = JSON.parse(t); const cu = lay('the6', null) || {}; luu('the6_dongbo', Date.now());
      if ((z.luc || 0) > (cu.luc || 0)) { const khac = JSON.stringify([z.video, z.manifest, z.video2, z.video3, z.video4]) !== JSON.stringify([cu.video, cu.manifest, cu.video2, cu.video3, cu.video4]); luu('the6', z); if (khac) ghi(`Cập nhật kho thẻ từ sheet (bản lưu lúc ${gioStr(new Date(z.luc))})`); return khac; } // (6.26.9) bấm Xác nhận ở máy kia cũng cập nhật mốc kiểm tra
    } catch (e) { /* */ }
    return false;
  }
  async function baiConAnhApi(text) { // true = còn ảnh · false = không còn ảnh · null = chưa hỏi được
    if (!coApi() || !text) return null;
    try {
      const p = baiKhop(await baiTrenTrangApi(Date.now() - 12 * 3600e3), text); if (!p || !p.id) return null;
      const j = await goiFb(`/${p.id}?fields=attachments{type,media_type,subattachments{type,media_type}}`);
      const ds = ((j.attachments || {}).data || []); const anh = (x) => /photo|album|image/i.test((x.type || '') + ' ' + (x.media_type || ''));
      return ds.some((x) => anh(x) || ((x.subattachments || {}).data || []).some(anh));
    } catch (e) { return null; }
  }
  async function dongBoCmt(san) { // đọc bản trên sheet (ô Z3): mới hơn bản trong máy thì dùng bản sheet
    try {
      const t = chuO(san !== undefined ? san : await docO(CAI_DAT.TAB_BAI, CAI_DAT.O_CMT)).trim(); if (!t || t[0] !== '{') return false;
      const z = JSON.parse(t); const cu = lay('cmt6', null) || {};
      luu('cmt6_dongbo', Date.now());
      const khac = JSON.stringify([z.goc, z.link, z.cta, z.bat, z.loai, z.kenh]) !== JSON.stringify([cu.goc, cu.link, cu.cta, cu.bat, cu.loai, cu.kenh]);
      if ((z.luc || 0) > (cu.luc || 0) && khac) { luu('cmt6', z); ghi(`Cập nhật cài đặt comment từ sheet (bản lưu lúc ${gioStr(new Date(z.luc))}${z.may ? ' ở ' + (z.may === 'GIAO' ? 'Máy Giao' : 'Máy Cao') : ''})`); return true; }
    } catch (e) { /* */ }
    return false;
  }
  let doTrangCho = null, doTrangKC = 0;
  async function doTrang(lyDo = '') {
    if (!coApi()) return null;
    const KC = KENH_HT;
    if (doTrangCho && doTrangKC === KC) return doTrangCho;
    if (doTrangCho) { try { await doTrangCho; } catch (e) { /* */ } datKenh(KC); } // (6.20.2) đang dò kênh khác → chờ xong rồi dò đúng kênh này (trước đây trả luôn kết quả kênh kia → kênh 2/3 không được dò)
    doTrangKC = KC; // (6.19.2) giữ kênh lúc bắt đầu (trong lúc chờ Facebook trả lời, kênh đang làm có thể đổi)
    doTrangCho = (async () => {
      const tu = new Date(new Date().setHours(0, 0, 0, 0)).getTime();
      const ds = await baiTrenTrangApi(tu - 6 * 3600e3);
      const homNayDs = ds.filter((p) => p.luc >= tu); const LK = LICH.filter((x) => (x.kenh || 1) === KC);
      try { // (6.25) trang có 2 bài cùng nội dung hôm nay → báo nhóm lỗi NGAY (mỗi cặp 1 lần)
        for (let i = 0; i < homNayDs.length; i++) for (let j = i + 1; j < homNayDs.length; j++) {
          const a = homNayDs[i], b = homNayDs[j]; if (khoaSo(a.text || '').length < 30 || khoaSo(b.text || '').length < 30) continue;
          if (!soChat(a.text, b.text).ok) continue;
          const kt = 'trung_' + [a.id, b.id].sort().join('_').slice(-40);
          const daBao = lay('trung6', []) || []; if (daBao.includes(kt)) continue; luu('trung6', daBao.concat(kt).slice(-30));
          ghi(`⚠️ Trang ${CAI_DAT.KENH[KC].ngan} có 2 bài trùng nội dung: ${gioStr(new Date(a.luc))} và ${gioStr(new Date(b.luc))} — "${chuan(a.text).slice(0, 50)}…"`);
          baoLoi(`🚨 Trang ${CAI_DAT.KENH[KC].ngan} có 2 bài TRÙNG nội dung hôm nay (${gioStr(new Date(a.luc))} và ${gioStr(new Date(b.luc))}): "${chuan(a.text).slice(0, 60)}…" — cần xoá 1 bài${a.link ? ' — ' + a.link : ''}${b.link ? ' · ' + b.link : ''}`, kt);
        }
      } catch (e) { /* */ } // (6.19) chỉ dò các bài của kênh đang xét
      luu(KC === 1 ? 'trang6' : 'trang6_k' + KC, { luc: Date.now(), n: homNayDs.length, moiNhat: Math.max(0, ...ds.map((p) => p.luc || 0)) });
      const d = duLieu(); const ngay = homNay(); let moi = [];
      const dd = lay('dang_do', null);
      capNhatTT((s) => {
        // (6.17) sửa ô đã nhận nhầm: 2 ô cùng 1 link bài → ô "máy khác / có sẵn" là nhận nhầm → trả về chờ để dò lại
        const theoLink = {};
        for (const it of LK) { const r = s.s[it.k]; if (r && XONG.includes(r.tt) && r.link) (theoLink[linkGon(r.link)] = theoLink[linkGon(r.link)] || []).push(it); }
        for (const ds2 of Object.values(theoLink)) {
          if (ds2.length < 2) continue;
          const sai = ds2.filter((it) => ['khac', 'tay'].includes(s.s[it.k].may) || s.s[it.k].tt === 'co_san');
          const bo = sai.length < ds2.length ? sai : sai.slice(1);
          for (const it of bo) { const r = s.s[it.k]; moi.push(`${it.ten}: trước đó nhận nhầm bài của ô khác (cùng link) → dò lại`); s.s[it.k] = { tt: 'cho', lan: r.lan || 0, vong: r.vong || 0, can: r.can, lyDo: '' }; }
        }
        // (6.19.3) bài trước đó chỉ "nhận theo thứ tự" (chữ khác sheet) thì chưa chắc → nếu chữ của nó khớp đúng 1 ô khác, chuyển sang ô đó
        const daDung = new Set(); for (const r of Object.values(s.s)) if (r && r.id && !r.theoThuTu) dungBai(daDung, r);
        for (const it of LK) {
          const r = ttSlot(s, it.k); if (XONG.includes(r.tt) && r.id && !r.theoThuTu) continue;
          const nd = noiDungSlot(ngay, it.k, d); if (!nd.text) continue;
          let p = baiKhop(homNayDs, nd.text, daDung);
          if (p && (it.loai === 'video' || it.loai === 'manifest') && laVideoApi(p) === false) { if (/bấm tay/.test(lyDo)) ghi(`Kiểm tra bài: ${it.ten} khớp chữ với bài lúc ${gioStr(new Date(p.luc))} nhưng Facebook báo bài đó không phải video → chưa tính`); p = null; }
          if (!p && /bấm tay/.test(lyDo) && !XONG.includes(r.tt)) ghi(`Kiểm tra bài: ${it.ten} — chưa thấy bài trùng nội dung trong ${homNayDs.length} bài hôm nay của trang`);
          if (!p) { if (r.tt === 'co_san' && !r.id && !r.link && r.may !== 'tay' && !(r.nguon === 'sheet' && nd.daDang)) { s.s[it.k] = { tt: 'cho', lan: 0, vong: r.vong || 0, can: r.can, lyDo: '' }; moi.push(`${it.ten}: trước đó nhận nhầm là đã có trên trang, kiểm lại thấy chưa có → đưa lại vào hàng chờ`); try { baoLoi(`[fb] ${it.ten}: trước đó nhận nhầm là đã đăng (trang thực tế chưa có) → đã đưa lại vào hàng chờ`, 'nham_' + it.k).catch(() => {}); } catch (e) { /* */ } } continue; } // (6.20.2)
          if (r.theoThuTu && r.id === p.id) { delete r.theoThuTu; dungBai(daDung, p); continue; } // đúng là bài của ô này
          for (const it2 of LK) { const r2 = s.s[it2.k]; if (it2.k !== it.k && r2 && r2.theoThuTu && (r2.id === p.id || (p.link && linkGon(r2.link) === linkGon(p.link)))) { s.s[it2.k] = { tt: 'cho', lan: r2.lan || 0, can: r2.can, lyDo: '' }; moi.push(`${it2.ten}: bài nhận theo thứ tự trước đó thật ra là ${it.ten} → trả ${it2.ten} về chờ`); } }
          if (r.theoThuTu) { s.s[it.k] = { tt: 'cho', lan: r.lan || 0, can: r.can, lyDo: '' }; }
          const rr = ttSlot(s, it.k);
          dungBai(daDung, p);
          { const ng0 = s.ngoai[p.id]; if (ng0) { Object.assign(rr, { kiem: ng0.kiem || rr.kiem, cmtOk: ng0.cmtOk, guiBu: ng0.guiBu, kiem19: ng0.kiem19 }); delete s.ngoai[p.id]; } }
          if (XONG.includes(rr.tt)) { Object.assign(rr, { id: p.id, link: p.link || rr.link }); continue; }
          if (dd && dd.slot === it.k) { Object.assign(rr, { id: p.id, link: p.link }); continue; } // máy này đang làm dở bài đó
          s.s[it.k] = Object.assign(rr, { tt: 'xong', luc: p.luc, id: p.id, link: p.link || '', may: 'khac', kiem: rr.kiem || [], can: rr.can || canCmt(it, nd), lyDo: '', loi: '' });
          moi.push(`${it.ten} (đăng lúc ${gioStr(new Date(p.luc))})`);
        }
        // dự phòng: manifest / video đăng tay mà chữ khác sheet (hoặc sheet thiếu chữ) → gán vào ô còn trống theo thứ tự giờ đăng
        const giu = (p) => Object.values(s.ngoai).some((g) => g.giu && (g.id === p.id || (!g.id && baiGiongNhat([p], g.text))));
        for (const r of Object.values(s.s)) if (r && r.id && r.theoThuTu) dungBai(daDung, r);
        const chuaDung = (p) => !daDung.has(p.id) && !(p.link && daDung.has('L:' + linkGon(p.link)));
        const mmNow = phutTrongNgay(new Date());
        const conMf = homNayDs.filter((p) => chuaDung(p) && !giu(p) && /#manifest/i.test(p.text || '')).sort((a, b) => a.luc - b.luc);
        const conVd = homNayDs.filter((p) => chuaDung(p) && !giu(p) && !/#manifest/i.test(p.text || '') && laVideoApi(p) === true).sort((a, b) => a.luc - b.luc);
        for (const it of (KC === 1 ? LK : [])) { // (6.19.2) kênh 2, 3: chỉ nhận bài khớp chữ (không gán video lạ theo thứ tự)
          if (it.loai !== 'manifest' && it.loai !== 'video') continue;
          const r = ttSlot(s, it.k); if (XONG.includes(r.tt) || r.tt === 'dang' || (dd && dd.slot === it.k)) continue;
          if (!(typeof s.gio[it.k] === 'number' && s.gio[it.k] <= mmNow)) continue; // (6.19.3) chỉ nhận theo thứ tự cho ô ĐÃ tới giờ (bài đăng tay có thể là bài thêm sheet chưa kịp đọc)
          const p = (it.loai === 'manifest' ? conMf : conVd).shift(); if (!p) continue;
          dungBai(daDung, p);
          const ng = s.ngoai[p.id]; if (ng) { Object.assign(r, { kiem: ng.kiem || [], cmtOk: ng.cmtOk, guiBu: ng.guiBu, kiem19: ng.kiem19 }); delete s.ngoai[p.id]; }
          s.s[it.k] = Object.assign(r, { tt: 'xong', luc: p.luc, id: p.id, link: p.link || '', may: 'khac', kiem: r.kiem || [], can: r.can || canCmt(it, noiDungSlot(ngay, it.k, d)), lyDo: '', loi: '', theoThuTu: true });
          moi.push(`${it.ten} (đăng tay lúc ${gioStr(new Date(p.luc))}, nhận theo thứ tự)`);
        }
        if (KC !== 1) return; // bài đăng tay ngoài lịch: chỉ theo dõi ở kênh 1
        for (const kg of Object.keys(s.ngoai)) { const g = s.ngoai[kg]; if (g.giu && !g.id) { const p = homNayDs.find((q) => !daDung.has(q.id) && baiGiongNhat([q], g.text)); if (p) { delete s.ngoai[kg]; s.ngoai[p.id] = Object.assign(g, { id: p.id, link: p.link || g.link, luc: p.luc }); daDung.add(p.id); } } }
        const linkNgoai = new Set(Object.values(s.ngoai).map((g) => linkGon(g.link)).filter(Boolean));
        for (const p of homNayDs) { // video/manifest đăng tay (không thuộc lịch) → cũng cần comment
          if (!chuaDung(p) || s.ngoai[p.id] || (p.link && linkNgoai.has(linkGon(p.link)))) continue;
          if (laVideoApi(p) === true || /#manifest/i.test(p.text || '')) { s.ngoai[p.id] = { luc: p.luc, id: p.id, link: p.link || '', text: String(p.text || '').slice(0, 300), kiem: [], can: canCmt({ loai: 'video' }, {}) }; moi.push('bài đăng tay lúc ' + gioStr(new Date(p.luc))); }
        }
      });
      if (moi.length) ghi('Dò trang' + (lyDo ? ' (' + lyDo + ')' : '') + ': thấy ' + moi.join(', '));
      return ds;
    })();
    try { return await doTrangCho; } catch (e) { { const kt = KC === 1 ? 'trang6' : 'trang6_k' + KC; luu(kt, Object.assign({}, lay(kt, {}) || {}, { luc: Date.now(), loi: e.message })); } ghi('Dò trang qua Facebook lỗi' + (KC > 1 ? ' (kênh ' + KC + ')' : '') + ': ' + e.message); if (/\b190\b/.test(e.message)) maHong(KC); return null; } finally { doTrangCho = null; }
  }
  // Máy Giao thấy bài trong lịch do "máy khác" đăng → xem ô giữ chỗ: nếu Máy Cao đã nhận bài đó thì để Máy Cao lo comment (tránh 2 máy cùng gửi bù)
  async function xacDinhMayKhac() {
    if (!LA_GIAO || chanLark()) return;
    const s = trangThai(); const cac = LICH.filter((it) => { const r = s.s[it.k]; return r && r.may === 'khac' && !r.daXemKhoa; });
    if (!cac.length) return;
    let v = ''; try { v = chuO(await docO(CAI_DAT.TAB_BAI, CAI_DAT.O_KHOA)); } catch (e) { return; }
    capNhatTT((s2) => { for (const it of cac) { const r = s2.s[it.k]; r.daXemKhoa = true; const x = docKhoa(v, it.k); if (x && x.ngay === homNay() && x.slot === it.k && x.may === 'CAO') { r.may = 'CAO'; ghi(`${it.ten} do Máy Cao đăng thay → Máy Cao lo phần comment`); } } });
  }

  // =====================================================================
  //  Ô GIỮ CHỖ (chỉ dùng khi Máy Giao trễ hoặc Máy Cao đăng thay) — 3 lượt gọi Lark
  // =====================================================================
  // (6.28) ô giữ chỗ chứa NHIỀU khoá (mỗi bài 1 khoá, cách nhau " ; ") → 2 máy giữ 2 bài khác nhau cùng lúc không đè mất khoá của nhau
  const dsKhoa = (v) => { const out = []; const re = /KHOA\|(\d{2}-\d{2}-\d{4})\|(\w+)\|(GIAO|CAO)\|(\d+)/g; let m; while ((m = re.exec(String(v || '')))) out.push({ ngay: m[1], slot: m[2], may: m[3], luc: +m[4] }); return out; };
  const docKhoa = (v, slot) => { const ds = dsKhoa(v).filter((x) => !slot || x.slot === slot).sort((a, b) => a.luc - b.luc); return ds.length ? ds[ds.length - 1] : null; };
  async function ghiKhoaO(k, ep) { if (!ep && coKhoaMinh(k)) return; // (6.28.8) khoá của máy này còn hạn → không ghi lại
  {  let cu = ''; try { cu = chuO(await docO(CAI_DAT.TAB_BAI, CAI_DAT.O_KHOA)); } catch (e) { /* */ } const giu = dsKhoa(cu).filter((x) => x.ngay === homNay() && x.slot !== k && Date.now() - x.luc < 3 * 3600e3).slice(-6); giu.push({ ngay: homNay(), slot: k, may: MAY, luc: Date.now() }); await ghiO(CAI_DAT.TAB_BAI, CAI_DAT.O_KHOA, giu.map((x) => `KHOA|${x.ngay}|${x.slot}|${x.may}|${x.luc}`).join(' ; ')); } nhoKhoa(k); }
  // (6.26.4) máy này đã giữ chỗ bài này (đăng trễ) → ngay trước khi bấm Đăng đọc lại ô giữ chỗ: máy kia đã nhận bài (người bấm Đăng tay ở máy kia) thì nhường
  async function kiemCachTruocDang(slot) { // (6.28.2) ngay trước khi bấm Đăng: bài kênh 1 mới nhất trên trang (máy kia vừa đăng trong lúc mình đang soạn) chưa đủ 20 phút → chưa đăng
    if ((kenhCua(slot) || 1) !== 1 || window.__smhEp || !coApiKenh(1)) return;
    let j = null; try { j = await goiFb(`/${idTrangKenh(1)}/posts?fields=id,created_time&limit=3`, tokenTrang(1)); } catch (e) { ghi(`${tenSlot(slot)}: chưa hỏi được Facebook bài mới nhất (${e.message}) → vẫn đăng`); return; }
    const r = (trangThai().s || {})[slot] || {}; const batDau = r.batDau || Date.now() - 30 * 60000;
    const moi = (j.data || []).map((p) => ({ id: p.id, luc: Date.parse(String(p.created_time).replace(/([+-]\d\d)(\d\d)$/, '$1:$2')) })).filter((p) => p.luc && p.luc > batDau - 60000).sort((a, b) => b.luc - a.luc)[0]; // chỉ bài lên SAU lúc mình bắt đầu soạn (bài trước đó đã được kiểm lúc bắt đầu)
    const cachP = Math.min(CAI_DAT.CACH_TRANG_PHUT, cachK1());
    if (moi && Date.now() - moi.luc < cachP * 60000) { const den = moi.luc + cachP * 60000 + 30000; const e = new LoiMem(`trong lúc soạn, trang vừa có bài kênh 1 khác lên lúc ${gioStr(new Date(moi.luc))} (máy kia / đăng tay) — chưa đủ ${cachP} phút`); e.nhuong = true; e.choDen = den; throw e; }
  }
  async function kiemKhoaTruocDang(slot) { // (6.28) mọi lần đăng (kể cả đăng đúng giờ) đều đọc ô giữ chỗ 1 lần ngay trước khi bấm Đăng
    await kiemCachTruocDang(slot);
    if (chanLark()) return; const cuaMinh = window.__smhKhoaSlot === slot;
    { // (6.28.5) bớt lượt Lark: Máy Giao đăng đúng giờ (Máy Cao chỉ đăng thay khi Giao trễ > 25 phút và luôn ghi ô giữ chỗ trước) / vừa giữ chỗ xong < 5 phút → không đọc lại ô Z1
      const g = (trangThai().gio || {})[slot]; const dungGio = LA_GIAO && !window.__smhEp && typeof g === 'number' && Date.now() <= lucPhut(g) + CAI_DAT.GIAO_GIU_CHO_SAU_PHUT * 60000;
      if (dungGio || coKhoaMinh(slot) || (cuaMinh && Date.now() - (window.__smhKhoaLuc || 0) < 5 * 60000)) return; }
    let kx = null; try { kx = docKhoa(chuO(await docO(CAI_DAT.TAB_BAI, CAI_DAT.O_KHOA)), slot); } catch (e) { return; }
    if (kx && kx.ngay === homNay() && kx.slot === slot && kx.may !== MAY && (cuaMinh || Date.now() - kx.luc < CAI_DAT.NHUONG_PHUT * 60000)) { window.__smhKhoaSlot = ''; const e = new LoiMem(`máy ${kx.may === 'CAO' ? 'Cao' : 'Giao'} đã nhận đăng bài này lúc ${gioStr(new Date(kx.luc))} (người bấm Đăng tay)`); e.nhuong = true; throw e; }
  }
  // (6.28.8) NHỚ KHOÁ CỦA CHÍNH MÁY: giữ chỗ được 1 bài thì nhớ 25 phút — thử lại / bấm Soạn / kiểm trước khi Đăng trong 25 phút không gọi Lark lại (24/10: 319 lượt ô Z1 vì mỗi lần thử lại đều giữ chỗ từ đầu)
  const NHO_KHOA_PHUT = 25;
  const khoaMinh = () => { const m = lay('khoa_minh6', null) || {}; return m.ngay === homNay() ? m : { ngay: homNay() }; };
  const coKhoaMinh = (k) => { const t = khoaMinh()[k]; return typeof t === 'number' && Date.now() - t < NHO_KHOA_PHUT * 60000; };
  const nhoKhoa = (k) => { const m = khoaMinh(); m[k] = Date.now(); luu('khoa_minh6', m); window.__smhKhoaSlot = k; window.__smhKhoaLuc = Date.now(); };
  async function giuCho(k, ghiDe = false) {
    if (!ghiDe && coKhoaMinh(k)) { window.__smhKhoaSlot = k; window.__smhKhoaLuc = Date.now(); if (window['__nhoKhoa_' + k] !== khoaMinh()[k]) { window['__nhoKhoa_' + k] = khoaMinh()[k]; ghi(`${tenSlot(k)}: ${TEN_MAY} đã giữ chỗ lúc ${gioStr(new Date(khoaMinh()[k]))} (còn hạn) → dùng lại, không gọi Lark`); } return true; } // (6.26.4) ghiDe = người bấm Đăng dù máy kia đang giữ chỗ
    const doc = async () => { const c = await docO(CAI_DAT.TAB_BAI, CAI_DAT.O_KHOA); const t = chuO(c).trim(); if (t && !/^KHOA\|/.test(t)) throw new LoiMem(`ô ${CAI_DAT.O_KHOA} (tab Bài viết kênh 1) đang có chữ khác — script không dùng ô này để giữ chỗ`); return docKhoa(t, k); };
    const x = await doc();
    if (x && x.ngay === homNay() && x.slot === k && x.may !== MAY && Date.now() - x.luc < CAI_DAT.NHUONG_PHUT * 60000 && ghiDe) ghi(`${tenSlot(k)}: máy ${x.may === 'CAO' ? 'Cao' : 'Giao'} đang giữ chỗ từ ${gioStr(new Date(x.luc))} nhưng người bấm Đăng → ${TEN_MAY} ghi đè ô giữ chỗ và đăng (vẫn kiểm trang trước khi bấm Đăng)`);
    else if (x && x.ngay === homNay() && x.slot === k && x.may !== MAY && Date.now() - x.luc < CAI_DAT.NHUONG_PHUT * 60000) { capNhatTT((s) => { ttSlot(s, k).khoaKhac = { may: x.may, luc: x.luc }; }); ghi(`${tenSlot(k)}: máy ${x.may === 'CAO' ? 'Cao' : 'Giao'} đã giữ chỗ lúc ${gioStr(new Date(x.luc))} → nhường, không đăng`); return false; }
    await ghiKhoaO(k);
    await sleepThat(20000);
    const y = await doc();
    const ok = !!(y && y.ngay === homNay() && y.slot === k && y.may === MAY); // (6.28) khoá riêng từng bài // (6.19.2) máy kia vừa giữ ô của bài KHÁC (vd kênh 2 vs kênh 3) → không phải nhường
    ghi(ok ? `${tenSlot(k)}: đã giữ chỗ (ô ${CAI_DAT.O_KHOA}) → ${TEN_MAY} đăng` : `${tenSlot(k)}: máy kia vừa giữ chỗ cùng lúc → nhường`);
    if (!ok) { const m = khoaMinh(); delete m[k]; luu('khoa_minh6', m); }
    if (ok) { nhoKhoa(k); capNhatTT((s) => { ttSlot(s, k).khoaKhac = null; }); }
    return ok;
  }

  // =====================================================================
  //  ĐẾM NGƯỢC 10 GIÂY trước mỗi việc chạm vào trang (nhấp nháy + Tạm dừng/Tiếp tục + Hoãn 10 phút)
  // =====================================================================
  let demNguoc = null; // { ten, den, dung, dungLuc, hoan }
  function batDemNguoc(ten, giay) { // (6.22) giay: 3 = việc nhanh / bấm tay, mặc định 10 = việc lâu (đăng bài, comment, cảm xúc, gắn thẻ)
    giay = giay || CAI_DAT.DEM_NGUOC_GIAY;
    demNguoc = { ten, giay, den: Date.now() + giay * 1000, dung: false, hoan: false };
    veBang();
    return new Promise((resolve) => {
      const iv = setInterval(() => {
        const d = demNguoc;
        if (!d) { clearInterval(iv); resolve('hoan'); return; }
        if (d.hoan) { clearInterval(iv); demNguoc = null; resolve('hoan'); veBang(); return; }
        if (d.dung) { if (Date.now() - d.dungLuc > 10 * 60000) { d.dung = false; d.den = Date.now() + (d.giay || CAI_DAT.DEM_NGUOC_GIAY) * 1000; ghi('Đếm ngược: tạm dừng quá 10 phút → tự tiếp tục'); } veDemNguoc(); return; }
        if (Date.now() >= d.den) { clearInterval(iv); demNguoc = null; resolve('ok'); veBang(); return; }
        veDemNguoc();
      }, 250);
    });
  }
  // chờ nhân sự dùng xong trang (tối đa 10 phút) — trả về true nếu được làm ngay
  function choNhanSu(khoaCho, ten) { // ten: việc sắp làm (để popup nói rõ "Sắp …")
    const ly = nhanSuDangDung();
    const k = 'cho_ns_' + khoaCho; const tu = window[k] || 0;
    ten = ten || (khoaCho.startsWith('dang') ? 'đăng bài' : 'làm việc trên trang');
    if (!ly) { window[k] = 0; return true; }
    if (Date.now() - (lay('lam_ngay6', 0) || 0) < 60000) { window[k] = 0; luu('lam_ngay6', 0); luu('cho_nguoi', null); ghi(`Bạn bấm "Làm ngay" → ${ten} luôn`); return true; }
    if (!tu) { window[k] = Date.now(); ghi(`Sắp ${ten}, nhưng ${ly} → chờ tối đa ${CAI_DAT.CHO_NGUOI_TOI_DA_PHUT} phút (có đếm ngược 10 giây) — bấm "Làm ngay" trên popup để làm luôn`); }
    luu('cho_nguoi', { ly, luc: window[k], viec: khoaCho, ten });
    if (Date.now() - (window[k] || Date.now()) >= CAI_DAT.CHO_NGUOI_TOI_DA_PHUT * 60000) { window[k] = 0; return true; }
    return false;
  }

  // =====================================================================
  //  ĐĂNG 1 BÀI TRONG LỊCH
  // =====================================================================
  let dangBan = false;
  function tabAnNhac(it) { // (6.22) tab Facebook ẩn lúc đến giờ: không hiện thông báo; chỉ khi trễ quá 1 tiếng mới báo nhóm Lark 1 tin cho bài đó
    if (Date.now() - (it.den || Date.now()) < 120 * 60000) return; // (6.25) trễ quá 2 tiếng mới báo
    baoLoi(`🚨 ${it.ten} trễ quá 2 tiếng vì tab Facebook đang ẩn — mở cửa sổ Facebook để script đăng`, 'tab_an_' + it.k);
  }
  async function vongDang() {
    if (!MAY || tamDung() || !laTabChinh() || dangBan || lay('dang_do', null) || lay('cho_tay6', null)) return false;
    if (lay('nghi_loi6', 0) > Date.now()) return false; // (6.15) Facebook báo lỗi 3 lần liền → nghỉ 10 phút
    let L = tinhLich();
    { // (6.19.3) yêu cầu bấm tay (Soạn / Đăng ngay) quá 15 phút chưa làm được → báo rõ rồi thôi (trước đây hết hạn trong im lặng)
      const het = L.filter((x) => !x.ket && x.r.tt !== 'dang' && (x.r.ep || x.r.soan) && !(x.r.ep && Date.now() - x.r.ep < 15 * 60000));
      if (het.length) { capNhatTT((s) => { for (const x of het) Object.assign(ttSlot(s, x.k), { ep: 0, soan: false }); }); for (const x of het) { ghi(`${x.ten}: yêu cầu ${x.r.soan ? 'Soạn' : 'Đăng ngay'} đã quá 15 phút mà chưa làm được (tab bị ẩn / đang bận / đang chờ) → huỷ yêu cầu, bài theo lịch bình thường`); thongBaoMay(`Chưa ${x.r.soan ? 'soạn' : 'đăng'} được ${x.ten}`, 'Yêu cầu bấm tay đã quá 15 phút nên đã huỷ — bấm lại nếu vẫn cần.'); } L = tinhLich(); }
    }
    // bấm "Đăng ngay" trên popup: bài đó được làm trước (kể cả chưa phải bài kế tiếp)
    const epIt = L.find((x) => !x.ket && x.r.tt !== 'dang' && x.r.ep && Date.now() - x.r.ep < 15 * 60000);
    if (!epIt && (await soanBaiMai())) return true;
    let it = epIt || L.find((x) => x.keTiep); if (!it) return false;
    // (6.10) bài kế tiếp đang chờ thử lại (lỗi) → các bài sau tới giờ vẫn đăng, không đứng chờ bài lỗi
    const sanSang = (x) => !x.ket && x.r.tt !== 'dang' && !(x.r.thuLai && Date.now() < x.r.thuLai) && !(x.r.choDen && Date.now() < x.r.choDen);
    if (!epIt && !sanSang(it) && ((it.r.thuLai && Date.now() < it.r.thuLai) || (it.r.choDen && Date.now() < it.r.choDen))) { // (6.19.3) cả khi bài đang chờ giãn cách / giữ chỗ → bài kênh khác tới giờ vẫn đăng
      const khac = L.find((x) => x.k !== it.k && sanSang(x) && Date.now() >= Math.max(lucPhut(x.gioKH), lucBuKenh(L, x)));
      if (khac) { if (Math.max(it.r.thuLai || 0, it.r.choDen || 0) - Date.now() > 60000 && !window['__vuot_' + khac.k]) { window['__vuot_' + khac.k] = 1; ghi(`${it.ten} đang chờ tới ${gioStr(new Date(Math.max(it.r.thuLai || 0, it.r.choDen || 0)))} → đăng ${khac.ten} trước (không để bài lỗi chặn các bài khác)`); } it = Object.assign({}, khac, { den: Math.max(lucPhut(khac.gioKH), lucBuKenh(L, khac)) }); }
    }
    if (!it.den) it.den = Date.now();
    datKenh(it.kenh); // (6.19) mọi bước sau (tư cách, đúng trang, dò bài qua Facebook) theo kênh của bài này
    const now = Date.now(), ngay = homNay(), mm = phutTrongNgay(new Date());
    const r = it.r; const ep = r.ep && now - r.ep < 15 * 60000;
    // quá giờ chót: các bài còn lại bỏ, ghi vào báo cáo ngày (bài thêm của kênh 1 được tới GIO_CHOT_THEM)
    { const chotCua = (x) => (x.them || x.baiThem ? CAI_DAT.GIO_CHOT_THEM : CAI_DAT.GIO_CHOT);
      const con = L.filter((x) => !x.ket && !(x.r.ep && now - x.r.ep < 15 * 60000) && mm >= docGio(chotCua(x)));
      if (con.length) {
        capNhatTT((s) => { for (const x of con) Object.assign(ttSlot(s, x.k), { tt: 'bo', lyDo: `quá ${chotCua(x)} chưa đăng được${x.r.loi ? ' (' + x.r.loi + ')' : ''}` }); });
        const gio = [...new Set(con.map(chotCua))].join(' / ');
        ghi(`Quá ${gio}: bỏ ${con.map((x) => x.ten).join(', ')} — ghi vào báo cáo ngày`);
        if (LA_GIAO || (L.some((x) => x.r.may === MAY) && caoNenBao(L))) { // (6.25) 1 tin tổng kết vào nhóm lỗi TRƯỚC báo cáo Marketing: mọi bài chưa lên trang + lý do
          const L2 = tinhLich(); const lan2 = !gio.includes(CAI_DAT.GIO_CHOT); const thieu = L2.filter((x) => !x.xong && (gio.includes(chotCua(x)) || (!lan2 && x.ket)));
          await baoLoi(tinTongKet(`Tổng kết ${gio}`, thieu.length ? thieu : con), 'tongtoi_' + gio);
        }
        return true;
      }
    }
    if (!tuDong() && !ep) return false;
    if (!ep && r.thuLai && now < r.thuLai) return false;
    if (!ep && r.choDen && now < r.choDen) return false;
    // giờ bắt đầu theo vai trò của máy
    let batDau = it.den;
    if (LA_CAO && !ep) batDau = Math.max(it.den + CAI_DAT.CAO_TRE_PHUT * 60000, moLuc + CAI_DAT.CAO_CHO_MO_PHUT * 60000);
    if (!ep && now < batDau) return false;
    { const kt = kenhCuaDuong(); if (!ep && kt && kt !== (it.kenh || 1) && coSuaKenhCho(kt)) return false; }
    if (document.visibilityState !== 'visible') { if (!ep) tabAnNhac(it); return false; } // (6.19.3) việc bấm tay thì không báo nhóm "đến giờ mà tab ẩn"
    if (!ep && dangHoan()) return false;
    if (!ep && !choNhanSu('dang_' + it.k, `đăng ${it.ten} (hẹn ${gioStr(new Date(it.den))})`)) return false;
    // nội dung trong sheet
    let nd = noiDungSlot(ngay, it.k);
    if (nd.thieu.length) {
      const d0 = duLieu();
      if (!chanDocLark() && (!d0 || !d0.ngay || !d0.ngay[ngay] || now - (d0.luc || 0) > 30 * 60000) && now - (r.docLai || 0) > 30 * 60000) {
        capNhatTT((s) => { ttSlot(s, it.k).docLai = now; });
        ghi(`${it.ten}: thiếu ${nd.thieu.join(', ')} → đọc lại sheet 1 lần xem đã bổ sung chưa`);
        try { await docDuLieu('thieu'); } catch (e) { ghi('Đọc lại sheet lỗi: ' + e.message); }
        nd = noiDungSlot(ngay, it.k);
      }
      if (nd.thieu.length) {
        capNhatTT((s) => { Object.assign(ttSlot(s, it.k), { tt: 'thieu', lyDo: 'thiếu ' + nd.thieu.join(', ') }); });
        ghi(`Bỏ qua ${it.ten}: thiếu ${nd.thieu.join(', ')}`);
        if (LA_GIAO) await baoLoi(`${it.ten} hôm nay chưa đăng được vì sheet thiếu ${nd.thieu.join(', ')} — đã bỏ qua, đăng bài kế tiếp`, 'thieu_' + it.k);
        return true;
      }
    }
    if (it.loai === 'video' && nd.daDang) { capNhatTT((s) => { Object.assign(ttSlot(s, it.k), { tt: 'co_san', luc: Date.now(), may: 'khac', link: /^https?:/.test(nd.link || '') ? nd.link : '', lyDo: 'sheet ghi ĐÃ ĐĂNG' + (nd.hang ? ' (hàng ' + nd.hang + ')' : ''), nguon: 'sheet' }); }); ghi(`${it.ten}: sheet đã ghi "ĐÃ ĐĂNG"${nd.hang ? ' (hàng ' + nd.hang + ')' : ''} → không đăng lại (nếu thật ra chưa đăng: xoá chữ ĐÃ ĐĂNG ở cột J rồi bấm Đọc lại sheet)`); if (coApi()) await doTrang('lấy mã bài ' + it.ten); return true; } // (6.19.2)
    // trang đã có bài này chưa (máy kia / đăng tay) + giãn cách với bài gần nhất trên trang
    let daDoApi = false;
    if (coApi()) {
      const ds = await doTrang('trước khi đăng ' + it.ten);
      const r2 = trangThai().s[it.k] || {};
      if (XONG.includes(r2.tt)) { ghi(`${it.ten} đã có trên trang (${r2.may === 'khac' ? 'máy khác/đăng tay' : 'đã ghi nhận'}) → không đăng`); return true; }
      if (ds) daDoApi = true; else ghi(`${it.ten}: chưa hỏi được Facebook (mã khoá lỗi) → nhìn trang để tránh đăng trùng`);
      if (ds && !ep) {
        const moiNhat = Math.max(0, ...ds.map((p) => p.luc || 0));
        const cachTrang = (it.kenh || 1) > 1 ? CAI_DAT.KENH_CACH_PHUT : Math.min(CAI_DAT.CACH_TRANG_PHUT, cachK1()); // (6.28.3) sát giờ còn nhiều bài → 15 phút
        if (moiNhat && now - moiNhat < cachTrang * 60000) {
          const den = moiNhat + cachTrang * 60000 + 30000;
          capNhatTT((s) => { ttSlot(s, it.k).choDen = den; });
          ghi(`${it.ten}: bài gần nhất trên trang mới ${Math.round((now - moiNhat) / 60000)} phút → chờ đến ${gioStr(new Date(den))}`);
          return false;
        }
      }
    }
    // (6.19.2) không hỏi được Facebook (chưa có mã / mã lỗi), hoặc video kênh 2, 3 đã trễ quá 1 giờ (dễ đã có người đăng tay) → nhìn trang trước khi đăng
    // (6.26.5) hỏi được Facebook (mã khoá) thì chỉ dựa vào đó, KHÔNG lướt trang; không hỏi được → tải lại trang (F5) cho mới rồi mới nhìn trang
    if (!daDoApi && !window['__nhin_' + it.k]) {
      if (!dungTrang()) { ghi(`${it.ten}: không hỏi được Facebook → mở trang ${CAI_DAT.TEN_NGAN} để xem bài đã lên chưa (tránh đăng trùng)`); veTrang(); return true; }
      if (performance.now() > 90000 && lay('f5_kiem6', '') !== homNay() + '|' + it.k) { luu('f5_kiem6', homNay() + '|' + it.k); ghi(`${it.ten}: không hỏi được Facebook → tải lại trang ${CAI_DAT.TEN_NGAN} (F5) cho mới rồi mới kiểm bài đã có chưa`); roiTrang(CAI_DAT.URL_TRANG); return true; }
      const co = await daCoTrenTrangDom(nd.text, it.k); window['__nhin_' + it.k] = 1;
      if (co) { capNhatTT((s) => { Object.assign(ttSlot(s, it.k), { tt: 'co_san', luc: Date.now(), may: 'khac', link: co.link || '', lyDo: '' }); }); ghi(`${it.ten} đã có trên trang ${CAI_DAT.TEN_NGAN} (máy khác / đăng tay) → không đăng`); return true; }
      ghi(`${it.ten}: đã xem trang ${CAI_DAT.TEN_NGAN} — chưa có bài này → đăng`);
    }
    // (6.19.3) Máy Giao đăng đúng giờ: vẫn liếc ô giữ chỗ (1 lượt đọc Lark) — Máy Cao đang làm bài này thì nhường
    // (6.25) bỏ bước liếc ô Z1 khi Máy Giao đăng đúng giờ: Máy Cao chỉ đăng thay khi trễ > 25 phút và 2 máy cùng lịch → không thể trùng (tiết kiệm ~12–15 lượt Lark/ngày)
    if (false && LA_GIAO && !ep && !(now > it.den + CAI_DAT.GIAO_GIU_CHO_SAU_PHUT * 60000) && !chanLark()) {
      try { const x = docKhoa(chuO(await docO(CAI_DAT.TAB_BAI, CAI_DAT.O_KHOA)), it.k); if (x && x.ngay === homNay() && x.slot === it.k && x.may === 'CAO' && now - x.luc < CAI_DAT.NHUONG_PHUT * 60000) { ghi(`${it.ten}: Máy Cao đã giữ chỗ lúc ${gioStr(new Date(x.luc))} → Máy Giao nhường (chờ xem bài lên)`); capNhatTT((s) => { ttSlot(s, it.k).choDen = Date.now() + 10 * 60000; }); return false; } } catch (e) { /* đọc không được thì vẫn đăng (đã kiểm trang) */ }
    }
    // 2 máy cùng bật: Máy Cao (dự phòng) hoặc Máy Giao trễ quá 15 phút phải giữ chỗ trước
    if ((LA_CAO || now > it.den + CAI_DAT.GIAO_GIU_CHO_SAU_PHUT * 60000) && chanLark()) ghi(`${it.ten}: Lark đang tạm ngừng nên không giữ chỗ được → ${TEN_MAY} vẫn đăng (đã kiểm trang chưa có bài)`); // (6.19.3) Lark hết hạn mức không làm Máy Cao đứng im
    if (LA_CAO && !ep && !chanDocLark() && Date.now() - ((duLieu() || {}).luc || 0) > 20 * 60000 && it.r.caoDoc !== it.den) { // (6.25) Máy Cao chỉ đọc sheet 16:00 → trước khi đăng thay đọc lại 1 lần cho đúng nội dung mới nhất
      capNhatTT((s) => { ttSlot(s, it.k).caoDoc = it.den; });
      try { await docDuLieu('thay'); ghi(`${it.ten}: Máy Cao đọc lại sheet 1 lần trước khi đăng thay`); } catch (e) { ghi(`${it.ten}: Máy Cao chưa đọc lại được sheet (${e.message}) → đăng bằng dữ liệu 16:00`); }
      return true;
    }
    else if (!chanLark() && (LA_CAO || now > it.den + CAI_DAT.GIAO_GIU_CHO_SAU_PHUT * 60000)) {
      try {
        if (!(await giuCho(it.k, !!(it.r.ghiDe && Date.now() - it.r.ghiDe < 30 * 60000)))) { capNhatTT((s) => { ttSlot(s, it.k).choDen = Date.now() + 5 * 60000; }); return false; }
      } catch (e) { ghi(`${it.ten}: chưa giữ chỗ được (${e.message}) → ${LA_CAO && !e.tranCung ? 'Máy Cao không đăng để tránh trùng' : 'vẫn đăng (đã kiểm trang chưa có bài)'}`); if (LA_CAO && !e.tranCung) { capNhatTT((s) => { ttSlot(s, it.k).choDen = Date.now() + 10 * 60000; }); return false; } }
      if (LA_CAO && !ep) await baoLoi(`Máy Giao chưa đăng ${it.ten} (quá ${Math.round((now - it.den) / 60000)} phút so với giờ hẹn ${gioStr(new Date(it.den))}) → Máy Cao đăng thay`, 'thay_' + it.k);
    }
    // đếm ngược 10 giây (bấm "Đăng ngay" trên popup thì không cần)
    { const kq = await batDemNguoc('đăng ' + it.ten, ep ? 3 : 10); if (kq !== 'ok') { ghi(`Hoãn ${it.ten}`); return false; } } // (6.22) bấm tay cũng đếm ngược 3 giây
    if (tamDung() || lay('dang_do', null) || !laTabChinh()) return false;
    if (ep) { const sn = await sanSangTrang((r.soan ? 'soạn ' : 'đăng ngay ') + it.ten); if (sn !== true) { if (sn) { capNhatTT((s) => { const x = ttSlot(s, it.k); x.ep = 0; x.soan = false; }); ghi(`${it.ten}: chưa làm được việc bấm tay — ${sn}`); } return true; } } // (6.19.3)
    window.__smhEp = !!ep; // (6.28.2) bấm Đăng ngay thì không chờ giãn cách
    const soan = chayThu() || !!(ep && r.soan); // bấm "Soạn": làm hết mọi thứ, dừng trước nút Đăng
    dangBan = true; giuKhoa();
    window.__smhLan = (r.lan || 0) + ((r.vong || 1) - 1) * CAI_DAT.SO_LAN_THU; window.__smhBoQua = []; window.__smhHuyLuot = 0; window.__smhTreoLuc = 0; // lần thử thứ mấy (để bật chế độ bỏ bước phụ khi thử lại)
    if (window.__smhLan) ghi(`${it.ten}: lần thử ${window.__smhLan + 1} — bước phụ nào lỗi sẽ bỏ qua để bài vẫn lên`);
    capNhatTT((s) => { const x = ttSlot(s, it.k); x.tt = 'dang'; x.batDau = Date.now(); x.may = MAY; if (!soan || !ep) { x.ep = 0; x.soan = false; } }); // (6.19.3) bấm Soạn: giữ yêu cầu tới khi soạn xong (trang tải lại giữa chừng vẫn là SOẠN, không thành đăng thật)
    try { await dangSlot(it, nd, soan); }
    catch (e) { await xuLyLoiDang(it, e); }
    finally { dangBan = false; giuKhoa(); veBang(); }
    return true;
  }

  // bấm "Soạn" ở tab Ngày mai: soạn thử bài của ngày mai NGAY HÔM NAY (làm hết, dừng trước nút Đăng) — để kiểm tra trước, không đăng
  // (6.19.3) việc bấm tay (Soạn / Đăng ngay): mở đúng trang + đúng tư cách TRƯỚC khi xoá yêu cầu, để tải lại trang xong vẫn làm tiếp
  // true = sẵn sàng · false = đang mở trang / chuyển tư cách (làm tiếp sau khi trang tải lại) · chuỗi = lỗi, thôi
  async function sanSangTrang(viec) {
    if (!dungTrang()) { ghi(`${viec}: mở trang ${CAI_DAT.TEN_NGAN} trước`); veTrang(); return false; }
    try { if (!(await damBaoTuCach())) { ghi(`${viec}: đang chuyển sang tư cách "${CAI_DAT.TEN_TRANG}" — trang tải lại xong sẽ làm tiếp`); return false; } }
    catch (e) { return e.message; }
    return true;
  }
  async function soanBaiMai() {
    const nm = ngayMai(); const sM = lay('ngay6_' + nm, null); if (!sM || !sM.s) return false;
    { const het = Object.keys(sM.s).filter((x) => sM.s[x].soan && !(sM.s[x].ep && Date.now() - sM.s[x].ep < 15 * 60000) && !XONG.includes(sM.s[x].tt));
      if (het.length) { capNhatTT((s) => { for (const x of het) Object.assign(ttSlot(s, x), { ep: 0, soan: false }); }, nm); for (const x of het) { ghi(`Soạn thử ${tenSlot(x)} ngày mai: quá 15 phút chưa làm được → huỷ yêu cầu`); thongBaoMay(`Chưa soạn thử được ${tenSlot(x)} ngày mai`, 'Yêu cầu đã quá 15 phút nên đã huỷ — bấm Soạn lại nếu vẫn cần.'); } } }
    const k = Object.keys(sM.s).find((x) => sM.s[x].ep && Date.now() - sM.s[x].ep < 15 * 60000 && sM.s[x].soan && !XONG.includes(sM.s[x].tt));
    if (!k) return false;
    const it = lichNgay(nm).find((x) => x.k === k); if (!it) return false;
    if (document.visibilityState !== 'visible') return false;
    datKenh(it.kenh);
    { const sn = await sanSangTrang(`soạn thử ${it.ten} ngày mai`); if (sn !== true) { if (sn) { capNhatTT((s) => { const x = ttSlot(s, k); x.ep = 0; x.soan = false; }, nm); ghi(`Soạn thử ${it.ten} ngày mai chưa được: ${sn}`); thongBaoMay(`Soạn thử ${it.ten} ngày mai chưa được`, sn); } return true; } } // (6.19.3) đổi trang / tư cách trước, yêu cầu soạn vẫn giữ qua lần tải lại trang
    capNhatTT((s) => { const x = ttSlot(s, k); x.soanThu = Date.now(); }, nm); // (6.19.3) giữ yêu cầu tới khi soạn xong
    const nd = noiDungSlot(nm, k);
    if (nd.thieu.length) { capNhatTT((s) => { const x = ttSlot(s, k); x.ep = 0; x.soan = false; }, nm); ghi(`Soạn thử ${it.ten} ngày mai: sheet còn thiếu ${nd.thieu.join(', ')} → chưa soạn được`); thongBaoMay(`Chưa soạn được ${it.ten} ngày mai`, 'Sheet còn thiếu ' + nd.thieu.join(', ')); return true; }
    dangBan = true; giuKhoa(); veBang();
    try { await dangSlot(it, nd, true, nm); }
    catch (e) {
      if (e instanceof LoiDung) { ghi(`Soạn thử ${it.ten} ngày mai: ${e.message} — sẽ soạn tiếp`); } // tab ẩn / đang đổi tư cách: giữ yêu cầu, lượt sau làm tiếp
      else { capNhatTT((s) => { const x = ttSlot(s, k); x.ep = 0; x.soan = false; }, nm); ghi(`Soạn thử ${it.ten} ngày mai lỗi: ${e.message}`); chupLoi(it.ten); try { await dongHopSoan(); } catch (e2) { /* */ } thongBaoMay(`Soạn thử ${it.ten} ngày mai chưa được`, e.message); }
    }
    finally { dangBan = false; giuKhoa(); veBang(); }
    return true;
  }
  // (6.10) bài bị bỏ vì sheet thiếu nội dung: đọc sheet thấy đã bổ sung → tự đưa lại hàng chờ (đăng bù, cách bài trước 30 phút)
  function thuLaiBaiThieu(d) {
    const ngay = homNay(); const s0 = trangThai(); const dua = [];
    for (const it of LICH) { const r = s0.s[it.k]; if (r && r.tt === 'thieu' && !noiDungSlot(ngay, it.k, d).thieu.length) dua.push(it); }
    if (!dua.length) return;
    capNhatTT((s) => { for (const it of dua) Object.assign(ttSlot(s, it.k), { tt: 'cho', lyDo: '', loi: '', lan: 0, thuLai: 0, docLai: 0 }); });
    ghi(`Sheet đã bổ sung nội dung cho ${dua.map((x) => x.ten).join(', ')} → đưa lại hàng chờ để đăng bù`);
  }
  // (6.10) thả cảm xúc cho thước phim (trang /reel/…): nút Thích nằm ở cột nút bên phải, không nằm trong khung bài như bài thường
  async function thaCamXucReel(text) {
    if (!CAI_DAT.THA_CAM_XUC) return { tt: 'tat' };
    try {
      kiemDung();
      if (!/^\/reel\//.test(location.pathname) && timBai(text)) return await thaCamXucBai(text);
      const timNut = (n) => [...document.querySelectorAll('[role="button"],button')].find((b) => {
        if (!dangHien(b) || b.closest('[role="article"]') || b.closest('#smhfb,#smhfb-soan-w,#smhfb-nho')) return false;
        const l = b.getAttribute('aria-label') || ''; return n instanceof RegExp ? n.test(l) : l === n; });
      await thaCamXuc(timNut, 'Cảm xúc cho thước phim', null);
      return { tt: 'ok' };
    } catch (e) { ghi('Chưa thả được cảm xúc cho thước phim: ' + e.message); return { tt: 'chua', loi: e.message }; }
  }
  // ---- (6.11) sau khi đăng video / manifest: gắn thẻ Trang "Sơn Mộc Hương" + cảm xúc (màn Chỉnh sửa thước phim) ----
  // chạy khi bài đã lên + comment xong; mỗi bài thử tối đa 4 lần (cách nhau 5–10 phút), có kiểm lại trên trang sau khi Lưu
  async function vongSuaVideo() {
    if (!CAI_DAT.SUA_VIDEO_SAU_DANG || !MAY || tamDung() || !laTabChinh() || dangBan || lay('dang_do', null) || lay('cho_tay6', null)) return false;
    const kt = kenhCuaDuong(); // (6.19) chỉ sửa bài của trang ĐANG MỞ (không chuyển trang chỉ để thả cảm xúc)
    if (document.visibilityState !== 'visible' || !kt || dangODuongSua()) return false;
    const mm = phutTrongNgay(new Date()); if (mm >= docGio(CAI_DAT.GIO_CHOT) + 120) return false; // (6.24.3) thử gắn thẻ + cảm xúc tới 23:30
    const s = trangThai(); const now = Date.now();
    { // video kênh 2, 3 đã rời trang của nó quá 12 phút mà chưa thả được cảm xúc → thôi (không quan trọng, không chuyển trang lại)
      const bo = LICH.filter((x) => x.kenh > 1 && x.kenh !== kt && (() => { const r = s.s[x.k]; return r && XONG.includes(r.tt) && r.link && !r.suaXong && now - (r.luc || 0) > (CAI_DAT.KENH[x.kenh].ganThe ? 40 : 12) * 60000; })()); // (6.26) kênh Hà Xá (gắn thẻ) chờ 40 phút
      if (bo.length) { capNhatTT((s1) => { for (const x of bo) Object.assign(ttSlot(s1, x.k), { suaXong: Date.now(), suaLoi: (s1.s[x.k].suaLoi ? s1.s[x.k].suaLoi + ' · ' : '') + 'bỏ qua cảm xúc (đã chuyển sang trang khác)' }); }); ghi(`${bo.map((x) => x.ten).join(', ')}: chưa thả được cảm xúc nhưng đã chuyển trang → bỏ qua (cảm xúc không bắt buộc)`); }
    }
    const it = LICH.find((x) => { const r = s.s[x.k]; const toiDa = (x.kenh || 1) > 1 && !CAI_DAT.KENH[x.kenh].ganThe ? CAI_DAT.KENH_SUA_TOI_DA : 4; return (x.kenh || 1) === kt && (x.loai === 'video' || x.loai === 'manifest') && r && XONG.includes(r.tt) && (r.may === MAY || ((r.may === 'tay' || r.may === 'khac') && (LA_GIAO || now - (r.luc || 0) > 30 * 60000))) && r.link && !r.suaXong && (r.suaLan || 0) < toiDa && now - (r.luc || 0) > 3 * 60000 && now >= (r.suaHen || 0); });
    if (!it) return false;
    datKenh(it.kenh);
    const laKenhPhu = (it.kenh || 1) > 1 && !CAI_DAT.KENH[it.kenh].ganThe; const toiDaSua = laKenhPhu ? CAI_DAT.KENH_SUA_TOI_DA : 4; // kênh 2, 3: chỉ thả cảm xúc (không gắn thẻ), lỗi thử thêm 1 lần rồi thôi
    if (!choNhanSu('suavideo_' + it.k, laKenhPhu ? `thả cảm xúc cho ${it.ten}` : `kiểm tra / gắn thẻ ${CAI_DAT.TAG_TEN} + cảm xúc cho ${it.ten}`)) return false;
    { const kq0 = await batDemNguoc(laKenhPhu ? `thả cảm xúc cho ${it.ten}` : `gắn thẻ + cảm xúc cho ${it.ten}`, 10); if (kq0 !== 'ok') return false; } // (6.22)
    const r = s.s[it.k]; const text = noiDungSlot(homNay(), it.k).text || '';
    const ghiSua = (o) => capNhatTT((s1) => Object.assign(ttSlot(s1, it.k), o));
    const p = { link: r.link, text, luc: r.luc };
    const timK = () => cacKhungBai().find((k) => khungKhopP(k, p));
    dangBan = true; giuKhoa(); bamNutLuc = Date.now(); // hiện thông báo ngay từ bước tìm bài
    try {
      await theoDoi('suavideo', async () => {
        ghi(`Kiểm tra thẻ ${CAI_DAT.TAG_TEN} + cảm xúc của ${it.ten}: tìm bài trên trang…`);
        let k = timK();
        for (let i = 0; i < 10 && !k; i++) { window.scrollBy(0, 1000); await sleep(1500); k = timK(); if (!k) ghi(`${it.ten}: chưa thấy bài, cuộn tìm tiếp (${i + 1}/10)…`); }
        if (!k) { window.scrollTo(0, 0); ghiSua({ suaLan: (r.suaLan || 0) + 1, suaHen: now + (laKenhPhu ? 3 : 10) * 60000, suaLoi: 'chưa thấy bài trên trang' }); ghi(`${laKenhPhu ? 'Thả cảm xúc' : 'Gắn thẻ + cảm xúc'} ${it.ten}: chưa thấy bài trên trang (lần ${(r.suaLan || 0) + 1}/${toiDaSua}) → ${(r.suaLan || 0) + 1 >= toiDaSua ? 'thôi' : 'thử lại sau'}`); return; }
        const dg = baiDaGan(k);
        if (dg.du || (laKenhPhu && dg.cx)) { ghiSua({ suaXong: Date.now(), suaLoi: '' }); ghi(`${it.ten}: đã có ${laKenhPhu ? 'cảm xúc' : 'thẻ ' + CAI_DAT.TAG_TEN + ' + cảm xúc'} trên bài → không cần sửa`); return; }
        if ((r.suaLan || 0) >= 1 && r.suaDaLuu) ghi(`${it.ten}: lần trước đã Lưu nhưng trên bài chưa hiện đủ thẻ/cảm xúc → làm lại`);
        ghi(`Bắt đầu gắn thẻ "${CAI_DAT.TAG_TEN}" + cảm xúc cho ${it.ten}`);
        const d = await moManHinhSua(k, text);
        let daLuu = false;
        try {
          if (laHopMoi(d)) { // (6.24) trang mới: hộp "Chỉnh sửa bài viết" (Tiếp → Lưu)
            const kq = await suaVideoMoi(laKenhPhu);
            if (kq.khongCan) { ghiSua({ suaXong: Date.now(), suaLoi: '' }); ghi(`${it.ten}: hộp sửa đã có đủ ${laKenhPhu ? 'cảm xúc' : 'thẻ + cảm xúc'} → đóng, không cần lưu`); return; }
            daLuu = kq.daLuu;
            await sleep(2500);
            const k2 = timK(); const ok = k2 && (laKenhPhu ? baiDaGan(k2).cx : baiDaGan(k2).du);
            ghiSua({ suaDaLuu: Date.now(), suaLan: (r.suaLan || 0) + 1, suaHen: Date.now() + 5 * 60000, suaXong: ok ? Date.now() : 0, suaLoi: '' });
            ghi(`${it.ten}: đã lưu ${kq.the && !laKenhPhu ? 'thẻ "' + CAI_DAT.TAG_TEN + '"' : ''}${kq.nhan ? ' + cảm xúc "' + kq.nhan + '"' : ''} (hộp mới)${ok ? ' — trên bài đã hiện đủ' : ' — sẽ kiểm lại trên bài sau 5 phút'}`);
            return;
          }
          if (!/^Chỉnh sửa thước phim/.test(chuan(d.innerText))) { ghiSua({ suaXong: Date.now(), suaLoi: 'không phải thước phim' }); ghi(`${it.ten}: màn sửa không phải thước phim → bỏ qua`); return; }
          const c = chipsSua(d); const canThe = !laKenhPhu && !daGanThe(c), canCx = chuaCamXuc(c);
          if (!canThe && !canCx) { ghiSua({ suaXong: Date.now(), suaLoi: '' }); ghi(`${it.ten}: màn sửa đã có đủ ${laKenhPhu ? 'cảm xúc' : 'thẻ + cảm xúc'} → đóng, không cần lưu`); return; } // (6.26)
          let nhan = '';
          if (canThe) { try { await ganTheSua(); } catch (e) { if (e instanceof LoiDung) throw e; ghi(`${it.ten}: gắn thẻ chưa được (${e.message}) → vẫn gắn cảm xúc, lần sau thử thẻ lại`); } }
          if (canCx) {
            try { nhan = await camXucSua(0); }
            catch (e1) { if (e1 instanceof LoiDung || !hopSua()) throw e1; ghi('Cảm xúc lần 1 chưa xác nhận (' + e1.message + ') → thử lại lần 2'); dongBangCamXuc(); await sleep(1500); try { nhan = await camXucSua(1); } catch (e2) { if (e2 instanceof LoiDung) throw e2; ghi(`${it.ten}: cảm xúc chưa được (${e2.message})`); } }
          }
          const c2 = chipsSua(hopSua() || d);
          if ((canThe || canCx) && !(canThe && daGanThe(c2)) && !nhan) throw new Error('chưa gắn được thẻ lẫn cảm xúc');
          const nutLuu = await cho(() => { const n = nutTheoChu(hopSua() || d, 'Lưu'); return n && n.getAttribute('aria-disabled') !== 'true' ? n : null; }, 8000, 400);
          if (!nutLuu) throw new Error('nút "Lưu" không bấm được');
          nutLuu.click();
          let dong = await cho(() => !hopSua(), 12000, 500);
          if (!dong) { const n2 = nutTheoChu(hopSua() || d, 'Lưu'); if (n2) { ghi('Bấm Lưu lần 1 chưa ăn → bấm lại'); try { ganBam(n2); } catch (e) { n2.click(); } } dong = await cho(() => !hopSua(), 20000, 500); }
          if (!dong) throw new Error('đã bấm Lưu nhưng màn hình chỉnh sửa không đóng');
          daLuu = true;
          await cho(() => !dangODuongSua(), 10000); await sleep(2500);
          const k2 = timK(); const ok = k2 && (laKenhPhu ? baiDaGan(k2).cx : baiDaGan(k2).du);
          ghiSua({ suaDaLuu: Date.now(), suaLan: (r.suaLan || 0) + 1, suaHen: Date.now() + 5 * 60000, suaXong: ok ? Date.now() : 0, suaLoi: '' });
          ghi(`${it.ten}: đã lưu ${daGanThe(c2) ? 'thẻ "' + CAI_DAT.TAG_TEN + '"' : ''}${nhan ? ' + cảm xúc "' + nhan + '"' : ''}${ok ? ' — trên bài đã hiện đủ' : ' — sẽ kiểm lại trên bài sau 5 phút'}`);
        } finally { if (!daLuu) await dongManHinhSua(); }
      }, 'Đang kiểm tra / gắn thẻ + cảm xúc cho ' + it.ten);
    } catch (e) {
      const lan = (r.suaLan || 0) + 1;
      ghiSua({ suaLan: lan, suaHen: Date.now() + (laKenhPhu ? 1 : lan >= 2 ? 10 : 5) * 60000, suaLoi: e.message });
      ghi(`${laKenhPhu ? 'Thả cảm xúc' : 'Gắn thẻ + cảm xúc'} ${it.ten} lỗi (lần ${lan}/${toiDaSua}): ${e.message}${lan >= toiDaSua ? (laKenhPhu ? ' — thôi (cảm xúc không bắt buộc)' : ' — dừng, ghi vào báo cáo') : ' → thử lại sau'}`);
      if (lan >= 4 && !laKenhPhu) ghi(`⚠️ ${it.ten}: chưa gắn được thẻ ${CAI_DAT.TAG_TEN} + cảm xúc sau 4 lần (${e.message}) — cần gắn tay${r.link ? ' — ' + r.link : ''} (không báo Lark)`); // (6.24.3) chỉ ghi nhật ký + Báo lỗi
    } finally { dangBan = false; giuKhoa(); veBang(); }
    return true;
  }
  async function xuLyLoiDang(it, e) {
    const dd0 = lay('dang_do', null);
    if (e instanceof LoiTrung) { await dongHopSoan(); capNhatTT((s) => { Object.assign(ttSlot(s, it.k), { tt: 'co_san', luc: (e.p && e.p.luc) || Date.now(), id: (e.p && e.p.id) || '', link: (e.p && e.p.link) || '', may: 'khac' }); }); ghi(`${it.ten} đã có trên trang (phát hiện ngay trước khi bấm Đăng) → không đăng`); return; }
    if (dd0) { ghi(`${it.ten}: đã bấm Đăng — giữ việc dở để xác minh (${e.message})`); if (e instanceof LoiCung && !dd0.video) { dd0.buoc = 'kiem_bai'; dd0.luc = Date.now(); luu('dang_do', dd0); { const u0 = CAI_DAT.URL_TRANG; setTimeout(() => roiTrang(u0), 1500); } } return; }
    if (e && e.nhuong) { await dongHopSoan().catch(() => {}); try { await dongHopVideo(); } catch (e3) { /* */ } capNhatTT((s) => { const x = ttSlot(s, it.k); if (x.tt === 'dang') x.tt = 'cho'; x.choDen = e.choDen || Date.now() + 15 * 60000; }); ghi(`${it.ten}: ${e.message} → không bấm Đăng; ${e.choDen ? 'đóng hộp, chờ tới ' + gioStr(new Date(e.choDen)) + ' rồi đăng lại' : '15 phút sau kiểm lại trang (máy kia đăng xong thì thôi)'}`); return; } // (6.26.4) (6.28.2) choDen = chờ đủ 20 phút sau bài vừa lên
    if (e instanceof LoiDung) { await dongHopSoan().catch(() => {}); capNhatTT((s) => { const x = ttSlot(s, it.k); if (x.tt === 'dang') x.tt = 'cho'; x.thuLai = Date.now() + 60000; }); ghi(`Hoãn đăng ${it.ten}: ${e.message}`); return; }
    if (e instanceof LoiLark) { capNhatTT((s) => { const x = ttSlot(s, it.k); x.tt = 'cho'; x.thuLai = Date.now() + 15 * 60000; x.loi = e.message; }); ghi(`${it.ten}: ${e.message} — thử lại sau 15 phút`); await baoLoi(`Chưa đăng được ${it.ten}: ${e.message}`, 'lark_' + it.k); return; }
    if (!e.daChup) tuChupHienTruong(`Lỗi khi đăng ${it.ten}: ${e.message}`);
    ghi(`Lỗi khi đăng ${it.ten}: ${e.message}`); chupLoi(it.ten);
    let dong = true; try { dong = await dongHopSoan(); if (dangODuongSua()) await dongManHinhSua(); } catch (e2) { /* */ }
    let vongMoi = false;
    const chot = lucPhut(docGio(CAI_DAT.GIO_CHOT));
    const s = capNhatTT((s1) => {
      const x = ttSlot(s1, it.k); x.lan = (x.lan || 0) + 1; x.loi = e.message; x.vong = x.vong || 1; x.thuLai = Date.now() + CAI_DAT.THU_LAI_PHUT * 60000; x.tt = 'cho';
      if (x.lan >= CAI_DAT.SO_LAN_THU) {
        const hen = Date.now() + CAI_DAT.NGHI_GIUA_VONG_PHUT * 60000;
        if (x.vong < CAI_DAT.SO_VONG_THU && hen < chot - 10 * 60000) { x.vong++; x.lan = 0; x.thuLai = hen; vongMoi = true; } else x.tt = 'loi';
      }
    });
    const x = s.s[it.k]; const lanTong = (x.vong - 1) * CAI_DAT.SO_LAN_THU + x.lan;
    if (x.tt === 'loi') await baoLoi(`❌ Không đăng được ${it.ten} sau ${x.vong} vòng thử (${x.vong * CAI_DAT.SO_LAN_THU} lần): ${e.message} — các bài khác vẫn đăng bình thường. Cần đăng tay (bấm Soạn hoặc Đăng lại trên popup).`, 'loi_' + it.k);
    else if (vongMoi && x.vong >= 3) await baoLoi(`🚨 ${it.ten} đã hỏng ${x.vong - 1} vòng thử (${(x.vong - 1) * CAI_DAT.SO_LAN_THU} lần, lỗi cuối: ${e.message}) → nghỉ ${CAI_DAT.NGHI_GIUA_VONG_PHUT} phút rồi thử vòng cuối ${x.vong}/${CAI_DAT.SO_VONG_THU} lúc ${gioStr(new Date(x.thuLai))} — nên vào kiểm tra máy ${TEN_MAY}; trong lúc chờ các bài khác vẫn đăng`, 'vong' + x.vong + '_' + it.k);
    else if (vongMoi) await baoLoi(`⚠️ ${it.ten} lỗi ${CAI_DAT.SO_LAN_THU} lần liền (${e.message}) → nghỉ ${CAI_DAT.NGHI_GIUA_VONG_PHUT} phút rồi thử vòng ${x.vong}/${CAI_DAT.SO_VONG_THU} lúc ${gioStr(new Date(x.thuLai))}, bước phụ lỗi sẽ được bỏ qua; trong lúc chờ các bài khác vẫn đăng`, 'vong' + x.vong + '_' + it.k);
    else await baoLoi(`⚠️ Lỗi khi đăng ${it.ten}: ${e.message} — script tự thử lại sau ${CAI_DAT.THU_LAI_PHUT} phút (lần ${lanTong + 1}, bước phụ lỗi sẽ được bỏ qua)`, 'loi1_' + it.k);
    window.__smhHuyLuot = 0;
    if (!dong || vongMoi || x.lan % 2 === 0 || e.taiLai) { if (e.taiLai) ghi(`${it.ten}: tải lại trang cho sạch rồi thử lại lúc ${gioStr(new Date(x.thuLai))}`); setTimeout(() => { if (!dangBan && !lay('dang_do', null)) roiTrang(); }, 3000); } // tải lại trang cho sạch trước lần thử sau
  }

  async function dangSlot(it, nd, thu, ngayBai) {
    const ngay = homNay(); const mai = ngayBai && ngayBai !== ngay ? ngayBai : ''; const ngayTT = mai || ngay;
    const chung = (duLieu() || {}).chung || { co: '', pool: [] };
    const can = canCmt(it, nd, chung, ngayTT);
    const cmts = can.text.map((v) => ({ k: 'text', v })).concat(can.anh.map((v) => ({ k: 'anh', v })));
    capNhatTT((s) => { ttSlot(s, it.k).can = can; }, ngayTT);
    const luiCho = () => capNhatTT((s) => { ttSlot(s, it.k).tt = 'cho'; }, ngayTT);
    const choTay = (them) => { if (!mai && !chanLark()) ghiKhoaO(it.k).catch(() => {}); // (6.19.3) đang soạn sẵn chờ người bấm Đăng → giữ chỗ để máy kia không đăng thay
      capNhatTT((s) => { const x = ttSlot(s, it.k); if (x.tt === 'dang') x.tt = 'cho'; x.ep = 0; x.soan = false; x.daSoan = Date.now(); x.thuLai = Date.now() + 60 * 60000; }, ngayTT); luu('cho_tay6', Object.assign({ slot: it.k, ten: it.ten + (mai ? ' (ngày mai)' : ''), loai: loaiSo[it.loai], text: nd.text, hang: nd.hang, cmts, luc: Date.now(), ngay, mai, soan: !chayThu() }, them)); thongBaoMay(`Đã soạn ${mai ? 'thử' : 'sẵn'} ${it.ten}${mai ? ' của ngày mai' : ''}`, mai ? 'Xem kỹ rồi bấm Huỷ / đóng hộp. Nếu bấm Đăng thì bài lên trang NGAY HÔM NAY và ngày mai không đăng lại.' : 'Kiểm tra rồi bấm Đăng. Sau khi đăng, script tự comment.'); };
    if (hdChay) hdChay.ten = `Đang ${thu ? 'soạn' : 'đăng'} ${it.ten}${mai ? ' (ngày mai)' : ''}`;
    ghi(`Bắt đầu ${thu ? 'soạn' : 'đăng'} ${it.ten}${mai ? ' (bài của ngày mai, soạn thử)' : ''}${thu ? ' (dừng trước nút Đăng, chờ bạn bấm Đăng)' : ''}`);
    if (it.loai === 'b1' || it.loai === 'b2' || it.loai === 'b3') {
      const files = [];
      for (let i = 0; i < (nd.anh || []).length; i++) { kiemDung(); files.push(await taiAnhKho(nd.anh[i], 'anh-' + (i + 1))); }
      if (!(await damBaoTuCach())) { luiCho(); return; }
      if (!dungTrang()) { luiCho(); veTrang(); return; }
      if (hopDangDo() || hopSoanBai()) { ghi('Có hộp đăng bài mở dở → đóng lại'); if (!(await dongHopSoan())) { luiCho(); roiTrang(); return; } }
      const bai = { ngay, hang: nd.hang, khoa: ngay + '|' + it.k, bai: nd.text, cmt: '', files,
        ddThem: { slot: it.k, loai: loaiSo[it.loai], ten: it.ten, cmts, cmtIdx: 0, soAnh: files.length, ghiChuTruoc: window.__smhBoQua || [] } };
      const soNhom = await dangLenFacebook(bai, { soanThu: thu });
      if (thu) { choTay({}); return; }
      const thay = await cho(() => timBai(nd.text), 60000, 1000);
      if (!thay) { ghi('Chưa thấy bài trên trang → tải lại để kiểm tra'); roiTrang(CAI_DAT.URL_TRANG); return; }
      ghi('B10. Đã thấy bài trên trang');
      const dd = lay('dang_do', null) || Object.assign({ ngay, hang: nd.hang, khoa: bai.khoa, bai: nd.text, soNhom }, bai.ddThem);
      await sauKhiDangSlot(dd);
      return;
    }
    // video / manifest
    const file = it.loai === 'video' ? await taiVideoKho(nd.tep) : await videoManifest(ngayTT, it.so, nd.anh, (m) => { if (hdChay) { hdChay.chi = m; hdChay.cap = Date.now(); } });
    if (!(await damBaoTuCach())) { luiCho(); return; }
    if (!dungTrang()) { luiCho(); veTrang(); return; }
    if (hopDangDo() || hopSoanBai() || ganManHinh()) { ghi('Có hộp đăng bài mở dở → đóng lại'); if (!(await dongHopSoan()) || ganManHinh()) { await dongHopVideo(); if (ganManHinh() || hopSoanBai()) { luiCho(); roiTrang(); return; } } }
    window.__smhThe = chonThe(it.loai, it.so, ngayTT, null, it.kenh || 1); // (6.19.3) thẻ theo kênh
    window.__smhTheDuoc = 0;
    { const kc = CAI_DAT.KENH[it.kenh || 1] || {}; window.__smhBoViTri = !!kc.hx; window.__smhBoThe = !!kc.hx && !window.__smhThe.length; } // (6.26) kênh Hà Xá: không gắn vị trí Sơn Mộc Hương; kho thẻ trống thì bỏ bước thẻ
    window.__smhNhe = (it.kenh || 1) > 1; // (6.19) kênh 2, 3: vị trí / thẻ / nhóm / hình thu nhỏ lỗi → bỏ qua bước đó, vẫn đăng (đăng bài mới là chính)
    const kq = await dangVideoFb({ slot: it.k, ten: it.ten, loai: loaiSo[it.loai], text: nd.text, file, cmts, hang: nd.hang, ngay }, { soanThu: thu });
    if (thu) { choTay({ video: true }); return; }
    void kq; // việc dở 'kiem_bai' (dò bài qua Facebook) chạy tiếp ở nhịp sau
  }

  // ---------------- video / manifest: soạn thước phim → vị trí → thẻ → nhóm → hình thu nhỏ → Đăng ----------------
  const nutHopPhuChung = () => {
    const CHU = ['Lúc khác', 'Để sau', 'Không phải bây giờ', 'Không phải lúc này', 'Bỏ qua', 'Không, cảm ơn', 'Không cảm ơn', 'Đăng bài viết gốc', 'Đăng bài gốc'];
    const lop = Array.from(document.querySelectorAll('div[role="dialog"],[role="alertdialog"],[aria-modal="true"]')).filter((d) => dangHien(d) && (!/Tạo bài viết|Cài đặt thước phim|Chỉnh sửa thước phim|Cài đặt bài viết/.test(d.innerText || '') || (d.innerText || '').length < 500));
    for (const d of lop) for (const chu of CHU) { const n = Array.from(d.querySelectorAll('[role="button"],button')).filter(dangHien).find((x) => chuan(x.innerText || x.getAttribute('aria-label')) === chu); if (n) return { n, chu, hop: chuan(d.innerText).slice(0, 80) }; }
    return null;
  };
  const oMoTaVideo = () => Array.from(document.querySelectorAll('[role="dialog"] [contenteditable="true"]')).find((e) => ganThay(e) && /^Mô tả/i.test(e.getAttribute('aria-label') || ''));
  const laNutDang = (b) => !b.closest('#smhfb') && (b.getAttribute('aria-label') === 'Đăng' || chuan(b.innerText) === 'Đăng') && b.getAttribute('aria-disabled') !== 'true' && !b.disabled;
  const nutDangVideo = () => { // (6.9) nút Đăng bị cuộn khuất trong khung Cài đặt → cuộn tới rồi trả về
    const b = Array.from(document.querySelectorAll('[role="button"],button')).find((x) => ganThay(x) && laNutDang(x)); if (b) return b;
    const k = Array.from(document.querySelectorAll('[role=dialog] [role="button"],[role=dialog] button')).find((x) => laNutDang(x) && x.getClientRects().length && !x.closest('[aria-hidden="true"]'));
    if (k) { try { k.scrollIntoView({ block: 'center' }); } catch (e) { /* */ } if (ganThay(k)) return k; }
    return null;
  };
  async function dongHopVideo() {
    for (let lan = 0; lan < 4 && (ganManHinh() || hopSoanBai()); lan++) {
      const nut = Array.from(document.querySelectorAll('[aria-label="Đóng"], [aria-label="Quay lại"], [aria-label="Đóng hộp thoại của công cụ tạo"]')).find(ganThay);
      if (nut) { try { ganBam(nut); } catch (e) { nut.click(); } } else document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', code: 'Escape', keyCode: 27, which: 27, bubbles: true }));
      await sleep(1500);
      const hoi = hopThoai((d) => /Bỏ|Rời khỏi|bỏ những thay đổi|Hủy thước phim/i.test(d.innerText) && d.innerText.length < 400);
      if (hoi) { const bo = Array.from(hoi.querySelectorAll('[role="button"]')).find((b) => /^(Bỏ|Bỏ bài viết|Rời khỏi|Rời khỏi trang|Bỏ thay đổi|Hủy)$/i.test(chuan(b.innerText))); if (bo) bo.click(); await sleep(1000); }
    }
    return !ganManHinh() && !hopSoanBai();
  }
  const tenHopDung = (d) => !!d && chuan(String(d.innerText || '').replace(/\s+/g, ' ').slice(0, 400)).includes(chuan(CAI_DAT.TEN_TRANG)); // (6.9) không đếm dòng: dòng "100%" của video cũ chen vào đầu hộp
  async function choTenHop(layHop) { // hộp soạn phải đứng tên trang; mới mở có thể chưa hiện tên → đợi tối đa 8 giây
    const ok = await cho(() => tenHopDung(layHop()), 8000, 400);
    if (ok) return;
    const d = layHop(); const dau = d ? chuan(d.innerText.split('\n').slice(0, 4).join(' | ')) : '(không có hộp)';
    const e = new LoiMem('Hộp soạn bài không đứng tên ' + CAI_DAT.TEN_TRANG + ' (đang hiện: ' + dau.slice(0, 70) + ')'); e.taiLai = true; throw e;
  }
  // (6.15) mở hộp soạn bằng nhiều đường: ô "Bạn đang nghĩ gì?" (2 cách bấm) → nút "Ảnh/video" → báo lỗi để tải lại trang
  async function moHopSoanNhieuDuong(B) {
    let dlg = hopSoanBai(); if (dlg) return dlg;
    const nut = timNutSoanBai();
    if (nut) {
      nut.click(); dlg = await cho(hopSoanBai, 10000);
      if (!dlg) { const n2 = timNutSoanBai() || nut; try { ganBam(n2); } catch (e) { n2.click(); } dlg = await cho(hopSoanBai, 12000); }
      if (dlg) return dlg;
    }
    const av = Array.from(document.querySelectorAll('[role="button"]')).find((b) => (chuan(b.innerText) === 'Ảnh/video' || b.getAttribute('aria-label') === 'Ảnh/video') && !b.closest('[role="dialog"]') && !b.closest('#smhfb') && dangHien(b));
    if (av) {
      B((nut ? 'Ô "Bạn đang nghĩ gì?" không mở được hộp soạn' : 'Không thấy ô "Bạn đang nghĩ gì?"') + ' → thử nút "Ảnh/video"');
      try { ganBam(av); } catch (e) { av.click(); }
      dlg = await cho(hopSoanBai, 12000); if (dlg) return dlg;
    }
    const e = new LoiMem(nut || av ? 'Không mở được hộp soạn bài (đã thử ô "Bạn đang nghĩ gì?" và nút "Ảnh/video")' : 'Không tìm thấy ô "Bạn đang nghĩ gì?" lẫn nút "Ảnh/video" trên trang');
    e.taiLai = true; throw e;
  }
  // (6.15) chờ nút Đăng sáng lên: mỗi phút ghi tiến độ; video đứng yên ở cùng 1 mức % suốt 3 phút → làm lại (tải lại trang)
  const phanTramVideo = () => { let m = null; for (const d of document.querySelectorAll('[role="dialog"]')) { if (!dangHien(d)) continue; const r = String(d.innerText || '').match(/(^|\s)(\d{1,3})\s?%/); if (r) m = +r[2]; } return m; };
  async function choNutDangVideo(B) {
    const t0 = Date.now(); let pt = phanTramVideo(), ptLuc = Date.now(), baoLuc = Date.now();
    for (;;) {
      const nd = await cho(nutDangVideo, 1500, 500); if (nd) return nd;
      const x = nutHopPhuChung() || nutHopLa(); if (x) { B(`Facebook hiện hộp «${x.hop}» che nút Đăng → bấm "${x.chu}"`); try { ganBam(x.n); } catch (e) { x.n.click(); } await sleep(1500); }
      const p = phanTramVideo(); if (p !== pt) { pt = p; ptLuc = Date.now(); }
      if (pt !== null && pt < 100 && Date.now() - ptLuc > 180000) { const e = new LoiMem(`Video đứng yên ở ${pt}% suốt 3 phút (Facebook không xử lý tiếp)`); e.taiLai = true; throw e; }
      if (Date.now() - t0 > 240000) { const e = new LoiMem('Nút Đăng chưa bấm được sau 4 phút (Facebook có thể còn đang kiểm tra video)'); e.taiLai = true; throw e; }
      if (Date.now() - baoLuc > 60000) { baoLuc = Date.now(); B(`Chờ nút Đăng sáng lên (Facebook đang xử lý video${pt !== null ? ' · ' + pt + '%' : ''}) — đã ${Math.round((Date.now() - t0) / 60000)} phút`); }
    }
  }
  // (6.15) hộp lạ của Facebook (chưa có trong danh sách chữ quen) che hộp đăng → bấm nút X "Đóng" của chính hộp đó. KHÔNG đụng hộp hỏi Bỏ/Xoá/Rời khỏi
  const HOP_LA_DA_GHI = {};
  const nutHopLa = () => {
    const lop = Array.from(document.querySelectorAll('div[role="dialog"],[role="alertdialog"]')).filter((d) => dangHien(d) && !d.closest('#smhfb,#smhfb-nho,#smhfb-soan-w,#smhfb-gan-w,#smhfb-gan-modal'));
    for (const d of lop) {
      const tx = String(d.innerText || '');
      if (!tx.trim() || tx.length > 500 || /Tạo bài viết|Cài đặt thước phim|Chỉnh sửa thước phim|Cài đặt bài viết|Tạo thước phim/.test(tx)) continue;
      if (/Bỏ|Xóa|Xoá|Rời khỏi|bỏ những thay đổi|Hủy|Huỷ|Thanh toán|Mật khẩu|Chuyển trang cá nhân/i.test(tx)) continue; // (6.26.1) không đóng hộp xác nhận đổi tư cách
      const k = chuan(tx).slice(0, 80); if (!HOP_LA_DA_GHI[k]) { HOP_LA_DA_GHI[k] = 1; ghi(`Gặp hộp lạ của Facebook: «${k}»`); }
      const n = Array.from(d.querySelectorAll('[role="button"],button')).filter(dangHien).find((x) => x.getAttribute('aria-label') === 'Đóng' || chuan(x.innerText) === 'Đóng');
      if (n) return { n, chu: 'Đóng', hop: k };
    }
    return null;
  };
  async function dangVideoFb(v, { soanThu = false } = {}) {
    const B = (m) => ghi(`${v.ten}: ${m}`);
    kiemDung(); window.__smhMoHop = Date.now();
    window.scrollTo(0, 0); await sleep(800);
    let dlg = await moHopSoanNhieuDuong(B);
    try { await choTenHop(() => hopSoanBai() || dlg); }
    catch (eT) { // (6.15) hộp đứng sai tên → đóng hộp, chuyển sang tư cách trang, mở lại 1 lần
      if (!(eT instanceof LoiMem)) throw eT;
      B('Hộp soạn không đứng tên ' + CAI_DAT.TEN_TRANG + ' → đóng hộp, chuyển tư cách rồi mở lại');
      await dongHopVideo();
      if (!(await damBaoTuCach())) throw new LoiDung('đang chuyển sang tư cách ' + CAI_DAT.TEN_TRANG + ' — trang tải lại xong sẽ đăng tiếp');
      dlg = await moHopSoanNhieuDuong(B);
      await choTenHop(() => hopSoanBai() || dlg);
      B('Mở lại hộp soạn: đã đứng tên ' + CAI_DAT.TEN_TRANG);
    }
    await xoaAnhCu();
    const ed = () => { const d = hopSoanBai(); return d ? Array.from(d.querySelectorAll('div[contenteditable="true"][data-lexical-editor]')).pop() : null; };
    if (!(await datChu(ed(), v.text))) { await sleep(800); if (!(await datChu(ed(), v.text))) throw new LoiMem('Điền chữ mô tả chưa khớp'); }
    B('V1. Đã điền chữ mô tả (' + v.text.length + ' ký tự)');
    kiemDung();
    const d0 = hopSoanBai(); if (!d0) throw new LoiMem('Hộp soạn bài đã đóng');
    const inps = Array.from(d0.querySelectorAll('input[type="file"]'));
    const inp = inps.find((i) => /video/.test(i.accept || '')) || inps[0];
    if (!inp) throw new LoiMem('Không thấy ô chọn ảnh/video trong hộp soạn bài');
    const gan = () => { const dt = new DataTransfer(); dt.items.add(v.file); inp.files = dt.files; inp.dispatchEvent(new Event('input', { bubbles: true })); inp.dispatchEvent(new Event('change', { bubbles: true })); };
    gan();
    const coVideo = () => Array.from(document.querySelectorAll('div[role="dialog"] video')).some((x) => x.getBoundingClientRect().width > 60);
    let ok = await cho(coVideo, 60000, 1000);
    if (!ok && hopSoanBai()) { B('Facebook chưa hiện video sau 60 giây → gắn lại lần 2'); try { gan(); } catch (e) { /* */ } ok = await cho(coVideo, 90000, 1000); }
    if (!ok) { const eV = new LoiMem('Facebook chưa nhận video sau 2 lần gắn'); eV.taiLai = true; throw eV; }
    B(`V2. Đã gắn video (${(v.file.size / 1048576).toFixed(1)} MB)`);
    const bao = (m) => { if (hdChay) { hdChay.chi = v.ten + ': ' + m; hdChay.cap = Date.now(); } };
    // vị trí (trong hộp soạn) → Tiếp → màn "Chỉnh sửa thước phim"
    kiemDung();
    const phu = async (ten, fn, gocLai) => { // bước phụ: lần đầu lỗi thì báo lỗi (thử lại cả bài); từ lần thử lại thì bỏ qua bước đó, vẫn đăng
      try { return await fn(); } catch (e) { if (!thuNhe() || e instanceof LoiDung) throw e; boQuaBuoc(ten, e); try { await gocLai(); } catch (e2) { /* */ } return null; }
    };
    const thoatLop = async () => { document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', code: 'Escape', keyCode: 27, which: 27, bubbles: true })); await sleep(1200); };
    if (ganManHinh() === 'soan' && !window.__smhBoViTri) { const vt = await phu('vị trí', async () => { await ganViTri(bao); return 1; }, async () => { if (ganManHinh() === 'vitri-tim') await thoatLop(); const t = ganNutTiep(); if (t) ganBamCu(t); }); if (vt) B('V3. Đã gắn vị trí ' + CAI_DAT.VI_TRI); }
    else { const t0 = ganNutTiep(); if (t0) ganBamCu(t0); }
    if (!(await ganCho(() => ganManHinh() === 'the' || ganManHinh() === 'caidat', 60000, 500))) {
      const t1 = ganNutTiep(); if (t1) { B('Chưa sang màn Chỉnh sửa thước phim → bấm Tiếp lại'); ganBam(t1); }
      if (!(await ganCho(() => ganManHinh() === 'the' || ganManHinh() === 'caidat', 60000, 500))) throw new LoiMem('Không sang được màn Chỉnh sửa thước phim');
    }
    kiemDung();
    if (ganManHinh() === 'the' && window.__smhBoThe) { B('V4. Kênh này không gắn thẻ → bỏ qua'); const t = ganNutTiep(); if (t) ganBamCu(t); }
    else if (ganManHinh() === 'the') { const th = await phu('thẻ', async () => { await ganThe(bao); return 1; }, async () => { const t = ganNutTiep(); if (t) ganBamCu(t); }); if (th) B('V4. Đã gắn ' + (window.__smhTheDuoc || ganDsThe().length) + ' thẻ'); }
    if (!(await ganCho(() => ganManHinh() === 'caidat', 30000, 500))) throw new LoiMem('Không sang được màn Cài đặt thước phim');
    // chữ mô tả còn không
    await sleep(1200);
    const mt = oMoTaVideo();
    if (mt && !khoaSo(mt.innerText).includes(khoaSo(v.text).slice(0, 30))) { B('Chữ mô tả bị mất khi Facebook chuyển màn → điền lại'); await datChu(mt, v.text); }
    kiemDung();
    const veCaiDat = () => ganManHinh() === 'caidat' && ![...document.querySelectorAll('input[type=checkbox]')].some((x) => x.getAttribute('role') !== 'switch' && ganThay(x));
    const n = (await phu('chọn nhóm', async () => {
      const k = await ganNhom(bao);
      if (!(await ganCho(veCaiDat, 15000, 300))) throw new LoiMem('Chưa quay lại được màn Cài đặt thước phim sau khi chọn nhóm');
      return k;
    }, async () => { for (let lan = 0; lan < 3 && !veCaiDat(); lan++) { const x = ganNut('Xong') || [...document.querySelectorAll('[role=dialog] [aria-label="Quay lại"]')].find((b) => b.getClientRects().length); if (x) { try { if (lan) ganBam(x); else ganBamCu(x); } catch (e) { x.click(); } } else await thoatLop(); await ganCho(veCaiDat, 5000, 300); } })) || { tong: 0 }; // (6.26.5) quay lại màn Cài đặt: Xong → nút ← → Esc
    if (!veCaiDat() && !(await ganCho(veCaiDat, 8000, 300))) throw new LoiMem('Chưa quay lại được màn Cài đặt thước phim');
    if (n.tong) B('V5. Đã chọn ' + n.tong + ' nhóm'); else if (n.trong) B('V5. Trang chưa tham gia nhóm nào → bỏ qua chọn nhóm');
    kiemDung();
    { const tn = await phu('hình thu nhỏ', () => ganThuNho(bao), async () => { const l = ganNutLuuAnh(); if (l) ganBamCu(l); else if (ganManHinh() !== 'caidat') await thoatLop(); await ganCho(veCaiDat, 15000, 300); }); B(tn === null ? 'V6. Bỏ qua hình thu nhỏ — giữ hình mặc định' : 'V6. Đã chọn hình thu nhỏ là khung hình đầu'); }
    kiemDung();
    const nd = await choNutDangVideo(B);
    if (soanThu) { nd.style.outline = '4px solid #f7b928'; nd.style.outlineOffset = '2px'; B('đã soạn xong, dừng trước nút "Đăng" — bấm Đăng tay, script sẽ comment tiếp'); return -1; }
    if (coApi()) {
      let trung = null;
      try { const tu = new Date(new Date().setHours(0, 0, 0, 0)).getTime(); const daDung = new Set(); for (const [k0, r0] of Object.entries(trangThai().s || {})) if (k0 !== v.slot && r0 && r0.id && !r0.theoThuTu) dungBai(daDung, r0); trung = baiKhop((await baiTrenTrangApi(tu)).filter((p) => p.luc >= tu && laVideoApi(p) !== false), v.text, daDung); } catch (e) { B('Dò trùng lần cuối lỗi (' + e.message + ') → vẫn đăng'); }
      if (trung) { await dongHopVideo(); throw new LoiTrung('Bài đã có trên trang ngay trước khi bấm Đăng', trung); }
    }
    await kiemKhoaTruocDang(v.slot); // (6.26.4)
    kiemDung();
    luu('dang_do', { video: true, slot: v.slot, loai: v.loai, ten: v.ten, ngay: v.ngay, hang: v.hang, khoa: v.ngay + '|' + v.slot, bai: v.text, luc: Date.now(), buoc: 'kiem_bai', cmts: v.cmts, cmtIdx: 0, soAnh: 0, ghiChuTruoc: (window.__smhBoQua || []).map((t) => 'bỏ qua bước ' + t + ' (lần thử lại)'), soNhom: n.tong, ngoai: true });
    try { ganBamCu(nd); } catch (e) { nd.click(); }
    B('V7. Đã bấm Đăng');
    let lucPhu = 0;
    const daDong = () => { const x = nutHopPhuChung() || nutHopLa(); if (x && Date.now() - lucPhu > 2500) { lucPhu = Date.now(); ghi(`${v.ten}: Facebook hiện hộp «${x.hop}» → bấm "${x.chu}"`); try { ganBam(x.n); } catch (e) { x.n.click(); } } return !ganManHinh() && !hopSoanBai(); };
    let dong = await cho(daDong, 60000, 800);
    if (!dong) { const n2 = nutDangVideo(); if (n2) { B('Bấm Đăng lần 1 chưa ăn → bấm lại'); try { ganBam(n2); } catch (e) { n2.click(); } } dong = await cho(daDong, 60000, 1000); }
    if (!dong && nutDangVideo()) { // (6.15) bấm 2 lần mà hộp vẫn mở, nút Đăng vẫn còn → nhịp sau hỏi Facebook ngay, chưa có bài thì đóng hộp + tải lại + đăng lại
      const dd2 = lay('dang_do', null); if (dd2 && dd2.slot === v.slot) { dd2.khongAn = Date.now(); luu('dang_do', dd2); }
      B('V8. Bấm Đăng 2 lần không ăn (hộp vẫn mở, nút Đăng vẫn còn) → hỏi Facebook xem bài đã lên chưa; chưa có thì tải lại trang và đăng lại');
    } else B(dong ? 'V8. Hộp đăng thước phim đã đóng — chờ Facebook xử lý video' : 'V8. Hộp đăng thước phim chưa đóng sau ~2 phút — sẽ dò trên trang');
    return n.tong;
  }

  // =====================================================================
  //  SAU KHI ĐĂNG: ghi nhận → (sửa nền đỏ Bài 2) → comment → kiểm qua Facebook
  // =====================================================================
  async function sauKhiDangSlot(dd) {
    const s0 = trangThai(); const r0 = s0.s[dd.slot] || {};
    const coLoiTruoc = !!r0.loi;
    capNhatTT((s) => { Object.assign(ttSlot(s, dd.slot), { tt: 'xong', luc: dd.lucApi || Date.now(), may: MAY, link: dd.link || r0.link || '', id: dd.id || r0.id || '', kiem: [], loi: '', daSoan: 0 }); });
    luu('bai_cuoi6', Date.now());
    ghi(`Đã đăng ${dd.ten} lúc ${gioStr(new Date())}`);
    if (coLoiTruoc) baoLoi(`✅ ${dd.ten} đã đăng được lúc ${gioStr(new Date())} (sau lỗi trước đó)`, 'hoi_' + dd.slot);
    Object.assign(dd, { buoc: 'cho_binh_luan', luc: Date.now(), lucDang: gioStr(new Date()), cmtIdx: dd.cmtIdx || 0 });
    const canSuaNen = dd.loai === 2 && CAI_DAT.SUA_NEN_B2 !== false;
    if ((!dd.cmts || !dd.cmts.length) && !canSuaNen) { await hoanTatSlot(dd, dd.ghiChuTruoc || []); return; }
    dd.cmts = dd.cmts || [];
    luu('dang_do', dd);
    ghi(dd.cmts.length ? 'Chờ vài giây rồi tải lại trang để comment' : 'Chờ vài giây rồi tải lại trang để sửa nền đỏ');
    await sleep(2500);
    if (dd.viaLink) roiTrang(dd.viaLink); else roiTrang();
  }
  // video: đã thấy bài → ghi "ĐÃ ĐĂNG" (cột J) + link (cột B) vào đúng hàng — gộp 1 lượt ghi
  // (6.19.3) ghi "ĐÃ ĐĂNG" + link vào sheet: tìm đúng dòng (cùng ngày đăng, chưa "ĐÃ ĐĂNG", khớp chữ); lỗi thì để vào hàng chờ, Lark ổn lại sẽ ghi bù
  // (6.20.8) ghi "ĐÃ ĐĂNG" + link: gom lại, ghi 1 lần mỗi buổi (12:30, 19:30, 22:40) — mỗi tab 1 lượt đọc + 1 lượt ghi
  async function ghiKetQuaVideo(dd, laThuLai) {
    if (dd.loai !== 4 || !dd.hang) return true;
    if (laThuLai) return ghiKetQuaVideoNgay(dd, true);
    const ds = (lay('ghigom6', []) || []).filter((x) => !(x.slot === dd.slot && x.ngay === (dd.ngay || homNay())));
    ds.push({ loai: 4, slot: dd.slot, ten: dd.ten, ngay: dd.ngay || homNay(), hang: dd.hang, bai: String(dd.bai || '').slice(0, 400), link: dd.link || '', luc: Date.now() });
    luu('ghigom6', ds); ghi(`${dd.ten}: sẽ ghi "ĐÃ ĐĂNG" + link vào sheet ở lượt gom tiếp theo (12:30 / 19:30 / 22:40)`);
    return true;
  }
  const MOC_GOM = ['13:40', '18:40', '22:40']; // (6.25) ngay sau lượt đọc sheet 13:30 / 18:30 → dùng luôn dữ liệu vừa đọc, khỏi đọc lại tab
  async function ghiGomKetQua(ep) {
    const ds = lay('ghigom6', []) || []; if (!ds.length || chanLark()) return false;
    const mm = phutTrongNgay(new Date()); const st = lay('gom6_' + homNay(), {}) || {};
    const moc = MOC_GOM.filter((g) => mm >= docGio(g) && !st[g]).pop(); const cu = ds.some((x) => x.ngay !== homNay());
    if (!ep && !moc && !cu) return false;
    if (moc) { MOC_GOM.forEach((g) => { if (mm >= docGio(g)) st[g] = Date.now(); }); luu('gom6_' + homNay(), st); }
    luu('ghigom6', []);
    const L = (i) => String.fromCharCode(65 + i); const theoTab = {};
    for (const dd of ds) { const c = kenhCua(dd.slot); const tab = c > 1 ? CAI_DAT.KENH[c].tab : CAI_DAT.TAB_VIDEO; (theoTab[tab] = theoTab[tab] || { c, ds: [] }).ds.push(dd); }
    for (const [tab, g] of Object.entries(theoTab)) {
      const cfg = g.c > 1 ? CAI_DAT.KENH[g.c] : null; const cot = cfg ? cfg.cot : { cap: 4, tt: 9, ngay: 10, link: 1 }; const tenTab = cfg ? `tab "${cfg.tenTab}"` : 'tab Kênh 1';
      try {
        // (6.25) dữ liệu sheet vừa đọc (≤ 60 phút) xác nhận đúng dòng → ghi luôn, không đọc lại cả tab
        const dl = duLieu(); const moi = dl && Date.now() - (dl.luc || 0) < 60 * 60000;
        const hangCache = (dd) => { if (!moi) return 0; try { const nd = noiDungSlot(dd.ngay || homNay(), dd.slot, dl); return nd.hang && khoaSo(nd.text).slice(0, 40) === khoaSo(dd.bai).slice(0, 40) ? nd.hang : 0; } catch (e) { return 0; } };
        const v = g.ds.every((dd) => hangCache(dd)) ? null : await docBang(tab, 'A1:N3000'); const o = []; const xong = [];
        if (!v) ghi(`Ghi gom: dùng dữ liệu sheet vừa đọc (${gioStr(new Date(dl.luc))}) → không đọc lại ${tenTab}`);
        for (const dd of g.ds) {
          const khoa = khoaSo(dd.bai).slice(0, 40); let hang = v ? dd.hang : hangCache(dd);
          if (v && khoaSo(chuO((v[hang - 1] || [])[cot.cap])).slice(0, 40) !== khoa) { const ung = []; for (let i = 1; i < v.length; i++) { const x = v[i] || []; if (khoaSo(chuO(x[cot.cap])).slice(0, 40) !== khoa) continue; if (dd.ngay && ngayO(x[cot.ngay]) !== dd.ngay) continue; if (/đã đăng/i.test(chuO(x[cot.tt]))) continue; ung.push(i + 1); } if (ung.length !== 1) { ghi(`${dd.ten}: chưa ghi được "ĐÃ ĐĂNG" vào ${tenTab} (${ung.length ? 'có nhiều dòng cùng chữ' : 'không còn thấy dòng của video'})`); baoLoi(`${dd.ten} đã đăng nhưng chưa ghi được "ĐÃ ĐĂNG"/link vào ${tenTab}${dd.link ? ' — link: ' + dd.link : ''}`, 'ghij_' + dd.slot); continue; } hang = ung[0]; }
          o.push([L(cot.tt) + hang, 'ĐÃ ĐĂNG']); if (dd.link) o.push([L(cot.link) + hang, dd.link]); xong.push(`${dd.ten} (dòng ${hang})`);
        }
        if (o.length) { await ghiNhieuO(tab, o); ghi(`Ghi gom vào ${tenTab}: "ĐÃ ĐĂNG" + link cho ${xong.join(', ')}`); }
      } catch (e) {
        ghi(`Ghi gom vào ${tenTab} chưa được (${e.message}) → chuyển sang ghi bù từng bài`);
        const cho = lay('ghij_cho6', []) || []; for (const dd of g.ds) if (!cho.some((x) => x.slot === dd.slot && x.ngay === dd.ngay)) cho.push(Object.assign({}, dd, { lan: 0, luc: Date.now() - 9 * 60000 })); luu('ghij_cho6', cho);
      }
    }
    return true;
  }
  async function ghiKetQuaVideoNgay(dd, laThuLai) {
    if (dd.loai !== 4 || !dd.hang) return true;
    const c = kenhCua(dd.slot); const cfg = c > 1 ? CAI_DAT.KENH[c] : null; const L = (i) => String.fromCharCode(65 + i);
    const tab = c > 1 ? cfg.tab : CAI_DAT.TAB_VIDEO;
    const cot = c > 1 ? cfg.cot : { cap: 4, tt: 9, ngay: 10, link: 1 };
    const tenTab = c > 1 ? `tab "${cfg.tenTab}"` : 'tab Kênh 1';
    try {
      if (chanLark()) throw new Error('Lark đang tạm ngừng');
      const khoa = khoaSo(dd.bai).slice(0, 40);
      let hang = dd.hang; const r = (await docBang(tab, `A${hang}:N${hang}`))[0] || [];
      if (khoaSo(chuO(r[cot.cap])).slice(0, 40) !== khoa) {
        const v = await docBang(tab, 'A1:N3000'); const ung = [];
        for (let i = 1; i < v.length; i++) { const x = v[i] || []; if (khoaSo(chuO(x[cot.cap])).slice(0, 40) !== khoa) continue; if (dd.ngay && ngayO(x[cot.ngay]) !== dd.ngay) continue; if (/đã đăng/i.test(chuO(x[cot.tt]))) continue; ung.push(i + 1); }
        if (ung.length !== 1) throw new Error(ung.length ? `có ${ung.length} dòng cùng chữ trong ngày ${dd.ngay} (${ung.join(', ')}) — không biết ghi dòng nào` : `không còn thấy dòng ngày ${dd.ngay} có chữ của video trong ${tenTab}`);
        hang = ung[0];
      }
      const o = [[L(cot.tt) + hang, 'ĐÃ ĐĂNG']]; if (dd.link) o.push([L(cot.link) + hang, dd.link]);
      await ghiNhieuO(tab, o);
      ghi(`${dd.ten}: đã ghi "ĐÃ ĐĂNG" (ô ${L(cot.tt)}${hang})${dd.link ? ` và link (ô ${L(cot.link)}${hang})` : ''} vào ${tenTab}${laThuLai ? ' (ghi bù)' : ''}`);
      return true;
    } catch (e) {
      const cho = (lay('ghij_cho6', []) || []).filter((x) => !(x.slot === dd.slot && x.ngay === dd.ngay));
      const lan = laThuLai ? (dd.lan || 0) + 1 : 0;
      if (lan < 6 && !/không biết ghi dòng nào|không còn thấy dòng/.test(e.message)) cho.push({ loai: 4, slot: dd.slot, ten: dd.ten, ngay: dd.ngay || homNay(), hang: dd.hang, bai: String(dd.bai || '').slice(0, 400), link: dd.link || '', lan, luc: Date.now() });
      luu('ghij_cho6', cho);
      ghi(`${dd.ten}: chưa ghi được kết quả vào sheet (${e.message})${cho.some((x) => x.slot === dd.slot) ? ' → sẽ ghi bù khi Lark ổn' : ''}`);
      if (!laThuLai || lan >= 6) baoLoi(`${dd.ten} đã đăng nhưng chưa ghi được "ĐÃ ĐĂNG"/link vào ${tenTab} (${e.message})${dd.link ? ' — link: ' + dd.link : ''}`, 'ghij_' + dd.slot);
      return false;
    }
  }
  async function ghiBuKetQua() { // gọi trong vòng nhịp: 10 phút/lần thử ghi bù các dòng còn treo
    const cho = lay('ghij_cho6', []) || []; if (!cho.length || chanLark()) return false;
    const x = cho[0]; if (Date.now() - (x.luc || 0) < 10 * 60000) return false;
    luu('ghij_cho6', cho.slice(1));
    await ghiKetQuaVideo(x, true);
    return false;
  }

  async function xuLyDangDo() {
    const dd = lay('dang_do', null);
    if (!dd) return false;
    dangBan = true; giuKhoa();
    if (dd.ngay && dd.ngay !== homNay() && /^\d{2}-\d{2}-\d{4}$/.test(dd.ngay)) NGAY_VIEC = dd.ngay; // (6.19.3) việc dở của hôm qua (qua 0 giờ) → ghi vào lịch hôm qua, không đè lên bài cùng tên của ngày mới
    try { return await xuLyDangDo2(dd); } finally { dangBan = false; giuKhoa(); NGAY_VIEC = ''; }
  }
  const choDD = (dd, ly) => { const k = (dd.ten || '') + '|' + ly; if (window.__choDD === k && Date.now() - (window.__choDDLuc || 0) < 2 * 60000) return; window.__choDD = k; window.__choDDLuc = Date.now(); ghi(`Việc dở ${dd.ten || ''} (${dd.buoc || ''}): đang chờ vì ${ly}`); }; // (6.28.9) mọi lần chờ đều có dòng nhật ký (tối đa 2 phút/lần)
  async function xuLyDangDo2(dd) {
    if (dd.raSoat && Date.now() - (dd.batDauBu || (dd.batDauBu = (luu('dang_do', Object.assign(dd, { batDauBu: dd.luc || Date.now() })), dd.batDauBu))) > 8 * 60000) { // (6.20.3) gửi bù kẹt quá 8 phút (vd kẹt chuyển tư cách) → bỏ lượt này, ghi lỗi + báo, không treo máy
      const ly = 'quá 8 phút chưa gửi xong (kẹt ở bước chuyển tư cách/mở bài)';
      try { luuKiem(dd.rsKey || dd.slot, (x) => { x.buHong = (x.buHong || 0) + 1; x.buLyDo = ly; }); } catch (e) { /* */ }
      luu('dang_do', null); ghi(`❌ Bỏ lượt gửi bù comment ${dd.ten || ''}: ${ly}`);
      try { baoLoi(`[fb][${TEN_MAY}] Bỏ lượt gửi bù comment ${dd.ten || ''}: ${ly} — sẽ thử lại ở lượt kiểm sau (tối đa 2 lần)`, 'bukẹt_' + (dd.rsKey || dd.slot)).catch(() => {}); } catch (e) { /* */ }
      datKenh(1); return true;
    }
    { const idDung = String(dd.viaLink || dd.link || '').match(/\/(?:reel|videos)\/(\d+)/); const idNay = location.pathname.match(/^\/(?:reel|videos)\/(\d+)/); // (6.20.5) Facebook đưa sang video lạ (sau khi chuyển tư cách) → không comment bậy, mở lại đúng bài (tính vào số lần mở lại)
      if (idDung && idNay && idDung[1] !== idNay[1]) { dd.lac = (dd.lac || 0) + 1; luu('dang_do', dd); ghi(`⚠️ ${dd.ten || ''}: Facebook đưa sang video lạ (không phải bài của mình) → ${dd.lac <= 2 ? 'mở lại đúng bài' : 'dừng, không comment'}`); if (dd.lac <= 2) { await sleep(800); roiTrang(dd.viaLink || dd.link); return true; } if (dd.raSoat) { try { luuKiem(dd.rsKey || dd.slot, (x) => { x.buHong = 2; x.buLyDo = 'Facebook đưa sang video lạ'; }); } catch (e) { /* */ } luu('dang_do', null); try { baoLoi(`[fb][${TEN_MAY}] ${dd.ten || ''}: Facebook liên tục đưa sang video lạ khi mở bài để comment → đã dừng, cần comment tay`, 'lac_' + dd.slot).catch(() => {}); } catch (e) { /* */ } datKenh(1); return true; } } }
    datKenh(kenhCua(dd.slot)); // (6.19) việc dở thuộc kênh nào thì tư cách / trang / dò bài theo kênh đó
    if ((hopDangDo() || hopSoanBai() || dangODuongSua()) && nguoiDangThaoTac()) { choDD(dd, 'bạn đang thao tác trên hộp soạn bài'); return true; }
    if (!laTabChinh()) { choDD(dd, 'tab này không phải tab chính của script'); return true; }
    if (dd.ngay !== homNay() && Date.now() - dd.luc > 6 * 3600e3) { luu('dang_do', null); ghi('Bỏ việc dở của ngày cũ'); return false; }
    if (tamDung() && dd.buoc !== 'kiem_bai') { choDD(dd, 'script đang Tạm dừng'); return true; }
    // video / manifest vừa bấm Đăng: dò qua Facebook đến khi thấy bài (không cần tab hiện)
    if (dd.video && dd.buoc === 'kiem_bai') {
      // (6.15) hỏi Facebook ở các mốc 1-2-3-5-8-12-16-20 phút sau khi bấm Đăng (nhẹ, không hỏi liên tục); bấm Đăng 2 lần không ăn thì hỏi ngay
      const phut = (Date.now() - dd.luc) / 60000;
      const moc = [1, 2, 3, 5, 8, 12, 16, 20].filter((m) => phut >= m).length;
      const gap = dd.khongAn && !dd.khongAnDaHoi;
      if (!gap && (moc <= (dd.mocDo || 0) || Date.now() - (dd.lanDo || 0) < 20000)) return true;
      dd.mocDo = moc; dd.lanDo = Date.now(); if (gap) dd.khongAnDaHoi = Date.now(); luu('dang_do', dd);
      let p = null, hoiDuoc = false;
      try {
        const ds = await baiTrenTrangApi(dd.luc - 10 * 60000); hoiDuoc = true;
        p = baiKhop(ds.filter((x) => x.luc >= dd.luc - 10 * 60000 && laVideoApi(x) !== false), dd.bai);
        if (!p) { dd.apiKhong = (dd.apiKhong || 0) + 1; luu('dang_do', dd); }
      } catch (e) { ghi(`${dd.ten}: dò bài qua Facebook lỗi (${e.message})`); }
      if (p) {
        Object.assign(dd, { id: p.id, link: p.link, lucApi: p.luc, viaLink: p.link || '' });
        ghi(`${dd.ten}: Facebook xác nhận đã lên trang lúc ${gioStr(new Date(p.luc))}`);
        if (ganManHinh() || hopSoanBai()) await dongHopVideo().catch(() => {});
        await ghiKetQuaVideo(dd);
        await sauKhiDangSlot(dd); return true;
      }
      // (6.19) chưa có mã khoá đọc được trang này (kênh 2, 3 khi mã đang cài là mã riêng của trang kênh 1) → xác nhận bằng cách nhìn trang
      if (!coApi() && document.visibilityState === 'visible' && phut >= 1 && !(ganManHinh() || hopSoanBai())) {
        if (!dungTrang()) { veTrang(); return true; }
        const kh = cacKhungBai().find((x) => khungKhop(x, dd.bai));
        if (kh) {
          const a = Array.from(kh.khung.querySelectorAll('a[href]')).map((x) => x.href).find((h) => /\/(reel|videos)\//.test(h)) || '';
          Object.assign(dd, { link: a.replace(/[?#].*$/, '').replace(/\/+$/, ''), viaLink: a, lucApi: Date.now() });
          ghi(`${dd.ten}: thấy bài trên trang ${CAI_DAT.TEN_NGAN} (mã khoá chưa đọc được trang này nên xác nhận bằng cách nhìn trang)`);
          await ghiKetQuaVideo(dd); await sauKhiDangSlot(dd); return true;
        }
        if (Date.now() - (dd.taiLaiLuc || 0) > 2 * 60000) { dd.taiLaiLuc = Date.now(); luu('dang_do', dd); ghi(`${dd.ten}: chưa thấy bài trên trang → tải lại trang xem lại`); roiTrang(); return true; }
      }
      // hộp đăng vẫn mở + nút Đăng vẫn còn = Facebook chưa nhận lệnh Đăng → đóng hộp, tải lại trang, đăng lại (tính 1 lần thử; trước khi bấm Đăng lần sau vẫn dò trùng)
      const hopCon = !!(ganManHinh() || hopSoanBai()) && !!nutDangVideo();
      if (hopCon && document.visibilityState === 'visible') { const x = nutHopPhuChung() || nutHopLa(); if (x) { ghi(`${dd.ten}: hộp «${x.hop}» đang che hộp đăng → bấm "${x.chu}"`); try { ganBam(x.n); } catch (e) { x.n.click(); } await sleep(2500); } }
      if (hopCon && document.visibilityState === 'visible' && (dd.khongAn || phut >= 3) && (hoiDuoc || !coApi())) {
        ghi(`${dd.ten}: đã ${Math.max(1, Math.round(phut))} phút mà hộp đăng vẫn mở, nút Đăng vẫn còn${hoiDuoc ? ', Facebook chưa có bài' : ''} → bấm Đăng không ăn: đóng hộp, tải lại trang rồi đăng lại`);
        tuChupHienTruong(`${dd.ten}: bấm Đăng nhưng Facebook không nhận (hộp đăng vẫn mở sau ${Math.round(phut)} phút)`);
        luu('dang_do', null);
        await dongHopVideo().catch(() => {});
        const eK = new LoiMem('bấm Đăng nhưng Facebook không nhận (hộp đăng vẫn mở)'); eK.taiLai = true; eK.daChup = true;
        await xuLyLoiDang({ k: dd.slot, ten: dd.ten }, eK);
        return true;
      }
      const hanPhut = coApi() ? CAI_DAT.CHO_VIDEO_XU_LY_PHUT : CAI_DAT.CHO_VIDEO_LEN_PHUT;
      if (coApi() && !hopCon && phut >= hanPhut && (dd.apiKhong || 0) >= 3) {
        // (6.19.3) trước khi đăng lại: NHÌN TRANG thêm 1 lần (video xử lý lâu có thể đã hiện trên trang mà Facebook chưa trả qua mã khoá) → tránh 2 bài
        if (!dd.daNhinTrang && document.visibilityState === 'visible') {
          if (!dungTrang()) { dd.veNhin = (dd.veNhin || 0) + 1; luu('dang_do', dd); if (dd.veNhin <= 2) { veTrang(); return true; } }
          else { dd.daNhinTrang = true; luu('dang_do', dd); const co = await daCoTrenTrangDom(dd.bai); if (co) { Object.assign(dd, { link: co.link || dd.link, viaLink: co.link || dd.viaLink, lucApi: Date.now() }); ghi(`${dd.ten}: Facebook chưa trả bài qua mã khoá nhưng nhìn trang thấy video đã lên → không đăng lại`); if (ganManHinh() || hopSoanBai()) await dongHopVideo().catch(() => {}); await ghiKetQuaVideo(dd); await sauKhiDangSlot(dd); return true; } }
        }
        ghi(`${dd.ten}: hộp đăng đã đóng nhưng sau ${hanPhut} phút Facebook vẫn không có bài (nhìn trang cũng chưa thấy) → coi như chưa lên, đăng lại (trước khi bấm Đăng sẽ dò trùng lần nữa)`);
        luu('dang_do', null); chupLoi(dd.ten);
        if (ganManHinh() || hopSoanBai()) await dongHopVideo().catch(() => {});
        await xuLyLoiDang({ k: dd.slot, ten: dd.ten }, new LoiMem(`đã bấm Đăng nhưng sau ${hanPhut} phút Facebook vẫn không có bài`));
        return true;
      }
      if (phut >= hanPhut) {
        luu('dang_do', null);
        capNhatTT((s) => { Object.assign(ttSlot(s, dd.slot), { tt: 'khong_ro', luc: dd.luc, lyDo: `đã bấm Đăng nhưng sau ${hanPhut} phút Facebook vẫn chưa thấy bài` }); });
        ghi(`${dd.ten}: đã bấm Đăng nhưng sau ${hanPhut} phút chưa thấy bài trên trang — không đăng lại để tránh trùng`); chupLoi(dd.ten);
        await baoLoi(`❓ ${dd.ten}: đã bấm Đăng nhưng sau ${hanPhut} phút chưa thấy bài trên trang${coApi() ? ' (chưa hỏi được Facebook)' : ' (chưa cài mã khoá)'} — script KHÔNG đăng lại (tránh trùng), cần vào trang kiểm tra`, 'kr_' + dd.slot);
        if (ganManHinh() || hopSoanBai()) await dongHopVideo().catch(() => {});
      }
      return true;
    }
    if (document.visibilityState !== 'visible') { choTabAn(dd.ten || 'bài đang làm dở'); return true; }
    hetChoTabAn();
    if (!dungTrang() && !(dd.viaLink && /(^|\.)facebook\.com$/.test(location.hostname))) { veTrang(); return true; }
    if (dd.buoc === 'kiem_bai') { // bài chữ/ảnh: vừa bấm Đăng thì trang tải lại
      dd.kiemLan = (dd.kiemLan || 0) + 1; luu('dang_do', dd);
      const thay = await cho(() => timBai(dd.bai), 30000, 1000);
      if (thay) { await sauKhiDangSlot(dd); return true; }
      if (coApi()) {
        try {
          const p = baiKhop(await baiTrenTrangApi(dd.luc - 10 * 60000), dd.bai);
          if (p) { ghi(`Facebook (API) xác nhận ${dd.ten} đã lên (trang chưa hiện) → tiếp tục comment`); Object.assign(dd, { id: p.id, link: p.link, lucApi: p.luc }); await sauKhiDangSlot(dd); return true; }
          dd.apiKhong = (dd.apiKhong || 0) + 1; luu('dang_do', dd);
        } catch (e) { ghi('Kiểm bài qua API lỗi: ' + e.message); }
      }
      if (dd.kiemLan === 2 || dd.kiemLan === 4 || dd.kiemLan === 8) { ghi(`Chưa thấy ${dd.ten} vừa đăng → tải lại trang kiểm tra lần nữa`); roiTrang(); return true; }
      if (dd.kiemLan >= 6 && coApi() && (dd.apiKhong || 0) < 4 && dd.kiemLan < 12) return true;
      if (dd.kiemLan >= 6) {
        luu('dang_do', null);
        if (coApi() && (dd.apiKhong || 0) >= 4) {
          const s = capNhatTT((s1) => { const x = ttSlot(s1, dd.slot); x.lan = (x.lan || 0) + 1; x.tt = x.lan >= CAI_DAT.SO_LAN_THU ? 'loi' : 'cho'; x.thuLai = Date.now(); x.loi = 'đã bấm Đăng nhưng bài không lên trang'; });
          ghi(`Đã bấm Đăng ${dd.ten} nhưng kiểm nhiều lần vẫn không có bài → coi như chưa đăng${s.s[dd.slot].tt === 'loi' ? ' (đã thử đủ số lần — bỏ qua)' : ', sẽ tự đăng lại (có dò trùng trước khi bấm Đăng)'}`);
          if (s.s[dd.slot].tt === 'loi') await baoLoi(`❌ ${dd.ten}: bấm Đăng ${s.s[dd.slot].lan} lần nhưng bài không lên trang — đã bỏ qua`, 'loi_' + dd.slot);
        } else {
          capNhatTT((s1) => { Object.assign(ttSlot(s1, dd.slot), { tt: 'khong_ro', luc: dd.luc, lyDo: 'đã bấm Đăng nhưng không thấy bài trên trang' }); });
          await baoLoi(`❓ ${dd.ten}: đã bấm Đăng nhưng không thấy bài trên trang${coApi() ? '' : ' (chưa cài mã khoá)'} — script không đăng lại để tránh trùng, cần vào trang kiểm tra`, 'kr_' + dd.slot);
        }
      }
      return true;
    }
    if (dd.buoc === 'cho_binh_luan' || dd.buoc === 'dang_binh_luan') { // (6.22) đếm ngược trước khi comment: lần đầu 10 giây, các lần tiếp (sau tải lại) 3 giây
      if (document.visibilityState !== 'visible') return false;
      const kq = await batDemNguoc((dd.raSoat ? 'gửi bù comment ' : 'comment ') + (dd.ten || ''), dd.daDemCmt ? 3 : 10); if (kq !== 'ok') { choDD(dd, 'đếm ngược bị hoãn/huỷ (' + kq + ')'); return false; }
      if (!dd.daDemCmt) { dd.daDemCmt = true; luu('dang_do', dd); }
      return chayComment(dd);
    }
    return false;
  }
  // Facebook cho biết comment đã đủ chưa
  async function kiemCmtApi(id, can) {
    const cs = await cmtChiTietApi(id);
    const thieuText = (can.text || []).filter((t) => !cs.msgs.some((c) => khopCmt(c, t)));
    const thieuAnh = Math.max(0, (can.anh || []).length - cs.anh);
    return { ok: !thieuText.length && !thieuAnh, thieuText, thieuAnh, anhCo: cs.anh };
  }
  async function hoanTatSlot(dd, ghiChu = []) {
    if (dd.raSoat) { await hoanTatRaSoat(dd, [...new Set((dd.ghiChuTruoc || []).concat(ghiChu))]); return; }
    if (await lenLaiCmtThieu(dd)) return;
    ghiChu = [...new Set((dd.ghiChuTruoc || []).concat(dd.ghiChuLan1 || [], ghiChu))];
    let id = dd.id || '', link = dd.link || '', kq = null;
    const can = (trangThai().s[dd.slot] || {}).can || { text: (dd.cmtsGoc || dd.cmts || []).filter((x) => x.k === 'text').map((x) => x.v), anh: (dd.cmtsGoc || dd.cmts || []).filter((x) => x.k === 'anh').map((x) => x.v) };
    if (coApi()) {
      for (let lan = 0; lan < 3; lan++) {
        if (lan) await sleepThat(10000);
        try {
          if (!id) { const p = baiKhop(await baiTrenTrangApi(Date.now() - 864e5), dd.bai); if (!p) continue; id = p.id; link = p.link || link; }
          kq = await kiemCmtApi(id, can); if (kq.ok) break;
        } catch (e) { ghi('Không xác nhận được comment qua API: ' + e.message); break; }
      }
    }
    capNhatTT((s) => {
      const r = ttSlot(s, dd.slot);
      Object.assign(r, { id: id || r.id || '', link: link || r.link || '', ghiChu, soNhom: dd.soNhom || r.soNhom || 0 });
      r.kiem = (r.kiem || []).concat(kq ? [{ luc: Date.now(), ok: kq.ok }] : []);
      r.cmtOk = !!(kq && kq.ok);
    });
    luu('dang_do', null);
    if (dd.viaLink) { const kv = KENH_HT; setTimeout(() => { if (!dangBan && !lay('dang_do', null)) { datKenh(kv); veTrang(); } }, 4000); } // (6.19) về đúng trang của kênh vừa làm
    ghi(kq && kq.ok ? `Xong ${dd.ten}: đã đủ comment (Facebook xác nhận)` : `Xong ${dd.ten}${kq ? `: Facebook thấy còn thiếu ${kq.thieuText.length ? 'comment chữ' : ''}${kq.thieuText.length && kq.thieuAnh ? ' + ' : ''}${kq.thieuAnh ? kq.thieuAnh + ' comment ảnh' : ''} — lượt kiểm sau 10 phút sẽ gửi bù` : ' (chưa kiểm được comment — lượt kiểm sau sẽ xem lại)'}${ghiChu.length ? ' · lưu ý: ' + ghiChu.join('; ') : ''}`);
  }

  // =====================================================================
  //  KIỂM COMMENT: ngay sau đăng (~2 phút), 10 phút, 20 phút (tối đa 3 lần/bài) + 1 lượt 19:00
  // =====================================================================
  function mucKiem(s = trangThai()) { // các bài máy này lo comment
    const out = [];
    for (const it of LICH) {
      const r = s.s[it.k]; if (!r || !XONG.includes(r.tt) || !r.id) continue;
      if (r.may === 'CAO' ? !LA_CAO : r.may === 'GIAO' ? !LA_GIAO : false) continue; // máy nào đăng thì máy đó lo; bài máy khác/đăng tay → cả 2 máy (Máy Cao chậm hơn 30 phút)
      out.push({ key: it.k, ten: it.ten, r, laSlot: true });
    }
    for (const id of Object.keys(s.ngoai)) { const r = s.ngoai[id]; if (!r.id) continue; out.push({ key: 'n|' + id, ten: r.ten ? r.ten + ' (đăng trước)' : 'bài đăng tay ' + gioStr(new Date(r.luc)), r, laSlot: false }); }
    return out;
  }
  function luuKiem(key, f) { capNhatTT((s) => { const r = key.startsWith('n|') ? s.ngoai[key.slice(2)] : s.s[key]; if (r) f(r); }); }
  async function vongKiemCmt() {
    if (!MAY || tamDung() || !laTabChinh() || dangBan || lay('dang_do', null) || !coApi()) return false;
    const now = Date.now(); const mm = phutTrongNgay(new Date()); const cuoi = docGio(CAI_DAT.GIO_KIEM_CMT_CUOI);
    // hàng đợi gửi bù do bấm tay
    const hang = lay('hang_bu6', []) || [];
    let t = null;
    // (6.19.2) vừa kiểm xong mà đang chờ nhân sự rảnh để gửi bù → dùng lại kết quả vừa kiểm (không hỏi Facebook lại mỗi vài giây)
    for (const m of mucKiem()) { const b = m.r.buCho; if (!m.r.cmtOk && !m.r.baoBu && b && now - b.luc < 20 * 60000) { t = Object.assign({ cache: true }, m); break; } }
    if (!t) for (const m of mucKiem()) {
      const r = m.r; if (r.cmtOk || r.baoBu) continue; const n = (r.kiem || []).length; // (6.19.2) bài đã báo "cần comment tay" → không kiểm lại nữa (bấm "Kiểm lại" trên popup thì kiểm)
      { const kc = m.laSlot ? kenhCua(m.key) : (m.r.kenh || 1); // (6.20.5) kênh 2, 3: máy tự đăng đã comment + kiểm ngay lúc đăng → không kiểm định kỳ; bài máy khác/đăng tay chỉ kiểm 1 lần, và chỉ khi còn trống ≥ 15 phút trước bài kế tiếp (hạn chế rời Kênh 1)
        if (kc >= 1) { const khac0 = m.r.may === 'khac' || m.r.may === 'tay' || !m.laSlot; if (!khac0 || n >= 1 || r.kiem19) continue; const L0 = tinhLich(); const sap0 = L0.filter((x) => !x.ket && x.r.tt !== 'bo').map((x) => (x.r.ep ? Date.now() : Math.max(lucPhut(x.gioKH), lucBuKenh(L0, x)))).filter((v) => Number.isFinite(v)).sort((a, b) => a - b)[0]; if (sap0 != null && sap0 - now < 15 * 60000) continue; } }
      if (!coApiKenh(m.laSlot ? kenhCua(m.key) : (m.r.kenh || 1))) continue; // (6.19) kênh chưa có mã khoá đọc được trang → không kiểm qua Facebook được
      const moc = CAI_DAT.KIEM_CMT_SAU_PHUT[n];
      const khac = m.r.may === 'khac' || !m.laSlot; // bài máy khác / đăng tay: bắt đầu kiểm từ 10 phút (để máy kia comment xong trước)
      const tre = khac ? (LA_CAO ? 35 : 20) : 0; // Máy Cao kiểm bài máy khác chậm hơn để Máy Giao làm trước, tránh 2 máy cùng gửi bù (6.19.3: chờ lâu hơn để máy đã đăng comment xong — video có thể xử lý tới 20 phút)
      if (n < CAI_DAT.KIEM_CMT_TOI_DA && moc != null && now >= r.luc + (moc + tre) * 60000) { t = m; break; }
      if (false && mm >= cuoi + (khac && LA_CAO ? 30 : 0) && !r.kiem19 && now - r.luc > 10 * 60000) { t = Object.assign({ cuoi: true }, m); break; }
    }
    if (!t && hang.length) { const h = hang[0]; const m = mucKiem().find((x) => x.key === h.key); luu('hang_bu6', hang.slice(1)); if (m && !m.r.cmtOk) t = Object.assign({ tay: true }, m); }
    if (!t) return false;
    datKenh(t.laSlot ? kenhCua(t.key) : (t.r.kenh || 1)); // (6.19.3) bài soạn-ngày-mai của kênh 2, 3 đăng hôm nay: kiểm bằng đúng trang
    const r = t.r; const can = r.can || canCmt({ loai: 'video' }, {});
    let kq;
    if (t.cache) kq = r.buCho;
    else {
      try { kq = await kiemCmtApi(r.id, can); } catch (e) { ghi(`Kiểm comment ${t.ten}: chưa đọc được (${e.message})`); luuKiem(t.key, (x) => { x.kiem = (x.kiem || []).concat([{ luc: Date.now(), loi: true }]); if (t.cuoi) x.kiem19 = Date.now(); }); return false; }
      luuKiem(t.key, (x) => { x.kiem = (x.kiem || []).concat([{ luc: Date.now(), ok: kq.ok, tay: !!t.tay }]); x.cmtOk = kq.ok; if (t.cuoi) x.kiem19 = Date.now(); if (kq.ok) x.buCho = null; });
      ghi(`Kiểm comment ${t.ten} (lần ${(r.kiem || []).length + 1}${t.cuoi ? ', lượt 19:00' : t.tay ? ', bấm tay' : ''}): ${kq.ok ? 'đủ' : 'thiếu ' + moTaThieu(kq)}`);
    }
    if (kq.ok) return true;
    const bao = async (chu) => { luuKiem(t.key, (x) => { x.baoBu = Date.now(); x.buCho = null; }); await baoLoi(`${t.ten}: ${chu} — cần comment tay (thiếu ${moTaThieu(kq)})${r.link ? ' — ' + r.link : ''}`, 'bu_' + t.key); return true; };
    if ((r.guiBu || 0) >= CAI_DAT.GUI_BU_TOI_DA) return bao(`đã gửi bù ${r.guiBu} lần vẫn thiếu comment`);
    if ((r.buHong || 0) >= 2) return bao(`2 lần mở bài để gửi bù đều chưa comment được${r.buLyDo ? ' (' + r.buLyDo + ')' : ''}`);
    if (!tuDong() && !t.tay) return true;
    // gửi bù: cần chạm vào trang → chờ nhân sự rảnh + đếm ngược (trong lúc chờ giữ kết quả vừa kiểm, không hỏi lại Facebook)
    const giu = () => { if (!t.cache) luuKiem(t.key, (x) => { x.buCho = { luc: Date.now(), ok: false, thieuText: kq.thieuText, thieuAnh: kq.thieuAnh, anhCo: kq.anhCo }; }); return false; };
    if (!t.tay && (dangHoan() || !choNhanSu('bu_' + t.key, `gửi bù comment cho ${t.ten}`))) return giu();
    const cmts = kq.thieuText.map((v) => ({ k: 'text', v }));
    const anhCan = can.anh || []; anhCan.slice(Math.max(0, anhCan.length - kq.thieuAnh)).forEach((v) => cmts.push({ k: 'anh', v }));
    if (!cmts.length) { luuKiem(t.key, (x) => { x.buCho = null; }); return true; }
    { const k2 = await batDemNguoc('gửi bù comment ' + t.ten, t.tay ? 3 : 10); if (k2 !== 'ok') return giu(); } // (6.22)
    luuKiem(t.key, (x) => { x.buThu = (x.buThu || 0) + 1; x.buCho = null; }); // (6.19.2) chỉ tính "đã gửi bù" khi comment thật sự gửi được (xem hoanTatRaSoat)
    let text = r.text || ''; let lk = r.link;
    if (t.laSlot) { const nd = noiDungSlot(homNay(), t.key); text = nd.text || text; }
    const dd = { loai: 9, slot: t.key, ten: t.ten, ngay: homNay(), hang: 0, khoa: homNay() + '|rs|' + t.key, bai: text, id: r.id, link: lk || '', cmts, cmtIdx: 0, soAnh: 0, ghiChuTruoc: [], luc: Date.now(), batDauBu: Date.now(), buoc: 'cho_binh_luan', raSoat: true, rsKey: t.key, anhCoSan: kq.anhCo, daThaBai: true, daSuaNen: true, camXucCmt: { tt: 'bo' }, suaLan: 1, ngoai: true };
    if (lk && /^https?:/.test(lk)) dd.viaLink = lk;
    luu('dang_do', dd);
    ghi(`Gửi bù comment cho ${t.ten} (${cmts.length} comment) — mở thẳng bài để thấy bài mới nhất`);
    await sleep(1200);
    if (dd.viaLink) roiTrang(dd.viaLink); else roiTrang();
    return true;
  }
  const moTaThieu = (kq) => { const a = []; const cta = (kq.thieuText || []).filter((x) => /zalo\.me|>>>/.test(x)).length; const chu = (kq.thieuText || []).length - cta;
    if (chu) a.push(chu > 1 ? chu + ' comment chữ' : 'comment thông tin trang'); if (cta) a.push('comment mời nhóm Zalo'); if (kq.thieuAnh) a.push(kq.thieuAnh + ' comment ảnh'); return a.join(' + ') || 'comment'; };
  async function hoanTatRaSoat(dd, ghiChu) {
    let kq = null;
    const m = mucKiem().find((x) => x.key === dd.rsKey); const can = (m && m.r.can) || { text: [], anh: [] };
    if (coApi() && dd.id) for (let lan = 0; lan < 2; lan++) { if (lan) await sleepThat(10000); try { kq = await kiemCmtApi(dd.id, can); if (kq.ok) break; } catch (e) { break; } }
    const daGui = (dd.cmtIdx || 0) > 0; // (6.19.2) có gửi được ít nhất 1 comment mới tính là 1 lần gửi bù
    luuKiem(dd.rsKey, (x) => { if (kq) x.cmtOk = kq.ok; if (daGui) { x.guiBu = (x.guiBu || 0) + 1; x.buHong = 0; x.buLyDo = ''; } else { x.buHong = (x.buHong || 0) + 1; x.buLyDo = String((ghiChu || [])[0] || '').slice(0, 160); } });
    luu('dang_do', null);
    if (dd.viaLink) { const kv = KENH_HT; setTimeout(() => { if (!dangBan && !lay('dang_do', null)) { datKenh(kv); veTrang(); } }, 4000); } // (6.19) về đúng trang của kênh vừa làm
    ghi(kq && kq.ok ? `Gửi bù xong: ${dd.ten} đã đủ comment` : `Gửi bù cho ${dd.ten} xong nhưng chưa xác nhận đủ${ghiChu.length ? ' — ' + ghiChu.join('; ') : ''}`);
  }
  // bấm tay: kiểm comment bài mới nhất / 3 bài gần nhất / video trong 24 giờ qua (luôn hỏi Facebook danh sách mới nhất)
  async function kiemTay(kieu) {
    if (!coApi()) { ghi('Kiểm comment: chưa cài mã khoá Facebook'); throw new Error('chưa cài mã khoá Facebook'); }
    await doTrang('bấm kiểm comment');
    let ds;
    try { ds = await baiTrenTrangApi(Date.now() - 24 * 3600e3); } catch (e) { ghi('Kiểm comment: chưa đọc được bài trên trang (' + e.message + ')'); throw new Error('chưa đọc được bài trên trang (' + e.message + ')'); }
    const s = trangThai(); const theoId = {};
    for (const m of mucKiem(s)) theoId[m.r.id] = m;
    const tu = new Date(new Date().setHours(0, 0, 0, 0)).getTime();
    let chon = ds.slice().sort((a, b) => b.luc - a.luc);
    if (kieu === 'kiem24') chon = chon.filter((p) => laVideoApi(p) === true || /#manifest/i.test(p.text || ''));
    else chon = chon.filter((p) => p.luc >= tu).slice(0, kieu === 'kiem1' ? 1 : 3);
    // bài video trong 24h (cả hôm qua) chưa có trong danh sách → thêm vào "bài đăng tay" để kiểm
    capNhatTT((s1) => { for (const p of chon) if (!theoId[p.id] && !s1.ngoai[p.id] && (laVideoApi(p) === true || /#manifest/i.test(p.text || ''))) s1.ngoai[p.id] = { luc: p.luc, id: p.id, link: p.link || '', text: String(p.text || '').slice(0, 300), kiem: [], can: canCmt({ loai: 'video' }, {}) }; });
    const muc = mucKiem(); const ketQua = []; const can = [];
    for (const p of chon) {
      const m = muc.find((x) => x.r.id === p.id);
      if (!m) { ketQua.push(`${gioStr(new Date(p.luc))} bài chữ không thuộc lịch hôm nay → bỏ qua`); continue; }
      if (m.r.cmtOk) { ketQua.push(`${m.ten}: đã đủ comment`); continue; }
      can.push({ key: m.key });
      ketQua.push(`${m.ten}: sẽ kiểm${(m.r.kiem || []).length >= CAI_DAT.KIEM_CMT_TOI_DA ? ' (đã kiểm ' + m.r.kiem.length + ' lần, bấm tay vẫn kiểm)' : ''}`);
    }
    if (kieu !== 'kiem1') { // (6.19.2) video kênh 2, 3 hôm nay cũng kiểm
      const s2 = trangThai();
      for (const it of LICH.filter((x) => (x.kenh || 1) > 1)) {
        const r = s2.s[it.k]; if (!r || !XONG.includes(r.tt) || !r.id) continue;
        if (r.cmtOk) { ketQua.push(`${it.ten}: đã đủ comment`); continue; }
        if (!coApiKenh(it.kenh)) { ketQua.push(`${it.ten}: chưa có mã đọc trang ${tenKenh(it.kenh)}`); continue; }
        luuKiem(it.k, (x) => { x.baoBu = 0; x.buHong = 0; x.buCho = null; }); can.push({ key: it.k }); ketQua.push(`${it.ten}: sẽ kiểm`);
      }
    }
    luu('hang_bu6', (lay('hang_bu6', []) || []).concat(can.filter((x) => !(lay('hang_bu6', []) || []).some((y) => y.key === x.key))));
    ghi(`Kiểm comment (${kieu === 'kiem1' ? 'bài mới nhất' : kieu === 'kiem3' ? '3 bài gần nhất' : 'video trong 24 giờ qua'}): ${ketQua.join(' · ') || 'không có bài nào'}`);
  }

  // =====================================================================
  //  CHẠY THỬ: script soạn sẵn rồi dừng trước nút Đăng → người bấm Đăng → script comment tiếp
  // =====================================================================
  let hopThayTrangNay = false, hopMatTuLuc = 0; // trạng thái hộp soạn kể từ lúc tải trang này (không lưu, F5 là về 0)
  async function tiepChoTay() {
    const p = lay('cho_tay6', null); if (!p) return false;
    if (!laTabChinh() || tamDung() || lay('dang_do', null) || dangBan) return true;
    if (p.ngay !== homNay()) { luu('cho_tay6', null); return true; }
    { const itP = lichNgay(p.mai ? ngayMai() : homNay()).find((x) => x.k === p.slot); datKenh(itP ? itP.kenh : kenhCua(p.slot)); } // (6.19.2) bài soạn sẵn của kênh 2, 3 → kiểm đúng trang
    const hopMo = hopDangDo() || hopSoanBai() || ganManHinh();
    if (hopMo) hopThayTrangNay = true; // (6.8) tính theo lần tải trang này: F5 xong mà không còn hộp → 45 giây là bỏ
    if (hopMo && !p.mai && !chanLark() && Date.now() - (p.khoaLuc || p.luc) > NHO_KHOA_PHUT * 60000) { p.khoaLuc = Date.now(); luu('cho_tay6', p); ghiKhoaO(p.slot, true).catch(() => {}); } // (6.28) bản soạn còn chờ bấm Đăng → 15 phút ghi lại ô giữ chỗ (khoá không hết hạn ở phút 40)
    if (hopMo) {
      if (Date.now() - p.luc > 45 * 60000) { luu('cho_tay6', null); capNhatTT((s) => { Object.assign(ttSlot(s, p.slot), p.soan ? { tt: 'cho', thuLai: p.mai ? 0 : Date.now() + 15 * 60000, daSoan: 0 } : { tt: 'bo', lyDo: 'chạy thử: quá 45 phút chưa bấm Đăng' }); }, p.mai || homNay()); ghi(`${p.ten} ${p.soan ? 'đã soạn' : 'chạy thử'}: quá 45 phút chưa bấm Đăng → ${p.soan ? 'để lại hàng chờ' : 'bỏ lượt này'}`); }
      return true;
    }
    if (!p.dongLuc) { p.dongLuc = Date.now(); luu('cho_tay6', p); }
    if (Date.now() - (p.doLuc || 0) < 15000) return true;
    p.doLuc = Date.now(); luu('cho_tay6', p);
    let thay = null;
    if (!p.video && !p.mai) { const x = timBai(p.text); if (x) thay = { link: linkBai(x.khung), id: '' }; }
    if (!thay && coApi()) { try { const q = baiKhop(await baiTrenTrangApi(p.luc - 5 * 60000), p.text); if (q) thay = q; } catch (e) { /* */ } }
    if (!thay && p.mai && !p.video) { const x = timBai(p.text); if (x) thay = { link: linkBai(x.khung), id: '' }; }
    if (!thay && p.video && !coApi() && dungTrang() && Date.now() - (p.domLuc || 0) > 60000) { p.domLuc = Date.now(); luu('cho_tay6', p); const co = await daCoTrenTrangDom(p.text); if (co) thay = { link: co.link || '', id: '' }; } // (6.19.3) kênh chưa có mã khoá: nhìn trang
    if (!thay) {
      if (!hopMatTuLuc) hopMatTuLuc = Date.now();
      const gioiHan = hopThayTrangNay ? (p.video ? 20 : 3) * 60000 : 45000; // (6.19.3) video có thể xử lý tới 20 phút // trang vừa tải lại mà không còn hộp soạn (F5) → 45 giây là coi như mất
      if (Date.now() - (hopThayTrangNay ? p.dongLuc : hopMatTuLuc) > gioiHan) { luu('cho_tay6', null); if (!hopThayTrangNay) { ghi(`${p.ten}: hộp soạn không còn trên trang (trang đã tải lại?) và chưa thấy bài → bỏ bản soạn, bấm Soạn lại nếu cần`); thongBaoMay(`${p.ten}: bản soạn đã mất`, 'Trang đã tải lại nên hộp soạn không còn. Bấm Soạn lại nếu cần.'); } capNhatTT((s) => { Object.assign(ttSlot(s, p.slot), p.soan ? { tt: 'cho', thuLai: p.mai ? 0 : Date.now() + 15 * 60000, daSoan: 0 } : { tt: 'bo', lyDo: 'chạy thử: hộp đã đóng mà không thấy bài (đã huỷ?)' }); }, p.mai || homNay()); if (p.mai) ghi(`${p.ten}: hộp soạn thử đã đóng, không thấy bài → coi như bạn đã huỷ (ngày mai vẫn đăng bình thường)`); if (hopThayTrangNay) ghi(`${p.ten}: hộp soạn đã đóng mà không thấy bài → coi như huỷ${p.soan ? ' (bài để lại hàng chờ)' : ''}`); }
      return true;
    }
    luu('cho_tay6', null);
    if (p.mai) { // bài của ngày mai được bấm Đăng hôm nay: ghi vào "đăng ngoài lịch" hôm nay để kiểm/gửi comment, và đánh dấu ngày mai đã đăng (không đăng lại)
      const can = (lay('ngay6_' + p.mai, { s: {} }).s[p.slot] || {}).can || canCmt({ loai: 'video' }, {});
      const id = thay.id || 'mai_' + p.slot + '_' + Date.now();
      capNhatTT((s) => { s.ngoai[id] = { luc: thay.luc || Date.now(), id: thay.id || '', link: thay.link || '', text: String(p.text || '').slice(0, 300), kiem: [], can, giu: true, mai: p.mai, ten: p.ten, kenh: KENH_HT }; });
      if (p.video && p.loai === 4) await ghiKetQuaVideo({ loai: 4, slot: p.slot, ten: p.ten, ngay: p.mai, hang: p.hang, bai: p.text, link: thay.link || '' }); // (6.19.3) ghi "ĐÃ ĐĂNG" vào dòng ngày mai → máy kia ngày mai cũng không đăng lại
      capNhatTT((s) => { Object.assign(ttSlot(s, p.slot), { tt: 'xong', luc: Date.now(), may: 'tay', link: thay.link || '', id: thay.id || '', kiem: [], cmtOk: false, lyDo: 'đã đăng trước (soạn thử hôm ' + homNay().slice(0, 5).replace('-', '/') + ')' }); }, p.mai);
      ghi(`${p.ten} đã được bấm Đăng hôm nay → ghi là bài đăng ngoài lịch (script kiểm và gửi bù comment sau ${CAI_DAT.KIEM_CMT_SAU_PHUT[0] + 10} phút); ngày mai không đăng lại`);
      thongBaoMay(`${p.ten} đã lên trang`, 'Ngày mai script sẽ không đăng lại bài này. Comment được kiểm và gửi bù sau ít phút.');
      return true;
    }
    ghi(`Thấy ${p.ten} đã được bấm Đăng → script comment tiếp`);
    const dd = { slot: p.slot, loai: p.loai, ten: p.ten, ngay: p.ngay, hang: p.hang, khoa: p.ngay + '|' + p.slot, bai: p.text, cmts: p.cmts, cmtIdx: 0, soAnh: 0, ghiChuTruoc: [], id: thay.id || '', link: thay.link || '', lucApi: thay.luc, ngoai: !!p.video, viaLink: p.video ? (thay.link || '') : '' };
    if (p.video && p.loai === 4) await ghiKetQuaVideo(dd);
    await sauKhiDangSlot(dd);
    return true;
  }

  // =====================================================================
  //  ĐỌC SHEET THEO LỊCH + TẢI SẴN ĐỒ ĐĂNG (Máy Giao)
  // =====================================================================
  async function docSheetTheoLich() {
    if (!MAY || chanDocLark()) return false; // (6.30) API hết lượt nhưng có dữ liệu Lark web → vẫn đọc theo lịch
    const mm = phutTrongNgay(new Date()); const ngay = homNay(); const d = duLieu();
    const k = 'doc6_' + ngay; const st = lay(k, {}) || {};
    const lech = (g) => docGio(g) + (parseInt(bam(ngay + g + MAY), 36) % 9); // lệch 0–8 phút cố định trong ngày
    const thu = async (loai) => { st[loai] = Date.now(); luu(k, st); try { await docDuLieu(loai); st[loai + 'Ok'] = Date.now(); luu(k, st); if (loai === 'chot') luu('tai6', null); } catch (e) { ghi(`Đọc Lark sheet (${loai}) lỗi: ${e.message} — 30 phút sau thử lại`); } veBang(); return true; };
    if (LA_CAO) { // (6.25) Máy Cao (dự phòng): chỉ đọc sheet lúc 16:00 (kịp nhắc bổ sung bài ngày mai); khi phải đăng thay thì đọc thêm 1 lần ở bước đăng
      if (mm >= lech('16:00') && mm < 22 * 60 && !st.cao16Ok && Date.now() - (st.cao16 || 0) > 30 * 60000) return thu('cao16');
      return false;
    }
    if (mm >= lech(CAI_DAT.GIO_DOC_CHOT) && mm < 22 * 60 && !st.chotOk && Date.now() - (st.chot || 0) > 30 * 60000) return thu('chot');
    if (!LA_CAO && mm >= lech(CAI_DAT.GIO_DOC_NHE) && mm < docGio(CAI_DAT.GIO_DOC_CHOT) && !st.nheOk && Date.now() - (st.nhe || 0) > 30 * 60000) return thu('nhe');
    const coHomNay = d && d.ngay && d.ngay[ngay];
    // (6.10) hôm nay có bài bị bỏ vì thiếu nội dung → mỗi giờ đọc lại sheet 1 lần (06:00–21:00) xem đã bổ sung chưa
    const coThieu = Object.values(trangThai().s).some((r) => r.tt === 'thieu');
    // (6.25) bài thiếu nội dung: chỉ đọc lại khi có bài thiếu sắp tới giờ (≤ 30 phút), mỗi bài tối đa 1 lần — không đọc mỗi giờ nữa
    const sapThieu = tinhLich().find((x) => !x.ket && (x.kenh || 1) >= 1 && typeof x.gioKH === 'number' && lucPhut(x.gioKH) - Date.now() <= 30 * 60000 && lucPhut(x.gioKH) - Date.now() > -60 * 60000 && noiDungSlot(ngay, x.k).thieu.length && !(st.thieuSlot || []).includes(x.k));
    if (sapThieu && mm >= 6 * 60 && mm < 22 * 60 && Date.now() - (d ? d.luc : 0) > 20 * 60000) { st.thieuSlot = (st.thieuSlot || []).concat(sapThieu.k); luu(k, st); return thu('thieuGio'); }
    if (!coHomNay && mm >= 6 * 60 && mm < 22 * 60 && Date.now() - (st.thieu || 0) > 30 * 60000) return thu('thieu');
    // dữ liệu đang giữ là của hôm qua (đọc trước 0h, chưa biết các sửa đổi mới) → sáng sớm đọc lại 1 lần cho đúng
    if (d && ngayStr(new Date(d.luc)) !== ngay && mm >= 5 * 60 && mm < 22 * 60 && !st.sang && Date.now() - (st.thieu || 0) > 30 * 60000) { st.sang = Date.now(); luu(k, st); return thu('sang'); }
    return false;
  }
  function dsTaiSan() { // (6.29) đồ cần tải sẵn: hôm nay (bài chưa đăng) + 2 ngày tới (ảnh, video, video manifest) — Lark hỏng/hết lượt vẫn đăng đủ 2 ngày
    const d = duLieu(); if (!d || !d.ngay) return [];
    const out = []; const s = trangThai();
    const cacNgay = [homNay(), ngayMai(), ngayStr(congNgay(2))].filter((n) => d.ngay[n]);
    const them = (k, x) => { if (!out.some((y) => y.k === k)) out.push(Object.assign({ k }, x)); };
    if (d.chung) { if (d.chung.co) them('tep|' + d.chung.co, { loai: 'anh', token: d.chung.co }); (d.chung.pool || []).concat(d.chung.poolK || []).forEach((t) => them('tep|' + t, { loai: 'anh', token: t })); }
    for (const ngay of cacNgay) {
      for (const it of (ngay === homNay() ? LICH : lichNgay(ngay, d))) { // (6.19.3) ngày mai: theo lịch của ngày mai (có thể có bài thêm)
        if (ngay === homNay()) { const r = s.s[it.k]; if (r && KET.includes(r.tt)) continue; }
        const nd = noiDungSlot(ngay, it.k, d); if (nd.thieu && nd.thieu.length && !nd.tep && !nd.anh) continue;
        (Array.isArray(nd.anh) ? nd.anh : []).forEach((t) => them('tep|' + t, { loai: 'anh', token: t }));
        (nd.anhCmt || []).forEach((t) => them('tep|' + t, { loai: 'anh', token: t }));
        if (it.loai === 'video' && nd.tep && nd.tep.fileToken) them('tep|' + nd.tep.fileToken, { loai: 'video', tep: nd.tep, ngay }); // (6.29) video: tải sẵn cả 2 ngày tới (qua Lark web, không tốn lượt)
        if (it.loai === 'manifest' && nd.anh && ngay !== ngayStr(congNgay(2))) them(`mf|${ngay}|${it.so}|${nd.anh}`, { loai: 'mf', ngay, so: it.so, anh: nd.anh });
      }
    }
    return out;
  }
  async function taiSan() { // (6.25) ảnh tải sẵn từ đầu ngày; video chỉ tải trước giờ đăng 90 phút; mỗi file chỉ tải sẵn 1 lần (lỗi thì để lúc đăng tải 1 lần nữa); nhiều file → gộp 1 lượt Lark
    if (tamDung() || !laTabChinh() || dangBan || lay('dang_do', null)) return false; // (6.29) cả 2 máy tải sẵn (máy dự phòng cũng có đủ file); hết lượt Lark vẫn tải qua Lark web
    const mm = phutTrongNgay(new Date()); if (mm < 5 * 60 + 30 || mm > 22 * 60 + 30) return false;
    if (LA_CAO && larkWebNghi()) return false; // (6.29) Máy Cao chỉ tải sẵn qua Lark web (không tốn lượt); Lark web đang hỏng thì để lúc đăng mới tải
    { const s0 = trangThai(); if (LICH.some((it) => { const r = s0.s[it.k]; return !(r && KET.includes(r.tt)) && typeof s0.gio[it.k] === 'number' && Math.abs(lucPhut(s0.gio[it.k]) - Date.now()) < 5 * 60000; })) return false; } // (6.29) sắp tới giờ đăng (±5 phút) → không tải file lớn, để nhịp đăng chạy trước
    let st = lay('tai6', null) || {}; if (st.ngay !== homNay()) st = { ngay: homNay() };
    if (st.xongLuc && Date.now() - st.xongLuc < 10 * 60000) return false;
    if (st.loiLuc && Date.now() - st.loiLuc < 10 * 60000) return false;
    const boQua = new Set(st.boQua || []);
    const ds = dsTaiSan(); const can = []; let daCo = 0;
    for (const x of ds) { const c = await khoLay(x.k); if (c && c.blob && c.blob.size > 500) daCo++; else if (!boQua.has(x.k)) can.push(x); }
    if (!can.length) { const daBao = st.baoXong === ds.length; luu('tai6', Object.assign(st, { xongLuc: Date.now(), n: ds.length, baoXong: ds.length })); if (ds.length && !daBao) { const kd = await khoDon(); ghi(`Tải sẵn xong ${daCo}/${ds.length} file${boQua.size ? ` (${boQua.size} file lỗi → tải lúc đăng)` : ''} (kho đang giữ ${kd.n} file, ~${(kd.tong / 1048576).toFixed(0)} MB${kd.xoa ? `, đã dọn ${kd.xoa} file cũ` : ''})`); } return false; }
    const tep = can.filter((x) => x.loai === 'anh' || x.loai === 'video').slice(0, 5);
    const danhDau = (ks, e) => { st = Object.assign(lay('tai6', null) || st, { ngay: homNay() }); st.boQua = Array.from(new Set((st.boQua || []).concat(ks))).slice(-60); if (e) { st.loiLuc = Date.now(); st.loi = e; } st.xongLuc = 0; luu('tai6', st); };
    luu('tai6', Object.assign(st, { dang: can[0].k, daCo, tong: ds.length, luc: Date.now(), xongLuc: 0 }));
    if (tep.length >= 2 && lay('lo_batch6', '') !== homNay() && !chanLark() && larkWebNghi()) { // (6.29) gộp lượt API chỉ khi Lark web đang hỏng
      const kq = await taiNhieuTepLark(tep.map((x) => (x.loai === 'video' ? { token: x.tep.fileToken, ten: 'video "' + x.tep.ten + '"', loai: 'video', size: x.tep.size, k: x.k } : { token: x.token, ten: 'ảnh', loai: 'anh', k: x.k })));
      if (kq.loiBatch) return true; // (6.25) Lark không cho xin link tạm (lỗi xin link, chưa tải gì) → lượt sau tải lẻ ngay, không tính là file lỗi
      if (kq.hong.length) danhDau(kq.hong.map((x) => x.k), kq.hong.length + ' file lỗi khi tải nhiều tệp');
      if (!kq.ok.length && kq.hong.length === tep.length && lay('lo_batch6', '') === homNay()) { /* Lark không cho tải nhiều → lượt sau tải lẻ */ st = lay('tai6', null) || st; st.boQua = (st.boQua || []).filter((k) => !kq.hong.some((x) => x.k === k)); luu('tai6', st); }
      return true;
    }
    const con = tep[0] || can[0];
    try {
      if (con.loai === 'anh') await taiTepLark(con.token, { ten: 'ảnh', loai: 'anh' });
      else if (con.loai === 'video') await taiTepLark(con.tep.fileToken, { ten: 'video "' + con.tep.ten + '"', loai: 'video', size: con.tep.size, timeout: 300000 });
      else if (con.loai === 'mf') await videoManifest(con.ngay, con.so, con.anh);
    } catch (e) {
      ghi('Tải sẵn: ' + (con.loai === 'video' ? 'video' : con.loai === 'mf' ? 'video manifest' : 'ảnh') + ' chưa tải được (' + e.message + ') — không tải lại, lúc đăng sẽ tải 1 lần nữa');
      danhDau([con.k], e.message);
    }
    return true;
  }


  // =====================================================================
  //  BÁO CÁO CUỐI NGÀY (nhóm Marketing) — 1 tin khi xong các bài; chưa đủ thì 21:45
  // =====================================================================
  function noiDungBaoCao(s) {
    const d = new Date(); const ngayBC = `${d.getDate()}/${d.getMonth() + 1}/${d.getFullYear()}`;
    const ds = LICH.map((it) => ({ it, r: s.s[it.k] || { tt: 'cho' } }));
    const thuTu = (x) => (/^b/.test(x.it.loai) ? 0 : x.it.loai === 'manifest' ? 1 : 2) * 100 + LICH.indexOf(x.it); // (6.20.7) xếp theo loại bài: Bài viết → Manifest → Video
    const xong = ds.filter((x) => XONG.includes(x.r.tt)).sort((a, b) => thuTu(a) - thuTu(b));
    const chua = ds.filter((x) => !XONG.includes(x.r.tt));
    const dongCua = (ds1, ds2) => ds1.map((x) => `${gioNgan(x.r.luc)} ${x.it.tenBC}: ${/^https?:/.test(x.r.link || '') ? x.r.link : '(chưa lấy được link)'}`).concat(ds2.map((x) => `--h-- ${x.it.tenBC}: chưa đăng${x.r.lyDo ? ' (' + x.r.lyDo + ')' : x.r.loi ? ' (' + x.r.loi + ')' : ''}`));
    let dong;
    if (!LICH.some((it) => (it.kenh || 1) > 1)) dong = dongCua(xong, chua);
    else { dong = []; for (const c of KENH_ALL) { const a = xong.filter((x) => (x.it.kenh || 1) === c), b = chua.filter((x) => (x.it.kenh || 1) === c); if (!a.length && !b.length) continue; dong.push(`— ${tenKenhDai(c)}: ${a.length}/${a.length + b.length} bài`); dong.push(...dongCua(a, b)); } } // (6.19) chia theo kênh
    const dau = chua.length ? `Báo cáo ${ngayBC}: đã đăng ${xong.length}/${LICH.length} bài fb (chưa đăng: ${chua.map((x) => x.it.ten).join(', ')}):` : `Báo cáo ${ngayBC}: đã đăng xong ${LICH.length} bài fb:`;
    return dau + '\n' + dong.join('\n');
  }
  // (6.20.7) báo cáo dạng thẻ: mỗi kênh, mỗi loại bài 1 hàng (Bài viết → Manifest → Video), link bấm được
  function theBaoCao(s) { // (6.25) gọn: dòng tổng to, mỗi kênh 1 khối, mỗi loại 1 dòng "B1 06:53 · B2 10:16" (tên bấm mở bài)
    const d = new Date(); const ngayBC = `${d.getDate()}/${d.getMonth() + 1}/${d.getFullYear()}`;
    const ds = LICH.map((it, i) => ({ it, i, r: s.s[it.k] || { tt: 'cho' } }));
    const nX = ds.filter((x) => XONG.includes(x.r.tt)).length; const du = nX === ds.length;
    const nhom = (x) => (/^b/.test(x.it.loai) ? 0 : x.it.loai === 'manifest' ? 1 : 2);
    const ma = (x) => { const g = nhom(x); const so = /^b(\d+)/.exec(x.it.k) ? +/^b(\d+)/.exec(x.it.k)[1] : (x.it.so || 0) + 1; return (g === 0 ? 'B' : g === 1 ? 'M' : 'V') + so + (x.it.them ? ' (thêm)' : ''); };
    const muc = (x) => { if (XONG.includes(x.r.tt)) return (/^https?:/.test(x.r.link || '') ? `[${ma(x)}](${x.r.link})` : ma(x)) + ` ${gioNgan(x.r.luc)}`; return `<font color='red'>${ma(x)} chưa đăng</font>`; };
    const icon = { 1: '📘', 2: '📗', 3: '📙', 4: '📕' };
    const el = [{ tag: 'markdown', text_size: 'heading', content: `**${du ? '✅' : '⚠️'} Đã đăng ${nX}/${ds.length} bài**` }];
    for (const c of KENH_ALL) {
      const a = ds.filter((x) => (x.it.kenh || 1) === c); if (!a.length) continue;
      const xc = a.filter((x) => XONG.includes(x.r.tt)).length; const hang = [];
      for (const [g, ten] of [[0, 'Bài viết'], [1, 'Manifest'], [2, 'Video']]) { const b = a.filter((x) => nhom(x) === g).sort((p, q) => p.i - q.i); if (b.length) hang.push(`**${ten}:** ${b.map(muc).join('  ·  ')}`); }
      el.push({ tag: 'hr' }, { tag: 'markdown', content: `${icon[c] || '📘'} **${CAI_DAT.KENH[c].anSo ? CAI_DAT.KENH[c].ngan : 'Kênh ' + c + ' · ' + CAI_DAT.KENH[c].ngan}**  (${xc}/${a.length})\n${hang.join('\n')}` });
    }
    return { msg_type: 'interactive', card: { config: { wide_screen_mode: true }, header: { template: du ? 'green' : 'orange', title: { tag: 'plain_text', content: `Báo cáo đăng bài fb · ${ngayBC}` } }, elements: el } };
  }

  // (6.25) 12:00: bài buổi sáng chưa lên trang (lỗi / bị bỏ / trễ > 30 phút) → 1 tin nhóm lỗi để kịp cứu, không đợi tới tối
  // (6.26.5) tin tổng kết gọn: mỗi bài 1 dòng "• giờ hẹn · tên — lý do ngắn"
  function lyDoNgan(x) {
    const r = x.r || {}; let t = String(r.loi || '');
    if (!t) { const m = String(r.lyDo || '').match(/\((.*)\)\s*$/); t = m ? m[1] : (/quá .*chưa đăng/.test(r.lyDo || '') ? '' : String(r.lyDo || '')); }
    if (r.tt === 'thieu' || /^thiếu|sheet thiếu/.test(t)) return 'sheet thiếu nội dung';
    if (/tư cách|nút chuyển/i.test(t)) return 'không chuyển được tư cách sang trang';
    if (/Cài đặt thước phim/.test(t)) return 'kẹt ở màn Cài đặt thước phim';
    if (/nhóm/.test(t)) return 'lỗi bước chọn nhóm';
    if (/Lark/.test(t)) return 'Lark lỗi';
    if (!t) return r.tt === 'cho' || r.tt === 'bo' ? 'máy chưa đăng tới' : 'chưa đăng';
    return t.length > 60 ? t.slice(0, 58) + '…' : t;
  }
  const tinTongKet = (tieu, ds, cuoi) => `🚨 ${tieu} — ${ds.length} bài chưa lên trang\n` + ds.slice().sort((a, b) => (a.gioKH || 0) - (b.gioKH || 0)).map((x) => `• ${typeof x.gioKH === 'number' ? phutStr(x.gioKH) : '--:--'}  ${x.ten} — ${lyDoNgan(x)}`).join('\n') + (cuoi ? '\n' + cuoi : '');
  // (6.26.5) Máy Cao chỉ gửi tin tổng kết khi Máy Giao có vẻ không chạy (không có bài nào của máy khác trong 3 giờ qua) → tránh 2 máy gửi trùng
  const caoNenBao = (L) => { const t = Math.max(0, ...L.filter((x) => x.xong && x.r.may && x.r.may !== 'CAO' && x.r.may !== 'tay').map((x) => x.r.luc || 0)); return !t || Date.now() - t > 3 * 3600e3; };
  async function tongKet12() {
    if (!MAY || !laTabChinh() || !trongGioNhan()) return false;
    const mm = phutTrongNgay(new Date()); if (mm < 12 * 60 || mm >= 13 * 60) return false;
    const k = 'tk12_' + homNay(); if (lay(k, 0)) return false;
    const L = tinhLich(); if (LA_CAO && (!L.some((x) => x.r.may === 'CAO') || !caoNenBao(L))) return false; // Máy Cao chỉ báo khi chính nó đang đăng thay và Máy Giao không chạy
    luu(k, Date.now());
    const ds = L.filter((x) => !x.xong && typeof x.gioKH === 'number' && x.gioKH < 12 * 60 && (x.ket || lucPhut(x.gioKH) < Date.now() - 30 * 60000));
    if (!ds.length) { ghi('Tổng kết 12:00: các bài buổi sáng đã lên đủ'); return false; }
    await baoLoi(tinTongKet('Tổng kết 12:00 (buổi sáng)', ds, '→ cần xử lý ngay'), 'tong12_' + homNay());
    return true;
  }
  async function xemDauBaoCao() { // (6.28.9) đọc ô Z2: 'roi' = máy kia đã gửi báo cáo hôm nay · 'chua' · 'loi' (đọc thử 2 lần)
    for (let lan = 0; lan < 2; lan++) {
      try { const m = String(chuO(await docO(CAI_DAT.TAB_BAI, CAI_DAT.O_BAO_CAO)) || ''); if (m.startsWith('BAOCAO|' + homNay() + '|')) { capNhatTT((x) => { x.baoCao = Date.now(); x.baoCaoMay = m.split('|')[2]; }); ghi(`Báo cáo ngày: ${m.split('|')[2] === MAY ? 'máy này' : 'máy kia'} đã gửi rồi (ô ${CAI_DAT.O_BAO_CAO}) → không gửi lại`); return 'roi'; } return 'chua'; }
      catch (e) { ghi('Báo cáo ngày: chưa đọc được ô ' + CAI_DAT.O_BAO_CAO + ' (' + e.message + ')' + (lan ? '' : ' → đọc lại sau 5 giây')); if (!lan) await sleep(5000); }
    }
    return 'loi';
  }
  async function baoCaoNgay() {
    if (!MAY || !laTabChinh()) return false;
    const s = trangThai(); if (s.baoCao) return false;
    const L = tinhLich(s); const mm = phutTrongNgay(new Date());
    const tatCaKet = L.every((x) => x.ket); const du9 = L.every((x) => x.xong);
    const cuoi = L.filter((x) => x.xong).sort((a, b) => (b.r.luc || 0) - (a.r.luc || 0))[0];
    let gui = false;
    if (du9 && cuoi && cuoi.r.may === MAY) {
      const thieuLink = L.some((x) => (x.kenh || 1) === 1 && !/^https?:/.test(x.r.link || ''));
      if (thieuLink && Date.now() - (cuoi.r.luc || 0) < 10 * 60000) { if (Date.now() - (window.__smhLinkDo || 0) > 60000) { window.__smhLinkDo = Date.now(); await doTrang('lấy link cho báo cáo'); } return false; }
      { // (6.28.9) 2 máy có thể cùng thấy "đủ bài, bài cuối do mình đăng" khi danh sách 2 máy lệch nhau → luôn xem ô Z2 trước; Máy Cao chờ thêm 5 phút sau bài cuối (nhường Máy Giao gửi trước)
        if (LA_CAO && Date.now() - (cuoi.r.luc || 0) < 5 * 60000) return false;
        if (Date.now() - (s.baoCaoThu || 0) < (LA_CAO ? 15 : 3) * 60000) return false;
        capNhatTT((x) => { x.baoCaoThu = Date.now(); });
        const z = await xemDauBaoCao(); if (z === 'roi') return false;
        if (LA_CAO && z === 'loi' && mm < docGio(CAI_DAT.GIO_BAO_CAO_THIEU) + 20) { ghi('Báo cáo ngày: chưa xem được ô ' + CAI_DAT.O_BAO_CAO + ' → Máy Cao chờ tới ' + gioStr(new Date(new Date().setHours(0, docGio(CAI_DAT.GIO_BAO_CAO_THIEU) + 20, 0, 0))) + ' (Máy Giao gửi trước), quá giờ đó vẫn chưa ai gửi thì Máy Cao gửi'); return false; }
      }
      gui = true;
    } else if ((LA_GIAO && mm >= docGio(CAI_DAT.GIO_BAO_CAO_THIEU)) || (LA_CAO && L.some((x) => x.r.may === 'CAO') && mm >= docGio(CAI_DAT.GIO_BAO_CAO_THIEU) + 20)) { // Máy Cao chỉ báo cáo khi hôm nay chính nó đã đăng thay
      if (!tatCaKet && mm < docGio(L.some((x) => !x.ket && (x.them || x.baiThem)) ? CAI_DAT.GIO_CHOT_THEM : CAI_DAT.GIO_CHOT)) return false; // (6.19.3) còn bài thêm (được tới 22:30) thì chờ
      if (Date.now() - (s.baoCaoThu || 0) < 15 * 60000) return false;
      capNhatTT((x) => { x.baoCaoThu = Date.now(); });
      if ((await xemDauBaoCao()) === 'roi') return false;
      await doTrang('trước báo cáo ngày');
      gui = true;
    }
    if (!gui || !trongGioNhan()) return false;
    { // (6.25) thiếu bài: gửi nhóm lỗi TRƯỚC (chi tiết lý do), nhóm Marketing chỉ nhận kết quả
      const L3 = tinhLich(trangThai()); const thieu = L3.filter((x) => !x.xong);
      const daTong = Object.keys(lay('tin6_' + homNay(), {}) || {}).some((k) => /^tongtoi_/.test(k));
      if (thieu.length && !daTong) await baoLoi(tinTongKet(`Tổng kết cuối ngày (${L3.length - thieu.length}/${L3.length} bài đã lên)`, thieu), 'tongtoi_bc');
    }
    const ok = await guiLark('baocao', noiDungBaoCao(trangThai()), { khoa: 'baocao_' + homNay(), the: theBaoCao(trangThai()) });
    if (ok) { capNhatTT((x) => { x.baoCao = Date.now(); x.baoCaoMay = MAY; }); try { await ghiO(CAI_DAT.TAB_BAI, CAI_DAT.O_BAO_CAO, `BAOCAO|${homNay()}|${MAY}|${Date.now()}`); } catch (e) { ghi('Chưa ghi được dấu báo cáo vào ô ' + CAI_DAT.O_BAO_CAO + ': ' + e.message); } }
    return true;
  }

  // =====================================================================
  //  YÊU CẦU TỪ POPUP (tab nào bấm cũng được, tab đang làm việc sẽ làm)
  // =====================================================================
  function yeuCau(loai, them) {
    const ds = (lay('yc6', []) || []).filter((x) => Date.now() - x.luc < 10 * 60000 && x.loai !== loai);
    ds.push(Object.assign({ loai, luc: Date.now(), tu: MA_TAB }, them || {}));
    luu('yc6', ds); luu('yc6_kq_' + loai, { tt: 'cho', luc: Date.now() });
    ghi('Bấm: ' + (TEN_YC[loai] || loai)); veBang();
    setTimeout(nhip, 300);
  }
  const TEN_YC = { docsheet: 'Đọc lại Lark sheet', kiem1: 'Kiểm comment bài mới nhất', kiem3: 'Kiểm comment 3 bài gần nhất', kiem24: 'Kiểm comment video 24 giờ qua', dotrang: 'Kiểm tra bài trên trang', taoanh: 'Tạo ảnh manifest', khanhthu: 'Kiểm thử Khanh Trầm Hương', tinthu: 'Gửi tin thử', taisan: 'Tải sẵn đồ đăng' };
  async function xuLyYeuCau() {
    const ds = lay('yc6', []) || []; if (!ds.length || !laTabChinh()) return false;
    luu('yc6', []);
    for (const y of ds) {
      if (Date.now() - y.luc > 10 * 60000) continue;
      luu('yc6_kq_' + y.loai, { tt: 'dang', luc: Date.now() }); if (hdChay) { hdChay.ten = 'Đang ' + (TEN_YC[y.loai] || 'làm việc bạn vừa bấm').replace(/^./, (c) => c.toLowerCase()); } veBang();
      let kq = 'Xong';
      try {
        if (y.loai === 'docsheet') {
          if (chanLark()) { // (6.30) API hết lượt → nhờ tab sheet Lark đọc lại ngay, chờ tối đa 2 phút
            const yc = Date.now(); datCoLarkWeb(true); ghi('Đọc ngay: Lark hết lượt API → nhờ tab sheet Lark trên Chrome máy này đọc lại');
            let xong = false; for (let i = 0; i < 40; i++) { await sleepThat(3000); const t = lay('lark_webtt6', null); if (t && t.luc >= yc) { if (!t.ok) throw new Error('tab Lark đọc lỗi: ' + t.loi); xong = true; break; } }
            if (!xong) throw new Error('chưa thấy tab sheet Lark nào đọc giúp — mở sheet MKT 10 trên Chrome máy này (đã đăng nhập Lark) rồi bấm lại');
          }
          const d = await docDuLieu('tay'); luu('tai6', null); kq = `Đã đọc lúc ${gioStr(new Date())}${chanLark() ? ' (qua Lark web)' : ''}`; void d;
        }
        else if (y.loai === 'dotrang') { // (6.19.2) kiểm cả 3 kênh
          const ds2 = [];
          for (const c of KENH_ALL) {
            if (c > 1 && !LICH.some((x) => x.kenh === c)) continue;
            if (!coApiKenh(c)) { ds2.push(`${c === 4 ? 'HX' : 'K' + c}: chưa có mã đọc trang`); continue; }
            datKenh(c); try { const x = await doTrang('bấm tay' + (c > 1 ? ' ' + tenKenh(c) : '')); ds2.push(`${c === 4 ? 'HX' : 'K' + c}: ${x ? ((lay(c === 1 ? 'trang6' : 'trang6_k' + c, {}) || {}).n || 0) + ' bài hôm nay' : 'chưa kiểm được'}`); } finally { datKenh(1); }
          }
          kq = 'Đã kiểm — ' + ds2.join(' · ');
        }
        else if (y.loai === 'kiem1' || y.loai === 'kiem3' || y.loai === 'kiem24') { await kiemTay(y.loai); kq = 'Đã kiểm — bài nào thiếu sẽ được gửi bù ngay'; }
        else if (y.loai === 'khanhthu') { await khanhThuNgay(); kq = 'Đang mở trang để đọc'; }
        else if (y.loai === 'tinthu') { const ok = await guiLark('loi', `[fb][${TEN_MAY}] Tin thử từ popup — kết nối nhóm Đăng bài fb hoạt động`, { khoa: 'thu' + Date.now(), toiDa: 9 }); kq = ok ? 'Đã gửi tin thử' : 'Gửi chưa được'; }
        else if (y.loai === 'taisan') { luu('tai6', null); kq = 'Sẽ tải sẵn ngay'; }
      } catch (e) { kq = 'Lỗi: ' + e.message; ghi(`Lỗi khi ${TEN_YC[y.loai] || y.loai}: ${e.message}`); }
      luu('yc6_kq_' + y.loai, { tt: /^Lỗi/.test(kq) ? 'loi' : 'xong', luc: Date.now(), kq }); if (hdChay) hdChay.cuoi = kq;
      veBang();
    }
    return true;
  }

  // =====================================================================
  //  TẠO ẢNH MANIFEST (bấm tay ở tab Manifest): tạo xem trước trong popup → chọn → dán vào sheet
  //  chữ cột G → ảnh dán vào cột bên phải cùng hàng. Ảnh tạo ra chỉ giữ trong tab này cho tới khi dán.
  // =====================================================================
  let anhNenTam = []; // ảnh nền vừa chọn trên popup
  const mf = { ds: [], tien: null, chay: false, dan: false };
  function mfBuoc(buoc, chu, i, n) {
    mf.tien = { buoc, chu, i: i || 0, n: n || 0, luc: Date.now(), bd: (mf.tien && mf.tien.bd) || Date.now() };
    if (hdChay) { hdChay.chi = chu; hdChay.cap = Date.now(); if (hdChay.hien) luu('hoat_dong', hdChay); }
    veBang();
  }
  function docVungMF(vung) {
    const m = String(vung || '').toUpperCase().replace(/\s+/g, '').match(/^([A-Z]{1,2})(\d+)(?::([A-Z]{1,2})?(\d+))?$/);
    if (!m) throw new Error('vùng ô không đúng dạng (ví dụ G220:G223)');
    const cot = m[1], tu = +m[2], den = +(m[4] || m[2]);
    if (m[3] && m[3] !== cot) throw new Error('chỉ chọn 1 cột (ví dụ G220:G223)');
    if (den < tu || den - tu > 60) throw new Error('vùng ô từ 1 đến 60 hàng');
    if (cot.length > 1 || cot >= 'Z') throw new Error('cột chữ phải từ A đến Y');
    return { cot, tu, den, cotKQ: String.fromCharCode(cot.charCodeAt(0) + 1) };
  }
  // ---- font chữ ảnh manifest: 2 font có sẵn + font tải thêm (lưu trong Tampermonkey của máy này) ----
  const FONT_GOC = ['UTM American Sans', 'UTM Aptima'];
  const FONT_MAC_DINH = { td: 'UTM American Sans', than: 'UTM American Sans', cmt: 'UTM Aptima' };
  const fontThem = () => lay('mf_fonts6', {}) || {};
  const dsFont = () => FONT_GOC.concat(Object.keys(fontThem()));
  function fontChon() { const c = Object.assign({}, FONT_MAC_DINH, lay('mf_font6', {}) || {}); const ds = dsFont(); for (const k of Object.keys(FONT_MAC_DINH)) if (!ds.includes(c[k])) c[k] = FONT_MAC_DINH[k]; return c; }
  const fontDaNap = new Set();
  async function napFontChon() {
    await napFontMF();
    for (const [ten, b64] of Object.entries(fontThem())) {
      if (fontDaNap.has(ten)) continue;
      const bin = atob(b64); const u8 = new Uint8Array(bin.length); for (let i = 0; i < bin.length; i++) u8[i] = bin.charCodeAt(i);
      const f = new FontFace(ten, u8.buffer); await f.load(); document.fonts.add(f); fontDaNap.add(ten);
    }
  }
  async function themFont(file) {
    if (!/\.(ttf|otf|woff2?)$/i.test(file.name)) throw new Error('chỉ nhận file font .ttf, .otf, .woff, .woff2');
    if (file.size > 3 * 1024 * 1024) throw new Error(`file font nặng ${(file.size / 1048576).toFixed(1)} MB — tối đa 3 MB`);
    const ds = fontThem(); if (Object.keys(ds).length >= 6) throw new Error('đã có 6 font tải thêm — xoá bớt rồi thêm');
    let ten = file.name.replace(/\.(ttf|otf|woff2?)$/i, '').replace(/[^\p{L}\p{N} _-]/gu, ' ').replace(/\s+/g, ' ').trim() || 'Font';
    if (FONT_GOC.includes(ten)) ten += ' (tải)';
    const buf = await file.arrayBuffer();
    try { const f = new FontFace(ten, buf.slice(0)); await f.load(); document.fonts.add(f); fontDaNap.add(ten); } catch (e) { throw new Error('file này không phải font hợp lệ'); }
    const u8 = new Uint8Array(buf); let bin = ''; for (let i = 0; i < u8.length; i += 0x8000) bin += String.fromCharCode.apply(null, u8.subarray(i, i + 0x8000));
    ds[ten] = btoa(bin); luu('mf_fonts6', ds);
    ghi(`Đã thêm font "${ten}" (${(file.size / 1024).toFixed(0)} KB) cho ảnh manifest`);
    return ten;
  }
  function xoaFont(ten) { const ds = fontThem(); delete ds[ten]; luu('mf_fonts6', ds); fontDaNap.delete(ten); const c = lay('mf_font6', {}) || {}; for (const k of Object.keys(c)) if (c[k] === ten) delete c[k]; luu('mf_font6', c); ghi(`Đã xoá font "${ten}"`); }
  function datFont(vai, ten) { const c = lay('mf_font6', {}) || {}; c[vai] = ten; luu('mf_font6', c); }
  const nenNgauNhien = (tru) => { const ds = anhNenTam.filter((f) => f !== tru); const L = ds.length ? ds : anhNenTam; return L[Math.floor(Math.random() * L.length)]; };
  async function veMotAnh(x) {
    const f = fontChon();
    const kq = await taoAnhManifest(x.nen, x.chu, f.than, f.cmt, f.td, f.than);
    if (!kq.blob || kq.blob.size < 20000) throw new Error('ảnh tạo ra bị lỗi');
    if (kq.phaiNhat > 1080 - 128) throw new Error('chữ sát mép quá, cần rút ngắn');
    if (x.url) URL.revokeObjectURL(x.url);
    Object.assign(x, { blob: kq.blob, url: URL.createObjectURL(kq.blob), tl: kq.tl, tt: 'moi', loi: '' });
  }
  async function taoAnhXemTruoc(vung) {
    if (mf.chay || mf.dan) throw new Error('đang tạo/dán ảnh, đợi xong đã');
    if (!anhNenTam.length) throw new Error('chưa chọn ảnh nền');
    const v0 = docVungMF(vung);
    mf.chay = true; mf.ds.forEach((x) => { if (x.url) URL.revokeObjectURL(x.url); }); mf.ds = []; mf.tien = null;
    try {
      mfBuoc('doc', `Bước 1/3 · Đọc chữ trong sheet (ô ${vung})`);
      const v = await docBang(CAI_DAT.TAB_VIDEO, `${v0.cot}${v0.tu}:${v0.cot}${v0.den}`);
      const hangs = [];
      for (let h = v0.tu; h <= v0.den; h++) { const chu = chuO((v[h - v0.tu] || [])[0]).trim(); if (chu) hangs.push({ h, chu }); }
      if (!hangs.length) throw new Error(`các ô ${vung} chưa có chữ`);
      ghi(`Tạo ảnh manifest: đọc được ${hangs.length} ô có chữ trong ${vung}`);
      { const f = fontChon(); mfBuoc('font', `Bước 2/3 · Nạp font chữ (tiêu đề: ${f.td} · thân: ${f.than} · kêu gọi: ${f.cmt})`); } await napFontChon();
      // chia đều ảnh nền (xáo trộn) cho các ảnh
      const tron = anhNenTam.slice().sort(() => Math.random() - 0.5);
      for (let i = 0; i < hangs.length; i++) {
        const { h, chu } = hangs[i];
        mfBuoc('tao', `Bước 3/3 · Tạo ảnh ${i + 1}/${hangs.length} (chữ ô ${v0.cot}${h})`, i, hangs.length);
        const x = { h, oChu: v0.cot + h, oKQ: v0.cotKQ + h, chu, nen: tron[i % tron.length], chon: true, tt: 'moi' };
        try { await veMotAnh(x); } catch (e) { x.tt = 'loi'; x.loi = e.message; x.chon = false; ghi(`Tạo ảnh manifest ô ${x.oChu} lỗi: ${e.message}`); }
        mf.ds.push(x); veBang(); await sleepThat(30);
      }
      const ok = mf.ds.filter((x) => x.tt !== 'loi').length;
      mfBuoc('xong', `Đã tạo ${ok}/${hangs.length} ảnh — bấm vào từng ảnh để xem trước, rồi bấm "Dán vào sheet"`, hangs.length, hangs.length);
      ghi(`Tạo ảnh manifest: đã tạo ${ok}/${hangs.length} ảnh xem trước (chưa dán vào sheet)`);
      return `đã tạo ${ok}/${hangs.length} ảnh xem trước`;
    } catch (e) { mfBuoc('loi', 'Chưa tạo được: ' + e.message); throw e; } finally { mf.chay = false; veBang(); }
  }
  async function taoLaiAnh(i) {
    const x = mf.ds[i]; if (!x || mf.chay || mf.dan) return;
    mf.chay = true; x.tt = 'dangtao'; veBang();
    try { x.nen = nenNgauNhien(x.nen); await napFontChon(); await veMotAnh(x); x.chon = true; ghi(`Tạo lại ảnh manifest ô ${x.oKQ} (đổi ảnh nền)`); }
    catch (e) { x.tt = 'loi'; x.loi = e.message; } finally { mf.chay = false; veBang(); }
  }
  async function veLaiFont() { // đổi font → vẽ lại tất cả ảnh chưa dán, giữ nguyên ảnh nền
    if (mf.chay || mf.dan) throw new Error('đang tạo/dán ảnh, đợi xong đã');
    const ds = mf.ds.filter((x) => x.nen && x.tt !== 'xong');
    if (!ds.length) throw new Error('không còn ảnh nào chưa dán để vẽ lại');
    mf.chay = true; mf.tien = null;
    try {
      const f = fontChon(); mfBuoc('font', `Nạp font chữ (tiêu đề: ${f.td} · thân: ${f.than} · kêu gọi: ${f.cmt})`); await napFontChon();
      let ok = 0;
      for (let i = 0; i < ds.length; i++) {
        const x = ds[i]; x.tt = 'dangtao';
        mfBuoc('tao', `Vẽ lại ảnh ${i + 1}/${ds.length} với font mới (ô ${x.oKQ})`, i, ds.length);
        try { await veMotAnh(x); x.chon = true; ok++; } catch (e) { x.tt = 'loi'; x.loi = e.message; x.chon = false; }
        veBang(); await sleepThat(30);
      }
      mfBuoc('xong', `Đã vẽ lại ${ok}/${ds.length} ảnh với font mới — xem lại rồi bấm "Dán vào sheet"`, ds.length, ds.length);
      ghi(`Vẽ lại ${ok}/${ds.length} ảnh manifest với font: ${f.td} / ${f.than} / ${f.cmt}`);
      return `đã vẽ lại ${ok}/${ds.length} ảnh với font mới`;
    } catch (e) { mfBuoc('loi', 'Chưa vẽ lại được: ' + e.message); throw e; } finally { mf.chay = false; veBang(); }
  }
  async function danAnhVaoSheet() {
    if (mf.chay || mf.dan) throw new Error('đang tạo/dán ảnh, đợi xong đã');
    const ds = mf.ds.filter((x) => x.chon && x.blob && x.tt !== 'xong');
    if (!ds.length) throw new Error('chưa chọn ảnh nào để dán');
    mf.dan = true; mf.tien = null;
    try {
      let ok = 0;
      for (let i = 0; i < ds.length; i++) {
        const x = ds[i]; x.tt = 'dang';
        mfBuoc('dan', `Dán ảnh ${i + 1}/${ds.length} vào ô ${x.oKQ}`, i, ds.length);
        try { await ghiAnhVaoO(CAI_DAT.TAB_VIDEO, x.oKQ, x.blob, `manifest-h${x.h}.jpg`); x.tt = 'xong'; ok++; ghi(`Đã dán ảnh manifest vào ô ${x.oKQ}`); }
        catch (e) { x.tt = 'loi'; x.loi = e.message; ghi(`Dán ảnh manifest vào ô ${x.oKQ} lỗi: ${e.message}`); }
        veBang();
      }
      const kq = `đã dán ${ok}/${ds.length} ảnh vào sheet${ok < ds.length ? ' — ảnh lỗi có thể bấm Dán lại' : ''}`;
      mfBuoc('daxong', 'Xong: ' + kq, ds.length, ds.length);
      return kq;
    } finally { mf.dan = false; veBang(); }
  }
