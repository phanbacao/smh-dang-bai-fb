
  // =====================================================================
  //  (6.20) BÁO CÁO CHỈ SỐ TUẦN FB KÊNH 1 — CHỈ MÁY CAO, PHẦN PHỤ (chỉ chạy khi script rảnh ≥ 15 phút trước việc chính)
  //  Thứ 6 từ 7:00: mở 6 trang Công cụ chuyên nghiệp (Lượt xem / Nhắn tin / Đối tượng × 7 ngày / 28 ngày), đọc số → gửi 1 tin vào NHÓM KẾT QUẢ.
  //  Lỗi → 5 phút thử lại; 10 lần lỗi → báo NHÓM LỖI (1 lần); 9:30 chưa gửi được → báo NHÓM LỖI rồi thôi.
  //  Nhóm kết quả CHỈ nhận báo cáo chính thức; tin thử / tin lỗi chỉ vào nhóm lỗi.
  // =====================================================================
  const CS = {
    TU: '07:00', DEN: '09:30', RANH_PHUT: 15, CHO_LOI_PHUT: 5, BAO_SAU_LOI: 10,
    TIEU_DE: 'Báo cáo chỉ số tuần fb kênh 1',
    BUOC: [
      { trang: 'views', ky: '7D', ten: 'Lượt xem 7 ngày' }, { trang: 'messaging', ky: '7D', ten: 'Nhắn tin 7 ngày' }, { trang: 'audience', ky: '7D', ten: 'Theo dõi 7 ngày' },
      { trang: 'views', ky: '28D', ten: 'Lượt xem 28 ngày' }, { trang: 'messaging', ky: '28D', ten: 'Nhắn tin 28 ngày' }, { trang: 'audience', ky: '28D', ten: 'Theo dõi 28 ngày' },
    ],
  };
  const linkCS = (b) => `https://www.facebook.com/professional_dashboard/profile_insights/${b.trang}/?date_range=LAST_${b.ky}`;
  const dangOTrangCS = () => /^\/professional_dashboard\/(profile_insights|content\/content_library)/.test(location.pathname) || /^\/content\/insights/.test(location.pathname);
  const LINK_TV = 'https://www.facebook.com/professional_dashboard/content/content_library'; // (6.28.1) Thư viện nội dung — dự phòng khi mã đọc trang không trả lượt xem từng video
  const dangOTV = () => /^\/professional_dashboard\/content\/content_library/.test(location.pathname);
  const ghiChuCS = () => String(lay('csghichu6', '') || '').trim();
  const DUNG_LAI_PHUT = 30;
  const dungTrangCS = (b) => location.pathname.replace(/\/+$/, '') === `/professional_dashboard/profile_insights/${b.trang}` && new URLSearchParams(location.search).get('date_range') === 'LAST_' + b.ky;
  const csTT = () => lay('cs6', null) || {};
  const luuCS = (f) => { const c = csTT(); f(c); luu('cs6', c); return c; };
  // tuần = thứ 2 → chủ nhật; khoá tuần = ngày thứ 6 của tuần đó
  function tuanCS(d = new Date()) { const x = new Date(d); x.setHours(12, 0, 0, 0); const t = (x.getDay() + 6) % 7; x.setDate(x.getDate() - t + 4); return ngayStr(x); }
  const hookCS = () => { const b = lay('bimat6', null) || {}; return { kq: b.csKQ || '', loi: b.csLoi || '' }; };
  const LINK_HOOK_RE = /^https:\/\/open\.larksuite\.com\/open-apis\/bot\/v2\/hook\/[A-Za-z0-9-]{20,}$/;

  // ---------- đọc 1 trang ----------
  const laSo = (s) => /^[\d.,]+$/.test(s) || /^[—–-]$/.test(s);
  const soCS = (s) => (/^[—–-]$/.test(String(s || '').trim()) ? 0 : parseInt(String(s || '0').replace(/[^\d]/g, ''), 10) || 0);
  const sachCS = (s) => String(s || '').replace(/[\u200b-\u200f\ufeff]/g, '').trim();
  function dauPhanTram(el) { // trang Lượt xem hay chỉ có mũi tên màu, không ghi dấu → xanh = tăng, đỏ = giảm
    try { const m = getComputedStyle(el).color.match(/(\d+)\D+(\d+)\D+(\d+)/); if (!m) return ''; const r = +m[1], g = +m[2]; if (g > r + 40) return '+'; if (r > g + 40) return '-'; } catch (e) { /* */ }
    return '';
  }
  function soTheoNhan(nhan, canPct) { // con số đứng ngay trước nhãn (trong cùng 1 khung nhỏ) — tránh lấy nhầm số trên trục biểu đồ
    const las = Array.from(document.querySelectorAll('span,div')).filter((e) => e.childElementCount === 0 && sachCS(e.textContent) === nhan && dangHien(e) && !e.closest('[role="navigation"],#smhfb'));
    for (const e of las) {
      let p = e;
      for (let i = 0; i < 5 && p; i++) {
        p = p.parentElement; if (!p) break;
        const dong = String(p.innerText || '').split('\n').map(sachCS).filter(Boolean);
        if (dong.length > 5) break;
        const iN = dong.indexOf(nhan); if (iN < 1) continue;
        const so = dong.slice(0, iN).find(laSo); if (so == null) continue;
        let pct = null;
        const dp = dong.slice(0, iN).find((x) => /^[+\-−]?\d+(?:[.,]\d+)?%$/.test(x));
        if (dp) {
          let dau = /^[+\-−]/.test(dp) ? (dp[0] === '+' ? '+' : '-') : '';
          if (!dau) { const els = Array.from(p.querySelectorAll('span,div')).filter((x) => sachCS(x.textContent) === dp); const el = els[els.length - 1]; if (el) dau = dauPhanTram(el); } // phần tử sâu nhất mang màu chữ
          pct = { dau, so: dp.replace(/^[+\-−]/, '').replace('%', '') };
        }
        if (canPct && !pct) continue;
        return { so: soCS(so), pct };
      }
    }
    return null;
  }
  function khoangNgayCS(txt, ky) { // "7 ngày qua: 8 Tháng 10 - 14 Tháng 10" → {tu:'08/10/2026', den:'14/10/2026'}
    const m = txt.match(new RegExp((ky === '7D' ? 7 : 28) + '\\s*ngày qua:\\s*(\\d{1,2}) Tháng (\\d{1,2})(?:,? (\\d{4}))?\\s*[-–]\\s*(\\d{1,2}) Tháng (\\d{1,2})(?:,? (\\d{4}))?'));
    if (!m) return null;
    const nay = new Date(); let nDen = m[6] ? +m[6] : nay.getFullYear(); if (!m[6] && +m[5] > nay.getMonth() + 1) nDen--;
    let nTu = m[3] ? +m[3] : nDen; if (!m[3] && (+m[2] > +m[5] || (+m[2] === +m[5] && +m[1] > +m[4]))) nTu = nDen - 1; // tuần giao năm
    return { tu: `${pad(m[1])}/${pad(m[2])}/${nTu}`, den: `${pad(m[4])}/${pad(m[5])}/${nDen}` };
  }
  function docTrangCS(b) { // null = chưa đủ số (chờ thêm) · {loi} · {so, pct, ngay}
    const txt = document.body ? document.body.innerText : '';
    const ngay = khoangNgayCS(txt, b.ky); if (!ngay) return null;
    const chuaDu = /Chưa đủ dữ liệu/.test(txt);
    if (b.trang === 'views') {
      const x = soTheoNhan('Lượt xem', true) || soTheoNhan('Lượt xem', false);
      if (!x) return null; // (6.31.2) chữ "Chưa đủ dữ liệu" có thể là của biểu đồ con khi trang đang tải → không coi là 0, chờ thêm / tải lại
      return { so: x.so, pct: x.pct, ngay, chuaDu };
    }
    const pm = txt.match(new RegExp('([+\\-−]?\\d+(?:[.,]\\d+)?)% từ ' + (b.ky === '7D' ? 7 : 28) + ' ngày trước'));
    const pct = pm ? { dau: /^[+]/.test(pm[1]) ? '+' : /^[-−]/.test(pm[1]) ? '-' : '', so: pm[1].replace(/^[+\-−]/, '') } : null;
    const nhan = b.trang === 'messaging' ? 'Số người liên hệ nhắn tin' : 'Số người theo dõi thực';
    const x = soTheoNhan(nhan, false);
    if (!x) return null; // (6.31.2) như trên
    return { so: x.so, pct, ngay, chuaDu };
  }

  // ---------- định dạng + gửi ----------
  const fmtSo = (n) => String(Math.round(n || 0)).replace(/\B(?=(\d{3})+(?!\d))/g, '.');
  const laKhong = (p) => p && /^0+(?:[.,]0+)?$/.test(p.so);
  function fmtPct(p, mau) {
    if (!p) return '';
    if (laKhong(p)) return mau ? `<font color='grey'>=0%</font>` : '=0%';
    if (p.dau === '+' && /^100(?:[.,]0+)?$/.test(p.so)) return mau ? `<font color='grey'>mới</font>` : 'mới'; // (6.28.4) kỳ trước = 0 (page mới) → % không có ý nghĩa
    const s = (p.dau === '-' ? '▼' : p.dau === '+' ? '▲' : '') + p.so + '%';
    return mau && p.dau ? `<font color='${p.dau === '-' ? 'red' : 'green'}'>${s}</font>` : s;
  }
  const ngayNgan = (s) => String(s || '').slice(0, 5);
  function dongCS(kq, ky, mau) {
    const v = kq[ky + 'views'], m = kq[ky + 'messaging'], a = kq[ky + 'audience']; const ng = (v || m || a || {}).ngay || {};
    const o = (x, icon) => `${icon} ${x ? (x.so == null ? 'Không xác định được' : fmtSo(x.so)) : '…'}${x && fmtPct(x.pct, mau) ? ' ' + fmtPct(x.pct, mau) : ''}`;
    const truoc = (() => { const p = String(ng.tu || '').split('/').map(Number); if (p.length < 3 || !p[2]) return ''; const n = ky === '7D' ? 7 : 28; const t0 = new Date(p[2], p[1] - 1, p[0]); const d1 = new Date(t0); d1.setDate(d1.getDate() - 1); const t1 = new Date(t0); t1.setDate(t1.getDate() - n); const f = (d) => String(d.getDate()).padStart(2, '0') + '/' + String(d.getMonth() + 1).padStart(2, '0'); return f(t1) + '–' + f(d1); })(); // (6.20.7) kỳ so sánh = kỳ liền trước cùng độ dài
    const dau = `${ky === '7D' ? '7 ngày' : '28 ngày'} (${ngayNgan(ng.tu)}–${ngayNgan(ng.den)})${truoc ? ' · so với ' + truoc : ''}`;
    return mau ? `**${dau}**\n${o(v, '👁')} · ${o(m, '💬')} · ${o(a, '👥')}` : `${dau}: ${o(v, '👁')} · ${o(m, '💬')} · ${o(a, '👥')}`;
  }
  const noiDungCS = (kq, thu, mau, ghiChu) => `${thu ? '(GỬI THỬ) ' : ''}${CS.TIEU_DE}\n${dongCS(kq, '7D', mau)}\n${dongCS(kq, '28D', mau)}\n(% = so với kỳ liền trước cùng độ dài, số liệu từ Facebook)${kq.video ? '\n\n' + dongVideoTuan(kq.video, false).join('\n').replace(/\*\*/g, '') : ''}${ghiChu ? '\n\n📝 Ghi chú: ' + ghiChu : ''}`;
  const duSoCS = (kq) => CS.BUOC.every((b) => kq && kq[b.ky + b.trang]);
  function oCS(kq, ky) { // (6.28.2) 3 ô số to cạnh nhau: Lượt xem · Nhắn tin · Theo dõi
    const dau = dongCS(kq, ky, true).split('\n')[0];
    const o = (x, nhan) => ({ tag: 'column', width: 'weighted', weight: 1, vertical_align: 'top', elements: [
      { tag: 'markdown', content: nhan, text_align: 'center' },
      { tag: 'markdown', content: x && x.so == null ? '**Không xác định được**' : `**${x ? fmtSo(x.so) : '…'}**`, text_align: 'center', text_size: x && x.so == null ? 'normal' : 'heading' },
      { tag: 'markdown', content: x && fmtPct(x.pct, true) ? fmtPct(x.pct, true) : '—', text_align: 'center' }] });
    return [{ tag: 'markdown', content: dau }, { tag: 'column_set', flex_mode: 'none', background_style: 'grey', horizontal_spacing: 'default', columns: [o(kq[ky + 'views'], '👁 Lượt xem'), o(kq[ky + 'messaging'], '💬 Nhắn tin'), o(kq[ky + 'audience'], '👥 Theo dõi')] }];
  }
  const trungKy = (kq) => ['views', 'messaging', 'audience'].every((t) => kq['7D' + t] && kq['28D' + t] && kq['7D' + t].so != null && kq['7D' + t].so === kq['28D' + t].so); // (6.28.4)
  function theCS(kq, thu, ghiChu) { // (6.28.1) 1 hàm dựng thẻ Lark — dùng cho cả gửi lẫn xem trước trong tab (giống hệt nhau)
    const el = oCS(kq, '7D').concat([{ tag: 'div', text: { tag: 'plain_text', content: ' ' } }], oCS(kq, '28D'));
    if (kq.video) el.push({ tag: 'hr' }, { tag: 'markdown', content: dongVideoTuan(kq.video, true).join('\n') });
    if (ghiChu) el.push({ tag: 'hr' }, { tag: 'div', text: { tag: 'lark_md', content: '📝 **Ghi chú:** ' + ghiChu } });
    el.push({ tag: 'note', elements: [{ tag: 'plain_text', content: '% = so với kỳ liền trước cùng độ dài (số liệu từ Facebook)' + (trungKy(kq) ? ' · page mới lập từ 17/10 nên số 28 ngày = 7 ngày, "mới" = kỳ trước chưa có số' : '') }] });
    return { msg_type: 'interactive', card: { config: { wide_screen_mode: true }, header: { template: thu ? 'grey' : 'blue', title: { tag: 'plain_text', content: (thu ? '(GỬI THỬ) ' : '') + CS.TIEU_DE } }, elements: el } };
  }
  async function guiHookCS(nhom, kq, thu, ghiChu) { // nhom: 'kq' | 'loi' — 2 đường riêng, KHÔNG bao giờ đổi nhóm khi lỗi
    const h = hookCS(); const hook = nhom === 'kq' ? h.kq : h.loi;
    if (!hook) throw new Error(`chưa cài link ${nhom === 'kq' ? 'NHÓM KẾT QUẢ' : 'NHÓM LỖI'} (nút 🔑 Cài nhóm Lark ở tab Chỉ số tuần)`);
    if (nhom === 'kq' && (thu || !duSoCS(kq))) throw new Error('chặn: nhóm kết quả chỉ nhận báo cáo chính thức đủ số');
    const ok = (r) => r && r.json && (r.json.code === 0 || r.json.StatusCode === 0);
    let r = null; try { r = await goi('POST', hook, theCS(kq, thu, ghiChu)); } catch (e) { /* thử dạng chữ */ }
    if (ok(r)) return 'thẻ';
    r = await goi('POST', hook, { msg_type: 'text', content: { text: noiDungCS(kq, thu, false, ghiChu) } });
    if (ok(r)) return 'chữ';
    throw new Error('Lark trả lời mã ' + (r && r.json ? (r.json.code || r.json.StatusCode) + ' ' + (r.json.msg || '') : r && r.status));
  }
  async function guiBaoCaoCS(loai, kq) { // (6.28.1) gửi + ghi chú; mục video chưa đọc được → thêm 1 tin vào NHÓM LỖI
    const thu = loai === 'thu'; const gc = ghiChuCS();
    const kieu = await guiHookCS(thu ? 'loi' : 'kq', kq, thu, gc);
    if (!thu) { luuCS((x) => { if (x.tuan !== tuanCS()) x.tuan = tuanCS(); x.guiLuc = Date.now(); x.guiLoai = loai; x.lyDo = ''; }); if (gc) luu('csghichu6', ''); }
    const thieu = loiVideoCS(kq.video);
    if (thieu.length) await guiChuLoiCS(`${CS.TIEU_DE}${thu ? ' (gửi thử)' : ''}: phần video nổi bật có mục chưa đọc được — ${thieu.join('; ')}`);
    return kieu;
  }
  async function guiChuLoiCS(chu) { // tin chữ vào NHÓM LỖI (có chữ "fb")
    const h = hookCS(); if (!h.loi) { ghi('Chỉ số tuần: chưa cài link NHÓM LỖI → không báo được: ' + chu); return false; }
    try { const r = await goi('POST', h.loi, { msg_type: 'text', content: { text: /fb/i.test(chu) ? chu : '[fb] ' + chu } }); const ok = r && r.json && (r.json.code === 0 || r.json.StatusCode === 0); ghi(`Chỉ số tuần: ${ok ? 'đã báo' : 'báo chưa được'} nhóm lỗi — ${chu.slice(0, 120)}`); return ok; } catch (e) { ghi('Chỉ số tuần: báo nhóm lỗi chưa được (' + e.message + ')'); return false; }
  }

  // ---------- rảnh chưa ----------
  function lyDoBanCS() { // '' = rảnh; ngược lại là lý do đang bận
    { const c0 = lay('cs6', {}) || {}; const tay = !!(c0.yc || (c0.chay && c0.chay.loai !== 'tudong')); // (6.20.6) bấm tay: chỉ nhường khi script đang đăng/comment thật sự — không chờ "bạn đang dùng trang", không chờ 15 phút trước bài kế tiếp
      if (tay) { if (!MAY || !LA_CAO) return 'chỉ chạy trên Máy Cao'; if (!laTabChinh()) return 'tab này không phải tab làm việc'; if (dangBan || lay('dang_do', null) || lay('cho_tay6', null) || lay('khanh_dang', null)) return 'script đang đăng/comment bài'; if (demNguoc) return 'sắp đăng bài (đang đếm ngược)'; return ''; } }
    if (!MAY || !LA_CAO) return 'chỉ chạy trên Máy Cao';
    if (tamDung()) return 'đang Tạm dừng';
    if (!laTabChinh()) return 'tab này không phải tab làm việc';
    if (dangBan || lay('dang_do', null) || lay('cho_tay6', null) || lay('khanh_dang', null)) return 'script đang làm việc chính';
    if ((lay('yc6', []) || []).length || (lay('hang_bu6', []) || []).length || demNguoc) return 'script đang làm việc bạn vừa bấm';
    if (dangHoan()) return 'đang Hoãn 10 phút';
    if (nhanSuDangDung()) return 'bạn đang dùng trang';
    const L = tinhLich(); const sap = L.filter((x) => !x.ket && x.r.tt !== 'bo').map((x) => (x.r.ep ? Date.now() : Math.max(lucPhut(x.gioKH), lucBuKenh(L, x)))).filter((t) => Number.isFinite(t)).sort((a, b) => a - b)[0];
    if (tuDong() && sap != null && sap - Date.now() < CS.RANH_PHUT * 60000) return `sắp tới giờ đăng bài (${gioStr(new Date(Math.max(sap, Date.now())))})`;
    if (document.visibilityState !== 'visible') return 'tab Facebook đang bị ẩn';
    return '';
  }

  // ---------- vòng chính (gọi cuối nhịp) ----------
  // (6.26.11) chỉ số tuần (tự động thứ 6): tab Facebook đang ẩn → tự chuyển về tab; Chrome không cho → thông báo trên máy + chuông, 07:45–09:00 cứ 15 phút nhắc lại
  function nhacMayCS(tieu, noi) {
    try { GM_notification({ title: tieu, text: noi, timeout: 0, highlight: true, onclick: () => { try { window.focus(); } catch (e) { /* */ } } }); } catch (e) { ghi('Chỉ số tuần: không hiện được thông báo trên máy (' + e.message + ')'); }
    try { const AC = window.AudioContext || window.webkitAudioContext; const ac = new AC(); const t0 = ac.currentTime + 0.05; [0, 0.4, 0.8].forEach((d, i) => { const o = ac.createOscillator(); const g = ac.createGain(); o.frequency.value = i === 2 ? 1046 : 880; g.gain.setValueAtTime(0.0001, t0 + d); g.gain.exponentialRampToValueAtTime(0.5, t0 + d + 0.02); g.gain.exponentialRampToValueAtTime(0.0001, t0 + d + 0.32); o.connect(g); g.connect(ac.destination); o.start(t0 + d); o.stop(t0 + d + 0.35); }); setTimeout(() => { try { ac.close(); } catch (e) { /* */ } }, 2500); } catch (e) { /* */ }
    ghi('Chỉ số tuần: đã hiện thông báo + kêu chuông trên máy — "' + tieu + '"');
  }
  function nhacTabCS(viec) {
    if (!viec || viec.loai !== 'tudong' || document.visibilityState === 'visible') return;
    const now = new Date(); const mm = phutTrongNgay(now);
    if (!window.__csNhay) {
      window.__csNhay = Date.now(); ghi('Chỉ số tuần: đến giờ nhưng tab Facebook đang ẩn → tự chuyển về tab Facebook');
      try { window.focus(); } catch (e) { /* */ }
      setTimeout(() => ghi(document.visibilityState === 'visible' ? 'Chỉ số tuần: đã tự chuyển về tab Facebook → xem chỉ số ngay' : '⚠️ Chỉ số tuần: Chrome không cho tự chuyển về tab Facebook (cửa sổ đang thu nhỏ / đang dùng ứng dụng khác) → sẽ nhắc bằng thông báo + chuông'), 4000);
    }
    const tu = docGio('07:45'), den = docGio('09:00');
    if (now.getDay() === 5 && mm >= tu && mm <= den) {
      const k = homNay() + '|' + Math.floor((mm - tu) / 15);
      if (lay('csnhac6', '') !== k) { luu('csnhac6', k); try { window.focus(); } catch (e) { /* */ } nhacMayCS('Đến giờ xem chỉ số tuần fb kênh 1', 'Bấm vào đây để mở tab Facebook — script sẽ xem chỉ số và gửi báo cáo ngay.'); }
    }
  }
  let csDangChay = false;
  async function vongChiSo() { if (csDangChay) return false; csDangChay = true; try { const r = await vongChiSo0(); if (r) return r; return await vongTV24(); } finally { csDangChay = false; } }
  async function vongChiSo0() {
    if (!LA_CAO || !MAY) return false;
    const c = csTT(); const tuan = tuanCS(); const now = new Date(); const mm = phutTrongNgay(now);
    if (c.tuan !== tuan) { luu('cs6', { tuan, kqCuoi: c.kqCuoi || null, yc: c.yc && Date.now() - c.yc.luc < 30 * 60000 ? c.yc : null }); return false; }
    // yêu cầu bấm tay quá 30 phút chưa làm được → huỷ, báo
    if (c.yc && Date.now() - c.yc.luc > 30 * 60000 && !c.chay) { luuCS((x) => { x.yc = null; }); ghi('Chỉ số tuần: yêu cầu bấm tay quá 30 phút chưa làm được (script bận) → huỷ'); thongBaoMay('Chưa xem được chỉ số tuần', 'Script bận quá 30 phút nên đã huỷ yêu cầu — bấm lại nếu vẫn cần.'); return false; }
    const tuDongDenGio = now.getDay() === 5 && mm >= docGio(CS.TU) && !c.guiLuc && !c.het;
    // 9:30 thứ 6 chưa gửi được → báo nhóm lỗi 1 lần rồi thôi (chỉ phần tự động; bấm tay vẫn làm được)
    if (now.getDay() === 5 && mm >= docGio(CS.DEN) && !c.guiLuc && !c.het) {
      const ban = c.lyDo && !/^lỗi/.test(c.lyDo) ? c.lyDo : lyDoBanCS(); const ly = [c.loiDem ? `đã thử ${c.loiDem} lần chưa đọc/gửi được (lỗi cuối: ${c.loiCuoi || c.lyDo || 'không rõ'})` : '', ban && !c.loiDem ? 'script bận: ' + ban : ''].filter(Boolean).join('; ') || 'không rõ';
      luuCS((x) => { x.het = Date.now(); if (x.chay && x.chay.loai === 'tudong') x.chay = null; });
      await guiChuLoiCS(`Tuần này không gửi được báo cáo chỉ số fb kênh 1, lý do: ${ly}`);
      if (dangOTrangCS() && !lay('dang_do', null)) { datKenh(1); veTrang(); }
      return false;
    }
    if (tuDongDenGio && !c.yc && !c.chay && !hookCS().kq) { if (c.lyDo !== 'chưa cài link NHÓM KẾT QUẢ (nút 🔑 Cài nhóm Lark)') { luuCS((x) => { x.lyDo = 'chưa cài link NHÓM KẾT QUẢ (nút 🔑 Cài nhóm Lark)'; }); ghi('Chỉ số tuần: chưa cài link NHÓM KẾT QUẢ → chưa xem chỉ số (bấm 🔑 Cài nhóm Lark ở tab Chỉ số tuần)'); } return false; } // (6.20) chưa có nơi gửi thì không mở trang vô ích
    const viec = c.chay || (c.yc ? { loai: c.yc.loai, buoc: 0, kq: {}, batDau: Date.now() } : (tuDongDenGio && !(c.cho && Date.now() < c.cho) ? { loai: 'tudong', buoc: 0, kq: {}, batDau: Date.now() } : null));
    if (!viec) return false;
    if (document.visibilityState !== 'visible' && laTabChinh() && !tamDung()) nhacTabCS(viec); // (6.27) tab ẩn lúc tới giờ chỉ số → tự nhảy về tab Facebook; không được thì thông báo + chuông 15 phút/lần (07:45–09:00 thứ 6)
    const ly = lyDoBanCS();
    if (ly) {
      luuCS((x) => { x.lyDo = ly; });
      if (dangOTrangCS() && /sắp tới giờ|làm việc chính/.test(ly) && !lay('dang_do', null)) { datKenh(1); ghi('Chỉ số tuần: tạm dừng để nhường việc chính → về trang kênh 1'); veTrang(); return true; }
      return false;
    }
    if (!c.chay) { luuCS((x) => { x.chay = viec; if (x.yc) x.yc = null; x.lyDo = ''; }); ghi(`Chỉ số tuần: bắt đầu xem chỉ số (${viec.loai === 'tudong' ? 'tự động thứ 6' : viec.loai === 'soan' ? 'Soạn thử' : viec.loai === 'thu' ? 'Gửi thử' : 'Gửi ngay'})`); }
    if (Date.now() - (viec.batDau || Date.now()) > 20 * 60000) return loiCS(viec, 'quá 20 phút chưa xem xong 6 trang');
    datKenh(1);
    // bước 0: đúng tư cách page kênh 1 (giống trước mỗi lần đăng bài: menu tài khoản / nút Chuyển ngay)
    if (viec.buoc === 0) {
      if (hdChay) hdChay.chi = 'Chỉ số tuần: kiểm tra tư cách page kênh 1';
      let ok = false;
      try { ok = await damBaoTuCach(); } catch (e) { return loiCS(viec, 'sai tư cách page: ' + e.message); }
      if (!ok) return true; // đang chuyển tư cách → trang tải lại, lượt sau làm tiếp
      luuCS((x) => { x.chay.buoc = 1; }); viec.buoc = 1;
    }
    if (viec.buoc > CS.BUOC.length) return await buocTVCS(viec); // (6.28.1) đã đọc đủ 6 trang (bị ngắt giữa chừng lúc đọc video) → làm tiếp phần video, không đọc CS.BUOC[6] (lỗi 'ten')
    const b = CS.BUOC[viec.buoc - 1];
    if (!dungTrangCS(b)) { if (hdChay) hdChay.chi = `Chỉ số tuần ${viec.buoc}/6: mở trang ${b.ten}`; ghi(`Chỉ số tuần ${viec.buoc}/6: mở trang ${b.ten}`); await sleep(500); roiTrang(linkCS(b)); return true; }
    if (hdChay) hdChay.chi = `Chỉ số tuần ${viec.buoc}/6: đọc ${b.ten}`;
    let kq = null; const het = Date.now() + 25000;
    while (Date.now() < het) { kq = docTrangCS(b); if (kq) break; await sleepThat(1000); if (lyDoBanCS()) return false; }
    if (!kq) {
      if (!viec.f5) { luuCS((x) => { x.chay.f5 = 1; }); ghi(`Chỉ số tuần: ${b.ten} chưa hiện đủ số → tải lại trang`); roiTrang(linkCS(b)); return true; }
      const ngay = khoangNgayCS(document.body ? document.body.innerText : '', b.ky);
      if (ngay && /Chưa đủ dữ liệu/.test(document.body.innerText)) { kq = { so: null, khongRo: 'Facebook ghi "Chưa đủ dữ liệu", không có con số', pct: null, ngay }; ghi(`Chỉ số tuần: ${b.ten} — Facebook ghi "Chưa đủ dữ liệu" → ghi "Không xác định được" (không ghi 0)`); } // (6.31.2)
      else return loiCS(viec, `không đọc được ${b.ten}`);
    }
    if (b.ky === '28D' && kq.so != null && (b.trang === 'views' || b.trang === 'messaging')) { // (6.31.2) 28 ngày không thể ít hơn 7 ngày (23/10: 7 ngày 8.418 mà 28 ngày = 0) → đọc hụt, tải lại 1 lần; vẫn hụt → Không xác định được
      const k7 = (viec.kq || {})['7D' + b.trang];
      if (k7 && typeof k7.so === 'number' && kq.so < k7.so) {
        if (!viec.f5) { luuCS((x) => { x.chay.f5 = 1; }); ghi(`Chỉ số tuần: ${b.ten} = ${fmtSo(kq.so)} nhỏ hơn 7 ngày (${fmtSo(k7.so)}) → số chưa tải xong, tải lại trang`); roiTrang(linkCS(b)); return true; }
        ghi(`Chỉ số tuần: ${b.ten} vẫn = ${fmtSo(kq.so)} < 7 ngày ${fmtSo(k7.so)} sau khi tải lại → ghi "Không xác định được"`);
        kq = { so: null, khongRo: `đọc được ${fmtSo(kq.so)} nhưng nhỏ hơn số 7 ngày (${fmtSo(k7.so)})`, pct: null, ngay: kq.ngay };
      }
    }
    luuCS((x) => { x.chay.kq[b.ky + b.trang] = kq; x.chay.buoc++; x.chay.f5 = 0; });
    ghi(`Chỉ số tuần ${viec.buoc}/6: ${b.ten} = ${kq.so == null ? 'Không xác định được' : fmtSo(kq.so)}${kq.pct ? ' ' + fmtPct(kq.pct) : ''} (${kq.ngay.tu}–${kq.ngay.den})`);
    if (viec.buoc < CS.BUOC.length) { const b2 = CS.BUOC[viec.buoc]; await sleep(800); roiTrang(linkCS(b2)); return true; }
    return await xongCS();
  }
  async function loiCS(viec, loi) {
    const c = luuCS((x) => { x.lan = (x.lan || 0) + 1; x.loiDem = (x.loiDem || 0) + 1; x.loiCuoi = loi; x.lyDo = 'lỗi: ' + loi; x.cho = Date.now() + CS.CHO_LOI_PHUT * 60000; if (x.chay) { x.chay.buoc = 0; x.chay.f5 = 0; x.chay.batDau = Date.now() + CS.CHO_LOI_PHUT * 60000; } if (x.chay && x.chay.loai !== 'tudong') { x.kqLoi = { loai: x.chay.loai, loi, luc: Date.now() }; x.chay = null; } else if (x.chay) { x.chay = null; } });
    ghi(`Chỉ số tuần: lỗi (lần ${c.loiDem}) — ${loi} → ${viec.loai === 'tudong' ? CS.CHO_LOI_PHUT + ' phút sau thử lại' : 'dừng (việc bấm tay)'}`);
    if (viec.loai === 'tudong' && c.loiDem >= CS.BAO_SAU_LOI && !c.bao10) {
      luuCS((x) => { x.bao10 = Date.now(); });
      const thieu = CS.BUOC.filter((b) => !(viec.kq && viec.kq[b.ky + b.trang])).map((b) => b.ten).join(', ');
      await guiChuLoiCS(`${CS.TIEU_DE}: đã thử ${c.loiDem} lần vẫn chưa đọc được (lỗi cuối: ${loi}) — thiếu: ${thieu || 'không rõ'}. Script vẫn thử tiếp 5 phút/lần tới ${CS.DEN}.`);
    }
    if (dangOTrangCS() && !lay('dang_do', null)) { datKenh(1); veTrang(); }
    return true;
  }
  async function buocTVCS(viec) { // (6.28.4) mã đọc trang không trả lượt xem → mở trang Thông tin chi tiết của TỪNG video (tối đa 20, mỗi trang ≤ 20 giây); vẫn thiếu → Thư viện nội dung
    const vt = viec.kq && viec.kq.video;
    if (vt && vt.ds && viec.tv === 1) {
      const can = vt.ds.filter((p) => !p.mf && p.xem == null && !p.ttctXong).slice(0, 20);
      if (!can.length || Date.now() - (viec.batDau || 0) > 18 * 60000) { luuCS((x) => { if (x.chay) x.chay.tv = 3; }); viec.tv = 3; }
      else {
        const p = can[0];
        if (!dangOTTCTCua(p.id)) { if (hdChay) hdChay.chi = `Chỉ số tuần: mở Thông tin chi tiết "${p.ten}" (${vt.ds.length - can.length + 1}/${vt.ds.length})`; if (!viec.ttctGhi) { ghi('Chỉ số tuần: Facebook không trả lượt xem từng video qua mã đọc trang → mở trang Thông tin chi tiết của từng video'); luuCS((x) => { if (x.chay) x.chay.ttctGhi = 1; }); } await sleep(400); roiTrang(linkTTCT(p.id)); return true; }
        let r = null; const het = Date.now() + 20000; while (Date.now() < het && !r) { r = docTTCT(); if (!r) await sleepThat(1000); }
        if (r) { if (r.xem != null) p.xem = r.xem; if (r.theoDoi != null && p.theoDoi == null) p.theoDoi = r.theoDoi; ghi(`Chỉ số tuần: "${p.ten}" — lượt xem ${r.xem == null ? '?' : fmtSo(r.xem)}, theo dõi ${r.theoDoi == null ? '?' : fmtSo(r.theoDoi)} (trang Thông tin chi tiết)`); }
        else ghi(`Chỉ số tuần: trang Thông tin chi tiết của "${p.ten}" chưa hiện số sau 20 giây → bỏ qua`);
        p.ttctXong = 1;
        luuCS((x) => { if (x.chay) x.chay.kq.video = vt; });
        return await buocTVCS(Object.assign(viec, { kq: Object.assign(viec.kq, { video: vt }) }));
      }
    }
    if (viec.tv === 3 && vt && vt.ds && vt.ds.some((p) => !p.mf && p.xem == null)) { // còn thiếu → Thư viện nội dung (1 lần)
      if (!dangOTV()) { if (hdChay) hdChay.chi = 'Chỉ số tuần: mở Thư viện nội dung'; ghi('Chỉ số tuần: vẫn còn video thiếu lượt xem → mở Thư viện nội dung để đọc'); await sleep(500); roiTrang(LINK_TV); return true; }
      if (hdChay) hdChay.chi = 'Chỉ số tuần: đọc Thư viện nội dung';
      const ly = Object.assign({}, vt.ly);
      try {
        const rows = await docThuVien(); let n = 0;
        for (const p of vt.ds) { const r = khopTV(rows, p.khoa, p.id); if (!r) continue; if (p.xem == null && r.xem != null) { p.xem = r.xem; n++; } if (p.theoDoi == null && r.theoDoi != null) p.theoDoi = r.theoDoi; }
        ghi(`Chỉ số tuần: Thư viện nội dung có ${rows.length} bài → bổ sung lượt xem cho ${n} video`);
        if (!n && vt.ds.every((p) => p.mf || p.xem == null)) ly.xem = (ly.xem ? ly.xem + '; ' : '') + 'Thư viện nội dung không khớp được video nào';
      } catch (e) { if (vt.ds.every((p) => p.mf || p.xem == null)) ly.xem = (ly.xem || 'Facebook không trả lượt xem') + '; Thư viện nội dung: ' + e.message; ghi('Chỉ số tuần: chưa đọc được Thư viện nội dung (' + e.message + ')'); }
      vt.ly = ly;
    }
    if (vt && vt.ds) { if (vt.ds.some((p) => !p.mf && p.xem != null)) vt.ly = Object.assign({}, vt.ly, { xem: '' }); if (vt.ds.some((p) => !p.mf && p.theoDoi != null)) vt.ly = Object.assign({}, vt.ly, { theoDoi: '' }); }
    luuCS((x) => { if (x.chay) { x.chay.kq.video = vt; x.chay.tv = 4; } });
    return await xongCS();
  }
  async function xongCS() {
    const c = csTT(); const viec = c.chay; const kq = viec.kq;
    if (!kq.video) { // (6.26) phần video nổi bật kênh 1
      if (hdChay) hdChay.chi = 'Chỉ số tuần: đọc số từng video kênh 1';
      try { kq.video = await layVideoTuan(); } catch (e) { kq.video = { loi: e.message }; ghi('Báo cáo tuần: chưa đọc được số từng video (' + e.message + ') → báo cáo ghi "chưa đọc được"'); }
      if (kq.video.ds && !viec.tv && kq.video.ds.some((p) => !p.mf && p.xem == null && kq.video.luc - p.luc > 3600e3)) { // còn video thiếu lượt xem → trang Thông tin chi tiết từng video, rồi Thư viện nội dung
        luuCS((x) => { x.chay.kq.video = kq.video; x.chay.tv = 1; x.chay.buoc = CS.BUOC.length + 1; });
        return await buocTVCS(Object.assign({}, viec, { kq, tv: 1 }));
      }
    }
    luuCS((x) => { x.kqCuoi = { kq, luc: Date.now(), loai: viec.loai }; x.chay = null; });
    let thongBao = '';
    try {
      if (viec.loai === 'soan') thongBao = `Soạn thử xong (không gửi Lark) — bấm Gửi thử / Gửi ngay trong ${DUNG_LAI_PHUT} phút sẽ gửi đúng bản này`;
      else if (viec.loai === 'thu') { const kieu = await guiBaoCaoCS('thu', kq); thongBao = `Đã gửi thử vào NHÓM LỖI (dạng ${kieu})`; }
      else { // tự động / Gửi ngay → NHÓM KẾT QUẢ (1 lần / tuần)
        const c2 = csTT();
        if (viec.loai === 'tudong' && c2.guiLuc) thongBao = 'Tuần này đã gửi rồi → không gửi lại';
        else { const kieu = await guiBaoCaoCS(viec.loai, kq); thongBao = `Đã gửi báo cáo chính thức vào NHÓM KẾT QUẢ (dạng ${kieu})`; }
      }
      ghi('Chỉ số tuần: ' + thongBao + ' — ' + noiDungCS(kq, false, false).replace(/\n/g, ' · ').slice(0, 600));
      nhacNho('Chỉ số tuần: ' + thongBao);
    } catch (e) {
      ghi('Chỉ số tuần: gửi Lark chưa được — ' + e.message);
      if (viec.loai === 'tudong') { luuCS((x) => { x.cho = Date.now() + CS.CHO_LOI_PHUT * 60000; x.lyDo = 'lỗi gửi Lark: ' + e.message; x.loiDem = (x.loiDem || 0) + 1; }); }
      else { luuCS((x) => { x.kqLoi = { loai: viec.loai, loi: 'gửi Lark: ' + e.message, luc: Date.now() }; }); nhacNho('Chỉ số tuần: gửi chưa được — ' + e.message, 'vang', 8000); }
    }
    datKenh(1); if (!lay('dang_do', null)) veTrang();
    return true;
  }
  // ---------- popup: tab "Chỉ số tuần" ----------
  function trangThaiCS() {
    const c = csTT(); const now = new Date();
    if (c.chay) return `⏳ Đang xem chỉ số: bước ${Math.min(CS.BUOC.length, Math.max(1, c.chay.buoc))}/6${c.chay.buoc ? ' — ' + (c.chay.buoc > CS.BUOC.length ? 'đọc số từng video' : CS.BUOC[Math.max(0, c.chay.buoc - 1)].ten) : ' — kiểm tra tư cách page'} (${c.chay.loai === 'tudong' ? 'tự động' : c.chay.loai === 'soan' ? 'Soạn thử' : c.chay.loai === 'thu' ? 'Gửi thử' : 'Gửi ngay'})`;
    if (c.yc) return `⏳ Đang chờ script rảnh để ${c.yc.loai === 'soan' ? 'soạn thử' : c.yc.loai === 'thu' ? 'gửi thử' : 'gửi ngay'}${c.lyDo ? ' — ' + c.lyDo : ''}`;
    if (c.guiLuc) return `✅ Tuần này đã gửi lúc ${gioStr(new Date(c.guiLuc))} ${ngayStr(new Date(c.guiLuc)).slice(0, 5).replace('-', '/')}${c.guiLoai === 'ngay' ? ' (bấm Gửi ngay)' : ''}`;
    if (c.het) return `❌ Tuần này không gửi được (đã báo nhóm lỗi lúc ${gioStr(new Date(c.het))})${c.lyDo ? ' — ' + c.lyDo : ''}`;
    if (now.getDay() === 5 && phutTrongNgay(now) >= docGio(CS.TU)) return `⏳ ${c.loiDem ? `Đã thử ${c.loiDem} lần (lỗi: ${c.loiCuoi || ''}) — thử lại lúc ${c.cho ? gioStr(new Date(c.cho)) : 'sớm'}` : 'Đang chờ script rảnh'}${c.lyDo && !c.loiDem ? ' — ' + c.lyDo : ''}`;
    return `Chưa tới giờ — tự chạy thứ 6 (${tuanCS().slice(0, 5).replace('-', '/')}) từ ${CS.TU}, chậm nhất ${CS.DEN}`;
  }
  function tabChiSo() {
    const c = csTT(); const h = hookCS(); const k = c.kqCuoi;
    const o = (x) => (x ? `<b>${x.so == null ? 'Không xác định được' : fmtSo(x.so)}</b> ${fmtPct(x.pct) ? `<span style="color:${x.pct.dau === '-' ? 'var(--do-chu,#d93a3a)' : x.pct.dau === '+' ? '#2e9d57' : 'inherit'}">${esc(fmtPct(x.pct))}</span>` : ''}` : '<span class="mo">—</span>');
    const ng = (ky) => { const x = k && (k.kq[ky + 'views'] || k.kq[ky + 'messaging'] || k.kq[ky + 'audience']); return x ? `${ngayNgan(x.ngay.tu)}–${ngayNgan(x.ngay.den)}` : ''; };
    const bang = k ? `<table style="width:100%;border-collapse:collapse;margin:6px 0"><tr><th style="text-align:left;padding:4px"></th><th style="text-align:left;padding:4px">7 ngày <span class="mo">${ng('7D')}</span></th><th style="text-align:left;padding:4px">28 ngày <span class="mo">${ng('28D')}</span></th></tr>${[['views', '👁 Lượt xem'], ['messaging', '💬 Người liên hệ nhắn tin'], ['audience', '👥 Người theo dõi thực']].map(([t, ten]) => `<tr style="border-top:1px solid var(--vien,#ddd)"><td style="padding:4px">${ten}</td><td style="padding:4px">${o(k.kq['7D' + t])}</td><td style="padding:4px">${o(k.kq['28D' + t])}</td></tr>`).join('')}</table><div class="mo">Kiểm lúc ${gioStr(new Date(k.luc))} ${ngayStr(new Date(k.luc)).slice(0, 5).replace('-', '/')} (${k.loai === 'tudong' ? 'tự động' : k.loai === 'soan' ? 'Soạn thử' : k.loai === 'thu' ? 'Gửi thử' : 'Gửi ngay'})</div>` : '<div class="mo">Chưa có lần kiểm nào.</div>';
    const ban = !!(c.chay || c.yc || (c.dangGui && Date.now() - c.dangGui < 2 * 60000));
    const nut = (a, chu, chinh) => `<button class="nut${chinh ? ' chinh' : ''}" data-a="${a}" ${ban || !LA_CAO ? 'disabled' : ''}>${chu}</button>`;
    return `<div class="the-nd"><h4${fbToi() ? ' style="color:#f2f3f5"' : ''}>📊 Báo cáo chỉ số tuần fb kênh 1 <span class="mo">(${esc(CAI_DAT.KENH[1].ngan)} · chỉ Máy Cao · phần phụ, nhường việc chính)</span></h4>
      <div class="ghichu" style="margin:6px 0"><b>Tuần này:</b> ${esc(trangThaiCS())}</div>
      ${c.kqLoi ? `<div class="mo" style="color:var(--do-chu,#d93a3a)">Lần bấm tay gần nhất (${esc(c.kqLoi.loai === 'soan' ? 'Soạn thử' : c.kqLoi.loai === 'thu' ? 'Gửi thử' : 'Gửi ngay')} lúc ${gioStr(new Date(c.kqLoi.luc))}): ${esc(c.kqLoi.loi)}</div>` : ''}
      ${bang}
      ${k && k.kq ? xemTruocCS(k) : ''}
      <div style="margin:6px 0"><div class="mo"><b>📝 Ghi chú thêm</b> — có chữ thì thêm 1 dòng ghi chú ở cuối tin khi gửi (Gửi ngay xong tự xoá)</div><textarea class="cmtta" rows="2" data-o="cs_ghichu" placeholder="Để trống = không thêm ghi chú">${esc(lay('csghichu6', '') || '')}</textarea></div>
      <div class="hang" style="margin-top:8px">${nut('cs_soan', '✎ Soạn thử')}${nut('cs_thu', '🧪 Gửi thử (nhóm lỗi)')}${nut('cs_ngay', '📤 Gửi ngay (nhóm kết quả)', true)}</div>
      <div class="mo">Soạn thử: soạn đầy đủ tin sắp gửi và hiện ở trên, không gửi Lark — trong ${DUNG_LAI_PHUT} phút bấm Gửi thử / Gửi ngay sẽ gửi đúng bản này (không xem lại 6 trang) · Gửi thử: gửi vào NHÓM LỖI, không tính là đã gửi tuần này · Gửi ngay: gửi báo cáo chính thức vào NHÓM KẾT QUẢ (tính là đã gửi tuần này). Cả 3 nút đều chờ script rảnh (≥ ${CS.RANH_PHUT} phút trước bài kế tiếp) rồi mới mở trang chỉ số.</div>
      <div class="hang" style="margin-top:8px"><span>Nhóm Lark: <b>Kết quả</b> ${h.kq ? '🟢 đã cài' : '🔴 chưa cài'} · <b>Lỗi</b> ${h.loi ? '🟢 đã cài' : '🔴 chưa cài'}</span><button class="nut nho" data-a="cs_hook">🔑 Cài nhóm Lark</button></div>
      <div class="mo">Lịch tự động: thứ 6 từ ${CS.TU}, khi script rảnh; lỗi thì ${CS.CHO_LOI_PHUT} phút thử lại, ${CS.BAO_SAU_LOI} lần lỗi báo nhóm lỗi; ${CS.DEN} chưa gửi được thì báo nhóm lỗi rồi thôi. Máy tắt / Chrome đóng thì không chạy được.</div></div>`;
  }
  const mdHtmlCS = (s) => { // markdown thẻ Lark → HTML xem trước (đậm, link, màu %)
    const re = /\[([^\]]+)\]\((https?:\/\/[^)\s]+)\)|\*\*([^*]+)\*\*|<font color='(\w+)'>([^<]*)<\/font>|\*([^*\n]+)\*/g; let o = '', i = 0, m;
    while ((m = re.exec(s))) { o += esc(s.slice(i, m.index)); if (m[1]) o += `<a href="${esc(m[2])}" target="_blank" rel="noopener" style="color:#3370ff">${esc(m[1])}</a>`; else if (m[3]) o += `<b>${esc(m[3])}</b>`; else if (m[6]) o += `<i style="color:#646a73">${esc(m[6])}</i>`; else o += `<span style="color:${m[4] === 'red' ? '#d93a3a' : m[4] === 'green' ? '#2e9d57' : '#8f959e'}">${esc(m[5])}</span>`; i = re.lastIndex; }
    return (o + esc(s.slice(i))).replace(/\n/g, '<br>');
  };
  function xemTruocCS(k) { // (6.28.1) khung giống hệt thẻ Lark sắp gửi
    const the = theCS(k.kq, false, ghiChuCS()).card; const het = k.luc + DUNG_LAI_PHUT * 60000; const conDung = Date.now() < het && tuanCS(new Date(k.luc)) === tuanCS();
    const ve = (e) => e.tag === 'hr' ? '<hr style="border:0;border-top:1px solid #dee0e3;margin:8px 0">'
      : e.tag === 'note' ? `<div style="color:#8f959e;font-size:11.5px;margin-top:6px">${esc(e.elements[0].content)}</div>`
      : e.tag === 'column_set' ? `<div style="display:flex;gap:8px;margin:4px 0 2px">${e.columns.map((c) => `<div style="flex:1;background:#f2f3f5;border-radius:6px;padding:6px 4px">${c.elements.map(ve).join('')}</div>`).join('')}</div>`
      : e.tag === 'div' && e.text.tag === 'plain_text' ? `<div style="height:6px"></div>`
      : `<div style="${e.text_align === 'center' ? 'text-align:center;' : ''}${e.text_size === 'heading' ? 'font-size:20px;line-height:1.3;' : ''}">${mdHtmlCS(e.tag === 'div' ? e.text.content : e.content)}</div>`;
    const than = the.elements.map(ve).join('');
    return `<div class="mo" style="margin-top:8px"><b>Xem trước tin Lark</b> · Soạn lúc ${gioStr(new Date(k.luc))} — ${conDung ? `dùng lại được tới ${gioStr(new Date(het))}` : 'đã quá ' + DUNG_LAI_PHUT + ' phút, bấm Gửi sẽ soạn lại từ đầu'}</div>
      <div style="border:1px solid #dee0e3;border-radius:8px;overflow:hidden;margin:4px 0 6px;background:#fff;color:#1f2329;font-size:12.5px;line-height:1.5"><div style="background:#3370ff;color:#fff;font-weight:600;padding:8px 10px">${esc(the.header.title.content)}</div><div style="padding:8px 10px">${than}</div></div>`;
  }
  async function guiLaiCS(loai, k) { // (6.28.1) dùng lại bản soạn < 30 phút → gửi luôn, không xem lại 6 trang
    const ten = loai === 'thu' ? 'Gửi thử' : 'Gửi ngay';
    ghi(`Bấm ${ten} chỉ số tuần → dùng lại bản soạn lúc ${gioStr(new Date(k.luc))} (chưa quá ${DUNG_LAI_PHUT} phút), không xem lại 6 trang`);
    luuCS((x) => { x.kqLoi = null; x.dangGui = Date.now(); }); veBangNgay();
    try { const kieu = await guiBaoCaoCS(loai, k.kq); const tb = loai === 'thu' ? `Đã gửi thử vào NHÓM LỖI (dạng ${kieu})` : `Đã gửi báo cáo chính thức vào NHÓM KẾT QUẢ (dạng ${kieu})`; ghi('Chỉ số tuần: ' + tb + ' — bản soạn lúc ' + gioStr(new Date(k.luc))); nhacNho('Chỉ số tuần: ' + tb); }
    catch (e) { luuCS((x) => { x.kqLoi = { loai, loi: 'gửi Lark: ' + e.message, luc: Date.now() }; }); ghi('Chỉ số tuần: gửi Lark chưa được — ' + e.message); nhacNho('Chỉ số tuần: gửi chưa được — ' + e.message, 'vang', 8000); }
    finally { luuCS((x) => { x.dangGui = null; }); veBangNgay(); }
  }
  async function bamChiSo(hd) { // nút trong tab Chỉ số tuần
    if (hd === 'cs_hook') {
      const kq = prompt('Dán link NHÓM KẾT QUẢ (chỉ nhận báo cáo chính thức mỗi tuần):\n(để trống = giữ link đang có)'); if (kq == null) return;
      const loi = prompt('Dán link NHÓM LỖI (nhận tin lỗi + tin gửi thử):\n(để trống = giữ link đang có)'); if (loi == null) return;
      const b = Object.assign({}, lay('bimat6', null) || {}); const k1 = kq.trim() || b.csKQ || '', l1 = loi.trim() || b.csLoi || '';
      if ((k1 && !LINK_HOOK_RE.test(k1)) || (l1 && !LINK_HOOK_RE.test(l1))) { alert('Link không đúng dạng (phải bắt đầu bằng https://open.larksuite.com/open-apis/bot/v2/hook/...). Cao copy lại giúp nhé.'); return; }
      if (k1 && k1 === l1) { alert('2 link đang giống nhau — nhóm kết quả và nhóm lỗi phải là 2 nhóm khác nhau.'); return; }
      b.csKQ = k1; b.csLoi = l1; luu('bimat6', b); ghi('Chỉ số tuần: đã cài link nhóm Lark (kết quả ' + (k1 ? 'có' : 'chưa') + ', lỗi ' + (l1 ? 'có' : 'chưa') + ')'); nhacNho('Đã lưu link nhóm Lark cho báo cáo chỉ số tuần'); veBangNgay(); return;
    }
    if (!LA_CAO) { alert('Báo cáo chỉ số tuần chỉ chạy trên Máy Cao.'); return; }
    const loai = hd === 'cs_soan' ? 'soan' : hd === 'cs_thu' ? 'thu' : 'ngay';
    const h = hookCS();
    if (loai === 'thu' && !h.loi) { alert('Chưa cài link NHÓM LỖI — bấm 🔑 Cài nhóm Lark trước.'); return; }
    if (loai === 'ngay' && !h.kq) { alert('Chưa cài link NHÓM KẾT QUẢ — bấm 🔑 Cài nhóm Lark trước.'); return; }
    const c = csTT();
    if (loai === 'ngay' && c.tuan === tuanCS() && c.guiLuc && !confirm(`Tuần này đã gửi báo cáo lúc ${gioStr(new Date(c.guiLuc))}. Vẫn gửi thêm 1 báo cáo chính thức nữa vào NHÓM KẾT QUẢ?`)) return;
    { const k = c.kqCuoi; if (loai !== 'soan' && k && k.kq && Date.now() - k.luc < DUNG_LAI_PHUT * 60000 && tuanCS(new Date(k.luc)) === tuanCS() && (loai === 'thu' || duSoCS(k.kq))) return await guiLaiCS(loai, k); }
    luuCS((x) => { if (x.tuan !== tuanCS()) { x.tuan = tuanCS(); } x.yc = { loai, luc: Date.now() }; x.kqLoi = null; });
    ghi(`Bấm ${loai === 'soan' ? 'Soạn thử' : loai === 'thu' ? 'Gửi thử' : 'Gửi ngay'} chỉ số tuần`);
    nhacNho(lyDoBanCS() ? `Đã nhận — chờ script rảnh (${lyDoBanCS()})` : 'Đã nhận — bắt đầu xem chỉ số');
    veBangNgay(); setTimeout(() => { if (!lyDoBanCS() && !csDangChay) vongChiSo().catch((e) => ghi('Chỉ số tuần lỗi: ' + e.message)); }, 300); // (6.20.6) bấm tay → chạy ngay, không đợi tới cuối nhịp
  }

  // =====================================================================
  //  (6.26) BÁO CÁO TUẦN — PHẦN "VIDEO NỔI BẬT" KÊNH 1 (lấy qua Facebook bằng mã đọc trang, không tốn Lark)
  //  Xếp hạng trong video đăng 7 ngày qua và 28 ngày qua (số liệu tính đến lúc gửi):
  //   1. Lượt xem top 3 · video xem nhiều nhất không tính #manifest · 24h đầu sau khi đăng: thấp nhất / cao nhất
  //   2. Video mang lại nhiều lượt theo dõi nhất · 3. Tương tác top 3 (thích + bình luận của khách + chia sẻ)
  //  Lượt xem 24h đầu: Máy Cao tự ghi lại đúng lúc mỗi video tròn 24h (ô v24_6 trong máy) — video đăng trước khi cài bản này chưa có số.
  // =====================================================================
  const tenVid = (p) => { let t = String(p.text || '').split('\n').map((x) => chuan(x.replace(/#\S+/g, '')).trim()).find(Boolean) || '';
    if (!t) t = tenTuSheet(p) || (p.luc ? `Video đăng ${gioStr(new Date(p.luc))} ${ngayStr(new Date(p.luc)).slice(0, 5).replace('-', '/')}` : 'Video'); // (6.28.4) bài không có chữ → lấy chữ ở sheet theo link, không có thì ghi giờ đăng
    return t.length > 40 ? t.slice(0, 39) + '…' : t; };
  const tenTuSheet = (p) => { try { const d = duLieu(); if (!d || !d.ngay || !p.link) return ''; const id = (p.link.match(/\/(?:reel|videos)\/(\d+)/) || [])[1]; if (!id) return ''; for (const n of Object.values(d.ngay)) for (const x of (n.v || [])) if (x.link && String(x.link).includes(id) && x.cap) return String(x.cap).split('\n')[0].trim(); } catch (e) { /* */ } return ''; };
  const laManifestVid = (p) => /#manifest/i.test(p.text || '');
  const HOI_MUA_RE = /\bgia\b(?! dinh)|bao nhieu|\bib\b|\binbox|\bin box|tu van|\bcon (khong|ko|k|hang)\b|\bmua\b|\bchot\b|\bship|\bsize\b|\bsz\b|zalo|\bsdt\b|so dien thoai|\bxin gia/; // (6.28.1) comment hỏi mua → ước tính nhắn tin theo video (so trên chữ đã bỏ dấu: khách hay gõ không dấu)
  const boDauCS = (s) => thuong(s).normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/đ/g, 'd');
  async function dsVideoK1(tuMs) { // video kênh 1 đăng từ tuMs: id bài, id video, chữ, link, giờ, thích, bình luận (của khách), chia sẻ, comment hỏi mua
    const pid = idTrangKenh(1), tok = tokenTrang(1); if (!pid || !tok) throw new Error('chưa có mã đọc trang kênh 1');
    let url = `/${pid}/posts?fields=id,message,created_time,permalink_url,shares,reactions.summary(total_count).limit(0),comments.filter(stream).limit(100).summary(total_count){from{id},message},attachments{media_type,type,target{id}}&limit=25&since=${Math.floor(tuMs / 1000)}`;
    const out = [];
    for (let i = 0; i < 10 && url; i++) {
      const j = await goiFb(url, tok);
      for (const p of j.data || []) {
        const at = ((p.attachments || {}).data || [])[0] || {}; const link = p.permalink_url || '';
        const laVid = /video|reel/i.test(at.media_type || '') || /video|reel/i.test(at.type || '') || /\/(reel|videos)\//.test(link);
        if (!laVid) continue;
        const vid = (at.target && at.target.id) || ((link.match(/\/(?:reel|videos)\/([^/?#]+)/) || [])[1]) || '';
        const cm = (p.comments || {}); const khach = (cm.data || []).filter((c) => !(c.from && String(c.from.id) === String(pid)));
        out.push({ id: p.id, vid, text: p.message || '', link, luc: Date.parse(String(p.created_time).replace(/([+-]\d\d)(\d\d)$/, '$1:$2')),
          thich: ((p.reactions || {}).summary || {}).total_count || 0, binhLuan: khach.length, chiaSe: (p.shares || {}).count || 0, hoiMua: khach.filter((c) => HOI_MUA_RE.test(boDauCS(c.message || '')) || /đặt (hàng|mua|cho|giúp|\d)/.test(thuong(c.message || ''))).length });
      }
      const next = j.paging && j.paging.next; url = next ? next.replace(/^https:\/\/graph\.facebook\.com(\/v[\d.]+)?/, '') : null;
    }
    return out;
  }
  async function soVideo(vid) { // → { xem, theoDoi, loi } (null = Facebook không trả số; loi = lý do Facebook từ chối)
    const tok = tokenTrang(1); const kq = { xem: null, theoDoi: null, loi: '' }; if (!vid) { kq.loi = 'không tìm thấy mã video'; return kq; }
    const doc = (j) => { for (const m of j.data || []) { const v = ((m.values || [])[0] || {}).value; const n = typeof v === 'number' ? v : (v && typeof v === 'object' ? Object.values(v).reduce((a, b) => a + (+b || 0), 0) : null); if (n == null) continue; if (/play_count|total_video_views|video_views/.test(m.name) && kq.xem == null) kq.xem = n; if (/followers/.test(m.name)) kq.theoDoi = n; } };
    for (const mt of ['blue_reels_play_count,post_video_followers', 'blue_reels_play_count', 'total_video_views']) {
      try { const j = await goiFb(`/${vid}/video_insights?metric=${mt}`, tok); doc(j); if (kq.xem != null) break; if (!kq.loi && !(j.data || []).length) kq.loi = `Facebook trả danh sách rỗng (${mt})`; } catch (e) { if (/\b190\b/.test(e.message)) throw e; if (!kq.loi) kq.loi = String(e.message || e).slice(0, 160); }
    }
    return kq;
  }
  // ---- (6.28.1) Thư viện nội dung: bảng có cột Lượt xem / Lượt theo dõi; cuộn để lấy hết (bảng chỉ vẽ ~16 dòng) ----
  const soTV = (s) => { const t = sachCS(s).replace(/\s+/g, ''); const m = t.match(/^([\d.,]+)(K|N|Tr|M)?/i); if (!m) return null; if (m[2]) { const n = parseFloat(m[1].replace(',', '.')); return Number.isFinite(n) ? Math.round(n * (/^(k|n)$/i.test(m[2]) ? 1e3 : 1e6)) : null; } const n = parseInt(m[1].replace(/[^\d]/g, ''), 10); return Number.isFinite(n) ? n : null; };
  const khopTV = (rows, khoa, id) => { // (6.28.2) khớp theo MÃ BÀI (link "Thông tin chi tiết" của dòng gốc) — nhiều video cùng câu mở đầu nên khớp chữ dễ nhầm
    const pid = String(id || '').split('_').pop();
    if (pid) { const r = rows.find((x) => x.pid === pid || x.pid === String(id)); if (r) return r; }
    const k = String(khoa || ''); if (k.length < 20) return null;
    const ung = rows.filter((r) => r.goc && r.khoa.startsWith(k.slice(0, 80))); return ung.length === 1 ? ung[0] : null; // chỉ khi chữ khớp đúng 1 dòng gốc
  };
  const maBaiTV = (r) => { const a = r.querySelector('a[href*="content_id="]'); if (!a) return ''; try { const d = atob(new URL(a.href).searchParams.get('content_id').replace(/-/g, '+').replace(/_/g, '/')); const m = d.match(/^S:_I\d+:([^:]+)/); return m ? m[1] : ''; } catch (e) { return ''; } };
  async function docThuVien() { // → [{khoa, xem, theoDoi}] (bài chia sẻ vào nhóm hiện thêm dòng số 0 → lấy số lớn nhất)
    let cot = null; const het = Date.now() + 30000;
    while (Date.now() < het) { const h = Array.from(document.querySelectorAll('[role="columnheader"]')).map((e) => sachCS(e.innerText)); const ix = h.indexOf('Lượt xem'); if (ix >= 0 && document.querySelector('[role="row"] [role="gridcell"]')) { cot = { xem: ix, td: h.indexOf('Lượt theo dõi') }; break; } await sleepThat(1000); }
    if (!cot) throw new Error('trang không hiện bảng số (không thấy cột "Lượt xem")');
    const gap = new Map();
    const doc = () => { let moi = 0; for (const r of document.querySelectorAll('[role="row"]')) { const o = r.querySelectorAll('[role="gridcell"]'); if (o.length <= cot.xem) continue; const pid = maBaiTV(r); if (!pid) continue; // (6.28.2) chỉ dòng GỐC (có link Thông tin chi tiết); dòng chia sẻ vào nhóm bỏ qua
      if (gap.has(pid)) continue; gap.set(pid, { pid, goc: true, khoa: khoaSo(o[1] ? o[1].innerText : '').slice(0, 120), xem: soTV(o[cot.xem].innerText), theoDoi: cot.td >= 0 && o[cot.td] ? soTV(o[cot.td].innerText) : null }); moi++; } return moi; };
    let khong = 0;
    for (let i = 0; i < 60 && khong < 4; i++) {
      khong = doc() ? 0 : khong + 1;
      const rows = document.querySelectorAll('[role="row"]'); const cuoi = rows[rows.length - 1];
      if (cuoi) { try { cuoi.scrollIntoView({ block: 'end' }); } catch (e) { /* */ } let p = cuoi.parentElement; while (p && p !== document.body) { const st = getComputedStyle(p); if (/(auto|scroll)/.test(st.overflowY) && p.scrollHeight > p.clientHeight + 5) { p.scrollTop += Math.max(200, p.clientHeight * 0.8); break; } p = p.parentElement; } }
      try { window.scrollBy(0, 600); } catch (e) { /* */ }
      await sleepThat(900);
    }
    return Array.from(gap.values());
  }
  // ---- lượt xem 24h đầu: Máy Cao, ~30 phút/lần, video kênh 1 vừa tròn 24h (24–36h) chưa ghi thì hỏi Facebook 1 lần; Facebook không trả → chờ máy rảnh đọc ở Thư viện nội dung ----
  async function ghiXem24h() {
    if (!LA_CAO || !MAY || !coApiKenh(1)) return false;
    const c = lay('v24_6', null) || { luc: 0, ds: {} }; if (Date.now() - (c.luc || 0) < 30 * 60000) return false;
    c.luc = Date.now(); luu('v24_6', c);
    try {
      const t = lay('tv24_6', null) || { ds: {}, thu: 0 };
      const ds = (await dsVideoK1(Date.now() - 36 * 3600e3)).filter((p) => { const tuoi = Date.now() - p.luc; return tuoi >= 24 * 3600e3 && tuoi <= 36 * 3600e3 && !c.ds[p.id]; });
      for (const p of ds) {
        const s = await soVideo(p.vid);
        if (s.xem == null) { if (!t.ds[p.id]) { t.ds[p.id] = { luc: p.luc, ten: tenVid(p), link: p.link, mf: laManifestVid(p), khoa: khoaSo(p.text).slice(0, 120), lan: 0 }; ghi(`Báo cáo tuần: Facebook không trả lượt xem 24h của "${tenVid(p)}" (${s.loi || 'không rõ lý do'}) → chờ máy rảnh mở trang Thông tin chi tiết của video`); } continue; }
        c.ds[p.id] = { xem: s.xem, sau: Math.round((Date.now() - p.luc) / 3600e3 * 10) / 10, luc: p.luc, ten: tenVid(p), link: p.link, mf: laManifestVid(p) };
        ghi(`Báo cáo tuần: ghi lượt xem 24h đầu của "${tenVid(p)}" = ${fmtSo(s.xem)} (sau ${c.ds[p.id].sau} giờ)`);
      }
      for (const k of Object.keys(c.ds)) if (Date.now() - (c.ds[k].luc || 0) > 40 * 864e5) delete c.ds[k]; // giữ 40 ngày
      luu('v24_6', c); luu('tv24_6', t);
    } catch (e) { ghi('Báo cáo tuần: chưa ghi được lượt xem 24h (' + e.message + ')'); }
    return true;
  }
  // (6.28.4) trang "Thông tin chi tiết" của 1 bài: /content/insights/?content_id=base64("S:_I<mã trang>:<mã bài>:<mã bài>") — đọc được Lượt xem, Lượt theo dõi kể cả khi mã thiếu quyền
  const linkTTCT = (postId) => { const pid = String(postId).split('_'); const trang = pid.length > 1 ? pid[0] : idTrangKenh(1); const bai = pid[pid.length - 1]; return 'https://www.facebook.com/content/insights/?content_id=' + encodeURIComponent(btoa(`S:_I${trang}:${bai}:${bai}`)); };
  const dangOTTCT = () => /^\/content\/insights/.test(location.pathname);
  const dangOTTCTCua = (postId) => { if (!dangOTTCT()) return false; try { const d = atob(new URLSearchParams(location.search).get('content_id') || ''); return d.split(':').pop() === String(postId).split('_').pop(); } catch (e) { return false; } };
  function docTTCT() { // → { xem, theoDoi, tuongTac } hoặc null (chưa hiện số)
    const L = String(document.body ? document.body.innerText : '').split('\n').map(sachCS).filter(Boolean);
    const sau = (nhan) => { const i = L.findIndex((x) => x === nhan); if (i < 1) return null; const v = L[i - 1]; return laSo(v) ? soCS(v) : null; }; // số đứng ngay TRƯỚC nhãn
    const xem = sau('Lượt xem'); if (xem == null) return /Không có thông tin chi tiết|Chưa đủ dữ liệu/.test(L.join(' ')) ? { xem: 0, theoDoi: 0, tuongTac: 0 } : null;
    const td = (() => { const i = L.findIndex((x) => x === 'Lượt theo dõi'); if (i < 0) return null; for (let j = i + 1; j < Math.min(L.length, i + 4); j++) if (laSo(L[j])) return soCS(L[j]); return null; })();
    const tt = (() => { const m = L.find((x) => /^\d[\d.,]*\s*Lượt tương tác$/.test(x)); return m ? soCS(m) : null; })();
    return { xem, theoDoi: td, tuongTac: tt };
  }
  async function vongTV24() { // (6.28.4) Máy Cao rảnh → mở trang Thông tin chi tiết của từng video Facebook không trả số (mỗi video 1 lần, tối đa 3 lần, 60 phút/lượt)
    if (!LA_CAO || !MAY) return false;
    const t = lay('tv24_6', null); if (!t || !t.ds) return false;
    const c = csTT(); if (c.chay || c.yc) return false;
    const now = Date.now(); const veLai = () => { if ((dangOTTCT() || dangOTV()) && !lay('dang_do', null)) { datKenh(1); veTrang(); return true; } return false; };
    for (const k of Object.keys(t.ds)) { const x = t.ds[k]; if (now - x.luc > 40 * 3600e3 || (x.lan >= 3 && !t.dang)) { ghi(`Báo cáo tuần: không ghi được lượt xem 24h đầu của "${x.ten}" (Facebook không trả số, trang Thông tin chi tiết cũng chưa đọc được)`); delete t.ds[k]; } }
    const cho = Object.keys(t.ds);
    if (t.dang && (now - t.dang > 10 * 60000 || !cho.length || lyDoBanCS())) { t.dang = 0; t.dangK = ''; luu('tv24_6', t); return veLai(); }
    if (!cho.length) { luu('tv24_6', t); return false; }
    if (t.dang) {
      const k = t.dangK && t.ds[t.dangK] ? t.dangK : cho[0]; const x = t.ds[k];
      if (!dangOTTCTCua(k)) { t.dangK = k; luu('tv24_6', t); if (hdChay) hdChay.chi = `Báo cáo tuần: mở Thông tin chi tiết "${x.ten}"`; roiTrang(linkTTCT(k)); return true; }
      let r = null; const het = Date.now() + 20000; while (Date.now() < het && !r) { r = docTTCT(); if (!r) await sleepThat(1000); }
      const v = lay('v24_6', null) || { luc: 0, ds: {} };
      if (r && r.xem != null) { v.ds[k] = { xem: r.xem, theoDoi: r.theoDoi, sau: Math.round((Date.now() - x.luc) / 3600e3 * 10) / 10, luc: x.luc, ten: x.ten, link: x.link, mf: x.mf, tv: 2 }; delete t.ds[k]; luu('v24_6', v); ghi(`Báo cáo tuần: ghi lượt xem 24h đầu của "${x.ten}" = ${fmtSo(r.xem)} (trang Thông tin chi tiết, sau ${v.ds[k].sau} giờ)`); }
      else ghi(`Báo cáo tuần: trang Thông tin chi tiết của "${x.ten}" chưa hiện số (lần ${x.lan})`);
      t.dangK = '';
      const con = Object.keys(t.ds).filter((kk) => (t.ds[kk].lan || 0) < 3 && Date.now() - (t.ds[kk].luc || 0) <= 40 * 3600e3);
      if (con.length && Date.now() - t.dang < 8 * 60000 && !lyDoBanCS()) { t.dangK = con[0]; t.ds[con[0]].lan = (t.ds[con[0]].lan || 0) + 1; luu('tv24_6', t); roiTrang(linkTTCT(con[0])); return true; } // video kế tiếp
      t.dang = 0; luu('tv24_6', t); datKenh(1); if (!lay('dang_do', null)) veTrang(); return true;
    }
    if (now - (t.thu || 0) < 60 * 60000 || lyDoBanCS()) return false;
    t.dang = now; t.thu = now; t.dangK = cho[0]; t.ds[cho[0]].lan = (t.ds[cho[0]].lan || 0) + 1; luu('tv24_6', t);
    ghi(`Báo cáo tuần: máy đang rảnh → mở trang Thông tin chi tiết đọc lượt xem 24h của ${cho.length} video`); datKenh(1); roiTrang(linkTTCT(cho[0])); return true;
  }
  async function khoaManifestSheet() { // (6.28.2) chữ các hàng Manifest (cột G tab Kênh 1) → nhận ra manifest cả khi bài quên gắn #manifest
    try { const v = await docBang(CAI_DAT.TAB_VIDEO, 'G1:G3000'); return new Set(v.map((r) => (r || [])[0]).filter((c) => c && !coTep(c)).map((c) => khoaSo(chuO(c)).slice(0, 40)).filter((k) => k.length >= 15)); }
    catch (e) { ghi('Báo cáo tuần: chưa đọc được cột Manifest trong sheet (' + e.message + ') → chỉ nhận manifest theo #manifest'); return new Set(); }
  }
  async function layVideoTuan() { // gọi trước khi gửi báo cáo tuần — (6.28.2) chỉ video chính, bỏ toàn bộ manifest
    const t0 = Date.now(); const tatCa = await dsVideoK1(Date.now() - 28 * 864e5);
    const mfSheet = await khoaManifestSheet();
    const laMf = (p) => laManifestVid(p) || (p.text && mfSheet.has(khoaSo(p.text).slice(0, 40)));
    const ds = tatCa.filter((p) => !laMf(p));
    ghi(`Báo cáo tuần: ${tatCa.length} video kênh 1 trong 28 ngày → bỏ ${tatCa.length - ds.length} manifest (theo #manifest + ${mfSheet.size} hàng Manifest trong sheet), còn ${ds.length} video chính`);
    if (!ds.length) throw new Error('không thấy video chính nào của kênh 1 trong 28 ngày qua');
    let lyXem = '';
    for (const p of ds) { const s = await soVideo(p.vid); p.xem = s.xem; p.theoDoi = s.theoDoi; p.tuongTac = p.thich + p.binhLuan + p.chiaSe; if (s.xem == null && s.loi && !lyXem) lyXem = s.loi; }
    if (ds.every((p) => p.xem == null)) ghi(`Báo cáo tuần: Facebook không trả lượt xem của từng video — lý do Facebook: ${lyXem || 'không rõ'}`);
    const v24 = (lay('v24_6', null) || { ds: {} }).ds;
    ghi(`Báo cáo tuần: đọc số ${ds.length} video kênh 1 trong 28 ngày qua (${Math.round((Date.now() - t0) / 1000)} giây)`);
    return { luc: Date.now(), ly: { xem: lyXem ? 'Facebook: ' + lyXem : '', theoDoi: lyXem ? 'Facebook: ' + lyXem : '' }, ds: ds.map((p) => ({ id: p.id, ten: tenVid(p), link: p.link, luc: p.luc, mf: laManifestVid(p), khoa: khoaSo(p.text).slice(0, 120), xem: p.xem, theoDoi: p.theoDoi, thich: p.thich, binhLuan: p.binhLuan, chiaSe: p.chiaSe, tuongTac: p.tuongTac, hoiMua: p.hoiMua || 0, x24: v24[p.id] ? v24[p.id].xem : null })) };
  }
  function loiVideoCS(vt) { // các mục "chưa đọc được" (để báo nhóm lỗi)
    if (!vt) return [];
    if (vt.loi || !vt.ds) return ['cả phần video (' + (vt.loi || 'không rõ') + ')'];
    const ly = vt.ly || {}; const out = [];
    if (!vt.ds.some((p) => p.xem != null)) out.push('Lượt xem (' + (ly.xem || 'Facebook không trả số') + ')');
    if (!vt.ds.some((p) => p.theoDoi != null)) out.push('Follow (' + (ly.theoDoi || 'Facebook không trả số') + ')');
    if (!vt.ds.some((p) => vt.luc - p.luc <= 7 * 864e5 && p.x24 != null)) out.push('Lượt xem 24h đầu (chưa có video nào được ghi số lúc tròn 24h)');
    return out;
  }
  const ngan = (l) => { const t = String(l || ''); if (!t) return 'Facebook không trả số'; if (/read_insights|permission/i.test(t)) return 'mã đọc trang chưa có quyền xem thống kê'; if (/190|expired|hết hạn/i.test(t)) return 'mã đọc trang hết hạn'; if (/Thư viện/i.test(t)) return 'Facebook không trả số, Thư viện nội dung cũng không khớp'; return t.length > 60 ? t.slice(0, 57) + '…' : t; }; // (6.28.4) lỗi trong thẻ: 1 dòng ngắn — câu gốc vào nhật ký + nhóm lỗi
  function dongVideoTuan(vt, mau) { // (6.28.2) chỉ video chính · mỗi video 1 dòng · 7 ngày trên, 28 ngày dưới
    const dau = '**📊 VIDEO NỔI BẬT (kênh 1 · chỉ video chính, không tính manifest)**';
    if (!vt) return [];
    if (vt.loi || !vt.ds) return [dau, `Chưa đọc được (${ngan(vt.loi)})`];
    const ly = vt.ly || {}; const chua = (k) => `chưa đọc được (${ngan(ly[k])})`;
    const L = (p) => (mau && p.link ? `[${p.ten}](${p.link})` : p.ten);
    const ds0 = vt.ds.filter((p) => !p.mf);
    const trong = (ngay) => ds0.filter((p) => vt.luc - p.luc <= ngay * 864e5);
    const top = (ds, f, n) => ds.filter((p) => f(p) != null).sort((a, b) => f(b) - f(a)).slice(0, n);
    const huy = ['🥇', '🥈', '🥉'];
    const khoi = (ds, f, n, rong, them, cong) => { const t = top(ds, f, n); return t.length ? t.map((p, i) => `${n > 1 ? huy[i] : '•'} **${cong || ''}${fmtSo(f(p))}** · ${L(p)}${them ? them(p) : ''}`) : [rong]; };
    const out = [dau, '', '**👁 LƯỢT XEM — top 3**', '*7 ngày*'];
    out.push(...khoi(trong(7), (p) => p.xem, 3, chua('xem')), '*28 ngày*', ...khoi(trong(28), (p) => p.xem, 3, chua('xem')));
    { const c = trong(7).filter((p) => p.x24 != null).sort((x, y) => x.x24 - y.x24);
      out.push(c.length ? `24h đầu sau khi đăng (video 7 ngày): thấp nhất **${fmtSo(c[0].x24)}** · ${L(c[0])} — cao nhất **${fmtSo(c[c.length - 1].x24)}** · ${L(c[c.length - 1])}` : '24h đầu sau khi đăng: chưa đọc được (chưa có video nào được ghi số lúc tròn 24h — Máy Cao cần mở Chrome lúc video tròn 24h)'); }
    out.push('', '**👥 FOLLOW — video mang lại nhiều lượt theo dõi nhất**');
    out.push('*7 ngày*', ...khoi(trong(7), (p) => p.theoDoi, 1, chua('theoDoi'), null, '+'), '*28 ngày*', ...khoi(trong(28), (p) => p.theoDoi, 1, chua('theoDoi'), null, '+'));
    out.push('', '**❤️ TƯƠNG TÁC — top 3** (thích + bình luận + chia sẻ)');
    const ct = (p) => ` (${fmtSo(p.thich)} thích · ${fmtSo(p.binhLuan)} bình luận · ${fmtSo(p.chiaSe)} chia sẻ)`;
    out.push('*7 ngày*', ...khoi(trong(7), (p) => p.tuongTac, 3, 'chưa có số', ct), '*28 ngày*', ...khoi(trong(28), (p) => p.tuongTac, 3, 'chưa có số', ct));
    return out;
  }

