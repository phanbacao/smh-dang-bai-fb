
  // =====================================================================
  //  KHỞI ĐỘNG
  // =====================================================================
  try { GM_registerMenuCommand('🔑 Cài mã khoá Facebook', () => { caiMaKhoa(); }); } catch (e) { /* */ }
  setInterval(() => { // chống treo: 1 lượt làm việc kẹt quá 20 phút → tải lại trang
    try {
      if (!dangChay || !nhipBatDau || Date.now() - nhipBatDau < 20 * 60000) return;
      if (Date.now() - baoTreo > 10 * 60000) { baoTreo = Date.now(); ghi('Lỗi: một lượt làm việc bị treo hơn 20 phút' + (lay('dang_do', null) ? ' (đang dở: ' + tenDangDo(lay('dang_do', null)).replace(/^Đang /, '') + ')' : '') + ' → tải lại trang để làm tiếp'); }
      if (document.visibilityState === 'visible' && !nhanSuDangDung() && !demNguoc) roiTrang();
    } catch (e) { /* */ }
  }, 30000);
  let demGiay = 0;
  setInterval(() => { // 1 giây: đếm ngược + thanh hoạt động + giữ quyền làm việc
    demGiay++;
    try { if (demGiay % 5 === 0 || document.visibilityState !== 'visible') giuKhoa(); } catch (e) { /* */ }
    if (document.visibilityState !== 'visible') return;
    try { capNhatDongHo(); if (demGiay % 5 === 0) veBang(); } catch (e) { /* */ }
  }, 1000);
  setInterval(() => { try { ganVe(); } catch (e) { /* */ } }, 1000);
  // (6.10) hộp nhắc của Facebook ("Lúc khác", "Để sau"…) hiện ra giữa lúc script đang soạn/đăng → tự bấm bỏ qua, không để treo
  const CHU_BO_QUA_FB = ['Lúc khác', 'Để sau', 'Không phải bây giờ', 'Không phải lúc này', 'Không, cảm ơn', 'Không cảm ơn', 'Để lúc khác', 'Đăng bài viết gốc', 'Đăng bài gốc', 'Tiếp tục đăng bài viết gốc']; // (6.11) "Bạn đang tổ chức sự kiện?" → chọn Đăng bài viết gốc (KHÔNG bấm Tiếp tục)
  let lucBoQuaFB = 0;
  setInterval(() => {
    try {
      if (!(dangBan || lay('dang_do', null))) return;
      if (Date.now() - lucBoQuaFB < 2500) return;
      const n = [...document.querySelectorAll('[role="button"],button')].find((b) => !b.closest('#smhfb,#smhfb-nho,#smhfb-soan-w,#smhfb-gan-w,#smhfb-gan-modal') && CHU_BO_QUA_FB.includes(chuan(b.innerText || b.getAttribute('aria-label') || '')) && b.getClientRects().length && getComputedStyle(b).visibility !== 'hidden' && !b.closest('[aria-hidden="true"]'));
      if (!n) return;
      lucBoQuaFB = Date.now();
      const lop = n.closest('[role="dialog"],[role="alertdialog"],[aria-modal="true"]');
      ghi(`Facebook hiện hộp nhắc «${chuan(lop ? lop.innerText : '').slice(0, 90)}» → tự bấm "${chuan(n.innerText || n.getAttribute('aria-label'))}" để đăng tiếp`);
      try { ganBam(n); } catch (e) { n.click(); }
    } catch (e) { /* */ }
  }, 1000);
  // (6.15) BỘ CANH TREO: đang soạn/đăng (hộp soạn đang mở, chưa bấm Đăng) mà TREO_PHUT phút không có bước mới → dừng bước kẹt (script tự đóng hộp + tải lại + thử lại)
  setInterval(() => {
    try {
      if (!dangBan) { window.__smhTreoLuc = 0; window.__smhHuyLuot = 0; return; }
      if (lay('dang_do', null) || lay('cho_tay6', null) || demNguoc || !(hopSoanBai() || ganManHinh())) { window.__smhTreoLuc = 0; return; }
      const cuoi = Math.max(window.__smhGhiLuc || 0, (hdChay && hdChay.cap) || 0);
      const treo = Date.now() - cuoi;
      if (treo < CAI_DAT.TREO_PHUT * 60000) { window.__smhTreoLuc = 0; return; }
      const giuLai = () => { window.__smhGhiLuc = cuoi; if (hdChay) hdChay.cap = cuoi; }; // lời ghi của bộ canh treo không tính là "có bước mới"
      if (!window.__smhTreoLuc) {
        window.__smhTreoLuc = Date.now();
        ghi(`Bộ canh treo: ${Math.round(treo / 60000)} phút không có bước mới (bước cuối: «${String(window.__smhGhiCuoi || '').slice(0, 90)}») → dừng bước đang kẹt, đóng hộp, tải lại trang rồi thử lại`);
        try { chupLoi('kẹt'); tuChupHienTruong('Bộ canh treo: kẹt ' + Math.round(treo / 60000) + ' phút ở bước «' + String(window.__smhGhiCuoi || '').slice(0, 90) + '»'); } catch (e) { /* */ }
        window.__smhHuyLuot = `kẹt ${Math.round(treo / 60000)} phút không có bước mới`; giuLai(); return;
      }
      if (Date.now() - window.__smhTreoLuc < 90000) return;
      // bước kẹt không nằm trong vòng chờ nào (script không tự dừng được) → ghi 1 lần thử rồi tải lại thẳng
      window.__smhTreoLuc = Date.now() + 10 * 60000;
      let ten = '';
      capNhatTT((s) => { for (const it of LICH) { const x = s.s[it.k]; if (x && x.tt === 'dang') { ten = it.ten; x.lan = (x.lan || 0) + 1; x.vong = x.vong || 1; x.loi = 'kẹt khi soạn/đăng'; x.tt = 'cho'; x.thuLai = Date.now() + 60000; if (x.lan >= CAI_DAT.SO_LAN_THU) { if (x.vong < CAI_DAT.SO_VONG_THU) { x.vong++; x.lan = 0; x.thuLai = Date.now() + CAI_DAT.NGHI_GIUA_VONG_PHUT * 60000; } else x.tt = 'loi'; } } } });
      ghi(`Bộ canh treo: ${ten || 'việc đang làm'} vẫn kẹt → tải lại trang ngay (tính 1 lần thử)`);
      roiTrang();
    } catch (e) { /* */ }
  }, 15000);
  // (6.15) Facebook báo lỗi / trắng trang liên tục 30 giây → tải lại; 3 lần trong 30 phút → nghỉ 10 phút rồi tải lại (có báo nhóm)
  { let thayLoi = 0;
    setInterval(() => {
      try {
        if (!MAY || !laTabChinh() || dangBan || document.visibilityState !== 'visible' || !/(^|\.)facebook\.com$/.test(location.hostname) || performance.now() < 40000) return;
        if (lay('nghi_loi6', 0) > Date.now()) return;
        let tx = ''; for (const c of Array.from(document.body ? document.body.children : [])) { if (/^smhfb/.test(c.id || '') || c.tagName === 'SCRIPT' || c.tagName === 'STYLE') continue; tx += (c.innerText || '') + '\n'; if (tx.length > 4000) break; }
        const main = document.querySelector('[role="main"]');
        const coLoi = /Đã xảy ra lỗi|Có lỗi xảy ra|Rất tiếc, đã xảy ra sự cố|Something went wrong|Bạn đang ngoại tuyến|Không có kết nối Internet|You're offline|Trang này hiện không hiển thị|This page isn't available/i.test(tx.slice(0, 4000)) && (!main || String(main.innerText || '').length < 400);
        const trang = tx.trim().length < 30;
        if (!coLoi && !trang) { thayLoi = 0; return; }
        if (++thayLoi < 3) return;
        thayLoi = 0;
        const n0 = lay('loi_trang6', null); const n = (n0 && Date.now() - n0.luc < 30 * 60000 ? n0.n : 0) + 1;
        luu('loi_trang6', { n: n >= 3 ? 0 : n, luc: Date.now() });
        if (n >= 3) {
          luu('nghi_loi6', Date.now() + 10 * 60000);
          ghi(`Facebook báo lỗi / trắng trang ${n} lần liền → nghỉ 10 phút rồi tải lại`);
          baoLoi(`⚠️ Trang Facebook trên ${TEN_MAY} báo lỗi / trắng trang ${n} lần liền (${coLoi ? 'có chữ báo lỗi' : 'trang trắng'}) → script nghỉ 10 phút rồi tải lại. Nếu vẫn vậy cần kiểm tra mạng hoặc đăng nhập Facebook.`, 'loitrang');
          setTimeout(() => { if (!dangBan) roiTrang(CAI_DAT.URL_TRANG); }, 10 * 60000);
          return;
        }
        ghi(`Trang Facebook đang ${coLoi ? 'báo lỗi' : 'trắng'} (lần ${n}) → chờ 30 giây đã qua, tải lại trang`);
        if (!demNguoc) batDemNguoc(`tải lại trang (Facebook đang ${coLoi ? 'báo lỗi' : 'trắng'})`).then((kq) => { if (kq === 'ok') roiTrang(); else ghi('Bạn bấm Hoãn → chưa tải lại trang'); });
      } catch (e) { /* */ }
    }, 10000);
  }
  // (6.15) TỰ KIỂM TRA BUỔI SÁNG (từ 6h, trước Bài 1; máy mở muộn thì kiểm lúc mở): mã khoá Facebook, đọc Lark, đúng trang, có ô soạn bài → hỏng gì báo ngay
  { let dangKiem = false;
    setInterval(async () => {
      try {
        if (dangKiem || dangChay || !MAY || !laTabChinh() || dangBan || lay('dang_do', null)) return;
        const mm = phutTrongNgay(new Date()); if (mm < 360 || mm > docGio(CAI_DAT.GIO_CHOT)) return;
        const sk0 = lay('sk6', null); if (sk0 && sk0.ngay === homNay() && sk0.xong) return;
        if (document.visibilityState !== 'visible' || performance.now() < 30000) return;
        dangKiem = true; const loi = []; let boQuaLuot = false;
        await theoDoi('suckhoe', async () => {
        if (!coApi()) loi.push('chưa cài mã khoá Facebook (script không hỏi được bài đã lên chưa)');
        else { try { await baiTrenTrangApi(Date.now() - 3600e3); } catch (e) { loi.push('mã khoá Facebook không dùng được (' + String(e.message).slice(0, 60) + ') — cần đổi mã mới'); } }
        const d = duLieu();
        if (!d || !d.ngay || !d.ngay[homNay()]) { try { await docDuLieu('suckhoe'); } catch (e) { loi.push('không đọc được Lark sheet (' + String(e.message).slice(0, 60) + ')'); } }
        if (dungTrang() && !hopSoanBai() && !ganManHinh()) {
          if (!timNutSoanBai() && !Array.from(document.querySelectorAll('[role="button"]')).some((b) => chuan(b.innerText) === 'Ảnh/video')) {
            if (!window.__skThieuO || Date.now() - window.__skThieuO < 180000) { window.__skThieuO = window.__skThieuO || Date.now(); boQuaLuot = true; return; } // trang có thể đang tải / đang lỗi: 3 phút sau vẫn không thấy mới báo
            loi.push('trên trang không thấy ô "Bạn đang nghĩ gì?" (có thể bị đăng xuất hoặc Facebook đổi giao diện)');
          } else window.__skThieuO = 0;
        }
        if (!coBiMat()) loi.push('máy này chưa có mã bí mật (mã Lark) — script chưa đọc/ghi được Lark sheet');
        });
        if (boQuaLuot) return;
        luu('sk6', { ngay: homNay(), luc: Date.now(), xong: true, loi });
        if (loi.length) { ghi('Tự kiểm tra sáng: ' + loi.join(' · ')); thongBaoMay('Tự kiểm tra sáng phát hiện lỗi', loi.join(' · ')); await baoLoi(`🩺 Tự kiểm tra sáng ${TEN_MAY}: ${loi.join(' · ')} — cần xử lý trước giờ đăng`, 'suckhoe'); }
        else ghi('Tự kiểm tra sáng: mã khoá Facebook, Lark sheet, trang và ô soạn bài đều ổn');
        veBang();
      } catch (e) { /* */ } finally { dangKiem = false; }
    }, 60000);
  }
  // (6.10) ghi mọi lỗi ngầm của script vào nhật ký để dễ kiểm tra
  { const daGhi = {};
    const ghiLoiNgam = (msg) => { try { const k = String(msg).slice(0, 120); if (daGhi[k] && Date.now() - daGhi[k] < 10 * 60000) return; daGhi[k] = Date.now(); ghi('Lỗi ngầm trong script: ' + k); } catch (e) { /* */ } };
    window.addEventListener('error', (e) => { if (e && e.filename && !/userscript|tampermonkey|smh/i.test(e.filename + (e.error && e.error.stack || ''))) return; ghiLoiNgam((e && e.message) || 'lỗi'); });
    window.addEventListener('unhandledrejection', (e) => { const r = e && e.reason; const st = (r && r.stack) || ''; if (st && !/userscript|tampermonkey|smh/i.test(st)) return; ghiLoiNgam((r && r.message) || String(r)); });
  }
  // (6.21) đổi trang kênh 1 (cũ ↔ mới): đặt lại lịch kênh 1 hôm nay + ngày mai để đăng theo trang/tab mới (kênh 2, 3 giữ nguyên)
  if (MAY) { try { const k1 = CAI_DAT.KENH[1].moi ? 'moi' : 'cu'; const cu = lay('k1_trang6', ''); if (cu !== k1 && (cu || k1 === 'moi')) {
    for (const ng of [homNay(), ngayMai()]) { const s = lay('ngay6_' + ng, null); if (s && s.s) { for (const k of Object.keys(s.s)) if (!/^k[2-4]/.test(k)) delete s.s[k]; s.gan = Object.fromEntries(Object.entries(s.gan || {}).filter(([k]) => /^k[2-4]/.test(k))); delete s.baoCao; delete s.baoCaoThu; luu('ngay6_' + ng, s); } }
    luu('du_lieu6', null); luu('dang_do', null); luu('cho_tay6', null); luu('ghigom6', []); luu('ghij_cho6', []); luu('kenh_ma6', null); luu('trang6', null);
    ghi(k1 === 'moi' ? 'Đổi sang KÊNH 1 MỚI (trang ' + CAI_DAT.KENH[1].url + ', tab ' + CAI_DAT.TAB_VIDEO + ', video cột M) — kênh 1 cũ tạm dừng; lịch kênh 1 hôm nay đặt lại để đăng theo sheet' : 'Bật lại KÊNH 1 CŨ — lịch kênh 1 hôm nay đặt lại');
  } luu('k1_trang6', k1); } catch (e) { ghi('Đổi trang kênh 1 lỗi: ' + e.message); } }
  // (6.24.2) video/manifest đã dừng gắn thẻ vì lỗi "không thấy màn Cài đặt" (thước phim) → cho thử lại 1 lần với bản mới
  if (MAY) { try { const sv = trangThai(); const ds = Object.entries(sv.s || {}).filter(([, r]) => r && !r.suaXong && /Cài đặt bài viết|không thấy màn Cài đặt|chưa thấy bài trên trang/.test(r.suaLoi || '') && !r.sua6242); if (ds.length) { capNhatTT((s1) => { for (const [k] of ds) Object.assign(ttSlot(s1, k), { suaLan: 0, suaHen: 0, suaLoi: '', sua6242: 1 }); }); ghi(`Bản 6.24.2: cho thử lại gắn thẻ + cảm xúc ${ds.length} bài trước đó lỗi (${ds.map(([k]) => k.toUpperCase()).join(', ')})`); } } catch (e) { /* */ } }
  setInterval(nhip, 15000);
  setTimeout(nhip, 4000);
  try { dongBoLich(); } catch (e) { /* */ } // (6.19) lịch hôm nay gồm cả video kênh 2, 3 (theo sheet đã đọc)
  if (MAY) trangThai(homNay()); // tạo sẵn giờ đăng hôm nay để hiện trên popup
  if (MAY) { // (6.9) bài bị bỏ vì 2 lỗi đã sửa (kiểm tên hộp soạn / nút hình thu nhỏ bị cuộn khuất) → đưa lại hàng chờ
    const dua = [];
    capNhatTT((s) => { for (const it of LICH) { const r = s.s[it.k]; if (r && ((['loi', 'cho'].includes(r.tt) && /không đứng tên|Chỉnh sửa hình thu nhỏ/.test(r.loi || '')) || (r.tt === 'loi' && lay('datlai_' + PHIEN_BAN, '') !== homNay()))) { Object.assign(r, { tt: 'cho', lan: 0, loi: '', thuLai: 0, lyDo: '' }); dua.push(it.ten); } } });
    luu('datlai_' + PHIEN_BAN, homNay());
    if (dua.length) ghi(`Bản ${PHIEN_BAN}: đưa lại hàng chờ các bài đang lỗi hôm nay để thử lại theo cách mới: ${dua.join(', ')}`);
  }
  veBang();
  { let kieu = ''; try { const nv = performance.getEntriesByType('navigation')[0]; kieu = nv ? ({ reload: 'tải lại', navigate: 'mở trang', back_forward: 'quay lại' }[nv.type] || nv.type) : ''; } catch (e) { /* */ }
    ghi(`Khởi động bản ${PHIEN_BAN} (${TEN_MAY}) · ${location.pathname.slice(0, 40)}${kieu ? ' · ' + kieu : ''}`); }
})();
