
  // =====================================================================
  //  NHIỀU TAB FACEBOOK: chỉ 1 tab làm việc
  // =====================================================================
  const cuHon = (a, b) => { const x = String(a).split('.').map(Number), y = String(b).split('.').map(Number);
    for (let i = 0; i < Math.max(x.length, y.length); i++) { if ((x[i] || 0) !== (y[i] || 0)) return (x[i] || 0) < (y[i] || 0); } return false; };
  let dangChay = false, nhipBatDau = 0, baoTreo = 0, dungMoc = lay('dung_moc', 0), choNhanKhoa = false;
  function giuKhoa() {
    const k = GM_getValue('khoa_dang_bai_that', null);
    const now = Date.now();
    const hienThi = document.visibilityState === 'visible';
    const cu = !k || now - k.ts > 150000;
    const cuaMinh = k && k.id === MA_TAB;
    const gianhDuoc = k && !k.ghim && !k.ban && !k.hien && hienThi && now - (k.anTu || k.ts) > 90000;
    const banCu = k && !k.ghim && !k.ban && cuHon(k.v || '0', PHIEN_BAN) && (hienThi || !k.hien);
    const daNha = k && k.nha && now - k.nha < 120000 && (hienThi || !k.hien); // (6.20.9) tab giữ quyền vừa rời trang (tải lại / chuyển tư cách) → nhận ngay, không chờ 2,5 phút
    if (cu || cuaMinh || gianhDuoc || banCu || daNha) {
      if (banCu && !cuaMinh) ghi('Tab khác đang chạy bản cũ ' + (k.v || '') + ' → tab này (bản ' + PHIEN_BAN + ') nhận làm việc');
      if (!cuaMinh) luuNK('Nhận quyền làm việc từ tab ' + ((k && k.id) || '(chưa có)'), false);
      const anTu = hienThi ? 0 : ((cuaMinh && k.anTu && !k.hien) ? k.anTu : now);
      GM_setValue('khoa_dang_bai_that', { nha: 0, id: MA_TAB, ts: now, hien: hienThi, anTu, ban: dangBan || dangChay, v: PHIEN_BAN, ghim: !!(cuaMinh && k.ghim) });
      return true;
    }
    return false;
  }
  // (6.20.9) rời trang (Facebook tải lại khi chuyển tư cách, F5, chuyển trang) → đánh dấu "nhả quyền" để trang mới nhận ngay
  window.addEventListener('pagehide', () => { try { const k = GM_getValue('khoa_dang_bai_that', null); if (k && k.id === MA_TAB) GM_setValue('khoa_dang_bai_that', Object.assign({}, k, { nha: Date.now() })); } catch (e) { /* */ } });
  const laTabChinh = () => { const k = GM_getValue('khoa_dang_bai_that', {}) || {}; return k.id === MA_TAB && Date.now() - k.ts <= 150000; };
  function kiemDung() {
    if (!laTabChinh()) throw new LoiTamHoan('Tạm mất quyền làm việc — lượt này hoãn, lát nữa làm tiếp');
    if (tamDung() || lay('dung_moc', 0) > dungMoc) throw new LoiDung('Đã nhận yêu cầu Tạm dừng');
    if (document.visibilityState !== 'visible') throw new LoiTamHoan('Tab bị ẩn trong lúc thao tác — chờ tab hiện lại sẽ làm tiếp');
  }
  async function nhanQuyen() {
    if (dangChay || choNhanKhoa) return false;
    choNhanKhoa = true;
    try {
      if (!giuKhoa()) return false;
      await sleepThat(180 + Math.floor(Math.random() * 120));
      if (!laTabChinh()) return false;
      dangChay = true; nhipBatDau = Date.now(); giuKhoa();
      dungMoc = lay('dung_moc', 0);
      return true;
    } finally { choNhanKhoa = false; }
  }

  // =====================================================================
  //  Nhận biết trang Facebook (khung bài, video, màn sửa)
  // =====================================================================
  const cheDoThu = false; // (bản cũ có "quét thử"; 6.0 không còn)
  const dangODuongSua = () => /\/post\/edit/.test(location.pathname);
  // Mỗi bài trên trang có đúng 1 nút ⋯ "Hành động đối với bài viết này" → leo lên đến khung chỉ chứa 1 bài
  function cacKhungBai() {
    const out = [];
    for (const b of document.querySelectorAll('[aria-label^="Hành động đối với bài viết này"][role="button"]')) {
      let p = b, best = null;
      for (let i = 0; i < 30 && p; i++) {
        p = p.parentElement; if (!p) break;
        if (p.querySelectorAll('[aria-label^="Hành động đối với bài viết này"][role="button"]').length > 1) break;
        best = p;
      }
      if (best) out.push({ khung: best, menu: b });
    }
    return out;
  }
  // link bài: /reel/ /videos/ = video; /posts/ /photos/ = không phải; còn lại = chưa biết (null)
  const laVideoApi = (p) => { const l = String(p.link || ''); if (/\/(reel|reels|videos|watch)\b/i.test(l)) return true; if (/\/(posts|photos?|permalink)\b|story_fbid/i.test(l)) return false; return null; };
  const hopSua = () => hopThoai((d) => /^Chỉnh sửa/.test(chuan(d.innerText)) && nutTheoChu(d, 'Lưu'));
  // hộp soạn bài / màn chỉnh sửa đang mở mà KHÔNG phải script mở → có thể nhân viên đang thao tác tay: chờ; để nguyên ≥ 10 phút → coi là bỏ quên
  function nguoiDangThaoTac() {
    const sua = dangODuongSua();
    const el = sua ? hopSua() : (hopSoanBai() || hopDangDo() || (typeof hopSuaMoi === 'function' ? hopSuaMoi() : null)); // (6.24) cả hộp "Chỉnh sửa bài viết" kiểu mới do người mở
    if (!sua && !el) { window.__smhNguoi = null; return false; }
    if (!sua && window.__smhMoHop) return false; // script tự mở → script tự đóng được
    const chu = location.pathname + '|' + (el ? chuan(el.innerText).slice(0, 500) : '');
    const w = window.__smhNguoi; const bg = Date.now();
    if (!w) { window.__smhNguoi = { luc: bg, chu }; ghi((sua ? 'Đang có màn chỉnh sửa bài' : 'Đang có hộp soạn bài') + ' do người mở (không phải script) — có thể nhân viên đang thao tác → script chờ, không đóng ngang'); return true; }
    if (w.chu !== chu) { w.chu = chu; w.luc = bg; w.boQuen = false; return true; }
    if (w.boQuen) return false;
    if (bg - w.luc >= 10 * 60000) { w.boQuen = true; ghi((sua ? 'Màn chỉnh sửa bài' : 'Hộp soạn bài') + ' để nguyên hơn 10 phút không thay đổi → coi như bỏ quên, script đóng lại để làm tiếp'); return false; }
    return true;
  }
  async function dongManHinhSua() {
    if (typeof hopSuaMoi === 'function' && (hopSuaMoi() || hopCaiDatMoi())) await dongHopMoi(); // (6.24) hộp "Chỉnh sửa bài viết" kiểu mới
    for (let lan = 0; lan < 3 && dangODuongSua(); lan++) {
      dongBangCamXuc();
      const x = Array.from(document.querySelectorAll('[aria-label="Đóng"]')).filter(dangHien).sort((a, b) => a.getBoundingClientRect().x - b.getBoundingClientRect().x)[0];
      if (x && lan < 2) { if (lan) { try { ganBam(x); } catch (e) { x.click(); } } else x.click(); }
      else history.back();
      const hoi = await cho(() => hopThoai((d) => d.innerText.startsWith('Rời khỏi trang')), 3000);
      if (hoi) { const bo = nutTheoChu(hoi, 'Rời khỏi'); if (bo) { if (lan) { try { ganBam(bo); } catch (e) { bo.click(); } } else bo.click(); } }
      await cho(() => !dangODuongSua(), 8000);
    }
    return !dangODuongSua();
  }
  function dongBangCamXuc() {
    const lb = document.querySelector('ul[role="listbox"]'); if (!lb) return;
    const hop = lb.closest('[role="dialog"]');
    const nut = hop && Array.from(hop.querySelectorAll('[aria-label="Quay lại"], [aria-label="Đóng"]')).find(dangHien);
    if (nut) nut.click(); else document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', code: 'Escape', keyCode: 27, which: 27, bubbles: true }));
  }

  // =====================================================================
  //  Nhân sự đang dùng trang?
  // =====================================================================
  let nguoiLuc = 0, nguoiPhim = 0;
  const trongPopup = (t) => !!(t && t.closest && t.closest('#smhfb,#smhfb-nho,#smhfb-soan-w,#smhfb-gan-w,#smhfb-gan-modal'));
  for (const ten of ['keydown', 'mousedown', 'wheel', 'touchstart']) {
    document.addEventListener(ten, (e) => { if (!e.isTrusted || trongPopup(e.target)) return; nguoiLuc = Date.now(); if (ten === 'keydown') nguoiPhim = nguoiLuc; }, { capture: true, passive: true });
  }
  function oDangGoDo() {
    const a = document.activeElement; if (!a || trongPopup(a) || Date.now() - nguoiPhim > 15 * 60000) return false;
    if (!(a.isContentEditable || a.tagName === 'TEXTAREA' || (a.tagName === 'INPUT' && /^(text|search|)$/.test(a.type || '')))) return false;
    return !!chuan(a.isContentEditable ? a.innerText : a.value);
  }
  function nhanSuDangDung() {
    // (6.24) không tính bấm chuột / cuộn trang nữa — chỉ chờ khi đang gõ dở hoặc có hộp soạn/sửa do người mở
    if (oDangGoDo()) return 'bạn đang gõ dở bài viết/bình luận';
    if (nguoiDangThaoTac()) return 'đang có hộp soạn bài do người mở';
    return '';
  }

  // =====================================================================
  //  Thanh "đang làm gì" (dưới thanh trên cùng của popup)
  // =====================================================================
  const HD_TEN = {
    chiso: 'Đang xem chỉ số tuần fb kênh 1', dangdo: 'Đang làm tiếp việc dở', dang: 'Đang đăng bài', chotay: 'Chạy thử: chờ bấm Đăng', khanh: 'Đang đọc trang ' + CAI_DAT.KHANH_TEN,
    docsheet: 'Đang đọc Lark sheet', dotrang: 'Đang kiểm tra bài trên trang', kiemcmt: 'Đang kiểm tra comment', taisan: 'Đang tải sẵn đồ đăng',
    baocao: 'Đang gửi báo cáo ngày', suavideo: 'Đang kiểm tra / gắn thẻ + cảm xúc video', danmf: 'Đang dán ảnh manifest vào sheet', yeucau: 'Đang làm việc bạn vừa bấm trên popup', taoanh: 'Đang tạo ảnh manifest', nhac: 'Đang lấy nhạc nền',
    suckhoe: 'Đang tự kiểm tra buổi sáng (mã khoá Facebook, Lark sheet, trang)', baocaoloi: 'Đang ghi báo cáo lỗi lên Lark sheet', duyet: 'Đang ghi duyệt bản mới', baoclaude: 'Đang gửi lỗi cho Claude', chuanbi: 'Đang kiểm tra chuẩn bị cho bài sắp đăng', doichieu: 'Đang đối chiếu bài vừa đăng với sheet', nhacsheet: 'Đang nhắc nhóm bổ sung sheet ngày mai', thunap: 'Đang thử nạp bản qua Lark (cách 2)', makenh: 'Đang lấy mã đọc trang kênh 2, 3',
  };
  const tenDangDo = (dd) => (dd ? (dd.buoc === 'kiem_bai' ? `Đang chờ Facebook xác nhận ${dd.ten || 'bài vừa đăng'}` : dd.raSoat ? `Đang gửi bù comment ${dd.ten || ''}` : `Đang comment ${dd.ten || ''}`) : HD_TEN.dangdo);
  let hdChay = null; // việc tab này đang chạy
  let bamNutLuc = 0; // lúc người dùng bấm nút gần nhất → việc bắt đầu ngay sau đó hiện thanh hoạt động NGAY (không chờ 0,7 giây)
  // ước lượng thời gian 1 việc (mili giây): học từ 5 lần gần nhất của chính việc đó (theo tên), chưa có thì dùng mức mặc định theo loại
  const UOC_MAC_DINH = { thunap: 60000, chuanbi: 15000, doichieu: 4000, nhacsheet: 15000, suckhoe: 8000, baocaoloi: 5000, duyet: 4000, docsheet: 15000, dotrang: 6000, taisan: 60000, suavideo: 60000, yeucau: 25000, dang: 90000, dangdo: 60000, kiemcmt: 30000, khanh: 120000, chotay: 60000, taoanh: 20000, danmf: 15000, nhac: 10000, baocao: 8000, nhac_dang: 10000, dang_do: 60000 };
  const UOC_THEO_TEN = [[/đọc lại lark sheet|đọc sheet/i, 15000], [/kiểm comment 3 bài/i, 45000], [/kiểm comment video 24/i, 60000], [/kiểm comment/i, 25000], [/kiểm tra bài trên trang/i, 20000], [/tải sẵn/i, 90000], [/gửi tin thử/i, 5000], [/manifest/i, 240000], [/video/i, 150000], [/bài 1|bài 2|bài 3|twist/i, 60000]];
  function uocLuong(key, ten) {
    const hoc = (lay('tg_hoc6', {}) || {})[String(ten || key).replace(/\s+\(.*$/, '')];
    if (hoc && hoc.length) { const a = hoc.slice().sort((x, y) => x - y); return a[Math.floor(a.length / 2)]; }
    if (['yeucau', 'dang', 'dangdo', 'dang_do', 'kiemcmt', 'chotay'].includes(key)) for (const [re, ms] of UOC_THEO_TEN) if (re.test(ten || '')) return ms;
    return UOC_MAC_DINH[key] || 30000;
  }
  // (6.16) dự kiến thời gian cho việc SẮP làm (dòng đếm ngược / chờ nhân sự) — để nhân sự biết nên Hoãn hay để script làm
  function uocDem(ten) {
    const t = String(ten || '').replace(/\s*\(hẹn [^)]*\)/, '').trim(); let m;
    if ((m = t.match(/^đăng (.+)$/i))) return uocLuong('dang', 'Đang đăng ' + m[1]);
    if ((m = t.match(/^comment tiếp cho (.+)$/i))) return uocLuong('dangdo', 'Đang comment ' + m[1]);
    if (/gửi bù comment/i.test(t)) return 90000;
    if ((m = t.match(/cảm xúc cho (.+)$/i))) return uocLuong('suavideo', 'Đang kiểm tra / gắn thẻ + cảm xúc cho ' + m[1]);
    if (/Khanh|báo cáo tuần/i.test(t)) return uocLuong('khanh', HD_TEN.khanh);
    if (/tải lại trang/i.test(t)) return 15000;
    return 60000;
  }
  function hocThoiGian(ten, ms) {
    if (!ten || ms < 1500 || ms > 60 * 60000) return;
    const all = lay('tg_hoc6', {}) || {}; const k = String(ten).replace(/\s+\(.*$/, '');
    all[k] = ((all[k] || []).concat([ms])).slice(-5); luu('tg_hoc6', all);
  }
  // (6.24) ngưỡng thời gian từng việc (giây): vượt ngưỡng → ghi "⚠️ Bước quá lâu" (vào Báo lỗi) + lưu để xem ở tab Hệ thống
  const NGUONG_GIAY = { dang: 180, dangdo: 120, suavideo: 60, suanen: 60, dotrang: 60, docsheet: 60, kiemcmt: 120, chuanbi: 120 };
  function ghiCham(ten, giay, nguong) {
    ghi(`⚠️ Bước quá lâu: ${ten} mất ${giay} giây (ngưỡng ${nguong} giây)`);
    const c = lay('cham6', null); const ds = c && c.ngay === homNay() ? c.ds : [];
    ds.push({ luc: Date.now(), ten, giay, nguong }); luu('cham6', { ngay: homNay(), ds: ds.slice(-30) });
  }
  function baoThoiGian(key, rec) {
    if (!rec.hien || !(rec.soDong || 0)) return; // việc không làm gì (chỉ kiểm rồi thôi) thì không ghi
    const giay = Math.round((Date.now() - rec.bd) / 1000);
    const ten = String(rec.ten || key).replace(/^Đang /, '');
    if (giay >= 2) ghi(`⏱ ${ten}: xong sau ${giay} giây`);
    const n = NGUONG_GIAY[key]; if (n && giay > n) ghiCham(ten, giay, n);
  }
  async function theoDoi(key, fn, ten) {
    const hd0 = lay('hoat_dong', null);
    const tiep = !!(hd0 && hd0.key === key && Date.now() - (hd0.cap || 0) < 4 * 60000); // việc đang làm dở từ trước khi trang tải lại
    const rec = { key, ten: ten || HD_TEN[key] || 'Đang chạy', bd: tiep ? hd0.bd : Date.now(), chi: tiep ? hd0.chi : '', cuoi: '', soDong: 0, cap: Date.now(), hien: tiep };
    hdChay = rec;
    if (tiep) luu('hoat_dong', rec);
    const doBam = Date.now() - bamNutLuc < 3000 && ['yeucau', 'taoanh', 'danmf', 'nhac', 'khanh', 'suavideo'].includes(key); // người dùng vừa bấm → hiện ngay
    const hen = setTimeout(() => { if (hdChay === rec && !rec.hien) { rec.hien = true; luu('hoat_dong', rec); veBang(); } }, 250); // (6.16) việc nào chạy quá 0,25 giây hoặc vừa ghi 1 bước là hiện ngay (lượt kiểm "không có gì làm" thì không nháy)
    if (doBam) { rec.hien = true; luu('hoat_dong', rec); try { nhacNho(rec.ten + '…', 'cho'); } catch (e) { /* */ } }
    let kq; const buocCu = window.__smhBuoc; window.__smhBuoc = { key, cuoi: Date.now() };
    try { kq = await fn(); return kq; } finally {
      clearTimeout(hen);
      window.__smhBuoc = buocCu || null;
      try { baoThoiGian(key, rec); } catch (e) { /* */ }
      if (hdChay === rec) hdChay = null;
      try { if (rec.hien) demViec(key, Date.now() - rec.bd, rec.coKQ); } catch (e) { /* */ }
      const conDo = kq === true && ((key === 'dangdo' && lay('dang_do', null)) || (key === 'khanh' && lay('khanh_dang', null)));
      if (!conDo && rec.hien && !/Lỗi|lỗi|chưa được|không được|thất bại/.test(rec.cuoi || '')) hocThoiGian(rec.ten, Date.now() - rec.bd);
      if (conDo) { if (rec.hien) luu('hoat_dong', Object.assign(rec, { cap: Date.now() })); }
      else {
        const h = lay('hoat_dong', null); if (h && h.bd === rec.bd) luu('hoat_dong', null);
        // thanh "Xong: … lúc …" cho các việc người dùng bấm hoặc việc lớn (đăng, comment)
        const ketCu = lay('hd_ket', null); const ketLon = ketCu && !ketCu.ngan && !ketCu.dong && Date.now() - ketCu.luc < 3 * 60000;
        if (rec.hien && (rec.soDong || Date.now() - rec.bd > 1000) && !ketLon && !['yeucau', 'nhac', 'dangdo', 'dang', 'kiemcmt', 'khanh', 'chotay'].includes(key)) luu('hd_ket', { key, ten: rec.ten, chu: rec.cuoi, luc: Date.now(), tg: Date.now() - rec.bd, mau: 'ok', ngan: true }); // (6.16) việc nhanh: hiện "✓ Xong …" vài giây để kịp thấy
        if (rec.hien && (rec.soDong || rec.cuoi) && !(key === 'dang' && /^Sắp |chờ tối đa/.test(rec.cuoi || '')) && ['yeucau', 'nhac', 'dangdo', 'dang', 'kiemcmt', 'khanh', 'chotay'].includes(key)) luu('hd_ket', { key, ten: rec.ten, chu: rec.cuoi, luc: Date.now(), tg: Date.now() - rec.bd, mau: /Lỗi|lỗi|chưa được|không được|thất bại/.test(rec.cuoi || '') ? 'vang' : 'ok' });
        if (rec.hien) veBang();
      }
    }
  }
  // việc chạm vào trang mà KHÔNG gấp (Khanh): chỉ chạy khi nhân sự không dùng trang
  async function chayRanh(key, fn, ten) {
    const ly = nhanSuDangDung();
    if (ly) return false;
    return theoDoi(key, fn, ten);
  }

  // =====================================================================
  //  Dọn dữ liệu cũ (1 lần/ngày) — xoá cả các mục của bản 5.x không còn dùng
  // =====================================================================
  function donDuLieuCu6() {
    if (typeof GM_listValues !== 'function' || lay('don6', '') === homNay()) return;
    luu('don6', homNay());
    const giuNgay = new Set(Array.from({ length: 8 }, (_, i) => ngayStr(congNgay(-i))));
    const GIU = new Set(['the6_bd', 'csnhac6', 'csghichu6', 'tv24_6', 'lichghi6', 'khong_nhom6', 'v24_6', 'nhay6', 'bimat6', 'capnhat6', 'drive6', 'thunap6b', 'trang6_k2', 'trang6_k3', 'trang6_k4', 'nhacsheet6', 'cs6', 'ghij_cho6', 'ghigom6', 'k1_cu', 'k1_trang6', 'nhacsheet6_thu', 'lich_t6', 'fb_hong1', 'tc_mo_trang6', 'tc_trang6', 'tc_reload_luc', 'fb_token_nguoi_luc', 'fb_token', 'fb_token_luc', 'fb_token_nhac', 'gan_the', 'khanh', 'khanh_kq', 'khanh_thu', 'khanh_dang', 'may6', 'nhac6', 'nhac6_info', 'o_nhac6', 'tam_dung', 'tam_dung_luc', 'cham6', 'lo_batch6', 'trung6', 'dung_moc', 'tu_dong6', 'chay_thu6', 'lark_gate', 'lark_tok', 'suc_khoe', 'mf_vung6', 'lam_ngay6', 'mf_font6', 'mf_fonts6', 'tg_hoc6', 'cmt6', 'cmt6_dongbo', 'the6', 'the6_dongbo', 'ui_tab6', 'ui_co_chu6', 'du_lieu6', 'dang_do', 'cho_tay6', 'trang6', 'mo6', 'song6', 'hoan6', 'lark_dem', 'tai6', 'yc6', 'hang_bu6', 'hoat_dong', 'cho_nguoi', 'bai_cuoi6', 'mf_tien6', 'don6', 'ui_co_chu', 'hd_ket', 'lan_chuyen', 'tc_reload_luc', 'cho_tab_an', 'sk6', 'loi_trang6', 'nghi_loi6', 'fb_token_nguoi', 'fb_token_nguoi_luc', 'fb_tok_trang6', 'kenh_id6', 'kenh_ma6', 'lich_k6']);
    let xoa = 0;
    for (const k0 of GM_listValues()) {
      const k = String(k0); if (!k.startsWith('that_')) continue;
      const ten = k.slice(5);
      if (GIU.has(ten) || ten.startsWith('yc6_kq_') || ten.startsWith('datlai_')) continue;
      const m = ten.match(/^(ngay6|nk6|doc6|tin6|an6)_(\d{2}-\d{2}-\d{4})$/);
      if (m && giuNgay.has(m[2])) continue;
      GM_deleteValue(k0); xoa++;
    }
    if (xoa) ghi(`Dọn dữ liệu: đã xoá ${xoa} mục cũ (của bản cũ hoặc quá 7 ngày)`);
    khoDon().catch(() => {});
  }

  // =====================================================================
  //  NHỊP CHÍNH (15 giây/lần)
  // =====================================================================
  const trongGioDo = () => { const m = phutTrongNgay(new Date()); return m >= docGio(CAI_DAT.GIO_DO_TU) && m < docGio(CAI_DAT.GIO_DO_DEN); };
  async function nhip() {
    if (!MAY) { veBang(); return; } // chưa chọn máy → không làm gì
    if (!(await nhanQuyen())) { veBang(); return; }
    try {
      datKenh(1); try { dongBoLich(); } catch (e) { /* */ } // (6.19) lịch hôm nay gồm cả video kênh 2, 3
      luu('song6', Date.now());
      { const y0 = (lay('yc6', []) || []).find((y) => Date.now() - y.luc < 10 * 60000); if (y0) await theoDoi('yeucau', () => xuLyYeuCau(), 'Đang ' + (TEN_YC[y0.loai] || y0.loai).replace(/^./, (c) => c.toLowerCase())); }
      donDuLieuCu6();
      await baoTinhTrangLark();
      tuChayLaiTamDung();
      const dd = lay('dang_do', null);
      if (tamDung()) { // tạm dừng: chỉ chờ Facebook xác nhận video vừa bấm Đăng (không chạm vào trang)
        if (dd && dd.video && dd.buoc === 'kiem_bai') await theoDoi('dangdo', () => xuLyDangDo(), tenDangDo(dd));
        return;
      }
      if (!dangBan && !hopSoanBai() && !hopDangDo() && !ganManHinh()) window.__smhMoHop = 0;
      if (lay('cho_nguoi', null) && !nhanSuDangDung()) luu('cho_nguoi', null);
      // (6.26) ĐĂNG BÀI: TẮT = tắt hẳn: không đăng, không đăng thay, không comment / gửi bù, không gắn thẻ / cảm xúc, không tải tệp.
      //  Chỉ còn: đọc sheet, dò bài trên trang 10 phút/lần, báo cáo nhóm, báo thiếu bài trong sheet.
      const tatDang = !tuDong();
      if (tatDang && dd && !(dd.video && dd.buoc === 'kiem_bai')) { if (!window.__smhTatDd) { window.__smhTatDd = 1; ghi(`ĐĂNG BÀI đang TẮT → dừng việc dở của ${dd.ten || 'bài vừa đăng'} (bật lại thì làm tiếp)`); } }
      // 1) việc dở (đã bấm Đăng → xác nhận → comment)
      if (dd && !(tatDang && !(dd.video && dd.buoc === 'kiem_bai'))) {
        if (!(dd.video && dd.buoc === 'kiem_bai') && !choNhanSu('dangdo', `comment tiếp cho ${dd.ten || 'bài vừa đăng'}`)) return;
        if (await theoDoi('dangdo', () => xuLyDangDo(), tenDangDo(dd))) return;
        datKenh(1); // (6.19.3) việc dở kênh 2, 3 trả về mà không làm gì → các bước sau vẫn theo kênh 1
      }
      // 2) chạy thử: chờ người bấm Đăng
      if (!tatDang && lay('cho_tay6', null) && (await theoDoi('chotay', () => tiepChoTay()))) return;
      // 3) Khanh đang đọc dở (Máy Cao)
      if (LA_CAO && lay('khanh_dang', null)) { if (await chayRanh('khanh', () => tiepKhanh()).catch((e) => { luu('khanh_dang', null); ghi(CAI_DAT.KHANH_TEN + ' lỗi: ' + e.message); return false; })) return; }
      // 4) đọc sheet theo lịch (13:30, 18:30)
      await theoDoi('docsheet', () => docSheetTheoLich());
      // 5) dò bài trên trang qua Facebook (10 phút/lần, không tốn Lark)
      if (coApi() && trongGioDo() && Date.now() - ((lay('trang6', null) || {}).luc || 0) > phutDoTrang() * 60000) {
        await theoDoi('dotrang', () => doTrang('định kỳ'));
        await xacDinhMayKhac().catch(() => {});
      }
      for (const c of KENH_PHU) { // (6.19) kênh 2, 3, Hà Xá: chỉ dò khi hôm nay có video của kênh đó
        if (!LICH.some((x) => x.kenh === c) || !coApiKenh(c) || !trongGioDo() || Date.now() - ((lay('trang6_k' + c, null) || {}).luc || 0) <= phutDoTrang() * 60000) continue;
        datKenh(c); try { await theoDoi('dotrang', () => doTrang('định kỳ kênh ' + c), 'Đang kiểm tra bài trên trang kênh ' + c); } finally { datKenh(1); }
      }
      tuDoMaKenh().catch(() => {});
      // 6) đăng bài đến giờ
      if (await theoDoi('dang', () => vongDang())) return;
      datKenh(1);
      // 7) kiểm comment (+2 / +10 / +20 phút, 19:00) và gửi bù
      if (!tatDang && (await theoDoi('kiemcmt', () => vongKiemCmt()))) return;
      datKenh(1);
      if (!tatDang && await vongSuaVideo().catch((e) => { ghi('Gắn thẻ + cảm xúc video lỗi: ' + e.message); return false; })) return;
      datKenh(1);
      // (6.18) chuẩn bị trước giờ đăng ~10 phút · đối chiếu bài sau khi đăng ~15 phút · 16:00 nhắc sheet ngày mai
      if (!tatDang && await theoDoi('chuanbi', () => chuanBiTruoc()).catch((e) => { ghi('Chuẩn bị trước giờ đăng lỗi: ' + e.message); return false; })) return;
      datKenh(1);
      await theoDoi('doichieu', () => doiChieuSauDang()).catch((e) => ghi('Đối chiếu sau đăng lỗi: ' + e.message));
      datKenh(1);
      await ghiGomKetQua().catch((e) => ghi('Ghi gom kết quả lỗi: ' + e.message)); // (6.20.8)
      await ghiBuKetQua().catch(() => {}); // (6.19.3) ghi bù "ĐÃ ĐĂNG" vào sheet cho các bài trước đó ghi lỗi
      await theoDoi('nhacsheet', () => nhacSheetMai()).catch((e) => ghi('Nhắc điền sheet lỗi: ' + e.message));
      // 8) tải sẵn đồ đăng (Máy Giao)
      if (!tatDang) await theoDoi('taisan', () => taiSan());
      // 9) báo cáo cuối ngày
      await tongKet12().catch((e) => ghi('Tổng kết 12:00 lỗi: ' + e.message)); // (6.25)
      await theoDoi('baocao', () => baoCaoNgay().catch((e) => ghi('Báo cáo ngày lỗi: ' + e.message)));
      // 10) báo cáo tuần Khanh (Máy Cao)
      if (LA_CAO) await chayRanh('khanh', () => khanhTuan()).catch((e) => { luu('khanh_dang', null); ghi(CAI_DAT.KHANH_TEN + ' lỗi: ' + e.message); return false; });
      await nhacGiaHanMa().catch(() => {});
      // (6.20) báo cáo chỉ số tuần fb kênh 1 (Máy Cao, thứ 6) — phần phụ, chỉ chạy khi rảnh, đặt cuối nhịp để mọi việc chính được làm trước
      if (LA_CAO) await ghiXem24h().catch(() => {}); // (6.26) ghi lượt xem 24h đầu của video kênh 1 (cho báo cáo tuần)
      if (LA_CAO && !lay('dang_do', null) && !dangBan) { datKenh(1); await theoDoi('chiso', () => vongChiSo()).catch((e) => { ghi('Chỉ số tuần lỗi: ' + e.message); return false; }); datKenh(1); }
      // 11) (6.16) báo cáo lỗi kỹ thuật lên Lark (khi có lỗi mới) + xem có bản mới chờ duyệt (Máy Cao)
      if (canGhiBC() && !dangBan && !lay('dang_do', null)) await theoDoi('baocaoloi', () => ghiBaoCaoLark()).catch((e) => ghi('Ghi báo cáo lỗi lên Lark chưa được: ' + e.message));
      docTrangThaiGit(); docNguonCapNhat(); nhipBaoCaoToi();
    } catch (e) {
      if (e instanceof LoiTamHoan) ghi('Tạm hoãn: ' + e.message); else { ghi('Lỗi không lường trước: ' + e.message); chupLoi('nhịp chính'); }
    } finally {
      { const h = lay('hoat_dong', null); if (h && !hdChay && Date.now() - (h.cap || 0) > 4 * 60000) luu('hoat_dong', null); }
      dangChay = false; datKenh(1); if (laTabChinh()) giuKhoa(); veBang();
    }
  }

  // (6.25) Máy Giao: đến 5:00 / 12:30 / 19:00 tự đưa tab Facebook lên trước (chỉ 3 mốc này, trong giờ làm việc không tự nhảy)
  function nhayVeTabFb() {
    if (!LA_GIAO || !laTabChinh() || !/(^|\.)facebook\.com$/.test(location.hostname)) return;
    const now = phutTrongNgay(new Date()); const ngay = homNay();
    for (const moc of CAI_DAT.MOC_NHAY_TAB || []) {
      const m = docGio(moc); if (now < m || now > m + 15) continue;
      const nh = lay('nhay6', null); const da = nh && nh.ngay === ngay ? nh.ds : []; if (da.includes(moc)) continue; luu('nhay6', { ngay, ds: da.concat(moc) });
      if (document.visibilityState === 'visible' && document.hasFocus()) { ghi(`Mốc ${moc}: tab Facebook đang ở sẵn trước màn hình`); continue; }
      try { window.focus(); } catch (e) { ghi(`Mốc ${moc}: chưa tự chuyển được về tab Facebook (${e.message})`); continue; }
      setTimeout(() => ghi(document.visibilityState === 'visible' ? `Mốc ${moc}: đã tự chuyển về tab Facebook` : `⚠️ Mốc ${moc}: đã thử chuyển về tab Facebook nhưng tab vẫn ẩn (Chrome không cho)`), 4000);
    }
  }
  setInterval(() => { try { nhayVeTabFb(); } catch (e) {} }, 30000);
  setTimeout(() => { try { nhayVeTabFb(); } catch (e) {} }, 5000);
  // Tab vừa hiện lại → nhận việc và chạy ngay (đăng bù bài trễ ngay lúc mở tab)
  document.addEventListener('visibilitychange', () => {
    if (document.visibilityState !== 'visible') return;
    giuKhoa(); veBang(); setTimeout(nhip, 800);
  });
