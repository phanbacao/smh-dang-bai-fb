
  // =====================================================================
  //  LỊCH 9 BÀI / NGÀY + TRẠNG THÁI
  // =====================================================================
  const XONG = ['xong', 'co_san'];                                   // đã lên trang
  const KET = XONG.concat(['bo', 'thieu', 'loi', 'khong_ro']);        // đã kết thúc (không đăng nữa)
  function taoGio() { // giờ ngẫu nhiên trong khung, 2 bài liền nhau cách ít nhất 1 tiếng
    let truoc = -1e9; const g = {};
    for (const it of LICH_GOC) { const a = docGio(it.tu), b = docGio(it.den); let x = a + Math.floor(Math.random() * (b - a + 1)); x = Math.max(x, truoc + CAI_DAT.CACH_LICH_PHUT); g[it.k] = x; truoc = x; }
    return g;
  }
  // (6.19) giờ cho video kênh 2, 3: video cuối của mỗi kênh đăng trước bài đầu tiên kênh 1 khoảng 5–15 phút; video trước đó cách ≥ 30 phút (cùng trang)
  const ngauNhien = (a, b) => a + Math.floor(Math.random() * (b - a + 1));
  function ganGioKenh(s, ngay) {
    const L = lichNgay(ngay).filter((x) => x.kenh > 1); if (!L.length) return false;
    const goc = LICH_GOC.map((x) => s.gio[x.k]).filter((v) => typeof v === 'number'); if (!goc.length) return false;
    const dau = Math.min(...goc); let doi = false;
    for (const c of [2, 3]) {
      const ds = L.filter((x) => x.kenh === c).sort((a, b) => a.so - b.so); if (!ds.length || ds.every((x) => typeof s.gio[x.k] === 'number')) continue;
      const co = ds.filter((x) => typeof s.gio[x.k] === 'number');
      if (!co.length) { // chưa có giờ nào → tính lùi từ trước bài đầu kênh 1
        let t = dau - ngauNhien(CAI_DAT.KENH_TRUOC_PHUT[0], CAI_DAT.KENH_TRUOC_PHUT[1]);
        for (let i = ds.length - 1; i >= 0; i--) { s.gio[ds[i].k] = t; t -= CAI_DAT.KENH_CACH_PHUT + ngauNhien(0, 5); }
      } else { // sheet thêm video giữa ngày → xếp sau video cuối của kênh đó ≥ 30 phút
        let truoc = Math.max(...co.map((x) => s.gio[x.k]));
        for (const x of ds) if (typeof s.gio[x.k] !== 'number') { truoc += CAI_DAT.KENH_CACH_PHUT + ngauNhien(0, 5); s.gio[x.k] = truoc; }
      }
      doi = true;
    }
    return doi;
  }
  function trangThai(ngay = homNay()) {
    let s = lay('ngay6_' + ngay, null);
    if (!s || !s.gio) { s = { gio: taoGio(), s: {}, ngoai: {}, tao: Date.now() }; ganGioKenh(s, ngay); luu('ngay6_' + ngay, s); ghi(`Lịch đăng ${ngay === homNay() ? 'hôm nay' : ngay}: ` + lichNgay(ngay).filter((it) => typeof s.gio[it.k] === 'number').sort((a, b) => s.gio[a.k] - s.gio[b.k]).map((it) => it.ten + ' ' + phutStr(s.gio[it.k])).join(' · ')); }
    else if (ganGioKenh(s, ngay)) { luu('ngay6_' + ngay, s); ghi(`Giờ đăng video kênh 2, 3 ${ngay === homNay() ? 'hôm nay' : ngay}: ` + lichNgay(ngay).filter((it) => it.kenh > 1).map((it) => it.ten + ' ' + phutStr(s.gio[it.k])).join(' · ')); }
    s.s = s.s || {}; s.ngoai = s.ngoai || {};
    return s;
  }
  const capNhatTT = (f, ngay = homNay()) => { const s = trangThai(ngay); f(s); luu('ngay6_' + ngay, s); return s; };
  const ttSlot = (s, k) => s.s[k] || (s.s[k] = { tt: 'cho' });
  function tinhLich(s = trangThai()) { // (6.19) xếp theo giờ; giãn cách bài bù chỉ tính trong CÙNG 1 kênh (mỗi trang riêng)
    const g = (it) => (typeof s.gio[it.k] === 'number' ? s.gio[it.k] : 9e9);
    const L = LICH.slice().sort((a, b) => g(a) - g(b)).map((it) => { const r = s.s[it.k] || { tt: 'cho' }; return Object.assign({}, it, { r, gioKH: s.gio[it.k], ket: KET.includes(r.tt), xong: XONG.includes(r.tt) }); });
    // kênh 1: bài kế tiếp là bài chưa xong đầu tiên theo thứ tự (như cũ); kênh 2, 3: video kênh khác tới giờ thì không phải chờ kênh này
    const conLai = L.filter((x) => !x.ket); if (!conLai.length) return L;
    const den = (x) => Math.max(lucPhut(g(x)), lucBuKenh(L, x));
    // mỗi kênh lấy bài chưa xong đầu tiên của kênh đó → chọn bài tới giờ sớm nhất (bằng nhau thì theo thứ tự lịch)
    const dau = []; for (const x of conLai) if (!dau.some((y) => (y.kenh || 1) === (x.kenh || 1))) dau.push(x);
    let kt = dau[0]; for (const x of dau.slice(1)) if (den(x) < den(kt) && den(kt) > Date.now()) kt = x;
    kt.keTiep = true; kt.den = den(kt);
    return L;
  }
  const lucBuKenh = (L, x) => { const c = x.kenh || 1; const t = Math.max(0, ...L.filter((y) => y.xong && y.r.luc && (y.kenh || 1) === c).map((y) => y.r.luc)); return t ? t + (c > 1 ? CAI_DAT.KENH_CACH_PHUT : CAI_DAT.CACH_BU_PHUT) * 60000 : 0; };
  // trang đang mở thuộc kênh nào (0 = không phải trang nào trong 3 kênh)
  const kenhCuaDuong = () => { const p = location.pathname.toLowerCase().replace(/\/+$/, ''); for (const c of [1, 2, 3]) if (CAI_DAT.KENH[c].duong.includes(p)) return c; return 0; };
  // video kênh 2, 3 vừa đăng (≤ 12 phút) còn chờ thả cảm xúc trên trang đang mở → đừng chuyển sang trang khác vội
  function coSuaKenhCho(c) {
    if (!c || c === 1 || !CAI_DAT.SUA_VIDEO_SAU_DANG) return false; const s = trangThai(); const now = Date.now();
    return LICH.some((x) => x.kenh === c && (() => { const r = s.s[x.k]; return r && XONG.includes(r.tt) && r.may === MAY && r.link && !r.suaXong && (r.suaLan || 0) < CAI_DAT.KENH_SUA_TOI_DA && now - (r.luc || 0) < 12 * 60000; })());
  }
  const keTiep = () => tinhLich().find((x) => x.keTiep) || null;
  // "máy mở lại lúc nào" (để Máy Cao chờ Máy Giao làm trước khi cả hai cùng có mạng lại)
  let moLuc = Date.now();
  { const song = lay('song6', 0); const m0 = lay('mo6', 0); moLuc = Date.now() - song < 5 * 60000 && m0 ? m0 : Date.now(); luu('mo6', moLuc); }
  const tamDung = () => !!lay('tam_dung', false);
  const tuDong = () => lay('tu_dong6', true) !== false;
  const chayThu = () => !!lay('chay_thu6', false);
  const dangHoan = () => lay('hoan6', 0) > Date.now();

  // =====================================================================
  //  DÒ BÀI TRÊN TRANG (qua Facebook — không tốn lượt Lark)
  // =====================================================================
  const loaiSo = { b1: 1, b2: 2, b3: 3, video: 4, manifest: 5 };
  // khớp bài trên trang với chữ trong sheet: so từng từ (≥ 90%); dự phòng khi Facebook dính chữ ở chỗ xuống dòng → so chuỗi chữ-số liền (40 ký tự đầu)
  // (6.17) 2 video khác nhau có thể giống nhau gần hết phần thân (chỉ khác câu mở đầu) → bắt buộc câu mở đầu cũng phải khớp;
  // 1 thước phim có thể hiện 2 lần trong danh sách Facebook (2 mã khác nhau, cùng 1 link) → coi là 1 bài, không gán cho 2 ô
  const linkGon = (l) => String(l || '').replace(/[?#].*$/, '').replace(/\/+$/, '').replace(/^https?:\/\/(www\.|m\.|web\.)?/, '').toLowerCase();
  const dongDau = (s) => (String(s || '').split('\n').map((x) => x.trim()).find((x) => tuCua(x).length >= 2) || '');
  function dauKhop(p, text) {
    const d = dongDau(text); const a = tuCua(d); if (a.length < 3) return true;
    { const kd = khoaSo(d); if (kd.length >= 12 && khoaSo(p.text).slice(0, kd.length + 40).includes(kd)) return true; } // (6.19) Facebook dính chữ ở chỗ xuống dòng ("denNang") → so chuỗi chữ-số liền của câu mở đầu
    const b = tuCua(p.text).slice(0, a.length + 8).join(' ');
    return doGiong(b, d) >= 0.75;
  }
  function baiKhop(ds, text, daDung) {
    const ok = ds.filter((x) => !(daDung && (daDung.has(x.id) || (x.link && daDung.has('L:' + linkGon(x.link))))) && dauKhop(x, text));
    const p = baiGiongNhat(ok, text); if (p) return p;
    const k = khoaSo(text).slice(0, 40); if (k.length < 20) return null;
    return ok.find((x) => khoaSo(x.text).includes(k)) || null;
  }
  const dungBai = (set, p) => { set.add(p.id); if (p.link) set.add('L:' + linkGon(p.link)); };
  // ---- (6.9) cài đặt comment: comment mặc định + link Zalo + danh sách câu CTA (lưu trong máy + ô Z3 của sheet cho cả 2 máy) ----
  function cauHinhCmt() {
    const c = lay('cmt6', null) || {};
    const cta = Array.isArray(c.cta) ? c.cta.map((x) => String(x).trim()).filter(Boolean) : CAI_DAT.CTA_MAC_DINH.slice();
    return { goc: typeof c.goc === 'string' && c.goc.trim() ? c.goc : CAI_DAT.CMT_BAI3, link: (c.link || CAI_DAT.LINK_ZALO).trim(), cta, bat: c.bat !== false,
      loai: Object.assign({ b1: true, b2: true, b3: true, video: true, manifest: true }, c.loai || {}), kenh: Object.assign({ 1: true, 2: true, 3: true }, c.kenh || {}), luc: c.luc || 0, may: c.may || '' };
  }
  function soNgau(seed) { let a = seed >>> 0; return () => { a = (a + 0x6D2B79F5) >>> 0; let t = a; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }
  function chonCTA(k, ngay = homNay()) { // mỗi bài trong ngày 1 câu khác nhau (xáo theo ngày), hết câu thì quay vòng
    const c = cauHinhCmt(); if (!c.cta.length) return '';
    let seed = 0; for (const ch of ngay) seed = seed * 31 + ch.charCodeAt(0);
    const r = soNgau(seed); const thu = c.cta.map((x, i) => [r(), i]).sort((a, b) => a[0] - b[0]).map((x) => x[1]);
    const vt = LICH.findIndex((x) => x.k === k);
    return c.cta[thu[(vt >= 0 ? vt : Math.floor(Math.random() * 9)) % thu.length]];
  }
  // (6.12) CTA nhóm Zalo là 1 comment RIÊNG, đăng ngay sau comment chữ chính (trước các comment ảnh)
  function cmtCTA(it, ngay) {
    const c = cauHinhCmt(); if (!c.bat || !c.loai[it.loai] || !c.link || !c.cta.length) return '';
    if (it.k && c.kenh[kenhCua(it.k)] === false) return ''; // (6.19) bỏ tick CTA Zalo của kênh nào thì kênh đó không comment CTA
    return `${chonCTA(it.k, ngay)}\n>>> ${c.link}`; // (6.12) không ghi chữ "CTA:" / "Link:"
  }
  function canCmt(it, nd, chung, ngay) { // các comment cần có dưới bài (để kiểm và gửi bù)
    chung = chung || ((duLieu() || {}).chung) || { co: '', pool: [] };
    const it2 = it.k ? it : { loai: it.loai || 'video' };
    const cta = cmtCTA(it2, ngay);
    if (it.loai === 'b1' || it.loai === 'b2') return { text: nd.cmt ? [nd.cmt].concat(cta ? [cta] : []) : [], anh: [] };
    const anh = []; if (chung.co) anh.push(chung.co); if (chung.pool.length) anh.push(chung.pool[Math.floor(Math.random() * chung.pool.length)]);
    if (it.loai === 'b3') (nd.anhCmt || []).forEach((t) => anh.push(t));
    return { text: [cauHinhCmt().goc].concat(cta ? [cta] : []), anh };
  }
  async function luuCauHinhCmt(c) {
    const moi = { goc: c.goc, link: c.link, cta: c.cta, bat: c.bat, loai: c.loai, kenh: c.kenh || { 1: true, 2: true, 3: true }, luc: Date.now(), may: MAY };
    luu('cmt6', moi);
    ghi(`Đã lưu cài đặt comment (${moi.cta.length} câu CTA, CTA ${moi.bat ? 'BẬT' : 'TẮT'})`);
    await ghiO(CAI_DAT.TAB_BAI, CAI_DAT.O_CMT, JSON.stringify(moi));
    luu('cmt6_dongbo', Date.now());
    return moi;
  }
  // ---- (6.11) kho thẻ: video / manifest — mỗi bài bốc 8 thẻ, các bài cùng loại trong ngày lấy bộ khác nhau ----
  function khoThe() {
    const c = lay('the6', null) || {}; const sach = (a, md) => (Array.isArray(a) ? a.map((x) => String(x).trim()).filter(Boolean) : md.slice());
    return { video: sach(c.video, CAI_DAT.THE_VIDEO), manifest: sach(c.manifest, CAI_DAT.THE_MANIFEST), luc: c.luc || 0, may: c.may || '' };
  }
  function chonThe(loai, so, ngay = homNay(), kho) {
    const ds = (kho || khoThe())[loai === 'manifest' ? 'manifest' : 'video']; const n = Math.min(CAI_DAT.SO_THE, ds.length); if (!n) return [];
    let seed = 7; for (const ch of ngay + loai) seed = seed * 31 + ch.charCodeAt(0);
    const r = soNgau(seed); const thu = ds.map((x, i) => [r(), i]).sort((a, b) => a[0] - b[0]).map((x) => x[1]);
    const out = []; for (let j = 0; j < n; j++) out.push(ds[thu[((so || 0) * n + j) % thu.length]]);
    return [...new Set(out)];
  }
  async function luuKhoThe(c) {
    const moi = { video: c.video, manifest: c.manifest, luc: Date.now(), may: MAY };
    luu('the6', moi); ghi(`Đã lưu kho thẻ (video ${moi.video.length} thẻ, manifest ${moi.manifest.length} thẻ)`);
    await ghiO(CAI_DAT.TAB_BAI, CAI_DAT.O_THE, JSON.stringify(moi)); luu('the6_dongbo', Date.now());
    return moi;
  }
  async function dongBoThe() {
    try {
      const t = chuO(await docO(CAI_DAT.TAB_BAI, CAI_DAT.O_THE)).trim(); if (!t || t[0] !== '{') return false;
      const z = JSON.parse(t); const cu = lay('the6', null) || {}; luu('the6_dongbo', Date.now());
      if ((z.luc || 0) > (cu.luc || 0) && JSON.stringify([z.video, z.manifest]) !== JSON.stringify([cu.video, cu.manifest])) { luu('the6', z); ghi(`Cập nhật kho thẻ từ sheet (bản lưu lúc ${gioStr(new Date(z.luc))})`); return true; }
    } catch (e) { /* */ }
    return false;
  }
  async function baiConAnhApi(text) { // true = còn ảnh · false = không còn ảnh · null = chưa hỏi được
    if (!coApi() || !text) return null;
    try {
      const p = baiKhop(await baiTrenTrangApi(Date.now() - 12 * 3600e3), text); if (!p || !p.id) return null;
      const j = await goiFb(`/${p.id}?fields=attachments{type,media_type,subattachments{type,media_type}}`);
      const ds = ((j.attachments || {}).data || []); const anh = (x) => /photo|album|image/i.test((x.type || '') + ' ' + (x.media_type || ''));
      return ds.some((x) => anh(x) || ((x.subattachments || {}).data || []).some(anh));
    } catch (e) { return null; }
  }
  async function dongBoCmt() { // đọc bản trên sheet (ô Z3): mới hơn bản trong máy thì dùng bản sheet
    try {
      const t = chuO(await docO(CAI_DAT.TAB_BAI, CAI_DAT.O_CMT)).trim(); if (!t || t[0] !== '{') return false;
      const z = JSON.parse(t); const cu = lay('cmt6', null) || {};
      luu('cmt6_dongbo', Date.now());
      const khac = JSON.stringify([z.goc, z.link, z.cta, z.bat, z.loai, z.kenh]) !== JSON.stringify([cu.goc, cu.link, cu.cta, cu.bat, cu.loai, cu.kenh]);
      if ((z.luc || 0) > (cu.luc || 0) && khac) { luu('cmt6', z); ghi(`Cập nhật cài đặt comment từ sheet (bản lưu lúc ${gioStr(new Date(z.luc))}${z.may ? ' ở ' + (z.may === 'GIAO' ? 'Máy Giao' : 'Máy Cao') : ''})`); return true; }
    } catch (e) { /* */ }
    return false;
  }
  let doTrangCho = null;
  async function doTrang(lyDo = '') {
    if (!coApi()) return null;
    if (doTrangCho) return doTrangCho;
    doTrangCho = (async () => {
      const tu = new Date(new Date().setHours(0, 0, 0, 0)).getTime();
      const ds = await baiTrenTrangApi(tu - 6 * 3600e3);
      const homNayDs = ds.filter((p) => p.luc >= tu);
      const KC = KENH_HT; const LK = LICH.filter((x) => (x.kenh || 1) === KC); // (6.19) chỉ dò các bài của kênh đang xét
      luu(KC === 1 ? 'trang6' : 'trang6_k' + KC, { luc: Date.now(), n: homNayDs.length, moiNhat: Math.max(0, ...ds.map((p) => p.luc || 0)) });
      const d = duLieu(); const ngay = homNay(); let moi = [];
      const dd = lay('dang_do', null);
      capNhatTT((s) => {
        // (6.17) sửa ô đã nhận nhầm: 2 ô cùng 1 link bài → ô "máy khác / có sẵn" là nhận nhầm → trả về chờ để dò lại
        const theoLink = {};
        for (const it of LK) { const r = s.s[it.k]; if (r && XONG.includes(r.tt) && r.link) (theoLink[linkGon(r.link)] = theoLink[linkGon(r.link)] || []).push(it); }
        for (const ds2 of Object.values(theoLink)) {
          if (ds2.length < 2) continue;
          const sai = ds2.filter((it) => ['khac', 'tay'].includes(s.s[it.k].may) || s.s[it.k].tt === 'co_san');
          const bo = sai.length < ds2.length ? sai : sai.slice(1);
          for (const it of bo) { const r = s.s[it.k]; moi.push(`${it.ten}: trước đó nhận nhầm bài của ô khác (cùng link) → dò lại`); s.s[it.k] = { tt: 'cho', lan: r.lan || 0, vong: r.vong || 0, can: r.can, lyDo: '' }; }
        }
        const daDung = new Set(); for (const r of Object.values(s.s)) if (r && r.id) dungBai(daDung, r);
        for (const it of LK) {
          const r = ttSlot(s, it.k); if (XONG.includes(r.tt) && r.id) continue;
          const nd = noiDungSlot(ngay, it.k, d); if (!nd.text) continue;
          let p = baiKhop(homNayDs, nd.text, daDung);
          if (p && (it.loai === 'video' || it.loai === 'manifest') && laVideoApi(p) === false) p = null;
          if (!p) continue;
          dungBai(daDung, p);
          { const ng0 = s.ngoai[p.id]; if (ng0) { Object.assign(r, { kiem: ng0.kiem || r.kiem, cmtOk: ng0.cmtOk, guiBu: ng0.guiBu, kiem19: ng0.kiem19 }); delete s.ngoai[p.id]; } }
          if (XONG.includes(r.tt)) { Object.assign(r, { id: p.id, link: p.link || r.link }); continue; }
          if (dd && dd.slot === it.k) { Object.assign(r, { id: p.id, link: p.link }); continue; } // máy này đang làm dở bài đó
          s.s[it.k] = Object.assign(r, { tt: 'xong', luc: p.luc, id: p.id, link: p.link || '', may: 'khac', kiem: r.kiem || [], can: r.can || canCmt(it, nd), lyDo: '' });
          moi.push(`${it.ten} (đăng lúc ${gioStr(new Date(p.luc))})`);
        }
        // dự phòng: manifest / video đăng tay mà chữ khác sheet (hoặc sheet thiếu chữ) → gán vào ô còn trống theo thứ tự giờ đăng
        const giu = (p) => Object.values(s.ngoai).some((g) => g.giu && (g.id === p.id || (!g.id && baiGiongNhat([p], g.text))));
        const chuaDung = (p) => !daDung.has(p.id) && !(p.link && daDung.has('L:' + linkGon(p.link)));
        const conMf = homNayDs.filter((p) => chuaDung(p) && !giu(p) && /#manifest/i.test(p.text || '')).sort((a, b) => a.luc - b.luc);
        const conVd = homNayDs.filter((p) => chuaDung(p) && !giu(p) && !/#manifest/i.test(p.text || '') && laVideoApi(p) === true).sort((a, b) => a.luc - b.luc);
        for (const it of LK) {
          if (it.loai !== 'manifest' && it.loai !== 'video') continue;
          const r = ttSlot(s, it.k); if (XONG.includes(r.tt) || r.tt === 'dang' || (dd && dd.slot === it.k)) continue;
          const p = (it.loai === 'manifest' ? conMf : conVd).shift(); if (!p) continue;
          dungBai(daDung, p);
          const ng = s.ngoai[p.id]; if (ng) { Object.assign(r, { kiem: ng.kiem || [], cmtOk: ng.cmtOk, guiBu: ng.guiBu, kiem19: ng.kiem19 }); delete s.ngoai[p.id]; }
          s.s[it.k] = Object.assign(r, { tt: 'xong', luc: p.luc, id: p.id, link: p.link || '', may: 'khac', kiem: r.kiem || [], can: r.can || canCmt(it, noiDungSlot(ngay, it.k, d)), lyDo: '' });
          moi.push(`${it.ten} (đăng tay lúc ${gioStr(new Date(p.luc))}, nhận theo thứ tự)`);
        }
        if (KC !== 1) return; // bài đăng tay ngoài lịch: chỉ theo dõi ở kênh 1
        for (const kg of Object.keys(s.ngoai)) { const g = s.ngoai[kg]; if (g.giu && !g.id) { const p = homNayDs.find((q) => !daDung.has(q.id) && baiGiongNhat([q], g.text)); if (p) { delete s.ngoai[kg]; s.ngoai[p.id] = Object.assign(g, { id: p.id, link: p.link || g.link, luc: p.luc }); daDung.add(p.id); } } }
        const linkNgoai = new Set(Object.values(s.ngoai).map((g) => linkGon(g.link)).filter(Boolean));
        for (const p of homNayDs) { // video/manifest đăng tay (không thuộc lịch) → cũng cần comment
          if (!chuaDung(p) || s.ngoai[p.id] || (p.link && linkNgoai.has(linkGon(p.link)))) continue;
          if (laVideoApi(p) === true || /#manifest/i.test(p.text || '')) { s.ngoai[p.id] = { luc: p.luc, id: p.id, link: p.link || '', text: String(p.text || '').slice(0, 300), kiem: [], can: canCmt({ loai: 'video' }, {}) }; moi.push('bài đăng tay lúc ' + gioStr(new Date(p.luc))); }
        }
      });
      if (moi.length) ghi('Dò trang' + (lyDo ? ' (' + lyDo + ')' : '') + ': thấy ' + moi.join(', '));
      return ds;
    })();
    try { return await doTrangCho; } catch (e) { ghi('Dò trang qua Facebook lỗi: ' + e.message); return null; } finally { doTrangCho = null; }
  }
  // Máy Giao thấy bài trong lịch do "máy khác" đăng → xem ô giữ chỗ: nếu Máy Cao đã nhận bài đó thì để Máy Cao lo comment (tránh 2 máy cùng gửi bù)
  async function xacDinhMayKhac() {
    if (!LA_GIAO || chanLark()) return;
    const s = trangThai(); const cac = LICH.filter((it) => { const r = s.s[it.k]; return r && r.may === 'khac' && !r.daXemKhoa; });
    if (!cac.length) return;
    let v = ''; try { v = chuO(await docO(CAI_DAT.TAB_BAI, CAI_DAT.O_KHOA)); } catch (e) { return; }
    const x = docKhoa(v);
    capNhatTT((s2) => { for (const it of cac) { const r = s2.s[it.k]; r.daXemKhoa = true; if (x && x.ngay === homNay() && x.slot === it.k && x.may === 'CAO') { r.may = 'CAO'; ghi(`${it.ten} do Máy Cao đăng thay → Máy Cao lo phần comment`); } } });
  }

  // =====================================================================
  //  Ô GIỮ CHỖ (chỉ dùng khi Máy Giao trễ hoặc Máy Cao đăng thay) — 3 lượt gọi Lark
  // =====================================================================
  const docKhoa = (v) => { const m = String(v || '').match(/^KHOA\|(\d{2}-\d{2}-\d{4})\|(\w+)\|(GIAO|CAO)\|(\d+)$/); return m ? { ngay: m[1], slot: m[2], may: m[3], luc: +m[4] } : null; };
  async function giuCho(k) {
    const doc = async () => { const c = await docO(CAI_DAT.TAB_BAI, CAI_DAT.O_KHOA); const t = chuO(c).trim(); if (t && !/^KHOA\|/.test(t)) throw new LoiMem(`ô ${CAI_DAT.O_KHOA} (tab Bài viết kênh 1) đang có chữ khác — script không dùng ô này để giữ chỗ`); return docKhoa(t); };
    const x = await doc();
    if (x && x.ngay === homNay() && x.slot === k && x.may !== MAY && Date.now() - x.luc < CAI_DAT.NHUONG_PHUT * 60000) { ghi(`${tenSlot(k)}: máy ${x.may === 'CAO' ? 'Cao' : 'Giao'} đã giữ chỗ lúc ${gioStr(new Date(x.luc))} → nhường, không đăng`); return false; }
    await ghiO(CAI_DAT.TAB_BAI, CAI_DAT.O_KHOA, `KHOA|${homNay()}|${k}|${MAY}|${Date.now()}`);
    await sleepThat(20000);
    const y = await doc();
    const ok = !!(y && y.ngay === homNay() && y.slot === k && y.may === MAY);
    ghi(ok ? `${tenSlot(k)}: đã giữ chỗ (ô ${CAI_DAT.O_KHOA}) → ${TEN_MAY} đăng` : `${tenSlot(k)}: máy kia vừa giữ chỗ cùng lúc → nhường`);
    return ok;
  }

  // =====================================================================
  //  ĐẾM NGƯỢC 10 GIÂY trước mỗi việc chạm vào trang (nhấp nháy + Tạm dừng/Tiếp tục + Hoãn 10 phút)
  // =====================================================================
  let demNguoc = null; // { ten, den, dung, dungLuc, hoan }
  function batDemNguoc(ten) {
    demNguoc = { ten, den: Date.now() + CAI_DAT.DEM_NGUOC_GIAY * 1000, dung: false, hoan: false };
    veBang();
    return new Promise((resolve) => {
      const iv = setInterval(() => {
        const d = demNguoc;
        if (!d) { clearInterval(iv); resolve('hoan'); return; }
        if (d.hoan) { clearInterval(iv); demNguoc = null; resolve('hoan'); veBang(); return; }
        if (d.dung) { if (Date.now() - d.dungLuc > 10 * 60000) { d.dung = false; d.den = Date.now() + CAI_DAT.DEM_NGUOC_GIAY * 1000; ghi('Đếm ngược: tạm dừng quá 10 phút → tự tiếp tục'); } veDemNguoc(); return; }
        if (Date.now() >= d.den) { clearInterval(iv); demNguoc = null; resolve('ok'); veBang(); return; }
        veDemNguoc();
      }, 250);
    });
  }
  // chờ nhân sự dùng xong trang (tối đa 10 phút) — trả về true nếu được làm ngay
  function choNhanSu(khoaCho, ten) { // ten: việc sắp làm (để popup nói rõ "Sắp …")
    const ly = nhanSuDangDung();
    const k = 'cho_ns_' + khoaCho; const tu = window[k] || 0;
    ten = ten || (khoaCho.startsWith('dang') ? 'đăng bài' : 'làm việc trên trang');
    if (!ly) { window[k] = 0; return true; }
    if (Date.now() - (lay('lam_ngay6', 0) || 0) < 60000) { window[k] = 0; luu('lam_ngay6', 0); luu('cho_nguoi', null); ghi(`Bạn bấm "Làm ngay" → ${ten} luôn`); return true; }
    if (!tu) { window[k] = Date.now(); ghi(`Sắp ${ten}, nhưng ${ly} → chờ tối đa ${CAI_DAT.CHO_NGUOI_TOI_DA_PHUT} phút (có đếm ngược 10 giây) — bấm "Làm ngay" trên popup để làm luôn`); }
    luu('cho_nguoi', { ly, luc: window[k], viec: khoaCho, ten });
    if (Date.now() - (window[k] || Date.now()) >= CAI_DAT.CHO_NGUOI_TOI_DA_PHUT * 60000) { window[k] = 0; return true; }
    return false;
  }

  // =====================================================================
  //  ĐĂNG 1 BÀI TRONG LỊCH
  // =====================================================================
  let dangBan = false;
  function tabAnNhac(it) { // đến giờ mà tab Facebook bị ẩn: thông báo trên máy (15 phút/lần) + báo nhóm 1 lần/ngày
    const k = 'an6_' + homNay(); const a = lay(k, { luc: 0, so: 0 });
    if (Date.now() - a.luc >= 15 * 60000 && a.so < 6) { luu(k, { luc: Date.now(), so: a.so + 1 }); thongBaoMay(`Đến giờ ${it.ten} — cần mở tab Facebook`, 'Tab Facebook đang bị che/thu nhỏ nên chưa đăng được. Mở cửa sổ Facebook lên là script đăng ngay.'); }
    baoLoi(`Đến giờ ${it.ten} nhưng tab Facebook đang bị ẩn/thu nhỏ — mở tab lên là script đăng ngay`, 'tab_an');
  }
  async function vongDang() {
    if (!MAY || tamDung() || !laTabChinh() || dangBan || lay('dang_do', null) || lay('cho_tay6', null)) return false;
    if (lay('nghi_loi6', 0) > Date.now()) return false; // (6.15) Facebook báo lỗi 3 lần liền → nghỉ 10 phút
    const L = tinhLich();
    // bấm "Đăng ngay" trên popup: bài đó được làm trước (kể cả chưa phải bài kế tiếp)
    const epIt = L.find((x) => !x.ket && x.r.tt !== 'dang' && x.r.ep && Date.now() - x.r.ep < 15 * 60000);
    if (!epIt && (await soanBaiMai())) return true;
    let it = epIt || L.find((x) => x.keTiep); if (!it) return false;
    // (6.10) bài kế tiếp đang chờ thử lại (lỗi) → các bài sau tới giờ vẫn đăng, không đứng chờ bài lỗi
    const sanSang = (x) => !x.ket && x.r.tt !== 'dang' && !(x.r.thuLai && Date.now() < x.r.thuLai) && !(x.r.choDen && Date.now() < x.r.choDen);
    if (!epIt && !sanSang(it) && it.r.thuLai && Date.now() < it.r.thuLai) {
      const khac = L.find((x) => x.k !== it.k && sanSang(x) && Date.now() >= Math.max(lucPhut(x.gioKH), lucBuKenh(L, x)));
      if (khac) { if (it.r.thuLai - Date.now() > 60000 && !window['__vuot_' + khac.k]) { window['__vuot_' + khac.k] = 1; ghi(`${it.ten} đang chờ thử lại lúc ${gioStr(new Date(it.r.thuLai))} → đăng ${khac.ten} trước (không để bài lỗi chặn các bài khác)`); } it = Object.assign({}, khac, { den: Math.max(lucPhut(khac.gioKH), lucBuKenh(L, khac)) }); }
    }
    if (!it.den) it.den = Date.now();
    datKenh(it.kenh); // (6.19) mọi bước sau (tư cách, đúng trang, dò bài qua Facebook) theo kênh của bài này
    const now = Date.now(), ngay = homNay(), mm = phutTrongNgay(new Date());
    const r = it.r; const ep = r.ep && now - r.ep < 15 * 60000;
    // quá giờ chót: các bài còn lại bỏ, ghi vào báo cáo ngày
    if (!ep && mm >= docGio(CAI_DAT.GIO_CHOT)) {
      const con = L.filter((x) => !x.ket);
      capNhatTT((s) => { for (const x of con) Object.assign(ttSlot(s, x.k), { tt: 'bo', lyDo: `quá ${CAI_DAT.GIO_CHOT} chưa đăng được${x.r.loi ? ' (' + x.r.loi + ')' : ''}` }); });
      ghi(`Quá ${CAI_DAT.GIO_CHOT}: bỏ ${con.map((x) => x.ten).join(', ')} — ghi vào báo cáo ngày`);
      if (LA_GIAO || L.some((x) => x.r.may === MAY)) await baoLoi(`Quá ${CAI_DAT.GIO_CHOT} chưa đăng được: ${con.map((x) => x.ten).join(', ')} — đã bỏ, ghi vào báo cáo ngày`, 'chot');
      return true;
    }
    if (!tuDong() && !ep) return false;
    if (!ep && r.thuLai && now < r.thuLai) return false;
    if (!ep && r.choDen && now < r.choDen) return false;
    // giờ bắt đầu theo vai trò của máy
    let batDau = it.den;
    if (LA_CAO && !ep) batDau = Math.max(it.den + CAI_DAT.CAO_TRE_PHUT * 60000, moLuc + CAI_DAT.CAO_CHO_MO_PHUT * 60000);
    if (!ep && now < batDau) return false;
    { const kt = kenhCuaDuong(); if (!ep && kt && kt !== (it.kenh || 1) && coSuaKenhCho(kt)) return false; }
    if (LA_CAO && !ep && (it.kenh || 1) > 1 && !coApi()) { // (6.19) Máy Cao không biết Máy Giao đã đăng chưa (chưa đọc được trang) → không đăng thay, tránh trùng
      capNhatTT((s) => { Object.assign(ttSlot(s, it.k), { tt: 'bo', lyDo: 'Máy Cao chưa có mã khoá đọc được trang kênh ' + it.kenh + ' → không đăng thay (tránh trùng với Máy Giao)' }); });
      ghi(`${it.ten}: Máy Cao chưa đọc được trang ${CAI_DAT.TEN_NGAN} qua Facebook nên không biết Máy Giao đã đăng chưa → không đăng thay (tránh trùng)`); return true;
    } // (6.19) thả cảm xúc xong video kênh 2/3 đang mở rồi mới chuyển trang
    if (document.visibilityState !== 'visible') { tabAnNhac(it); return false; }
    if (!ep && dangHoan()) return false;
    if (!ep && !choNhanSu('dang_' + it.k, `đăng ${it.ten} (hẹn ${gioStr(new Date(it.den))})`)) return false;
    // nội dung trong sheet
    let nd = noiDungSlot(ngay, it.k);
    if (nd.thieu.length) {
      const d0 = duLieu();
      if (!chanLark() && (!d0 || !d0.ngay || !d0.ngay[ngay] || now - (d0.luc || 0) > 30 * 60000) && now - (r.docLai || 0) > 30 * 60000) {
        capNhatTT((s) => { ttSlot(s, it.k).docLai = now; });
        ghi(`${it.ten}: thiếu ${nd.thieu.join(', ')} → đọc lại sheet 1 lần xem đã bổ sung chưa`);
        try { await docDuLieu('thieu'); } catch (e) { ghi('Đọc lại sheet lỗi: ' + e.message); }
        nd = noiDungSlot(ngay, it.k);
      }
      if (nd.thieu.length) {
        capNhatTT((s) => { Object.assign(ttSlot(s, it.k), { tt: 'thieu', lyDo: 'thiếu ' + nd.thieu.join(', ') }); });
        ghi(`Bỏ qua ${it.ten}: thiếu ${nd.thieu.join(', ')}`);
        if (LA_GIAO) await baoLoi(`${it.ten} hôm nay chưa đăng được vì sheet thiếu ${nd.thieu.join(', ')} — đã bỏ qua, đăng bài kế tiếp`, 'thieu_' + it.k);
        return true;
      }
    }
    // trang đã có bài này chưa (máy kia / đăng tay) + giãn cách với bài gần nhất trên trang
    if (coApi()) {
      const ds = await doTrang('trước khi đăng ' + it.ten);
      const r2 = trangThai().s[it.k] || {};
      if (XONG.includes(r2.tt)) { ghi(`${it.ten} đã có trên trang (${r2.may === 'khac' ? 'máy khác/đăng tay' : 'đã ghi nhận'}) → không đăng`); return true; }
      if (ds && !ep) {
        const moiNhat = Math.max(0, ...ds.map((p) => p.luc || 0));
        const cachTrang = (it.kenh || 1) > 1 ? CAI_DAT.KENH_CACH_PHUT : CAI_DAT.CACH_TRANG_PHUT;
        if (moiNhat && now - moiNhat < cachTrang * 60000) {
          const den = moiNhat + cachTrang * 60000 + 30000;
          capNhatTT((s) => { ttSlot(s, it.k).choDen = den; });
          ghi(`${it.ten}: bài gần nhất trên trang mới ${Math.round((now - moiNhat) / 60000)} phút → chờ đến ${gioStr(new Date(den))}`);
          return false;
        }
      }
    }
    // 2 máy cùng bật: Máy Cao (dự phòng) hoặc Máy Giao trễ quá 15 phút phải giữ chỗ trước
    if (LA_CAO || now > it.den + CAI_DAT.GIAO_GIU_CHO_SAU_PHUT * 60000) {
      try {
        if (!(await giuCho(it.k))) { capNhatTT((s) => { ttSlot(s, it.k).choDen = Date.now() + 5 * 60000; }); return false; }
      } catch (e) { ghi(`${it.ten}: chưa giữ chỗ được (${e.message}) → ${LA_CAO ? 'Máy Cao không đăng để tránh trùng' : 'vẫn đăng (đã kiểm trang chưa có bài)'}`); if (LA_CAO) { capNhatTT((s) => { ttSlot(s, it.k).choDen = Date.now() + 10 * 60000; }); return false; } }
      if (LA_CAO && !ep) await baoLoi(`Máy Giao chưa đăng ${it.ten} (quá ${Math.round((now - it.den) / 60000)} phút so với giờ hẹn ${gioStr(new Date(it.den))}) → Máy Cao đăng thay`, 'thay_' + it.k);
    }
    // đếm ngược 10 giây (bấm "Đăng ngay" trên popup thì không cần)
    if (!ep) { const kq = await batDemNguoc('đăng ' + it.ten); if (kq !== 'ok') { ghi(`Hoãn đăng ${it.ten} (nhân sự bấm Hoãn)`); return false; } }
    if (tamDung() || lay('dang_do', null) || !laTabChinh()) return false;
    const soan = chayThu() || !!(ep && r.soan); // bấm "Soạn": làm hết mọi thứ, dừng trước nút Đăng
    dangBan = true; giuKhoa();
    window.__smhLan = (r.lan || 0) + ((r.vong || 1) - 1) * CAI_DAT.SO_LAN_THU; window.__smhBoQua = []; window.__smhHuyLuot = 0; window.__smhTreoLuc = 0; // lần thử thứ mấy (để bật chế độ bỏ bước phụ khi thử lại)
    if (window.__smhLan) ghi(`${it.ten}: lần thử ${window.__smhLan + 1} — bước phụ nào lỗi sẽ bỏ qua để bài vẫn lên`);
    capNhatTT((s) => { const x = ttSlot(s, it.k); x.tt = 'dang'; x.batDau = Date.now(); x.may = MAY; x.ep = 0; x.soan = false; });
    try { await dangSlot(it, nd, soan); }
    catch (e) { await xuLyLoiDang(it, e); }
    finally { dangBan = false; giuKhoa(); veBang(); }
    return true;
  }

  // bấm "Soạn" ở tab Ngày mai: soạn thử bài của ngày mai NGAY HÔM NAY (làm hết, dừng trước nút Đăng) — để kiểm tra trước, không đăng
  async function soanBaiMai() {
    const nm = ngayMai(); const sM = lay('ngay6_' + nm, null); if (!sM || !sM.s) return false;
    const k = Object.keys(sM.s).find((x) => sM.s[x].ep && Date.now() - sM.s[x].ep < 15 * 60000 && sM.s[x].soan && !XONG.includes(sM.s[x].tt));
    if (!k) return false;
    const it = lichNgay(nm).find((x) => x.k === k); if (!it) return false;
    if (document.visibilityState !== 'visible') return false;
    datKenh(it.kenh);
    capNhatTT((s) => { const x = ttSlot(s, k); x.ep = 0; x.soan = false; x.soanThu = Date.now(); }, nm);
    const nd = noiDungSlot(nm, k);
    if (nd.thieu.length) { ghi(`Soạn thử ${it.ten} ngày mai: sheet còn thiếu ${nd.thieu.join(', ')} → chưa soạn được`); thongBaoMay(`Chưa soạn được ${it.ten} ngày mai`, 'Sheet còn thiếu ' + nd.thieu.join(', ')); return true; }
    dangBan = true; giuKhoa(); veBang();
    try { await dangSlot(it, nd, true, nm); }
    catch (e) { ghi(`Soạn thử ${it.ten} ngày mai lỗi: ${e.message}`); chupLoi(it.ten); try { await dongHopSoan(); } catch (e2) { /* */ } thongBaoMay(`Soạn thử ${it.ten} ngày mai chưa được`, e.message); }
    finally { dangBan = false; giuKhoa(); veBang(); }
    return true;
  }
  // (6.10) bài bị bỏ vì sheet thiếu nội dung: đọc sheet thấy đã bổ sung → tự đưa lại hàng chờ (đăng bù, cách bài trước 30 phút)
  function thuLaiBaiThieu(d) {
    const ngay = homNay(); const s0 = trangThai(); const dua = [];
    for (const it of LICH) { const r = s0.s[it.k]; if (r && r.tt === 'thieu' && !noiDungSlot(ngay, it.k, d).thieu.length) dua.push(it); }
    if (!dua.length) return;
    capNhatTT((s) => { for (const it of dua) Object.assign(ttSlot(s, it.k), { tt: 'cho', lyDo: '', loi: '', lan: 0, thuLai: 0, docLai: 0 }); });
    ghi(`Sheet đã bổ sung nội dung cho ${dua.map((x) => x.ten).join(', ')} → đưa lại hàng chờ để đăng bù`);
  }
  // (6.10) thả cảm xúc cho thước phim (trang /reel/…): nút Thích nằm ở cột nút bên phải, không nằm trong khung bài như bài thường
  async function thaCamXucReel(text) {
    if (!CAI_DAT.THA_CAM_XUC) return { tt: 'tat' };
    try {
      kiemDung();
      if (!/^\/reel\//.test(location.pathname) && timBai(text)) return await thaCamXucBai(text);
      const timNut = (n) => [...document.querySelectorAll('[role="button"],button')].find((b) => {
        if (!dangHien(b) || b.closest('[role="article"]') || b.closest('#smhfb,#smhfb-soan-w,#smhfb-nho')) return false;
        const l = b.getAttribute('aria-label') || ''; return n instanceof RegExp ? n.test(l) : l === n; });
      await thaCamXuc(timNut, 'Cảm xúc cho thước phim', null);
      return { tt: 'ok' };
    } catch (e) { ghi('Chưa thả được cảm xúc cho thước phim: ' + e.message); return { tt: 'chua', loi: e.message }; }
  }
  // ---- (6.11) sau khi đăng video / manifest: gắn thẻ Trang "Sơn Mộc Hương" + cảm xúc (màn Chỉnh sửa thước phim) ----
  // chạy khi bài đã lên + comment xong; mỗi bài thử tối đa 4 lần (cách nhau 5–10 phút), có kiểm lại trên trang sau khi Lưu
  async function vongSuaVideo() {
    if (!CAI_DAT.SUA_VIDEO_SAU_DANG || !MAY || tamDung() || !laTabChinh() || dangBan || lay('dang_do', null) || lay('cho_tay6', null)) return false;
    const kt = kenhCuaDuong(); // (6.19) chỉ sửa bài của trang ĐANG MỞ (không chuyển trang chỉ để thả cảm xúc)
    if (document.visibilityState !== 'visible' || !kt || dangODuongSua()) return false;
    const mm = phutTrongNgay(new Date()); if (mm >= docGio(CAI_DAT.GIO_CHOT) + 60) return false;
    const s = trangThai(); const now = Date.now();
    { // video kênh 2, 3 đã rời trang của nó quá 12 phút mà chưa thả được cảm xúc → thôi (không quan trọng, không chuyển trang lại)
      const bo = LICH.filter((x) => x.kenh > 1 && x.kenh !== kt && (() => { const r = s.s[x.k]; return r && XONG.includes(r.tt) && r.link && !r.suaXong && now - (r.luc || 0) > 12 * 60000; })());
      if (bo.length) { capNhatTT((s1) => { for (const x of bo) Object.assign(ttSlot(s1, x.k), { suaXong: Date.now(), suaLoi: (s1.s[x.k].suaLoi ? s1.s[x.k].suaLoi + ' · ' : '') + 'bỏ qua cảm xúc (đã chuyển sang trang khác)' }); }); ghi(`${bo.map((x) => x.ten).join(', ')}: chưa thả được cảm xúc nhưng đã chuyển trang → bỏ qua (cảm xúc không bắt buộc)`); }
    }
    const it = LICH.find((x) => { const r = s.s[x.k]; const toiDa = (x.kenh || 1) > 1 ? CAI_DAT.KENH_SUA_TOI_DA : 4; return (x.kenh || 1) === kt && (x.loai === 'video' || x.loai === 'manifest') && r && XONG.includes(r.tt) && (r.may === MAY || ((r.may === 'tay' || r.may === 'khac') && (LA_GIAO || now - (r.luc || 0) > 30 * 60000))) && r.link && !r.suaXong && (r.suaLan || 0) < toiDa && now - (r.luc || 0) > 3 * 60000 && now >= (r.suaHen || 0); });
    if (!it) return false;
    datKenh(it.kenh);
    const laKenhPhu = (it.kenh || 1) > 1; const toiDaSua = laKenhPhu ? CAI_DAT.KENH_SUA_TOI_DA : 4; // kênh 2, 3: chỉ thả cảm xúc (không gắn thẻ), lỗi thử thêm 1 lần rồi thôi
    if (!choNhanSu('suavideo_' + it.k, laKenhPhu ? `thả cảm xúc cho ${it.ten}` : `kiểm tra / gắn thẻ ${CAI_DAT.TAG_TEN} + cảm xúc cho ${it.ten}`)) return false;
    const r = s.s[it.k]; const text = noiDungSlot(homNay(), it.k).text || '';
    const ghiSua = (o) => capNhatTT((s1) => Object.assign(ttSlot(s1, it.k), o));
    const p = { link: r.link, text, luc: r.luc };
    const timK = () => cacKhungBai().find((k) => khungKhopP(k, p));
    dangBan = true; giuKhoa(); bamNutLuc = Date.now(); // hiện thông báo ngay từ bước tìm bài
    try {
      await theoDoi('suavideo', async () => {
        ghi(`Kiểm tra thẻ ${CAI_DAT.TAG_TEN} + cảm xúc của ${it.ten}: tìm bài trên trang…`);
        let k = timK();
        for (let i = 0; i < 6 && !k; i++) { window.scrollBy(0, 900); await sleep(1500); k = timK(); if (!k) ghi(`${it.ten}: chưa thấy bài, cuộn tìm tiếp (${i + 1}/6)…`); }
        if (!k) { window.scrollTo(0, 0); ghiSua({ suaLan: (r.suaLan || 0) + 1, suaHen: now + (laKenhPhu ? 3 : 10) * 60000, suaLoi: 'chưa thấy bài trên trang' }); ghi(`${laKenhPhu ? 'Thả cảm xúc' : 'Gắn thẻ + cảm xúc'} ${it.ten}: chưa thấy bài trên trang (lần ${(r.suaLan || 0) + 1}/${toiDaSua}) → ${(r.suaLan || 0) + 1 >= toiDaSua ? 'thôi' : 'thử lại sau'}`); return; }
        const dg = baiDaGan(k);
        if (dg.du || (laKenhPhu && dg.cx)) { ghiSua({ suaXong: Date.now(), suaLoi: '' }); ghi(`${it.ten}: đã có ${laKenhPhu ? 'cảm xúc' : 'thẻ ' + CAI_DAT.TAG_TEN + ' + cảm xúc'} trên bài → không cần sửa`); return; }
        if ((r.suaLan || 0) >= 1 && r.suaDaLuu) ghi(`${it.ten}: lần trước đã Lưu nhưng trên bài chưa hiện đủ thẻ/cảm xúc → làm lại`);
        ghi(`Bắt đầu gắn thẻ "${CAI_DAT.TAG_TEN}" + cảm xúc cho ${it.ten}`);
        const d = await moManHinhSua(k, text);
        let daLuu = false;
        try {
          if (!/^Chỉnh sửa thước phim/.test(chuan(d.innerText))) { ghiSua({ suaXong: Date.now(), suaLoi: 'không phải thước phim' }); ghi(`${it.ten}: màn sửa không phải thước phim → bỏ qua`); return; }
          const c = chipsSua(d); const canThe = !laKenhPhu && !daGanThe(c), canCx = chuaCamXuc(c);
          let nhan = '';
          if (canThe) { try { await ganTheSua(); } catch (e) { if (e instanceof LoiDung) throw e; ghi(`${it.ten}: gắn thẻ chưa được (${e.message}) → vẫn gắn cảm xúc, lần sau thử thẻ lại`); } }
          if (canCx) {
            try { nhan = await camXucSua(0); }
            catch (e1) { if (e1 instanceof LoiDung || !hopSua()) throw e1; ghi('Cảm xúc lần 1 chưa xác nhận (' + e1.message + ') → thử lại lần 2'); dongBangCamXuc(); await sleep(1500); try { nhan = await camXucSua(1); } catch (e2) { if (e2 instanceof LoiDung) throw e2; ghi(`${it.ten}: cảm xúc chưa được (${e2.message})`); } }
          }
          const c2 = chipsSua(hopSua() || d);
          if ((canThe || canCx) && !(canThe && daGanThe(c2)) && !nhan) throw new Error('chưa gắn được thẻ lẫn cảm xúc');
          const nutLuu = await cho(() => { const n = nutTheoChu(hopSua() || d, 'Lưu'); return n && n.getAttribute('aria-disabled') !== 'true' ? n : null; }, 8000, 400);
          if (!nutLuu) throw new Error('nút "Lưu" không bấm được');
          nutLuu.click();
          let dong = await cho(() => !hopSua(), 12000, 500);
          if (!dong) { const n2 = nutTheoChu(hopSua() || d, 'Lưu'); if (n2) { ghi('Bấm Lưu lần 1 chưa ăn → bấm lại'); try { ganBam(n2); } catch (e) { n2.click(); } } dong = await cho(() => !hopSua(), 20000, 500); }
          if (!dong) throw new Error('đã bấm Lưu nhưng màn hình chỉnh sửa không đóng');
          daLuu = true;
          await cho(() => !dangODuongSua(), 10000); await sleep(2500);
          const k2 = timK(); const ok = k2 && (laKenhPhu ? baiDaGan(k2).cx : baiDaGan(k2).du);
          ghiSua({ suaDaLuu: Date.now(), suaLan: (r.suaLan || 0) + 1, suaHen: Date.now() + 5 * 60000, suaXong: ok ? Date.now() : 0, suaLoi: '' });
          ghi(`${it.ten}: đã lưu ${daGanThe(c2) ? 'thẻ "' + CAI_DAT.TAG_TEN + '"' : ''}${nhan ? ' + cảm xúc "' + nhan + '"' : ''}${ok ? ' — trên bài đã hiện đủ' : ' — sẽ kiểm lại trên bài sau 5 phút'}`);
        } finally { if (!daLuu) await dongManHinhSua(); }
      }, 'Đang kiểm tra / gắn thẻ + cảm xúc cho ' + it.ten);
    } catch (e) {
      const lan = (r.suaLan || 0) + 1;
      ghiSua({ suaLan: lan, suaHen: Date.now() + (laKenhPhu ? 1 : lan >= 2 ? 10 : 5) * 60000, suaLoi: e.message });
      ghi(`${laKenhPhu ? 'Thả cảm xúc' : 'Gắn thẻ + cảm xúc'} ${it.ten} lỗi (lần ${lan}/${toiDaSua}): ${e.message}${lan >= toiDaSua ? (laKenhPhu ? ' — thôi (cảm xúc không bắt buộc)' : ' — dừng, ghi vào báo cáo') : ' → thử lại sau'}`);
      if (lan >= 4 && !laKenhPhu) baoLoi(`${it.ten}: chưa gắn được thẻ ${CAI_DAT.TAG_TEN} + cảm xúc sau 4 lần (${e.message}) — cần gắn tay${r.link ? ' — ' + r.link : ''}`, 'suavid_' + it.k);
    } finally { dangBan = false; giuKhoa(); veBang(); }
    return true;
  }
  async function xuLyLoiDang(it, e) {
    const dd0 = lay('dang_do', null);
    if (e instanceof LoiTrung) { await dongHopSoan(); capNhatTT((s) => { Object.assign(ttSlot(s, it.k), { tt: 'co_san', luc: (e.p && e.p.luc) || Date.now(), id: (e.p && e.p.id) || '', link: (e.p && e.p.link) || '', may: 'khac' }); }); ghi(`${it.ten} đã có trên trang (phát hiện ngay trước khi bấm Đăng) → không đăng`); return; }
    if (dd0) { ghi(`${it.ten}: đã bấm Đăng — giữ việc dở để xác minh (${e.message})`); if (e instanceof LoiCung && !dd0.video) { dd0.buoc = 'kiem_bai'; dd0.luc = Date.now(); luu('dang_do', dd0); { const u0 = CAI_DAT.URL_TRANG; setTimeout(() => roiTrang(u0), 1500); } } return; }
    if (e instanceof LoiDung) { await dongHopSoan().catch(() => {}); capNhatTT((s) => { const x = ttSlot(s, it.k); if (x.tt === 'dang') x.tt = 'cho'; x.thuLai = Date.now() + 60000; }); ghi(`Hoãn đăng ${it.ten}: ${e.message}`); return; }
    if (e instanceof LoiLark) { capNhatTT((s) => { const x = ttSlot(s, it.k); x.tt = 'cho'; x.thuLai = Date.now() + 15 * 60000; x.loi = e.message; }); ghi(`${it.ten}: ${e.message} — thử lại sau 15 phút`); await baoLoi(`Chưa đăng được ${it.ten}: ${e.message}`, 'lark_' + it.k); return; }
    if (!e.daChup) tuChupHienTruong(`Lỗi khi đăng ${it.ten}: ${e.message}`);
    ghi(`Lỗi khi đăng ${it.ten}: ${e.message}`); chupLoi(it.ten);
    let dong = true; try { dong = await dongHopSoan(); if (dangODuongSua()) await dongManHinhSua(); } catch (e2) { /* */ }
    let vongMoi = false;
    const chot = lucPhut(docGio(CAI_DAT.GIO_CHOT));
    const s = capNhatTT((s1) => {
      const x = ttSlot(s1, it.k); x.lan = (x.lan || 0) + 1; x.loi = e.message; x.vong = x.vong || 1; x.thuLai = Date.now() + CAI_DAT.THU_LAI_PHUT * 60000; x.tt = 'cho';
      if (x.lan >= CAI_DAT.SO_LAN_THU) {
        const hen = Date.now() + CAI_DAT.NGHI_GIUA_VONG_PHUT * 60000;
        if (x.vong < CAI_DAT.SO_VONG_THU && hen < chot - 10 * 60000) { x.vong++; x.lan = 0; x.thuLai = hen; vongMoi = true; } else x.tt = 'loi';
      }
    });
    const x = s.s[it.k]; const lanTong = (x.vong - 1) * CAI_DAT.SO_LAN_THU + x.lan;
    if (x.tt === 'loi') await baoLoi(`❌ Không đăng được ${it.ten} sau ${x.vong} vòng thử (${x.vong * CAI_DAT.SO_LAN_THU} lần): ${e.message} — các bài khác vẫn đăng bình thường. Cần đăng tay (bấm Soạn hoặc Đăng lại trên popup).`, 'loi_' + it.k);
    else if (vongMoi && x.vong >= 3) await baoLoi(`🚨 ${it.ten} đã hỏng ${x.vong - 1} vòng thử (${(x.vong - 1) * CAI_DAT.SO_LAN_THU} lần, lỗi cuối: ${e.message}) → nghỉ ${CAI_DAT.NGHI_GIUA_VONG_PHUT} phút rồi thử vòng cuối ${x.vong}/${CAI_DAT.SO_VONG_THU} lúc ${gioStr(new Date(x.thuLai))} — nên vào kiểm tra máy ${TEN_MAY}; trong lúc chờ các bài khác vẫn đăng`, 'vong' + x.vong + '_' + it.k);
    else if (vongMoi) await baoLoi(`⚠️ ${it.ten} lỗi ${CAI_DAT.SO_LAN_THU} lần liền (${e.message}) → nghỉ ${CAI_DAT.NGHI_GIUA_VONG_PHUT} phút rồi thử vòng ${x.vong}/${CAI_DAT.SO_VONG_THU} lúc ${gioStr(new Date(x.thuLai))}, bước phụ lỗi sẽ được bỏ qua; trong lúc chờ các bài khác vẫn đăng`, 'vong' + x.vong + '_' + it.k);
    else await baoLoi(`⚠️ Lỗi khi đăng ${it.ten}: ${e.message} — script tự thử lại sau ${CAI_DAT.THU_LAI_PHUT} phút (lần ${lanTong + 1}, bước phụ lỗi sẽ được bỏ qua)`, 'loi1_' + it.k);
    window.__smhHuyLuot = 0;
    if (!dong || vongMoi || x.lan % 2 === 0 || e.taiLai) { if (e.taiLai) ghi(`${it.ten}: tải lại trang cho sạch rồi thử lại lúc ${gioStr(new Date(x.thuLai))}`); setTimeout(() => { if (!dangBan && !lay('dang_do', null)) roiTrang(); }, 3000); } // tải lại trang cho sạch trước lần thử sau
  }

  async function dangSlot(it, nd, thu, ngayBai) {
    const ngay = homNay(); const mai = ngayBai && ngayBai !== ngay ? ngayBai : ''; const ngayTT = mai || ngay;
    const chung = (duLieu() || {}).chung || { co: '', pool: [] };
    const can = canCmt(it, nd, chung, ngayTT);
    const cmts = can.text.map((v) => ({ k: 'text', v })).concat(can.anh.map((v) => ({ k: 'anh', v })));
    capNhatTT((s) => { ttSlot(s, it.k).can = can; }, ngayTT);
    const luiCho = () => capNhatTT((s) => { ttSlot(s, it.k).tt = 'cho'; }, ngayTT);
    const choTay = (them) => { capNhatTT((s) => { const x = ttSlot(s, it.k); if (x.tt === 'dang') x.tt = 'cho'; x.daSoan = Date.now(); x.thuLai = Date.now() + 60 * 60000; }, ngayTT); luu('cho_tay6', Object.assign({ slot: it.k, ten: it.ten + (mai ? ' (ngày mai)' : ''), loai: loaiSo[it.loai], text: nd.text, hang: nd.hang, cmts, luc: Date.now(), ngay, mai, soan: !chayThu() }, them)); thongBaoMay(`Đã soạn ${mai ? 'thử' : 'sẵn'} ${it.ten}${mai ? ' của ngày mai' : ''}`, mai ? 'Xem kỹ rồi bấm Huỷ / đóng hộp. Nếu bấm Đăng thì bài lên trang NGAY HÔM NAY và ngày mai không đăng lại.' : 'Kiểm tra rồi bấm Đăng. Sau khi đăng, script tự comment.'); };
    if (hdChay) hdChay.ten = `Đang ${thu ? 'soạn' : 'đăng'} ${it.ten}${mai ? ' (ngày mai)' : ''}`;
    ghi(`Bắt đầu ${thu ? 'soạn' : 'đăng'} ${it.ten}${mai ? ' (bài của ngày mai, soạn thử)' : ''}${thu ? ' (dừng trước nút Đăng, chờ bạn bấm Đăng)' : ''}`);
    if (it.loai === 'b1' || it.loai === 'b2' || it.loai === 'b3') {
      const files = [];
      for (let i = 0; i < (nd.anh || []).length; i++) { kiemDung(); files.push(await taiAnhKho(nd.anh[i], 'anh-' + (i + 1))); }
      if (!(await damBaoTuCach())) { luiCho(); return; }
      if (!dungTrang()) { luiCho(); veTrang(); return; }
      if (hopDangDo() || hopSoanBai()) { ghi('Có hộp đăng bài mở dở → đóng lại'); if (!(await dongHopSoan())) { luiCho(); roiTrang(); return; } }
      const bai = { ngay, hang: nd.hang, khoa: ngay + '|' + it.k, bai: nd.text, cmt: '', files,
        ddThem: { slot: it.k, loai: loaiSo[it.loai], ten: it.ten, cmts, cmtIdx: 0, soAnh: files.length, ghiChuTruoc: window.__smhBoQua || [] } };
      const soNhom = await dangLenFacebook(bai, { soanThu: thu });
      if (thu) { choTay({}); return; }
      const thay = await cho(() => timBai(nd.text), 60000, 1000);
      if (!thay) { ghi('Chưa thấy bài trên trang → tải lại để kiểm tra'); roiTrang(CAI_DAT.URL_TRANG); return; }
      ghi('B10. Đã thấy bài trên trang');
      const dd = lay('dang_do', null) || Object.assign({ ngay, hang: nd.hang, khoa: bai.khoa, bai: nd.text, soNhom }, bai.ddThem);
      await sauKhiDangSlot(dd);
      return;
    }
    // video / manifest
    const file = it.loai === 'video' ? await taiVideoKho(nd.tep) : await videoManifest(ngayTT, it.so, nd.anh, (m) => { if (hdChay) { hdChay.chi = m; hdChay.cap = Date.now(); } });
    if (!(await damBaoTuCach())) { luiCho(); return; }
    if (!dungTrang()) { luiCho(); veTrang(); return; }
    if (hopDangDo() || hopSoanBai() || ganManHinh()) { ghi('Có hộp đăng bài mở dở → đóng lại'); if (!(await dongHopSoan()) || ganManHinh()) { await dongHopVideo(); if (ganManHinh() || hopSoanBai()) { luiCho(); roiTrang(); return; } } }
    window.__smhThe = chonThe(it.loai, it.so, ngayTT); window.__smhTheDuoc = 0;
    window.__smhNhe = (it.kenh || 1) > 1; // (6.19) kênh 2, 3: vị trí / thẻ / nhóm / hình thu nhỏ lỗi → bỏ qua bước đó, vẫn đăng (đăng bài mới là chính)
    const kq = await dangVideoFb({ slot: it.k, ten: it.ten, loai: loaiSo[it.loai], text: nd.text, file, cmts, hang: nd.hang, ngay }, { soanThu: thu });
    if (thu) { choTay({ video: true }); return; }
    void kq; // việc dở 'kiem_bai' (dò bài qua Facebook) chạy tiếp ở nhịp sau
  }

  // ---------------- video / manifest: soạn thước phim → vị trí → thẻ → nhóm → hình thu nhỏ → Đăng ----------------
  const nutHopPhuChung = () => {
    const CHU = ['Lúc khác', 'Để sau', 'Không phải bây giờ', 'Không phải lúc này', 'Bỏ qua', 'Không, cảm ơn', 'Không cảm ơn', 'Đăng bài viết gốc', 'Đăng bài gốc'];
    const lop = Array.from(document.querySelectorAll('div[role="dialog"],[role="alertdialog"],[aria-modal="true"]')).filter((d) => dangHien(d) && (!/Tạo bài viết|Cài đặt thước phim|Chỉnh sửa thước phim|Cài đặt bài viết/.test(d.innerText || '') || (d.innerText || '').length < 500));
    for (const d of lop) for (const chu of CHU) { const n = Array.from(d.querySelectorAll('[role="button"],button')).filter(dangHien).find((x) => chuan(x.innerText || x.getAttribute('aria-label')) === chu); if (n) return { n, chu, hop: chuan(d.innerText).slice(0, 80) }; }
    return null;
  };
  const oMoTaVideo = () => Array.from(document.querySelectorAll('[role="dialog"] [contenteditable="true"]')).find((e) => ganThay(e) && /^Mô tả/i.test(e.getAttribute('aria-label') || ''));
  const laNutDang = (b) => !b.closest('#smhfb') && (b.getAttribute('aria-label') === 'Đăng' || chuan(b.innerText) === 'Đăng') && b.getAttribute('aria-disabled') !== 'true' && !b.disabled;
  const nutDangVideo = () => { // (6.9) nút Đăng bị cuộn khuất trong khung Cài đặt → cuộn tới rồi trả về
    const b = Array.from(document.querySelectorAll('[role="button"],button')).find((x) => ganThay(x) && laNutDang(x)); if (b) return b;
    const k = Array.from(document.querySelectorAll('[role=dialog] [role="button"],[role=dialog] button')).find((x) => laNutDang(x) && x.getClientRects().length && !x.closest('[aria-hidden="true"]'));
    if (k) { try { k.scrollIntoView({ block: 'center' }); } catch (e) { /* */ } if (ganThay(k)) return k; }
    return null;
  };
  async function dongHopVideo() {
    for (let lan = 0; lan < 4 && (ganManHinh() || hopSoanBai()); lan++) {
      const nut = Array.from(document.querySelectorAll('[aria-label="Đóng"], [aria-label="Quay lại"], [aria-label="Đóng hộp thoại của công cụ tạo"]')).find(ganThay);
      if (nut) { try { ganBam(nut); } catch (e) { nut.click(); } } else document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', code: 'Escape', keyCode: 27, which: 27, bubbles: true }));
      await sleep(1500);
      const hoi = hopThoai((d) => /Bỏ|Rời khỏi|bỏ những thay đổi|Hủy thước phim/i.test(d.innerText) && d.innerText.length < 400);
      if (hoi) { const bo = Array.from(hoi.querySelectorAll('[role="button"]')).find((b) => /^(Bỏ|Bỏ bài viết|Rời khỏi|Rời khỏi trang|Bỏ thay đổi|Hủy)$/i.test(chuan(b.innerText))); if (bo) bo.click(); await sleep(1000); }
    }
    return !ganManHinh() && !hopSoanBai();
  }
  const tenHopDung = (d) => !!d && chuan(String(d.innerText || '').replace(/\s+/g, ' ').slice(0, 400)).includes(chuan(CAI_DAT.TEN_TRANG)); // (6.9) không đếm dòng: dòng "100%" của video cũ chen vào đầu hộp
  async function choTenHop(layHop) { // hộp soạn phải đứng tên trang; mới mở có thể chưa hiện tên → đợi tối đa 8 giây
    const ok = await cho(() => tenHopDung(layHop()), 8000, 400);
    if (ok) return;
    const d = layHop(); const dau = d ? chuan(d.innerText.split('\n').slice(0, 4).join(' | ')) : '(không có hộp)';
    const e = new LoiMem('Hộp soạn bài không đứng tên ' + CAI_DAT.TEN_TRANG + ' (đang hiện: ' + dau.slice(0, 70) + ')'); e.taiLai = true; throw e;
  }
  // (6.15) mở hộp soạn bằng nhiều đường: ô "Bạn đang nghĩ gì?" (2 cách bấm) → nút "Ảnh/video" → báo lỗi để tải lại trang
  async function moHopSoanNhieuDuong(B) {
    let dlg = hopSoanBai(); if (dlg) return dlg;
    const nut = timNutSoanBai();
    if (nut) {
      nut.click(); dlg = await cho(hopSoanBai, 10000);
      if (!dlg) { const n2 = timNutSoanBai() || nut; try { ganBam(n2); } catch (e) { n2.click(); } dlg = await cho(hopSoanBai, 12000); }
      if (dlg) return dlg;
    }
    const av = Array.from(document.querySelectorAll('[role="button"]')).find((b) => (chuan(b.innerText) === 'Ảnh/video' || b.getAttribute('aria-label') === 'Ảnh/video') && !b.closest('[role="dialog"]') && !b.closest('#smhfb') && dangHien(b));
    if (av) {
      B((nut ? 'Ô "Bạn đang nghĩ gì?" không mở được hộp soạn' : 'Không thấy ô "Bạn đang nghĩ gì?"') + ' → thử nút "Ảnh/video"');
      try { ganBam(av); } catch (e) { av.click(); }
      dlg = await cho(hopSoanBai, 12000); if (dlg) return dlg;
    }
    const e = new LoiMem(nut || av ? 'Không mở được hộp soạn bài (đã thử ô "Bạn đang nghĩ gì?" và nút "Ảnh/video")' : 'Không tìm thấy ô "Bạn đang nghĩ gì?" lẫn nút "Ảnh/video" trên trang');
    e.taiLai = true; throw e;
  }
  // (6.15) chờ nút Đăng sáng lên: mỗi phút ghi tiến độ; video đứng yên ở cùng 1 mức % suốt 3 phút → làm lại (tải lại trang)
  const phanTramVideo = () => { let m = null; for (const d of document.querySelectorAll('[role="dialog"]')) { if (!dangHien(d)) continue; const r = String(d.innerText || '').match(/(^|\s)(\d{1,3})\s?%/); if (r) m = +r[2]; } return m; };
  async function choNutDangVideo(B) {
    const t0 = Date.now(); let pt = phanTramVideo(), ptLuc = Date.now(), baoLuc = Date.now();
    for (;;) {
      const nd = await cho(nutDangVideo, 1500, 500); if (nd) return nd;
      const x = nutHopPhuChung() || nutHopLa(); if (x) { B(`Facebook hiện hộp «${x.hop}» che nút Đăng → bấm "${x.chu}"`); try { ganBam(x.n); } catch (e) { x.n.click(); } await sleep(1500); }
      const p = phanTramVideo(); if (p !== pt) { pt = p; ptLuc = Date.now(); }
      if (pt !== null && pt < 100 && Date.now() - ptLuc > 180000) { const e = new LoiMem(`Video đứng yên ở ${pt}% suốt 3 phút (Facebook không xử lý tiếp)`); e.taiLai = true; throw e; }
      if (Date.now() - t0 > 240000) { const e = new LoiMem('Nút Đăng chưa bấm được sau 4 phút (Facebook có thể còn đang kiểm tra video)'); e.taiLai = true; throw e; }
      if (Date.now() - baoLuc > 60000) { baoLuc = Date.now(); B(`Chờ nút Đăng sáng lên (Facebook đang xử lý video${pt !== null ? ' · ' + pt + '%' : ''}) — đã ${Math.round((Date.now() - t0) / 60000)} phút`); }
    }
  }
  // (6.15) hộp lạ của Facebook (chưa có trong danh sách chữ quen) che hộp đăng → bấm nút X "Đóng" của chính hộp đó. KHÔNG đụng hộp hỏi Bỏ/Xoá/Rời khỏi
  const HOP_LA_DA_GHI = {};
  const nutHopLa = () => {
    const lop = Array.from(document.querySelectorAll('div[role="dialog"],[role="alertdialog"]')).filter((d) => dangHien(d) && !d.closest('#smhfb,#smhfb-nho,#smhfb-soan-w,#smhfb-gan-w,#smhfb-gan-modal'));
    for (const d of lop) {
      const tx = String(d.innerText || '');
      if (!tx.trim() || tx.length > 500 || /Tạo bài viết|Cài đặt thước phim|Chỉnh sửa thước phim|Cài đặt bài viết|Tạo thước phim/.test(tx)) continue;
      if (/Bỏ|Xóa|Xoá|Rời khỏi|bỏ những thay đổi|Hủy|Huỷ|Thanh toán|Mật khẩu/i.test(tx)) continue;
      const k = chuan(tx).slice(0, 80); if (!HOP_LA_DA_GHI[k]) { HOP_LA_DA_GHI[k] = 1; ghi(`Gặp hộp lạ của Facebook: «${k}»`); }
      const n = Array.from(d.querySelectorAll('[role="button"],button')).filter(dangHien).find((x) => x.getAttribute('aria-label') === 'Đóng' || chuan(x.innerText) === 'Đóng');
      if (n) return { n, chu: 'Đóng', hop: k };
    }
    return null;
  };
  async function dangVideoFb(v, { soanThu = false } = {}) {
    const B = (m) => ghi(`${v.ten}: ${m}`);
    kiemDung(); window.__smhMoHop = Date.now();
    window.scrollTo(0, 0); await sleep(800);
    let dlg = await moHopSoanNhieuDuong(B);
    try { await choTenHop(() => hopSoanBai() || dlg); }
    catch (eT) { // (6.15) hộp đứng sai tên → đóng hộp, chuyển sang tư cách trang, mở lại 1 lần
      if (!(eT instanceof LoiMem)) throw eT;
      B('Hộp soạn không đứng tên ' + CAI_DAT.TEN_TRANG + ' → đóng hộp, chuyển tư cách rồi mở lại');
      await dongHopVideo();
      if (!(await damBaoTuCach())) throw new LoiDung('đang chuyển sang tư cách ' + CAI_DAT.TEN_TRANG + ' — trang tải lại xong sẽ đăng tiếp');
      dlg = await moHopSoanNhieuDuong(B);
      await choTenHop(() => hopSoanBai() || dlg);
      B('Mở lại hộp soạn: đã đứng tên ' + CAI_DAT.TEN_TRANG);
    }
    await xoaAnhCu();
    const ed = () => { const d = hopSoanBai(); return d ? Array.from(d.querySelectorAll('div[contenteditable="true"][data-lexical-editor]')).pop() : null; };
    if (!(await datChu(ed(), v.text))) { await sleep(800); if (!(await datChu(ed(), v.text))) throw new LoiMem('Điền chữ mô tả chưa khớp'); }
    B('V1. Đã điền chữ mô tả (' + v.text.length + ' ký tự)');
    kiemDung();
    const d0 = hopSoanBai(); if (!d0) throw new LoiMem('Hộp soạn bài đã đóng');
    const inps = Array.from(d0.querySelectorAll('input[type="file"]'));
    const inp = inps.find((i) => /video/.test(i.accept || '')) || inps[0];
    if (!inp) throw new LoiMem('Không thấy ô chọn ảnh/video trong hộp soạn bài');
    const gan = () => { const dt = new DataTransfer(); dt.items.add(v.file); inp.files = dt.files; inp.dispatchEvent(new Event('input', { bubbles: true })); inp.dispatchEvent(new Event('change', { bubbles: true })); };
    gan();
    const coVideo = () => Array.from(document.querySelectorAll('div[role="dialog"] video')).some((x) => x.getBoundingClientRect().width > 60);
    let ok = await cho(coVideo, 60000, 1000);
    if (!ok && hopSoanBai()) { B('Facebook chưa hiện video sau 60 giây → gắn lại lần 2'); try { gan(); } catch (e) { /* */ } ok = await cho(coVideo, 90000, 1000); }
    if (!ok) { const eV = new LoiMem('Facebook chưa nhận video sau 2 lần gắn'); eV.taiLai = true; throw eV; }
    B(`V2. Đã gắn video (${(v.file.size / 1048576).toFixed(1)} MB)`);
    const bao = (m) => { if (hdChay) { hdChay.chi = v.ten + ': ' + m; hdChay.cap = Date.now(); } };
    // vị trí (trong hộp soạn) → Tiếp → màn "Chỉnh sửa thước phim"
    kiemDung();
    const phu = async (ten, fn, gocLai) => { // bước phụ: lần đầu lỗi thì báo lỗi (thử lại cả bài); từ lần thử lại thì bỏ qua bước đó, vẫn đăng
      try { return await fn(); } catch (e) { if (!thuNhe() || e instanceof LoiDung) throw e; boQuaBuoc(ten, e); try { await gocLai(); } catch (e2) { /* */ } return null; }
    };
    const thoatLop = async () => { document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', code: 'Escape', keyCode: 27, which: 27, bubbles: true })); await sleep(1200); };
    if (ganManHinh() === 'soan') { const vt = await phu('vị trí', async () => { await ganViTri(bao); return 1; }, async () => { if (ganManHinh() === 'vitri-tim') await thoatLop(); const t = ganNutTiep(); if (t) ganBamCu(t); }); if (vt) B('V3. Đã gắn vị trí ' + CAI_DAT.VI_TRI); }
    else { const t0 = ganNutTiep(); if (t0) ganBamCu(t0); }
    if (!(await ganCho(() => ganManHinh() === 'the' || ganManHinh() === 'caidat', 60000, 500))) {
      const t1 = ganNutTiep(); if (t1) { B('Chưa sang màn Chỉnh sửa thước phim → bấm Tiếp lại'); ganBam(t1); }
      if (!(await ganCho(() => ganManHinh() === 'the' || ganManHinh() === 'caidat', 60000, 500))) throw new LoiMem('Không sang được màn Chỉnh sửa thước phim');
    }
    kiemDung();
    if (ganManHinh() === 'the') { const th = await phu('thẻ', async () => { await ganThe(bao); return 1; }, async () => { const t = ganNutTiep(); if (t) ganBamCu(t); }); if (th) B('V4. Đã gắn ' + (window.__smhTheDuoc || ganDsThe().length) + ' thẻ'); }
    if (!(await ganCho(() => ganManHinh() === 'caidat', 30000, 500))) throw new LoiMem('Không sang được màn Cài đặt thước phim');
    // chữ mô tả còn không
    await sleep(1200);
    const mt = oMoTaVideo();
    if (mt && !khoaSo(mt.innerText).includes(khoaSo(v.text).slice(0, 30))) { B('Chữ mô tả bị mất khi Facebook chuyển màn → điền lại'); await datChu(mt, v.text); }
    kiemDung();
    const veCaiDat = () => ganManHinh() === 'caidat' && ![...document.querySelectorAll('input[type=checkbox]')].some((x) => x.getAttribute('role') !== 'switch' && ganThay(x));
    const n = (await phu('chọn nhóm', async () => {
      const k = await ganNhom(bao);
      if (!(await ganCho(veCaiDat, 15000, 300))) throw new LoiMem('Chưa quay lại được màn Cài đặt thước phim sau khi chọn nhóm');
      return k;
    }, async () => { const x = ganNut('Xong'); if (x) ganBamCu(x); else await thoatLop(); await ganCho(veCaiDat, 8000, 300); })) || { tong: 0 };
    if (!veCaiDat() && !(await ganCho(veCaiDat, 8000, 300))) throw new LoiMem('Chưa quay lại được màn Cài đặt thước phim');
    if (n.tong) B('V5. Đã chọn ' + n.tong + ' nhóm');
    kiemDung();
    { const tn = await phu('hình thu nhỏ', () => ganThuNho(bao), async () => { const l = ganNutLuuAnh(); if (l) ganBamCu(l); else if (ganManHinh() !== 'caidat') await thoatLop(); await ganCho(veCaiDat, 15000, 300); }); B(tn === null ? 'V6. Bỏ qua hình thu nhỏ — giữ hình mặc định' : 'V6. Đã chọn hình thu nhỏ là khung hình đầu'); }
    kiemDung();
    const nd = await choNutDangVideo(B);
    if (soanThu) { nd.style.outline = '4px solid #f7b928'; nd.style.outlineOffset = '2px'; B('đã soạn xong, dừng trước nút "Đăng" — bấm Đăng tay, script sẽ comment tiếp'); return -1; }
    if (coApi()) {
      let trung = null;
      try { const tu = new Date(new Date().setHours(0, 0, 0, 0)).getTime(); trung = baiKhop((await baiTrenTrangApi(tu)).filter((p) => p.luc >= tu && laVideoApi(p) !== false), v.text); } catch (e) { B('Dò trùng lần cuối lỗi (' + e.message + ') → vẫn đăng'); }
      if (trung) { await dongHopVideo(); throw new LoiTrung('Bài đã có trên trang ngay trước khi bấm Đăng', trung); }
    }
    kiemDung();
    luu('dang_do', { video: true, slot: v.slot, loai: v.loai, ten: v.ten, ngay: v.ngay, hang: v.hang, khoa: v.ngay + '|' + v.slot, bai: v.text, luc: Date.now(), buoc: 'kiem_bai', cmts: v.cmts, cmtIdx: 0, soAnh: 0, ghiChuTruoc: (window.__smhBoQua || []).map((t) => 'bỏ qua bước ' + t + ' (lần thử lại)'), soNhom: n.tong, ngoai: true });
    try { ganBamCu(nd); } catch (e) { nd.click(); }
    B('V7. Đã bấm Đăng');
    let lucPhu = 0;
    const daDong = () => { const x = nutHopPhuChung() || nutHopLa(); if (x && Date.now() - lucPhu > 2500) { lucPhu = Date.now(); ghi(`${v.ten}: Facebook hiện hộp «${x.hop}» → bấm "${x.chu}"`); try { ganBam(x.n); } catch (e) { x.n.click(); } } return !ganManHinh() && !hopSoanBai(); };
    let dong = await cho(daDong, 60000, 800);
    if (!dong) { const n2 = nutDangVideo(); if (n2) { B('Bấm Đăng lần 1 chưa ăn → bấm lại'); try { ganBam(n2); } catch (e) { n2.click(); } } dong = await cho(daDong, 60000, 1000); }
    if (!dong && nutDangVideo()) { // (6.15) bấm 2 lần mà hộp vẫn mở, nút Đăng vẫn còn → nhịp sau hỏi Facebook ngay, chưa có bài thì đóng hộp + tải lại + đăng lại
      const dd2 = lay('dang_do', null); if (dd2 && dd2.slot === v.slot) { dd2.khongAn = Date.now(); luu('dang_do', dd2); }
      B('V8. Bấm Đăng 2 lần không ăn (hộp vẫn mở, nút Đăng vẫn còn) → hỏi Facebook xem bài đã lên chưa; chưa có thì tải lại trang và đăng lại');
    } else B(dong ? 'V8. Hộp đăng thước phim đã đóng — chờ Facebook xử lý video' : 'V8. Hộp đăng thước phim chưa đóng sau ~2 phút — sẽ dò trên trang');
    return n.tong;
  }

  // =====================================================================
  //  SAU KHI ĐĂNG: ghi nhận → (sửa nền đỏ Bài 2) → comment → kiểm qua Facebook
  // =====================================================================
  async function sauKhiDangSlot(dd) {
    const s0 = trangThai(); const r0 = s0.s[dd.slot] || {};
    const coLoiTruoc = !!r0.loi;
    capNhatTT((s) => { Object.assign(ttSlot(s, dd.slot), { tt: 'xong', luc: dd.lucApi || Date.now(), may: MAY, link: dd.link || r0.link || '', id: dd.id || r0.id || '', kiem: [], loi: '', daSoan: 0 }); });
    luu('bai_cuoi6', Date.now());
    ghi(`Đã đăng ${dd.ten} lúc ${gioStr(new Date())}`);
    if (coLoiTruoc) baoLoi(`✅ ${dd.ten} đã đăng được lúc ${gioStr(new Date())} (sau lỗi trước đó)`, 'hoi_' + dd.slot);
    Object.assign(dd, { buoc: 'cho_binh_luan', luc: Date.now(), lucDang: gioStr(new Date()), cmtIdx: dd.cmtIdx || 0 });
    const canSuaNen = dd.loai === 2 && CAI_DAT.SUA_NEN_B2 !== false;
    if ((!dd.cmts || !dd.cmts.length) && !canSuaNen) { await hoanTatSlot(dd, dd.ghiChuTruoc || []); return; }
    dd.cmts = dd.cmts || [];
    luu('dang_do', dd);
    ghi(dd.cmts.length ? 'Chờ vài giây rồi tải lại trang để comment' : 'Chờ vài giây rồi tải lại trang để sửa nền đỏ');
    await sleep(2500);
    if (dd.viaLink) roiTrang(dd.viaLink); else roiTrang();
  }
  // video: đã thấy bài → ghi "ĐÃ ĐĂNG" (cột J) + link (cột B) vào đúng hàng — gộp 1 lượt ghi
  async function ghiKetQuaVideo(dd) {
    if (dd.loai !== 4 || !dd.hang || !dd.link) return;
    const c = kenhCua(dd.slot);
    if (c > 1) { // (6.19) kênh 2, 3: Trạng thái → "ĐÃ ĐĂNG", link bài → cột J
      const cfg = CAI_DAT.KENH[c]; const L = (i) => String.fromCharCode(65 + i);
      try {
        let hang = dd.hang; const r = (await docBang(cfg.tab, `A${hang}:J${hang}`))[0] || [];
        if (khoaSo(chuO(r[cfg.cot.cap])).slice(0, 40) !== khoaSo(dd.bai).slice(0, 40)) {
          const v = await docBang(cfg.tab, 'A1:J3000'); hang = 0;
          for (let i = 1; i < v.length; i++) if (khoaSo(chuO((v[i] || [])[cfg.cot.cap])).slice(0, 40) === khoaSo(dd.bai).slice(0, 40)) { hang = i + 1; break; }
          if (!hang) throw new Error(`không còn thấy hàng có caption của video trong tab "${cfg.tenTab}"`);
        }
        await ghiNhieuO(cfg.tab, [[L(cfg.cot.tt) + hang, 'ĐÃ ĐĂNG'], [L(cfg.cot.link) + hang, dd.link]]);
        ghi(`${dd.ten}: đã ghi "ĐÃ ĐĂNG" (ô ${L(cfg.cot.tt)}${hang}) và link (ô ${L(cfg.cot.link)}${hang}) vào tab "${cfg.tenTab}"`);
      } catch (e) { ghi(`${dd.ten}: chưa ghi được kết quả vào sheet (${e.message})`); baoLoi(`${dd.ten} đã đăng nhưng chưa ghi được "ĐÃ ĐĂNG"/link vào tab "${cfg.tenTab}" (${e.message}) — link: ${dd.link}`, 'ghij_' + dd.slot); }
      return;
    }
    try {
      const tab = CAI_DAT.TAB_VIDEO; let hang = dd.hang;
      const r = (await docBang(tab, `A${hang}:N${hang}`))[0] || [];
      if (khoaSo(chuO(r[4])).slice(0, 40) !== khoaSo(dd.bai).slice(0, 40)) {
        const v = await docBang(tab, 'A1:N3000'); hang = 0;
        for (let i = 1; i < v.length; i++) if (khoaSo(chuO((v[i] || [])[4])).slice(0, 40) === khoaSo(dd.bai).slice(0, 40)) { hang = i + 1; break; }
        if (!hang) throw new Error('không còn thấy hàng có chữ của video trong tab Kênh 1');
      }
      await ghiNhieuO(tab, [['J' + hang, 'ĐÃ ĐĂNG'], ['B' + hang, dd.link]]);
      ghi(`${dd.ten}: đã ghi "ĐÃ ĐĂNG" (ô J${hang}) và link (ô B${hang}) vào sheet`);
    } catch (e) { ghi(`${dd.ten}: chưa ghi được kết quả vào sheet (${e.message})`); baoLoi(`${dd.ten} đã đăng nhưng chưa ghi được "ĐÃ ĐĂNG"/link vào sheet (${e.message}) — link: ${dd.link}`, 'ghij_' + dd.slot); }
  }

  async function xuLyDangDo() {
    const dd = lay('dang_do', null);
    if (!dd) return false;
    dangBan = true; giuKhoa();
    try { return await xuLyDangDo2(dd); } finally { dangBan = false; giuKhoa(); }
  }
  async function xuLyDangDo2(dd) {
    datKenh(kenhCua(dd.slot)); // (6.19) việc dở thuộc kênh nào thì tư cách / trang / dò bài theo kênh đó
    if ((hopDangDo() || hopSoanBai() || dangODuongSua()) && nguoiDangThaoTac()) return true;
    if (!laTabChinh()) return true;
    if (dd.ngay !== homNay() && Date.now() - dd.luc > 6 * 3600e3) { luu('dang_do', null); ghi('Bỏ việc dở của ngày cũ'); return false; }
    if (tamDung() && dd.buoc !== 'kiem_bai') return true;
    // video / manifest vừa bấm Đăng: dò qua Facebook đến khi thấy bài (không cần tab hiện)
    if (dd.video && dd.buoc === 'kiem_bai') {
      // (6.15) hỏi Facebook ở các mốc 1-2-3-5-8-12-16-20 phút sau khi bấm Đăng (nhẹ, không hỏi liên tục); bấm Đăng 2 lần không ăn thì hỏi ngay
      const phut = (Date.now() - dd.luc) / 60000;
      const moc = [1, 2, 3, 5, 8, 12, 16, 20].filter((m) => phut >= m).length;
      const gap = dd.khongAn && !dd.khongAnDaHoi;
      if (!gap && (moc <= (dd.mocDo || 0) || Date.now() - (dd.lanDo || 0) < 20000)) return true;
      dd.mocDo = moc; dd.lanDo = Date.now(); if (gap) dd.khongAnDaHoi = Date.now(); luu('dang_do', dd);
      let p = null, hoiDuoc = false;
      try {
        const ds = await baiTrenTrangApi(dd.luc - 10 * 60000); hoiDuoc = true;
        p = baiKhop(ds.filter((x) => x.luc >= dd.luc - 10 * 60000 && laVideoApi(x) !== false), dd.bai);
        if (!p) { dd.apiKhong = (dd.apiKhong || 0) + 1; luu('dang_do', dd); }
      } catch (e) { ghi(`${dd.ten}: dò bài qua Facebook lỗi (${e.message})`); }
      if (p) {
        Object.assign(dd, { id: p.id, link: p.link, lucApi: p.luc, viaLink: p.link || '' });
        ghi(`${dd.ten}: Facebook xác nhận đã lên trang lúc ${gioStr(new Date(p.luc))}`);
        if (ganManHinh() || hopSoanBai()) await dongHopVideo().catch(() => {});
        await ghiKetQuaVideo(dd);
        await sauKhiDangSlot(dd); return true;
      }
      // (6.19) chưa có mã khoá đọc được trang này (kênh 2, 3 khi mã đang cài là mã riêng của trang kênh 1) → xác nhận bằng cách nhìn trang
      if (!coApi() && document.visibilityState === 'visible' && phut >= 1 && !(ganManHinh() || hopSoanBai())) {
        if (!dungTrang()) { veTrang(); return true; }
        const kh = cacKhungBai().find((x) => khungKhop(x, dd.bai));
        if (kh) {
          const a = Array.from(kh.khung.querySelectorAll('a[href]')).map((x) => x.href).find((h) => /\/(reel|videos)\//.test(h)) || '';
          Object.assign(dd, { link: a.replace(/[?#].*$/, '').replace(/\/+$/, ''), viaLink: a, lucApi: Date.now() });
          ghi(`${dd.ten}: thấy bài trên trang ${CAI_DAT.TEN_NGAN} (mã khoá chưa đọc được trang này nên xác nhận bằng cách nhìn trang)`);
          await ghiKetQuaVideo(dd); await sauKhiDangSlot(dd); return true;
        }
        if (Date.now() - (dd.taiLaiLuc || 0) > 2 * 60000) { dd.taiLaiLuc = Date.now(); luu('dang_do', dd); ghi(`${dd.ten}: chưa thấy bài trên trang → tải lại trang xem lại`); roiTrang(); return true; }
      }
      // hộp đăng vẫn mở + nút Đăng vẫn còn = Facebook chưa nhận lệnh Đăng → đóng hộp, tải lại trang, đăng lại (tính 1 lần thử; trước khi bấm Đăng lần sau vẫn dò trùng)
      const hopCon = !!(ganManHinh() || hopSoanBai()) && !!nutDangVideo();
      if (hopCon && document.visibilityState === 'visible') { const x = nutHopPhuChung() || nutHopLa(); if (x) { ghi(`${dd.ten}: hộp «${x.hop}» đang che hộp đăng → bấm "${x.chu}"`); try { ganBam(x.n); } catch (e) { x.n.click(); } await sleep(2500); } }
      if (hopCon && document.visibilityState === 'visible' && (dd.khongAn || phut >= 3) && (hoiDuoc || !coApi())) {
        ghi(`${dd.ten}: đã ${Math.max(1, Math.round(phut))} phút mà hộp đăng vẫn mở, nút Đăng vẫn còn${hoiDuoc ? ', Facebook chưa có bài' : ''} → bấm Đăng không ăn: đóng hộp, tải lại trang rồi đăng lại`);
        tuChupHienTruong(`${dd.ten}: bấm Đăng nhưng Facebook không nhận (hộp đăng vẫn mở sau ${Math.round(phut)} phút)`);
        luu('dang_do', null);
        await dongHopVideo().catch(() => {});
        const eK = new LoiMem('bấm Đăng nhưng Facebook không nhận (hộp đăng vẫn mở)'); eK.taiLai = true; eK.daChup = true;
        await xuLyLoiDang({ k: dd.slot, ten: dd.ten }, eK);
        return true;
      }
      const hanPhut = coApi() ? CAI_DAT.CHO_VIDEO_XU_LY_PHUT : CAI_DAT.CHO_VIDEO_LEN_PHUT;
      if (coApi() && !hopCon && phut >= hanPhut && (dd.apiKhong || 0) >= 3) {
        ghi(`${dd.ten}: hộp đăng đã đóng nhưng sau ${hanPhut} phút Facebook vẫn không có bài → coi như chưa lên, đăng lại (trước khi bấm Đăng sẽ dò trùng lần nữa)`);
        luu('dang_do', null); chupLoi(dd.ten);
        if (ganManHinh() || hopSoanBai()) await dongHopVideo().catch(() => {});
        await xuLyLoiDang({ k: dd.slot, ten: dd.ten }, new LoiMem(`đã bấm Đăng nhưng sau ${hanPhut} phút Facebook vẫn không có bài`));
        return true;
      }
      if (phut >= hanPhut) {
        luu('dang_do', null);
        capNhatTT((s) => { Object.assign(ttSlot(s, dd.slot), { tt: 'khong_ro', luc: dd.luc, lyDo: `đã bấm Đăng nhưng sau ${hanPhut} phút Facebook vẫn chưa thấy bài` }); });
        ghi(`${dd.ten}: đã bấm Đăng nhưng sau ${hanPhut} phút chưa thấy bài trên trang — không đăng lại để tránh trùng`); chupLoi(dd.ten);
        await baoLoi(`❓ ${dd.ten}: đã bấm Đăng nhưng sau ${hanPhut} phút chưa thấy bài trên trang${coApi() ? ' (chưa hỏi được Facebook)' : ' (chưa cài mã khoá)'} — script KHÔNG đăng lại (tránh trùng), cần vào trang kiểm tra`, 'kr_' + dd.slot);
        if (ganManHinh() || hopSoanBai()) await dongHopVideo().catch(() => {});
      }
      return true;
    }
    if (document.visibilityState !== 'visible') { choTabAn(dd.ten || 'bài đang làm dở'); return true; }
    hetChoTabAn();
    if (!dungTrang() && !(dd.viaLink && /(^|\.)facebook\.com$/.test(location.hostname))) { veTrang(); return true; }
    if (dd.buoc === 'kiem_bai') { // bài chữ/ảnh: vừa bấm Đăng thì trang tải lại
      dd.kiemLan = (dd.kiemLan || 0) + 1; luu('dang_do', dd);
      const thay = await cho(() => timBai(dd.bai), 30000, 1000);
      if (thay) { await sauKhiDangSlot(dd); return true; }
      if (coApi()) {
        try {
          const p = baiKhop(await baiTrenTrangApi(dd.luc - 10 * 60000), dd.bai);
          if (p) { ghi(`Facebook (API) xác nhận ${dd.ten} đã lên (trang chưa hiện) → tiếp tục comment`); Object.assign(dd, { id: p.id, link: p.link, lucApi: p.luc }); await sauKhiDangSlot(dd); return true; }
          dd.apiKhong = (dd.apiKhong || 0) + 1; luu('dang_do', dd);
        } catch (e) { ghi('Kiểm bài qua API lỗi: ' + e.message); }
      }
      if (dd.kiemLan === 2 || dd.kiemLan === 4 || dd.kiemLan === 8) { ghi(`Chưa thấy ${dd.ten} vừa đăng → tải lại trang kiểm tra lần nữa`); roiTrang(); return true; }
      if (dd.kiemLan >= 6 && coApi() && (dd.apiKhong || 0) < 4 && dd.kiemLan < 12) return true;
      if (dd.kiemLan >= 6) {
        luu('dang_do', null);
        if (coApi() && (dd.apiKhong || 0) >= 4) {
          const s = capNhatTT((s1) => { const x = ttSlot(s1, dd.slot); x.lan = (x.lan || 0) + 1; x.tt = x.lan >= CAI_DAT.SO_LAN_THU ? 'loi' : 'cho'; x.thuLai = Date.now(); x.loi = 'đã bấm Đăng nhưng bài không lên trang'; });
          ghi(`Đã bấm Đăng ${dd.ten} nhưng kiểm nhiều lần vẫn không có bài → coi như chưa đăng${s.s[dd.slot].tt === 'loi' ? ' (đã thử đủ số lần — bỏ qua)' : ', sẽ tự đăng lại (có dò trùng trước khi bấm Đăng)'}`);
          if (s.s[dd.slot].tt === 'loi') await baoLoi(`❌ ${dd.ten}: bấm Đăng ${s.s[dd.slot].lan} lần nhưng bài không lên trang — đã bỏ qua`, 'loi_' + dd.slot);
        } else {
          capNhatTT((s1) => { Object.assign(ttSlot(s1, dd.slot), { tt: 'khong_ro', luc: dd.luc, lyDo: 'đã bấm Đăng nhưng không thấy bài trên trang' }); });
          await baoLoi(`❓ ${dd.ten}: đã bấm Đăng nhưng không thấy bài trên trang${coApi() ? '' : ' (chưa cài mã khoá)'} — script không đăng lại để tránh trùng, cần vào trang kiểm tra`, 'kr_' + dd.slot);
        }
      }
      return true;
    }
    if (dd.buoc === 'cho_binh_luan' || dd.buoc === 'dang_binh_luan') return chayComment(dd);
    return false;
  }
  // Facebook cho biết comment đã đủ chưa
  async function kiemCmtApi(id, can) {
    const cs = await cmtChiTietApi(id);
    const thieuText = (can.text || []).filter((t) => !cs.msgs.some((c) => khopCmt(c, t)));
    const thieuAnh = Math.max(0, (can.anh || []).length - cs.anh);
    return { ok: !thieuText.length && !thieuAnh, thieuText, thieuAnh, anhCo: cs.anh };
  }
  async function hoanTatSlot(dd, ghiChu = []) {
    if (dd.raSoat) { await hoanTatRaSoat(dd, [...new Set((dd.ghiChuTruoc || []).concat(ghiChu))]); return; }
    if (await lenLaiCmtThieu(dd)) return;
    ghiChu = [...new Set((dd.ghiChuTruoc || []).concat(dd.ghiChuLan1 || [], ghiChu))];
    let id = dd.id || '', link = dd.link || '', kq = null;
    const can = (trangThai().s[dd.slot] || {}).can || { text: (dd.cmtsGoc || dd.cmts || []).filter((x) => x.k === 'text').map((x) => x.v), anh: (dd.cmtsGoc || dd.cmts || []).filter((x) => x.k === 'anh').map((x) => x.v) };
    if (coApi()) {
      for (let lan = 0; lan < 3; lan++) {
        if (lan) await sleepThat(10000);
        try {
          if (!id) { const p = baiKhop(await baiTrenTrangApi(Date.now() - 864e5), dd.bai); if (!p) continue; id = p.id; link = p.link || link; }
          kq = await kiemCmtApi(id, can); if (kq.ok) break;
        } catch (e) { ghi('Không xác nhận được comment qua API: ' + e.message); break; }
      }
    }
    capNhatTT((s) => {
      const r = ttSlot(s, dd.slot);
      Object.assign(r, { id: id || r.id || '', link: link || r.link || '', ghiChu, soNhom: dd.soNhom || r.soNhom || 0 });
      r.kiem = (r.kiem || []).concat(kq ? [{ luc: Date.now(), ok: kq.ok }] : []);
      r.cmtOk = !!(kq && kq.ok);
    });
    luu('dang_do', null);
    if (dd.viaLink) { const kv = KENH_HT; setTimeout(() => { if (!dangBan && !lay('dang_do', null)) { datKenh(kv); veTrang(); } }, 4000); } // (6.19) về đúng trang của kênh vừa làm
    ghi(kq && kq.ok ? `Xong ${dd.ten}: đã đủ comment (Facebook xác nhận)` : `Xong ${dd.ten}${kq ? `: Facebook thấy còn thiếu ${kq.thieuText.length ? 'comment chữ' : ''}${kq.thieuText.length && kq.thieuAnh ? ' + ' : ''}${kq.thieuAnh ? kq.thieuAnh + ' comment ảnh' : ''} — lượt kiểm sau 10 phút sẽ gửi bù` : ' (chưa kiểm được comment — lượt kiểm sau sẽ xem lại)'}${ghiChu.length ? ' · lưu ý: ' + ghiChu.join('; ') : ''}`);
  }

  // =====================================================================
  //  KIỂM COMMENT: ngay sau đăng (~2 phút), 10 phút, 20 phút (tối đa 3 lần/bài) + 1 lượt 19:00
  // =====================================================================
  function mucKiem(s = trangThai()) { // các bài máy này lo comment
    const out = [];
    for (const it of LICH) {
      const r = s.s[it.k]; if (!r || !XONG.includes(r.tt) || !r.id) continue;
      if (r.may === 'CAO' ? !LA_CAO : r.may === 'GIAO' ? !LA_GIAO : false) continue; // máy nào đăng thì máy đó lo; bài máy khác/đăng tay → cả 2 máy (Máy Cao chậm hơn 30 phút)
      out.push({ key: it.k, ten: it.ten, r, laSlot: true });
    }
    for (const id of Object.keys(s.ngoai)) { const r = s.ngoai[id]; if (!r.id) continue; out.push({ key: 'n|' + id, ten: r.ten ? r.ten + ' (đăng trước)' : 'bài đăng tay ' + gioStr(new Date(r.luc)), r, laSlot: false }); }
    return out;
  }
  function luuKiem(key, f) { capNhatTT((s) => { const r = key.startsWith('n|') ? s.ngoai[key.slice(2)] : s.s[key]; if (r) f(r); }); }
  async function vongKiemCmt() {
    if (!MAY || tamDung() || !laTabChinh() || dangBan || lay('dang_do', null) || !coApi()) return false;
    const now = Date.now(); const mm = phutTrongNgay(new Date()); const cuoi = docGio(CAI_DAT.GIO_KIEM_CMT_CUOI);
    // hàng đợi gửi bù do bấm tay
    const hang = lay('hang_bu6', []) || [];
    let t = null;
    for (const m of mucKiem()) {
      const r = m.r; if (r.cmtOk) continue; const n = (r.kiem || []).length;
      if (m.laSlot && !coApiKenh(kenhCua(m.key))) continue; // (6.19) kênh chưa có mã khoá đọc được trang → không kiểm qua Facebook được
      const moc = CAI_DAT.KIEM_CMT_SAU_PHUT[n];
      const khac = m.r.may === 'khac' || !m.laSlot; // bài máy khác / đăng tay: bắt đầu kiểm từ 10 phút (để máy kia comment xong trước)
      const tre = khac ? (LA_CAO ? 30 : 10) : 0; // Máy Cao kiểm bài máy khác chậm hơn để Máy Giao làm trước, tránh 2 máy cùng gửi bù
      if (n < CAI_DAT.KIEM_CMT_TOI_DA && moc != null && now >= r.luc + (moc + tre) * 60000) { t = m; break; }
      if (mm >= cuoi + (khac && LA_CAO ? 30 : 0) && !r.kiem19 && now - r.luc > 10 * 60000) { t = Object.assign({ cuoi: true }, m); break; }
    }
    if (!t && hang.length) { const h = hang[0]; const m = mucKiem().find((x) => x.key === h.key); luu('hang_bu6', hang.slice(1)); if (m && !m.r.cmtOk) t = Object.assign({ tay: true }, m); }
    if (!t) return false;
    datKenh(t.laSlot ? kenhCua(t.key) : 1);
    const r = t.r; const can = r.can || canCmt({ loai: 'video' }, {});
    let kq;
    try { kq = await kiemCmtApi(r.id, can); } catch (e) { ghi(`Kiểm comment ${t.ten}: chưa đọc được (${e.message})`); luuKiem(t.key, (x) => { x.kiem = (x.kiem || []).concat([{ luc: Date.now(), loi: true }]); if (t.cuoi) x.kiem19 = Date.now(); }); return false; }
    luuKiem(t.key, (x) => { x.kiem = (x.kiem || []).concat([{ luc: Date.now(), ok: kq.ok, tay: !!t.tay }]); x.cmtOk = kq.ok; if (t.cuoi) x.kiem19 = Date.now(); });
    ghi(`Kiểm comment ${t.ten} (lần ${(r.kiem || []).length + 1}${t.cuoi ? ', lượt 19:00' : t.tay ? ', bấm tay' : ''}): ${kq.ok ? 'đủ' : `thiếu ${kq.thieuText.length ? 'comment chữ' : ''}${kq.thieuText.length && kq.thieuAnh ? ' + ' : ''}${kq.thieuAnh ? kq.thieuAnh + ' ảnh' : ''}`}`);
    if (kq.ok) return true;
    if ((r.guiBu || 0) >= CAI_DAT.GUI_BU_TOI_DA) { await baoLoi(`${t.ten}: đã gửi bù ${r.guiBu} lần vẫn thiếu comment — cần comment tay${r.link ? ' — ' + r.link : ''}`, 'bu_' + t.key); return true; }
    if (!tuDong() && !t.tay) return true;
    // gửi bù: cần chạm vào trang → chờ nhân sự rảnh + đếm ngược
    if (!t.tay && (dangHoan() || !choNhanSu('bu_' + t.key, `gửi bù comment cho ${t.ten}`))) { luuKiem(t.key, (x) => { x.kiem.pop(); }); return false; }
    const cmts = kq.thieuText.map((v) => ({ k: 'text', v }));
    const anhCan = can.anh || []; anhCan.slice(Math.max(0, anhCan.length - kq.thieuAnh)).forEach((v) => cmts.push({ k: 'anh', v }));
    if (!cmts.length) return true;
    if (!t.tay) { const k2 = await batDemNguoc('gửi bù comment ' + t.ten); if (k2 !== 'ok') { luuKiem(t.key, (x) => { x.kiem.pop(); }); return false; } }
    luuKiem(t.key, (x) => { x.guiBu = (x.guiBu || 0) + 1; });
    let text = r.text || ''; let lk = r.link;
    if (t.laSlot) { const nd = noiDungSlot(homNay(), t.key); text = nd.text || text; }
    const dd = { loai: 9, slot: t.key, ten: t.ten, ngay: homNay(), hang: 0, khoa: homNay() + '|rs|' + t.key, bai: text, id: r.id, link: lk || '', cmts, cmtIdx: 0, soAnh: 0, ghiChuTruoc: [], luc: Date.now(), buoc: 'cho_binh_luan', raSoat: true, rsKey: t.key, anhCoSan: kq.anhCo, daThaBai: true, daSuaNen: true, camXucCmt: { tt: 'bo' }, suaLan: 1, ngoai: true };
    if (lk && /^https?:/.test(lk)) dd.viaLink = lk;
    luu('dang_do', dd);
    ghi(`Gửi bù comment cho ${t.ten} (${cmts.length} comment) — mở thẳng bài để thấy bài mới nhất`);
    await sleep(1200);
    if (dd.viaLink) roiTrang(dd.viaLink); else roiTrang();
    return true;
  }
  async function hoanTatRaSoat(dd, ghiChu) {
    let kq = null;
    const m = mucKiem().find((x) => x.key === dd.rsKey); const can = (m && m.r.can) || { text: [], anh: [] };
    if (coApi() && dd.id) for (let lan = 0; lan < 2; lan++) { if (lan) await sleepThat(10000); try { kq = await kiemCmtApi(dd.id, can); if (kq.ok) break; } catch (e) { break; } }
    luuKiem(dd.rsKey, (x) => { if (kq) x.cmtOk = kq.ok; });
    luu('dang_do', null);
    if (dd.viaLink) { const kv = KENH_HT; setTimeout(() => { if (!dangBan && !lay('dang_do', null)) { datKenh(kv); veTrang(); } }, 4000); } // (6.19) về đúng trang của kênh vừa làm
    ghi(kq && kq.ok ? `Gửi bù xong: ${dd.ten} đã đủ comment` : `Gửi bù cho ${dd.ten} xong nhưng chưa xác nhận đủ${ghiChu.length ? ' — ' + ghiChu.join('; ') : ''}`);
  }
  // bấm tay: kiểm comment bài mới nhất / 3 bài gần nhất / video trong 24 giờ qua (luôn hỏi Facebook danh sách mới nhất)
  async function kiemTay(kieu) {
    if (!coApi()) { ghi('Kiểm comment: chưa cài mã khoá Facebook'); return; }
    await doTrang('bấm kiểm comment');
    let ds;
    try { ds = await baiTrenTrangApi(Date.now() - 24 * 3600e3); } catch (e) { ghi('Kiểm comment: chưa đọc được bài trên trang (' + e.message + ')'); return; }
    const s = trangThai(); const theoId = {};
    for (const m of mucKiem(s)) theoId[m.r.id] = m;
    const tu = new Date(new Date().setHours(0, 0, 0, 0)).getTime();
    let chon = ds.slice().sort((a, b) => b.luc - a.luc);
    if (kieu === 'kiem24') chon = chon.filter((p) => laVideoApi(p) === true || /#manifest/i.test(p.text || ''));
    else chon = chon.filter((p) => p.luc >= tu).slice(0, kieu === 'kiem1' ? 1 : 3);
    // bài video trong 24h (cả hôm qua) chưa có trong danh sách → thêm vào "bài đăng tay" để kiểm
    capNhatTT((s1) => { for (const p of chon) if (!theoId[p.id] && !s1.ngoai[p.id] && (laVideoApi(p) === true || /#manifest/i.test(p.text || ''))) s1.ngoai[p.id] = { luc: p.luc, id: p.id, link: p.link || '', text: String(p.text || '').slice(0, 300), kiem: [], can: canCmt({ loai: 'video' }, {}) }; });
    const muc = mucKiem(); const ketQua = []; const can = [];
    for (const p of chon) {
      const m = muc.find((x) => x.r.id === p.id);
      if (!m) { ketQua.push(`${gioStr(new Date(p.luc))} bài chữ không thuộc lịch hôm nay → bỏ qua`); continue; }
      if (m.r.cmtOk) { ketQua.push(`${m.ten}: đã đủ comment`); continue; }
      can.push({ key: m.key });
      ketQua.push(`${m.ten}: sẽ kiểm${(m.r.kiem || []).length >= CAI_DAT.KIEM_CMT_TOI_DA ? ' (đã kiểm ' + m.r.kiem.length + ' lần, bấm tay vẫn kiểm)' : ''}`);
    }
    luu('hang_bu6', (lay('hang_bu6', []) || []).concat(can.filter((x) => !(lay('hang_bu6', []) || []).some((y) => y.key === x.key))));
    ghi(`Kiểm comment (${kieu === 'kiem1' ? 'bài mới nhất' : kieu === 'kiem3' ? '3 bài gần nhất' : 'video trong 24 giờ qua'}): ${ketQua.join(' · ') || 'không có bài nào'}`);
  }

  // =====================================================================
  //  CHẠY THỬ: script soạn sẵn rồi dừng trước nút Đăng → người bấm Đăng → script comment tiếp
  // =====================================================================
  let hopThayTrangNay = false, hopMatTuLuc = 0; // trạng thái hộp soạn kể từ lúc tải trang này (không lưu, F5 là về 0)
  async function tiepChoTay() {
    const p = lay('cho_tay6', null); if (!p) return false;
    if (!laTabChinh() || tamDung() || lay('dang_do', null) || dangBan) return true;
    if (p.ngay !== homNay()) { luu('cho_tay6', null); return true; }
    const hopMo = hopDangDo() || hopSoanBai() || ganManHinh();
    if (hopMo) hopThayTrangNay = true; // (6.8) tính theo lần tải trang này: F5 xong mà không còn hộp → 45 giây là bỏ
    if (hopMo) {
      if (Date.now() - p.luc > 45 * 60000) { luu('cho_tay6', null); capNhatTT((s) => { Object.assign(ttSlot(s, p.slot), p.soan ? { tt: 'cho', thuLai: p.mai ? 0 : Date.now() + 15 * 60000, daSoan: 0 } : { tt: 'bo', lyDo: 'chạy thử: quá 45 phút chưa bấm Đăng' }); }, p.mai || homNay()); ghi(`${p.ten} ${p.soan ? 'đã soạn' : 'chạy thử'}: quá 45 phút chưa bấm Đăng → ${p.soan ? 'để lại hàng chờ' : 'bỏ lượt này'}`); }
      return true;
    }
    if (!p.dongLuc) { p.dongLuc = Date.now(); luu('cho_tay6', p); }
    if (Date.now() - (p.doLuc || 0) < 15000) return true;
    p.doLuc = Date.now(); luu('cho_tay6', p);
    let thay = null;
    if (!p.video && !p.mai) { const x = timBai(p.text); if (x) thay = { link: linkBai(x.khung), id: '' }; }
    if (!thay && coApi()) { try { const q = baiKhop(await baiTrenTrangApi(p.luc - 5 * 60000), p.text); if (q) thay = q; } catch (e) { /* */ } }
    if (!thay && p.mai && !p.video) { const x = timBai(p.text); if (x) thay = { link: linkBai(x.khung), id: '' }; }
    if (!thay) {
      if (!hopMatTuLuc) hopMatTuLuc = Date.now();
      const gioiHan = hopThayTrangNay ? (p.video ? 8 : 3) * 60000 : 45000; // trang vừa tải lại mà không còn hộp soạn (F5) → 45 giây là coi như mất
      if (Date.now() - (hopThayTrangNay ? p.dongLuc : hopMatTuLuc) > gioiHan) { luu('cho_tay6', null); if (!hopThayTrangNay) { ghi(`${p.ten}: hộp soạn không còn trên trang (trang đã tải lại?) và chưa thấy bài → bỏ bản soạn, bấm Soạn lại nếu cần`); thongBaoMay(`${p.ten}: bản soạn đã mất`, 'Trang đã tải lại nên hộp soạn không còn. Bấm Soạn lại nếu cần.'); } capNhatTT((s) => { Object.assign(ttSlot(s, p.slot), p.soan ? { tt: 'cho', thuLai: p.mai ? 0 : Date.now() + 15 * 60000, daSoan: 0 } : { tt: 'bo', lyDo: 'chạy thử: hộp đã đóng mà không thấy bài (đã huỷ?)' }); }, p.mai || homNay()); if (p.mai) ghi(`${p.ten}: hộp soạn thử đã đóng, không thấy bài → coi như bạn đã huỷ (ngày mai vẫn đăng bình thường)`); if (hopThayTrangNay) ghi(`${p.ten}: hộp soạn đã đóng mà không thấy bài → coi như huỷ${p.soan ? ' (bài để lại hàng chờ)' : ''}`); }
      return true;
    }
    luu('cho_tay6', null);
    if (p.mai) { // bài của ngày mai được bấm Đăng hôm nay: ghi vào "đăng ngoài lịch" hôm nay để kiểm/gửi comment, và đánh dấu ngày mai đã đăng (không đăng lại)
      const can = (lay('ngay6_' + p.mai, { s: {} }).s[p.slot] || {}).can || canCmt({ loai: 'video' }, {});
      const id = thay.id || 'mai_' + p.slot + '_' + Date.now();
      capNhatTT((s) => { s.ngoai[id] = { luc: thay.luc || Date.now(), id: thay.id || '', link: thay.link || '', text: String(p.text || '').slice(0, 300), kiem: [], can, giu: true, mai: p.mai, ten: p.ten }; });
      capNhatTT((s) => { Object.assign(ttSlot(s, p.slot), { tt: 'xong', luc: Date.now(), may: 'tay', link: thay.link || '', id: thay.id || '', kiem: [], cmtOk: false, lyDo: 'đã đăng trước (soạn thử hôm ' + homNay().slice(0, 5).replace('-', '/') + ')' }); }, p.mai);
      ghi(`${p.ten} đã được bấm Đăng hôm nay → ghi là bài đăng ngoài lịch (script kiểm và gửi bù comment sau ${CAI_DAT.KIEM_CMT_SAU_PHUT[0] + 10} phút); ngày mai không đăng lại`);
      thongBaoMay(`${p.ten} đã lên trang`, 'Ngày mai script sẽ không đăng lại bài này. Comment được kiểm và gửi bù sau ít phút.');
      return true;
    }
    ghi(`Thấy ${p.ten} đã được bấm Đăng → script comment tiếp`);
    const dd = { slot: p.slot, loai: p.loai, ten: p.ten, ngay: p.ngay, hang: p.hang, khoa: p.ngay + '|' + p.slot, bai: p.text, cmts: p.cmts, cmtIdx: 0, soAnh: 0, ghiChuTruoc: [], id: thay.id || '', link: thay.link || '', lucApi: thay.luc, ngoai: !!p.video, viaLink: p.video ? (thay.link || '') : '' };
    if (p.video && p.loai === 4) await ghiKetQuaVideo(dd);
    await sauKhiDangSlot(dd);
    return true;
  }

  // =====================================================================
  //  ĐỌC SHEET THEO LỊCH + TẢI SẴN ĐỒ ĐĂNG (Máy Giao)
  // =====================================================================
  async function docSheetTheoLich() {
    if (!MAY || chanLark()) return false;
    const mm = phutTrongNgay(new Date()); const ngay = homNay(); const d = duLieu();
    const k = 'doc6_' + ngay; const st = lay(k, {}) || {};
    const lech = (g) => docGio(g) + (parseInt(bam(ngay + g + MAY), 36) % 9); // lệch 0–8 phút cố định trong ngày
    const thu = async (loai) => { st[loai] = Date.now(); luu(k, st); try { await docDuLieu(loai); st[loai + 'Ok'] = Date.now(); luu(k, st); if (loai === 'chot') luu('tai6', null); } catch (e) { ghi(`Đọc Lark sheet (${loai}) lỗi: ${e.message} — 30 phút sau thử lại`); } veBang(); return true; };
    if (mm >= lech(CAI_DAT.GIO_DOC_CHOT) && mm < 22 * 60 && !st.chotOk && Date.now() - (st.chot || 0) > 30 * 60000) return thu('chot');
    if (mm >= lech(CAI_DAT.GIO_DOC_NHE) && mm < docGio(CAI_DAT.GIO_DOC_CHOT) && !st.nheOk && Date.now() - (st.nhe || 0) > 30 * 60000) return thu('nhe');
    const coHomNay = d && d.ngay && d.ngay[ngay];
    // (6.10) hôm nay có bài bị bỏ vì thiếu nội dung → mỗi giờ đọc lại sheet 1 lần (06:00–21:00) xem đã bổ sung chưa
    const coThieu = Object.values(trangThai().s).some((r) => r.tt === 'thieu');
    if (coThieu && mm >= 6 * 60 && mm < 21 * 60 && Date.now() - (d ? d.luc : 0) > 60 * 60000 && Date.now() - (st.thieuGio || 0) > 60 * 60000) { st.thieuGio = Date.now(); luu(k, st); return thu('thieuGio'); }
    if (!coHomNay && mm >= 6 * 60 && mm < 22 * 60 && Date.now() - (st.thieu || 0) > 30 * 60000) return thu('thieu');
    // dữ liệu đang giữ là của hôm qua (đọc trước 0h, chưa biết các sửa đổi mới) → sáng sớm đọc lại 1 lần cho đúng
    if (d && ngayStr(new Date(d.luc)) !== ngay && mm >= 5 * 60 && mm < 22 * 60 && !st.sang && Date.now() - (st.thieu || 0) > 30 * 60000) { st.sang = Date.now(); luu(k, st); return thu('sang'); }
    return false;
  }
  function dsTaiSan() { // đồ cần tải sẵn: hôm nay (bài chưa đăng) + ngày mai (sau 18:30)
    const d = duLieu(); if (!d || !d.ngay) return [];
    const out = []; const s = trangThai(); const mm = phutTrongNgay(new Date());
    const cacNgay = [homNay()]; if (mm >= docGio(CAI_DAT.GIO_DOC_CHOT)) cacNgay.push(ngayMai());
    const them = (k, x) => { if (!out.some((y) => y.k === k)) out.push(Object.assign({ k }, x)); };
    if (d.chung) { if (d.chung.co) them('tep|' + d.chung.co, { loai: 'anh', token: d.chung.co }); (d.chung.pool || []).forEach((t) => them('tep|' + t, { loai: 'anh', token: t })); }
    for (const ngay of cacNgay) {
      for (const it of LICH) {
        if (ngay === homNay()) { const r = s.s[it.k]; if (r && KET.includes(r.tt)) continue; }
        const nd = noiDungSlot(ngay, it.k, d); if (nd.thieu && nd.thieu.length && !nd.tep && !nd.anh) continue;
        (Array.isArray(nd.anh) ? nd.anh : []).forEach((t) => them('tep|' + t, { loai: 'anh', token: t }));
        (nd.anhCmt || []).forEach((t) => them('tep|' + t, { loai: 'anh', token: t }));
        if (it.loai === 'video' && nd.tep) them('tep|' + nd.tep.fileToken, { loai: 'video', tep: nd.tep });
        if (it.loai === 'manifest' && nd.anh) them(`mf|${ngay}|${it.so}|${nd.anh}`, { loai: 'mf', ngay, so: it.so, anh: nd.anh });
      }
    }
    return out;
  }
  async function taiSan() {
    if (!LA_GIAO || tamDung() || !laTabChinh() || dangBan || lay('dang_do', null) || chanLark()) return false;
    const mm = phutTrongNgay(new Date()); if (mm < 5 * 60 + 30 || mm > 22 * 60 + 30) return false;
    const st = lay('tai6', null) || {}; if (st.xongLuc && Date.now() - st.xongLuc < 30 * 60000) return false;
    if (st.loiLuc && Date.now() - st.loiLuc < 10 * 60000) return false;
    const ds = dsTaiSan(); let con = null, daCo = 0;
    for (const x of ds) { const c = await khoLay(x.k); if (c && c.blob && c.blob.size > 500) daCo++; else { con = x; break; } }
    if (!con) { luu('tai6', { xongLuc: Date.now(), n: ds.length }); if (ds.length && !st.xongLuc) { const kd = await khoDon(); ghi(`Tải sẵn xong ${ds.length} file (kho đang giữ ${kd.n} file, ~${(kd.tong / 1048576).toFixed(0)} MB${kd.xoa ? `, đã dọn ${kd.xoa} file cũ` : ''})`); } return false; }
    luu('tai6', { dang: con.k, daCo, tong: ds.length, luc: Date.now() });
    try {
      if (con.loai === 'anh') await taiTepLark(con.token, { ten: 'ảnh', loai: 'anh' });
      else if (con.loai === 'video') await taiTepLark(con.tep.fileToken, { ten: 'video "' + con.tep.ten + '"', loai: 'video', size: con.tep.size, timeout: 300000 });
      else if (con.loai === 'mf') await videoManifest(con.ngay, con.so, con.anh);
    } catch (e) {
      ghi('Tải sẵn: một file chưa tải được (' + e.message + ') — lúc đăng sẽ tải lại');
      luu('tai6', Object.assign({}, lay('tai6', {}), { loiLuc: Date.now(), loi: e.message, boQua: (st.boQua || []).concat(con.k).slice(-30) }));
      if (e instanceof LoiThieu) { luu('tai6', Object.assign({}, lay('tai6', {}), { loiLuc: Date.now() + 50 * 60000 })); }
    }
    return true;
  }

  // =====================================================================
  //  BÁO CÁO CUỐI NGÀY (nhóm Marketing) — 1 tin khi xong các bài; chưa đủ thì 21:45
  // =====================================================================
  function noiDungBaoCao(s) {
    const d = new Date(); const ngayBC = `${d.getDate()}/${d.getMonth() + 1}/${d.getFullYear()}`;
    const ds = LICH.map((it) => ({ it, r: s.s[it.k] || { tt: 'cho' } }));
    const xong = ds.filter((x) => XONG.includes(x.r.tt)).sort((a, b) => (a.r.luc || 0) - (b.r.luc || 0));
    const chua = ds.filter((x) => !XONG.includes(x.r.tt));
    const dongCua = (ds1, ds2) => ds1.map((x) => `${gioNgan(x.r.luc)} ${x.it.tenBC}: ${/^https?:/.test(x.r.link || '') ? x.r.link : '(chưa lấy được link)'}`).concat(ds2.map((x) => `--h-- ${x.it.tenBC}: chưa đăng${x.r.lyDo ? ' (' + x.r.lyDo + ')' : x.r.loi ? ' (' + x.r.loi + ')' : ''}`));
    let dong;
    if (!LICH.some((it) => (it.kenh || 1) > 1)) dong = dongCua(xong, chua);
    else { dong = []; for (const c of [1, 2, 3]) { const a = xong.filter((x) => (x.it.kenh || 1) === c), b = chua.filter((x) => (x.it.kenh || 1) === c); if (!a.length && !b.length) continue; dong.push(`— Kênh ${c} (${CAI_DAT.KENH[c].ngan}): ${a.length}/${a.length + b.length} bài`); dong.push(...dongCua(a, b)); } } // (6.19) chia theo kênh
    const dau = chua.length ? `Báo cáo ${ngayBC}: đã đăng ${xong.length}/${LICH.length} bài fb (chưa đăng: ${chua.map((x) => x.it.ten).join(', ')}):` : `Báo cáo ${ngayBC}: đã đăng xong ${LICH.length} bài fb:`;
    return dau + '\n' + dong.join('\n');
  }
  async function baoCaoNgay() {
    if (!MAY || !laTabChinh()) return false;
    const s = trangThai(); if (s.baoCao) return false;
    const L = tinhLich(s); const mm = phutTrongNgay(new Date());
    const tatCaKet = L.every((x) => x.ket); const du9 = L.every((x) => x.xong);
    const cuoi = L.filter((x) => x.xong).sort((a, b) => (b.r.luc || 0) - (a.r.luc || 0))[0];
    let gui = false;
    if (du9 && cuoi && cuoi.r.may === MAY) {
      const thieuLink = L.some((x) => !/^https?:/.test(x.r.link || ''));
      if (thieuLink && Date.now() - (cuoi.r.luc || 0) < 10 * 60000) { if (Date.now() - (window.__smhLinkDo || 0) > 60000) { window.__smhLinkDo = Date.now(); await doTrang('lấy link cho báo cáo'); } return false; }
      gui = true;
    } else if ((LA_GIAO && mm >= docGio(CAI_DAT.GIO_BAO_CAO_THIEU)) || (LA_CAO && L.some((x) => x.r.may === 'CAO') && mm >= docGio(CAI_DAT.GIO_BAO_CAO_THIEU) + 20)) { // Máy Cao chỉ báo cáo khi hôm nay chính nó đã đăng thay
      if (!tatCaKet && mm < docGio(CAI_DAT.GIO_CHOT)) return false;
      if (Date.now() - (s.baoCaoThu || 0) < 15 * 60000) return false;
      capNhatTT((x) => { x.baoCaoThu = Date.now(); });
      try { const m = String(chuO(await docO(CAI_DAT.TAB_BAI, CAI_DAT.O_BAO_CAO))); if (m.startsWith('BAOCAO|' + homNay())) { capNhatTT((x) => { x.baoCao = Date.now(); x.baoCaoMay = m.split('|')[2]; }); ghi('Báo cáo ngày: máy kia đã gửi rồi'); return false; } } catch (e) { ghi('Báo cáo ngày: chưa đọc được ô ' + CAI_DAT.O_BAO_CAO + ' (' + e.message + ') → vẫn gửi'); }
      await doTrang('trước báo cáo ngày');
      gui = true;
    }
    if (!gui || !trongGioNhan()) return false;
    const ok = await guiLark('baocao', noiDungBaoCao(trangThai()), { khoa: 'baocao_' + homNay() });
    if (ok) { capNhatTT((x) => { x.baoCao = Date.now(); x.baoCaoMay = MAY; }); try { await ghiO(CAI_DAT.TAB_BAI, CAI_DAT.O_BAO_CAO, `BAOCAO|${homNay()}|${MAY}|${Date.now()}`); } catch (e) { ghi('Chưa ghi được dấu báo cáo vào ô ' + CAI_DAT.O_BAO_CAO + ': ' + e.message); } }
    return true;
  }

  // =====================================================================
  //  YÊU CẦU TỪ POPUP (tab nào bấm cũng được, tab đang làm việc sẽ làm)
  // =====================================================================
  function yeuCau(loai, them) {
    const ds = (lay('yc6', []) || []).filter((x) => Date.now() - x.luc < 10 * 60000 && x.loai !== loai);
    ds.push(Object.assign({ loai, luc: Date.now(), tu: MA_TAB }, them || {}));
    luu('yc6', ds); luu('yc6_kq_' + loai, { tt: 'cho', luc: Date.now() });
    ghi('Bấm: ' + (TEN_YC[loai] || loai)); veBang();
    setTimeout(nhip, 300);
  }
  const TEN_YC = { docsheet: 'Đọc lại Lark sheet', kiem1: 'Kiểm comment bài mới nhất', kiem3: 'Kiểm comment 3 bài gần nhất', kiem24: 'Kiểm comment video 24 giờ qua', dotrang: 'Kiểm tra bài trên trang', taoanh: 'Tạo ảnh manifest', khanhthu: 'Kiểm thử Khanh Trầm Hương', tinthu: 'Gửi tin thử', taisan: 'Tải sẵn đồ đăng' };
  async function xuLyYeuCau() {
    const ds = lay('yc6', []) || []; if (!ds.length || !laTabChinh()) return false;
    luu('yc6', []);
    for (const y of ds) {
      if (Date.now() - y.luc > 10 * 60000) continue;
      luu('yc6_kq_' + y.loai, { tt: 'dang', luc: Date.now() }); if (hdChay) { hdChay.ten = 'Đang ' + (TEN_YC[y.loai] || 'làm việc bạn vừa bấm').replace(/^./, (c) => c.toLowerCase()); } veBang();
      let kq = 'Xong';
      try {
        if (y.loai === 'docsheet') { const d = await docDuLieu('tay'); luu('tai6', null); kq = `Đã đọc lúc ${gioStr(new Date())}`; void d; }
        else if (y.loai === 'dotrang') { const x = await doTrang('bấm tay'); kq = x ? `Đã kiểm: hôm nay trang có ${(lay('trang6', {}) || {}).n || 0} bài` : 'Chưa kiểm được (xem nhật ký)'; }
        else if (y.loai === 'kiem1' || y.loai === 'kiem3' || y.loai === 'kiem24') { await kiemTay(y.loai); kq = 'Đã kiểm — bài nào thiếu sẽ được gửi bù ngay'; }
        else if (y.loai === 'khanhthu') { await khanhThuNgay(); kq = 'Đang mở trang để đọc'; }
        else if (y.loai === 'tinthu') { const ok = await guiLark('loi', `[fb][${TEN_MAY}] Tin thử từ popup — kết nối nhóm Đăng bài fb hoạt động`, { khoa: 'thu' + Date.now(), toiDa: 9 }); kq = ok ? 'Đã gửi tin thử' : 'Gửi chưa được'; }
        else if (y.loai === 'taisan') { luu('tai6', null); kq = 'Sẽ tải sẵn ngay'; }
      } catch (e) { kq = 'Lỗi: ' + e.message; ghi(`Lỗi khi ${TEN_YC[y.loai] || y.loai}: ${e.message}`); }
      luu('yc6_kq_' + y.loai, { tt: /^Lỗi/.test(kq) ? 'loi' : 'xong', luc: Date.now(), kq }); if (hdChay) hdChay.cuoi = kq;
      veBang();
    }
    return true;
  }

  // =====================================================================
  //  TẠO ẢNH MANIFEST (bấm tay ở tab Manifest): tạo xem trước trong popup → chọn → dán vào sheet
  //  chữ cột G → ảnh dán vào cột bên phải cùng hàng. Ảnh tạo ra chỉ giữ trong tab này cho tới khi dán.
  // =====================================================================
  let anhNenTam = []; // ảnh nền vừa chọn trên popup
  const mf = { ds: [], tien: null, chay: false, dan: false };
  function mfBuoc(buoc, chu, i, n) {
    mf.tien = { buoc, chu, i: i || 0, n: n || 0, luc: Date.now(), bd: (mf.tien && mf.tien.bd) || Date.now() };
    if (hdChay) { hdChay.chi = chu; hdChay.cap = Date.now(); if (hdChay.hien) luu('hoat_dong', hdChay); }
    veBang();
  }
  function docVungMF(vung) {
    const m = String(vung || '').toUpperCase().replace(/\s+/g, '').match(/^([A-Z]{1,2})(\d+)(?::([A-Z]{1,2})?(\d+))?$/);
    if (!m) throw new Error('vùng ô không đúng dạng (ví dụ G220:G223)');
    const cot = m[1], tu = +m[2], den = +(m[4] || m[2]);
    if (m[3] && m[3] !== cot) throw new Error('chỉ chọn 1 cột (ví dụ G220:G223)');
    if (den < tu || den - tu > 60) throw new Error('vùng ô từ 1 đến 60 hàng');
    if (cot.length > 1 || cot >= 'Z') throw new Error('cột chữ phải từ A đến Y');
    return { cot, tu, den, cotKQ: String.fromCharCode(cot.charCodeAt(0) + 1) };
  }
  // ---- font chữ ảnh manifest: 2 font có sẵn + font tải thêm (lưu trong Tampermonkey của máy này) ----
  const FONT_GOC = ['UTM American Sans', 'UTM Aptima'];
  const FONT_MAC_DINH = { td: 'UTM American Sans', than: 'UTM American Sans', cmt: 'UTM Aptima' };
  const fontThem = () => lay('mf_fonts6', {}) || {};
  const dsFont = () => FONT_GOC.concat(Object.keys(fontThem()));
  function fontChon() { const c = Object.assign({}, FONT_MAC_DINH, lay('mf_font6', {}) || {}); const ds = dsFont(); for (const k of Object.keys(FONT_MAC_DINH)) if (!ds.includes(c[k])) c[k] = FONT_MAC_DINH[k]; return c; }
  const fontDaNap = new Set();
  async function napFontChon() {
    await napFontMF();
    for (const [ten, b64] of Object.entries(fontThem())) {
      if (fontDaNap.has(ten)) continue;
      const bin = atob(b64); const u8 = new Uint8Array(bin.length); for (let i = 0; i < bin.length; i++) u8[i] = bin.charCodeAt(i);
      const f = new FontFace(ten, u8.buffer); await f.load(); document.fonts.add(f); fontDaNap.add(ten);
    }
  }
  async function themFont(file) {
    if (!/\.(ttf|otf|woff2?)$/i.test(file.name)) throw new Error('chỉ nhận file font .ttf, .otf, .woff, .woff2');
    if (file.size > 3 * 1024 * 1024) throw new Error(`file font nặng ${(file.size / 1048576).toFixed(1)} MB — tối đa 3 MB`);
    const ds = fontThem(); if (Object.keys(ds).length >= 6) throw new Error('đã có 6 font tải thêm — xoá bớt rồi thêm');
    let ten = file.name.replace(/\.(ttf|otf|woff2?)$/i, '').replace(/[^\p{L}\p{N} _-]/gu, ' ').replace(/\s+/g, ' ').trim() || 'Font';
    if (FONT_GOC.includes(ten)) ten += ' (tải)';
    const buf = await file.arrayBuffer();
    try { const f = new FontFace(ten, buf.slice(0)); await f.load(); document.fonts.add(f); fontDaNap.add(ten); } catch (e) { throw new Error('file này không phải font hợp lệ'); }
    const u8 = new Uint8Array(buf); let bin = ''; for (let i = 0; i < u8.length; i += 0x8000) bin += String.fromCharCode.apply(null, u8.subarray(i, i + 0x8000));
    ds[ten] = btoa(bin); luu('mf_fonts6', ds);
    ghi(`Đã thêm font "${ten}" (${(file.size / 1024).toFixed(0)} KB) cho ảnh manifest`);
    return ten;
  }
  function xoaFont(ten) { const ds = fontThem(); delete ds[ten]; luu('mf_fonts6', ds); fontDaNap.delete(ten); const c = lay('mf_font6', {}) || {}; for (const k of Object.keys(c)) if (c[k] === ten) delete c[k]; luu('mf_font6', c); ghi(`Đã xoá font "${ten}"`); }
  function datFont(vai, ten) { const c = lay('mf_font6', {}) || {}; c[vai] = ten; luu('mf_font6', c); }
  const nenNgauNhien = (tru) => { const ds = anhNenTam.filter((f) => f !== tru); const L = ds.length ? ds : anhNenTam; return L[Math.floor(Math.random() * L.length)]; };
  async function veMotAnh(x) {
    const f = fontChon();
    const kq = await taoAnhManifest(x.nen, x.chu, f.than, f.cmt, f.td, f.than);
    if (!kq.blob || kq.blob.size < 20000) throw new Error('ảnh tạo ra bị lỗi');
    if (kq.phaiNhat > 1080 - 128) throw new Error('chữ sát mép quá, cần rút ngắn');
    if (x.url) URL.revokeObjectURL(x.url);
    Object.assign(x, { blob: kq.blob, url: URL.createObjectURL(kq.blob), tl: kq.tl, tt: 'moi', loi: '' });
  }
  async function taoAnhXemTruoc(vung) {
    if (mf.chay || mf.dan) throw new Error('đang tạo/dán ảnh, đợi xong đã');
    if (!anhNenTam.length) throw new Error('chưa chọn ảnh nền');
    const v0 = docVungMF(vung);
    mf.chay = true; mf.ds.forEach((x) => { if (x.url) URL.revokeObjectURL(x.url); }); mf.ds = []; mf.tien = null;
    try {
      mfBuoc('doc', `Bước 1/3 · Đọc chữ trong sheet (ô ${vung})`);
      const v = await docBang(CAI_DAT.TAB_VIDEO, `${v0.cot}${v0.tu}:${v0.cot}${v0.den}`);
      const hangs = [];
      for (let h = v0.tu; h <= v0.den; h++) { const chu = chuO((v[h - v0.tu] || [])[0]).trim(); if (chu) hangs.push({ h, chu }); }
      if (!hangs.length) throw new Error(`các ô ${vung} chưa có chữ`);
      ghi(`Tạo ảnh manifest: đọc được ${hangs.length} ô có chữ trong ${vung}`);
      { const f = fontChon(); mfBuoc('font', `Bước 2/3 · Nạp font chữ (tiêu đề: ${f.td} · thân: ${f.than} · kêu gọi: ${f.cmt})`); } await napFontChon();
      // chia đều ảnh nền (xáo trộn) cho các ảnh
      const tron = anhNenTam.slice().sort(() => Math.random() - 0.5);
      for (let i = 0; i < hangs.length; i++) {
        const { h, chu } = hangs[i];
        mfBuoc('tao', `Bước 3/3 · Tạo ảnh ${i + 1}/${hangs.length} (chữ ô ${v0.cot}${h})`, i, hangs.length);
        const x = { h, oChu: v0.cot + h, oKQ: v0.cotKQ + h, chu, nen: tron[i % tron.length], chon: true, tt: 'moi' };
        try { await veMotAnh(x); } catch (e) { x.tt = 'loi'; x.loi = e.message; x.chon = false; ghi(`Tạo ảnh manifest ô ${x.oChu} lỗi: ${e.message}`); }
        mf.ds.push(x); veBang(); await sleepThat(30);
      }
      const ok = mf.ds.filter((x) => x.tt !== 'loi').length;
      mfBuoc('xong', `Đã tạo ${ok}/${hangs.length} ảnh — bấm vào từng ảnh để xem trước, rồi bấm "Dán vào sheet"`, hangs.length, hangs.length);
      ghi(`Tạo ảnh manifest: đã tạo ${ok}/${hangs.length} ảnh xem trước (chưa dán vào sheet)`);
      return `đã tạo ${ok}/${hangs.length} ảnh xem trước`;
    } catch (e) { mfBuoc('loi', 'Chưa tạo được: ' + e.message); throw e; } finally { mf.chay = false; veBang(); }
  }
  async function taoLaiAnh(i) {
    const x = mf.ds[i]; if (!x || mf.chay || mf.dan) return;
    mf.chay = true; x.tt = 'dangtao'; veBang();
    try { x.nen = nenNgauNhien(x.nen); await napFontChon(); await veMotAnh(x); x.chon = true; ghi(`Tạo lại ảnh manifest ô ${x.oKQ} (đổi ảnh nền)`); }
    catch (e) { x.tt = 'loi'; x.loi = e.message; } finally { mf.chay = false; veBang(); }
  }
  async function veLaiFont() { // đổi font → vẽ lại tất cả ảnh chưa dán, giữ nguyên ảnh nền
    if (mf.chay || mf.dan) throw new Error('đang tạo/dán ảnh, đợi xong đã');
    const ds = mf.ds.filter((x) => x.nen && x.tt !== 'xong');
    if (!ds.length) throw new Error('không còn ảnh nào chưa dán để vẽ lại');
    mf.chay = true; mf.tien = null;
    try {
      const f = fontChon(); mfBuoc('font', `Nạp font chữ (tiêu đề: ${f.td} · thân: ${f.than} · kêu gọi: ${f.cmt})`); await napFontChon();
      let ok = 0;
      for (let i = 0; i < ds.length; i++) {
        const x = ds[i]; x.tt = 'dangtao';
        mfBuoc('tao', `Vẽ lại ảnh ${i + 1}/${ds.length} với font mới (ô ${x.oKQ})`, i, ds.length);
        try { await veMotAnh(x); x.chon = true; ok++; } catch (e) { x.tt = 'loi'; x.loi = e.message; x.chon = false; }
        veBang(); await sleepThat(30);
      }
      mfBuoc('xong', `Đã vẽ lại ${ok}/${ds.length} ảnh với font mới — xem lại rồi bấm "Dán vào sheet"`, ds.length, ds.length);
      ghi(`Vẽ lại ${ok}/${ds.length} ảnh manifest với font: ${f.td} / ${f.than} / ${f.cmt}`);
      return `đã vẽ lại ${ok}/${ds.length} ảnh với font mới`;
    } catch (e) { mfBuoc('loi', 'Chưa vẽ lại được: ' + e.message); throw e; } finally { mf.chay = false; veBang(); }
  }
  async function danAnhVaoSheet() {
    if (mf.chay || mf.dan) throw new Error('đang tạo/dán ảnh, đợi xong đã');
    const ds = mf.ds.filter((x) => x.chon && x.blob && x.tt !== 'xong');
    if (!ds.length) throw new Error('chưa chọn ảnh nào để dán');
    mf.dan = true; mf.tien = null;
    try {
      let ok = 0;
      for (let i = 0; i < ds.length; i++) {
        const x = ds[i]; x.tt = 'dang';
        mfBuoc('dan', `Dán ảnh ${i + 1}/${ds.length} vào ô ${x.oKQ}`, i, ds.length);
        try { await ghiAnhVaoO(CAI_DAT.TAB_VIDEO, x.oKQ, x.blob, `manifest-h${x.h}.jpg`); x.tt = 'xong'; ok++; ghi(`Đã dán ảnh manifest vào ô ${x.oKQ}`); }
        catch (e) { x.tt = 'loi'; x.loi = e.message; ghi(`Dán ảnh manifest vào ô ${x.oKQ} lỗi: ${e.message}`); }
        veBang();
      }
      const kq = `đã dán ${ok}/${ds.length} ảnh vào sheet${ok < ds.length ? ' — ảnh lỗi có thể bấm Dán lại' : ''}`;
      mfBuoc('daxong', 'Xong: ' + kq, ds.length, ds.length);
      return kq;
    } finally { mf.dan = false; veBang(); }
  }
