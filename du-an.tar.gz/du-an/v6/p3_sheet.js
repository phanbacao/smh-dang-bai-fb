
  // =====================================================================
  //  Đọc dữ liệu sheet (2 tab) — chỉ đọc 13:30 + 18:30 (và khi bấm nút)
  // =====================================================================
  function chuO(cell) {
    if (cell == null) return '';
    if (typeof cell === 'string') return cell;
    if (typeof cell === 'number') return String(cell);
    if (Array.isArray(cell)) return cell.map((s) => (typeof s === 'string' ? s : (s && !s.fileToken && (s.text != null ? s.text : (s.link || ''))) || '')).join('');
    if (typeof cell === 'object' && cell.text != null && !cell.fileToken) return String(cell.text);
    return '';
  }
  const coTep = (c) => !!c && (Array.isArray(c) ? c.some((x) => x && x.fileToken) : !!c.fileToken);
  function ngayO(cell) {
    if (typeof cell === 'number' && cell > 20000 && cell < 80000) {
      const d = new Date(Date.UTC(1899, 11, 30) + Math.floor(cell + 1e-6) * 86400000);
      return `${pad(d.getUTCDate())}-${pad(d.getUTCMonth() + 1)}-${d.getUTCFullYear()}`;
    }
    const s = chuO(cell);
    const m = s.match(/(\d{1,2})\s*[-\/.]\s*(\d{1,2})\s*[-\/.]\s*(\d{4})/);
    return m ? `${pad(m[1])}-${pad(m[2])}-${m[3]}` : '';
  }
  const COT_BAT_BUOC = [
    { cot: 'A', chiSo: 0, chua: 'từ khóa', ten: 'Từ khóa chính' },
    { cot: 'B', chiSo: 1, chua: 'không có ảnh', ten: 'Bài twist (không có ảnh)' },
    { cot: 'C', chiSo: 2, chua: 'cmt bài 1', ten: 'Cmt bài 1' },
    { cot: 'H', chiSo: 7, chua: 'ngày đăng', ten: 'Ngày đăng' },
  ];
  function kiemTenCot(values) {
    const h = values[0] || [];
    for (const c of COT_BAT_BUOC) {
      if (!thuong(chuO(h[c.chiSo])).includes(c.chua)) return `Tên cột ${c.cot} tab "Bài viết kênh 1" không còn là "${c.ten}" (đang là "${chuan(chuO(h[c.chiSo])) || 'trống'}") — script không đọc để tránh đăng nhầm cột`;
    }
    return null;
  }
  // ô ảnh của Lark: { fileToken, ... } hoặc danh sách → danh sách mã ảnh
  function tokenAnh(c) {
    if (!c) return [];
    if (Array.isArray(c)) return c.reduce((a, x) => a.concat(tokenAnh(x)), []);
    if (typeof c === 'object' && c.fileToken && (c.type === 'embed-image' || /^image\//.test(c.mimeType || '') || /\.(jpe?g|png|webp|heic|gif)$/i.test(c.text || '') || !c.mimeType)) return [String(c.fileToken)];
    return [];
  }
  const anhNhieuO = (r, tu, den) => { let a = []; for (let i = tu; i <= den; i++) a = a.concat(tokenAnh(r[i])); return a; };
  function tepVideo(c) {
    const ds = Array.isArray(c) ? c : (c && c.fileToken ? [c] : []);
    const t = ds.find((x) => x && x.fileToken && (/^video\//.test(x.mimeType || '') || /\.(mp4|mov|m4v|webm)$/i.test(x.text || '')));
    return t ? { fileToken: t.fileToken, size: t.size || 0, ten: t.text || 'video.mp4', mime: t.mimeType || 'video/mp4' } : null;
  }
  function tepNhac(c) {
    const ds = Array.isArray(c) ? c : (c && c.fileToken ? [c] : []);
    const t = ds.find((x) => x && x.fileToken && (/^audio\//.test(x.mimeType || '') || /\.(mp3|m4a|aac|wav|ogg)$/i.test(x.text || '')));
    return t ? { fileToken: t.fileToken, size: t.size || 0, ten: t.text || 'nhac.mp3', mime: t.mimeType || 'audio/mpeg' } : null;
  }
  // ảnh cố định cho comment (Bài 3, video, manifest): ô O2 + 1 ảnh ngẫu nhiên trong P2, Q2, O3, P3, Q3 (tab Bài viết kênh 1)
  function anhChung(v) {
    const r2 = v[1] || [], r3 = v[2] || [];
    return { co: tokenAnh(r2[14])[0] || '', pool: [r2[15], r2[16], r3[14], r3[15], r3[16]].reduce((a, x) => a.concat(tokenAnh(x)), []) };
  }
  function hangCuaNgay(values, ngay) {
    const out = [];
    for (let i = 1; i < values.length; i++) {
      const r = values[i] || [];
      if (ngayO(r[7]) === ngay) {
        out.push({ hang: i + 1, bai: chuO(r[1]).trim(), cmt: chuO(r[2]).trim(), bai2: chuO(r[3]).trim(), cmt2: chuO(r[4]).trim(), bai3: chuO(r[5]).trim(),
          anh2: anhNhieuO(r, 8, 10), anh3: anhNhieuO(r, 11, 13), anhCmt: anhNhieuO(r, 14, 16), trangThai: chuO(r[6]).trim() });
      }
    }
    return out;
  }
  // tab "Kênh 1 Vòng Trầm Hương SMH": K = ngày đăng, N = file video, E = chữ đăng video, G = chữ manifest, H = ảnh manifest, J = trạng thái, B = link
  function videoCuaNgay(values, ngay) {
    const v = [], m = [];
    for (let i = 1; i < values.length; i++) {
      const r = values[i] || [];
      if (ngayO(r[10]) !== ngay) continue;
      const tep = tepVideo(r[13]); const cap = chuO(r[4]).trim();
      if (tep || cap) v.push({ hang: i + 1, cap, tep, daDang: /đã đăng/i.test(chuO(r[9])), link: chuO(r[1]).trim() });
      const chu = coTep(r[6]) ? '' : chuO(r[6]).trim(); const anh = tokenAnh(r[7])[0] || '';
      if (chu || anh) m.push({ hang: i + 1, chu, anh });
    }
    return { v, m };
  }
  // hàng mới (nằm dưới hàng cuối cùng có ngày) đã có nội dung nhưng CHƯA ghi ngày đăng → script chưa biết đăng ngày nào
  function hangChuaNgay(values, cotNgay, coNoiDung, cotTT) {
    let cuoi = 0, ngayXa = '';
    const soNgay = (n) => { const m = n.match(/^(\d{2})-(\d{2})-(\d{4})$/); return m ? `${m[3]}${m[2]}${m[1]}` : ''; };
    for (let i = 1; i < values.length; i++) { const n = ngayO((values[i] || [])[cotNgay]); if (n) { cuoi = i; if (soNgay(n) > ngayXa) ngayXa = soNgay(n); } }
    // sheet đã ghi ngày cho hơn 3 ngày tới → chưa cần nhắc (các hàng chưa ghi ngày còn lâu mới tới lượt)
    if (ngayXa && ngayXa > soNgay(ngayStr(congNgay(3)))) return [];
    const out = [];
    for (let i = cuoi + 1; i < values.length; i++) {
      const r = values[i] || [];
      if (ngayO(r[cotNgay]) || /đã đăng/i.test(chuO(r[cotTT]))) continue;
      if (coNoiDung(r)) out.push(i + 1);
    }
    return out;
  }
  function gonHang(ds) { // [220,221,222,223,230] → "220–223, 230"
    const out = []; let a = null, b = null;
    for (const x of ds) { if (b !== null && x === b + 1) { b = x; continue; } if (a !== null) out.push(a === b ? String(a) : `${a}–${b}`); a = b = x; }
    if (a !== null) out.push(a === b ? String(a) : `${a}–${b}`);
    return out.join(', ');
  }

  // dữ liệu đã đọc (lưu trong Tampermonkey) — dùng cho cả ngày, không đọc lại
  const duLieu = () => lay('du_lieu6', null);
  // ---- (6.19) kênh 2, 3: tab riêng — mỗi dòng có Ngày đăng (H) + Trạng thái (G) + video (I) + caption (E/D) ----
  function kiemCotKenh(values, c) {
    const h = (values || [])[0] || []; const cfg = CAI_DAT.KENH[c]; const t = (i) => thuong(chuO(h[i]));
    const sai = [];
    if (!t(cfg.cot.ngay).includes('ngày đăng')) sai.push(`cột ${String.fromCharCode(65 + cfg.cot.ngay)} không phải "Ngày đăng" (đang là "${chuan(chuO(h[cfg.cot.ngay])) || 'trống'}")`);
    if (!t(cfg.cot.tt).includes('trạng thái')) sai.push(`cột ${String.fromCharCode(65 + cfg.cot.tt)} không phải "Trạng thái"`);
    if (!t(cfg.cot.video).includes('video')) sai.push(`cột ${String.fromCharCode(65 + cfg.cot.video)} không phải "VIDEO"`);
    if (!/tiêu đề|caption|fb/.test(t(cfg.cot.cap))) sai.push(`cột ${String.fromCharCode(65 + cfg.cot.cap)} không phải "Tiêu đề FB/Tiktok"`);
    return sai.length ? `Tab "${cfg.tenTab}": ${sai.join('; ')} — script không đọc kênh ${c} để tránh đăng nhầm cột` : null;
  }
  function hangKenh(values, c, ngay) { // mọi dòng ghi ngày này (kể cả chưa duyệt — để cảnh báo)
    const cfg = CAI_DAT.KENH[c]; const out = [];
    for (let i = 1; i < (values || []).length; i++) {
      const r = values[i] || []; if (ngayO(r[cfg.cot.ngay]) !== ngay) continue;
      const tt = chuan(chuO(r[cfg.cot.tt]));
      out.push({ hang: i + 1, cap: chuO(r[cfg.cot.cap]).trim(), tep: tepVideo(r[cfg.cot.video]), tt, duyet: /đã duyệt/i.test(tt), daDang: /đã đăng/i.test(tt), link: chuO(r[cfg.cot.link]).trim() });
    }
    return out;
  }
  function phanTich(vB, vV, loai, vK) {
    vK = vK || {};
    const loiCot = kiemTenCot(vB);
    const out = { luc: Date.now(), loai, ban: 2, loiCot, chung: anhChung(vB), ngay: {}, loiKenh: {},
      chuaNgayV: hangChuaNgay(vV, 10, (r) => !!(tepVideo(r[13]) || tokenAnh(r[7]).length || (!coTep(r[6]) && chuO(r[6]).trim())), 9),
      chuaNgayB: loiCot ? [] : hangChuaNgay(vB, 7, (r) => !!(chuO(r[1]).trim() || chuO(r[3]).trim() || chuO(r[5]).trim()), 6) };
    for (let i = 0; i <= 3; i++) {
      const ngay = ngayStr(congNgay(i));
      const hs = loiCot ? [] : hangCuaNgay(vB, ngay);
      const vm = videoCuaNgay(vV, ngay);
      out.ngay[ngay] = { bai: hs[0] || null, soHangBai: hs.length, v: vm.v, m: vm.m };
    }
    for (const c of [2, 3]) {
      const x = vK[c]; if (!x) continue;
      if (x.loi) { out.loiKenh[c] = x.loi; continue; }
      const lc = kiemCotKenh(x.values, c); if (lc) { out.loiKenh[c] = lc; continue; }
      for (let i = 0; i <= 3; i++) { const ngay = ngayStr(congNgay(i)); out.ngay[ngay]['k' + c] = hangKenh(x.values, c, ngay); }
    }
    return out;
  }
  let docDLCho = null;
  async function docDuLieu(loai) {
    if (docDLCho) return docDLCho;
    docDLCho = (async () => {
      const vB = await docBang(CAI_DAT.TAB_BAI, 'A1:Q3000');
      const vV = await docBang(CAI_DAT.TAB_VIDEO, 'A1:N3000');
      const vK = {};
      for (const c of [2, 3]) { // (6.19) kênh 2, 3 — đọc lỗi thì kênh 1 vẫn chạy bình thường
        try { vK[c] = { values: await docBang(CAI_DAT.KENH[c].tab, 'A1:J3000') }; } catch (e) { if (e instanceof LoiLark) throw e; vK[c] = { loi: `chưa đọc được tab "${CAI_DAT.KENH[c].tenTab}" (${e.message})` }; }
      }
      const d = phanTich(vB, vV, loai, vK);
      luu('du_lieu6', d);
      await dongBoCmt();
      await dongBoThe();
      try { dongBoLich(); } catch (e) { ghi('Cập nhật lịch kênh 2, 3 lỗi: ' + e.message); }
      try { thuLaiBaiThieu(d); } catch (e) { /* */ }
      const n = d.ngay[homNay()] || {};
      ghi(`Đọc Lark sheet (${({ nhe: 'lượt 13:30', chot: 'lượt 18:30', tay: 'bấm tay', thieu: 'chưa có dữ liệu hôm nay', thieuGio: 'có bài thiếu nội dung, đọc lại mỗi giờ', sang: 'đầu ngày, dữ liệu cũ từ hôm qua', suckhoe: 'tự kiểm tra sáng', nhacmai: 'trước khi nhắc điền sheet ngày mai' })[loai] || loai}): hôm nay có ${n.bai ? 'bài viết' : 'CHƯA có bài viết'}, ${(n.v || []).length} video, ${(n.m || []).length} manifest${d.chuaNgayV.length + d.chuaNgayB.length ? ` · ${d.chuaNgayV.length + d.chuaNgayB.length} hàng có nội dung nhưng chưa ghi ngày đăng (${[d.chuaNgayV.length ? 'tab Kênh 1 hàng ' + gonHang(d.chuaNgayV) : '', d.chuaNgayB.length ? 'tab Bài viết hàng ' + gonHang(d.chuaNgayB) : ''].filter(Boolean).join('; ')})` : ''}${d.loiCot ? ' — ' + d.loiCot : ''}${[2, 3].map((c) => d.loiKenh && d.loiKenh[c] ? ` — kênh ${c}: ${d.loiKenh[c]}` : ` · kênh ${c}: ${((n['k' + c] || []).filter((x) => x.duyet || x.daDang)).length} video hôm nay`).join('')}`);
      return d;
    })();
    try { return await docDLCho; } finally { docDLCho = null; }
  }
  // nội dung của 1 bài trong lịch (k = b1…m3) theo dữ liệu đã đọc
  function noiDungSlot(ngay, k, d = duLieu()) {
    const it = LICH.find((x) => x.k === k) || lichNgay(ngay, d).find((x) => x.k === k) || { k, loai: 'video', so: 0, kenh: kenhCua(k), ten: tenSlot(k) }; const n = d && d.ngay && d.ngay[ngay];
    if (!n) return { thieu: ['chưa đọc được sheet của ngày này'] };
    if ((it.kenh || 1) > 1) { // (6.19) video kênh 2, 3
      const c = it.kenh; const cfg = CAI_DAT.KENH[c]; const th = [];
      if (d.loiKenh && d.loiKenh[c]) return { thieu: [d.loiKenh[c]], text: '' };
      const x = videoKenh(n, c)[it.so];
      const cot = (i) => String.fromCharCode(65 + i);
      if (!x) th.push(`video kênh ${c} thứ ${it.so + 1} (tab "${cfg.tenTab}" chưa có dòng ghi ngày này với Trạng thái "ĐÃ DUYỆT")`);
      else { if (!x.tep) th.push(`file video ${it.ten} (cột ${cot(cfg.cot.video)} hàng ${x.hang})`); if (!x.cap) th.push(`caption ${it.ten} (cột ${cot(cfg.cot.cap)} hàng ${x.hang})`); }
      return { thieu: th, text: x ? x.cap : '', tep: x ? x.tep : null, hang: x ? x.hang : 0, daDang: x ? x.daDang : false, kenh: c };
    }
    const b = n.bai; const th = [];
    if (it.loai === 'b1') { if (!b) th.push('bài viết (cột H chưa có hàng ghi ngày này)'); else if (!b.bai) th.push('chữ Bài 1 (cột B)'); if (b && b.bai && !b.cmt) th.push('comment Bài 1 (cột C)'); return { thieu: th, text: b ? b.bai : '', cmt: b ? b.cmt : '', hang: b ? b.hang : 0 }; }
    if (it.loai === 'b2') { if (!b) th.push('bài viết (cột H chưa có hàng ghi ngày này)'); else if (!b.bai2) th.push('chữ Bài 2 (cột D)'); else { if (!b.anh2.length) th.push('ảnh Bài 2 (cột I–K)'); if (!b.cmt2) th.push('comment Bài 2 (cột E)'); } return { thieu: th, text: b ? b.bai2 : '', cmt: b ? b.cmt2 : '', anh: b ? b.anh2 : [], hang: b ? b.hang : 0 }; }
    if (it.loai === 'b3') { if (!b) th.push('bài viết (cột H chưa có hàng ghi ngày này)'); else if (!b.bai3) th.push('chữ Bài 3 (cột F)'); else { if (!b.anh3.length) th.push('ảnh Bài 3 (cột L–N)'); } return { thieu: th, text: b ? b.bai3 : '', anh: b ? b.anh3 : [], anhCmt: b ? b.anhCmt : [], hang: b ? b.hang : 0 }; }
    if (it.loai === 'video') { const x = n.v[it.so]; if (!x) th.push(`video (cột K chưa có hàng thứ ${it.so + 1} ghi ngày này)`); else { if (!x.tep) th.push(`file video ${it.ten} (cột N hàng ${x.hang})`); if (!x.cap) th.push(`chữ đăng ${it.ten} (cột E hàng ${x.hang})`); } return { thieu: th, text: x ? x.cap : '', tep: x ? x.tep : null, hang: x ? x.hang : 0, daDang: x ? x.daDang : false }; }
    const x = n.m[it.so]; if (!x) th.push(`manifest (cột K chưa có hàng thứ ${it.so + 1} ghi ngày này)`); else { if (!x.chu) th.push(`chữ ${it.ten} (cột G hàng ${x.hang})`); if (!x.anh) th.push(`ảnh ${it.ten} (cột H hàng ${x.hang})`); }
    return { thieu: th, text: x ? x.chu : '', anh: x ? x.anh : '', hang: x ? x.hang : 0 };
  }
  // danh sách thiếu của 1 ngày (cho cảnh báo vàng/đỏ trên popup)
  function thieuCuaNgay(ngay, d = duLieu()) {
    if (!d || !d.ngay || !d.ngay[ngay]) return null;
    const ds = [];
    for (const it of lichNgay(ngay, d)) { const nd = noiDungSlot(ngay, it.k, d); if (nd.thieu.length) ds.push({ k: it.k, ten: it.ten, thieu: nd.thieu }); }
    for (const w of canhBaoKenh(ngay, d)) ds.push(w);
    return ds;
  }
  // ---- (6.19) lịch theo ngày: 9 bài kênh 1 + video kênh 2, 3 (dòng có Ngày đăng = ngày đó VÀ Trạng thái "ĐÃ DUYỆT"; dòng đã "ĐÃ ĐĂNG" vẫn giữ chỗ) ----
  const videoKenh = (n, c) => ((n && n['k' + c]) || []).filter((x) => x.duyet || x.daDang);
  const CHU_SO = 'abcdefgh';
  function lichNgay(ngay, d = duLieu()) {
    const n = d && d.ngay && d.ngay[ngay]; const out = LICH_GOC.slice();
    for (const c of [2, 3]) {
      if (d && d.loiKenh && d.loiKenh[c]) continue;
      videoKenh(n, c).slice(0, CHU_SO.length).forEach((x, i) => out.push({ k: 'k' + c + CHU_SO[i], ten: `Kênh ${c} · Video ${i + 1}`, tenBC: `Kênh ${c} (${CAI_DAT.KENH[c].ngan}) · Video ${i + 1}`, nhan: `K${c}·${i + 1}`, loai: 'video', so: i, kenh: c }));
    }
    return out;
  }
  function dongBoLich() { // LICH = lịch hôm nay (giữ chỗ cho video đã có trạng thái trong ngày, kể cả khi sheet đổi trạng thái sau đó)
    const ngay = homNay(); const moi = lichNgay(ngay); const s = lay('ngay6_' + ngay, null);
    if (s && s.s) for (const k of Object.keys(s.s)) if (/^k[23][a-h]$/.test(k) && !moi.some((x) => x.k === k) && s.s[k] && s.s[k].tt !== 'cho') { const c = +k[1], i = CHU_SO.indexOf(k[2]); moi.push({ k, ten: `Kênh ${c} · Video ${i + 1}`, tenBC: `Kênh ${c} (${CAI_DAT.KENH[c].ngan}) · Video ${i + 1}`, nhan: `K${c}·${i + 1}`, loai: 'video', so: i, kenh: c }); }
    const cu = LICH.map((x) => x.k).join(',');
    LICH.length = 0; for (const it of moi) LICH.push(it);
    if (LICH.map((x) => x.k).join(',') !== cu) { const them = LICH.filter((x) => x.kenh > 1); const dau = ngay + '|' + them.map((x) => x.k).join(','); if (lay('lich_k6', '') !== dau) { luu('lich_k6', dau); ghi(`Lịch hôm nay có ${them.length} video kênh 2, 3: ${them.map((x) => x.ten).join(', ') || '(không có)'}`); } }
    return LICH;
  }
  // cảnh báo cho nhân sự sửa sheet kênh 2, 3 (popup + 16:00 hôm trước)
  function canhBaoKenh(ngay, d = duLieu()) {
    const out = []; const n = d && d.ngay && d.ngay[ngay]; if (!n) return out;
    for (const c of [2, 3]) {
      const cfg = CAI_DAT.KENH[c]; const ten = `Kênh ${c} (${cfg.ngan})`;
      if (d.loiKenh && d.loiKenh[c]) { out.push({ k: 'kenh' + c, ten, thieu: [d.loiKenh[c]] }); continue; }
      const ds = n['k' + c]; if (!ds) continue;
      if (!ds.length) { out.push({ k: 'kenh' + c, ten, thieu: [`chưa có dòng nào ghi Ngày đăng ${ngay.replace(/-/g, '/')} (tab "${cfg.tenTab}" cột ${String.fromCharCode(65 + cfg.cot.ngay)})`] }); continue; }
      for (const x of ds) if (!x.duyet && !x.daDang) out.push({ k: 'kenh' + c + '_' + x.hang, ten, thieu: [`hàng ${x.hang} có Ngày đăng nhưng Trạng thái (cột ${String.fromCharCode(65 + cfg.cot.tt)}) chưa "ĐÃ DUYỆT" (đang: "${x.tt || 'trống'}")${x.tep ? '' : ', chưa có video'}${x.cap ? '' : ', chưa có caption'}`] });
    }
    return out;
  }
