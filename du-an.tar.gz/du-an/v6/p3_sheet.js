
  // =====================================================================
  //  Đọc dữ liệu sheet (2 tab) — chỉ đọc 13:30 + 18:30 (và khi bấm nút)
  // =====================================================================
  function chuO(cell) {
    if (cell == null) return '';
    if (typeof cell === 'string') return cell;
    if (typeof cell === 'number') return String(cell);
    if (Array.isArray(cell)) return cell.map((s) => (typeof s === 'string' ? s : (s && !s.fileToken && (s.text != null ? s.text : (s.link || ''))) || '')).join('');
    if (typeof cell === 'object' && cell.text != null && !cell.fileToken) return String(cell.text);
    return '';
  }
  const coTep = (c) => !!c && (Array.isArray(c) ? c.some((x) => x && x.fileToken) : !!c.fileToken);
  function ngayO(cell) {
    if (typeof cell === 'number' && cell > 20000 && cell < 80000) {
      const d = new Date(Date.UTC(1899, 11, 30) + Math.floor(cell + 1e-6) * 86400000);
      return `${pad(d.getUTCDate())}-${pad(d.getUTCMonth() + 1)}-${d.getUTCFullYear()}`;
    }
    const s = chuO(cell);
    const m = s.match(/(\d{1,2})\s*[-\/.]\s*(\d{1,2})\s*[-\/.]\s*(\d{4})/);
    if (!m) { const q = s.match(/(\d{4})\s*[-\/.]\s*(\d{1,2})\s*[-\/.]\s*(\d{1,2})/); if (q) return `${pad(q[3])}-${pad(q[2])}-${q[1]}`; } // (6.19.3) dạng năm-tháng-ngày
    return m ? `${pad(m[1])}-${pad(m[2])}-${m[3]}` : '';
  }
  const COT_BAT_BUOC = [
    { cot: 'A', chiSo: 0, chua: 'từ khóa', ten: 'Từ khóa chính' },
    { cot: 'B', chiSo: 1, chua: 'không có ảnh', ten: 'Bài twist (không có ảnh)' },
    { cot: 'C', chiSo: 2, chua: 'cmt bài 1', ten: 'Cmt bài 1' },
    { cot: 'H', chiSo: 7, chua: 'ngày đăng', ten: 'Ngày đăng' },
  ];
  function kiemTenCot(values) {
    const h = values[0] || [];
    for (const c of COT_BAT_BUOC) {
      if (!thuong(chuO(h[c.chiSo])).includes(c.chua)) return `Tên cột ${c.cot} tab "Bài viết kênh 1" không còn là "${c.ten}" (đang là "${chuan(chuO(h[c.chiSo])) || 'trống'}") — script không đọc để tránh đăng nhầm cột`;
    }
    return null;
  }
  // ô ảnh của Lark: { fileToken, ... } hoặc danh sách → danh sách mã ảnh
  function tokenAnh(c) {
    if (!c) return [];
    if (Array.isArray(c)) return c.reduce((a, x) => a.concat(tokenAnh(x)), []);
    if (typeof c === 'object' && c.fileToken && (c.type === 'embed-image' || /^image\//.test(c.mimeType || '') || /\.(jpe?g|png|webp|heic|gif)$/i.test(c.text || '') || !c.mimeType)) return [String(c.fileToken)];
    return [];
  }
  const anhNhieuO = (r, tu, den) => { let a = []; for (let i = tu; i <= den; i++) a = a.concat(tokenAnh(r[i])); return a; };
  function tepVideo(c) {
    const ds = Array.isArray(c) ? c : (c && c.fileToken ? [c] : []);
    const t = ds.find((x) => x && x.fileToken && (/^video\//.test(x.mimeType || '') || /\.(mp4|mov|m4v|webm)$/i.test(x.text || '')));
    return t ? { fileToken: t.fileToken, size: t.size || 0, ten: t.text || 'video.mp4', mime: t.mimeType || 'video/mp4' } : null;
  }
  function tepNhac(c) {
    const ds = Array.isArray(c) ? c : (c && c.fileToken ? [c] : []);
    const t = ds.find((x) => x && x.fileToken && (/^audio\//.test(x.mimeType || '') || /\.(mp3|m4a|aac|wav|ogg)$/i.test(x.text || '')));
    return t ? { fileToken: t.fileToken, size: t.size || 0, ten: t.text || 'nhac.mp3', mime: t.mimeType || 'audio/mpeg' } : null;
  }
  // (6.20.2) ảnh cố định cho comment (tab Bài viết kênh 1): ô O2 (cả 3 kênh) + 1 ảnh ngẫu nhiên: kênh 1 lấy trong P2:P10, kênh 2 & 3 lấy trong Q2:Q10 (ô trống bỏ qua)
  function anhChung(v) {
    const r2 = v[1] || []; const cot = (c) => { const o = []; for (let i = 1; i <= 9; i++) o.push(...tokenAnh((v[i] || [])[c])); return o; };
    return { co: tokenAnh(r2[14])[0] || '', pool: cot(15), poolK: cot(16) };
  }
  function hangCuaNgay(values, ngay) {
    const out = [];
    for (let i = 1; i < values.length; i++) {
      const r = values[i] || [];
      if (ngayO(r[7]) === ngay) {
        out.push({ hang: i + 1, bai: chuO(r[1]).trim(), cmt: chuO(r[2]).trim(), bai2: chuO(r[3]).trim(), cmt2: chuO(r[4]).trim(), bai3: chuO(r[5]).trim(),
          anh2: anhNhieuO(r, 8, 10), anh3: anhNhieuO(r, 11, 13), anhCmt: anhNhieuO(r, 14, 16), trangThai: chuO(r[6]).trim() });
      }
    }
    return out;
  }
  // tab "Kênh 1 Vòng Trầm Hương SMH": K = ngày đăng, N = file video, E = chữ đăng video, G = chữ manifest, H = ảnh manifest, J = trạng thái, B = link
  function videoCuaNgay(values, ngay) {
    const v = [], m = [];
    for (let i = 1; i < values.length; i++) {
      const r = values[i] || [];
      if (ngayO(r[10]) !== ngay) continue;
      const tep = tepVideo(r[CAI_DAT.COT_VIDEO_K1]); const cap = chuO(r[4]).trim();
      if (tep || cap) v.push({ hang: i + 1, cap, tep, daDang: /đã đăng/i.test(chuO(r[9])), link: chuO(r[1]).trim() });
      const chu = coTep(r[6]) ? '' : chuO(r[6]).trim(); const anh = tokenAnh(r[7])[0] || '';
      if (chu || anh) m.push({ hang: i + 1, chu, anh });
    }
    return { v, m };
  }
  // hàng mới (nằm dưới hàng cuối cùng có ngày) đã có nội dung nhưng CHƯA ghi ngày đăng → script chưa biết đăng ngày nào
  function hangChuaNgay(values, cotNgay, coNoiDung, cotTT) {
    let cuoi = 0, ngayXa = '';
    const soNgay = (n) => { const m = n.match(/^(\d{2})-(\d{2})-(\d{4})$/); return m ? `${m[3]}${m[2]}${m[1]}` : ''; };
    for (let i = 1; i < values.length; i++) { const n = ngayO((values[i] || [])[cotNgay]); if (n) { cuoi = i; if (soNgay(n) > ngayXa) ngayXa = soNgay(n); } }
    // sheet đã ghi ngày cho hơn 3 ngày tới → chưa cần nhắc (các hàng chưa ghi ngày còn lâu mới tới lượt)
    if (ngayXa && ngayXa > soNgay(ngayStr(congNgay(3)))) return [];
    const out = [];
    for (let i = cuoi + 1; i < values.length; i++) {
      const r = values[i] || [];
      if (ngayO(r[cotNgay]) || /đã đăng/i.test(chuO(r[cotTT]))) continue;
      if (coNoiDung(r)) out.push(i + 1);
    }
    return out;
  }
  function gonHang(ds) { // [220,221,222,223,230] → "220–223, 230"
    const out = []; let a = null, b = null;
    for (const x of ds) { if (b !== null && x === b + 1) { b = x; continue; } if (a !== null) out.push(a === b ? String(a) : `${a}–${b}`); a = b = x; }
    if (a !== null) out.push(a === b ? String(a) : `${a}–${b}`);
    return out.join(', ');
  }

  // dữ liệu đã đọc (lưu trong Tampermonkey) — dùng cho cả ngày, không đọc lại
  const duLieu = () => lay('du_lieu6', null);
  // ---- (6.19) kênh 2, 3: tab riêng — mỗi dòng có Ngày đăng (H) + Trạng thái (G) + video (I) + caption (E/D) ----
  const vungKenh = (c) => 'A1:' + String.fromCharCode(65 + Math.max(9, ...Object.values(CAI_DAT.KENH[c].cot))) + '3000'; // (6.26) đọc tới cột link xa nhất (Hà Xá: K)
  function kiemCotKenh(values, c) {
    const h = (values || [])[0] || []; const cfg = CAI_DAT.KENH[c]; const t = (i) => thuong(chuO(h[i]));
    const sai = [];
    if (!t(cfg.cot.ngay).includes('ngày đăng')) sai.push(`cột ${String.fromCharCode(65 + cfg.cot.ngay)} không phải "Ngày đăng" (đang là "${chuan(chuO(h[cfg.cot.ngay])) || 'trống'}")`);
    if (!t(cfg.cot.tt).includes('trạng thái')) sai.push(`cột ${String.fromCharCode(65 + cfg.cot.tt)} không phải "Trạng thái"`);
    if (!t(cfg.cot.video).includes('video')) sai.push(`cột ${String.fromCharCode(65 + cfg.cot.video)} không phải "VIDEO"`);
    if (!/tiêu đề|caption|fb/.test(t(cfg.cot.cap))) sai.push(`cột ${String.fromCharCode(65 + cfg.cot.cap)} không phải "Tiêu đề FB/Tiktok"`);
    return sai.length ? `Tab "${cfg.tenTab}": ${sai.join('; ')} — script không đọc ${tenKenh(c)} để tránh đăng nhầm cột` : null;
  }
  function hangKenh(values, c, ngay) { // mọi dòng ghi ngày này (kể cả chưa duyệt — để cảnh báo)
    const cfg = CAI_DAT.KENH[c]; const out = [];
    for (let i = 1; i < (values || []).length; i++) {
      const r = values[i] || []; if (ngayO(r[cfg.cot.ngay]) !== ngay) continue;
      const tt = chuan(chuO(r[cfg.cot.tt]));
      const tep = tepVideo(r[cfg.cot.video]); const daDang = /đã đăng/i.test(tt);
      out.push({ hang: i + 1, cap: chuO(r[cfg.cot.cap]).trim(), tep, tt, duyet: cfg.khongDuyet ? (!!tep && !daDang) : /đã duyệt/i.test(tt), daDang, link: chuO(r[cfg.cot.link]).trim() }); // (6.26) kênh Hà Xá: có video là đăng
    }
    return out;
  }
  function phanTich(vB, vV, loai, vK) {
    vK = vK || {};
    const loiCot = kiemTenCot(vB);
    const out = { luc: Date.now(), loai, ban: 2, loiCot, chung: anhChung(vB), ngay: {}, loiKenh: {},
      chuaNgayV: hangChuaNgay(vV, 10, (r) => !!(tepVideo(r[CAI_DAT.COT_VIDEO_K1]) || tokenAnh(r[7]).length || (!coTep(r[6]) && chuO(r[6]).trim())), 9),
      chuaNgayB: loiCot ? [] : hangChuaNgay(vB, 7, (r) => !!(chuO(r[1]).trim() || chuO(r[3]).trim() || chuO(r[5]).trim()), 6) };
    for (let i = 0; i <= 3; i++) {
      const ngay = ngayStr(congNgay(i));
      const hs = loiCot ? [] : hangCuaNgay(vB, ngay);
      const vm = videoCuaNgay(vV, ngay);
      out.ngay[ngay] = { bai: hs[0] || null, bais: hs, soHangBai: hs.length, v: vm.v, m: vm.m };
    }
    for (const c of KENH_PHU) {
      const x = vK[c]; if (!x) continue;
      if (x.loi) { out.loiKenh[c] = x.loi; continue; }
      const lc = kiemCotKenh(x.values, c); if (lc) { out.loiKenh[c] = lc; continue; }
      for (let i = 0; i <= 3; i++) { const ngay = ngayStr(congNgay(i)); out.ngay[ngay]['k' + c] = hangKenh(x.values, c, ngay); }
    }
    return out;
  }
  let docDLCho = null;
  async function docDuLieu(loai) {
    if (docDLCho) return docDLCho;
    docDLCho = (async () => {
      let vB, vV, vZ = null; const vK = {};
      try { // (6.20.8) đọc 4 tab + ô Z3:Z4 (cài comment, kho thẻ) trong 1 lượt gọi
        const g = await docNhieu([[CAI_DAT.TAB_BAI, 'A1:Q3000'], [CAI_DAT.TAB_VIDEO, 'A1:N3000'], [CAI_DAT.TAB_BAI, CAI_DAT.O_CMT + ':' + CAI_DAT.O_THE]].concat(KENH_PHU.map((c) => [CAI_DAT.KENH[c].tab, vungKenh(c)])));
        vB = g[0]; vV = g[1]; vZ = g[2]; KENH_PHU.forEach((c, i) => { vK[c] = { values: g[3 + i] }; }); // (6.26) gộp cả tab kênh Hà Xá trong cùng 1 lượt đọc
      } catch (e0) {
        if (e0 instanceof LoiLark) throw e0;
        ghi('Đọc gộp sheet chưa được (' + e0.message + ') → đọc từng tab');
        vB = await docBang(CAI_DAT.TAB_BAI, 'A1:Q3000');
        vV = await docBang(CAI_DAT.TAB_VIDEO, 'A1:N3000');
        for (const c of KENH_PHU) { // (6.19) kênh 2, 3, Hà Xá — đọc lỗi thì kênh 1 vẫn chạy bình thường
          try { vK[c] = { values: await docBang(CAI_DAT.KENH[c].tab, vungKenh(c)) }; } catch (e) { if (e instanceof LoiLark) throw e; vK[c] = { loi: `chưa đọc được tab "${CAI_DAT.KENH[c].tenTab}" (${e.message})` }; }
        }
      }
      const d = phanTich(vB, vV, loai, vK);
      luu('du_lieu6', d);
      await dongBoCmt(vZ ? (vZ[0] || [])[0] : undefined);
      await dongBoThe(vZ ? (vZ[1] || [])[0] : undefined);
      try { dongBoLich(); } catch (e) { ghi('Cập nhật lịch kênh 2, 3 lỗi: ' + e.message); }
      try { thuLaiBaiThieu(d); } catch (e) { /* */ }
      const n = d.ngay[homNay()] || {};
      ghi(`Đọc Lark sheet (${({ nhe: 'lượt 13:30', chot: 'lượt 18:30', tay: 'bấm tay', thieu: 'chưa có dữ liệu hôm nay', thieuGio: 'có bài thiếu nội dung, đọc lại mỗi giờ', sang: 'đầu ngày, dữ liệu cũ từ hôm qua', suckhoe: 'tự kiểm tra sáng', nhacmai: 'trước khi nhắc điền sheet ngày mai' })[loai] || loai}): hôm nay có ${n.bai ? 'bài viết' : 'CHƯA có bài viết'}, ${(n.v || []).length} video, ${(n.m || []).length} manifest${d.chuaNgayV.length + d.chuaNgayB.length ? ` · ${d.chuaNgayV.length + d.chuaNgayB.length} hàng có nội dung nhưng chưa ghi ngày đăng (${[d.chuaNgayV.length ? 'tab Kênh 1 hàng ' + gonHang(d.chuaNgayV) : '', d.chuaNgayB.length ? 'tab Bài viết hàng ' + gonHang(d.chuaNgayB) : ''].filter(Boolean).join('; ')})` : ''}${d.loiCot ? ' — ' + d.loiCot : ''}${KENH_PHU.map((c) => d.loiKenh && d.loiKenh[c] ? ` — ${tenKenh(c)}: ${d.loiKenh[c]}` : ` · ${tenKenh(c)}: ${((n['k' + c] || []).filter((x) => x.duyet || x.daDang)).length} video hôm nay`).join('')}`);
      return d;
    })();
    try { return await docDLCho; } finally { docDLCho = null; }
  }
  // nội dung của 1 bài trong lịch (k = b1…m3) theo dữ liệu đã đọc
  function noiDungSlot(ngay, k, d = duLieu()) {
    const it = LICH.find((x) => x.k === k) || lichNgay(ngay, d).find((x) => x.k === k) || { k, loai: 'video', so: 0, kenh: kenhCua(k), ten: tenSlot(k) }; const n = d && d.ngay && d.ngay[ngay];
    if (!n) return { thieu: ['chưa đọc được sheet của ngày này'] };
    const gd = laSlotDong(it) ? ganDong(ngay, d) : null; // (6.19.3) video / manifest / kênh 2, 3: bài nào gắn với DÒNG nào trong sheet (không theo thứ tự)
    const matDong = gd && gd.map[k] === null; // dòng của bài này đã bị xoá / đổi chữ trong sheet sau khi bài đã làm
    if ((it.kenh || 1) > 1) { // (6.19) video kênh 2, 3
      const c = it.kenh; const cfg = CAI_DAT.KENH[c]; const th = [];
      if (d.loiKenh && d.loiKenh[c]) return { thieu: [d.loiKenh[c]], text: '' };
      const x = gd && k in gd.map ? gd.map[k] : videoKenh(n, c)[it.so];
      if (matDong) return { thieu: ['dòng của video này không còn trong sheet (đã xoá / đổi caption / đổi trạng thái)'], text: '', kenh: c, matDong: true };
      const cot = (i) => String.fromCharCode(65 + i);
      if (!x) th.push(`video ${tenKenh(c)} thứ ${it.so + 1} (tab "${cfg.tenTab}" chưa có dòng ghi ngày này với Trạng thái "ĐÃ DUYỆT")`);
      else { if (!x.tep) th.push(`file video ${it.ten} (cột ${cot(cfg.cot.video)} hàng ${x.hang})`); if (!x.cap) th.push(`caption ${it.ten} (cột ${cot(cfg.cot.cap)} hàng ${x.hang})`); }
      return { thieu: th, text: x ? x.cap : '', tep: x ? x.tep : null, hang: x ? x.hang : 0, daDang: x ? x.daDang : false, link: x ? x.link : '', kenh: c };
    }
    const b = it.hangSo ? ((n.bais || [])[it.hangSo] || null) : n.bai; const th = []; // (6.26) bài của hàng thứ 2, 3… trong ngày
    if (it.loai === 'b1') { if (!b) th.push('bài viết (cột H chưa có hàng ghi ngày này)'); else if (!b.bai) th.push('chữ Bài 1 (cột B)'); if (b && b.bai && !b.cmt) th.push('comment Bài 1 (cột C)'); return { thieu: th, text: b ? b.bai : '', cmt: b ? b.cmt : '', hang: b ? b.hang : 0 }; }
    if (it.loai === 'b2') { if (!b) th.push('bài viết (cột H chưa có hàng ghi ngày này)'); else if (!b.bai2) th.push('chữ Bài 2 (cột D)'); else { if (!b.anh2.length) th.push('ảnh Bài 2 (cột I–K)'); if (!b.cmt2) th.push('comment Bài 2 (cột E)'); } return { thieu: th, text: b ? b.bai2 : '', cmt: b ? b.cmt2 : '', anh: b ? b.anh2 : [], hang: b ? b.hang : 0 }; }
    if (it.loai === 'b3') { if (!b) th.push('bài viết (cột H chưa có hàng ghi ngày này)'); else if (!b.bai3) th.push('chữ Bài 3 (cột F)'); else { if (!b.anh3.length) th.push('ảnh Bài 3 (cột L–N)'); } return { thieu: th, text: b ? b.bai3 : '', anh: b ? b.anh3 : [], anhCmt: b ? b.anhCmt : [], hang: b ? b.hang : 0 }; }
    if (matDong) return { thieu: [`dòng của ${it.ten} không còn trong sheet (đã xoá / đổi chữ)`], text: '', matDong: true };
    if (it.loai === 'video') { const x = gd && k in gd.map ? gd.map[k] : n.v[it.so]; if (!x) th.push(`video (cột K chưa có hàng thứ ${it.so + 1} ghi ngày này)`); else { if (!x.tep) th.push(`file video ${it.ten} (cột ${String.fromCharCode(65 + CAI_DAT.COT_VIDEO_K1)} hàng ${x.hang})`); if (!x.cap) th.push(`chữ đăng ${it.ten} (cột E hàng ${x.hang})`); } return { thieu: th, text: x ? x.cap : '', tep: x ? x.tep : null, hang: x ? x.hang : 0, daDang: x ? x.daDang : false }; }
    const x = gd && k in gd.map ? gd.map[k] : n.m[it.so]; if (!x) th.push(`manifest (cột K chưa có hàng thứ ${it.so + 1} ghi ngày này)`); else { if (!x.chu) th.push(`chữ ${it.ten} (cột G hàng ${x.hang})`); if (!x.anh) th.push(`ảnh ${it.ten} (cột H hàng ${x.hang})`); }
    return { thieu: th, text: x ? x.chu : '', anh: x ? x.anh : '', hang: x ? x.hang : 0 };
  }
  // danh sách thiếu của 1 ngày (cho cảnh báo vàng/đỏ trên popup)
  function thieuCuaNgay(ngay, d = duLieu()) {
    if (!d || !d.ngay || !d.ngay[ngay]) return null;
    const ds = [];
    for (const it of lichNgay(ngay, d)) { const nd = noiDungSlot(ngay, it.k, d); if (nd.thieu.length) ds.push({ k: it.k, ten: it.ten, thieu: nd.thieu }); }
    for (const w of canhBaoKenh(ngay, d)) ds.push(w);
    return ds;
  }
  // ---- (6.19) lịch theo ngày: 9 bài kênh 1 + video kênh 2, 3 (dòng có Ngày đăng = ngày đó VÀ Trạng thái "ĐÃ DUYỆT"; dòng đã "ĐÃ ĐĂNG" vẫn giữ chỗ) ----
  const videoKenh = (n, c) => ((n && n['k' + c]) || []).filter((x) => x.duyet || x.daDang);
  const CHU_SO = 'abcdefgh';
  // ---- (6.19.3) GHIM DÒNG: mỗi bài video / manifest / kênh 2, 3 gắn với 1 dòng cụ thể của sheet (số dòng + 40 ký tự đầu của chữ).
  //  Sheet thêm / xoá / đổi thứ tự dòng giữa ngày thì bài đã làm vẫn giữ đúng dòng của nó; dòng mới → bài mới (Video 4, Manifest 4, Kênh 2 · Video 3…)
  const SO_TOI_DA = { v: 9, m: 9 };
  const khoaDong = (x) => khoaSo(x ? (x.cap || x.chu || (x.anh ? 'anh' + x.anh : '')) : '').slice(0, 40);
  const nhomSlot = (k) => { const m = String(k || '').match(/^(v|m)(\d)$/); if (m) return { nhom: m[1], so: +m[2] - 1 }; const q = String(k || '').match(/^k([2-4])([a-h])$/); return q ? { nhom: 'k' + q[1], so: CHU_SO.indexOf(q[2]) } : null; };
  const laSlotDong = (it) => !!(it && nhomSlot(it.k));
  const keySlot = (nhom, i) => (nhom === 'v' || nhom === 'm' ? nhom + (i + 1) : nhom + CHU_SO[i]);
  function itSlot(nhom, i) {
    if (nhom === 'v' || nhom === 'm') { const goc = LICH_GOC.find((x) => x.k === keySlot(nhom, i)); if (goc) return goc; const vd = nhom === 'v'; return { k: keySlot(nhom, i), ten: `${vd ? 'Video' : 'Manifest'} ${i + 1}`, tenBC: `${vd ? 'Video' : 'Manifest'} ${i + 1} (thêm)`, loai: vd ? 'video' : 'manifest', so: i, kenh: 1, them: true }; }
    const c = +nhom[1]; return { k: keySlot(nhom, i), ten: `${tenKenh(c)} · Video ${i + 1}`, tenBC: `${tenKenhDai(c)} · Video ${i + 1}`, nhan: `${CAI_DAT.KENH[c].hx ? 'HX' : 'K' + c}·${i + 1}`, loai: 'video', so: i, kenh: c };
  }
  let ganDongNho = null;
  function ganDong(ngay, d = duLieu()) { // → { map: { key: dòng | null (mất dòng) }, keys: { v: [...], m: [...], k2: [...], k3: [...] }, gan: {...} }
    const n = d && d.ngay && d.ngay[ngay]; const s = lay('ngay6_' + ngay, null) || {}; const ss = s.s || {}; const ganCu = s.gan || {};
    const dau = ngay + '|' + ((d && d.luc) || 0) + '|' + JSON.stringify(ganCu) + '|' + Object.keys(ss).map((k) => k + ss[k].tt).join(',');
    if (ganDongNho && ganDongNho.dau === dau) return ganDongNho.kq;
    const map = {}, keys = {}, gan = {};
    const nhoms = [['v', n ? n.v || [] : []], ['m', n ? n.m || [] : []]];
    for (const c of KENH_PHU) if (!(d && d.loiKenh && d.loiKenh[c])) nhoms.push(['k' + c, videoKenh(n, c)]);
    for (const [nhom, rows] of nhoms) {
      const toiDa = SO_TOI_DA[nhom] || CHU_SO.length;
      // các ô đang có của nhóm này: ô cố định (3 ô kênh 1) + ô đã có trạng thái / đã ghim
      const co = new Set(nhom === 'v' || nhom === 'm' ? [0, 1, 2] : []);
      for (const k of Object.keys(ss).concat(Object.keys(ganCu))) { const g = nhomSlot(k); if (g && g.nhom === nhom && g.so < toiDa) co.add(g.so); }
      const dung = new Set(); const oMap = {};
      // 1) ô đã ghim: tìm lại đúng dòng theo chữ (ưu tiên cùng số dòng)
      for (const i of [...co].sort((a, b) => a - b)) {
        const k = keySlot(nhom, i); const b = ganCu[k]; if (!b || !b.khoa) continue;
        let j = rows.findIndex((x, jj) => !dung.has(jj) && x.hang === b.hang && khoaDong(x) === b.khoa);
        if (j < 0) j = rows.findIndex((x, jj) => !dung.has(jj) && khoaDong(x) === b.khoa);
        if (j >= 0) { dung.add(j); oMap[i] = j; }
      }
      // 2) dòng chưa có ô → ô trống (chưa ghim, hoặc mất dòng mà chưa làm) theo thứ tự; hết ô thì mở ô mới
      const daLam = (i) => { const r = ss[keySlot(nhom, i)]; return !!(r && r.tt && r.tt !== 'cho'); };
      const trong = [...co].sort((a, b) => a - b).filter((i) => !(i in oMap) && !(ganCu[keySlot(nhom, i)] && daLam(i)));
      for (let j = 0; j < rows.length; j++) {
        if (dung.has(j)) continue;
        let i = trong.shift();
        if (i === undefined) { i = 0; while (co.has(i)) i++; if (i >= toiDa) break; co.add(i); }
        dung.add(j); oMap[i] = j;
      }
      keys[nhom] = [...co].sort((a, b) => a - b).map((i) => keySlot(nhom, i));
      for (const i of co) {
        const k = keySlot(nhom, i);
        if (i in oMap) { const x = rows[oMap[i]]; map[k] = x; gan[k] = { hang: x.hang, khoa: khoaDong(x) }; }
        else if (ganCu[k] && daLam(i)) { map[k] = null; gan[k] = ganCu[k]; } // bài đã làm nhưng dòng của nó không còn → giữ ô, không gán dòng khác
        else map[k] = undefined;
      }
      // ô kênh 2, 3 / ô thêm của kênh 1 không còn dòng nào và chưa làm → bỏ khỏi lịch
      keys[nhom] = keys[nhom].filter((k) => { const g = nhomSlot(k); return map[k] !== undefined || (nhom === 'v' || nhom === 'm' ? g.so < 3 : false) || daLam(g.so); });
    }
    const kq = { map, keys, gan };
    ganDongNho = { dau, kq }; return kq;
  }
  // (6.26) ngày có nhiều hàng bài viết: hàng thứ r (từ 0) → Bài 3r+1 (twist), 3r+2 (twist + ảnh), 3r+3 (storytelling)
  const TEN_LOAI_BAI = { 1: 'twist', 2: 'twist + ảnh', 3: 'storytelling' };
  const itBai = (r, j) => ({ k: 'b' + (3 * r + j), ten: `Bài ${3 * r + j}`, tenBC: `Bài ${3 * r + j} ${TEN_LOAI_BAI[j]}`, loai: 'b' + j, hangSo: r, kenh: 1, baiThem: true });
  function lichNgay(ngay, d = duLieu()) {
    const gd = ganDong(ngay, d); const out = [];
    for (const it of LICH_GOC) if (!laSlotDong(it)) out.push(it); else { const g = nhomSlot(it.k); if ((gd.keys[g.nhom] || []).includes(it.k)) out.push(it); }
    { const nh = Math.min(6, (d && d.ngay && d.ngay[ngay] && d.ngay[ngay].soHangBai) || 0); for (let r = 1; r < nh; r++) for (let j = 1; j <= 3; j++) out.push(itBai(r, j)); } // (6.26) mỗi hàng bài viết thêm = 3 bài
    for (const nhom of ['v', 'm']) for (const k of gd.keys[nhom] || []) { const g = nhomSlot(k); if (g.so >= 3) out.push(itSlot(nhom, g.so)); }
    for (const c of KENH_PHU) for (const k of gd.keys['k' + c] || []) out.push(itSlot('k' + c, nhomSlot(k).so));
    return out;
  }
  function dongBoLich() { // LICH = lịch hôm nay (giữ chỗ cho video đã có trạng thái trong ngày, kể cả khi sheet đổi trạng thái sau đó)
    const ngay = homNay(); const moi = lichNgay(ngay); const s = lay('ngay6_' + ngay, null);
    if (s && s.s) for (const k of Object.keys(s.s)) { const g = nhomSlot(k); if (g && !moi.some((x) => x.k === k) && s.s[k] && s.s[k].tt !== 'cho') moi.push(itSlot(g.nhom, g.so)); const bm = /^b(\d+)$/.exec(k); if (bm && +bm[1] > 3 && !moi.some((x) => x.k === k) && s.s[k] && s.s[k].tt !== 'cho') moi.push(itBai(Math.floor((+bm[1] - 1) / 3), ((+bm[1] - 1) % 3) + 1)); } // bài đã làm vẫn giữ chỗ
    { const d0 = duLieu(); if (s && d0 && d0.ngay && d0.ngay[ngay]) { const gd = ganDong(ngay, d0); if (JSON.stringify(gd.gan) !== JSON.stringify(s.gan || {})) { const s2 = lay('ngay6_' + ngay, null); if (s2) { s2.gan = gd.gan; luu('ngay6_' + ngay, s2); } } } } // (6.19.3) lưu ghim dòng
    const cu = LICH.map((x) => x.k).join(',');
    LICH.length = 0; for (const it of moi) LICH.push(it);
    if (LICH.map((x) => x.k).join(',') !== cu) { const tm = LICH.filter((x) => x.them); const dauT = ngay + '|' + tm.map((x) => x.k).join(','); if (tm.length && lay('lich_t6', '') !== dauT) { luu('lich_t6', dauT); ghi(`Sheet hôm nay có thêm ${tm.length} bài kênh 1 ngoài 9 bài thường lệ: ${tm.map((x) => x.ten).join(', ')} → đã xếp lịch`); } }
    if (LICH.map((x) => x.k).join(',') !== cu) { const them = LICH.filter((x) => x.kenh > 1); const dau = ngay + '|' + them.map((x) => x.k).join(','); if (lay('lich_k6', '') !== dau) { luu('lich_k6', dau); ghi(`Lịch hôm nay có ${them.length} video kênh 2, 3, Hà Xá: ${them.map((x) => x.ten).join(', ') || '(không có)'}`); } }
    return LICH;
  }
  // cảnh báo cho nhân sự sửa sheet kênh 2, 3 (popup + 16:00 hôm trước)
  function canhBaoKenh(ngay, d = duLieu()) {
    const out = []; const n = d && d.ngay && d.ngay[ngay]; if (!n) return out;
    for (const c of KENH_PHU) {
      const cfg = CAI_DAT.KENH[c]; const ten = tenKenhDai(c);
      if (d.loiKenh && d.loiKenh[c]) { out.push({ k: 'kenh' + c, ten, thieu: [d.loiKenh[c]] }); continue; }
      const ds = n['k' + c]; if (!ds) continue;
      if (!ds.length) { out.push({ k: 'kenh' + c, ten, thieu: [`chưa có dòng nào ghi Ngày đăng ${ngay.replace(/-/g, '/')} (tab "${cfg.tenTab}" cột ${String.fromCharCode(65 + cfg.cot.ngay)})`] }); continue; }
      for (const x of ds) if (!x.duyet && !x.daDang && cfg.khongDuyet) out.push({ k: 'kenh' + c + '_' + x.hang, ten, thieu: [`hàng ${x.hang} có Ngày đăng nhưng chưa có video (cột ${String.fromCharCode(65 + cfg.cot.video)})`] });
        else if (!x.duyet && !x.daDang) out.push({ k: 'kenh' + c + '_' + x.hang, ten, thieu: [`hàng ${x.hang} có Ngày đăng nhưng Trạng thái (cột ${String.fromCharCode(65 + cfg.cot.tt)}) chưa "ĐÃ DUYỆT" (đang: "${x.tt || 'trống'}")${x.tep ? '' : ', chưa có video'}${x.cap ? '' : ', chưa có caption'}`] });
    }
    return out;
  }
