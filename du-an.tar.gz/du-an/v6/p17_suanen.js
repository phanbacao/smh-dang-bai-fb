  // (6.26.6) Sửa nền đỏ — Facebook có 2 kiểu màn sửa:
  //  • kênh 1 mới: hộp nổi "Chỉnh sửa bài viết" — nút gỡ "Gỡ file đính kèm trong bài viết" (gỡ ảnh xong có thể hiện thêm bản đồ check-in → gỡ tiếp),
  //    nút Aa chỉ hiện khi đã gỡ hết → chọn nền → Tiếp → "Cài đặt bài viết" → Lưu
  //  • kênh 1 cũ: màn sửa toàn trang /post/edit/ (form "Bài viết", nút "Gỡ ảnh" từng ảnh, nút Lưu ở cuối cột trái); đôi khi tải mãi không xong → tải lại thẳng màn sửa
  const NUT_GO_NEN = '[aria-label="Gỡ ảnh"],[aria-label="Gỡ file đính kèm trong bài viết"]';
  const NUT_AA_NEN = '[aria-label="Hiển thị các tùy chọn phông nền"]';
  const laNutLuu = (x) => dangHien(x) && (chuan(x.innerText) === 'Lưu' || x.getAttribute('aria-label') === 'Lưu') && x.getAttribute('aria-disabled') !== 'true';
  function gocSuaNen() {
    if (dangODuongSua()) {
      const f = document.querySelector('[role="form"][aria-label="Bài viết"]'); if (!f) return null;
      let r = f; while (r && r !== document.body && !Array.from(r.querySelectorAll('[role="button"],[aria-label="Lưu"]')).some(laNutLuu)) r = r.parentElement;
      return { goc: r || document.body, kieu: 'trang' };
    }
    const ds = Array.from(document.querySelectorAll('[role="dialog"]')).filter((d) => dangHien(d) && /Chỉnh sửa bài viết/.test(d.innerText || '') && (d.querySelector('[contenteditable="true"],[role="textbox"]') || d.querySelector(NUT_GO_NEN + ',' + NUT_AA_NEN)));
    ds.sort((a, c) => c.querySelectorAll('[aria-label]').length - a.querySelectorAll('[aria-label]').length);
    return ds[0] ? { goc: ds[0], kieu: 'hop' } : null;
  }
  const hopCaiDatNen = () => Array.from(document.querySelectorAll('[role="dialog"]')).find((d) => dangHien(d) && /Cài đặt bài viết/.test(d.innerText || ''));
  async function thaoTacNen(kieu) {
    const goc = () => { const g = gocSuaNen(); return g ? g.goc : null; };
    const tim = (sel) => { const r = goc(); return r ? Array.from(r.querySelectorAll(sel)).find(dangHien) : null; };
    ghi('Sửa nền: đã mở ' + (kieu === 'trang' ? 'màn sửa toàn trang (kiểu kênh 1 cũ)' : 'hộp chỉnh sửa (kiểu kênh 1 mới)'));
    await sleep(1200);
    let soGo = 0;
    for (let i = 0; i < 20; i++) { const x = tim(NUT_GO_NEN); if (!x) break; ganBam(x); soGo++; await sleep(1300); }
    if (tim(NUT_GO_NEN)) throw new Error('chưa gỡ hết ảnh / file đính kèm');
    ghi('Sửa nền: đã gỡ ' + soGo + ' ảnh / file đính kèm');
    const aa = await cho(() => tim(NUT_AA_NEN), 10000);
    if (!aa) throw new Error('không thấy nút Aa (phông nền)');
    const timSw = () => tim(`[aria-label^="${CAI_DAT.NEN}"]`);
    ganBam(aa); await sleep(900);
    let sw = await cho(timSw, 6000);
    if (!sw) { const a2 = tim(NUT_AA_NEN); if (a2) ganBam(a2); sw = await cho(timSw, 6000); }
    if (!sw) throw new Error('không thấy nền "' + CAI_DAT.NEN + '"');
    ganBam(sw); await sleep(1000);
    ghi('Sửa nền: đã chọn nền ' + CAI_DAT.NEN);
    const luuNut = () => { const r = goc(); const a = r && Array.from(r.querySelectorAll('[role="button"],[aria-label="Lưu"]')).find(laNutLuu); if (a) return a; const d = hopCaiDatNen(); return d ? Array.from(d.querySelectorAll('[role="button"],[aria-label="Lưu"]')).find(laNutLuu) : null; };
    const nutTiep = () => { const r = goc(); return r ? Array.from(r.querySelectorAll('[aria-label="Tiếp"],[role="button"]')).find((x) => dangHien(x) && (x.getAttribute('aria-label') === 'Tiếp' || chuan(x.innerText) === 'Tiếp') && x.getAttribute('aria-disabled') !== 'true') : null; };
    const conMo = () => (kieu === 'trang' ? dangODuongSua() : (!!goc() || !!hopCaiDatNen()));
    let nl = await cho(() => luuNut() || nutTiep(), 8000);
    if (nl && !luuNut()) { ganBam(nl); ghi('Sửa nền: đã bấm Tiếp, chờ màn Cài đặt bài viết'); nl = await cho(luuNut, 12000); }
    if (!nl) throw new Error('không thấy nút Lưu');
    ganBam(nl);
    if (!(await cho(() => !conMo(), 15000))) {
      const nl2 = luuNut(); if (nl2) { ghi('Sửa nền: bấm Lưu lần 1 chưa ăn → bấm lại'); nl2.click(); }
      if (!(await cho(() => !conMo(), 20000))) throw new Error('bấm Lưu nhưng màn sửa chưa đóng');
    }
  }
  async function suaNenDo(b) {
    const art = b.khung.closest('[role="article"]') || b.khung;
    const nutBa = () => art.querySelector('[aria-label^="Hành động đối với bài viết này"]') || b.khung.querySelector('[aria-label^="Hành động đối với bài viết này"]');
    const n1 = await cho(nutBa, 10000); if (!n1) throw new Error('không thấy nút ⋯ của bài');
    window.__smhMoSua = Date.now();
    ganBam(n1);
    const timMenu = () => Array.from(document.querySelectorAll('[role="menuitem"]')).find((x) => dangHien(x) && /Chỉnh sửa bài viết/.test(x.innerText));
    let mn = await cho(timMenu, 6000);
    if (!mn) { n1.click(); mn = await cho(timMenu, 6000); }
    if (!mn) throw new Error('không thấy mục "Chỉnh sửa bài viết"');
    ganBam(mn);
    let g = await cho(gocSuaNen, 15000, 500);
    if (!g && dangODuongSua()) { ghi('Sửa nền: màn sửa toàn trang (kênh 1 cũ) tải chậm → chờ thêm'); g = await cho(gocSuaNen, 20000, 1000); }
    if (!g && dangODuongSua()) {
      luu('suanen_url6', { t: Date.now() }); window.__smhMoSua = Date.now();
      ghi('Sửa nền: màn sửa toàn trang tải mãi không xong → tải lại thẳng màn sửa (F5)');
      await sleep(500); roiTrang(location.href); await sleep(60000); // (6.28) qua roiTrang để gỡ hộp "Rời khỏi trang?" throw new Error('đang tải lại màn sửa');
    }
    if (!g) throw new Error('không mở được hộp chỉnh sửa bài viết');
    window.__smhMoSua = Date.now();
    await thaoTacNen(g.kieu);
    await sleep(4000);
    // kiểm lại trên bài: không còn ảnh lớn (ngoài phần comment)
    const conAnhF = () => { const b2 = timBai(b.bai || '') || b; return !!(b2 && b2.khung && Array.from(b2.khung.querySelectorAll('img')).some((im) => { const a = im.closest('[role="article"]'); return (!a || a === b2.khung || !b2.khung.contains(a)) && im.getBoundingClientRect().width > 150; })); };
    if (conAnhF()) { ghi('Sửa nền: đã Lưu nhưng trang chưa vẽ lại → chờ thêm (tối đa 25 giây)'); if (!(await cho(() => !conAnhF(), 25000, 1500))) { const api = await baiConAnhApi(b.bai || ''); if (api === false) { ghi('Sửa nền: trang chưa cập nhật nhưng Facebook (API) xác nhận bài KHÔNG còn ảnh → coi như đã sửa xong'); } else { try { const b2 = timBai(b.bai || '') || b; const ds = Array.from(b2.khung.querySelectorAll('img')).filter((im) => im.getBoundingClientRect().width > 100).map((im) => Math.round(im.getBoundingClientRect().width) + 'x' + Math.round(im.getBoundingClientRect().height) + ':' + (im.alt || '').slice(0, 30)); ghi('Sửa nền: ảnh còn thấy trên bài: ' + (ds.join(' | ') || 'không rõ') + (api === null ? ' · chưa hỏi được Facebook (API)' : ' · Facebook (API) cũng báo còn ảnh')); } catch (e) { /* */ } ghi('Sửa nền: đã Lưu, hộp sửa đã đóng — bài vẫn hiện ảnh (Facebook vẫn giữ ảnh khi có nền, bình thường) → coi như xong'); return; } } }
    ghi('Sửa nền: đã Lưu bài (nền đỏ, không còn ảnh)');
  }
  // (6.26.6) màn sửa toàn trang vừa được script tải lại (F5) → làm tiếp việc sửa nền ngay trên màn này
  async function suaNenSauTaiLai(dd) {
    const f = lay('suanen_url6', null);
    if (!dangODuongSua() || !f || Date.now() - (f.t || 0) > 3 * 60000) return false;
    luu('suanen_url6', null); window.__smhMoSua = Date.now();
    try {
      const g = await cho(gocSuaNen, 40000, 1000); if (!g) throw new Error('màn sửa toàn trang vẫn tải không xong');
      await thaoTacNen(g.kieu); dd.suaNenXong = true; ghi('Sửa nền: đã Lưu bài (nền đỏ) sau khi tải lại màn sửa');
    } catch (e) { ghi('Sửa nền đỏ (sau khi tải lại màn sửa) lỗi: ' + e.message); try { await dongManHinhSua(); } catch (e2) { /* */ } }
    luu('dang_do', dd); await sleep(1500); roiTrang(dd.viaLink || CAI_DAT.URL_TRANG); return true;
  }
  function dongHopSua() {
    try {
      if (dangODuongSua()) { dongManHinhSua().catch(() => {}); return; } // kênh 1 cũ: màn sửa toàn trang → Quay lại → "Rời khỏi"
      const g = gocSuaNen(); const cd = hopCaiDatNen(); if (!g && !cd) return;
      const ql = cd && cd.querySelector('[aria-label="Quay lại"]'); if (ql) ql.click();
      const dong = () => { const h = (gocSuaNen() || {}).goc || hopCaiDatNen(); const x = h && h.querySelector('[aria-label="Đóng hộp thoại của công cụ tạo"],[aria-label="Đóng"]'); if (x) ganBam(x); };
      if (ql) setTimeout(dong, 900); else dong();
      setTimeout(() => { const h2 = hopThoai((d) => /Bỏ|Hủy bỏ|Huỷ bỏ/.test(d.innerText) && /thay đổi|chỉnh sửa/i.test(d.innerText)); const bo = h2 && Array.from(h2.querySelectorAll('[role="button"]')).find((y) => /^(Bỏ|Hủy bỏ|Huỷ bỏ)$/.test(chuan(y.innerText))); if (bo) ganBam(bo); }, ql ? 2400 : 1500);
    } catch (e) { /* */ }
  }
