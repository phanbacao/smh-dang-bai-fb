
  // =====================================================================
  //  (6.24) HỘP SỬA KIỂU MỚI "Chỉnh sửa bài viết" (trang kênh 1 mới):
  //  Gắn thẻ người khác → Xong · Cảm xúc/hoạt động → chọn · Tiếp → Cài đặt bài viết → Lưu
  //  (đã thử trực tiếp trên Video 5 ngày 17/10/2026)
  // =====================================================================
  const hopSuaMoi = () => {
    const ds = Array.from(document.querySelectorAll('[role="dialog"]')).filter((d) => dangHien(d) && /^Chỉnh sửa bài viết/.test(chuan(d.innerText)));
    return ds.find((d) => d.querySelector('[aria-label="Tiếp"]') && (d.querySelector('[aria-label="Gắn thẻ người khác"]') || d.querySelector('[aria-label="Cảm xúc/hoạt động"]'))) || null;
  };
  const laHopMoi = (d) => !!d && d !== 'roi' && /^Chỉnh sửa bài viết/.test(chuan(d.innerText || '')) && !!d.querySelector('[aria-label="Tiếp"]') && !nutTheoChu(d, 'Lưu');
  // (6.24.2) sau Tiếp: bài viết → "Cài đặt bài viết"; video/thước phim → "Cài đặt thước phim" (đã thử trực tiếp trên Manifest 6). Không nhận màn đăng thước phim mới (có nút Đăng)
  const hopCaiDatMoi = () => Array.from(document.querySelectorAll('[role="dialog"]')).find((d) => dangHien(d) && /^Cài đặt (bài viết|thước phim)/.test(chuan(d.innerText)) && !Array.from(d.querySelectorAll('[aria-label="Đăng"]')).some(dangHien)) || null;
  const dauHopMoi = (d) => thuong(chuan((d && d.innerText) || '').slice(0, 260));
  const moiCoCx = (d) => /đang[^a-zà-ỹ]{0,6}cảm thấy/.test(dauHopMoi(d));
  const moiCoThe = (d) => new RegExp('(cùng với|và)\\s+' + thuong(CAI_DAT.TAG_TEN) + '(?!\\s+\\.)').test(dauHopMoi(d));
  const lopTheo = (nhan) => Array.from(document.querySelectorAll('[role="dialog"]')).filter((d) => dangHien(d) && (d.getAttribute('aria-label') === nhan || chuan(d.innerText).startsWith(nhan))).pop() || null;
  // nội dung của lớp (Gắn thẻ / Cảm xúc) đôi khi nằm ngoài thẻ dialog → leo lên cha tới khi có đủ phần tử cần tìm
  const vungLop = (lop, chon, toiThieu) => { let r = lop; for (let i = 0; i < 8 && r && r.querySelectorAll(chon).length < (toiThieu || 1); i++) r = r.parentElement; return r || document; };
  const nutXong = () => Array.from(document.querySelectorAll('[role="button"]')).filter((b) => dangHien(b) && chuan(b.innerText) === 'Xong').pop() || null;

  async function ganTheMoi(lan) {
    kiemDung(); const t0 = Date.now();
    const bam2 = (el) => { if (lan) { try { ganBam(el); } catch (e) { el.click(); } } else el.click(); };
    const d = hopSuaMoi(); if (!d) throw new Error('hộp sửa đã đóng');
    if (moiCoThe(d)) return true;
    const nut = d.querySelector('[aria-label="Gắn thẻ người khác"]'); if (!nut) throw new Error('không thấy nút "Gắn thẻ người khác"');
    bam2(nut);
    const lop = await cho(() => lopTheo('Gắn thẻ người khác'), 8000, 300); if (!lop) throw new Error('không mở được bảng "Gắn thẻ người khác"');
    const ten = CAI_DAT.TAG_TEN; const tenT = thuong(ten);
    const daChon = () => Array.from(document.querySelectorAll('[aria-label]')).some((e) => dangHien(e) && new RegExp('^gỡ\\s+' + tenT + '\\s*$').test(thuong(chuan(e.getAttribute('aria-label')))));
    const timHang = () => Array.from(vungLop(lop, 'li[role="option"]').querySelectorAll('li[role="option"]')).find((li) => dangHien(li) && thuong(chuan(li.getAttribute('aria-label') || '')).startsWith('gắn thẻ ' + tenT + ','));
    if (!daChon()) {
      let hang = await cho(timHang, 2500, 300);
      if (!hang) { // không có sẵn trong gợi ý → gõ tìm
        const inp = Array.from(vungLop(lop, 'input').querySelectorAll('input')).find(dangHien);
        if (!inp) throw new Error('không thấy ô tìm trong bảng gắn thẻ');
        inp.focus(); document.execCommand('insertText', false, ten);
        if (!inp.value) { try { Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value').set.call(inp, ten); inp.dispatchEvent(new Event('input', { bubbles: true })); } catch (e) { /* */ } }
        hang = await cho(timHang, 9000, 400);
      }
      if (!hang) throw new Error(`không thấy Trang "${ten}" trong bảng gắn thẻ`);
      kiemDung(); bam2(hang.querySelector('[role="none"]') || hang);
      if (!(await cho(daChon, 6000, 300))) throw new Error('đã bấm chọn nhưng chưa thấy thẻ trong mục "Được gắn thẻ"');
    }
    const x = nutXong(); if (!x) throw new Error('không thấy nút "Xong"'); bam2(x);
    if (!(await cho(() => !lopTheo('Gắn thẻ người khác'), 6000, 300))) { const x2 = nutXong(); if (x2) { try { ganBam(x2); } catch (e) { x2.click(); } } }
    if (!(await cho(() => { const d2 = hopSuaMoi(); return d2 && moiCoThe(d2); }, 8000, 400))) throw new Error('đã chọn thẻ nhưng đầu hộp sửa chưa hiện "cùng với ' + ten + '"');
    ghi(`Gắn thẻ (hộp mới): đã gắn "${ten}" (${Math.round((Date.now() - t0) / 1000)} giây)`);
    return true;
  }
  async function camXucMoi(lan) {
    kiemDung(); const t0 = Date.now();
    const bam2 = (el) => { if (lan) { try { ganBam(el); } catch (e) { el.click(); } } else el.click(); };
    const d = hopSuaMoi(); if (!d) throw new Error('hộp sửa đã đóng');
    if (moiCoCx(d)) return 'đã có';
    const nut = d.querySelector('[aria-label="Cảm xúc/hoạt động"]'); if (!nut) throw new Error('không thấy nút "Cảm xúc/hoạt động"');
    bam2(nut);
    const lb = await cho(() => { const u = Array.from(document.querySelectorAll('ul[role="listbox"]')).find((x) => dangHien(x) && x.querySelectorAll('li[role="option"]').length > 10); return u || null; }, 9000, 400);
    if (!lb) throw new Error('không mở được bảng cảm xúc');
    const lis = Array.from(lb.querySelectorAll('li[role="option"]'));
    const coSan = CAI_DAT.CAM_XUC_CHON.filter((n) => lis.some((x) => chuan(x.innerText) === n));
    const ds = coSan.length ? coSan : ['hạnh phúc'];
    const nhan0 = ds[Math.floor(Math.random() * ds.length)];
    const li = lis.find((x) => chuan(x.innerText) === nhan0) || lis[0]; const nhan = chuan(li.innerText);
    kiemDung(); li.scrollIntoView({ block: 'center' }); await sleep(400);
    bam2(li.querySelector('[role="button"]') || li);
    let ok = await cho(() => { const d2 = hopSuaMoi(); return d2 && moiCoCx(d2); }, 6000, 300);
    if (!ok) { const li2 = Array.from(document.querySelectorAll('ul[role="listbox"] li[role="option"]')).find((x) => dangHien(x) && chuan(x.innerText) === nhan); if (li2) { try { ganBam(li2.querySelector('[role="button"]') || li2); } catch (e) { li2.click(); } } ok = await cho(() => { const d2 = hopSuaMoi(); return d2 && moiCoCx(d2); }, 6000, 300); }
    if (!ok) { dongBangCamXuc(); throw new Error(`đã chọn "${nhan}" nhưng đầu hộp sửa chưa hiện "đang cảm thấy"`); }
    ghi(`Cảm xúc (hộp mới): đã chọn "${nhan}" (${Math.round((Date.now() - t0) / 1000)} giây)`);
    return nhan;
  }
  async function luuHopMoi() {
    const t0 = Date.now(); const d = hopSuaMoi(); if (!d) throw new Error('hộp sửa đã đóng trước khi Lưu');
    const tiep = Array.from(d.querySelectorAll('[aria-label="Tiếp"]')).find((x) => dangHien(x) && x.getAttribute('aria-disabled') !== 'true');
    if (!tiep) throw new Error('nút "Tiếp" không bấm được');
    tiep.click();
    // (6.24.4) trên máy thật, khung "Cài đặt thước phim" chỉ chứa tiêu đề + Quay lại; nút Lưu nằm ở khung cha → leo lên tối đa 5 bậc để tìm
    const timLuu = () => { const c = hopCaiDatMoi(); if (!c) return null; let r = c; for (let i = 0; i < 6 && r; i++, r = r.parentElement) { const n = Array.from(r.querySelectorAll('[role="button"],[aria-label="Lưu"]')).find((x) => dangHien(x) && (chuan(x.innerText) === 'Lưu' || x.getAttribute('aria-label') === 'Lưu') && x.getAttribute('aria-disabled') !== 'true'); if (n) return n; } return null; };
    let l = await cho(timLuu, 10000, 300);
    if (!l) { const t2 = hopSuaMoi() && Array.from(hopSuaMoi().querySelectorAll('[aria-label="Tiếp"]')).find(dangHien); if (t2) { try { ganBam(t2); } catch (e) { t2.click(); } } l = await cho(timLuu, 8000, 300); }
    if (!l) { const ds = Array.from(document.querySelectorAll('[role="dialog"]')).filter(dangHien).map((d) => chuan(d.innerText).slice(0, 40)).join(' ¦ '); throw new Error('bấm Tiếp nhưng không thấy màn Cài đặt / nút Lưu (đang thấy: ' + (ds || 'không có hộp') + ')'); }
    l.click();
    const mo = () => !!(hopSuaMoi() || hopCaiDatMoi());
    if (!(await cho(() => !mo(), 15000, 400))) { const l2 = timLuu(); if (l2) { ghi('Lưu (hộp mới) lần 1 chưa ăn → bấm lại'); try { ganBam(l2); } catch (e) { l2.click(); } } if (!(await cho(() => !mo(), 20000, 400))) throw new Error('đã bấm Lưu nhưng hộp sửa chưa đóng'); }
    ghi(`Lưu (hộp mới): đã lưu, hộp đã đóng (${Math.round((Date.now() - t0) / 1000)} giây)`);
    return true;
  }
  // đóng hộp sửa kiểu mới không lưu: Quay lại (nếu đang ở Cài đặt) → nút đóng → "Bỏ"
  async function dongHopMoi() {
    for (let lan = 0; lan < 3 && (hopSuaMoi() || hopCaiDatMoi() || lopTheo('Gắn thẻ người khác') || lopTheo('Bạn đang cảm thấy thế nào?')); lan++) {
      for (const ten of ['Gắn thẻ người khác', 'Bạn đang cảm thấy thế nào?', 'Cài đặt bài viết', 'Cài đặt thước phim']) { if (/^Cài đặt/.test(ten) && !hopCaiDatMoi()) continue; const l = lopTheo(ten); const q = l && Array.from(vungLop(l, '[aria-label="Quay lại"]').querySelectorAll('[aria-label="Quay lại"]')).find(dangHien); if (q) { q.click(); await sleep(700); } }
      const h = Array.from(document.querySelectorAll('[role="dialog"]')).filter((d) => dangHien(d) && /^Chỉnh sửa bài viết/.test(chuan(d.innerText))).pop();
      const x = h && Array.from(document.querySelectorAll('[aria-label="Đóng hộp thoại của công cụ tạo"],[aria-label="Đóng"]')).find(dangHien);
      if (x) { if (lan) { try { ganBam(x); } catch (e) { x.click(); } } else x.click(); } else document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', code: 'Escape', keyCode: 27, which: 27, bubbles: true }));
      const hoi = await cho(() => hopThoai((d) => /Thay đổi chưa lưu|Bỏ bài viết|Hủy thay đổi|Huỷ thay đổi/i.test(d.innerText)), 3000, 300);
      if (hoi) { const bo = Array.from(hoi.querySelectorAll('[role="button"]')).find((y) => /^(Bỏ|Hủy bỏ|Huỷ bỏ|Bỏ thay đổi)$/.test(chuan(y.innerText))); if (bo) { if (lan) { try { ganBam(bo); } catch (e) { bo.click(); } } else bo.click(); } }
      await cho(() => !hopSuaMoi() && !hopCaiDatMoi(), 6000, 300);
    }
    const ok = !hopSuaMoi() && !hopCaiDatMoi();
    ghi(ok ? 'Đã đóng hộp "Chỉnh sửa bài viết" (không lưu)' : 'Chưa đóng được hộp "Chỉnh sửa bài viết" — cần đóng tay');
    return ok;
  }
  // làm trọn 1 lượt trên hộp kiểu mới: thẻ (kênh 1) + cảm xúc → Lưu. Trả { daLuu, the, nhan, khongCan }
  async function suaVideoMoi(laKenhPhu) {
    window.__smhMoHop = Date.now();
    try {
      const d = await cho(hopSuaMoi, 8000, 300); if (!d) throw new Error('hộp sửa kiểu mới chưa sẵn sàng');
      await sleep(600);
      const canThe = !laKenhPhu && !moiCoThe(d), canCx = !moiCoCx(d);
      if (!canThe && !canCx) return { daLuu: false, the: !laKenhPhu, nhan: 'đã có', khongCan: true };
      let the = !laKenhPhu && !canThe, nhan = '';
      if (canThe) { try { await ganTheMoi(0); the = true; } catch (e1) { if (e1 instanceof LoiDung || !hopSuaMoi()) throw e1; ghi('Gắn thẻ (hộp mới) lần 1 chưa được (' + e1.message + ') → thử lại'); const l = lopTheo('Gắn thẻ người khác'); if (l) { const q = Array.from(vungLop(l, '[aria-label="Quay lại"]').querySelectorAll('[aria-label="Quay lại"]')).find(dangHien); if (q) q.click(); await sleep(1000); } try { await ganTheMoi(1); the = true; } catch (e2) { if (e2 instanceof LoiDung) throw e2; ghi('Gắn thẻ (hộp mới) chưa được: ' + e2.message + ' → vẫn lưu cảm xúc, lần sau thử thẻ lại'); } } }
      if (canCx) { try { nhan = await camXucMoi(0); } catch (e1) { if (e1 instanceof LoiDung || !hopSuaMoi()) throw e1; ghi('Cảm xúc (hộp mới) lần 1 chưa được (' + e1.message + ') → thử lại'); await sleep(1200); try { nhan = await camXucMoi(1); } catch (e2) { if (e2 instanceof LoiDung) throw e2; ghi('Cảm xúc (hộp mới) chưa được: ' + e2.message); } } }
      if ((canThe && !the) && (canCx && !nhan)) throw new Error('chưa gắn được thẻ lẫn cảm xúc (hộp mới)');
      if (canCx && !nhan && !canThe) throw new Error('chưa chọn được cảm xúc (hộp mới)');
      await luuHopMoi();
      return { daLuu: true, the, nhan, khongCan: false };
    } finally { window.__smhMoHop = 0; }
  }
