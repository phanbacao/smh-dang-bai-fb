# (6.28.6) Facebook đổi nhãn nút ảnh đại diện góc trên phải: "Trang cá nhân của bạn" → "Account, your profile" (nhãn cũ chỉ còn ở hình svg bên trong)
_A = """  function nutTaiKhoan() { const ds = Array.from(document.querySelectorAll('div[role="button"][aria-label="Trang cá nhân của bạn"]')); return ds.find(dangHien) || ds[0] || null; }"""
_B = r"""  const NHAN_TK = /^(Trang cá nhân của bạn|Account, your profile|Your profile|Tài khoản, trang cá nhân của bạn|Tài khoản|Account)$/i;
  function nutTaiKhoan() { // (6.28.6) nhiều cách tìm nút tài khoản — Facebook hay đổi nhãn
    const hien = (e) => e && dangHien(e) && !e.closest('#smhfb');
    let ds = Array.from(document.querySelectorAll('[role="button"][aria-label]')).filter((e) => NHAN_TK.test(e.getAttribute('aria-label').trim()));
    let n = ds.find(hien); if (n) return ghiCachTK(n, 'nhãn ' + n.getAttribute('aria-label')), n;
    ds = Array.from(document.querySelectorAll('svg[aria-label="Trang cá nhân của bạn"], svg[aria-label="Your profile"], image[aria-label="Trang cá nhân của bạn"]')).map((s) => s.closest('[role="button"]')).filter(Boolean);
    n = ds.find(hien); if (n) return ghiCachTK(n, 'hình bên trong nút'), n;
    const nav = document.querySelector('[role="navigation"][aria-label="Cài đặt và kiểm soát tài khoản"], [role="navigation"][aria-label="Account controls and settings"]');
    if (nav) { const bs = Array.from(nav.querySelectorAll('[role="button"]')).filter(hien); const cuoi = bs[bs.length - 1]; if (cuoi) return ghiCachTK(cuoi, 'nút cuối vùng tài khoản'), cuoi; }
    return null;
  }
  function ghiCachTK(n, cach) { if (window.__cachTK !== cach) { window.__cachTK = cach; ghi('Tìm thấy nút tài khoản Facebook theo: ' + cach); } }"""
assert out.count(_A) == 1, 'nutTaiKhoan'
out = out.replace(_A, _B)
_C = """Array.from(document.querySelectorAll('[role="button"][aria-label="Trang cá nhân của bạn"]')).find(dangHien)"""
assert out.count(_C) >= 1, 'cho nut'
out = out.replace(_C, "nutTaiKhoan()")
_left = out.count('aria-label="Trang cá nhân của bạn"]')
print('(6.28.6) còn chỗ dùng nhãn cũ:', _left)
