
  // =====================================================================
  //  (6.19) MÃ KHOÁ FACEBOOK CHO 3 KÊNH (chỉ đọc bài + comment của từng trang)
  //  Mã đang cài (fb_token) là mã của trang kênh 1. Kênh 2, 3 cần mã riêng của từng trang:
  //  lấy từ danh sách trang (/me/accounts) khi mã dán vào là mã NGƯỜI DÙNG (nick quản lý cả 3 trang).
  // =====================================================================
  const maCacTrang = () => lay('fb_tok_trang6', {}) || {};
  function tokenTrang(c) {
    c = +c || 1; if (c === 1) { const id1 = idTrangKenh(1); if (CAI_DAT.KENH[1].moi) return id1 ? (maCacTrang()[id1] || '') : ''; return fbToken(); } // (6.21) kênh 1 mới: dùng mã riêng của trang mới (lấy từ mã người dùng)
    const id = idTrangKenh(c); return id ? (maCacTrang()[id] || '') : '';
  }
  const tokenKenh = () => tokenTrang(KENH_HT);
  const coApiKenh = (c) => !!(tokenTrang(c) && idTrangKenh(c));
  const chuanTenTrang = (t) => chuan(t).toLowerCase().replace(/[^\p{L}\p{N}]+/gu, '');
  // danh sách trang (id, name, access_token) → lưu mã + mã số trang của kênh 2, 3
  function luuMaKenh(ds) {
    const ids = Object.assign({}, lay('kenh_id6', {}) || {}); const ma = Object.assign({}, maCacTrang()); const thay = [];
    for (const c of KENH_PHU) {
      const cfg = CAI_DAT.KENH[c];
      const p = (ds || []).find((x) => x && (String(x.id) === String(cfg.pageId || ids[c] || '-') || chuanTenTrang(x.name) === chuanTenTrang(cfg.ten)));
      if (!p) continue;
      ids[c] = String(p.id); if (p.access_token) ma[String(p.id)] = p.access_token;
      thay.push(`${tenKenh(c)} "${p.name}"${p.access_token ? '' : ' (chưa có mã trang)'}`);
    }
    // (6.21) kênh 1 mới: tìm theo tên (đúng cả dấu chấm cuối) và KHÁC mã trang kênh cũ
    if (CAI_DAT.KENH[1].moi) { const k1 = CAI_DAT.KENH[1]; const q = (ds || []).find((x) => x && String(x.id) !== String(k1.boId) && (String(x.id) === String(ids[1] || '-') || chuanTen(x.name) === chuanTen(k1.ten))); if (q) { if (String(ids[1] || '') !== String(q.id)) thay.push(`kênh 1 "${q.name}"`); ids[1] = String(q.id); if (q.access_token) ma[String(q.id)] = q.access_token; } }
    // kênh 1 cũng lưu mã trang (để dùng chung 1 chỗ)
    const p1 = (ds || []).find((x) => x && String(x.id) === String(idTrangKenh(1) || ids[1] || '-')); if (p1 && p1.access_token) ma[String(p1.id)] = p1.access_token;
    // (6.19.2) mã kênh 1 đang cài bị Facebook từ chối (hoặc chưa có) → thay bằng mã trang mới lấy được từ mã người dùng
    if (p1 && p1.access_token && (!fbToken() || lay('fb_hong1', 0)) && p1.access_token !== fbToken()) { luu('fb_token', p1.access_token); luu('fb_token_luc', Date.now()); luu('fb_token_nhac', 0); luu('fb_hong1', 0); thay.push('kênh 1 (thay mã cũ bị từ chối)'); }
    luu('kenh_id6', ids); luu('fb_tok_trang6', ma);
    if (thay.length) luu('kenh_ma6', { luc: Date.now(), ok: true, chi: thay.join(', ') });
    return thay;
  }
  // tự lấy mã kênh 2, 3 (6 giờ/lần khi còn thiếu): chỉ được nếu mã đang cài là mã người dùng
  async function tuDoMaKenh(ep) {
    if (!fbToken() && !lay('fb_token_nguoi', '')) return false;
    const thieu = (CAI_DAT.KENH[1].moi ? KENH_ALL : KENH_PHU).filter((c) => !coApiKenh(c)); if (!thieu.length && !lay('fb_hong1', 0)) return false;
    const k = lay('kenh_ma6', null); if (!ep && k && Date.now() - (k.thu || k.luc || 0) < 6 * 3600e3) return false;
    luu('kenh_ma6', Object.assign({}, k || {}, { thu: Date.now() }));
    try {
      const acc = await goiFb('/me/accounts?fields=id,name,access_token&limit=100', lay('fb_token_nguoi', '') || fbToken()); // (6.19.1) giữ mã người dùng → trang mới thêm sau này tự lấy được mã, không phải dán lại
      const thay = luuMaKenh(acc.data || []);
      const con = (CAI_DAT.KENH[1].moi ? KENH_ALL : KENH_PHU).filter((c) => !coApiKenh(c));
      if (con.length) { luu('kenh_ma6', { luc: Date.now(), thu: Date.now(), ok: false, loi: `Nick của mã khoá không quản lý trang ${con.map(tenKenh).join(', ')}.` }); ghi(`Mã khoá Facebook: chưa thấy trang ${con.map(tenKenh).join(', ')} trong danh sách trang của nick này`); }
      else ghi('Mã khoá Facebook: đã lấy được mã đọc trang ' + thay.join(', '));
      return true;
    } catch (e) {
      const het = /\b190\b/.test(e.message || '');
      luu('kenh_ma6', { luc: Date.now(), thu: Date.now(), ok: false, loi: het ? 'Mã người dùng đã hết hạn / bị Facebook từ chối — cần dán mã mới (🔑 Đổi mã khoá)' : 'Mã khoá đang cài là mã riêng của trang kênh 1 (không mở được danh sách trang).' });
      if (het && lay('fb_token_nguoi', '')) { luu('fb_token_nguoi', ''); ghi('Mã người dùng (dùng để lấy mã các trang) đã bị Facebook từ chối → cần dán mã mới ở 🔑 Đổi mã khoá'); }
      return false;
    }
  }
  // (6.19.2) Facebook từ chối mã đọc trang (mã 190: hết hạn / đổi mật khẩu / dán nhầm) → bỏ mã đó, lấy lại từ mã người dùng (nếu có)
  function maHong(c) {
    c = +c || 1; const id = idTrangKenh(c);
    if (c > 1 && id) { const ma = Object.assign({}, maCacTrang()); if (ma[id]) { delete ma[id]; luu('fb_tok_trang6', ma); } }
    if (c === 1) luu('fb_hong1', Date.now());
    if (lay('fb_token_nguoi', '') && Date.now() - (window.__smhMaHong || 0) > 10 * 60000) { window.__smhMaHong = Date.now(); ghi(`Mã đọc trang ${tenKenh(c)} bị Facebook từ chối → lấy lại mã từ mã người dùng`); tuDoMaKenh(true).catch(() => {}); }
  }
  function moTaMaKenh() { // cho tab Hệ thống / kiểm tra mã khoá
    return KENH_ALL.map((c) => `${tenKenhDai(c)}: ${coApiKenh(c) ? 'đọc được' : 'CHƯA đọc được'}`).join(' · ');
  }
