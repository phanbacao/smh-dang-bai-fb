
  // =====================================================================
  //  (6.18.1) THỬ "CÁCH 2": cất bản mới trong Lark → các máy tự nạp sau khi anh Cao duyệt
  //  Chỉ THỬ, không đổi cách chạy hiện tại. Chạy trên Máy Cao, 1 lần (hoặc khi bấm nút trong tab Hệ thống).
  //  Kiểm 4 việc: (1) Tampermonkey có cho chạy mã nạp về không  (2) nén/giải nén mã
  //               (3) cất mã vào ô sheet (Z20:Z29, thử xong xoá sạch)  (4) cất mã thành file trong Lark Drive của ứng dụng
  // =====================================================================
  const O_NAP = ['Z20', 'Z21', 'Z22', 'Z23', 'Z24', 'Z25', 'Z26', 'Z27', 'Z28', 'Z29'];
  const ketThuNap = () => lay('thunap6b', null);
  function thuBlob(src) {
    return new Promise((res) => {
      const w = (typeof unsafeWindow !== 'undefined' && unsafeWindow) || window; const ten = '__smhThu' + Math.random().toString(36).slice(2);
      const u = URL.createObjectURL(new Blob(['window["' + ten + '"] = function () {\n' + src + '\n};'], { type: 'text/javascript' }));
      const s = document.createElement('script'); const het = setTimeout(() => res(false), 15000);
      s.onload = () => { clearTimeout(het); const ok = typeof w[ten] === 'function'; try { delete w[ten]; } catch (e) { /* */ } URL.revokeObjectURL(u); s.remove(); res(ok); };
      s.onerror = () => { clearTimeout(het); res(false); };
      s.src = u; (document.head || document.documentElement).appendChild(s);
    });
  }
  async function sha(s) { const b = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(s)); return Array.from(new Uint8Array(b)).map((x) => x.toString(16).padStart(2, '0')).join('').slice(0, 16); }
  async function nenB64(s) {
    const st = new Blob([s]).stream().pipeThrough(new CompressionStream('gzip'));
    const u8 = new Uint8Array(await new Response(st).arrayBuffer());
    let bin = ''; for (let i = 0; i < u8.length; i += 0x8000) bin += String.fromCharCode.apply(null, u8.subarray(i, i + 0x8000));
    return btoa(bin);
  }
  async function giaiNenB64(b64) {
    const bin = atob(b64); const u8 = new Uint8Array(bin.length); for (let i = 0; i < bin.length; i++) u8[i] = bin.charCodeAt(i);
    const st = new Blob([u8]).stream().pipeThrough(new DecompressionStream('gzip'));
    return await new Response(st).text();
  }
  function goiTep(method, url, data, responseType) { // gọi Lark có tệp (multipart) / tải tệp về
    return new Promise(async (resolve) => {
      let t; try { t = await larkToken(); } catch (e) { resolve({ status: 0, loi: e.message }); return; }
      GM_xmlhttpRequest({ method, url, data, responseType, timeout: 120000, headers: { Authorization: 'Bearer ' + t },
        onload: (r) => resolve({ status: r.status, text: responseType ? null : r.responseText, resp: r.response }),
        onerror: () => resolve({ status: 0, loi: 'mất kết nối' }), ontimeout: () => resolve({ status: 0, loi: 'quá lâu' }) });
    });
  }
  async function thuNapBan() {
    const kq = { luc: Date.now(), may: MAY, ban: PHIEN_BAN, buoc: {} };
    const xong = (k, ok, chi) => { kq.buoc[k] = { ok, chi: String(chi || '').slice(0, 300) }; ghi(`Thử nạp bản — ${k}: ${ok ? 'ĐƯỢC' : 'CHƯA ĐƯỢC'}${chi ? ' (' + chi + ')' : ''}`); luu('thunap6b', kq); };
    ghi('Thử nạp bản (cách 2): bắt đầu — chỉ thử, không đổi cách chạy hiện tại');
    // (1) chạy mã nạp về
    let src = ''; try { src = (GM_info && GM_info.scriptSource) || ''; } catch (e) { /* */ }
    try {
      const f = new Function('a', 'b', 'return a + b'); if (f(40, 2) !== 42) throw new Error('kết quả sai');
      const t0 = Date.now(); if (src) new Function(src); // chỉ dịch thử, KHÔNG chạy
      xong('1a. Chạy mã nạp về (kiểu thường)', true, src ? `dịch thử ${Math.round(src.length / 1024)} KB mã trong ${Date.now() - t0} ms` : 'chỉ thử mã nhỏ');
    } catch (e) { xong('1a. Chạy mã nạp về (kiểu thường)', false, /unsafe-eval|Content Security/i.test(e.message) ? 'Facebook chặn kiểu này' : e.message); }
    try { // (6.18.2) kiểu Facebook cho phép: nạp mã qua "blob" — chỉ ĐỊNH NGHĨA hàm bọc ngoài, không chạy
      const t0 = Date.now(); const ok = await thuBlob(src || 'var x = 1;');
      xong('1b. Chạy mã nạp về (kiểu blob)', ok, ok ? `nạp ${Math.round((src || ' ').length / 1024)} KB mã trong ${Date.now() - t0} ms (chỉ nạp, không chạy)` : 'trình duyệt không nạp được');
    } catch (e) { xong('1b. Chạy mã nạp về (kiểu blob)', false, e.message); }
    if (!src) src = 'thu-nap-' + 'x'.repeat(600000);
    // (2) nén / giải nén
    let b64 = '', h0 = '';
    try {
      h0 = await sha(src); b64 = await nenB64(src); const lai = await giaiNenB64(b64);
      if (await sha(lai) !== h0) throw new Error('giải nén ra khác bản gốc');
      xong('2. Nén mã', true, `${Math.round(src.length / 1024)} KB → ${Math.round(b64.length / 1024)} KB`);
    } catch (e) { xong('2. Nén mã', false, e.message); }
    // (3) cất vào ô sheet Z20:Z29 rồi đọc lại, xong xoá sạch
    if (b64) {
      try {
        const cu = await docBang(CAI_DAT.TAB_BAI, 'Z20:Z29');
        if (cu.some((r) => chuO((r || [])[0]))) throw new Error('ô Z20:Z29 đang có chữ khác — không ghi đè');
        const manh = []; for (let i = 0; i < b64.length; i += 40000) manh.push(b64.slice(i, i + 40000));
        if (manh.length > O_NAP.length) throw new Error(`mã nén cần ${manh.length} ô, chỉ dành ${O_NAP.length} ô`);
        const t0 = Date.now();
        for (let i = 0; i < manh.length; i++) await ghiO(CAI_DAT.TAB_BAI, O_NAP[i], 'NAP|' + manh[i]);
        const tGhi = Date.now() - t0, t1 = Date.now();
        const v = await docBang(CAI_DAT.TAB_BAI, 'Z20:Z29');
        const ghep = v.map((r) => chuO((r || [])[0])).filter((s) => s.startsWith('NAP|')).map((s) => s.slice(4)).join('');
        const tDoc = Date.now() - t1;
        let dung = false; try { dung = (await sha(await giaiNenB64(ghep))) === h0; } catch (e) { /* */ }
        try { await ghiNhieuO(CAI_DAT.TAB_BAI, O_NAP.slice(0, manh.length).map((o) => [o, ''])); } catch (e) { ghi('Thử nạp bản: xoá ô Z20:Z29 chưa được — ' + e.message); }
        xong('3. Cất mã vào ô sheet', dung, `${manh.length} ô · ghi ${Math.round(tGhi / 1000)} giây · đọc lại ${Math.round(tDoc / 1000)} giây${dung ? ' · đọc lại khớp 100%' : ' · đọc lại KHÔNG khớp'} · đã xoá ô thử`);
      } catch (e) { xong('3. Cất mã vào ô sheet', false, e.message); }
    }
    // (4) cất thành file trong Lark Drive của ứng dụng rồi tải lại
    try {
      // (6.18.2) gọi thẳng, KHÔNG qua cổng chặn Lark — ứng dụng chưa có quyền Drive thì chỉ báo ở đây, không làm Máy Cao ngưng đọc sheet 60 phút
      const r0 = await goiTho('GET', 'https://open.larksuite.com/open-apis/drive/explorer/v2/root_folder/meta', null, { Authorization: 'Bearer ' + (await larkToken()) });
      if (r0.json && r0.json.code === 99991672) throw new Error('ứng dụng Lark chưa được cấp quyền Drive (mã 99991672) — không ảnh hưởng việc đăng bài');
      const thuMuc = r0.json && r0.json.data && r0.json.data.token; if (!thuMuc) throw new Error('không lấy được thư mục của ứng dụng');
      const fd = new FormData(); const tep = new Blob([src], { type: 'text/plain' });
      fd.append('file_name', 'smh-thu-nap.txt'); fd.append('parent_type', 'explorer'); fd.append('parent_node', thuMuc); fd.append('size', String(tep.size)); fd.append('file', tep, 'smh-thu-nap.txt');
      const t0 = Date.now(); const up = await goiTep('POST', 'https://open.larksuite.com/open-apis/drive/v1/files/upload_all', fd);
      let j = null; try { j = JSON.parse(up.text); } catch (e) { /* */ }
      if (!j || j.code !== 0) throw new Error('tải lên chưa được (mã ' + (j ? j.code + ' ' + (j.msg || '') : up.status + ' ' + (up.loi || '')) + ')');
      const ma = j.data.file_token; const tUp = Date.now() - t0, t1 = Date.now();
      const dl = await goiTep('GET', 'https://open.larksuite.com/open-apis/drive/v1/files/' + ma + '/download', null, 'text');
      const dung = dl.status === 200 && (await sha(String(dl.resp || ''))) === h0;
      luu('thunap_tep6', ma);
      xong('4. Cất mã thành file Lark Drive', dung, `tải lên ${Math.round(tUp / 1000)} giây · tải về ${Math.round((Date.now() - t1) / 1000)} giây${dung ? ' · khớp 100%' : ' · tải về KHÔNG khớp (mã ' + dl.status + ')'}`);
    } catch (e) { xong('4. Cất mã thành file Lark Drive', false, e.message); }
    kq.xong = Date.now(); luu('thunap6b', kq);
    const ok = Object.values(kq.buoc).filter((b) => b.ok).length;
    ghi(`Thử nạp bản (cách 2): xong — ${ok}/${Object.keys(kq.buoc).length} việc được`);
    return true;
  }
  function chayThuNap(tay) {
    if (!LA_CAO || dangChay || dangBan) return false;
    if (!tay && ketThuNap()) return false;
    if (!coBiMat()) return false;
    theoDoi('thunap', thuNapBan, 'Đang thử nạp bản qua Lark (cách 2)').catch((e) => ghi('Thử nạp bản lỗi: ' + e.message)).finally(() => { try { veBangNgay(); } catch (e) { /* */ } });
    return true;
  }
  function khungThuNap() {
    if (!LA_CAO) return '';
    const k = ketThuNap();
    let h = `<div class="dong" style="flex-direction:column;align-items:flex-start;gap:4px"><span><b>🧪 Thử cập nhật qua Lark (cách 2)</b> — chỉ thử, không đổi cách chạy</span>`;
    if (k) for (const [ten, b] of Object.entries(k.buoc)) h += `<span>${b.ok ? '🟢' : '🔴'} ${esc(ten)}: ${esc(b.chi)}</span>`;
    h += `<span>${k ? (k.xong ? 'Thử lúc ' + gioStr(new Date(k.luc)) : '⏳ đang thử…') : 'chưa thử — script tự thử khi rảnh'} <button class="nut" data-a="thunap">${k ? 'Thử lại' : 'Thử ngay'}</button></span></div>`;
    return h;
  }
  document.addEventListener('click', (ev) => {
    const a = ev.target.closest && ev.target.closest('#smhfb [data-a="thunap"]'); if (!a) return;
    if (chayThuNap(true)) nhacNho('Đang thử nạp bản qua Lark — khoảng 1 phút', 'cho'); else nhacNho('Script đang bận việc khác — thử lại sau ít phút', 'vang', 6000);
  });
  window.addEventListener('message', (e) => { // Claude gọi thử từ xa + đọc kết quả
    const d = e && e.data; if (!d || e.origin !== location.origin) return;
    if (d.smhThuNap) chayThuNap(true);
    if (d.smhThuNap || d.smhKetThuNap) { let el = document.getElementById('smhfb-thunap'); if (!el) { el = document.createElement('textarea'); el.id = 'smhfb-thunap'; el.style.display = 'none'; document.body.appendChild(el); } el.value = JSON.stringify({ ban: PHIEN_BAN, kq: ketThuNap() }); }
  });
  // tự thử 1 lần khi rảnh (Máy Cao, tab chính, không đang chạy việc nào) — kiểm mỗi 2 phút, bắt đầu sau 3 phút từ lúc mở trang
  setTimeout(() => { setInterval(() => { try { if (laTabChinh() && !hdChay) chayThuNap(false); } catch (e) { /* */ } }, 120000); }, 60000);
