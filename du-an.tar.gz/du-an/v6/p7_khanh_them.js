
  // =====================================================================
  //  (6.0) Khanh: bỏ bài ghim + mục "Đáng chú ý" ở đầu trang — chỉ đếm bài mới trong dòng thời gian 7 ngày qua
  // =====================================================================
  function neoFeedKhanh() { // tiêu đề dòng thời gian (nút "Bộ lọc" / chữ "Bài viết") — khung đứng TRƯỚC nó là mục nổi bật/ghim
    const loc = Array.from(document.querySelectorAll('[role="button"]')).find((b) => chuan(b.innerText || b.getAttribute('aria-label') || '') === 'Bộ lọc' && dangHien(b));
    if (loc) return loc;
    return Array.from(document.querySelectorAll('h2')).find((e) => chuan(e.textContent) === 'Bài viết' && dangHien(e)) || null;
  }
  const tieuDeNoiBat = (p) => Array.from(p.querySelectorAll('h2,h3,span')).find((e) => e.children.length === 0 && /^(Đáng chú ý|Bài viết nổi bật|Nổi bật)$/i.test(chuan(e.textContent)));
  function laKhungNoiBat(khung, neo) {
    const dau = chuan(khung.innerText).slice(0, 200);
    if (/Bài viết đã ghim|Đã ghim/i.test(dau) || khung.querySelector('[aria-label*="ghim" i]')) return 'ghim';
    if (neo && !khung.contains(neo) && (khung.compareDocumentPosition(neo) & Node.DOCUMENT_POSITION_FOLLOWING)) return 'truoc';
    for (let p = khung.parentElement, i = 0; p && i < 16; p = p.parentElement, i++) {
      if (tieuDeNoiBat(p)) return (neo ? !p.contains(neo) : i < 6) ? 'noibat' : '';
    }
    return '';
  }
  // không đọc trang Khanh khi: tab phụ, tạm dừng, đang đăng/comment, đang đếm ngược, hoặc sắp/đang tới giờ đăng 1 bài
  const khanhBan = () => !laTabChinh() || tamDung() || !!lay('dang_do', null) || dangBan || !!demNguoc || !!lay('cho_tay6', null)
    || (() => { const kt = keTiep(); return !!(kt && Date.now() > kt.den - 15 * 60000 && Date.now() < kt.den + 60 * 60000); })();
