  // (6.26.7) tab "Bài viết kênh 1" cột G (Trạng thái): hàng nào cả 3 bài đã lên trang → ghi "Đã đăng" (cùng các mốc ghi gom 13:40 / 18:40 / 22:40; Máy Cao trễ 20 phút để Máy Giao ghi trước)
  async function ghiTTBai(ep) {
    if (!MAY || chanLark()) return false;
    if (!ep && larkTietKiem()) return false; // (6.28.5) chạm trần lượt Lark ngày → để lượt sau / máy kia ghi
    const mm = phutTrongNgay(new Date()); const ngay = homNay(); const lech = LA_GIAO ? 0 : 20; const st = lay('gomb6_' + ngay, {}) || {};
    if (LA_CAO && !ep && mm < docGio(MOC_GOM[MOC_GOM.length - 1]) + 20) return false; // (6.28.5) Máy Cao chỉ ghi dự phòng 1 lần cuối ngày (Máy Giao đã ghi ở các mốc)
    const moc = MOC_GOM.filter((g) => mm >= docGio(g) + lech && !st[g]).pop(); if (!ep && !moc) return false;
    const xongMoc = () => { MOC_GOM.forEach((g) => { if (mm >= docGio(g) + lech) st[g] = Date.now(); }); luu('gomb6_' + ngay, st); }; // (6.28) chỉ đánh dấu khi đã ghi xong / không còn gì phải ghi
    if (Date.now() - (window.__ttBaiThu || 0) < 10 * 60000) return false; window.__ttBaiThu = Date.now();
    const d = duLieu(); const n = d && d.ngay && d.ngay[ngay]; if (!n) return false;
    const daGhi = new Set((lay('ttbai6_' + ngay, []) || []));
    const s = trangThai(ngay); const nhom = {};
    for (const it of LICH) {
      if ((it.kenh || 1) !== 1 || !/^b[123]$/.test(it.loai)) continue;
      const b = it.hangSo ? (n.bais || [])[it.hangSo] : n.bai; if (!b || !b.hang) continue;
      (nhom[b.hang] = nhom[b.hang] || { b, ds: [] }).ds.push(it);
    }
    const can = Object.values(nhom).filter((g) => !daGhi.has(g.b.hang) && !/đã đăng/i.test(g.b.trangThai || '') && g.ds.every((it) => { const r = s.s[it.k]; return r && XONG.includes(r.tt); }));
    if (!can.length) { xongMoc(); return false; }
    const v = await docBang(CAI_DAT.TAB_BAI, 'A1:H3000'); const o = []; const xong = [];
    for (const g of can) {
      const r = v[g.b.hang - 1] || [];
      if (ngayO(r[7]) !== ngay || khoaSo(chuO(r[1])).slice(0, 40) !== khoaSo(g.b.bai).slice(0, 40)) { ghi(`Bài viết kênh 1: dòng ${g.b.hang} đã đổi trong sheet → không ghi "Đã đăng"`); continue; }
      if (/đã đăng/i.test(chuO(r[6]))) { daGhi.add(g.b.hang); continue; }
      o.push(['G' + g.b.hang, 'Đã đăng']); xong.push(`dòng ${g.b.hang} (${g.ds.map((it) => it.ten).join(', ')})`);
    }
    if (o.length) { await ghiNhieuO(CAI_DAT.TAB_BAI, o); for (const x of o) daGhi.add(+x[0].slice(1)); ghi(`Ghi tab Bài viết kênh 1: cột G "Đã đăng" cho ${xong.join('; ')}`); }
    luu('ttbai6_' + ngay, [...daGhi]); xongMoc(); return true;
  }
  // (6.28.7) Facebook hiện hộp "Chào mừng bạn đến với Trang mới!" / "Đã cập nhật Trang của bạn!" khi trang chuyển sang kiểu Trang mới → che trang, script bấm gì cũng không ăn.
  //  Tự bấm "Dùng Trang" (giữ nguyên 2 công tắc mặc định: thông báo bật, email quảng cáo tắt), ghi nhật ký.
  const TIEU_DE_TRANG_MOI = /^(Chào mừng bạn đến với Trang mới!?|Đã cập nhật Trang của bạn!?|Welcome to your new Page!?|Your Page has been updated!?)$/i;
  function dongHopTrangMoi() {
    try {
      const nuts = document.evaluate("//*[@role='button' or self::button][normalize-space(.)='Dùng Trang' or normalize-space(.)='Use Page']", document.body, null, window.XPathResult.ORDERED_NODE_SNAPSHOT_TYPE, null);
      for (let i = 0; i < nuts.snapshotLength; i++) {
        const n = nuts.snapshotItem(i); if (!dangHien(n) || n.closest('#smhfb')) continue;
        let hop = n; for (let j = 0; j < 12 && hop && hop !== document.body; j++) { hop = hop.parentElement; if (hop && Array.from(hop.querySelectorAll('h1,h2,h3,span,div')).some((e) => e.childElementCount === 0 && TIEU_DE_TRANG_MOI.test(String(e.textContent || '').trim()))) break; }
        if (!hop || hop === document.body) continue;
        const ten = (Array.from(hop.querySelectorAll('span,div')).find((e) => e.childElementCount === 0 && TIEU_DE_TRANG_MOI.test(String(e.textContent || '').trim())) || {}).textContent || '';
        n.click(); ghi(`Facebook hiện hộp "${String(ten).trim()}" → đã bấm "Dùng Trang" (giữ nguyên lựa chọn mặc định, email quảng cáo vẫn tắt)`);
        return true;
      }
    } catch (e) { /* */ }
    return false;
  }
  setInterval(() => { if (MAY && document.visibilityState === 'visible') dongHopTrangMoi(); }, 2500);
  // (6.28.7) GỠ KẸT "Đang làm…": bài ở trạng thái đang đăng quá 8 phút mà không còn việc dở thật (trang tải lại giữa chừng, tab bị ẩn…) → đưa về hàng chờ.
  //  Lượt đăng sau luôn hỏi trang đã có bài chưa trước khi đăng → có rồi thì đánh dấu xong, chưa có thì đăng lại (không trùng).
  function goKetDangLam(lyDo) {
    try {
      if (!MAY || dangBan || lay('dang_do', null) || demNguoc) return 0;
      const ct = lay('cho_tay6', null); const s = trangThai(); const ds = [];
      for (const it of LICH) { const x = (s.s || {})[it.k]; if (!x || x.tt !== 'dang') continue; if (ct && ct.slot === it.k) continue; if (Date.now() - (x.batDau || 0) < 8 * 60000) continue; ds.push(it); }
      if (!ds.length) return 0;
      capNhatTT((s2) => { for (const it of ds) { const x = ttSlot(s2, it.k); if (x.tt !== 'dang') continue; x.tt = 'cho'; x.thuLai = Date.now() + 30000; x.lyDo = 'gỡ kẹt "Đang làm"'; } });
      ghi(`Gỡ kẹt "Đang làm" (${lyDo}): ${ds.map((it) => it.ten).join(', ')} — quá 8 phút không còn việc dở → đưa về hàng chờ, lượt sau kiểm trang rồi đăng lại nếu chưa có`);
      try { veBang(); } catch (e) { /* */ }
      return ds.length;
    } catch (e) { return 0; }
  }
  setTimeout(() => goKetDangLam('vừa mở trang'), 20000);
  setInterval(() => goKetDangLam('kiểm định kỳ'), 60000);
