  // (6.26.7) tab "Bài viết kênh 1" cột G (Trạng thái): hàng nào cả 3 bài đã lên trang → ghi "Đã đăng" (cùng các mốc ghi gom 13:40 / 18:40 / 22:40; Máy Cao trễ 20 phút để Máy Giao ghi trước)
  async function ghiTTBai(ep) {
    if (!MAY || chanLark()) return false;
    const mm = phutTrongNgay(new Date()); const ngay = homNay(); const lech = LA_GIAO ? 0 : 20; const st = lay('gomb6_' + ngay, {}) || {};
    const moc = MOC_GOM.filter((g) => mm >= docGio(g) + lech && !st[g]).pop(); if (!ep && !moc) return false;
    MOC_GOM.forEach((g) => { if (mm >= docGio(g) + lech) st[g] = Date.now(); }); luu('gomb6_' + ngay, st);
    const d = duLieu(); const n = d && d.ngay && d.ngay[ngay]; if (!n) return false;
    const s = trangThai(ngay); const nhom = {};
    for (const it of LICH) {
      if ((it.kenh || 1) !== 1 || !/^b[123]$/.test(it.loai)) continue;
      const b = it.hangSo ? (n.bais || [])[it.hangSo] : n.bai; if (!b || !b.hang) continue;
      (nhom[b.hang] = nhom[b.hang] || { b, ds: [] }).ds.push(it);
    }
    const can = Object.values(nhom).filter((g) => !/đã đăng/i.test(g.b.trangThai || '') && g.ds.every((it) => { const r = s.s[it.k]; return r && XONG.includes(r.tt); }));
    if (!can.length) return false;
    const v = await docBang(CAI_DAT.TAB_BAI, 'A1:H3000'); const o = []; const xong = [];
    for (const g of can) {
      const r = v[g.b.hang - 1] || [];
      if (ngayO(r[7]) !== ngay || khoaSo(chuO(r[1])).slice(0, 40) !== khoaSo(g.b.bai).slice(0, 40)) { ghi(`Bài viết kênh 1: dòng ${g.b.hang} đã đổi trong sheet → không ghi "Đã đăng"`); continue; }
      if (/đã đăng/i.test(chuO(r[6]))) continue;
      o.push(['G' + g.b.hang, 'Đã đăng']); xong.push(`dòng ${g.b.hang} (${g.ds.map((it) => it.ten).join(', ')})`);
    }
    if (o.length) { await ghiNhieuO(CAI_DAT.TAB_BAI, o); ghi(`Ghi tab Bài viết kênh 1: cột G "Đã đăng" cho ${xong.join('; ')}`); }
    return true;
  }
