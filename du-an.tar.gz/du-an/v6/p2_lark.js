
  // =====================================================================
  //  Gọi API Lark (sheet + webhook) — gọi càng ít càng tốt
  // =====================================================================
  function thangHienTai() { const d = new Date(); return d.getFullYear() + '-' + (d.getMonth() + 1); }
  function chanLark() {
    const g = lay('lark_gate', null);
    if (!g) return null;
    if (g.loai === 'quota' && g.thang !== thangHienTai()) return null;
    return g.den > Date.now() ? g : null;
  }
  const MA_TOKEN_LARK = ['99991663', '99991664', '99991665', '99991661'];
  function loiLark(ma, msg) {
    const g0 = lay('lark_gate', {}) || {};
    const lan = (g0.lan || 0) + 1;
    const code = String(ma), d = new Date();
    let loai = 'tam', moTa = 'Lark tạm lỗi kết nối/dịch vụ', den = Date.now() + Math.min(30, Math.pow(2, Math.min(lan - 1, 5))) * 60000;
    if (code === '99991403') { loai = 'quota'; moTa = 'Lark đã hết hạn mức API tháng'; den = new Date(d.getFullYear(), d.getMonth() + 1, 1).getTime(); }
    else if (['91403', '99991672', '99991676', '99991679', '99991668', '10014'].includes(code)) { loai = 'quyen'; moTa = 'Lark từ chối quyền truy cập hoặc thông tin ứng dụng'; den = Date.now() + 60 * 60000; }
    else if (MA_TOKEN_LARK.includes(code)) { moTa = 'Mã truy cập Lark cần làm mới'; boTokenLark(); }
    else if (code === '99991400' || code === '429') { moTa = 'Lark giới hạn tốc độ gọi API'; den = Date.now() + Math.min(60, 5 * lan) * 60000; }
    const g = { loai, ma: code, msg: moTa + ' (mã ' + code + ')', detail: anBiMat(msg || '').slice(0, 350), den, lan, luc: Date.now(), tu: (g0.loai === loai && g0.tu) ? g0.tu : Date.now(), thang: thangHienTai(), bao: g0.ma === code && g0.thang === thangHienTai() ? g0.bao : false };
    luu('lark_gate', g);
    capNhat('suc_khoe', { larkOk: false, larkLuc: Date.now(), larkLoi: g.msg });
    if (!g0.msg || g0.ma !== code) ghi('Lark tạm ngừng: ' + g.msg);
    return new LoiLark(g.msg);
  }
  async function baoTinhTrangLark() {
    const g = lay('lark_gate', null);
    if (!g || g.bao || !trongGioNhan() || !laTabChinh()) return;
    if (!(g.loai === 'quota' || g.loai === 'quyen' || Date.now() - (g.tu || g.luc) >= 30 * 60000)) return;
    luu('lark_gate', Object.assign({}, g, { bao: true }));
    await baoLoi(`${g.msg} — script vẫn đăng bằng dữ liệu đã tải sẵn; cần kiểm tra hạn mức/quyền Lark`, 'lark_' + g.ma);
  }
  function goiTho(method, url, body, headers, timeout = 25000) {
    return new Promise((resolve) => {
      GM_xmlhttpRequest({
        method, url,
        headers: Object.assign({ 'Content-Type': 'application/json; charset=utf-8' }, headers),
        data: body ? JSON.stringify(body) : undefined,
        timeout,
        onload: (r) => { let j = null; try { j = JSON.parse(r.responseText); } catch (e) { /* */ } resolve({ status: r.status, json: j }); },
        onerror: () => resolve({ status: 0, json: null, mang: 'network' }),
        ontimeout: () => resolve({ status: 0, json: null, mang: 'timeout' }),
      });
    });
  }
  const demLark = () => capNhat('lark_dem', { ngay: homNay(), so: (lay('lark_dem', {}).ngay === homNay() ? lay('lark_dem', {}).so || 0 : 0) + 1 });
  // lỗi mạng / quá lâu / máy chủ 5xx / giới hạn tốc độ: tự thử lại tối đa 2 lần (cách 3–8 giây) rồi mới tính là lỗi
  async function goi(method, url, body, headers = {}, timeout) {
    const duLieu = url.startsWith('https://open.larksuite.com/open-apis/') && !url.includes('/bot/v2/hook/');
    const gate = duLieu && chanLark();
    if (gate) throw new LoiLark(gate.msg + ' — đang chờ kiểm tra lại');
    for (let lan = 0; ; lan++) {
      if (duLieu) demLark();
      const r = await goiTho(method, url, body, headers, timeout);
      const j = r.json;
      if (!duLieu) {
        if (r.mang) throw new LoiMem(r.mang === 'timeout' ? 'Gửi tin Lark quá lâu' : 'Mất kết nối khi gửi tin Lark');
        return r;
      }
      const loi = r.mang || !j || r.status >= 400 || (j.code != null && j.code !== 0);
      if (!loi) { if (lay('lark_gate', null)) { luu('lark_gate', null); ghi('Kết nối Lark phục hồi'); } capNhat('suc_khoe', { larkOk: true, larkLuc: Date.now(), larkLoi: '' }); return r; }
      const ma = String(r.mang || (j && j.code) || r.status || 'network');
      if (MA_TOKEN_LARK.includes(ma)) { boTokenLark(); throw new LoiLarkToken('Mã truy cập Lark cần làm mới (mã ' + ma + ')'); }
      const tam = r.mang || r.status >= 500 || ma === '99991400' || ma === '429' || !j;
      if (tam && lan < 2) { await sleepThat(3000 + Math.floor(Math.random() * 5000)); continue; }
      throw loiLark(ma, r.mang ? (r.mang === 'timeout' ? 'Phản hồi quá lâu' : 'Mất kết nối') : (j && j.msg));
    }
  }
  async function goiLark(method, url, body, timeout) {
    for (let lan = 0; ; lan++) {
      const t = await larkToken();
      try { return await goi(method, url, body, { Authorization: 'Bearer ' + t }, timeout); }
      catch (e) { if (e instanceof LoiLarkToken && lan === 0) continue; throw e; }
    }
  }
  function boTokenLark() { tokenCache = null; try { luu('lark_tok', null); } catch (e) { /* */ } }
  let tokenCache = null, tokenCho = null;
  async function larkToken() {
    if (tokenCho) return tokenCho;
    tokenCho = layLarkToken();
    try { return await tokenCho; } finally { tokenCho = null; }
  }
  async function layLarkToken() {
    if (!tokenCache) { const c = lay('lark_tok', null); if (c && c.t && c.het > Date.now() + 5 * 60000) tokenCache = c; }
    if (tokenCache && tokenCache.het > Date.now() + 60000) return tokenCache.t;
    const r = await goi('POST', 'https://open.larksuite.com/open-apis/auth/v3/tenant_access_token/internal', { app_id: CAI_DAT.LARK_APP_ID, app_secret: CAI_DAT.LARK_APP_SECRET });
    if (!r.json || r.json.code !== 0) throw new LoiMem('Không lấy được quyền đọc Lark (mã ' + (r.json ? r.json.code : r.status) + ')');
    tokenCache = { t: r.json.tenant_access_token, het: Date.now() + r.json.expire * 1000 };
    luu('lark_tok', tokenCache);
    return tokenCache.t;
  }
  const URL_SHEET = () => 'https://open.larksuite.com/open-apis/sheets/v2/spreadsheets/' + CAI_DAT.SHEET_TOKEN;
  // đọc 1 vùng ô → mảng 2 chiều
  async function docBang(tab, vung) {
    const r = await goiLark('GET', `${URL_SHEET()}/values/${tab}!${vung}`, null, 60000);
    if (!r.json || r.json.code !== 0 || !r.json.data || !r.json.data.valueRange) throw new LoiMem('Không đọc được sheet (' + tab + '!' + vung + ')');
    return r.json.data.valueRange.values || [];
  }
  async function docO(tab, o) { const v = await docBang(tab, o + ':' + o); return (v[0] || [])[0]; }
  async function ghiO(tab, o, giaTri) {
    const r = await goiLark('PUT', `${URL_SHEET()}/values`, { valueRange: { range: `${tab}!${o}:${o}`, values: [[giaTri]] } });
    if (!r.json || r.json.code !== 0) throw new LoiMem('Ghi ô ' + o + ' chưa được (mã ' + (r.json ? r.json.code : r.status) + ')');
  }
  async function ghiNhieuO(tab, ds) { // ds: [[ô, giá trị], ...] — gộp 1 lượt gọi
    const r = await goiLark('POST', `${URL_SHEET()}/values_batch_update`, { valueRanges: ds.map(([o, v]) => ({ range: `${tab}!${o}:${o}`, values: [[v]] })) });
    if (!r.json || r.json.code !== 0) throw new LoiMem('Ghi ô ' + ds.map((x) => x[0]).join(', ') + ' chưa được (mã ' + (r.json ? r.json.code : r.status) + ')');
  }
  // dán ảnh vào ô (ảnh nằm trong ô, giống dán tay)
  async function ghiAnhVaoO(tab, o, blob, ten) {
    const u8 = new Uint8Array(await blob.arrayBuffer());
    const r = await goiLark('POST', `${URL_SHEET()}/values_image`, { range: `${tab}!${o}:${o}`, image: Array.from(u8), name: ten || ('manifest-' + homNay() + '.jpg') }, 120000);
    if (!r.json || r.json.code !== 0) throw new LoiMem('Lark không nhận ảnh ô ' + o + ' (mã ' + (r.json ? r.json.code : r.status) + ')');
  }

  // ---------------- tin nhắn Lark: chỉ 2 loại ----------------
  //  'baocao' → nhóm Marketing (báo cáo cuối ngày + báo cáo tuần Khanh)   'loi' → nhóm "Đăng bài fb" (lỗi khi đăng, ghi rõ máy nào)
  async function guiLark(nhom, noiDung, { khoa = '', toiDa = 1 } = {}) {
    const hook = nhom === 'baocao' ? CAI_DAT.WEBHOOK_BAO_CAO : CAI_DAT.WEBHOOK_LOI;
    let tin = String(noiDung).replace(/^\n/, '');
    if (!/fb/i.test(tin)) tin = (tin.includes('\n') ? `${CAI_DAT.TIEN_TO_TIN}\n` : `${CAI_DAT.TIEN_TO_TIN} `) + tin;
    const kk = 'tin6_' + homNay(); const k = khoa || bam(tin.replace(/\d{1,2}[:h]\d{2}/g, ''));
    const dem = lay(kk, {}) || {};
    if ((dem[k] || 0) >= toiDa) { ghi('(hôm nay đã gửi tin này rồi, không gửi lại) ' + tin.replace(/\s+/g, ' ').slice(0, 120)); return true; }
    dem[k] = (dem[k] || 0) + 1; luu(kk, dem);
    let loiCuoi = '';
    for (let lan = 0; lan < 3; lan++) {
      try {
        const r = await goi('POST', hook, { msg_type: 'text', content: { text: tin } });
        if (r.json && (r.json.code === 0 || r.json.StatusCode === 0)) { capNhat('suc_khoe', { tinOk: true, tinLuc: Date.now(), tinLoi: '' }); ghi('Đã báo Lark (' + (nhom === 'baocao' ? 'nhóm Marketing' : 'nhóm Đăng bài fb') + '): ' + tin.replace(/\s+/g, ' ').slice(0, 300)); return true; }
        loiCuoi = 'mã ' + (r.json ? (r.json.code || r.json.StatusCode) : r.status);
        if (!(r.status >= 500 || !r.json)) break;
      } catch (e) {
        loiCuoi = e.message;
        if (/quá lâu/.test(e.message)) { ghi('Gửi tin Lark phản hồi quá lâu (tin có thể đã tới nhóm) → không gửi lặp'); return true; }
      }
      if (lan < 2) await sleepThat(4000 + Math.floor(Math.random() * 6000));
    }
    const d2 = lay(kk, {}) || {}; if (d2[k]) d2[k]--; luu(kk, d2);
    capNhat('suc_khoe', { tinOk: false, tinLuc: Date.now(), tinLoi: loiCuoi });
    ghi('Báo Lark lỗi: ' + loiCuoi + ' — ' + tin.replace(/\s+/g, ' ').slice(0, 160));
    return false;
  }
  // báo lỗi vào nhóm "Đăng bài fb" — luôn ghi rõ máy nào; mỗi khoá tối đa 1 lần/ngày
  async function baoLoi(noiDung, khoa, toiDa = 1) {
    if (!laTabChinh()) return false;
    if (!trongGioNhan()) { ghi('(ngoài giờ gửi tin) ' + noiDung); return false; }
    return guiLark('loi', `[fb][${TEN_MAY}] ${noiDung}`, { khoa: khoa || '', toiDa });
  }
