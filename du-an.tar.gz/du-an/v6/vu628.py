# ===== (6.28) tổng rà soát =====
# 1) chờ video lên trang: sau mốc 20 phút vẫn hỏi tiếp mỗi 4 phút; kênh chưa có mã khoá quá hạn thì không tải lại trang mãi mà đi tới kết luận
out = thay(out, "      const moc = [1, 2, 3, 5, 8, 12, 16, 20].filter((m) => phut >= m).length;", "      const moc = [1, 2, 3, 5, 8, 12, 16, 20].filter((m) => phut >= m).length + (phut > 20 ? Math.floor((phut - 20) / 4) : 0); // (6.28) qua 20 phút vẫn hỏi tiếp 4 phút/lần")
out = thay(out, "      if (!coApi() && document.visibilityState === 'visible' && phut >= 1 && !(ganManHinh() || hopSoanBai())) {", "      if (!coApi() && document.visibilityState === 'visible' && phut >= 1 && phut < CAI_DAT.CHO_VIDEO_LEN_PHUT + 2 && !(ganManHinh() || hopSoanBai())) { // (6.28) quá hạn → không tải lại trang nữa, đi tới kết luận")
# 2) trước khi đăng lại video: tab ẩn thì chờ tab hiện để nhìn trang (tối đa thêm 30 phút), không đăng lại mù
out = thay(out, "        if (!dd.daNhinTrang && document.visibilityState === 'visible') {", "        if (!dd.daNhinTrang && document.visibilityState !== 'visible' && phut < hanPhut + 30) { if (!dd.choNhin) { dd.choNhin = 1; luu('dang_do', dd); ghi(`${dd.ten}: sau ${hanPhut} phút Facebook chưa trả bài → chờ tab Facebook hiện để nhìn trang trước khi đăng lại (tránh 2 bài)`); } return true; } // (6.28)\n        if (!dd.daNhinTrang && document.visibilityState === 'visible') {")
# 8) đếm số lần chuyển tư cách: riêng từng trang, xoá khi đã đúng tư cách
out = thay(out, "    const lan = lay('lan_chuyen', []).filter((t) => Date.now() - t < 15 * 60000);", "    const kLc = 'lan_chuyen|' + CAI_DAT.TEN_TRANG; const lan = (lay(kLc, []) || []).filter((t) => Date.now() - t < 15 * 60000); // (6.28) đếm riêng từng trang")
out = thay(out, "    lan.push(Date.now()); luu('lan_chuyen', lan);", "    lan.push(Date.now()); luu(kLc, lan);")
out = thay(out, "    if (dungTen) { await dongMenuTaiKhoan(); return true; }", "    if (dungTen) { luu('lan_chuyen|' + CAI_DAT.TEN_TRANG, []); await dongMenuTaiKhoan(); return true; }")
# 5) báo "2 bài trùng": cùng link = 1 bài Facebook trả 2 lần → bỏ; Máy Cao chỉ báo khi Máy Giao không chạy
out = thay(out, "          if (!soChat(a.text, b.text).ok) continue;\n          const kt = 'trung_'", "          if (!soChat(a.text, b.text).ok) continue;\n          if (a.link && b.link && linkGon(a.link) === linkGon(b.link)) continue; // (6.28) 1 thước phim Facebook trả 2 lần (2 mã, cùng link) → không phải trùng\n          if (LA_CAO && !caoNenBao(tinhLich())) continue; // (6.28) Máy Giao đang chạy thì để Máy Giao báo (tránh 2 tin)\n          const kt = 'trung_'")
# 13) Hoãn 10 phút: hoãn cả comment và gắn thẻ + cảm xúc
out = thay(out, "    { const kq0 = await batDemNguoc(laKenhPhu ?", "    if (dangHoan()) return false; // (6.28)\n    { const kq0 = await batDemNguoc(laKenhPhu ?")
out = thay(out, "      const kq = await batDemNguoc((dd.raSoat ? 'gửi bù comment ' : 'comment ') + (dd.ten || ''),", "      if (dangHoan()) return true; // (6.28) đang Hoãn 10 phút → chờ\n      const kq = await batDemNguoc((dd.raSoat ? 'gửi bù comment ' : 'comment ') + (dd.ten || ''),")
# 14) lệnh "về trang" hẹn giờ không cắt ngang lượt đăng đang chuẩn bị
out = out.replace("setTimeout(() => { if (!dangBan && !lay('dang_do', null))", "setTimeout(() => { if (!dangBan && !lay('dang_do', null) && Date.now() - (window.__smhChuanBi || 0) > 90000)")
out = thay(out, "    if (!it.den) it.den = Date.now();\n    datKenh(it.kenh);", "    if (!it.den) it.den = Date.now();\n    window.__smhChuanBi = Date.now(); // (6.28)\n    datKenh(it.kenh);")
# 15) tổng kết cuối ngày: chỉ coi là đã gửi tổng kết 21:30 khi tin đó gửi được
out = thay(out, "Object.keys(lay('tin6_' + homNay(), {}) || {}).some((k) => /^tongtoi_/.test(k));", "Object.entries(lay('tin6_' + homNay(), {}) || {}).some(([k, v]) => /^tongtoi_/.test(k) && v > 0); // (6.28)")
# 18) tổng kết 12:00: gửi lỗi thì lượt sau gửi lại
out = thay(out, "    luu(k, Date.now());\n    const ds = L.filter((x) => !x.xong && typeof x.gioKH === 'number' && x.gioKH < 12 * 60", "    const ds = L.filter((x) => !x.xong && typeof x.gioKH === 'number' && x.gioKH < 12 * 60")
out = thay(out, "    if (!ds.length) { ghi('Tổng kết 12:00: các bài buổi sáng đã lên đủ'); return false; }\n    await baoLoi(tinTongKet('Tổng kết 12:00 (buổi sáng)', ds, '→ cần xử lý ngay'), 'tong12_' + homNay());", "    if (!ds.length) { luu(k, Date.now()); ghi('Tổng kết 12:00: các bài buổi sáng đã lên đủ'); return false; }\n    if (Date.now() - (window.__tk12Thu || 0) < 5 * 60000) return false; window.__tk12Thu = Date.now();\n    if (await baoLoi(tinTongKet('Tổng kết 12:00 (buổi sáng)', ds, '→ cần xử lý ngay'), 'tong12_' + homNay())) luu(k, Date.now()); // (6.28) gửi được mới đánh dấu")
# 19) tin "nhận theo thứ tự" và "bỏ bước phụ" (6.26.8–6.26.9) trước đây không lọt bộ lọc nên chỉ ghi nhật ký → cho gửi nhóm lỗi
out = thay(out, "  const KHOA_NGUY_CAP = /^(thieu_|", "  const KHOA_NGUY_CAP = /^(theothutu_|boqua_|thieu_|")
# 7) số ngẫu nhiên theo ngày bị tràn số → thẻ / câu CTA ngày nào cũng giống nhau
out = out.replace("seed = seed * 31 + ch.charCodeAt(0)", "seed = (seed * 31 + ch.charCodeAt(0)) >>> 0")
