// ==UserScript==
// @name         Smh dang bai fb kenh 1 CHAY THAT 6.15
// @name:vi      Smh đăng bài FB kênh 1 (tự cập nhật — xem số bản trên popup)
// @namespace    smh-dang-bai-fb-kenh1-chay-that
// @version      6.28.1
// @description  Tự đăng bài mỗi ngày lên 3 fanpage: kênh 1 "Vòng Trầm Hương Sơn Mộc Hương ." (9 bài), kênh 2 "Trầm Hương Thủ Đức Sơn Mộc Hương" và kênh 3 "Sơn Mộc Hương - Trầm Chuẩn - Giá Chuẩn" (video theo sheet) — 1 file dùng chung cho Máy Giao (máy chính) và Máy Cao (máy dự phòng)
// @match        https://www.facebook.com/*
// @grant        GM_xmlhttpRequest
// @grant        GM_info
// @grant        GM_getValue
// @grant        GM_setValue
// @grant        GM_deleteValue
// @grant        GM_listValues
// @grant        GM_registerMenuCommand
// @grant        GM_openInTab
// @grant        GM_notification
// @grant        unsafeWindow
// @grant        GM_addElement
// @grant        window.focus
// @connect      open.larksuite.com
// @connect      larksuite.com
// @connect      larksuitecdn.com
// @connect      graph.facebook.com
// @connect      raw.githubusercontent.com
// @connect      drive.usercontent.google.com
// @connect      drive.google.com
// @connect      googleusercontent.com
// @updateURL    /*LINK_CAP_NHAT*/
// @downloadURL  /*LINK_CAP_NHAT*/
// @run-at       document-idle
// @noframes
// ==/UserScript==

(function () {
  'use strict';
  // Chặn chạy trùng: bản cũ (5.x) và bản này dùng chung dấu → máy nào lỡ còn bật cả 2 bản thì chỉ 1 bản chạy.
  const DA_CHAY = 'data-smhfb-runtime-200';
  if (document.documentElement.hasAttribute(DA_CHAY)) return;
  document.documentElement.setAttribute(DA_CHAY, '6');

  // =====================================================================
  //  CÀI ĐẶT
  // =====================================================================
  const K = (s) => 'that_' + s;
  const lay = (k, macDinh) => GM_getValue(K(k), macDinh);
  const luu = (k, v) => GM_setValue(K(k), v);
  const capNhat = (k, doi) => { const v = Object.assign({}, lay(k, {}) || {}, doi); luu(k, v); return v; };
  // Máy nào? Chọn 1 lần trên popup (lưu trong Tampermonkey của máy đó)
  const MAY = lay('may6', '');                 // 'GIAO' | 'CAO' | '' (chưa chọn)
  const LA_GIAO = MAY === 'GIAO', LA_CAO = MAY === 'CAO';
  const TEN_MAY = LA_GIAO ? 'Máy Giao' : LA_CAO ? 'Máy Cao' : 'Máy chưa chọn';
  const PHIEN_BAN = '6.28.4';
  const TEN_HE_THONG = 'Đăng bài fb kênh 1';
  // mã riêng của tab này (giữ nguyên khi tải lại chính tab này; tab mới mở → mã mới)
  const MA_TAB = (() => { let id = null; try { id = sessionStorage.getItem('smhdb_ma_tab'); } catch (e) { /* */ }
    const wn = String(window.name || '').match(/smhdb:(\w+)/);
    // (6.20.4) Facebook xoá window.name khi chuyển tư cách/về trang chủ → trước đây tab tự đổi mã rồi phải chờ ~2,5 phút mới nhận lại quyền làm việc
    if (!id || (wn && wn[1] !== id)) { id = Math.random().toString(36).slice(2, 10); try { sessionStorage.setItem('smhdb_ma_tab', id); } catch (e) { /* */ } }
    try { window.name = 'smhdb:' + id; } catch (e) { /* */ }
    return id; })();

  // (6.16) mã bí mật (mã Lark, link nhóm Lark) KHÔNG nằm trong file (file để công khai cho Tampermonkey tự cập nhật) — lưu riêng trong từng máy
  // (6.21) kênh 1 MỚI (trang 61595055137817, tab t79PeC, video cột M) thay kênh 1 cũ "Vòng Trầm Hương Sơn Mộc Hương ." — công tắc ở tab Hệ thống (mặc định tắt kênh cũ)
  const K1_CU = (() => { try { return GM_getValue('that_k1_cu', false) === true; } catch (e) { return false; } })();
  const BIMAT = (() => { try { return GM_getValue('that_bimat6', null) || {}; } catch (e) { return {}; } })();
  const CAI_DAT = {
    // Nhóm Lark nhận BÁO CÁO cuối ngày (nhóm Marketing, từ khoá "fb") — cũng nhận báo cáo tuần Khanh Trầm Hương
    WEBHOOK_BAO_CAO: BIMAT.hookBaoCao || '/*BM_HOOK_BC*/',
    // Nhóm Lark "Đăng bài fb" nhận BÁO LỖI khi đăng (giai đoạn mới chuyển sang tự động)
    WEBHOOK_LOI: BIMAT.hookLoi || '/*BM_HOOK_LOI*/',

    // App Lark "Script Dang Bai Kenh 1"
    LARK_APP_ID: BIMAT.appId || '/*BM_APP_ID*/',
    LARK_APP_SECRET: BIMAT.appSecret || '/*BM_APP_SECRET*/',
    SHEET_TOKEN: 'WPhusx4UJhvTbstKQHFlNkWHggd',   // tài liệu "MKT 10. KỊCH BẢN MARTKETING"
    TAB_BAI: 'apU3Ne',                              // tab "Bài viết kênh 1" (Bài 1/2/3)
    TAB_VIDEO: K1_CU ? 'e2f139' : 't79PeC',         // tab video + manifest của kênh 1 (6.21: kênh mới t79PeC)
    COT_VIDEO_K1: K1_CU ? 13 : 12,                  // cột file video: kênh cũ N, kênh mới M
    LINK_SHEET: 'https://zgml41unmm8.sg.larksuite.com/wiki/G9gOwWa7OiQxuCkYWKJlkHt4g2f?sheet=apU3Ne',
    LINK_SHEET_VIDEO: 'https://zgml41unmm8.sg.larksuite.com/wiki/G9gOwWa7OiQxuCkYWKJlkHt4g2f?sheet=' + (K1_CU ? 'e2f139' : 't79PeC'),
    O_LICH: 'Z8',     // (6.28.2) lịch giờ các bài thêm trong ngày — máy nào xếp lịch trước ghi vào, máy kia làm theo (1 máy tắt thì máy còn lại tự xếp)
    O_KHOA: 'Z1',     // ô "giữ chỗ" chung của 2 máy (tab Bài viết kênh 1) — chỉ dùng khi máy chính trễ
    O_BAO_CAO: 'Z2',  // ô ghi dấu "đã gửi báo cáo ngày" (để 2 máy không gửi trùng)

    TEN_TRANG: 'Vòng Trầm Hương Sơn Mộc Hương .',
    TEN_NGAN: 'Vòng Trầm Hương SMH',
    TIEN_TO_TIN: '[fb kênh 1]',
    URL_TRANG: 'https://www.facebook.com/vongtramhuongsonmochuong/',
    DUONG_DAN_TRANG: '/vongtramhuongsonmochuong',

    // ---- LỊCH 9 BÀI/NGÀY (giờ ngẫu nhiên trong khung, xen kẽ Bài → Video → Manifest) ----
    LICH: [
      { k: 'b1', ten: 'Bài 1', tenBC: 'Bài 1 twist', loai: 'b1', tu: '06:30', den: '06:50' },
      { k: 'v1', ten: 'Video 1', tenBC: 'Video 1', loai: 'video', so: 0, tu: '07:45', den: '08:05' },
      { k: 'm1', ten: 'Manifest 1', tenBC: 'Manifest 1', loai: 'manifest', so: 0, tu: '09:00', den: '09:20' },
      { k: 'b2', ten: 'Bài 2', tenBC: 'Bài 2 twist + ảnh', loai: 'b2', tu: '10:15', den: '10:35' },
      { k: 'v2', ten: 'Video 2', tenBC: 'Video 2', loai: 'video', so: 1, tu: '11:30', den: '11:50' },
      { k: 'm2', ten: 'Manifest 2', tenBC: 'Manifest 2', loai: 'manifest', so: 1, tu: '12:45', den: '13:05' },
      { k: 'b3', ten: 'Bài 3', tenBC: 'Bài 3 storytelling', loai: 'b3', tu: '16:30', den: '16:50' },
      { k: 'v3', ten: 'Video 3', tenBC: 'Video 3', loai: 'video', so: 2, tu: '17:45', den: '18:15' },
      { k: 'm3', ten: 'Manifest 3', tenBC: 'Manifest 3', loai: 'manifest', so: 2, tu: '19:15', den: '19:40' },
    ],
    CACH_LICH_PHUT: 60,        // 2 bài liền nhau theo lịch cách ít nhất 1 tiếng
    CACH_BU_PHUT: 30,          // bài trễ thì đăng bù lần lượt, cách nhau 30 phút
    CACH_TRANG_PHUT: 20,       // cách bài gần nhất trên trang (kể cả bài đăng tay) ít nhất 20 phút
    MOC_NHAY_TAB: ['05:00', '12:30', '19:00'], // (6.25) Máy Giao: đến các mốc này tự đưa tab Facebook lên trước màn hình (giờ không ai dùng máy)
    GIO_THEM_MUON_NHAT: '21:00', // (6.25) bài thêm xếp giờ muộn nhất 21:00
    GIO_CHOT_THEM: '22:30',    // (6.20) bài kênh 1 thêm (Video 4, Manifest 4…) được đăng tới giờ này
    GIO_CHOT: '21:30',         // quá giờ này bài chưa đăng thì bỏ, ghi vào báo cáo ngày
    GIO_BAO_CAO_THIEU: '21:45',// chưa đủ 9 bài thì 21:45 vẫn gửi báo cáo (ghi rõ bài chưa đăng)
    CAO_TRE_PHUT: 25,          // Máy Cao (dự phòng) chỉ ra tay khi quá giờ 25 phút mà trang vẫn chưa có bài
    CAO_CHO_MO_PHUT: 15,       // Máy Cao vừa mở lại tab: chờ 15 phút cho Máy Giao làm trước
    GIAO_GIU_CHO_SAU_PHUT: 15, // Máy Giao đăng trễ quá 15 phút thì phải "giữ chỗ" trước (tránh trùng với Máy Cao)
    NHUONG_PHUT: 40,           // (6.15) máy kia giữ chỗ quá 40 phút mà bài chưa lên = máy đó kẹt → máy này được làm thay (6.20: 20 → 40 vì video có thể xử lý tới 20 phút)
    THU_LAI_PHUT: 5,           // lỗi khi đăng → 5 phút sau thử lại
    SO_LAN_THU: 3,             // mỗi vòng thử tối đa 3 lần (cách nhau 5 phút)
    SO_VONG_THU: 3,            // (6.10) hết 1 vòng vẫn lỗi → nghỉ rồi thử vòng mới; tối đa 3 vòng (9 lần) trước giờ chốt
    NGHI_GIUA_VONG_PHUT: 20,   // nghỉ giữa 2 vòng thử (trong lúc nghỉ, các bài khác vẫn đăng bình thường)
    CHO_NGUOI_TOI_DA_PHUT: 10, // đến giờ mà nhân sự đang dùng trang: chờ tối đa 10 phút rồi vẫn đăng
    RANH_SAU_PHUT: 3,          // nhân sự ngừng thao tác 3 phút thì coi như trang rảnh
    DEM_NGUOC_GIAY: 3,         // trước mỗi việc chạm vào trang: đếm ngược 3 giây
    // ---- đọc Lark sheet: chỉ 2 lần/ngày ----
    GIO_DOC_NHE: '13:30',      // đọc để báo thiếu nội dung (còn cả buổi chiều để bổ sung)
    GIO_DOC_CHOT: '18:30',     // đọc chốt + tải sẵn đồ đăng ngày mai + tạo sẵn video manifest
    // ---- kiểm comment ----
    KIEM_CMT_SAU_PHUT: [2, 10, 20], // sau khi đăng: kiểm ngay (chờ ~2 phút cho bài hiện), 10 phút, 20 phút
    KIEM_CMT_TOI_DA: 3,        // mỗi bài kiểm tối đa 3 lần (tính cả kiểm tay)
    GIO_KIEM_CMT_CUOI: '19:00',// 19:00 kiểm 1 lượt các bài còn thiếu comment
    GUI_BU_TOI_DA: 2,          // mỗi bài gửi bù tối đa 2 lần, vẫn thiếu thì báo nhóm
    DO_TRANG_PHUT: 10,         // dò bài trên trang (qua Facebook, không tốn Lark) 10 phút/lần
    GIO_DO_TU: '06:00', GIO_DO_DEN: '22:30',
    GIO_NHAN_TU: '06:00', GIO_NHAN_DEN: '23:00', // khung gửi tin Lark
    // ---- đăng ----
    VI_TRI: 'Sơn Mộc Hương',
    VI_TRI_DIA_CHI: 'Vạn Phúc',
    NEN: 'Đỏ đậm',
    SO_NHOM_TOI_DA: 9,
    GIOI_HAN_KY_TU_NEN: 130,
    ANH_CANH_TOI_DA: 2048,
    SUA_NEN_B2: true,          // Bài 2: đăng xong sửa bài sang nền đỏ (gỡ ảnh)
    TAI_LAI_SAU_CMT: false,
    THA_CAM_XUC: true, THA_CAM_XUC_CMT: true,
    NGUONG_BAI: 0.9, NGUONG_CMT: 0.6,
    MA_KHOA_HAN_NGAY: 90,
    CHO_VIDEO_LEN_PHUT: 8,     // video/manifest bấm Đăng xong: chờ tối đa 8 phút cho Facebook xử lý rồi mới kết luận
    CHO_VIDEO_XU_LY_PHUT: 20,  // (6.15) có mã khoá: hộp đã đóng mà Facebook chưa có bài → chờ tới 20 phút, vẫn không có thì đăng lại (có dò trùng trước khi bấm Đăng)
    TREO_PHUT: 4,              // (6.15) đang soạn/đăng mà 4 phút không có bước mới → coi là kẹt: đóng hộp, tải lại trang, thử lại
    // ---- manifest ----
    MF_GIAY: 15,
    O_NHAC_DU_PHONG: 'G217',   // ô chứa file nhạc dự phòng (tab Kênh 1) — sửa được trên popup
    // Comment cố định (Bài 3, video, manifest)
    CMT_BAI3: 'Sơn Mộc Hương - Trầm Chuẩn - Giá Chuẩn\n• Zalo: 0762222448\n• Web: sonmochuong.com\n• Showroom: 76 đường 2, Khu Đô Thị Vạn Phúc, Phường Hiệp Bình, TP.HCM\n• Đổi trả trong 30 ngày khi không còn nhu cầu.\n• Thương hiệu chính hãng đã được Cục SHTT bảo hộ.\n• Đánh giá 5 sao shop hỗ trợ 100% phí ship đổi size.\n• Cam kết sản phẩm đúng mô tả.\n• Nói không với trầm nấu dầu.',
    // ---- (6.9) lời kêu gọi vào nhóm Zalo, nối vào cuối comment chữ — sửa được ở tab "Comment" trên popup ----
    O_CMT: 'Z3',      // ô lưu cài đặt comment chung của 2 máy (tab Bài viết kênh 1)
    LINK_ZALO: 'https://zalo.me/g/glqz9fnh7pcfx2gffmdh',
    CTA_MAC_DINH: [
      'Vào nhóm Zalo của Sơn Mộc Hương để hỏi trực tiếp trước khi chọn vòng trầm hương nhé',
      'Người mới chơi trầm muốn được tư vấn chọn size, chọn loại thì vào nhóm Zalo này',
      'Còn phân vân chưa biết chọn vòng nào? Vào nhóm Zalo Sơn Mộc Hương để được hướng dẫn',
      'Muốn xem thêm hình thật, video thật vòng trầm hương để mộc thì vào nhóm Zalo nhé',
      'Có câu hỏi về trầm mà chưa ai giải đáp? Vào nhóm Zalo Sơn Mộc Hương hỏi ngay',
      'Tham gia nhóm Zalo để nhận kiến thức phân biệt vòng trầm hương 108 hạt thật giả',
      'Sợ mua nhầm trầm? Vào nhóm Zalo để hỏi kỹ trước khi xuống tiền',
      'Đang tìm vòng trầm hương làm quà? Vào nhóm Zalo để được gợi ý mẫu phù hợp',
      'Nhóm Zalo Sơn Mộc Hương — nơi hỏi đáp về vòng trầm hương, nhang trầm và cách bảo quản',
      'Muốn biết cách đo tay chọn size chuỗi 108 hạt? Vào nhóm Zalo xem hướng dẫn',
      'Vào nhóm Zalo để xem trước các mẫu vòng trầm hương đang có tại showroom Thủ Đức',
      'Mới đeo trầm, chưa biết bảo quản sao cho đúng? Vào nhóm Zalo hỏi nhé',
    ],
    // ---- (6.11) kho thẻ cho video / manifest: mỗi bài bốc ngẫu nhiên 8 thẻ — sửa ở tab "Comment & Thẻ" ----
    O_BC_GIAO: 'Z5',  // (6.16) báo cáo lỗi kỹ thuật của Máy Giao (Claude đọc mỗi tối)
    O_BC_CAO: 'Z6',   // (6.16) báo cáo lỗi kỹ thuật của Máy Cao
    O_DUYET: 'Z7',    // (6.16) Máy Cao bấm "Duyệt bản mới"
    LINK_TRANG_THAI: 'https://raw.githubusercontent.com/phanbacao/smh-dang-bai-fb/main/trangthai.json',
    LINK_CAP_NHAT: '/*LINK_CAP_NHAT*/', // (6.18) nơi Tampermonkey tự tải bản mới đã duyệt
    LINK_THU_DRIVE: 'https://drive.usercontent.google.com/download?id=1S8X7GJEaVGBPGMf1Eu5UHPvh5m_BVOQj&export=download', // (6.18) thử: Tampermonkey có đọc được file phát hành trên Google Drive không
    O_THE: 'Z4',      // ô lưu kho thẻ chung của 2 máy (tab Bài viết kênh 1)
    SO_THE: 8,
    THE_VIDEO: [
      'Bí kíp chọn vòng trầm hương 108 hạt giá bao nhiêu cho người mua lần đầu',
      'Vì sao cùng là vòng trầm hương 108 hạt nhưng giá lại chênh lệch rất lớn',
      'Làm sao biết giá vòng trầm hương 108 hạt có hợp lý hay không',
      'Hướng dẫn cách xem giá vòng trầm hương 108 hạt chuẩn xác để không bị mua hớ',
      'Vòng trầm hương 108 hạt tự nhiên giá bao nhiêu là hợp lý',
      'Vòng trầm hương 108 hạt giá bao nhiêu mới đúng giá trị',
      'Hướng dẫn cách xem giá vòng trầm hương 108 hạt cho người mới chơi trầm',
      'Tại sao cùng là vòng trầm hương 108 hạt nhưng giá lại khác nhau?',
      'Cách phân biệt vòng trầm hương 108 hạt thật giả',
      'Vòng trầm hương 108 hạt để mộc không phủ keo sáp',
      'Cách chọn size vòng trầm hương 108 hạt',
      'Người mới chơi trầm nên chọn vòng nào',
      'Cách bảo quản vòng trầm hương khi đeo hằng ngày',
      'Vòng trầm hương làm quà tặng ý nghĩa',
      'Sơn Mộc Hương trầm chuẩn giá chuẩn',
      'Kinh nghiệm mua vòng trầm hương lần đầu',
    ],
    THE_VIDEO_K4: ['Nhang trầm hương sạch', 'Nhang trầm hương Hà Xá', 'Nhang sạch không hoá chất', 'Nhang trầm hương thật giả', 'Cách chọn nhang trầm hương', 'Nhang không tăm', 'Nụ trầm hương', 'Trầm Hương Hà Xá'], // (6.26.9) kênh Trầm Hương Hà Xá (sửa ở tab Comment & Thẻ)
    THE_NHAC_NGAY: 7, // (6.26.9) bộ thẻ để quá 7 ngày chưa sửa / chưa xác nhận → nhắc kiểm tra
    CMT_HX: 'Trầm Hương Hà Xá - Trầm Của Người Việt\n• Zalo: 0774222448\n• Web: tramhuonghaxa.com\n• Bảo hành đổi trả trong 30 ngày', // (6.26) comment cố định kênh Hà Xá (mỗi ý 1 dòng)
    THE_VIDEO_K2: [
      'Trầm hương Thủ Đức',
      'Showroom trầm hương Thủ Đức',
      'Vòng trầm hương Thủ Đức',
      'Mua vòng trầm hương ở Thủ Đức',
      'Vòng trầm hương 108 hạt thật giả',
      'Cách phân biệt vòng trầm hương thật giả',
      'Xem vòng trầm hương trực tiếp tại showroom',
      'Đeo thử vòng trầm hương trước khi mua',
      'Vòng trầm hương để mộc không keo sáp',
      'Chọn size vòng trầm hương 108 hạt',
      'Vòng trầm hương cho người mới chơi',
      'Nhang trầm hương Thủ Đức',
      'Trầm hương TP.HCM',
      'Sơn Mộc Hương Thủ Đức',
      'Vòng trầm hương làm quà tặng',
      'Kinh nghiệm mua vòng trầm hương',
    ], // (6.20) thẻ video kênh 2 Trầm Hương Thủ Đức
    THE_VIDEO_K3: [
      'Nhang trầm hương sạch',
      'Nhang trầm hương không nhuộm màu',
      'Nhang trầm không pha mùi',
      'Nhang trầm không cuộn tàn',
      'Cách nhận biết nhang trầm sạch',
      'Phân biệt nhang trầm thật giả',
      'Cách nhận biết nhang tẩm hóa chất',
      'Nhang trầm tăm tre để mộc',
      'Nhang trầm bột trầm bời lời',
      'Nụ trầm hương',
      'Nhang trầm thắp hằng ngày',
      'Nhang trầm cho bàn thờ gia tiên',
      'Trầm chuẩn giá chuẩn',
      'Sơn Mộc Hương trầm chuẩn',
      'Nhang trầm sỉ lẻ CTV',
      'Mua nhang trầm hương uy tín',
    ], // (6.20) thẻ video kênh 3 Sơn Mộc Hương Trầm Chuẩn (nhang)
    THE_MANIFEST: [
      'Manifest tài lộc mỗi ngày', 'Năng lượng tích cực thu hút tài chính', 'Câu khẳng định đón nhận tiền bạc', 'Manifest bình an và may mắn',
      'Lời chúc tài lộc đầu ngày', 'Năng lượng tốt đang tìm đến bạn', 'Đón nhận vận may và thịnh vượng', 'Sơn Mộc Hương manifest năng lượng',
      'Manifest tiền bạc tự tìm đến', 'Câu nói năng lượng tích cực mỗi ngày', 'Thu hút tài lộc và bình an', 'Manifest công việc thuận lợi',
      'Lời khẳng định thịnh vượng', 'Đón nhận năng lượng tốt lành', 'Manifest may mắn trong tuần mới', 'Năng lượng tài chính dồi dào',
    ],
    // ---- báo cáo tuần Khanh Trầm Hương (chỉ Máy Cao) ----
    KHANH_BAT: true,
    KHANH_URL: 'https://www.facebook.com/100063806572484',
    KHANH_TEN: 'Khanh Trầm Hương',
    KHANH_GIO: '19:00',
    KHANH_THU: 5,
    KHANH_MOC_GIO: [0, 1, 2, 3, 12.84, 18, 24, 27],
    KHANH_TOI_DA_BAI: 20,
    // Facebook Graph API — CHỈ ĐỌC. Mã khoá là BÍ MẬT, cài bằng nút "Cài mã khoá" trên popup.
    FB_PAGE_ID: '1196332230224812',
    FB_TOKEN: '',
    CAM_XUC_CHON: ['hạnh phúc', 'hào hứng', 'tuyệt vời', 'tích cực', 'biết ơn', 'cảm kích', 'vui vẻ', 'thư giãn', 'hân hoan'],
    SUA_VIDEO_SAU_DANG: true,  // (6.11) video/manifest đăng xong: mở "Chỉnh sửa thước phim" gắn thẻ Trang Sơn Mộc Hương + cảm xúc
    // ---- (6.19) 3 KÊNH (3 fanpage). Kênh 1 giữ nguyên như cũ; kênh 2, 3 chỉ đăng video theo sheet ----
    //  cot: số thứ tự cột (A = 0): ngay = Ngày đăng, video = file video, cap = caption, tt = Trạng thái, link = nơi ghi link bài
    KENH: {
      1: K1_CU ? { so: 1, ten: 'Vòng Trầm Hương Sơn Mộc Hương .', ngan: 'Vòng Trầm Hương SMH', url: 'https://www.facebook.com/vongtramhuongsonmochuong/', duong: ['/vongtramhuongsonmochuong', '/61590895435527'], pageId: '1196332230224812' }
        : { so: 1, ten: 'Vòng Trầm Hương Sơn Mộc Hương', ngan: 'Vòng Trầm Hương SMH', url: 'https://www.facebook.com/vongtramhuongsonmochuong1/', duong: ['/vongtramhuongsonmochuong1', '/61595055137817'], pageId: '', boId: '1196332230224812', moi: true },
      2: { so: 2, ten: 'Trầm Hương Thủ Đức Sơn Mộc Hương', ngan: 'Trầm Hương Thủ Đức', url: 'https://www.facebook.com/tramhuongthuducsonmochuong/', duong: ['/tramhuongthuducsonmochuong', '/61586752146281'], pageId: '',
        tab: 'em39qJ', tenTab: 'Kênh 2 Trầm Hương Thủ Đức', link: 'https://zgml41unmm8.sg.larksuite.com/wiki/G9gOwWa7OiQxuCkYWKJlkHt4g2f?sheet=em39qJ', cot: { cap: 4, tt: 6, ngay: 7, video: 8, link: 9 } },
      3: { so: 3, ten: 'Sơn Mộc Hương - Trầm Chuẩn - Giá Chuẩn', ngan: 'SMH Trầm Chuẩn', url: 'https://www.facebook.com/sonmochuongtramchuangiachuan/', duong: ['/sonmochuongtramchuangiachuan', '/61575413185162'], pageId: '',
        tab: '4OtbFA', tenTab: 'Kênh 3 Trầm Hương SMH', link: 'https://zgml41unmm8.sg.larksuite.com/wiki/G9gOwWa7OiQxuCkYWKJlkHt4g2f?sheet=4OtbFA', cot: { cap: 3, tt: 6, ngay: 7, video: 8, link: 9 } },
      4: { so: 4, ten: 'Trầm Hương Hà Xá', ngan: 'Trầm Hương Hà Xá', url: 'https://www.facebook.com/100092534930523', duong: ['/100092534930523'], pageId: '', hx: true, anSo: true, viTri: { go: 'trầm hương hà xá', re: 'Hà Xá', ten: 'Trầm Hương HÀ XÁ' }, ganThe: true, tag: 'Trầm Hương Hà Xá', khongDuyet: true, // (6.26) thương hiệu khác: comment riêng, gắn thẻ chính trang, có video là đăng (không cần ĐÃ DUYỆT)
        tab: 'ZSDDld', tenTab: 'Kênh Trầm Hương Hà Xá', link: 'https://zgml41unmm8.sg.larksuite.com/wiki/G9gOwWa7OiQxuCkYWKJlkHt4g2f?sheet=ZSDDld', cot: { cap: 4, tt: 7, ngay: 8, video: 9, link: 10 } },
    },
    KENH_CACH_PHUT: 30,        // kênh 2, 3: 2 video cùng 1 trang cách nhau ít nhất 30 phút
    KENH_TRUOC_PHUT: [5, 15],  // kênh 2, 3 đăng trước bài đầu tiên của kênh 1 khoảng 5–15 phút (ngẫu nhiên)
    KENH_SUA_TOI_DA: 2,        // kênh 2, 3: thả cảm xúc lỗi thì thử thêm 1 lần rồi thôi
  };
  // (6.19) "kênh đang làm": các chỗ dùng CAI_DAT.TEN_TRANG / URL_TRANG / FB_PAGE_ID… tự theo kênh của việc đang làm (mặc định kênh 1)
  let KENH_HT = 1;
  const kenhHT = () => CAI_DAT.KENH[KENH_HT] || CAI_DAT.KENH[1];
  const idTrangKenh = (k) => { const c = CAI_DAT.KENH[k] || CAI_DAT.KENH[1]; return c.pageId || String((lay('kenh_id6', {}) || {})[c.so] || ''); };
  // (6.26) danh sách kênh + tên hiển thị (kênh Hà Xá chỉ ghi tên, không ghi "Kênh 4")
  const KENH_PHU = [2, 3, 4], KENH_ALL = [1, 2, 3, 4];
  const tenKenh = (c) => { const x = CAI_DAT.KENH[c] || CAI_DAT.KENH[1]; return x.anSo ? x.ngan : `Kênh ${c}`; };
  const tenKenhDai = (c) => { const x = CAI_DAT.KENH[c] || CAI_DAT.KENH[1]; return x.anSo ? x.ngan : `Kênh ${c} (${x.ngan})`; };
  const duongNay = () => { const p = location.pathname.toLowerCase().replace(/\/+$/, ''); if (p === '/profile.php') { const id = new URLSearchParams(location.search).get('id'); if (id) return '/' + id; } return p; };
  function datKenh(k) { k = +k || 1; if (!CAI_DAT.KENH[k]) k = 1; KENH_HT = k; return k; }
  for (const [ten, f] of [['TAG_TEN', () => kenhHT().tag || 'Sơn Mộc Hương'], ['TEN_TRANG', () => kenhHT().ten], ['TEN_NGAN', () => kenhHT().ngan], ['URL_TRANG', () => kenhHT().url], ['DUONG_DAN_TRANG', () => kenhHT().duong[0]], ['FB_PAGE_ID', () => idTrangKenh(KENH_HT)]]) {
    Object.defineProperty(CAI_DAT, ten, { get: f, configurable: true, enumerable: true });
  }
  // lịch: 9 bài kênh 1 cố định + các video kênh 2, 3 của hôm nay (theo sheet) — LICH luôn là lịch của HÔM NAY
  const LICH_GOC = CAI_DAT.LICH.map((x) => Object.assign({ kenh: 1 }, x));
  const LICH = LICH_GOC.slice();
  const kenhCua = (k) => { const it = LICH.find((x) => x.k === k); if (it) return it.kenh || 1; const m = String(k || '').match(/^k([2-4])/); return m ? +m[1] : 1; };
  const tenSlot = (k) => (LICH.find((x) => x.k === k) || {}).ten || (/^k[2-4]/.test(k) ? `${tenKenh(+k[1])} · Video ${'abcdefgh'.indexOf(k[2]) + 1}` : /^[vm]\d$/.test(k) ? `${k[0] === 'v' ? 'Video' : 'Manifest'} ${k[1]}` : /^b\d+$/.test(k) ? `Bài ${k.slice(1)}` : k);

  // =====================================================================
  //  Tiện ích chung
  // =====================================================================
  const HE_SO_CHAM = LA_GIAO ? 1.8 : 1; // Máy Giao chạy chậm hơn → mỗi lần chờ dài hơn 1,8 lần cho chắc
  const sleep = (ms) => new Promise((r) => setTimeout(r, Math.round(ms * HE_SO_CHAM)));
  const sleepThat = (ms) => new Promise((r) => setTimeout(r, ms));
  const chuan = (s) => String(s == null ? '' : s).normalize('NFC').replace(/\s+/g, ' ').trim();
  const thuong = (s) => chuan(s).toLowerCase();
  const pad = (n) => String(n).padStart(2, '0');
  const ngayStr = (d) => `${pad(d.getDate())}-${pad(d.getMonth() + 1)}-${d.getFullYear()}`;
  const gioStr = (d) => `${pad(d.getHours())}:${pad(d.getMinutes())}`;
  const phutStr = (p) => `${pad(Math.floor(p / 60))}:${pad(p % 60)}`;
  const phutTrongNgay = (d) => d.getHours() * 60 + d.getMinutes();
  const docGio = (hhmm) => { const [h, m] = hhmm.split(':').map(Number); return h * 60 + m; };
  const homNay = () => ngayStr(new Date());
  const congNgay = (n) => { const d = new Date(); d.setDate(d.getDate() + n); return d; };
  const ngayMai = () => ngayStr(congNgay(1));
  const THU = ['CN', 'T2', 'T3', 'T4', 'T5', 'T6', 'T7'];
  const lucPhut = (phut) => { const d = new Date(); d.setHours(Math.floor(phut / 60), phut % 60, 0, 0); return d.getTime(); };
  const trongGioNhan = () => { const m = phutTrongNgay(new Date()); return m >= docGio(CAI_DAT.GIO_NHAN_TU) && m < docGio(CAI_DAT.GIO_NHAN_DEN); };
  const bam = (s) => { let h = 0; for (const ch of chuan(s)) h = (h * 31 + ch.codePointAt(0)) >>> 0; return h.toString(36); };
  const esc = (s) => String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  const conLai = (ms) => { const g = Math.max(0, Math.round(ms / 1000)); const h = Math.floor(g / 3600), p = Math.floor((g % 3600) / 60), s = g % 60;
    return h ? `${h} giờ ${pad(p)} phút` : `${pad(p)}:${pad(s)}`; };
  const gioNgan = (t) => (t ? gioStr(new Date(t)).replace(':', 'h') : '--h--');

  async function cho(fn, timeout = 8000, buoc = 300) {
    const han = Date.now() + timeout * HE_SO_CHAM;
    while (Date.now() < han) {
      if (window.__smhHuyLuot) { const ly = window.__smhHuyLuot; window.__smhHuyLuot = 0; const e = new LoiMem(ly); e.taiLai = true; throw e; } // (6.15) bộ canh treo: dừng bước đang kẹt
      try { const v = fn(); if (v) return v; } catch (e) { /* bỏ qua */ }
      await sleepThat(buoc);
    }
    return null;
  }

  class LoiMem extends Error {}   // lỗi có thể thử lại
  class LoiCung extends Error {}  // lỗi không được thử lại (tránh đăng trùng)
  class LoiDung extends Error {} // yêu cầu dừng hoặc mất quyền làm việc
  class LoiLark extends LoiMem {}
  class LoiTuChoi extends Error {} // Facebook báo rõ là KHÔNG nhận comment
  class LoiTamHoan extends LoiDung {} // tab bị ẩn / tạm mất quyền: lát nữa làm tiếp
  class LoiTrung extends LoiDung { constructor(m, p) { super(m); this.p = p; } } // phát hiện bài đã có ngay trước khi bấm Đăng
  class LoiChuaGui extends Error {} // comment CHƯA được gửi đi (an toàn để thử lại)
  class LoiLarkToken extends LoiMem {} // mã truy cập Lark hết hạn
  class LoiThieu extends LoiMem {} // thiếu nội dung trong sheet
  const khoaSo = (s) => thuong(s).replace(/[^\p{L}\p{N}]+/gu, '');
  // (6.21) văn bản có chứa ĐÚNG tên trang đang làm (phân biệt "…Sơn Mộc Hương ." với "…Sơn Mộc Hương")
  function chuaTenTrang(txt) { const t = chuan(txt || ''); const ten = chuan(CAI_DAT.TEN_TRANG).trim(); const goc = ten.replace(/\s*\.$/, ''); let i = t.indexOf(goc); while (i >= 0) { const sau = t.slice(i + goc.length); const coCham = /^\s?\./.test(sau); if (/\.$/.test(ten) ? coCham : !coCham) return true; i = t.indexOf(goc, i + 1); } return false; }
  const chuanTen = (s) => { const c = chuan(s).replace(/[?？!]+$/, '').trim(); return khoaSo(c) + (/\.$/.test(c) ? '.' : ''); }; // (6.21) giữ dấu chấm cuối: "…Sơn Mộc Hương ." (kênh cũ) ≠ "…Sơn Mộc Hương" (kênh 1 mới)

  // ---------------- nhật ký ----------------
  function anBiMat(msg) {
    let t = String(msg);
    const secrets = [CAI_DAT.LARK_APP_SECRET, CAI_DAT.WEBHOOK_BAO_CAO, CAI_DAT.WEBHOOK_LOI, lay('fb_token', ''), CAI_DAT.FB_TOKEN].filter(Boolean);
    for (const x of secrets) t = t.split(x).join('[ĐÃ ẨN]');
    return t.replace(/EAA[A-Za-z0-9]{40,}/g, '[MÃ FB ĐÃ ẨN]')
      .replace(/https:\/\/open\.larksuite\.com\/open-apis\/bot\/v2\/hook\/[^\s"']+/g, '[WEBHOOK ĐÃ ẨN]')
      .replace(/((?:access_token|app_secret|Authorization)["']?\s*[:=]\s*["']?)[^\s,"'}&]+/gi, '$1[ĐÃ ẨN]');
  }
  const laMocQuanTrong = (m) => /Đăng|đăng|comment|Lỗi|lỗi|dừng|Tạm dừng|giữ chỗ|nhường|Khởi động|Lark tạm ngừng|phục hồi|Báo cáo|báo nhóm/.test(m);
  function khoaNK(d) { return 'nk6_' + ngayStr(d); }
  function gioNK(t) { const d = new Date(t); return ngayStr(d).slice(0, 5) + ' ' + gioStr(d) + ':' + pad(d.getSeconds()); }
  function dongNK(e) { return gioNK(e.luc) + ' ' + e.msg + (e.so > 1 ? ' [lặp ' + e.so + ' lần; cuối ' + gioNK(e.cuoi) + ']' : ''); }
  function docNhatKy(soNgay = 3) {
    const ds = [];
    for (let i = soNgay - 1; i >= 0; i--) ds.push(...lay(khoaNK(congNgay(-i)), []));
    return ds.sort((a, b) => a.luc - b.luc);
  }
  function luuNK(msg, quanTrong = false, tab = MA_TAB) {
    const now = Date.now(), k = khoaNK(new Date());
    const ds = lay(k, []);
    const text = anBiMat(msg).slice(0, 2200) + (tab ? ' [tab ' + tab + ']' : '');
    const lap = ds.slice().reverse().find((e) => e.msg === text && now - e.cuoi < 30 * 60000);
    if (lap) { lap.so++; lap.cuoi = now; }
    else ds.push({ luc: now, cuoi: now, msg: text, so: 1, quanTrong });
    while (ds.length > 1500 || JSON.stringify(ds).length > 220000) {
      const i = ds.findIndex((e) => !e.quanTrong);
      ds.splice(i < 0 ? 0 : i, 1);
    }
    luu(k, ds);
  }
  function chupLoi(tieuDe) {
    try {
      const ds = Array.from(document.querySelectorAll('div[role="dialog"]')).map((d, i) => { const r = d.getBoundingClientRect(); return i + ':' + Math.round(r.width) + 'x' + Math.round(r.height) + (d.closest('[aria-hidden="true"]') ? ':ẩn' : '') + ':' + (d.innerText || '').replace(/\s+/g, ' ').slice(0, 70); });
      ghi('Lỗi chi tiết [' + tieuDe + '] bản ' + PHIEN_BAN + ' | tab ' + (document.visibilityState) + ' | hộp: ' + (ds.join(' ¦ ') || 'không có') + ' | trang: ' + location.pathname.slice(0, 60));
    } catch (e) { /* */ }
  }
  window.addEventListener('error', (ev) => { try { if (/ResizeObserver/.test(ev.message || '')) return; ghi('Lỗi script: ' + (ev.message || '') + ' @' + String(ev.filename || '').slice(-30) + ':' + ev.lineno); } catch (e) { /* */ } });
  window.addEventListener('unhandledrejection', (ev) => { try { ghi('Lỗi script (promise): ' + String((ev.reason && ev.reason.message) || ev.reason || '').slice(0, 160)); } catch (e) { /* */ } });
  // Script tự tải lại / chuyển trang: dọn chữ gõ dở + chặn hộp hỏi "Tải lại trang web?" của trình duyệt (hộp này làm cả trang đứng chờ người bấm)
  let roiTrangLuc = 0;
  window.addEventListener('beforeunload', (e) => { if (Date.now() - roiTrangLuc < 20000) { try { e.stopImmediatePropagation(); } catch (er) { /* */ } } }, true);
  try {
    if (typeof GM_addElement === 'function') GM_addElement('script', { textContent: "(function(){document.addEventListener('smhfb-roi-trang',function(){try{window.onbeforeunload=null;var P=window.BeforeUnloadEvent&&BeforeUnloadEvent.prototype;if(P){Object.defineProperty(P,'returnValue',{configurable:true,get:function(){return '';},set:function(){}});P.preventDefault=function(){};}window.addEventListener('beforeunload',function(e){e.stopImmediatePropagation();},true);}catch(e){}});})();" });
  } catch (er) { /* */ }
  function donNhapDo() {
    let n = 0;
    for (const ed of document.querySelectorAll('div[contenteditable="true"], textarea')) {
      if (ed.closest && ed.closest('#smhfb,#smhfb-nho,#smhfb-soan-w,#smhfb-gan-w,#smhfb-gan-modal')) continue;
      const v = ed.tagName === 'TEXTAREA' ? ed.value : ed.innerText;
      if (!String(v || '').trim()) continue;
      try { if (ed.tagName === 'TEXTAREA') { ed.value = ''; } else { ed.focus(); document.execCommand('selectAll', false); document.execCommand('delete', false); } n++; } catch (er) { /* */ }
    }
    return n;
  }
  function roiTrang(url) {
    roiTrangLuc = Date.now();
    try { document.dispatchEvent(new CustomEvent('smhfb-roi-trang')); } catch (er) { /* */ }
    try { donNhapDo(); } catch (er) { /* */ }
    for (const w of [typeof unsafeWindow !== 'undefined' ? unsafeWindow : null, window]) {
      if (!w) continue;
      try { w.onbeforeunload = null; } catch (er) { /* */ }
      try { const P = w.BeforeUnloadEvent && w.BeforeUnloadEvent.prototype; if (P) { Object.defineProperty(P, 'returnValue', { configurable: true, get() { return ''; }, set() { /* chặn */ } }); P.preventDefault = function () { /* chặn */ }; } } catch (er) { /* */ }
    }
    if (url) location.href = url; else location.reload();
  }
  // phần comment chính (bỏ khối "CTA:… Link:…" ở cuối) — dùng khi so comment trên trang, để comment cũ chưa có CTA vẫn tính là đủ
  // (6.10) lần thử lại (từ lần 2): bước phụ (nền đỏ, vị trí, thẻ, nhóm, hình thu nhỏ) lỗi thì BỎ QUA bước đó và vẫn đăng — ghi chú vào báo cáo
  const thuNhe = () => (window.__smhLan || 0) >= 1 || !!window.__smhNhe; // (6.19) kênh 2, 3: bước phụ lỗi luôn bỏ qua
  function boQuaBuoc(ten, e) { (window.__smhBoQua = window.__smhBoQua || []).push(ten); ghi(`Bỏ qua bước ${ten} (${e && e.message ? e.message : 'lỗi'}) — đây là lần thử lại nên vẫn đăng bài, ghi chú vào báo cáo`); }
  function boCTA(t) { return String(t || '').split(/\n\s*CTA:/)[0]; }
  function ghi(msg) {
    const safe = anBiMat(msg);
    window.__smhGhiLuc = Date.now(); window.__smhGhiCuoi = safe; // (6.15) bộ canh treo: lúc có bước mới gần nhất
    try { thuBaoCao(safe); if (hdChay && TK_KQ_RE.test(safe)) hdChay.coKQ = true; } catch (e) { /* */ } // (6.16) gom lỗi cho báo cáo kỹ thuật + thống kê việc
    { let duoi = ''; try { const b = window.__smhBuoc; if (b && !/^(Nhận quyền|Khởi động|⏱)/.test(safe)) { const s = Math.round((Date.now() - b.cuoi) / 1000); b.cuoi = Date.now(); if (s >= 1 && s < 900) duoi = ' (+' + s + 's)'; } } catch (e) { /* */ } luuNK(safe + duoi, laMocQuanTrong(safe)); } // (6.24) mỗi bước ghi số giây kể từ bước trước
    try { if (hdChay && !/^(Nhận quyền|Khởi động|Gửi yêu cầu)/.test(safe)) { hdChay.chi = safe; hdChay.cuoi = safe; hdChay.soDong = (hdChay.soDong || 0) + 1; hdChay.cap = Date.now(); if (!hdChay.hien) { hdChay.hien = true; } luu('hoat_dong', hdChay); } } catch (e) { /* */ }
    console.log('[' + TEN_HE_THONG + ']', safe);
    try { theoDoiSoan(safe); } catch (e) { /* */ }
    try { if (/^(Bấm|Nhân sự bấm|Chọn font|Đã chọn|Đã thêm font|Đã xoá font|Tự đăng:|Chạy thử:|Bỏ đánh dấu|Đặt máy|Đã dán ảnh|Tạo lại ảnh|Đã kiểm|Đã gửi|Đã đọc)/.test(safe)) nhacNho(safe); } catch (e) { /* */ }
    try { veBang(); } catch (e) { /* */ }
  }
  function thongBaoMay(tieuDe, noiDung) { // (6.22) không hiện thông báo trên máy nữa — chỉ ghi nhật ký
    try { ghi('(thông báo) ' + tieuDe); } catch (e) { /* */ } return;
    // eslint-disable-next-line no-unreachable
    try {
      GM_notification({ title: tieuDe, text: noiDung, timeout: 0, highlight: true, onclick: () => { try { window.focus(); } catch (e) { /* */ } } });
      ghi('Đã hiện thông báo trên máy: ' + tieuDe);
    } catch (e) { ghi('Không hiện được thông báo trên máy: ' + e.message); }
  }
