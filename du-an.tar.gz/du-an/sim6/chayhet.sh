#!/bin/sh
cd /tmp/claude-0/v114/sim6
rm -f kq/_tien.txt
for nhom in "ngay bu chot haimay caothay tranh thieu" "cmt nhansu demnguoc hoan khongnhac chaythuv cmt19" "gantay soan tay chaythu khanh taoanh ui" "chonmay nhac baocao chuangay ngaymai ngaymaihuy soanf5" "cuonkhuat nhomhong hongv1 luckhac thehong sukien sualoi" "trungcmt lamngay suavid thetab cmtcta phanhoi font" "videodung hopla moanh loitrang3 suckhoe khongan treo loitrang" "baocao6 duyet nhay bimat khonganmai"; do
  sh chay.sh $nhom
done
echo HET >> kq/_tien.txt
