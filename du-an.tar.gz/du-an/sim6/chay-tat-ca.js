// Chạy toàn bộ kịch bản giả lập (chạy được trên Windows lẫn Linux): node sim6/chay-tat-ca.js [số chạy song song, mặc định 4] [tên kịch bản...]
const { spawn } = require('child_process'); const fs = require('fs'); const path = require('path');
const TAT_CA = ['ngay', 'bu', 'chot', 'haimay', 'caothay', 'tranh', 'thieu', 'cmt', 'nhansu', 'demnguoc', 'hoan', 'khongnhac', 'chaythuv', 'cmt19', 'gantay', 'soan', 'tay', 'chaythu', 'khanh', 'taoanh', 'ui', 'chonmay', 'nhac', 'baocao', 'chuangay', 'ngaymai', 'ngaymaihuy', 'soanf5', 'cuonkhuat', 'nhomhong', 'hongv1', 'luckhac', 'thehong', 'sukien', 'sualoi', 'trungcmt', 'lamngay', 'suavid', 'thetab', 'cmtcta', 'phanhoi', 'font', 'videodung', 'hopla', 'moanh', 'loitrang3', 'suckhoe', 'khongan', 'treo', 'loitrang', 'baocao6', 'duyet', 'nhay', 'bimat', 'khonganmai', 'vtrung', 'nhacsheet', 'chuanbi', 'hb21', 'capnhat', 'thunap', 'thunapcsp', 'kenh', 'kenhcta', 'kenhnhac', 'kenhmatrang', 'kenhnick', 'kenhcao', 'mf1', 'kenhtay', 'kenhcaomt', 'kenhui', 'giaomuon', 'giaomuonma', 'bucao', 'bugiao', 'bucaomenu', 'soanmaik', 'themvideo', 'themgiua', 'soanan', 'chiso', 'chisoloi', 'chisoban', 'chisonut', 'chisoloi10', 'chisolai', 'chisotv', 'chisobuoc7', 'tv24'];
const song = +process.argv[2] || 4; const ds = process.argv.slice(3).length ? process.argv.slice(3) : TAT_CA;
const kq = path.join(__dirname, 'kq'); fs.mkdirSync(kq, { recursive: true });
let i = 0; const loi = [];
function chay() {
  if (i >= ds.length) return Promise.resolve();
  const sc = ds[i++];
  return new Promise((res) => {
    const out = fs.openSync(path.join(kq, sc + '.txt'), 'w');
    const p = spawn(process.execPath, [path.join(__dirname, 'sim6.js'), sc], { stdio: ['ignore', out, out] });
    const hen = setTimeout(() => p.kill(), 25 * 60000);
    p.on('exit', (code) => {
      clearTimeout(hen);
      const t = fs.readFileSync(path.join(kq, sc + '.txt'), 'utf8');
      const tot = code === 0 && !/SIM LỖI/.test(t) && !/TRÙNG: [1-9]/.test(t) && !/LỖI TRANG: \[".+/.test(t);
      if (!tot) loi.push(sc);
      console.log(`${tot ? 'ĐẠT ' : 'LỖI '} ${sc}`); res();
    });
  }).then(chay);
}
Promise.all(Array.from({ length: song }, chay)).then(() => { console.log(loi.length ? 'CÓ LỖI: ' + loi.join(', ') + ' (chạy lại riêng từng cái để loại lỗi do máy quá tải)' : 'TẤT CẢ ĐẠT'); });
