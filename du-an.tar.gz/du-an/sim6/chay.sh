#!/bin/sh
# chạy song song từng nhóm kịch bản
cd /tmp/claude-0/v114/sim6
for sc in "$@"; do (timeout 1500 node sim6.js $sc > kq/$sc.txt 2>&1; echo "$sc xong $?" >> kq/_tien.txt) & done
wait
