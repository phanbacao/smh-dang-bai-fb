// ==UserScript==
// @name         Smh dang bai fb kenh 1 CHAY THAT 5.9 MAY CAO
// @namespace    smh-dang-bai-fb-kenh1-chay-that
// @version      5.9.7
// @description  [Máy Cao] Tự đăng Bài 1 (6h45), Bài 2 (7h15) và Bài 3 (7h45, kèm ảnh + comment) lên fanpage "Vòng Trầm Hương Sơn Mộc Hương .", lấy chữ và ảnh từ Lark sheet "Bài viết kênh 1"
// @match        https://www.facebook.com/*
// @grant        GM_xmlhttpRequest
// @grant        GM_info
// @grant        GM_getValue
// @grant        GM_setValue
// @grant        GM_deleteValue
// @grant        GM_listValues
// @grant        GM_registerMenuCommand
// @grant        GM_openInTab
// @grant        GM_notification
// @grant        unsafeWindow
// @grant        GM_addElement
// @connect      open.larksuite.com
// @connect      graph.facebook.com
// @run-at       document-idle
// @noframes
// ==/UserScript==

(function () {
  'use strict';
  // Chặn cài trùng cùng bản trong cùng tài liệu; F5 tạo tài liệu mới.
  const DA_CHAY = 'data-smhfb-runtime-200';
  if (document.documentElement.hasAttribute(DA_CHAY)) return;
  document.documentElement.setAttribute(DA_CHAY, '1');

  // =====================================================================
  //  CÀI ĐẶT
  // =====================================================================
  const MAY = 'CAO'; const LA_GIAO = MAY === 'GIAO';
  const CAI_DAT = {
    // Nhóm Lark "Đăng bài fb" (bot có từ khoá bắt buộc "fb")
    WEBHOOK: '/*BI_MAT_DA_BO*/', // (5.7.1) nhóm Lark mới (từ khoá "fb")

    // App Lark "Script Dang Bai Kenh 1"
    LARK_APP_ID: '/*BI_MAT_DA_BO*/',
    LARK_APP_SECRET: '/*BI_MAT_DA_BO*/',
    SHEET_TOKEN: 'WPhusx4UJhvTbstKQHFlNkWHggd',   // tài liệu "MKT 10. KỊCH BẢN MARTKETING"
    SHEET_ID: 'apU3Ne',                             // tab "Bài viết kênh 1"
    LINK_SHEET: 'https://zgml41unmm8.sg.larksuite.com/wiki/G9gOwWa7OiQxuCkYWKJlkHt4g2f?sheet=apU3Ne',

    TEN_TRANG: 'Vòng Trầm Hương Sơn Mộc Hương .',
    TEN_NGAN: 'Vòng Trầm Hương SMH',
    TIEN_TO_TIN: '[fb kênh 1]',   // (5.2) đầu tin Lark — chỉ thêm khi nội dung chưa có chữ "fb" (nhóm Lark bắt buộc có "fb"); đặt '' để bỏ
    URL_TRANG: 'https://www.facebook.com/vongtramhuongsonmochuong/',
    DUONG_DAN_TRANG: '/vongtramhuongsonmochuong',

    GIO_DANG_TU: '06:45',         // giờ đăng ngẫu nhiên mỗi ngày trong khung này
    GIO_DANG_DEN: '06:47',
    GIO_CHOT: '12:00',            // quá giờ này chưa đăng được thì dừng, báo để đăng tay
    CACH_BAI_KHAC_PHUT: 25,       // cách bài gần nhất trên trang (manifest hay bài khác)
    CACH_BAI_TRUNG_NGAY_PHUT: 30, // 2 hàng cùng ngày = 2 bài, cách nhau 30 phút
    GIO_KIEM_TRUOC: '13:00',      // (5.7) kiểm sheet của ngày mai từ 13:00 (tránh giờ nhân sự làm việc)
    KIEM_TRUOC_LAP_PHUT: 60,      // chưa đủ thì 30 phút kiểm lại 1 lần
    THU_LAI_PHUT: 5,              // lỗi lúc đăng thì 5 phút thử lại 1 lần
    NHAC_LAI_PHUT: 120,           // lỗi chưa sửa thì 2 tiếng nhắc lại 1 lần
    GIO_NHAN_TU: '07:00',         // chỉ gửi tin Lark trong khung này
    GIO_NHAN_DEN: '23:00',
    BAO_DA_DANG_SO_NGAY: 7,       // tuần đầu: đăng xong cũng báo
    DEM_NGUOC_TOI_THIEU_GIAY: 60,
    CHUAN_BI_TRUOC_PHUT: 3,       // trước giờ đăng 3 phút thì tự đưa tab về đúng trang
    VI_TRI: 'Sơn Mộc Hương',
    VI_TRI_DIA_CHI: 'Vạn Phúc',
    NEN: 'Đỏ đậm',
    SO_NHOM_TOI_DA: 9,
    GIOI_HAN_KY_TU_NEN: 130,
    SAP_TOI_SO_NGAY: 7,
    TAI_TRUOC_ANH: true,          // sáng 08:05–08:40 (giờ ngẫu nhiên) tải sẵn ảnh cả ngày vào bộ nhớ tạm của trình duyệt
    RA_SOAT_CMT: true,            // rà soát định kỳ: mỗi ngày 3 lần (giờ ngẫu nhiên), bài nào thiếu comment thì gửi bù
    RA_SOAT_GIO: [[7, 50], [13, 0], [19, 0], [22, 0]],   // (5.7) giờ cố định (lệch 0–3 phút); tránh 08:00–12:30 và 13:55–19:00
    RA_SOAT_SUA_TOI_DA: 2,        // mỗi bài tối đa 2 lần gửi bù/ngày
    SUA_NEN_B2: true,             // Bài 2: đăng xong thì sửa bài sang nền đỏ (ảnh bị gỡ). false = tắt
    TAI_LAI_SAU_CMT: false,       // true = luôn F5 sau mỗi comment (chậm). Mặc định chỉ F5 khi ô bình luận bị treo
    BAO_LOI_SAU_PHUT: 8,          // lỗi đăng bài: chờ script tự thử lại, quá chừng này phút vẫn lỗi mới báo Lark
    THA_CAM_XUC_CMT: true,        // false = tắt hẳn việc thả cảm xúc cho comment (nếu vẫn lỗi)
    CANH_BAO_THIEU_NGAY: 4,
    LICH_KIEM_PHUT: 30,           // video/manifest do nhân sự đăng: kiểm trên trang 30 phút/lần đến khi thấy bài
    LICH_KIEM_SAU_PHUT: 5,        // bắt đầu kiểm sau giờ dự kiến 5 phút
    LICH_NGOAI: [                 // bài do nhân sự đăng (script chỉ theo dõi)
      { k: 'v1', ky: 'V1', ten: 'Video 1', loai: 'video', gio: '08:00' },
      { k: 'm1', ky: 'M1', ten: 'Manifest 1', loai: 'manifest', gio: '08:30' },
      { k: 'v2', ky: 'V2', ten: 'Video 2', loai: 'video', gio: '10:00' },
      { k: 'm2', ky: 'M2', ten: 'Manifest 2', loai: 'manifest', gio: '11:00' },
      { k: 'v3', ky: 'V3', ten: 'Video 3', loai: 'video', gio: '18:00' },
    ],       // chỉ báo thiếu nội dung trong 4 ngày gần nhất (hôm nay + 3 ngày tới)
    SAP_TOI_LAM_MOI_PHUT: 240,    // đọc lại lịch sheet 2 tiếng/lần (chỉ trong 08:00–22:00)
    GIO_TU_KIEM: '06:30',         // tự kiểm hộp đăng bài (mở thử rồi đóng, không đăng)
    GIO_TONG_KET: '20:00',        // 1 tin tổng kết mỗi tối
    KHANH_BAT: true,              // (5.0) báo cáo tuần trang Khanh Trầm Hương
    KHANH_URL: 'https://www.facebook.com/100063806572484',   // link theo ID trang (đổi tên trang vẫn vào được)
    KHANH_TEN: 'Khanh Trầm Hương',
    KHANH_GIO: '19:00',           // giờ gửi (5.7: tránh giờ nhân sự làm việc)
    KHANH_THU: 5,                 // thứ Sáu (0 = Chủ nhật … 6 = thứ Bảy)
    KHANH_MOC_GIO: [0, 1, 2, 3, 12.84, 18, 24, 27], // (5.7) thứ Sáu 19:00, 20:00, 21:00, 22:00; chưa được thì thứ Bảy 07:50, 13:00, 19:00, 22:00 (tránh giờ nhân sự làm việc)
    KHANH_TOI_DA_BAI: 20,         // đọc tối đa bấy nhiêu bài (dừng sớm khi gặp bài cũ hơn 7 ngày)
    GIO_BAO_CAO_TUAN: '19:00',    // (4.6) 19:00 thứ Bảy: báo cáo tuần (số bài từng loại)
    // Facebook Graph API — CHỈ ĐỌC danh sách bài của trang (không đăng). Mã khoá là BÍ MẬT, không gửi cho ai.
    FB_PAGE_ID: '1196332230224812',   // ID trang Vòng Trầm Hương Sơn Mộc Hương .
    FB_TOKEN: '',                     // để trống: mã khoá được cài bằng nút "Cài mã khoá" trên popup (lưu trong Tampermonkey)
    DO_BAI_PHUT: 10,              // dò Bài 2/3 (và link Bài 1) 10 phút/lần
    GIO_DO_TU: '07:00',
    GIO_DO_DEN: '23:00',
    GIO_NHAC_BAI23: '13:00',      // còn Bài 2/3 chưa thấy trên trang thì báo nhóm 1 lần (5.7: dời từ 11:30)
    GIO_NHAC_BAI2: '07:45',       // đến giờ này chưa thấy Bài 2 → hiện thông báo trên máy (để trống '' = tắt)
    GIO_NHAC_BAI3: '08:15',       // đến giờ này chưa thấy Bài 3 → hiện thông báo trên máy (để trống '' = tắt)
    // ---- 2.0: script tự đăng Bài 2 và Bài 3 (có ảnh lấy từ ô trong sheet) ----
    GIO_BAI2_TU: '07:13',         // giờ đăng Bài 2 ngẫu nhiên trong khung này
    GIO_BAI2_DEN: '07:17',
    GIO_BAI3_TU: '07:41',         // giờ đăng Bài 3 ngẫu nhiên trong khung này
    GIO_BAI3_DEN: '07:49',
    NGAY_THU_B23: '02-10-2026',   // ngày chạy thử: soạn sẵn Bài 2/3 rồi DỪNG trước nút Đăng (Cao tự bấm Đăng, script comment tiếp). Từ ngày sau trở đi tự đăng. Để trống '' = tắt
    ANH_CANH_TOI_DA: 2048,        // ảnh lớn hơn (px) thì thu nhỏ trước khi đưa lên Facebook
    GIO_BAO_ANH: '19:00',         // (5.7) thiếu ảnh của ngày mai: trước giờ này chỉ hiện trên popup, từ giờ này mới báo nhóm Lark
    TAB_AN_NHAC_MAY_PHUT: 15,     // đến giờ đăng mà tab Facebook bị che/ẩn → thông báo trên máy 15 phút/lần (tối đa 6 lần/ngày)
    TAB_AN_NHAC_LARK_PHUT: 1440,  // … nhóm Lark chỉ nhắn 1 lần/ngày (đăng ngay khi tab hiện lại)
    GACH_NGANG: false,            // false = KHÔNG gạch ngang ô trên sheet (Cao sẽ bàn lại sau)
    NGUONG_BAI: 0.9,              // bài trên trang giống ≥ 90% số từ trên sheet thì coi là cùng bài
    NGUONG_CMT: 0.6,              // comment giống ≥ 60% (hoặc cùng đường link) thì coi là đã comment
    MA_KHOA_HAN_NGAY: 90,         // Facebook có thể đòi cấp lại quyền sau ~90 ngày → nhắc trước 10 ngày và 3 ngày
    GIU_DU_LIEU_NGAY: 30,         // dữ liệu từng ngày giữ 30 ngày rồi tự xoá
    // Comment cố định dưới Bài 3 (so gần giống ≥ 60%) — sửa ở đây nếu đổi mẫu
    CMT_BAI3: 'Sơn Mộc Hương - Trầm Chuẩn - Giá Chuẩn\n• Zalo: 0762222448\n• Web: sonmochuong.com\n• Showroom: 76 đường 2, Khu Đô Thị Vạn Phúc, Phường Hiệp Bình, TP.HCM\n• Đổi trả trong 30 ngày khi không còn nhu cầu.\n• Thương hiệu chính hãng đã được Cục SHTT bảo hộ.\n• Đánh giá 5 sao shop hỗ trợ 100% phí ship đổi size.\n• Cam kết sản phẩm đúng mô tả.\n• Nói không với trầm nấu dầu.',
    LOI_NHAC_TOI_DA: 2,           // 1 lỗi: báo lần đầu + nhắc lại tối đa 2 lần/ngày
    // ---- 1.14: quét Thích + gắn thẻ/cảm xúc video ----
    GIO_QUET: ['07:50', '13:00', '19:00', '22:00'],   // (5.7) 4 mốc quét cố định, tránh 08:00–12:30 và 13:55–19:00 (ngoài ra có nút "Quét ngay")
    KHUNG_KIEM: ['07:50', '13:00', '19:00', '22:00'], // (5.7) các mốc kiểm tra định kỳ
    GIO_KIEM_GIAO: '07:58',       // (5.7) Máy Cao kiểm Máy Giao đã đăng đủ 3 bài chưa (Máy Giao xong trước 07:55)
    RANH_SAU_PHUT: 3,             // (5.7) nhân sự ngừng thao tác trên trang bấy nhiêu phút thì script mới tự chạy
    QUET_VIDEO_GIO: 24,           // chỉ xét video đăng trong 24 giờ qua
    QUET_THICH_GIO: 48,           // bài + comment đăng trong 48 giờ qua chưa Thích thì thả
    QUET_VIDEO_TOI_DA: 3,         // tối đa 3 video được sửa mỗi lượt quét
    QUET_BU_PHUT: 120,            // mở lại/cài lại script trễ mốc quét quá 120 phút thì bỏ mốc đó
    QUET_THICH_TOI_DA: 25,        // tối đa 40 lượt Thích mỗi lượt quét
    QUET_NGHI_GIAY: [20, 40],     // nghỉ ngẫu nhiên giữa 2 video
    QUET_LOAI_TRU: '#manifest',   // bài có chữ này (video Manifest) thì không sửa
    TAG_TEN: 'Sơn Mộc Hương',     // trang được gắn thẻ
    CAM_XUC_CHON: ['hạnh phúc', 'hào hứng', 'tuyệt vời', 'tích cực', 'biết ơn', 'cảm kích', 'vui vẻ', 'thư giãn', 'hân hoan'],
    THA_CAM_XUC: true,            // đăng xong / comment xong thì tự thả Thích hoặc Yêu thích (ngẫu nhiên)
  };

  // (5.3) cấu hình riêng từng máy
  CAI_DAT.DANG_MAC_DINH = !LA_GIAO;   // Máy Cao mặc định TẠM DỪNG đăng 3 bài (gạt nút để bật); Máy Giao mặc định bật
  if (LA_GIAO) { CAI_DAT.WEBHOOK = 'https://open.larksuite.com/open-apis/bot/v2/hook/69b654dd-158c-4ffe-9c36-db228a5bb6f4'; CAI_DAT.KHANH_BAT = false; }
  const PHIEN_BAN = '5.3';
  const TEN_HE_THONG = 'Đăng bài fb kênh 1';
  const ngayNgan = (ngay) => String(ngay).slice(0, 5).replace('-', '/'); // '05-10-2026' → '05/10'
  const K = (s) => 'that_' + s;

  const COT_BAT_BUOC = [
    { cot: 'A', chiSo: 0, chua: 'từ khóa', ten: 'Từ khóa chính' },
    { cot: 'B', chiSo: 1, chua: 'không có ảnh', ten: 'Bài twist (không có ảnh)' },
    { cot: 'C', chiSo: 2, chua: 'cmt bài 1', ten: 'Cmt bài 1' },
    { cot: 'G', chiSo: 6, chua: 'trạng thái', ten: 'Trạng thái' },
    { cot: 'H', chiSo: 7, chua: 'ngày đăng', ten: 'Ngày đăng' },
  ];

  // =====================================================================
  //  Tiện ích chung
  // =====================================================================
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const chuan = (s) => String(s == null ? '' : s).normalize('NFC').replace(/\s+/g, ' ').trim();
  const thuong = (s) => chuan(s).toLowerCase();
  const pad = (n) => String(n).padStart(2, '0');
  const ngayStr = (d) => `${pad(d.getDate())}-${pad(d.getMonth() + 1)}-${d.getFullYear()}`;
  const gioStr = (d) => `${pad(d.getHours())}:${pad(d.getMinutes())}`;
  const phutStr = (p) => `${pad(Math.floor(p / 60))}:${pad(p % 60)}`;
  const phutTrongNgay = (d) => d.getHours() * 60 + d.getMinutes();
  const docGio = (hhmm) => { const [h, m] = hhmm.split(':').map(Number); return h * 60 + m; };
  const homNay = () => ngayStr(new Date());
  const congNgay = (n) => { const d = new Date(); d.setDate(d.getDate() + n); return d; };
  const ngayMai = () => ngayStr(congNgay(1));
  const THU = ['CN', 'T2', 'T3', 'T4', 'T5', 'T6', 'T7'];
  const lucPhut = (phut) => { const d = new Date(); d.setHours(Math.floor(phut / 60), phut % 60, 0, 0); return d.getTime(); };
  const trongGioNhan = () => { const m = phutTrongNgay(new Date()); return m >= docGio(CAI_DAT.GIO_NHAN_TU) && m < docGio(CAI_DAT.GIO_NHAN_DEN); };
  const bam = (s) => { let h = 0; for (const ch of chuan(s)) h = (h * 31 + ch.codePointAt(0)) >>> 0; return h.toString(36); };
  const esc = (s) => String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  const conLai = (ms) => { const g = Math.max(0, Math.round(ms / 1000)); const h = Math.floor(g / 3600), p = Math.floor((g % 3600) / 60), s = g % 60;
    return h ? `${h} giờ ${pad(p)} phút` : `${pad(p)}:${pad(s)}`; };

  async function cho(fn, timeout = 8000, buoc = 300) {
    const han = Date.now() + timeout;
    while (Date.now() < han) {
      try { const v = fn(); if (v) return v; } catch (e) { /* bỏ qua */ }
      await sleep(buoc);
    }
    return null;
  }

  const lay = (k, macDinh) => GM_getValue(K(k), macDinh);
  const luu = (k, v) => GM_setValue(K(k), v);
  const dangTuDongBat = () => !!lay('dang_tu_dong', CAI_DAT.DANG_MAC_DINH);   // (5.3) công tắc đăng 3 bài tự động của máy này
  const capNhat = (k, doi) => { const v = Object.assign({}, lay(k, {}) || {}, doi); luu(k, v); return v; };

  class LoiMem extends Error {}   // lỗi có thể thử lại
  class LoiCung extends Error {}  // lỗi không được thử lại (tránh đăng trùng)
  class LoiDung extends Error {} // yêu cầu dừng hoặc mất quyền làm việc
  class LoiLark extends LoiMem {}
  class LoiTuChoi extends Error {} // Facebook báo rõ là KHÔNG nhận comment
  class LoiTamHoan extends LoiDung {} // (4.5) tab bị ẩn / tạm mất quyền: KHÔNG dừng cả ngày, lát nữa làm tiếp
  class LoiTrung extends LoiDung { constructor(m, p) { super(m); this.p = p; } } // (4.5) phát hiện bài đã có ngay trước khi bấm Đăng
  class LoiChuaGui extends Error {} // (4.5) comment CHƯA được gửi đi (an toàn để thử lại)
  class LoiLarkToken extends LoiMem {} // (4.5) mã truy cập Lark hết hạn → lấy mã mới rồi gọi lại
  // (4.5) so chữ "bỏ dấu câu/emoji/khoảng trắng" — Facebook vẽ emoji thành ảnh, rút gọn link… nên so thô hay trượt
  const khoaSo = (s) => thuong(s).replace(/[^\p{L}\p{N}]+/gu, '');
  const chuanTen = (s) => khoaSo(s);

  // ---------------- nhật ký + tiến trình từng bước ----------------
  function anBiMat(msg) {
    let t = String(msg);
    const secrets = [CAI_DAT.LARK_APP_SECRET, CAI_DAT.WEBHOOK, lay('fb_token', ''), CAI_DAT.FB_TOKEN].filter(Boolean);
    for (const x of secrets) t = t.split(x).join('[ĐÃ ẨN]');
    return t.replace(/EAA[A-Za-z0-9]{40,}/g, '[MÃ FB ĐÃ ẨN]')
      .replace(/https:\/\/open\.larksuite\.com\/open-apis\/bot\/v2\/hook\/[^\s"']+/g, '[WEBHOOK ĐÃ ẨN]')
      .replace(/((?:access_token|app_secret|Authorization)["']?\s*[:=]\s*["']?)[^\s,"'}&]+/gi, '$1[ĐÃ ẨN]');
  }
  const laMocQuanTrong = (m) => /B\d+\.|C\d+\.|Đăng|đăng|comment|dừng|hủy|Hủy|quyền|hẹn|giãn cách|ẩn|Khởi động|Lark tạm ngừng|phục hồi/.test(m) && !/Đọc lịch sắp tới lỗi|Chưa chuyển được cột G|Đọc sheet lỗi/.test(m);
  function khoaNK(d) { return 'nk112_' + ngayStr(d); }
  function gioNK(t) { const d = new Date(t); return ngayStr(d).slice(0, 5) + ' ' + gioStr(d) + ':' + pad(d.getSeconds()); }
  function dongNK(e) { return gioNK(e.luc) + ' ' + e.msg + (e.so > 1 ? ' [lặp ' + e.so + ' lần; cuối ' + gioNK(e.cuoi) + ']' : ''); }
  function docNhatKy() {
    const ds = [];
    for (let i = 6; i >= 0; i--) ds.push(...lay(khoaNK(congNgay(-i)), []));
    return ds.sort((a, b) => a.luc - b.luc).map(dongNK);
  }
  function luuNK(msg, quanTrong = false, tab = MA_TAB) {
    const now = Date.now(), k = khoaNK(new Date());
    const ds = lay(k, []);
    const text = anBiMat(msg).slice(0, 2200) + (tab ? ' [tab ' + tab + ']' : '');
    const lap = ds.slice().reverse().find((e) => e.msg === text && now - e.cuoi < 30 * 60000); // (5.8) dòng lặp lại (kể cả dòng quan trọng) thì gộp, không làm trôi nhật ký
    if (lap) { lap.so++; lap.cuoi = now; }
    else ds.push({ luc: now, cuoi: now, msg: text, so: 1, quanTrong });
    while (ds.length > 1500 || JSON.stringify(ds).length > 220000) {
      let i = ds.findIndex((e) => !e.quanTrong);
      ds.splice(i < 0 ? 0 : i, 1);
    }
    luu(k, ds);
  }
  function chuyenNhatKyCu() {
    if (lay('nk112_da_chuyen', false)) return;
    const cu = lay('nhatky', []);
    for (const line of cu) {
      const m = String(line).match(/^(\d{2})-(\d{2}) (\d{2}):(\d{2}):(\d{2}) (.*)$/);
      if (!m) continue;
      const d = new Date(new Date().getFullYear(), +m[2] - 1, +m[1], +m[3], +m[4], +m[5]);
      if (d.getTime() > Date.now() + 864e5) d.setFullYear(d.getFullYear() - 1);
      if (Date.now() - d.getTime() > 7 * 864e5) continue;
      const k = khoaNK(d), ds = lay(k, []), msg = anBiMat(m[6]);
      const lap = !laMocQuanTrong(msg) && ds.find((e) => e.msg === msg && d.getTime() - e.cuoi < 30 * 60000);
      if (lap) { lap.so++; lap.cuoi = d.getTime(); }
      else ds.push({ luc: d.getTime(), cuoi: d.getTime(), msg, so: 1, quanTrong: laMocQuanTrong(msg) });
      luu(k, ds);
    }
    luu('nk112_da_chuyen', true);
    GM_deleteValue(K('nhatky')); // đã chuyển sang nhật ký có che bí mật
  }
  // (5.4) chụp "hiện trường" khi có lỗi: ghi vào nhật ký danh sách hộp thoại đang mở + trạng thái tab
  function chupLoi(tieuDe) {
    try {
      const ds = Array.from(document.querySelectorAll('div[role="dialog"]')).map((d, i) => { const r = d.getBoundingClientRect(); return i + ':' + Math.round(r.width) + 'x' + Math.round(r.height) + (d.closest('[aria-hidden="true"]') ? ':ẩn' : '') + ':' + (d.innerText || '').replace(/\s+/g, ' ').slice(0, 70); });
      ghi('Lỗi chi tiết [' + tieuDe + '] bản ' + (typeof GM_info !== 'undefined' ? GM_info.script.version : '?') + ' | tab ' + (document.visibilityState) + ' | hộp: ' + (ds.join(' ¦ ') || 'không có') + ' | trang: ' + location.pathname.slice(0, 60));
    } catch (e) { /* */ }
  }
  window.addEventListener('error', (ev) => { try { if (/ResizeObserver/.test(ev.message || '')) return; ghi('Lỗi script: ' + (ev.message || '') + ' @' + String(ev.filename || '').slice(-30) + ':' + ev.lineno); } catch (e) { /* */ } });
  window.addEventListener('unhandledrejection', (ev) => { try { ghi('Lỗi script (promise): ' + String((ev.reason && ev.reason.message) || ev.reason || '').slice(0, 160)); } catch (e) { /* */ } });
  // (5.8) Script tự tải lại / chuyển trang: trước đó dọn chữ đang gõ dở trong ô bình luận/hộp soạn và chặn hộp hỏi
  // "Tải lại trang web? Các thay đổi bạn đã thực hiện có thể không được lưu" của trình duyệt — hộp này làm cả trang đứng chờ người bấm.
  let roiTrangLuc = 0;
  window.addEventListener('beforeunload', (e) => { if (Date.now() - roiTrangLuc < 20000) { try { e.stopImmediatePropagation(); } catch (er) { /* */ } } }, true);
  // phần chạy ngay trong trang Facebook (để chặn được cả hộp hỏi do chính Facebook gắn); chỉ bật khi script tự tải lại / chuyển trang
  try {
    if (typeof GM_addElement === 'function') GM_addElement('script', { textContent: "(function(){document.addEventListener('smhfb-roi-trang',function(){try{window.onbeforeunload=null;var P=window.BeforeUnloadEvent&&BeforeUnloadEvent.prototype;if(P){Object.defineProperty(P,'returnValue',{configurable:true,get:function(){return '';},set:function(){}});P.preventDefault=function(){};}window.addEventListener('beforeunload',function(e){e.stopImmediatePropagation();},true);}catch(e){}});})();" });
  } catch (er) { /* */ }
  function donNhapDo() {
    let n = 0;
    for (const ed of document.querySelectorAll('div[contenteditable="true"], textarea')) {
      if (ed.closest && ed.closest('#smhfb,#smhfb-gan-w,#smhfb-gan-modal')) continue;
      const v = ed.tagName === 'TEXTAREA' ? ed.value : ed.innerText;
      if (!String(v || '').trim()) continue;
      try { if (ed.tagName === 'TEXTAREA') { ed.value = ''; } else { ed.focus(); document.execCommand('selectAll', false); document.execCommand('delete', false); } n++; } catch (er) { /* */ }
    }
    return n;
  }
  function roiTrang(url) {
    roiTrangLuc = Date.now();
    try { document.dispatchEvent(new CustomEvent('smhfb-roi-trang')); } catch (er) { /* */ }
    try { const n = donNhapDo(); if (n) console.log('[smhfb] đã dọn ' + n + ' ô đang gõ dở trước khi tải lại trang'); } catch (er) { /* */ }
    for (const w of [typeof unsafeWindow !== 'undefined' ? unsafeWindow : null, window]) {
      if (!w) continue;
      try { w.onbeforeunload = null; } catch (er) { /* */ }
      try { const P = w.BeforeUnloadEvent && w.BeforeUnloadEvent.prototype; if (P) { Object.defineProperty(P, 'returnValue', { configurable: true, get() { return ''; }, set() { /* chặn */ } }); P.preventDefault = function () { /* chặn */ }; } } catch (er) { /* */ }
    }
    if (url) location.href = url; else location.reload();
  }
  function ghi(msg) {
    const safe = anBiMat(msg);
    luuNK(safe, laMocQuanTrong(safe));
    try { if (ghiBat) ghiBat.push(safe); } catch (e) { /* */ }
    try { if (hdChay && !/^(Nhận quyền|Khởi động|Gửi yêu cầu|Đang chờ:)/.test(safe)) { hdChay.chi = safe; hdChay.cuoi = safe; hdChay.soDong = (hdChay.soDong || 0) + 1; hdChay.cap = Date.now(); if (hdChay.hien) luu('hoat_dong', hdChay); } } catch (e) { /* */ }
    const m = String(msg).match(/^([BC]\d+)\./);
    if (m) { const tt = lay('tien_trinh', {}) || {}; tt.buoc = tt.buoc || {}; tt.buoc[m[1]] = Date.now(); luu('tien_trinh', tt); }
    console.log('[' + TEN_HE_THONG + ']', safe);
    veBang();
  }

  // =====================================================================
  //  Gọi API (Lark sheet + webhook)
  // =====================================================================
  function thangHienTai() { const d = new Date(); return d.getFullYear() + '-' + (d.getMonth() + 1); }
  function chanLark() {
    const g = lay('lark_gate', null);
    if (!g) return null;
    if (g.loai === 'quota' && g.thang !== thangHienTai()) return null;
    return g.den > Date.now() ? g : null;
  }
  function loiLark(ma, msg) {
    const g0 = lay('lark_gate', {}) || {};
    const lan = (g0.lan || 0) + 1;
    const code = String(ma), d = new Date();
    let loai = 'tam', moTa = 'Lark tạm lỗi kết nối/dịch vụ', den = Date.now() + Math.min(30, Math.pow(2, Math.min(lan - 1, 5))) * 60000;
    if (code === '99991403') { loai = 'quota'; moTa = 'Lark đã hết hạn mức API tháng'; den = new Date(d.getFullYear(), d.getMonth() + 1, 1).getTime(); }
    else if (['91403', '99991672', '99991676', '99991679', '99991668', '10014'].includes(code)) {
      loai = 'quyen'; moTa = 'Lark từ chối quyền truy cập hoặc thông tin ứng dụng'; den = Date.now() + 60 * 60000;
    } else if (['99991663', '99991664', '99991665', '99991661'].includes(code)) {
      moTa = 'Mã truy cập Lark cần làm mới'; boTokenLark();
    } else if (code === '99991400' || code === '429') { moTa = 'Lark giới hạn tốc độ gọi API'; den = Date.now() + Math.min(60, 5 * lan) * 60000; }
    const detail = anBiMat(msg || '').slice(0, 350);
    const g = { loai, ma: code, msg: moTa + ' (mã ' + code + ')', detail, den, lan, luc: Date.now(), tu: (g0.loai === loai && g0.tu) ? g0.tu : Date.now(), thang: thangHienTai(), bao: g0.ma === code && g0.thang === thangHienTai() ? g0.bao : false, baoThu: g0.baoThu || 0 };
    luu('lark_gate', g);
    capNhat('suc_khoe', { larkOk: false, larkLuc: Date.now(), larkLoi: g.msg });
    if (!g0.msg || g0.ma !== code) ghi('Lark tạm ngừng: ' + g.msg + ' — xem nút Kiểm tra kết nối lại');
    return new LoiLark(g.msg);
  }
  async function baoTinhTrangLark() {
    const g = lay('lark_gate', null);
    if (!g || g.bao || !trongGioNhan() || !laTabChinh()) return;
    // (4.5) lỗi tạm thời: script tự thử lại; chỉ báo nhóm khi hết hạn mức / bị từ chối quyền / lỗi kéo dài ≥ 30 phút
    if (!(g.loai === 'quota' || g.loai === 'quyen' || Date.now() - (g.tu || g.luc) >= 30 * 60000)) return;
    if (Date.now() - (g.baoThu || 0) < 20 * 60000) return;
    luu('lark_gate', Object.assign({}, g, { baoThu: Date.now() }));
    const ok = await baoLark(g.msg + '. Cần kiểm tra hạn mức/quyền Lark rồi bấm "Kiểm tra kết nối lại" trên popup');
    if (ok) { const g2 = lay('lark_gate', null); if (g2) luu('lark_gate', Object.assign({}, g2, { bao: true })); }
  }
  const MA_TOKEN_LARK = ['99991663', '99991664', '99991665', '99991661'];
  function goiTho(method, url, body, headers) {
    return new Promise((resolve) => {
      GM_xmlhttpRequest({
        method, url,
        headers: Object.assign({ 'Content-Type': 'application/json; charset=utf-8' }, headers),
        data: body ? JSON.stringify(body) : undefined,
        timeout: 25000,
        onload: (r) => { let j = null; try { j = JSON.parse(r.responseText); } catch (e) { /* */ } resolve({ status: r.status, json: j }); },
        onerror: () => resolve({ status: 0, json: null, mang: 'network' }),
        ontimeout: () => resolve({ status: 0, json: null, mang: 'timeout' }),
      });
    });
  }
  // (4.5) lỗi mạng / quá lâu / máy chủ 5xx / giới hạn tốc độ: tự thử lại tối đa 2 lần (cách 3–8 giây) rồi mới tính là lỗi
  async function goi(method, url, body, headers = {}) {
    const duLieu = url.startsWith('https://open.larksuite.com/open-apis/') && !url.includes('/bot/v2/hook/');
    const gate = duLieu && chanLark();
    if (gate) throw new LoiLark(gate.msg + ' — đang chờ kiểm tra lại');
    for (let lan = 0; ; lan++) {
      if (duLieu) capNhat('lark_dem', { ngay: homNay(), so: (lay('lark_dem', {}).ngay === homNay() ? lay('lark_dem', {}).so || 0 : 0) + 1 });
      const r = await goiTho(method, url, body, headers);
      const j = r.json;
      if (!duLieu) {
        if (r.mang) throw new LoiMem(r.mang === 'timeout' ? 'Gửi tin Lark quá lâu' : 'Mất kết nối khi gửi tin Lark');
        return r;
      }
      const loi = r.mang || !j || r.status >= 400 || (j.code != null && j.code !== 0);
      if (!loi) return r;
      const ma = String(r.mang || (j && j.code) || r.status || 'network');
      if (MA_TOKEN_LARK.includes(ma)) { boTokenLark(); throw new LoiLarkToken('Mã truy cập Lark cần làm mới (mã ' + ma + ')'); }
      const tam = r.mang || r.status >= 500 || ma === '99991400' || ma === '429' || !j;
      if (tam && lan < 2) { await sleep(3000 + Math.floor(Math.random() * 5000)); continue; }
      throw loiLark(ma, r.mang ? (r.mang === 'timeout' ? 'Phản hồi quá lâu' : 'Mất kết nối') : (j && j.msg));
    }
  }
  // gọi API dữ liệu Lark kèm mã truy cập; mã hết hạn thì lấy mã mới và gọi lại 1 lần
  async function goiLark(method, url, body) {
    for (let lan = 0; ; lan++) {
      const t = await larkToken();
      try { return await goi(method, url, body, { Authorization: 'Bearer ' + t }); }
      catch (e) { if (e instanceof LoiLarkToken && lan === 0) continue; throw e; }
    }
  }
  function boTokenLark() { tokenCache = null; try { luu('lark_tok', null); } catch (e) { /* */ } }

  let tokenCache = null, tokenCho = null;
  async function larkToken() {
    if (tokenCho) return tokenCho;
    tokenCho = layLarkToken();
    try { return await tokenCho; } finally { tokenCho = null; }
  }
  async function layLarkToken() {
    if (!tokenCache) { const c = lay('lark_tok', null); if (c && c.t && c.het > Date.now() + 5 * 60000) tokenCache = c; } // (4.5) giữ mã qua các lần tải lại trang → đỡ 1 lần gọi API
    if (tokenCache && tokenCache.het > Date.now() + 60000) return tokenCache.t;
    const r = await goi('POST', 'https://open.larksuite.com/open-apis/auth/v3/tenant_access_token/internal',
      { app_id: CAI_DAT.LARK_APP_ID, app_secret: CAI_DAT.LARK_APP_SECRET });
    if (!r.json || r.json.code !== 0) throw new LoiMem('Không lấy được quyền đọc Lark (mã ' + (r.json ? r.json.code : r.status) + ')');
    tokenCache = { t: r.json.tenant_access_token, het: Date.now() + r.json.expire * 1000 };
    luu('lark_tok', tokenCache);
    return tokenCache.t;
  }

  let sheetCache = null, sheetCho = null;
  const sheetDaLuu = () => { const c = lay('sheet_cache112', null); return c && Array.isArray(c.v) && c.v.length && Date.now() - c.luc < (chanLark() ? 7 * 864e5 : 36 * 3600e3) ? c : null; }; // Lark bị chặn lâu → dùng bản lưu tới 7 ngày
  const trongGioDocSheet = () => { const m = phutTrongNgay(new Date()); return m >= 375 && m < 1320; }; // 06:15–22:00
  // moi = bắt buộc đọc mới (đăng bài, nút làm mới). Còn lại: dùng bản đã lưu nếu còn mới (15 phút), ngoài 08:00–22:00 hoặc Lark lỗi thì luôn dùng bản đã lưu
  async function docSheet({ moi = false } = {}) {
    const gate = chanLark();
    if (gate) { if (!moi) { const c = sheetDaLuu(); if (c) return c.v; } throw new LoiLark(gate.msg + ' — đang chờ kiểm tra lại'); }
    if (sheetCho) return sheetCho;
    if (!moi) {
      const chung = lay('sheet_cache112', null);
      if (chung && !chung.het && Array.isArray(chung.v) && Date.now() - chung.luc < 60 * 60000) { sheetCache = chung; return chung.v; }
      if (!trongGioDocSheet()) { const c = sheetDaLuu(); if (c) return c.v; }
    }
    sheetCho = docSheetMoi();
    try { return await sheetCho; } finally { sheetCho = null; }
  }
  async function docSheetMoi() {
    try {
      const url = 'https://open.larksuite.com/open-apis/sheets/v2/spreadsheets/' + CAI_DAT.SHEET_TOKEN + '/values/' + CAI_DAT.SHEET_ID + '!A1:Q3000';
      const r = await goiLark('GET', url, null);
      if (!r.json || r.json.code !== 0) throw new LoiMem('Không đọc được sheet');
      if (!r.json.data || !r.json.data.valueRange || !Array.isArray(r.json.data.valueRange.values)) throw loiLark('response', 'Phản hồi sheet thiếu dữ liệu');
      const gateCu = lay('lark_gate', null);
      luu('lark_gate', null);
      capNhat('suc_khoe', { larkOk: true, larkLuc: Date.now(), larkThanhCong: Date.now(), larkLoi: '' });
      const v = (r.json.data && r.json.data.valueRange && r.json.data.valueRange.values) || [];
      sheetCache = { luc: Date.now(), v }; luu('sheet_cache112', sheetCache);
      if (gateCu) { luu('lark_phuc_hoi', Date.now()); ghi('Kết nối Lark phục hồi — đã đọc được sheet mới'); }
      return v;
    } catch (e) {
      capNhat('suc_khoe', { larkOk: false, larkLuc: Date.now(), larkLoi: e.message });
      throw e;
    }
  }
  // Đọc sheet để đăng Bài 1: Lark lỗi/hết hạn mức thì dùng bản sheet đã lưu (≤ 36 giờ, có hàng của hôm nay) để vẫn đăng đúng giờ
  // (5.3) sheet đã đọc từ 06:00 hôm nay và chưa quá 4 tiếng thì dùng lại (nhân sự thêm ảnh thì bấm "Cập nhật ảnh mới" → đọc mới)
  function docSheetSangNay() {
    const c = lay('sheet_cache112', null); const dau = new Date(); dau.setHours(6, 0, 0, 0);
    if (c && !c.het && Array.isArray(c.v) && c.luc >= dau.getTime() && Date.now() - c.luc < 4 * 3600e3) { sheetCache = c; return c.v; }
    return null;
  }
  async function docSheetChoDang(ngay) {
    { const c0 = docSheetSangNay(); if (c0 && !kiemTenCot(c0) && hangCuaNgay(c0, ngay).length) return c0; }
    try { return await docSheet({ moi: true }); }
    catch (e) {
      const c = lay('sheet_cache112', null);
      if (c && Array.isArray(c.v) && Date.now() - c.luc < 7 * 864e5 && !kiemTenCot(c.v) && hangCuaNgay(c.v, ngay).length) {
        ghi('Không đọc được sheet mới (' + e.message + ') → dùng bản sheet đã lưu lúc ' + gioStr(new Date(c.luc)) + ' để đăng đúng giờ');
        return c.v;
      }
      throw e;
    }
  }
  async function kiemKetNoiLark() {
    const last = lay('lark_kiem_tay', 0);
    if (Date.now() - last < 60000) { ghi('Kiểm tra kết nối: chờ đủ 60 giây giữa hai lần'); return; }
    luu('lark_kiem_tay', Date.now());
    // Chỉ mở một lượt kiểm tra; lỗi sẽ đóng cổng trở lại.
    const cu = lay('lark_gate', null);
    if (cu) luu('lark_gate', Object.assign({}, cu, { den: 0 }));
    tokenCache = null;
    await docSheet({ moi: true });
    await lamMoiSapToi();
    capNhatNgay(homNay(), (x) => { x.gThuLuc = 0; });
    await kiemTruoc(ngayMai());
    await capNhatCotG();
  }

  async function gachNgang(o) { // o = 'B31' — chỉ gạch ngang, không đụng màu nền/màu chữ/cỡ chữ
    const url = `https://open.larksuite.com/open-apis/sheets/v2/spreadsheets/${CAI_DAT.SHEET_TOKEN}/style`;
    const r = await goiLark('PUT', url, { appendStyle: { range: `${CAI_DAT.SHEET_ID}!${o}:${o}`, style: { textDecoration: 2 } } });
    if (!r.json || r.json.code !== 0) throw new Error('mã ' + (r.json ? r.json.code : r.status));
  }

  // (4.5) tin ngoài giờ nhắn: KHÔNG bỏ — để dành, đầu giờ nhắn (07:00) gửi; tin quá 6 tiếng thì thôi
  function deDanhTin(noiDung, opt) {
    const ds = (lay('tin_cho', []) || []).filter((x) => Date.now() - x.luc < 6 * 3600e3);
    const b = bam(String(noiDung).replace(/^Nhắc lại:\s*/, '').replace(/\d{1,2}:\d{2}/g, ''));
    if (!ds.some((x) => x.b === b)) ds.push({ b, noiDung, luc: Date.now(), toiDa: opt.toiDa || 1, lap: !!opt.lap, loai: opt.loai || '' });
    luu('tin_cho', ds.slice(-20));
  }
  async function guiTinCho() {
    if (!trongGioNhan() || !laTabChinh()) return;
    const ds = lay('tin_cho', []) || []; if (!ds.length) return;
    luu('tin_cho', []);
    for (const x of ds) {
      if (Date.now() - x.luc > 6 * 3600e3) continue;
      await baoLark(String(x.noiDung).startsWith('\n') ? x.noiDung : `${x.noiDung} (tin lúc ${gioStr(new Date(x.luc))})`, { toiDa: x.toiDa, lap: x.lap, loai: x.loai || '' });
      await sleep(1500);
    }
  }
  async function baoLark(noiDung, { batBuoc = false, toiDa = 1, lap = false, tinCuoi = false, loai = '' } = {}) {
    if (!laTabChinh()) { ghi('Không gửi tin Lark: tab này không giữ quyền'); return false; }
    if (LA_GIAO && !tinCuoi) { // (5.3) Máy Giao KHÔNG báo nhóm Lark, trừ 1 tin khi đăng xong 3 bài; việc quan trọng thì hiện thông báo trên máy
      const kk = bam(String(noiDung)); baoLark.im = baoLark.im || new Set();
      if (!baoLark.im.has(kk)) { baoLark.im.add(kk); ghi('(Máy Giao không báo nhóm Lark) ' + String(noiDung).replace(/\s+/g, ' ').slice(0, 160)); if (batBuoc) thongBaoMay('Máy Giao: cần xem', String(noiDung).replace(/\s+/g, ' ').slice(0, 200)); }
      return true;
    }
    if (!LA_GIAO && !['khanh', 'ngay8', 'thu'].includes(loai)) { // (5.7.1) Máy Cao chỉ gửi 2 tin: báo cáo tuần Khanh + báo cáo ngày khi đủ bài; các tin khác chỉ ghi nhật ký
      const kk = bam(String(noiDung)); baoLark.tat = baoLark.tat || new Set();
      if (!baoLark.tat.has(kk)) { baoLark.tat.add(kk); ghi('(Không gửi nhóm Lark — đã tắt loại tin này) ' + String(noiDung).replace(/\s+/g, ' ').slice(0, 200)); }
      return true;
    }
    // (5.2) tin gọn: không còn dòng "[Hệ thống] … · Vòng Trầm Hương SMH"; nhóm Lark bắt buộc có chữ "fb" nên chỉ thêm [fb kênh 1] khi nội dung chưa có
    const nhieuDong = String(noiDung).startsWith('\n'); let tin = nhieuDong ? String(noiDung).slice(1) : String(noiDung);
    if (!/fb/i.test(tin)) tin = nhieuDong ? `${CAI_DAT.TIEN_TO_TIN || 'fb'}\n${tin}` : `${CAI_DAT.TIEN_TO_TIN || 'fb'} ${tin}`;
    if (!batBuoc && !trongGioNhan()) { deDanhTin(noiDung, { toiDa, lap, loai }); ghi('(ngoài giờ nhắn — để dành, đến giờ nhắn sẽ gửi) ' + noiDung); return false; }
    // mỗi tin (cùng nội dung, bỏ qua giờ giấc) tối đa `toiDa` lần/ngày — chống nhắn trùng
    const khoaTin = 'tin112_' + homNay(), bamTin = bam(String(noiDung).replace(/^Nhắc lại:\s*/, '').replace(/\d{1,2}:\d{2}/g, ''));
    if (!lap) {
      const dem = lay(khoaTin, {}) || {};
      if ((dem[bamTin] || 0) >= toiDa) { ghi('(hôm nay đã báo tin này rồi, không gửi lại) ' + String(noiDung).replace(/\s+/g, ' ').slice(0, 120)); return true; }
      dem[bamTin] = (dem[bamTin] || 0) + 1; luu(khoaTin, dem);
    }
    const huyDem = () => { if (lap) return; const d2 = lay(khoaTin, {}) || {}; if (d2[bamTin]) d2[bamTin]--; luu(khoaTin, d2); };
    let loiCuoi = '';
    for (let lan = 0; lan < 3; lan++) { // (4.5) mất mạng / máy chủ bận → thử lại tối đa 2 lần
      try {
        const r = await goi('POST', CAI_DAT.WEBHOOK, { msg_type: 'text', content: { text: tin } });
        const ok = !!(r.json && (r.json.code === 0 || r.json.StatusCode === 0));
        if (ok) { capNhat('suc_khoe', { tinOk: true, tinLuc: Date.now(), tinLoi: '' }); ghi('Đã báo Lark: ' + noiDung); return true; }
        loiCuoi = 'mã ' + (r.json ? (r.json.code || r.json.StatusCode) : r.status);
        if (!(r.status >= 500 || !r.json || [9499, 11232, 11233].includes(r.json.code))) break; // lỗi không tạm thời (sai từ khoá…) → không thử lại
      } catch (e) {
        loiCuoi = e.message;
        if (/quá lâu/.test(e.message)) { ghi('Gửi tin Lark phản hồi quá lâu (tin có thể đã tới nhóm) → không gửi lặp: ' + noiDung); capNhat('suc_khoe', { tinOk: true, tinLuc: Date.now(), tinLoi: 'phản hồi chậm' }); return true; }
      }
      if (lan < 2) await sleep(4000 + Math.floor(Math.random() * 6000));
    }
    huyDem();
    capNhat('suc_khoe', { tinOk: false, tinLuc: Date.now(), tinLoi: loiCuoi });
    ghi('Báo Lark lỗi: ' + loiCuoi + ' — ' + noiDung);
    return false;
  }

  // =====================================================================
  //  Đọc dữ liệu sheet
  // =====================================================================
  function chuO(cell) {
    if (cell == null) return '';
    if (typeof cell === 'string') return cell;
    if (typeof cell === 'number') return String(cell);
    if (Array.isArray(cell)) return cell.map((s) => (typeof s === 'string' ? s : (s && (s.text != null ? s.text : '')) || '')).join('');
    if (typeof cell === 'object' && cell.text != null) return String(cell.text);
    return '';
  }

  function ngayO(cell) {
    if (typeof cell === 'number' && cell > 20000 && cell < 80000) {
      const d = new Date(Date.UTC(1899, 11, 30) + Math.floor(cell + 1e-6) * 86400000);
      return `${pad(d.getUTCDate())}-${pad(d.getUTCMonth() + 1)}-${d.getUTCFullYear()}`;
    }
    const s = chuO(cell);
    const m = s.match(/(\d{1,2})\s*[-\/.]\s*(\d{1,2})\s*[-\/.]\s*(\d{4})/);
    return m ? `${pad(m[1])}-${pad(m[2])}-${m[3]}` : '';
  }

  function kiemTenCot(values) {
    const h = values[0] || [];
    for (const c of COT_BAT_BUOC) {
      if (!thuong(chuO(h[c.chiSo])).includes(c.chua)) {
        return `Tên cột ${c.cot} trên sheet không còn là "${c.ten}" (đang là "${chuan(chuO(h[c.chiSo])) || 'trống'}") — script dừng để tránh đăng nhầm cột`;
      }
    }
    return null;
  }

  // Ô ảnh của Lark: { fileToken, ... } (hoặc danh sách nhiều phần) → danh sách mã ảnh
  function tokenAnh(c) {
    if (!c) return [];
    if (Array.isArray(c)) return c.reduce((a, x) => a.concat(tokenAnh(x)), []);
    if (typeof c === 'object' && c.fileToken) return [String(c.fileToken)];
    return [];
  }
  const anhNhieuO = (r, tu, den) => { let a = []; for (let i = tu; i <= den; i++) a = a.concat(tokenAnh(r[i])); return a; };
  // Ảnh cố định của comment Bài 3: ô O2 + 1 ảnh ngẫu nhiên trong P2, Q2, O3, P3, Q3
  function anhChung(v) {
    const r2 = v[1] || [], r3 = v[2] || [];
    return { co: tokenAnh(r2[14])[0] || '', pool: [r2[15], r2[16], r3[14], r3[15], r3[16]].reduce((a, x) => a.concat(tokenAnh(x)), []) };
  }
  function hangCuaNgay(values, ngay) {
    const out = [];
    for (let i = 1; i < values.length; i++) {
      const r = values[i] || [];
      if (ngayO(r[7]) === ngay) {
        const anh2 = anhNhieuO(r, 8, 10), anh3 = anhNhieuO(r, 11, 13), anhCmt = anhNhieuO(r, 14, 16);
        out.push({ hang: i + 1, bai: chuO(r[1]).trim(), cmt: chuO(r[2]).trim(), bai2: chuO(r[3]).trim(), cmt2: chuO(r[4]).trim(), bai3: chuO(r[5]).trim(),
          anh2, anh3, anhCmt, a2: anh2.length, a3: anh3.length, ac: anhCmt.length });
      }
    }
    return out;
  }
  // (5.2) bản gọn cho tin Lark: chỉ nói thiếu gì, không nêu số ô
  function thieuAnhNgan(h) {
    const t = [];
    if (h.bai2 && !h.a2) t.push('ảnh Bài 2');
    if (h.bai3 && !h.a3) t.push('ảnh Bài 3');
    if (h.bai3 && !h.ac) t.push('ảnh comment Bài 3');
    return t;
  }
  // Hàng có chữ nhưng chưa có ảnh (dùng cho cảnh báo ngày mai)
  function thieuAnhHang(h) {
    const t = [];
    if (h.bai2 && !h.a2) t.push(`hàng ${h.hang} chưa có ảnh Bài 2`);
    if (h.bai3 && !h.a3) t.push(`hàng ${h.hang} chưa có ảnh Bài 3`);
    if (h.bai3 && !h.ac) t.push(`hàng ${h.hang} chưa có ảnh comment Bài 3`);
    return t;
  }

  // Lịch 7 ngày tới cho tab "Sắp tới" (và xem trước bài hôm nay)
  async function lamMoiSapToi() {
    const v = await docSheet();
    const loiCot = kiemTenCot(v);
    const ds = [];
    for (let i = 0; i < CAI_DAT.SAP_TOI_SO_NGAY; i++) {
      const d = congNgay(i); const ngay = ngayStr(d);
      ds.push({ ngay, thu: THU[d.getDay()], hangs: loiCot ? [] : hangCuaNgay(v, ngay).map((h) => ({ hang: h.hang, bai: h.bai, cmt: h.cmt, bai2: h.bai2, cmt2: h.cmt2, bai3: h.bai3, a2: h.a2, a3: h.a3, ac: h.ac })) });
    }
    const ch = loiCot ? null : anhChung(v);
    luu('sap_toi', { luc: Date.now(), loiCot, ds, chung: ch ? { co: !!ch.co, pool: ch.pool.length } : null });
    veBang();
  }

  // =====================================================================
  //  Khoá: nhiều tab Facebook thì chỉ 1 tab làm việc
  // =====================================================================
  const MA_TAB = (() => { let id = null; try { id = sessionStorage.getItem('smhdb_ma_tab'); } catch (e) { /* */ }
    // window.name chỉ còn khi tải lại CHÍNH tab này; tab mới mở ra (dù được copy sessionStorage) sẽ không có → cấp mã mới
    const wn = String(window.name || '').match(/smhdb:(\w+)/);
    if (!id || !wn || wn[1] !== id) { id = Math.random().toString(36).slice(2, 10); try { sessionStorage.setItem('smhdb_ma_tab', id); } catch (e) { /* */ } }
    try { window.name = 'smhdb:' + id; } catch (e) { /* */ }
    return id; })();
  let dangBan = false;
  const cuHon = (a, b) => { const x = String(a).split('.').map(Number), y = String(b).split('.').map(Number);
    for (let i = 0; i < Math.max(x.length, y.length); i++) { if ((x[i] || 0) !== (y[i] || 0)) return (x[i] || 0) < (y[i] || 0); } return false; };
  function giuKhoa() {
    const k = GM_getValue('khoa_dang_bai_that', null);
    const now = Date.now();
    const hienThi = document.visibilityState === 'visible';
    const cu = !k || now - k.ts > 150000; // tab ẩn bị trình duyệt làm chậm đồng hồ (~1 phút/lần) nên cho dư dả
    const cuaMinh = k && k.id === MA_TAB;
    // tab đang hiện chỉ giành quyền khi tab giữ quyền đã bị ẩn liên tục > 90 giây (tránh giành đi giành lại)
    const gianhDuoc = k && !k.ghim && !k.ban && !k.hien && hienThi && now - (k.anTu || k.ts) > 90000;
    const banCu = k && !k.ghim && !k.ban && cuHon(k.v || '0', PHIEN_BAN) && (hienThi || !k.hien); // tab kia còn chạy bản cũ (chưa tải lại); tab ẩn không giành của tab đang hiện
    if (cu || cuaMinh || gianhDuoc || banCu) {
      if (banCu && !cuaMinh) ghi('Tab khác đang chạy bản cũ ' + (k.v || '') + ' → tab này (bản ' + PHIEN_BAN + ') nhận làm việc');
      if (!cuaMinh) luuNK('Nhận quyền làm việc từ tab ' + (k && k.id || '(chưa có)'), false);
      const anTu = hienThi ? 0 : ((cuaMinh && k.anTu && !k.hien) ? k.anTu : now);
      GM_setValue('khoa_dang_bai_that', { id: MA_TAB, ts: now, hien: hienThi, anTu, ban: dangBan || dangChay, v: PHIEN_BAN, ghim: !!(cuaMinh && k.ghim) });
      return true;
    }
    return false;
  }
  const laTabChinh = () => { const k = GM_getValue('khoa_dang_bai_that', {}) || {}; return k.id === MA_TAB && Date.now() - k.ts <= 150000; };
  let dungMoc = 0, choNhanKhoa = false;
  function kiemDung() {
    const st = trangThaiNgay(homNay());
    void st;
    if (!laTabChinh()) throw new LoiTamHoan('Tạm mất quyền làm việc — lượt này hoãn, lát nữa làm tiếp');
    if (lay('tam_dung', false) || (lay('dung_moc', 0) > dungMoc) || (dangQuet && lay('quet_dung', 0) > moQuet)) throw new LoiDung('Đã nhận yêu cầu Tạm dừng/Hủy');
    if (document.visibilityState !== 'visible') throw new LoiTamHoan('Tab bị ẩn trong lúc thao tác — chờ tab hiện lại sẽ làm tiếp');
  }
  async function nhanQuyen() {
    if (dangChay || choNhanKhoa) return false;
    choNhanKhoa = true;
    try {
      if (!giuKhoa()) return false;
      await sleep(180 + Math.floor(Math.random() * 120));
      if (!laTabChinh()) return false;
      dangChay = true; nhipBatDau = Date.now(); giuKhoa();
      dungMoc = lay('dung_moc', 0);
      return true;
    } finally { choNhanKhoa = false; }
  }
  function yeuCauViec(loai, them) {
    const k = 'viec112_' + loai, old = lay(k, null);
    if (old && old.tt !== 'xong' && Date.now() - old.luc < 60000) { ghi('Yêu cầu ' + loai + ' đã được ghi nhận — đang chờ/xử lý'); return; }
    luu(k, Object.assign({ luc: Date.now(), tuTab: MA_TAB, tt: 'cho' }, them || {}));
    ghi('Gửi yêu cầu ' + loai + ' cho tab làm việc');
    nhip();
  }
  let ghiBat = null; // các dòng nhật ký của việc vừa bấm (để báo đúng kết quả việc đó)
  function tenYeuCau(loai, v) {
    const so = (v && v.so) || 5;
    return ({ ketnoi: 'Đang kiểm tra kết nối Lark', lammoi: 'Đang đọc lại Lark sheet', kiembai: 'Đang kiểm tra bài đã đăng hôm nay', kiem: 'Đang kiểm tra sheet ngày mai',
      dobai: 'Đang dò bài trên trang', kiemma: 'Đang kiểm tra mã khoá Facebook', tinthu: 'Đang gửi tin thử vào nhóm Lark', anhmoi: 'Đang cập nhật ảnh mới từ sheet',
      rasoat: 'Đang rà soát comment ' + (so >= 5 ? '5 bài gần nhất' : so + ' bài gần nhất'), khanhthu: 'Đang kiểm thử trang ' + CAI_DAT.KHANH_TEN })[loai] || 'Đang làm việc bạn vừa bấm';
  }
  function tomTatYeuCau(loai, ds) {
    const bo = (m) => String(m || '').replace(/\s*\[tab [^\]]+\]\s*$/, '');
    const tim = (re) => { for (let i = ds.length - 1; i >= 0; i--) if (re.test(ds[i])) return bo(ds[i]); return ''; };
    const loi = ds.some((m) => /^Lỗi khi |^Lỗi: |chưa làm được|chưa đọc được|không đọc được/.test(m));
    let chu = '';
    if (loai === 'kiembai') { const q = lay('kiembai_kq', null); if (q && Date.now() - q.luc < 120000) { const mm = phutTrongNgay(new Date()); const chuaThay = lichHomNay().items.filter((i) => !i.xong && i.tt !== 'huy' && mm >= i.gioDK).map((i) => i.ten); chu = `${q.xong}/${q.tong} bài hôm nay đã lên trang${q.moi ? ` — vừa thấy thêm ${q.moi} bài` : ''}${chuaThay.length ? ` · quá giờ chưa thấy: ${chuaThay.join(', ')}` : ''}`; } }
    else if (loai === 'anhmoi') chu = tim(/^Tải sẵn ảnh:|^Cập nhật ảnh mới/).replace(/^Tải sẵn ảnh: /, '');
    else if (loai === 'rasoat') { chu = tim(/^Rà soát/).replace(/^Rà soát comment: /, ''); const g = chu.match(/^Rà soát: gửi bù cho (.+) \((\d+) comment\)$/); if (g) chu = `${g[1]} thiếu comment → đang gửi bù ${g[2]} comment (theo dõi ở thanh trên cùng)`; else if (/không còn bài nào cần kiểm/.test(chu)) chu = 'Các bài gần nhất đều đã đủ comment — không cần gửi bù'; }
    else if (loai === 'kiem') chu = tim(/^Kiểm tra sheet ngày/);
    else if (loai === 'lammoi') chu = tim(/^Đọc|sheet/i) || 'Đã đọc lại Lark sheet';
    else if (loai === 'tinthu') chu = tim(/^Đã báo Lark|Không gửi|Gửi tin Lark|^\(/);
    else if (loai === 'khanhthu') chu = tim(new RegExp(CAI_DAT.KHANH_TEN));
    else if (loai === 'kiemma') chu = tim(/mã khoá|Mã khoá|API/);
    else if (loai === 'ketnoi') chu = tim(/Lark/);
    if (!chu) { const cuoi = ds.filter((m) => !/^(Gửi yêu cầu|Cao bấm|Nhận quyền)/.test(m)); chu = cuoi.length ? bo(cuoi[cuoi.length - 1]) : 'Đã làm xong, không có gì thay đổi'; }
    return { chu: chu.slice(0, 220), mau: loi ? 'vang' : 'ok' };
  }
  async function xuLyYeuCau() {
    for (const loai of ['ketnoi', 'lammoi', 'kiembai', 'kiem', 'dobai', 'kiemma', 'tinthu', 'anhmoi', 'rasoat', 'khanhthu']) {
      const k = 'viec112_' + loai, v = lay(k, null);
      if (!v || Date.now() - v.luc > (loai === 'rasoat' ? 45 : 10) * 60000) continue; // rà soát bấm lúc đang quét thì chờ quét xong (tối đa 45 phút)
      const dangDoCu = v.tt === 'dang' && loai !== 'tinthu' && Date.now() - (v.nhan || v.luc) > 2 * 60000;
      if (v.tt !== 'cho' && !dangDoCu) continue;
      if (!laTabChinh()) return;
      if (loai === 'rasoat' && (dangBan || dangQuet || lay('dang_do', null) || lay('quet_dang', null) && Date.now() - lay('quet_dang', null).luc < 90000)) continue; // đang bận → để yên, lát nữa làm
      luu(k, Object.assign({}, v, { tt: 'dang', nhan: Date.now(), tab: MA_TAB }));
      { const ten = tenYeuCau(loai, v); if (hdChay && hdChay.key === 'yeucau') { hdChay.ten = ten; hdChay.chi = ''; hdChay.hien = true; luu('hoat_dong', hdChay); } }
      ghiBat = []; veBang();
      try {
        if (loai === 'ketnoi') await kiemKetNoiLark();
        if (loai === 'lammoi') {
          await docSheet({ moi: true }); await lamMoiSapToi();
          if (lay('kiem_' + ngayMai(), null) || phutTrongNgay(new Date()) >= docGio(CAI_DAT.GIO_KIEM_TRUOC)) await kiemTruoc(ngayMai());
          await doBaiTrang({ thuCong: true }); await capNhatCotG();
        }
        if (loai === 'kiembai') {
          const truoc = lichHomNay().items.filter((i) => i.xong).length;
          await doBaiTrang({ thuCong: true });
          await doLichNgoai(true).catch((e) => ghi('Kiểm video/manifest lỗi: ' + e.message));
          await baoLinkBaiScript().catch(() => {});
          const L = lichHomNay(); const xong = L.items.filter((i) => i.xong).length;
          luu('kiembai_kq', { luc: Date.now(), xong, tong: L.items.length, moi: Math.max(0, xong - truoc), api: coApi() });
        }
        if (loai === 'kiem') { await kiemTruoc(ngayMai(), { thuCong: true }); await lamMoiSapToi(); }
        if (loai === 'dobai') await doBaiTrang({ thuCong: true });
        if (loai === 'kiemma') await kiemMaKhoa();
        if (loai === 'anhmoi') {
          const t0 = Date.now(); await taiTruocAnh(true);
          const c = lay('sheet_cache112', null); if (!c || c.luc < t0) { try { await docSheet({ moi: true }); } catch (e) { ghi('Cập nhật ảnh mới: chưa đọc được sheet (' + e.message + ')'); } }
          await kiemTruoc(ngayMai(), { thuCong: true }); await lamMoiSapToi(); // (5.3) làm mới luôn danh sách "việc cần xử lý"
        }
        if (loai === 'rasoat') {
          const ng = homNay(); gioRaSoat(ng); // bảo đảm đã có lịch rà soát
          capNhatNgay(ng, (x) => { const g = x.rs.gio; g.splice(x.rs.lan, 0, phutTrongNgay(new Date()) - 1); x.rs.thuLuc = 0; });
          const so = v.so || 5;
          // (5.8.2) dò bài mới trên trang trước (video/manifest nhân sự vừa đăng), rồi mới rà soát
          await doBaiTrang({ thuCong: true }).catch(() => {});
          await doLichNgoai(true).catch((e) => ghi('Kiểm video/manifest lỗi: ' + e.message));
          ghi(`Cao bấm "Rà soát comment ${so >= 5 ? 'tất cả (5 bài gần nhất)' : so + ' bài'}"`);
          await raSoatCmt(true, so);
          luu('rasoat_kq', { luc: Date.now() });
        }
        if (loai === 'khanhthu') await khanhThuNgay();
        if (loai === 'tinthu') await baoLark('Tin thử từ popup — kết nối nhóm fb hoạt động', { batBuoc: true, lap: true, loai: 'thu' });
      } catch (e) { ghi('Lỗi khi ' + tenYeuCau(loai, v).replace(/^Đang /, '') + ': ' + e.message); }
      finally {
        const kq = tomTatYeuCau(loai, ghiBat || []); ghiBat = null;
        if (hdChay && hdChay.key === 'yeucau') { hdChay.cuoi = kq.chu; hdChay.soDong = (hdChay.soDong || 0) + 1; }
        luu(k, Object.assign({}, v, { tt: 'xong', xong: Date.now(), kq: kq.chu, mau: kq.mau }));
        veBang();
      }
    }
  }

  // =====================================================================
  //  Facebook: tư cách, đúng trang, giờ bài gần nhất
  // =====================================================================
  const dangHien = (d) => { const r = d.getBoundingClientRect(); if (!(r.width > 0 && r.height > 0)) return false;
    return d.checkVisibility ? d.checkVisibility({ checkOpacity: true, checkVisibilityCSS: true }) : true; };
  // kiểu mới của Facebook: tên bước hiện ở hộp tiêu đề mỏng riêng (hộp đang hiển thị KHÔNG bị aria-hidden)
  const tieuDeHien = (chu) => Array.from(document.querySelectorAll('div[role="dialog"]')).some((h) => (h.innerText || '').trim() === chu && h.getBoundingClientRect().height > 0 && !h.closest('[aria-hidden="true"]'));
  const laCaiDat = (d) => {
    const t = d.innerText || '';
    if (t.startsWith('Cài đặt bài viết') && d.getBoundingClientRect().height > 100) return true; // kiểu cũ
    if (!(t.includes('Xem trước bài viết') && t.includes('Chia sẻ lên nhóm'))) return false; // kiểu mới: màn Cài đặt nằm chung hộp với màn soạn bài
    const e = d.querySelector('div[contenteditable="true"][data-lexical-editor]');
    if (e && !e.closest('[aria-hidden="true"]')) return false;
    return tieuDeHien('Cài đặt bài viết');
  };
  const laNhom = (d) => { const t = d.innerText || ''; if (t.startsWith('Chia sẻ lên nhóm') && d.getBoundingClientRect().height > 100) return true; return t.includes('Chọn nhóm') && tieuDeHien('Chia sẻ lên nhóm') && !!d.querySelector('input[type="checkbox"]'); };
  const hopThoai = (dk) => Array.from(document.querySelectorAll('div[role="dialog"]')).find((d) => dangHien(d) && dk(d));
  const nutTheoChu = (goc, chu) => Array.from(goc.querySelectorAll('[role="button"]')).find((b) => chuan(b.innerText) === chu);
  function nutTaiKhoan() { const ds = Array.from(document.querySelectorAll('div[role="button"][aria-label="Trang cá nhân của bạn"]')); return ds.find(dangHien) || ds[0] || null; }

  async function moMenuTaiKhoan() {
    const dk = () => hopThoai((d) => d.querySelector('a[href^="/me/"]'));
    const dongPopup = async () => { document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', code: 'Escape', keyCode: 27, which: 27, bubbles: true })); await sleep(600); };
    for (let lan = 0; lan < 4; lan++) {
      const dangMo = dk(); if (dangMo) return dangMo;
      const nut = await cho(() => nutTaiKhoan() || Array.from(document.querySelectorAll('[role="button"][aria-label="Trang cá nhân của bạn"]')).find(dangHien) || null, 8000, 400);
      if (!nut) { await sleep(1500); continue; }
      // có bảng khác đang mở (Thông báo, Messenger…) thì đóng trước, kẻo bấm lần này chỉ để đóng bảng đó
      let nut2 = nut;
      if (lan && hopThoai(() => true)) { await dongPopup(); nut2 = nutTaiKhoan() || nut; }
      if (lan % 2 && dangHien(nut2)) { try { ganBam(nut2); } catch (e) { nut2.click(); } } else nut2.click(); // lần chẵn: click thường; lần lẻ: chuỗi sự kiện chuột đầy đủ
      const m = await cho(dk, 9000, 400); // menu hiện chậm → chờ tới 9 giây, KHÔNG bấm thêm (bấm thêm sẽ đóng menu lại)
      if (m) return m;
      await sleep(1000);
    }
    return null;
  }
  async function dongMenuTaiKhoan() {
    if (hopThoai((d) => d.querySelector('a[href^="/me/"]'))) { const nut = nutTaiKhoan(); if (nut) nut.click(); await sleep(500); }
  }

  // true = đã đúng tư cách; false = vừa bấm chuyển (trang sẽ tải lại)
  async function damBaoTuCach() {
    kiemDung();
    const menu = await moMenuTaiKhoan();
    if (!menu) {
      // phương án 2: ô bình luận ghi "Bình luận dưới tên <Page>" = Facebook đang ở tư cách Page → đủ tin cậy để làm tiếp
      const tenOCmt = Array.from(document.querySelectorAll('div[contenteditable="true"][aria-label^="Bình luận dưới tên"]')).map((e) => chuan(e.getAttribute('aria-label'))).find(Boolean) || '';
      if (tenOCmt && tenOCmt.startsWith(chuan('Bình luận dưới tên ' + CAI_DAT.TEN_TRANG))) {
        capNhat('suc_khoe', { tuCach: CAI_DAT.TEN_TRANG + ' (xác nhận qua ô bình luận)', tuCachLuc: Date.now(), tuCachDung: true });
        ghi('Menu tài khoản không mở được, nhưng ô bình luận đang ghi "dưới tên ' + CAI_DAT.TEN_TRANG + '" → đúng tư cách Page, làm tiếp');
        return true;
      }
      // phương án 3: tải lại trang 1 lần rồi thử lại (tối đa 1 lần / 10 phút)
      if (Date.now() - lay('tc_reload_luc', 0) > 10 * 60000) {
        luu('tc_reload_luc', Date.now()); ghi('Không mở được menu tài khoản → tải lại trang rồi thử lại');
        await sleep(800); roiTrang(); return false;
      }
      throw new LoiMem('Không mở được menu tài khoản Facebook (đã thử bấm 4 lần + tải lại trang; có thể đã bị đăng xuất)');
    }
    // (4.5) tên đọc lại cho chắc (menu vừa mở có thể chưa vẽ xong); so tên bỏ dấu câu/khoảng trắng
    const ten = chuan(await cho(() => { const m2 = hopThoai((d) => d.querySelector('a[href^="/me/"]')) || menu; const a = m2.querySelector('a[href^="/me/"]'); return a && chuan(a.innerText); }, 4000, 300) || '');
    const dungTen = chuanTen(ten) === chuanTen(CAI_DAT.TEN_TRANG);
    capNhat('suc_khoe', { tuCach: ten || '(chưa đọc được tên)', tuCachLuc: Date.now(), tuCachDung: dungTen });
    ghi('Tư cách hiện tại: "' + ten + '"');
    if (dungTen) { await dongMenuTaiKhoan(); return true; }
    const timNutChuyen = () => Array.from(document.querySelectorAll('[aria-label^="Chuyển sang"]')).find((e) => chuanTen(e.getAttribute('aria-label')) === chuanTen('Chuyển sang ' + CAI_DAT.TEN_TRANG));
    let nut = timNutChuyen();
    if (!nut) { // phương án 2: mở "Xem tất cả trang cá nhân" rồi tìm lại
      const xem = Array.from(menu.querySelectorAll('[role="button"], a')).find((b) => /^Xem tất cả trang cá nhân/.test(chuan(b.innerText)));
      if (xem) { xem.click(); nut = await cho(timNutChuyen, 6000, 400); }
    }
    if (!nut) { await dongMenuTaiKhoan(); throw new LoiMem(`Đang dùng tư cách "${ten}", không tìm thấy nút chuyển sang "${CAI_DAT.TEN_TRANG}"`); }
    const lan = lay('lan_chuyen', []).filter((t) => Date.now() - t < 15 * 60000);
    if (lan.length >= 4) { await dongMenuTaiKhoan(); throw new LoiMem(`Đã thử chuyển sang "${CAI_DAT.TEN_TRANG}" 4 lần nhưng vẫn đang là "${ten}"`); }
    lan.push(Date.now()); luu('lan_chuyen', lan);
    ghi(`Đang là "${ten}" → chuyển sang "${CAI_DAT.TEN_TRANG}"`);
    kiemDung();
    const cachKhac = lan.length % 2 === 0; // lần chẵn dùng chuỗi sự kiện chuột đầy đủ
    if (cachKhac) { try { ganBam(nut); } catch (e) { nut.click(); } } else nut.click();
    // trang không chuyển sau 8 giây → bấm lại bằng cách còn lại
    if (!(await cho(() => !document.contains(nut) || document.readyState === 'loading', 8000, 400))) {
      ghi('Bấm chuyển tư cách chưa ăn → bấm lại bằng cách khác');
      try { if (cachKhac) nut.click(); else ganBam(nut); } catch (e) { /* */ }
    }
    return false;
  }

  const dungTrang = () => location.pathname.toLowerCase().replace(/\/+$/, '') === CAI_DAT.DUONG_DAN_TRANG;
  function veTrang() { ghi('Chuyển tab về trang ' + CAI_DAT.TEN_NGAN); roiTrang(CAI_DAT.URL_TRANG); }

  // Tuổi (phút) của bài mới nhất đang hiện trên trang; null nếu không đọc được
  async function tuoiBaiMoiNhat() {
    if (coApi()) {
      try {
        const ds = await baiTrenTrangApi(Date.now() - 2 * 864e5);
        const moi = Math.max(0, ...ds.map((p) => p.luc || 0));
        const phut = moi ? Math.max(0, Math.floor((Date.now() - moi) / 60000)) : null;
        ghi(`Giãn cách: bài gần nhất trên trang (qua API) ${phut === null ? 'không có trong 2 ngày' : phut + ' phút trước'}`);
        return phut;
      } catch (e) { ghi('Giãn cách qua API lỗi (' + e.message + ') → đọc giờ trên trang'); }
    }
    return tuoiBaiMoiNhatTrang();
  }
  async function tuoiBaiMoiNhatTrang() {
    const y0 = window.scrollY;
    window.scrollTo(0, 1200); await sleep(2500);
    window.scrollTo(0, 2200); await sleep(1500);
    const re = /^(Vừa xong|(\d+)\s*(phút|giờ|ngày|tuần)(\s*trước)?|Hôm qua.*|\d{1,2}\s+[Tt]háng\s+\d{1,2}.*)$/;
    let min = null;
    for (const e of document.querySelectorAll('span[id]')) { // giờ ở đầu bài viết (không lấy giờ của comment)
      if (e.childElementCount || e.closest('[role="dialog"]')) continue;
      const m = (e.textContent || '').trim().match(re);
      if (!m) continue;
      let p;
      if (m[1] === 'Vừa xong') p = 0;
      else if (m[2]) p = +m[2] * ({ phút: 1, giờ: 60, ngày: 1440, tuần: 10080 })[m[3]];
      else p = 1440;
      if (min === null || p < min) min = p;
    }
    window.scrollTo(0, y0);
    return min;
  }

  // =====================================================================
  //  Facebook: đăng bài
  // =====================================================================
  const hopSoanBai = () => hopThoai((d) => d.querySelector('div[contenteditable="true"][data-lexical-editor]') && d.innerText.includes('Tạo bài viết') && !laCaiDat(d));

  function timNutSoanBai() {
    const anh = Array.from(document.querySelectorAll('[role="button"]')).find((b) => chuan(b.innerText) === 'Ảnh/video' && !b.closest('[role="dialog"]'));
    const boQua = ['Ảnh/video', 'Thước phim', 'Video trực tiếp', 'Sự kiện trong đời'];
    if (anh) {
      let p = anh;
      for (let i = 0; i < 8 && p; i++) {
        p = p.parentElement;
        const bs = Array.from(p.querySelectorAll('[role="button"]')).filter((b) => { const t = chuan(b.innerText); return t && !boQua.includes(t); });
        if (bs.length) return bs[0];
      }
    }
    return Array.from(document.querySelectorAll('[role="button"]')).find((b) => chuan(b.innerText) === 'Bạn đang nghĩ gì?');
  }

  async function datChu(ed, text) {
    const dong = text.split('\n');
    ed.focus(); await sleep(200);
    const sel = window.getSelection(); const rg = document.createRange();
    rg.selectNodeContents(ed); sel.removeAllRanges(); sel.addRange(rg);
    await sleep(300);
    document.execCommand('insertText', false, dong[0]);
    if (dong.length > 1) {
      await sleep(300);
      const dt = new DataTransfer(); dt.setData('text/plain', '\n' + dong.slice(1).join('\n'));
      ed.dispatchEvent(new ClipboardEvent('paste', { clipboardData: dt, bubbles: true, cancelable: true }));
    }
    await sleep(800);
    return chuan(ed.innerText) === chuan(text);
  }

  // ===================== (5.9) SOẠN THỬ VIDEO (dừng trước nút Đăng) =====================
  const TAB_VIDEO = 'e2f139'; // tab "Kênh 1 Vòng Trầm Hương SMH" trong bảng MKT 10
  const chuOV = (c) => (c == null ? "" : typeof c === "string" ? c : Array.isArray(c) ? c.map((x) => (x && (x.text || x.link)) || "").join("") : typeof c === "object" ? (c.text || "") : String(c));
  async function docHangVideo(hang) {
    const url = `https://open.larksuite.com/open-apis/sheets/v2/spreadsheets/${CAI_DAT.SHEET_TOKEN}/values/${TAB_VIDEO}!A${hang}:N${hang}`;
    const r = await goiLark('GET', url, null);
    if (!r.json || r.json.code !== 0) throw new LoiMem('Không đọc được hàng ' + hang + ' trong tab Kênh 1 (mã ' + (r.json ? r.json.code : r.status) + ')');
    const v = ((r.json.data && r.json.data.valueRange && r.json.data.valueRange.values) || [])[0] || [];
    const oN = v[13]; const tep = Array.isArray(oN) ? oN.find((x) => x && x.fileToken && (/^video\//.test(x.mimeType || '') || /\.(mp4|mov|m4v)$/i.test(x.text || ''))) : null;
    return { hang, chu: chuOV(v[4]).trim(), tieuDe: chuOV(v[0]).trim(), tep };
  }
  async function taiVideoLark(tep) {
    let loiCuoi = null;
    for (let lan = 0; lan < 3; lan++) {
      if (lan) { ghi('Video: tải lần ' + lan + ' chưa được (' + (loiCuoi && loiCuoi.message) + ') → tải lại'); await sleep(3000 + Math.floor(Math.random() * 3000)); }
      const t = await larkToken();
      capNhat('lark_dem', { ngay: homNay(), so: (lay('lark_dem', {}).ngay === homNay() ? lay('lark_dem', {}).so || 0 : 0) + 1 });
      const t0 = Date.now();
      const r = await new Promise((resolve) => {
        GM_xmlhttpRequest({
          method: 'GET', url: 'https://open.larksuite.com/open-apis/drive/v1/medias/' + encodeURIComponent(tep.fileToken) + '/download',
          headers: { Authorization: 'Bearer ' + t }, responseType: 'blob', timeout: 240000,
          onload: (x) => resolve({ status: x.status, blob: x.response }),
          onerror: () => resolve({ mang: 'Mất kết nối khi tải video từ Lark' }),
          ontimeout: () => resolve({ mang: 'Tải video từ Lark quá lâu (quá 4 phút)' }),
        });
      });
      if (r.mang) { loiCuoi = new LoiMem(r.mang); continue; }
      const b = r.blob;
      if (!b || b.size < 100000) { let j = null; try { j = JSON.parse(await b.text()); } catch (e) { /* */ } if (j && MA_TOKEN_LARK.includes(String(j.code))) boTokenLark(); loiCuoi = new LoiMem('Lark trả về dữ liệu không phải video' + (j ? ' (mã ' + j.code + ': ' + (j.msg || '') + ')' : ' (' + (b ? b.size : 0) + ' byte)')); continue; }
      if (tep.size && Math.abs(b.size - tep.size) > 1024) { loiCuoi = new LoiMem(`video tải về chưa đủ (${b.size}/${tep.size} byte)`); continue; }
      ghi(`Video: đã tải "${tep.text}" (${(b.size / 1048576).toFixed(1)} MB) trong ${((Date.now() - t0) / 1000).toFixed(1)} giây`);
      const ten = /\.(mp4|mov|m4v)$/i.test(tep.text || '') ? tep.text : (tep.text || 'video') + '.mp4';
      return new File([b], ten, { type: (b.type && /^video\//.test(b.type)) ? b.type : (tep.mimeType || 'video/mp4') });
    }
    throw loiCuoi || new LoiMem('Không tải được video');
  }

  // ===================== (5.9.6) TẠO ẢNH MANIFEST TỪ CHỮ + ẢNH NỀN (chỉ chạy khi bấm nút, để đỡ gọi Lark) =====================
  const FONT_MF = { 'UTM American Sans': 'AAEAAAAPAIAAAwBwT1MvMkA9kvAAAAF4AAAATlBDTFRD9kC/AACOuAAAADZjbWFwqh29IwAABbQAAAQmY3Z0IMiEyy0AAAp0AAAAPGZwZ22DM8JPAAAJ3AAAABRnbHlmhG6d8wAADKgAAHVoaGVhZPAl0u4AAAD8AAAANmhoZWEcOhKjAAABNAAAACRobXR4DTf+GwAAAcgAAAPsa2Vybg0XD8oAAIIQAAAFcGxvY2Hv1xH8AAAKsAAAAfhtYXhwAg8HFwAAAVgAAAAgbmFtZcLJTgYAAIeAAAAEknBvc3TMtECzAACMFAAAAqNwcmVwBWQUUgAACfAAAACEAAEAAAABAABXr+EZXw889QADCAAAAAAAt7hpSAAAAADGmh0A/2/+MRNOCXoAAAAGAAEAAAAAAAAAAQAACXr+MQAAE7D/b//GE04AAQAAAAAAAAAAAAAAAAAAAPsAAQAAAPsGUQBxAAAAAAACAAgAQAAKAAAAkACEAAAAAAAAA3MBkAAFAAYFRwTMAAD+iAVHBMwAAAH1AG0CZgUCAgQGAwUFBgICBAAAAAAAAAAAAAAAAAAAAABLVCAgAEAAICAmBkL+QgDNCXoBzwAAE7AALQAAAAACOwAAAmwAAAHOAAACsgAAA/UAAAO8AAAFgQAABQIAAAF+AAABgQAAAbQAAANPAAADJAAAAZ//ywMEAAABVgAAArYAAAUiAAACHv/sBBYAAAPZAAAE+wAABC8AAAUAAAAEAgAABNsAAAUI//wBrgAAAdL/8AP9AAACdAAAA74AAAPSAAAF2wAoBLgAAAQzAAAEWgAABQoAAAPGAAADwQAABRD/+gSlAAAB5QAAA7IAAASdAAADhQAABuEAAAUaAAAFtv/6BIEAAAW6//oExAAAA+UAAAQcAAAErgAABTMAAAdYAAAFbAAABXoAAgR+AAAB4QAAAswAAAIxAAAEVgAABOQAAAFsAAAEAP/2BC8AAANcAAQEXP/+BDf/+gLdAAAEXv/+BBIAAAHSAAICbAAAA+0AAAG0AAAGeAAABA4AAASXAAIEUwAABGz//gKjAAADFAAAAsYAAAQWAAAETQAABhwAAARPAAAEFAAAA4X//gJJAAAAkwAAAnwAAAKsAAAEAAAABJ3//ASf//4EAAAABAAAXQUSAAAFKAAABQgAAAS0AAAEtAAABLYAAAS2AAAEtAAABLYAAAS2AAAEtgAABLYAAAS2AAAEtgAABLYAAAS2AAAEtgAABLYAAAS2AAAEtgAAA7IAAAOyAAADxgAAA8YAAAPGAAADsgAAA7IAAAOyAAADsgAAA7IAAAOyAAAB4wAAAeMAAAHlAAAB5f9vAeUAAAW2//oFtv/6Bbb/+gW2//oFtv/6Bbb/+gW2//oFtv/6Bbb/+gW2//oFtv/6BK4AAASuAAAErgAABK4AAASuAAAErgAABK4AAASuAAAErgAABK4AAASuAAAFtv/6Bbb/+gW2//oFtv/6Bbb/+gW2//oFegACBXoAAgV6AAIFegACBXoAAgP3//YD9//2BAD/9gQA//YEAP/2A/f/9gP3//YD9//2A/f/9gP3//YD9//2BAD/9gQA//YEAP/2BAD/9gQA//YEAP/2BCb/+gQm//oEN//6BDf/+gQ3//oENf/6BDX/+gQ1//oENf/6BDX/+gQ1//oBsgAAAbIAAAHSABIB0v+PAdIAAgSXAAIElwACBJcAAgSXAAIElwACBJcAAgSXAAIElwACBJcAAgSXAAIElwACBBIAAAQSAAAEFgAABBYAAAQWAAAEFgAABBIAAAQSAAAEFgAABBYAAAQWAAAElwACBJcAAgSXAAIElwACBJcAAgSXAAIEFAAABBQAAAQUAAAEFAAABBQAAAaqAAACRgAAAkQAAAJ1AAAE+gAAA5oAAAVkAAAEXP/+AY0AAAF+AAACsgACArIAAAYKAAAAAAADAAAAAAAAABwAAQAAAAACIAADAAEAAAAcAAQCBAAAAEAAQAAFAAAAfgCpAK4AtAC2AL4AwwDKAM0A1QDaAN0A4wDqAO0A9QD3APoA/QEDAQ0BEQEpAWkBoQGwHvkgECAZIB0gJv//AAAAIACoAK4AtAC2ALwAwADIAMwA0gDZAN0A4ADoAOwA8gD3APkA/QECAQwBEAEoAWgBoAGvHqAgECAYIBwgJv///+P/uv+2/7H/sP+rAAAAAP+6AAD/vf/LAAAAAP/cAAD/9//f/+0AAP/m/+QAAAAAAAAAAAAA4ADg3uDc4NQAAQAAAAAAAAAAAAAAAAA0ADoAAAA8AAAAAAA+AEQAAABGAAAAAAAAAEYAAAAAAEQARgBIAEoATAAAAAAAAAAAAAAAagBrAG8AbQB7AHwAgACLAIwAkACOAKwArQCxAK8AvQC+AMIAzQDOANIA0AB1ALcAiQDLAJkA2wChAOMAmwDdAG4AsABsAK4AcQCzAHAAsgByALQAcwC1AHQAtgB3ALkAdgC4AHgAugB5ALsAegC8AH8AwQB9AL8AfgDAAIIAxACBAMMAgwDFAIQAxgCFAMcAiADKAIoAzACPANEAjQDPAJIA1ACRANMAkwDVAJQA1gCVANcAowDlAKIA5ACkAOYApQDnAKYA6ACaANwAmADaAJ0A3wCcAN4AngDgAJ8A4QCgAOIApwDpAKsA7QCpAOsAqgDsAAYCBgAAAAAA/gABAAAAAAAAAAAAAAAAAAAAAQADAAAAAAAAAAIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAAAAwAEAAUABgAHAAgACQAKAAsADAANAA4ADwAQABEAEgATABQAFQAWABcAGAAZABoAGwAcAB0AHgAfACAAIQAiACMAJAAlACYAJwAoACkAKgArACwALQAuAC8AMAAxADIAMwA0ADUANgA3ADgAOQA6ADsAPAA9AD4APwBAAEEAQgBDAEQARQBGAEcASABJAEoASwBMAE0ATgBPAFAAUQBSAFMAVABVAFYAVwBYAFkAWgBbAFwAXQBeAF8AYABhAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABiAGMAAAAAAAAAAABkAAAAAAAAAAAAAABlAAAAZgAAAAAAAAAAAAAAZwBoAGkAAABqAGsA7ADtAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAO4AAADvAPAAAAAAAPEAAEABACx2RSCwAyVFI2FoGCNoYEQtQCkXFxYWFRUUFBMTEhIRERAQDw8ODg0NDAwLCwoKCQkICAMDAgIBAQAAAY24Af+FRWhERWhERWhERWhERWhERWhERWhERWhERWhERWhERWhERWhERWhERWhERWhERWhERWhERWhERWhERWhEswUERgArswcGRgArsQQERWhEsQYGRWhE/mr/8QNxBPQAqwHJAEsAYQCEAEgBFgGhAhgB2ADjAxYBgQG3A54C/APxAVIDJQJYWnJaclpyWnIABAAGAAAIQAhACEAIQAhqCIAIugkMCW4JvAnMCeoKCAooCkIKUgpgCm4KfgqqCr4K6AssC0wLegu8C9IMIAxkDHoMkAykDLgMzg0GDYYNsA3oDhgOPA5UDmwOpA6+DswO6g8GDxYPNA9MD3wPpA/iEAwQThBiEIQQmhC8ENwQ9hEQES4RPBFaEW4RfBGKEcgR+hIoEloSkhK2EvgTHBM8E2QTfhOME8QT6BQeFFAUghSgFN4VABUkFToVWhV6FagVwhX2FgIWOBZUFlQWohbsFuwXCBcIFwgXCBc6F2wXtBfwGCoYYBicGNoZLhl2GbwaABpKGpQa9htMG6AbwBvgHBgcRBxuHJIcvBzoHSodYh2WHaodwB3sHgweKh5iHpoe6h8sH2wfqB/qIC4giCDWISIhSiF0IbQh6CIaIlQilCLWIy4jeiPEJBAkZCS4JSQlgiXeJf4mHiZWJoImrCbwJzYnkifiKDAoeijKKRwphCngKjoqkirwK04rxCwuLJYs1C0ULWottC38Lj4uiC7SLzQvii/eL/IwCDA0MFQwhDDCMQAxVjGgMegyKjJyMrwzHDNwM8Iz7DQYNFo0kDTENQA1RDWINeQ2NDaCNtA3JDd6N+Y4RjikONo5EDleOaA56DnoOeg56DnoOeg56DoWOkw6WjpqOoA6ljq0AHEALf6ME04H/QAQAB4AKgA5AE8AYwBsAH8AkwCsAMYA1QDnAQgBKAE+AV4BdwGCAY0BmAGcAa8ByAHaAegB+AIMAhsCHwItAjsCSgJSAl4CbgKAApoCvgLNAtoC5gLzAvsDAAMGAw4DFwMjAycDLAM6A04DUgNgA2QDaANsA3oDjgOqA8ED1APnA/YEDAQQBBQEGAQjBC8ENgRCBE4EWgReBGIEdgR6BIEEhwSMBKYErQS3BMgE6ATtBPoFEgUWBScFPAVIBVkFbAWBBZUFqQW8BcwF7QXzBfcGCwYPBhMGHwYmBiwGOQZFBlAAAAEzFhUUByM0PwEmJyMiByM2BRcUByMnByc2OwEXMzIFMxUjFTMVIxUHIxElMxcVMxUjFQcjNSM1MzUlMxcVMzY7ATIfARUjNTQrASIdASMRJTMXFRYzNj0BNzMVFAcGIyInJjU3MxUjESMRIzU3MxYXMzczESM1IwcjIi8BIxUjATMRIyc1NycGIyIvATU0PwEyFzMlMxcVIxUjNQYjJj0BMxUUHwEzMj8BNTM1JRUjFSM1IwYjIi8BNTMVFB8BMzI9ATMyNTcFMhcWFxQPASInJj0BNDchMzIXFSM1NCsBIh0BIzUzFTYhMzIXIyYrAQYVBxY7ATI3MzczFzcXNxcGIyIvATU0NzYhMzIXFSM0KwEiBxUUFxYVFA8BJjUzFBczMjc0JyY1NCUyFxYdASM1NCsBIgcVIzUjNzUzFTYhMzIXNSc3MxUUDwEjIiczFhczMjc2NyMGIyInJic0NwUzFRY7ATI9ATMVIyczJzU3NSMUByMiLwEFFjsBNj0BJisBIgUWOwEyNzQnIyIHBRY7ATY1NCcjBhUFMxUjBRYdARQHIzQ3NTQnIwYVIzU0NwUyFyMmIyIHBhUUHwEyNzMGIyInJjU0NzYhMhcWHQEUBwYjIicmPQE0NzYFMxczMjcXBisBJwcnNgUzMhcWFQYjFRYdARQPASMBMxUWMzI/ATU3MxcVFAcGIyIvATczMhczNTMXESMmJyMVIwEzESMBMzIXFh8BFRcUBwYrAQEzFSMVMxUjFRczFSMRBRUUHwEyPwE1NCcmJyIHJRUzMjU3JiMhFRcVMj8BNTQnJiMFMzIXNTMVIzUGIyIvATQ3JTMyFxUjNTQrASIHFSM1MxU2ITMyFzUzFRQHIyInMxY7ATI3BiMiLwE1NDclMzIXMzY7ATIXFh0BIzU0LwEjIgcVIzU0KwEiBxUjNTMVMzYlMhc1MxUjNQYjIi8BNDcFFBczMj8BNSYrASIHBRQfATMyNzUmKwEiBRUWOwE2PQE0LwEjBgUVFDMyNTQnARcHJiclFxQHJzYFMxcjJwcjNiEzFyMnIxQHIyUzFh8BNj8BMxUDIwEzFSM3MxcRIwEzFxUzFSMVIzUjNTM1NzMVMzY7ATIfARUjNTQrASIdASMTMxUjJTMXFTMVIxUjNSM1MzU3MxEjATMRIwEzFSMFMzIfARUUDwEiLwE0NyUzMhcWHQEjNSYrASIHFSM1MxU2ITMyFzM1MxUUDwEjIiczHwEzMjcGIyInJic0NyUzMh8BByMWMxcyNzMVBiMiLwE1NDc2ITMyFzM1MxUjNSMGIyIvATU0NyUzMhcHFRQHBiMiJxUHIxEzFTYhMhc1MxUjNQYjIic0NzYFMxUWOwEyPQEzFSM1IxQHIyInJj0BNzMVIyUzFSMlMxUjJRUWOwEyNyYrAQYFFjsBMjc1JisBIgclMzUmKwEiBRY7ATI3NSYrAQYVBRY7ATI3NTQnIyIHBRYzMj8BNTQnIyIHBTMVIyUzFSMFMzIXFRQPASM0PwE1JisBIgcjNgUXBycFMxYXByY1JRcHIic2JRcHJzcFMxUXMxUjBxEjNQYjIi8BNDczMhc1JyM1MyUzFyMnByMlMzIXIycGFSM1JTMVIxEjJzU3NSc3JzcnIzUlMxUXBxUXBxUXFQcXMzY7ATIXFh0BIzU0KwEiHQEjESUzFxUjJTMVNzMHFxUjJicVIwEVNjMyFxYdASM1NCsBIgcVIxEnNTcnNzsBFSMlMxU2OwEyHwEUBwYjIicVIwEzFTM2OwEyHwEVIzU0IycjIh0BIyUzFSMiHQEjNTMVNiEyFxUjNSYrASIdASM1MxU2ITIfAQYrARYzMjczBiMiJzU0NyUzMh8BFQcjFjsBMjczBiMiLwE0NyUzMhcWHQEjNTQnIyIHFSM1MxU2ITMyFzM1MxUjNSMGIyIvATU0NzYhMzIfARUjNTQnIyIHFSM1MxU2ITMyHwEUDwEiJxUjETMVNiEzMhc2OwEyHwEVIzU0KwEiBxUHIzU0JyMiHQEjNTMVNgUzFxUHIyUzFSMlMxUWOwEyPQEzFSM1IwYjIicmNSUzFSMlMxUjJRQXMzI3NTQnIyIHJTMmKwEiBwUzJisBIgUVFjsBNj0BNC8BIwYFFjsBMjc1JisBIgclFRQXMzI3JisBBg0XCiUgHBwCBQUJCAIeBvrwHSgTOwscCyALKgIK+gWOXllZBTECtSsGHh4GMRkZAdgqBAMXHwI6GQI0KgcrMwJIMQUKIywFMUIPFC8jDuufODU3v0cHTAJQSTYCSiwENhMDNwRzNC0FAwMdMUMhBVwXIxwD+VkkBC0wFyRZMxoSBhoNAzUFkB8vAg8qRBIDNBMVCSobBAP1k0QjCQNaID8mDGUBEANKCTMqBSw0Lh4B5wdIITwQGhE1AwwxCRYZKAIDAgIDAgIhTUwiBE0PBqECMRU0EAQOBUQePRdMNhsEEwVEIgRwNxYHNCgLIQc0AgIvGQEMBSgdAwMvVSEHRiI7GBUNFhUPBwMgKTknCgRX/dQ1BiIHLjMvAwMDAwQ5AzsZAvOnCjUHOw0uBToLdQ0wBToIMxYlEwLlCDkFOzsOOP5CNDT0xisgHB8HDAocIQkBXC48JSs3IApREiQnPSxeXTAKWh0BXTkuLlshHlkxDWId+qICLwMLDxISEQM2FBQS+gkTdgsZChQvRTZDByo1BicdDwMELQUoGCg3JAT/OwR2BDIEOh1gAzUBKDY2AvYImxMXGAQDUiNANwEamWdlZQRjnf3CTxNEHAM8DBtCHvUVCTYDCxIMIQJoEgIgGTX0uQUmITExJCxLGgVVASoDSgkzKgoiBTQvHAEGBS0aL2gQSiI7GhIONAwhKzwpB1UBiAIrEgIgJQQ5Fgg0FwwPIAQ0KwggBDYyAgYBoi8cLy8kKkocBlX7CT0ELREDDC0OKRIB9isSBS8QCy8MMgLZDyoOOiUSCkD6UQdNLwhvGDMSCfqUVRVXEgUzJjc2FRc2NgJBKDg2GAETNvVINAgnIgkZMDZwLAGoMzPDLgY0A8MtBB8fNRoacDQCFx8DORgDNCcKKjTvNDQBbCwGHR02GxvSNDQC0zQ0AWczM/U3BVMbA1UjTCMEXQEYBDUZBzYHHgomBDYxGgEMBC0SAzFZHAVJITQlDw4yCyEoPiQLAVYDTwJSHQICrA8eDh0UOSNJTSIBICICYwUpHQIvLwIjKkceBVQBMgdYEwJCFRkiHgUxMR8B3iwfMTEjKlwQSQ/zeTIDJwUsNC8FOAM3GwTxMzMF4TQ0BnQzM/T4DS4EOwcNLgs7Ae8PLAswCw0uDicRAzJ6ECsHIwIjDTAFNA0KLxA4AQsMMQMyDzEWLwsBxQo4KxICNBIqEf1ZMzMC0TMz+oQEIwgYChwcAwMGCggBHgb7gTQaNPtwBEsKFFgMVVYSClEPBEgTWxRc8tIzBQ4OBS4iL0geA2UOISEGKzEBFCg4NRcXNQTBIQwzNhcTOvYaoDgyBAICAgICAjYCji8CAgICAgICAxEiAzUYBzQoCCs0AlsvBTQCsjRGPk5aRgpANAEcGB05Fwo2KQsfBjUBAQEB8DMzArIzGykDSx4FQB4TKR8vBGc0AhcfAzwWAjQgCgwlNPCWAwUqNS8SAQtHDzMGIwYtNDIZA85IIQUCBakRLRgYOSFLUh9ZBKAFTR4DA6oSIwwVFTsiR1QfAlsBGQQ2GAc2IwsmBTYyGQJyBigeAi8vAiIsRx4ETQsBJAQ+FAM2JgkmBDYxGgGBAUoeBFQZKRs0Lx4CcAUiHRsqBjgXBjQnByMGBTAfESgzLxbvHzEFBTEDqjQ0AWA0BCcELDQvBQwvNBsFAykzMwgJMzPykjMMNgw2ESYUAWl6EiMHKxMEiXoVIQcuAkYKMwVAJhIOPAEADjALKRIIMBEvDAJiOwkyCw0tDzgH/QoqDC0YHgoNAhMxHR8QDgwMGR0LEjxLO4EFAUMFBU40vAXBNE4FBV4YRyePc1BWbQFDBQXeMwc01gXYVRsINxgh4Dz+9AEMNwUE9/v+uPLytjzyAUj+uAULAg4oWycDXh8DIDcGMd0XHw5TnGhPBwUkGoUZBjfdGSFOHZJ4MhIHRX4cAxdNEiRYJwNJFh4KXiBlmHdMTHf1FR1ZHw4vD0UbAwMDAwMHUV4kA1UjCDwOEA0NCRoTKDoWAwxHFAUXFhYbIEILPxIvfXBTNo0FAu4VHSgSAwvQYSMEUBYBFg0nKEYSLVglBYg7XWb1CgMFAgMXCEtVIUUOMw9BSUhLMRU5EEgMPD0MEC6lOaELJgQRKxkgBwwDBA8GIAw8YypEFhlOIAEnYXAfH2E3Dy8zQBRZOQ1lIRsSYjULAgsLJBMKByQQAxoaJDkGFysSPxkFAUjZPSceywYGq3YPGkw2zu3tBv6+ML7uAUj+uAFIKAtAJAsCXjcPAUg8SzlKBTkBQpkKTCABVhQPPSEIA1NLQxwOGc4DAkwPHSIiFw8oIPUgKGEkWSQDZpeAQz6F9RUdKCDbXx9SGU0qUSwQTyYDJSU3GRSZiiwLAkGCiDs5ivUVGAUqIvUgKFwpWiOLMA0uDxY+ORAwFAQ5F0FGDj0MNAstFAUIK1IFLSII/nMcNwwOHzYPGzYpITwaGjw8GgUVNASFbghckwL+ugFINjYF/r0BSAVONMHBNE4FYhdHJpBzUVdtAUg2NgVONMHBNE4F/rgBSP64AUg2FWYXC1MlBWEgYSECPBk4cJIyOYv1FR0nH85mIQNRFANIJ0wXJVUmAmgZGy0DFgNMYRwIMSgnJx/1HydZJA5WIgKAAQ9BKQsgYwUBRRwkJx/1HyeEVCUICIg8V231GBcJRCNAUQX19fX19YMQQkxHEEFCSwFHOQoCLU9EPwxIDjEMSDwWKxZICUIwDxA2DjysNDQ0iDICEBkRGR8CAhMTMhE8EzQKMAwlMQknOic3JAMqNCc6GhMFJAX+6R8oaRpmHSE7BSQQPRsbPT0bFQYEMTz+9AX1AwICAwIDAzYGSQIDAwIDAwICAwMYOhEZmX9EVm0BQgYGMTfGc3Z9AhZdcwFIYxg4Ezp4hT43jAE6AwMCAwM3N2whXiVLLQsoHwFIYxhKKYpvUgJQc/06OYr1FR1Xpog7VG/1FR1eJxgvFU9pJVEkA2EaFQ0vFU9mHV0jAzwZOW+KMAk5ivUVHSgg9R8oWiUMUiMGTlRbijAJNI/1FR1dKFgmAyJqAUYdJSUlQjOIekkyjAWMKg1NdvUVHQgG6gX19fWIPFFz9RghPwwWnfX19Xo1FEIKNRE5Ci8sAy8+C0kIPwUtFAUOP0U8DUlJCxYvD0xGEQAAAAIAAP/pAYUGVgALABcAAAEDBisBIjUDNDMhMgMUBiciJjU0NjMeAQGFUgIC4wRIBAF9BBZhVlZgYlRUYwZS+3UEBASLBPpeWHMDclZWcwJxAAAAAAIAAAR5Am0GQgADAAcAAAkBIxMjAyMTAm3+9ZOXQZKTHwZC/jcByf43AckAAgAAAKgD6QVSABsAHwAAAQcjAzMHIwMjEyEDIxMnNzMTIzczEzMDIRMzAwchAyED6Sh9RHspfVCkUv7wUKZQfSt7SIEpgU+mUgERUqZUzf7vQwEOBCGe/vie/ssBNf7LATMCngEGngEz/s0BM/7PoP76AAAEAAD/MQOoBw4AMQAyADMANAAAASYjIgcGFRQXFhcWFxYVFAcGBxUjNwYjIicRHgEzMjc2NTQnLgEnJjU0NzYlNTMVNhclIxMDkaNtPTA3QFhYZjNCi2+BcwIkJ6TNNbdPSCs3Oye4J5g4bAEKc5jM/isCAgSFVh0gOjszRENUTGB/xZp4JcO4BEIBrDNIHyc9RDUnfSOHzXhr0S2+rAY7I/mZAAUAAP/dBXcGYgAPABMAIgAwAEAAAAEUBwYjMSInJjU0NzYzMhYlASMJARQHBiMiJyY1NDc2MzIWARAjIgcGFRQXFjMxMjYBNCMiBwYHBhUUFxYzMTI2AqIvUNmyWT8lTuGgrgJo/DzPA8YBOi9Q2bJZQSVM5aCu/DVePBQKEhc1Ky8C1V4PBDUOBBIXNSsvBK64Y6OHYsemWsLTsPnFBjv7XblgpodlxqRcw9MCKQEAazladUFKb/1//gMQfy09d0BJbgABAAD//AUGBkYAMgAAASMCBwYjIicmJyY1EDcmJyY1NDc2NzYzMhcRJiMiBgcGFxYzMjcRJiMiBwYWMzI3NichBQZkIb6m6rKTmjMh+F4yKw0neITGhZ6BZE5cBgs+QWsvNWBMuhMMf1qgPzgVAZoCTv7VnolQUoFQYgEfbiNkVm09ModQWCn+lz5EL0AzOQz+yxuMWHmvl/YAAAABAAAEeQE5BkIAAwAAAQMjEwE5ppMzBkL+NwHJAAAAAAEAAP9SAV4G8AAPAAAFIyYnJjURNDc2NzMGFREUAV7ZKysvLysr2UWuIVJaRQV5RFxSIUzF+oPEAAAAAAEAAP9SAV4G8AAPAAAlFAcGByM2NRE0JzMWFxYVAV4tKyvbRkbbKystZEVaUiFMxAV9xUwhUlxEAAAAAAEAAALhAz8GKQARAAABBxcHJxUjNQcnNyc3FzUzFTcDP87KaMvTz2bNzWbP088E/Hd3tnnw7ne2d3e2d+7udwABAAABjwMjBLIACwAAASERIxEhNSERMxEhAyP+18/+1QErzwEpArr+1QErzQEr/tUAAAAAAf/L/1ABWgFxAAMAAAEDIxMBWq7hNQFx/d8CIQAAAAABAAACugKwA4cAAwAAASE1IQKw/VACsAK6zQAAAQAAAAABWgFvAAMAACkBESEBWv6mAVoBbwAAAAEAAP9IArwG+AADAAAJASMBArz9x4MCPQb4+FAHsAAAAgAA/+UE2wZcAA0AFgAAARAHAiEgJyYREDcSISABECMiERAzMTIE21iR/m7+tJd9d5kBZQJm/jyvpa6mAyn+prb+zPrNAWIBfcsBBvzDAd/+J/4hAAAAAAH/7AAAAckGQgAIAAApAREjNjc2NyEByf5xTjURKwIBagSBeS2FlgABAAAAAAPXBk4AGAAAKQEDNhM2NTQjIgcRNjMyFxYVFAcGBwYHIQPX/GtC8tVgza6TutHvkp6OcA1OSQG2ASPtARd9f7x/AY5gf4vPwdOoEG1JAAABAAD/8gOcBlAAKgAAARYVFAcGBxYXFhUUBwIhIicRFjMyNjc2IyIHERYzMjc2Jy4BIyIHAzYzIANiDzw/ZYZFQD6R/oWgsqKBYm8CBNtMWDczaz88CgdmUnGHApyiAcYFGys0dGdsJSlkXXp7c/70MQGXVmFLnhYBQw45M0QvRkQBeSkAAAAAAgAAAAAEwQZCAAoADQAAASMRIREhAwEhETMhEQMEwbv+df3TTgIdAem7/brhATX+ywE1AToD0/xNAcv+NQAAAAEAAP/pA/AGQgAaAAABEAcGISInER4BMzI1NCEiBwMhESEVNjMgFxYD8KCy/raaujvFXub+6ZGOAgNC/iUzLwEdkW0CP/7+obNKAZA2RcLBLQOk/pnPBrKDAAAAAgAA/+EExQZiABoAJwAAARYVFAcGJyQnJhEQNxIFFhcRJiMgAzYzMhcWATQjIgcGFxYXFjMxMgS8CZyi/P63rJZ5wgGos6zDnv70K3XCt3+L/n+mTi8zAgI1MUamApw0Mf6osAQH8dUBWgEd2wFeBgI1/mp5/uFba3H+qOA2O29qPjUAAQAAAAAD1wZCAAYAAAkBIQEhESED1/5E/jsBtv30A9cE8PsQBM8BcwAAAAADAAD/5QSYBlwAGQAmADMAAAEUBwYjIicmNTQ2NyY1NDc2ISAXFgcGBx4BATQmIyIGFRQWMzEyNhM0JiMiBhUUFjMxMjYEmMOi3+Goy4N1y3OPAR8BHJR3AgTPdIT+WF9BQl5eQkFfEG1LTG1tTEttAbbrfWlrg+t31zZ07qx3lZN3mvd3ONcCSEJcXEI/X1/9mUpqakpMamoAAAAC//z/9gTHBmAAHQApAAABEAcCISInERYXFjMyNzY3BiMiJyYnJjU0ABcEFxYFJicmIzEiBxQzMjYEx3uw/mbn02aFbz9xVGAZhaq1i5MbBgE//gFMrJb+MwI3MkemAqpMZAMx/ubg/r9sAW9ILydETpdocnvDMTP8AVwEBvTXXm09Nd3hcAAAAgAAAAABWgNvAAMABwAAASERIREhESEBWv6mAVr+pgFaAgABb/yRAW8AAAAC//D/UAF/A28AAwAHAAABAyMTJSERIQF/ruE1AVr+pgFaAXH93wIhjwFvAAEAAAAAA9UEuAAGAAAhATUBEQ0BA9X8KwPV/VQCrAHl8gHh/pLs6wACAAABywJcA+cAAwAHAAABITUhESE1IQJc/aQCXP2kAlwDF9D95NEAAQAAAAAD1QS4AAYAAAkBES0BEQED1fwrAqz9VAPVAeX+GwFz6+wBbv4fAAACAAD/1wOsBlgAFgAjAAAAFRQHBgcVIRE2NzY1NCcmIyIHETYzMgMUBiMxLgE1NDYzMhYDrGpxrv66nko9IzVxqJG0y+46YFZWYGJUVGIFXNewmJ0xyQGiBFJBY1QoPHEBbWL6SFZzAnFWVnJyAAAAAgAo//AFygZSAEoAVQAAAQYHBgcGIyImNTQ/AQYjIiY1NDc2NzYzMhc2JyYjIgcTNjMyFxYHAwYVFDMyNzY3Njc2NRAhIAMGFRAFMjcXBiMkETQ3EgAhIBEUATQjMSIGFRQzMjYFpzd7Tm1eXkZaBAtfWnKUBhuFf5pJQBAIHWyeUj6bqqRUZCKUAhcxLTsrIyUf/if9oZEfAdVQUAJSZP3hH1ABvgFUAiH9ZkorR0wrRQMh/sV9QTxGOxESMzGSeB0fqGxnG0wOL1IBEz9DTqL9WgoIG0Jae3Bxj3MByf0tlnb+NwIOWhAEAhCBnAGHAar97YH+x0hELUhEAAAAAAIAAAAABGIGWgAMABUAACkBESERIRE0ABcWABUBETQmIyIGFREEYv5Y/t7+aAE38PQBR/5YUkFCTQEd/uMEP+IBOQIC/rjx/moBjURpa0L+cwAAAAMAAAAAA/gGQgANABYAHwAAARYHBiMhESEyBBcWBxYBLgErAREzFjYTLgErAREzMjYD8Aielc3+CAHsuAEQCg2ivP5dA002Ky04TBQESC9KUDNGAcvJhX0GQvi325F9AZ43UP7vAlL9/DVG/vxSAAABAAD/5QQjBlwAHQAAJQYjIicmJyYRNDc2NzYzMhcRJiMiBwYHBhcWMzI3BCOLv6SPnmKmWF65rMqikHl/mF5rAgJ1ZJqPZzFMPEF/1wFc+LvCbWZD/mJGY3DV0W9gUgACAAAAAATJBkIACAAQAAABAgApAREhIAABNCYrAREzIATHAv6d/rf95wIdAUsBYf5WjIV9fQERAx/+g/5eBkL+Wv6FyNr8ugABAAAAAAN1BkIACwAAKQERIREhFSERIRUhA3X8iwNt/iQByf43AeQGQv584/6L5wABAAAAAANoBkIACQAAASERIREhESERIQNo/ikBmP5o/m8DaAS8/o7+g/4zBkIAAAAB//r/4QS7BloAHwAAJQYlJCcmAwI3Njc2MzIXESYHBgcGBwYXFhcWNzUjESEEu/D+zf7Vua4GBqST8GJnquW2y5FZYgQCMz5/RV7QAlJqiQYH8+oBYgFG2cI2FkP+U6AUD25516p5jxUMKboBSAAAAQAAAAAEUAZCAAsAACkBESERIREhESERIQRQ/mz+1f5vAZEBKwGUAZr+ZgZC/N8DIQAAAAEAAAAAAY8GQgADAAApAREhAY/+cQGPBkIAAAABAAD/+ANgBkIADwAAARQHBiMiJxEWMzI3NjURIQNgqJfkqpNgnlg1PgGXAfz4jX9MAYleJytTBC4AAAABAAAAAARtBkIACgAAKQEBESERIREBIQEEbf4t/vf+bwGRAREBlf6QAkr9tgZC/ZkCZ/ztAAAAAAEAAAAAA3MGQgAFAAApAREhESEDc/yNAZEB4gZC+0MAAQAAAAAGiwZCAAwAACkBEQMhAxEhESEbASEGi/5n5v5x5f5oAp6qxgJ9BCP73QQj+90GQvxqA5YAAAAAAQAAAAAExQZCAAkAACkBAREhESEBESEExf5B/pL+aAH0ASkBqANo/JgGQv0EAvwAAv/6/+UFcwZcAAsAFQAAAQIHBiEkAwIAISAAARIhIgYXEgUxBAVxAqqw/qP9VAwGAWYBWAFZAWL+WAL+64eLAgQBDAEPAyH+cNPZBAM4AYsBsP5Q/nUBsOHP/lICAgAAAgAAAAAEYAZCAAoAEwAAAQIAKwERIREhMgABNCcmKwERMzIEXgT+y+is/m8COfgBL/5tMThuZWXTA8H+8/6a/rIGQv6R/uVzSFL96wAAAAAC//r++gVzBloAFgAgAAABAgUWMzI3EQYjIiQjIgc3JAMCACEgAAEQISIGFxIFMSAFcQL+4V4vRDtOYEX+8UVjaAL9vgoGAWYBWAFWAWX+WP7th4sCBAEMAREDH/34xRAY/sEhOx7VQQLyAY0Brv5Q/nUBsOHP/lICAAAAAgAAAAAEhwZCAA4AFwAAKQEDIxEhESEgFxYRFAYHAzQnJisBETMyBIf+Osln/m8COQEAlpmDarYvOGpjY80B0f4vBkKQlf7+jvpNAbxUNz7+cgAAAQAA/+UDqAZmACkAAAEmIyIHBhUUFxYXFhcWFRQHBiEiJxEeATMyNzY1NCcuAScmNTQ3NiU2FwORo209MDdAWFhmM0KLnv7ypM01t09IKzc7J7gnmDh/AVS2xASFVh0gOjszRENUTGB/xZqsQgGsM0gfJz1ENSd9I4fNeGvyFgw5AAAAAQAAAAAD+AZCAAcAAAEhESERIREhA/j+wv5x/tUD+AS++0IEvgGEAAEAAP/jBFoGQgARAAABFAcGJyYnJjURIREUMxY1ESEEWrCg4+GarAGTnpQBlQGy24FzAgJzf9cEkvvbnAKiBCEAAAAAAQAAAAAFEAZCAAYAAAkBIQEhGwEFEP5Q/if+eQG0x8AGQvm+BkL77QQTAAABAAAAAAcbBkIADAAACQEhCwEhASEbASEbAQcb/vP+CYyF/fr/AAGYdIcBz5R7BkL5vgMn/NkGQvx6A4b8jwNxAAAAAAEAAAAABS0GQgALAAAJAiELASEJASEbAQUt/o8Ba/4WpbX+IwF7/n8B47mhBkL9Avy8AeP+HQM7Awf+TQGzAAABAAIAAAVBBkIACAAACQERIREBIRsBBUH+Kf5v/ikB28fXBkL77/3PAjEEEf20AkwAAAAAAQAAAAAESgZCAAkAAAkBIREhAwEhESEESv26Ahv8MVACTP3tA+AEzfy+/nUBXgNaAYoAAAEAAP6cAgQHpgARAAABISImNRE0NjMhFSMiFREUOwECBP45FicnFgHH9BIS9P6cKxYIhxcrlBj4ThkAAAEAAP9cArwHDAADAAAFIwEzAryD/cd/pAewAAABAAD+nAICB6YAEQAAARQGIyE1MzI1ETQrATUhMhYVAgIlFv458hIS8gHHFiX+3RYrkxkHshiUKxcAAAABAAAELQRUBkIABgAAASELASEBMwRU/q7X2f6uAbzeBC0BBP78AhUAAQAA/4wEwAAAAAMAAAUhNSEEwPtABMB0dAAAAAEAAAUOAUwGQgADAAABIwMzAUyqovgFDgE0AAAC//b/+gOmBNMAGwAnAAApATUGIyImJzEmNzYzMhc0JyYjIgcRNjMyFxYVATUuAQcOARUUFhcWA6b+mmdqktANCn93sFRQDyl6x1KexsV5j/6YCT0jNUpKNVI7Qdmkwn11H2MQM14BOUZOXLr936AcJQICUjs8UgIEAAAAAgAA//4ECAZCABIAGwAAATEQBwYjIicVIREhETY3NjMyAAESIyIHFRYXFgQGlY66hUb+ogFeSl4ZGMkBCP6cAqiDHRuFpAJa/vywqExKBkL+PzEKAv6q/vIBF7PCtgICAAAAAAEABP/yAxsExwAbAAAlBiMgJyYRNDc2NzYzMhcRJiMiBwYHFBcWMzI3Axtnj/7tkX1ERYmBmHlqWlxqREoCUkhuZ0orObygAQS6ipNQTjT+yzVJVKCcVEc7AAAAAv/+//oEBgZCABIAGwAAKQEnBiMiJyYDMQIAMzIXFhcRIQE1JiMiExA3NgQG/qgERoO6j5YCAgEKyRkWXkwBXP6kHYOoAqaDQkiqsgEEAQ4BVgIKMQHB+7rCs/7p/ugCAgAAAAL/+v/yA/oEywAYAB8AAAEhFBcWMzI3EQYjICcmExI3NjcxNhcWERQlLgEnIgYHA/b9c1JJd8WFrsX/AJ66BgaylL78gXP+rgZeQD1eBwIEcT01df6uUpGuAVoBG6CBAgK0oP7vMcNHVwJZRwAAAAABAAAAAAKgBn8AFQAAASYjIh0BMxEjESERIxEzNTQ3NjMyFwKgLyNcf3/+oZOTZV6oTFYFTA5gQv7+/EoDtgECkpdQThAAAAAC//7+MQQIBMEAHwAoAAAlFAcGIyInER4BMzI3NicxNQYjIicmNxoBMzIXFhc1IQE1JiMmAwIzMgQIuKDnzY03tFxrQUoCbXTbgW8CAvjFGht/NwFe/qIdg6QCAqiDNfyNe14BYUhUNTxqGU7NsOcBDwFUAxA7Rf1EwrcC/un+7AAAAAABAAAAAAO+BkIAEwAAKQERNCYHBgcRIREhET4BMzIXFhUDvv6gUDNoFf6iAV4Rk1aWXnIDEkBIAgJ//OkGQv49GzNUadsAAAACAAIAAAGBBn8ADAAQAAABFAYjIiY1NDY3MTIWAyERIQGBZlhbZmZbWGYQ/qEBXwWsXHd3XFp3Ann5+gS4AAAAAgAA/jcCHQZ/AAsAFQAAARQGIyImNTQ2NzIWAwYHBgcDNjURIQIdZ1haZmZaWmUNAnJnl56yAV4FrFp5d1xadwJ5+nH6oIsbATEh7gRBAAABAAAAAAO+BkIACgAAKQEDESERIRETIQEDvv5pyf6iAV6qAXf+5QGc/mQGQv0IAW79+gAAAQAAAAABXgZCAAMAACkBESEBXv6iAV4GQgAAAAEAAAAABicEugAiAAApARE0JgcGFREhETQnJiMmBgcRIREhFT4BMzIXPgEzMhcWFQYn/p5QOHj+mSUgNDFOCP6iAV4TfUvPaymmXp9tewMQREQFBoP89gMQQichAkZE/O4EuEkgK5NBUFpqwwAAAAABAAAAAAO8BLoAEwAAKQERNCYjIgcRIREhFT4BFxYXFhUDvP6gTDNsF/6mAVoTh1KbYXoDFD5IhvzsBLhOIS8CBk5m0wAAAAACAAL/8ARKBMMAFAAhAAABFhUQBwYhMSInJhE0NzY3NjMyFxYDNCcmIyIGBxQWMzI2BAhChZ7++vygg0JFhX+Ul3+M2Ds3WFRtAm9UVncDk4mw/v6mwsSkAQKyh5BSTk5Q/jGPVlCojYeopgACAAD+QgQIBLoAEwAcAAABEgAjIicxJicRIREhFTY3NjMyEgEQIyIHFRYzMgQGAv70yRYXYkb+ogFeM4MdG8by/qCogxsdgagCb/7v/pwECjH+CQZ2STkQAv6//uUBF7nCsgAAAv/+/kIEBgS6ABMAHAAAAREhEQYHMQYjIgATGgEzMhcWFzURNSYjIgMCMzIEBv6iSGAWF8n+9AIC8sQdHYUxHYOkAgKogwS4+YoB9zEKBAFkAREBCgFBAhA5Sf1Cwrn+6f7qAAEAAAAAAm8EvgAOAAABJgcGBwYVESERIRU+ATcCb2NJQBYP/qIBXiWeTgNvBisjRC9c/agEuHk0SQIAAAEAAP/wAs0E2QAmAAABJgcGFRQXFhcWFxYVFAcGIyInER4BMzI3NjU0JyYnJjU0NzYlNhcCvJdWYDFDREwpMWt5zn2eJ49ANR8rL0aDdStjAQSLlwNvSQwOSisnMzNAOUpglHKDMQFDJTcXHC8yKy9mZZ1aUrcQCCsAAAABAAD/+AKDBi8AFAAAJQYjIiY1ESMRMzUlETMRIxEUMzI3AoNWTqbAeXkBYpaWViExCBCimQJ9AQj4f/6J/vj91WIOAAEAAP/4A8EEuAATAAApATUOAScmJyY1ESERFBYzMjcRIQPB/qMUj1SQZncBYE4zaxYBX0wjMQICYG+2Azf8+EFQjwMKAAAAAAEAAAAABBQEuAAGAAAJASEBIRsBBBT+2v45/tkBdZWYBLj7SAS4/O4DEgAAAQAAAAAF3QS4AAwAAAEDIQsBIQMhGwEhGwEF3cb+QWRt/kLJAWhZbAGFa1gEuPtIAsv9NQS4/SkC1/0pAtcAAAEAAAAABBQEuAALAAAJAiELASEJASEbAQQU/toBIP5/gY3+hQEx/ssBf49/BLj90f13AYX+ewJ5Aj/+ngFiAAABAAD+RAPDBLgAHQAABRQHBiMiJxEWMzI9AQ4BIyInJjURIREUFjMyNxEhA8Oqkt/jmpbVzhJ5TJ9rgwFkTjNpFgFfLclqXFYBQX+JYx8rXnXtAvr8+j9SjwMIAAH//gAAAz0EuAAJAAAJASERIQMBIREhAz3+awGJ/O4hAZz+gwMQA5b9lf7VAR8CYAE5AAABAAD+kwJ1B6oAIAAAASMiJjcTNiM1MicDJjY7ARUjIgYHAxQGBx4BFRMUFjsBAnVnyIwECwLLywILBJi8Z1o0SwILiWZugQtWM1L+k4TEAnWJjZYCaKagbz8t/SdMdRAMcU79AicxAAEAAAAAAGYGPwADAAAzIxEzZmZmBj8AAAEAAP6TAnMHqgAhAAABIhcTFgYrATUzMjY1EzQ2Ny4BNQM0JisBNTMyFxYHAwYzAnPJAgoEjcdmUjNUDH9xZooMTDVYZrtQSQQKBMsC2Yn9i8SEcTEnAv5OcQwQdUwC2S0/b1JOpv2YlgAAAAEAAAVOAoMGQgAOAAABFAcGJyYVIzQzMhYzMicCg3svsnuskzC8H0MCBkLYFAgzI1DVM0wAAAAAA//8APoEhwZaAAoAFAAsAAABAiUxJAMCACEgAAMSAiMiAhMSBQQnBiMiJyY1NDc2MzIXFSYjIgcUFxYzMjcEhQT9wf3ICgQBKQEdARwBKeUCsq6wtQQHAVoBXJI9VqZWTCdYzUo/NTmeAjMtRkEtA6z9TgQCAqwBSAFm/pr+uAEKASP+3f72/dUCAt8jcWCccVG3HboevF4zKyQABP/+APwEiQZcAAoAFAAhACgAAAECJTEkAwIAISAAAxICIyICExIFBCcjJyMVIxEhMhYVFAcnNisBFTMyBIcE/cH9yAoEASkBHQEcASnjArSurrcEBQFcAV5KzVottAEAc4drUgJgKytcA679TgIEAqwBSAFm/pr+uAEKASP+3f72/dMCAsnR0QLOg3SFTMZbtQAAAAEAXQAAA6EFmwAPAAABFSMRIxEjESMRLgE1NDYzA6F/UqZUrsvXsgWbRvqrBVX6qwLiCL2XncAAAwAAAAAEYgfDAAwAFQAZAAApAREhESERNAAXFgAVARE0JiMiBhURASMDMwRi/lj+3v5oATfw9AFH/lhSQUJNASmqovgBHf7jBD/iATkCAv648f5qAY1EaWtC/nMECAE0AAAAAAMAAAAABGIHwwAMABUAGQAAKQERIREhETQAFxYAFQERNCYjIgYVEQEDIxMEYv5Y/t7+aAE38PQBR/5YUkFCTQFkoqpUAR3+4wQ/4gE5AgL+uPH+agGNRGlrQv5zBTz+zAE0AAADAAAAAARiCFgADAAVACwAACkBESERIRE0ABcWABUBETQmIyIGFREDNjMyFhUUBwYHFSM1Njc2NTQnJiMiBwRi/lj+3v5oATfw9AFH/lhSQUJNBDpBXn4qLUSBPh0ZDhUtMi0BHf7jBD/iATkCAv648f5qAY1EaWtC/nMFuBlkVUY8PhQofgIgGiciEBcZAAADAAAAAARiB8UADAAVACUAACkBESERIRE0ABcWABUBETQmIyIGFRESMzI1MxQjIiYjIhUjNDMyBGL+WP7e/mgBN/D0AUf+WFJBQk3TH0GklzG5HDOslCwBHf7jBD/iATkCAv648f5qAY1EaWtC/nME9EruOTvXAAADAAD+TgRiBloADAAVACIAACkBESERIRE0ABcWABUBETQmIyIGFREBFAYjMSImNTQ2MzIWBGL+WP7e/mgBN/D0AUf+WFJBQk0BHVQ7PFRUPDtUAR3+4wQ/4gE5AgL+uPH+agGNRGlrQv5z/FQ5VFQ5PFRUAAMAAAAABGIHwwAMABUAHAAAKQERIREhETQAFxYAFQERNCYjIgYVEQEjJwcjEzMEYv5Y/t7+aAE38PQBR/5YUkFCTQHr23t72ejbAR3+4wQ/4gE5AgL+uPH+agGNRGlrQv5zBBG2tgErAAAAAAQAAAAABGIIsAAMABUAHAAgAAApAREhESERNAAXFgAVARE0JiMiBhURASMnByMTMwUjAzMEYv5Y/t7+aAE38PQBR/5YUkFCTQHr23t72ejbASqqovgBHf7jBD/iATkCAv648f5qAY1EaWtC/nMEEba2AStHATQAAAQAAAAABG0IsAAMABUAHAAgAAApAREhESERNAAXFgAVARE0JiMiBhURASMnByMTMyUDIxMEYv5Y/t7+aAE38PQBR/5YUkFCTQHr23t72ejbAdGiqlQBHf7jBD/iATkCAv648f5qAY1EaWtC/nMEEba2ASvt/swBNAAAAAAEAAAAAARiCRgADAAVABwAMwAAKQERIREhETQAFxYAFQERNCYjIgYVEQEjJwcjEzMTNjMyFhUUBwYHFSM1Njc2NTQnJiMiBwRi/lj+3v5oATfw9AFH/lhSQUJNAevbe3vZ6NtSOkFefiotRIE+HRkOFS0yLQEd/uMEP+IBOQIC/rjx/moBjURpa0L+cwQRtrYBKwE8GWRVRjw+FCh+AiAaJyIQFxkAAAAEAAAAAARiCOYADAAVABwALAAAKQERIREhETQAFxYAFQERNCYjIgYVEQEjJwcjEzM2MzI1MxQjIiYjIhUjNDMyBGL+WP7e/mgBN/D0AUf+WFJBQk0B69t7e9no2w8fQaSXMbkcM6yULAEd/uMEP+IBOQIC/rjx/moBjURpa0L+cwQRtrYBK9lK7jk71wAAAAAEAAD+TgRiB8MADAAVABwAKQAAKQERIREhETQAFxYAFQERNCYjIgYVEQEjJwcjEzMTFAYjMSImNTQ2MzIWBGL+WP7e/mgBN/D0AUf+WFJBQk0B69t7e9no2xlUOzxUVDw7VAEd/uMEP+IBOQIC/rjx/moBjURpa0L+cwQRtrYBK/cYOVRUOTxUVAAAAAMAAAAABGIHrQAMABUAJwAAKQERIREhETQAFxYAFQERNCYjIgYVERMzBgcGIyInJiczFhcWMzI3NgRi/lj+3v5oATfw9AFH/lhSQUJN/r0MOFSNhlY4C7wHEh0tLiATAR3+4wQ/4gE5AgL+uPH+agGNRGlrQv5zBSZlRmhpRWUkHCwsGwAAAAAEAAAAAARiCP0ADAAVACcAKwAAKQERIREhETQAFxYAFQERNCYjIgYVERMzBgcGIyInJiczFhcWMzI3NicjAzMEYv5Y/t7+aAE38PQBR/5YUkFCTf69DDhUjYZWOAu8BxIdLS4gEwSqovgBHf7jBD/iATkCAv648f5qAY1EaWtC/nMFJmVGaGlFZSQcLCwbQQE0AAAABAAAAAAEYgj9AAwAFQAnACsAACkBESERIRE0ABcWABUBETQmIyIGFRETMwYHBiMiJyYnMxYXFjMyNzYDMwMjBGL+WP7e/mgBN/D0AUf+WFJBQk3+vQw4VI2GVjgLvAcSHS0uIBNg+KKqAR3+4wQ/4gE5AgL+uPH+agGNRGlrQv5zBSZlRmhpRWUkHCwsGwF1/swAAAQAAAAABGIJegAMABUAJwA+AAApAREhESERNAAXFgAVARE0JiMiBhUREzMGBwYjIicmJzMWFxYzMjc2AzYzMhYVFAcGBxUjNTY3NjU0JyYjIgcEYv5Y/t7+aAE38PQBR/5YUkFCTf69DDhUjYZWOAu8BxIdLS4gE9A6QV5+Ki1EgT4dGQ4VLTItAR3+4wQ/4gE5AgL+uPH+agGNRGlrQv5zBSZlRmhpRWUkHCwsGwHZGWRVRjw+FCh+AiAaJyIQFxkAAAAEAAAAAARiCMUADAAVACcANwAAKQERIREhETQAFxYAFQERNCYjIgYVERMzBgcGIyInJiczFhcWMzI3PgEzMjUzFCMiJiMiFSM0MzIEYv5Y/t7+aAE38PQBR/5YUkFCTf69DDhUjYZWOAu8BxIdLS4gEz0fQaSXMbkcM6yULAEd/uMEP+IBOQIC/rjx/moBjURpa0L+cwUmZUZoaUVlJBwsLBvzSu45O9cAAAAABAAA/k4EYgetAAwAFQAnADQAACkBESERIRE0ABcWABUBETQmIyIGFRETMwYHBiMiJyYnMxYXFjMyNzYTFAYjMSImNTQ2MzIWBGL+WP7e/mgBN/D0AUf+WFJBQk3+vQw4VI2GVjgLvAcSHS0uIBMmVDs8VFQ8O1QBHf7jBD/iATkCAv648f5qAY1EaWtC/nMFJmVGaGlFZSQcLCwb91M5VFQ5PFRUAAAAAgAAAAADdQfDAAsADwAAKQERIREhFSERIRUhASMDMwN1/IsDbf4kAcn+NwHk/tGqovgGQv584/6L5wUQATQAAAIAAAAAA3UHwwALAA8AACkBESERIRUhESEVIQsBIxMDdfyLA23+JAHJ/jcB5N2iqlQGQv584/6L5wZE/swBNAACAAAAAAN1CFgACwAiAAApAREhESEVIREhFSEBNjMyFhUUBwYHFSM1Njc2NTQnJiMiBwN1/IsDbf4kAcn+NwHk/do6QV5+Ki1EgT4dGQ4VLTItBkL+fOP+i+cGwBlkVUY8PhQofgIgGiciEBcZAAAAAgAAAAADdQePAAsAGwAAKQERIREhFSERIRUhADMyNTMUIyImIyIVIzQzMgN1/IsDbf4kAcn+NwHk/n8fQaSXMbkcM6yULAZC/nzj/ovnBcZK7jk71wAAAAIAAP5OA3UGQgALABgAACkBESERIRUhESEVIQEUBiMxIiY1NDYzMhYDdfyLA23+JAHJ/jcB5P7VVDw7VFQ7PFQGQv584/6L5/1cOVRUOTxUVAAAAAIAAAAAA3UHwwALABIAACkBESERIRUhESEVIQMjJwcjEzMDdfyLA23+JAHJ/jcB5HHZe3vb6NsGQv584/6L5wUZtrYBKwAAAAMAAAAAA3UIsAALAA8AFgAAKQERIREhFSERIRUhAyMDMxMjJwcjEzMDdfyLA23+JAHJ/jcB5C2qovgQ2Xt72+jbBkL+fOP+i+cF/QE0/ei2tgErAAMAAAAAA+wIsAALAA8AFgAAKQERIREhFSERIRUhEwMjGwEjJwcjEzMDdfyLA23+JAHJ/jcB5HeiqlQQ2Xt72+jbBkL+fOP+i+cHMf7MATT96La2ASsAAAADAAAAAAPECRgACwAiACkAACkBESERIRUhESEVIQE2MzIWFRQHBgcVIzU2NzY1NCcmIyIHEyMnByMTMwN1/IsDbf4kAcn+NwHk/vg6QV5+Ki1EgT4dGQ4VLTItl9l7e9vo2wZC/nzj/ovnB4AZZFVGPD4UKH4CIBonIhAXGf4ktrYBKwADAAAAAAN1COYACwAbACIAACkBESERIRUhESEVIQAzMjUzFCMiJiMiFSM0MzIBIycHIxMzA3X8iwNt/iQByf43AeT+wB9BpJcxuRwzrJQsAYfZe3vb6NsGQv584/6L5wcdSu45O9f9y7a2ASsAAAAAAwAA/k4DdQfDAAsAEgAfAAApAREhESEVIREhFSEDIycHIxMzExQGIzEiJjU0NjMyFgN1/IsDbf4kAcn+NwHkcdl7e9vo2y1UPDtUVDs8VAZC/nzj/ovnBRm2tgEr9xg5VFQ5PFRUAAACAAAAAAGPB8MAAwAHAAApAREhJyMDMwGP/nEBjyuqofcGQk0BNAAAAgAAAAABjwfDAAMABwAAKQERIQsBIxMBj/5xAY8UoqpUBkIBgf7MATQAAAACAAAAAAGPCFgAAwAaAAApAREhATYzMhYVFAcGBxUjNTY3NjU0JyYjIgcBj/5xAY/+qTpBXn4qLUSBPh0ZDhUtMi0GQgH9GWRVRjw+FCh+AiAaJyIQFxkAAv9vAAAB6wePAAMAEwAAKQERIQIzMjUzFCMiJiMiFSM0MzIBj/5xAY+oH0GklzG6GzOslCwGQgEDSu45O9cAAAIAAP5OAY8GQgADABAAACkBESEDFAYjMSImNTQ2MzIWAY/+cQGPP1Q8O1RUOzxUBkL4mTlUVDk8VFQAAAP/+v/lBXMHwwALABUAGQAAAQIHBiEkAwIAISAAARIhIgYXEgUxBAMjAzMFcQKqsP6j/VQMBgFmAVgBWQFi/lgC/uuHiwIEAQwBD8mqovgDIf5w09kEAzgBiwGw/lD+dQGw4c/+UgICBSABNAAAAAAD//r/5QVzB8MACwAVABkAAAECBwYhJAMCACEgAAESISIGFxIFMQQLASMTBXECqrD+o/1UDAYBZgFYAVkBYv5YAv7rh4sCBAEMAQ86oapUAyH+cNPZBAM4AYsBsP5Q/nUBsOHP/lICAgZU/swBNAAAA//6/+UFcwhYAAsAFQAsAAABAgcGISQDAgAhIAABEiEiBhcSBTEEATYzMhYVFAcGBxUjNTY3NjU0JyYjIgcFcQKqsP6j/VQMBgFmAVgBWQFi/lgC/uuHiwIEAQwBD/5mOkFefiotRIE+HRkOFS0yLQMh/nDT2QQDOAGLAbD+UP51AbDhz/5SAgIG0BlkVUY8PhQofgIgGiciEBcZAAAAAAP/+v/lBXMHjwALABUAJQAAAQIHBiEkAwIAISAAARIhIgYXEgUxBAIzMjUzFCMiJiMiFSM0MzIFcQKqsP6j/VQMBgFmAVgBWQFi/lgC/uuHiwIEAQwBD9UfQaSXMbkcM6yULAMh/nDT2QQDOAGLAbD+UP51AbDhz/5SAgIF1kruOTvXAAP/+v5OBXMGXAALABUAIgAAAQIHBiEkAwIAISAAARIhIgYXEgUxBAMUBiMxIiY1NDYzMhYFcQKqsP6j/VQMBgFmAVgBWQFi/lgC/uuHiwIEAQwBD39UPDtUVDs8VAMh/nDT2QQDOAGLAbD+UP51AbDhz/5SAgL9bDlUVDk8VFQAA//6/+UFcwfDAAsAFQAcAAABAgcGISQDAgAhIAABEiEiBhcSBTEEEyMnByMTMwVxAqqw/qP9VAwGAWYBWAFZAWL+WAL+64eLAgQBDAEPRdl7fNro2wMh/nDT2QQDOAGLAbD+UP51AbDhz/5SAgIFKba2ASsAAAAABP/6/+UFcwiwAAsAFQAZACAAAAECBwYhJAMCACEgAAESISIGFxIFMQQTIwMzEyMnByMTMwVxAqqw/qP9VAwGAWYBWAFZAWL+WAL+64eLAgQBDAEPjaqi+AzZe3za6NsDIf5w09kEAzgBiwGw/lD+dQGw4c/+UgICBg0BNP3otrYBKwAABP/6/+UFcwiwAAsAFQAZACAAAAECBwYhJAMCACEgAAESISIGFxIFMQQBAyMbASMnByMTMwVxAqqw/qP9VAwGAWYBWAFZAWL+WAL+64eLAgQBDAEPATGiqlQM2Xt82ujbAyH+cNPZBAM4AYsBsP5Q/nUBsOHP/lICAgdB/swBNP3otrYBKwAAAAT/+v/lBXMJGAALABUALAAzAAABAgcGISQDAgAhIAABEiEiBhcSBTEEAzYzMhYVFAcGBxUjNTY3NjU0JyYjIgcTIycHIxMzBXECqrD+o/1UDAYBZgFYAVkBYv5YAv7rh4sCBAEMAQ9NOkFefiotRIE+HRkOFS0yLZLZe3za6NsDIf5w09kEAzgBiwGw/lD+dQGw4c/+UgICB5AZZFVGPD4UKH4CIBonIhAXGf4ktrYBKwAAAAT/+v/lBXMI5gALABUAJQAsAAABAgcGISQDAgAhIAABEiEiBhcSBTEEAjMyNTMUIyImIyIVIzQzMgEjJwcjEzMFcQKqsP6j/VQMBgFmAVgBWQFi/lgC/uuHiwIEAQwBD4YfQaSXMbkcM6yULAGD2Xt82ujbAyH+cNPZBAM4AYsBsP5Q/nUBsOHP/lICAgctSu45O9f9y7a2ASsAAAT/+v5OBXMHwwALABUAHAApAAABAgcGISQDAgAhIAABEiEiBhcSBTEEEyMnByMTMxMUBiMxIiY1NDYzMhYFcQKqsP6j/VQMBgFmAVgBWQFi/lgC/uuHiwIEAQwBD0XZe3za6NsjVDw7VFQ7PFQDIf5w09kEAzgBiwGw/lD+dQGw4c/+UgICBSm2tgEr9xg5VFQ5PFRUAAAAAgAA/+MEWgfDABEAFQAAARQHBicmJyY1ESERFDMWNREhJSMDMwRasKDj4ZqsAZOelAGV/meqovgBstuBcwICc3/XBJL725wCogQhTQE0AAACAAD/4wRaB8MAEQAVAAABFAcGJyYnJjURIREUMxY1ESEBAyMTBFqwoOPhmqwBk56UAZX+kqKqVAGy24FzAgJzf9cEkvvbnAKiBCEBgf7MATQAAAACAAD/4wRaCFgAEQAoAAABFAcGJyYnJjURIREUMxY1ESEBNjMyFhUUBwYHFSM1Njc2NTQnJiMiBwRasKDj4ZqsAZOelAGV/WE6QV5+Ki1EgT4dGQ4VLTItAbLbgXMCAnN/1wSS+9ucAqIEIQH9GWRVRjw+FCh+AiAaJyIQFxkAAAIAAP/jBFoHjwARACEAAAEUBwYnJicmNREhERQzFjURIQAzMjUzFCMiJiMiFSM0MzIEWrCg4+GarAGTnpQBlf4QH0GklzG5HDOslCwBstuBcwICc3/XBJL725wCogQhAQNK7jk71wAAAgAA/k4EWgZCABEAHgAAARQHBicmJyY1ESERFDMWNREhARQGIzEiJjU0NjMyFgRasKDj4ZqsAZOelAGV/mJUOztUVDs7VAGy24FzAgJzf9cEkvvbnAKiBCH4mTlUVDk8VFQAAAIAAP/jBJkGggAMACUAAAEUBiMxIiY1NDYzMhYHERQHBicmJyY1ESERFDMWNREzBhUUFjMyBJlBLi9BQS8uQT+woOPhmqwBk56U0QhaQRoGEi1BQS0uQkLB/DPbgXMCAnN/1wSS+9ucAqIEIRcbPlsAAAAAAwAA/+MEmQfDAAMAEAApAAABIwMzARQGIzEiJjU0NjMyFgcRFAcGJyYnJjURIREUMxY1ETMGFRQWMzICwaqi+AIsQS4vQUEvLkE/sKDj4ZqsAZOelNEIWkEaBo8BNP5PLUFBLS5CQsH8M9uBcwICc3/XBJL725wCogQhFxs+WwADAAD/4wSZB8MAAwAQACkAAAEDIxMBFAYjMSImNTQ2MzIWBxEUBwYnJicmNREhERQzFjURMwYVFBYzMgLsoqpUAqVBLi9BQS8uQT+woOPhmqwBk56U0QhaQRoHw/7MATT+Ty1BQS0uQkLB/DPbgXMCAnN/1wSS+9ucAqIEIRcbPlsAAAADAAD/4wSZCFgAFgAjADwAAAE2MzIWFRQHBgcVIzU2NzY1NCcmIyIHARQGIzEiJjU0NjMyFgcRFAcGJyYnJjURIREUMxY1ETMGFRQWMzIBuzpBXn4qLUSBPh0ZDhUtMi0C3kEuL0FBLy5BP7Cg4+GarAGTnpTRCFpBGgg/GWRVRjw+FCh+AiAaJyIQFxn+Xi1BQS0uQkLB/DPbgXMCAnN/1wSS+9ucAqIEIRcbPlsAAAMAAP/jBJkHjwAPABwANQAAADMyNTMUIyImIyIVIzQzMgEUBiMxIiY1NDYzMhYHERQHBicmJyY1ESERFDMWNREzBhUUFjMyAmofQaSXMbkcM6yULALnQS4vQUEvLkE/sKDj4ZqsAZOelNEIWkEaB0VK7jk71/6cLUFBLS5CQsH8M9uBcwICc3/XBJL725wCogQhFxs+WwAAAwAA/k4EmQaCAAwAGQAyAAABFAYjMSImNTQ2MzIWARQGIzEiJjU0NjMyFgcRFAcGJyYnJjURIREUMxY1ETMGFRQWMzICvFQ7O1RUOztUAd1BLi9BQS8uQT+woOPhmqwBk56U0QhaQRr+2zlUVDk8VFQG+y1BQS0uQkLB/DPbgXMCAnN/1wSS+9ucAqIEIRcbPlsAAAP/+v/lBXMGggAJABYALAAAARIhIgYXEgUxBAEUBiMxIiY1NDYzMhYHFhcWAwIHBiEkAwIAITIXBhUUFjMyA8sC/uuHiwIEAQwBDwEXQS4vQUEvLkElBQSxAgKqsP6j/VQMBgFmAViifANYPi0DIQGw4c/+UgICBKMtQUEtLkJCsgUF2P51/nDT2QQDOAGLAbAvERE8WAAABP/6/+UFcwfDAAkADQAaADAAAAESISIGFxIFMQQDIwMzARQGIzEiJjU0NjMyFgcWFxYDAgcGISQDAgAhMhcGFRQWMzIDywL+64eLAgQBDAEPyaqi+AI0QS4vQUEvLkElBQSxAgKqsP6j/VQMBgFmAViifANYPi0DIQGw4c/+UgICBSABNP5PLUFBLS5CQrIFBdj+df5w09kEAzgBiwGwLxERPFgAAAAABP/6/+UFcwfDAAkADQAaADAAAAESISIGFxIFMQQLASMTARQGIzEiJjU0NjMyFgcWFxYDAgcGISQDAgAhMhcGFRQWMzIDywL+64eLAgQBDAEPOqGqVAJIQS4vQUEvLkElBQSxAgKqsP6j/VQMBgFmAViifANYPi0DIQGw4c/+UgICBlT+zAE0/k8tQUEtLkJCsgUF2P51/nDT2QQDOAGLAbAvERE8WAAABP/6/+UFcwhYAAkAIAAtAEMAAAESISIGFxIFMQQBNjMyFhUUBwYHFSM1Njc2NTQnJiMiBwEUBiMxIiY1NDYzMhYHFhcWAwIHBiEkAwIAITIXBhUUFjMyA8sC/uuHiwIEAQwBD/5mOkFefiotRIE+HRkOFS0yLQKxQS4vQUEvLkElBQSxAgKqsP6j/VQMBgFmAViifANYPi0DIQGw4c/+UgICBtAZZFVGPD4UKH4CIBonIhAXGf5eLUFBLS5CQrIFBdj+df5w09kEAzgBiwGwLxERPFgAAAAABP/6/+UFcwePAAkAGQAmADwAAAESISIGFxIFMQQCMzI1MxQjIiYjIhUjNDMyARQGIzEiJjU0NjMyFgcWFxYDAgcGISQDAgAhMhcGFRQWMzIDywL+64eLAgQBDAEP1R9BpJcxuRwzrJQsAqRBLi9BQS8uQSUFBLECAqqw/qP9VAwGAWYBWKJ8A1g+LQMhAbDhz/5SAgIF1kruOTvX/pwtQUEtLkJCsgUF2P51/nDT2QQDOAGLAbAvERE8WAAE//r+TgVzBoIACQAWACMAOQAAARIhIgYXEgUxBAMUBiMxIiY1NDYzMhYBFAYjMSImNTQ2MzIWBxYXFgMCBwYhJAMCACEyFwYVFBYzMgPLAv7rh4sCBAEMAQ9/VDw7VFQ7PFQBlkEuL0FBLy5BJQUEsQICqrD+o/1UDAYBZgFYonwDWD4tAyEBsOHP/lICAv1sOVRUOTxUVAb7LUFBLS5CQrIFBdj+df5w09kEAzgBiwGwLxERPFgAAgACAAAFQQfDAAgADAAACQERIREBIRsBJyMDMwVB/in+b/4pAdvH12mqofcGQvvv/c8CMQQR/bQCTE0BNAAAAAIAAgAABUEHwwAIAAwAAAkBESERASEbAQMzAyMFQf4p/m/+KQHbx9fg96GqBkL77/3PAjEEEf20AkwBgf7MAAACAAIAAAVBCFgACAAfAAAJAREhEQEhGwEBNjMyFhUUBwYHFSM1Njc2NTQnJiMiBwVB/in+b/4pAdvH1/62OkFefiotRIE+HRkOFS0yLQZC++/9zwIxBBH9tAJMAf0ZZFVGPD4UKH4CIBonIhAXGQAAAgACAAAFQQePAAgAGAAACQERIREBIRsBAjMyNTMUIyImIyIVIzQzMgVB/in+b/4pAdvH14UfQaSXMbkcM6yULAZC++/9zwIxBBH9tAJMAQNK7jk71wAAAAIAAv5OBUEGQgAIABUAAAkBESERASEbAQMUBiMxIiY1NDYzMhYFQf4p/m/+KQHbx9deVDw7VFQ7PFQGQvvv/c8CMQQR/bQCTPiZOVRUOTxUVAAAAAP/9v/6A6YGQgAbACcAKwAAKQE1BiMiJicxJjc2MzIXNCcmIyIHETYzMhcWFQE1LgEHDgEVFBYXFhMjAzMDpv6aZ2qS0A0Kf3ewVFAPKXrHUp7GxXmP/pgJPSM1Sko1Uimqovg7Qdmkwn11H2MQM14BOUZOXLr936AcJQICUjs8UgIEBAQBNAAD//b/+gOmBkIAGwAnACsAACkBNQYjIiYnMSY3NjMyFzQnJiMiBxE2MzIXFhUBNS4BBw4BFRQWFxYTAyMTA6b+mmdqktANCn93sFRQDyl6x1KexsV5j/6YCT0jNUpKNVKWoqpUO0HZpMJ9dR9jEDNeATlGTly6/d+gHCUCAlI7PFICBAU4/swBNAAAAAP/9v/6A6YGywAbACcAPgAAKQE1BiMiJicxJjc2MzIXNCcmIyIHETYzMhcWFQE1LgEHDgEVFBYXFgM2MzIWFRQHBgcVIzU2NzY1NCcmIyIHA6b+mmdqktANCn93sFRQDyl6x1KexsV5j/6YCT0jNUpKNVKmOkFefiotRIE+HRkOFS0yLTtB2aTCfXUfYxAzXgE5Rk5cuv3foBwlAgJSOzxSAgQFqBlkVUY8PhQofgIgGiciEBcZAAAD//b/+gOmBgIAGwAnADcAACkBNQYjIiYnMSY3NjMyFzQnJiMiBxE2MzIXFhUBNS4BBw4BFRQWFxYSMzI1MxQjIiYjIhUjNDMyA6b+mmdqktANCn93sFRQDyl6x1KexsV5j/6YCT0jNUpKNVIVH0GklzG6GzOslCs7Qdmkwn11H2MQM14BOUZOXLr936AcJQICUjs8UgIEBK5K7jk71wAAA//2/k4DpgTTABsAJwA0AAApATUGIyImJzEmNzYzMhc0JyYjIgcRNjMyFxYVATUuAQcOARUUFhcWExQGIzEiJjU0NjMyFgOm/ppnapLQDQp/d7BUUA8pesdSnsbFeY/+mAk9IzVKSjVSN1Q7PFRUPDtUO0HZpMJ9dR9jEDNeATlGTly6/d+gHCUCAlI7PFICBP3ROVRUOTxUVAAAA//2//oDpgZCABsAJwAuAAApATUGIyImJzEmNzYzMhc0JyYjIgcRNjMyFxYVATUuAQcOARUUFhcWASMnByMTMwOm/ppnapLQDQp/d7BUUA8pesdSnsbFeY/+mAk9IzVKSjVSAR3Ze3vb59s7Qdmkwn11H2MQM14BOUZOXLr936AcJQICUjs8UgIEBA22tgErAAAAAAT/9v/6A6YHJwAbACcAKwAyAAApATUGIyImJzEmNzYzMhc0JyYjIgcRNjMyFxYVATUuAQcOARUUFhcWASMDMxMjJwcjEzMDpv6aZ2qS0A0Kf3ewVFAPKXrHUp7GxXmP/pgJPSM1Sko1UgFcqqL4Fdl7e9vn2ztB2aTCfXUfYxAzXgE5Rk5cuv3foBwlAgJSOzxSAgQE6QE0/fC2tgErAAAE//b/+gQnBzEAGwAnACsAMgAAKQE1BiMiJicxJjc2MzIXNCcmIyIHETYzMhcWFQE1LgEHDgEVFBYXFgEDIxsBIycHIxMzA6b+mmdqktANCn93sFRQDyl6x1KexsV5j/6YCT0jNUpKNVICAKKqVBXZe3vb59s7Qdmkwn11H2MQM14BOUZOXLr936AcJQICUjs8UgIEBif+zAE0/ea2tgErAAAAAAT/9v/6A/8HmQAbACcAPgBFAAApATUGIyImJzEmNzYzMhc0JyYjIgcRNjMyFxYVATUuAQcOARUUFhcWEzYzMhYVFAcGBxUjNTY3NjU0JyYjIgcTIycHIxMzA6b+mmdqktANCn93sFRQDyl6x1KexsV5j/6YCT0jNUpKNVKBOkFefiotRIE+HRkOFS0yLZzZe3vb59s7Qdmkwn11H2MQM14BOUZOXLr936AcJQICUjs8UgIEBnYZZFVGPD4UKH4CIBonIhAXGf4itrYBKwAAAAAE//b/+gOmB2cAGwAnADcAPgAAKQE1BiMiJicxJjc2MzIXNCcmIyIHETYzMhcWFQE1LgEHDgEVFBYXFhIzMjUzFCMiJiMiFSM0MzIBIycHIxMzA6b+mmdqktANCn93sFRQDyl6x1KexsV5j/6YCT0jNUpKNVJJH0GklzG5HDOslCwBjNl7e9vn2ztB2aTCfXUfYxAzXgE5Rk5cuv3foBwlAgJSOzxSAgQGE0ruOTvX/cm2tgErAAAABP/2/k4DpgZCABsAJwAuADsAACkBNQYjIiYnMSY3NjMyFzQnJiMiBxE2MzIXFhUBNS4BBw4BFRQWFxYBIycHIxMzExQGIzEiJjU0NjMyFgOm/ppnapLQDQp/d7BUUA8pesdSnsbFeY/+mAk9IzVKSjVSAR3Ze3vb59sCVDs8VFQ8O1Q7Qdmkwn11H2MQM14BOUZOXLr936AcJQICUjs8UgIEBA22tgEr+Jk5VFQ5PFRUAAAAA//2//oDpgYkABsAJwA5AAApATUGIyImJzEmNzYzMhc0JyYjIgcRNjMyFxYVATUuAQcOARUUFhcWEzMGBwYjIicmJzMWFxYzMjc2A6b+mmdqktANCn93sFRQDyl6x1KexsV5j/6YCT0jNUpKNVI9vQw4VI2GVjgLvAcSHS0uIBM7Qdmkwn11H2MQM14BOUZOXLr936AcJQICUjs8UgIEBRplRmhpRWUkHCwsGwAAAAAE//b/+gOmB2EAGwAnADkAPQAAKQE1BiMiJicxJjc2MzIXNCcmIyIHETYzMhcWFQE1LgEHDgEVFBYXFhMzBgcGIyInJiczFhcWMzI3NicjAzMDpv6aZ2qS0A0Kf3ewVFAPKXrHUp7GxXmP/pgJPSM1Sko1Uj29DDhUjYZWOAu8BxIdLS4gEwWqovg7Qdmkwn11H2MQM14BOUZOXLr936AcJQICUjs8UgIEBRplRmhpRWUkHCwsGy4BNAAAAAT/9v/6A6YHYQAbACcAOQA9AAApATUGIyImJzEmNzYzMhc0JyYjIgcRNjMyFxYVATUuAQcOARUUFhcWEzMGBwYjIicmJzMWFxYzMjc2AzMDIwOm/ppnapLQDQp/d7BUUA8pesdSnsbFeY/+mAk9IzVKSjVSPb0MOFSNhlY4C7wHEh0tLiATZviiqjtB2aTCfXUfYxAzXgE5Rk5cuv3foBwlAgJSOzxSAgQFGmVGaGlFZSQcLCwbAWL+zAAABP/2//oDpgfUABsAJwA5AFAAACkBNQYjIiYnMSY3NjMyFzQnJiMiBxE2MzIXFhUBNS4BBw4BFRQWFxYTMwYHBiMiJyYnMxYXFjMyNzYDNjMyFhUUBwYHFSM1Njc2NTQnJiMiBwOm/ppnapLQDQp/d7BUUA8pesdSnsbFeY/+mAk9IzVKSjVSPb0MOFSNhlY4C7wHEh0tLiAT3DpBXn4qLUSBPh0ZDhUtMi07Qdmkwn11H2MQM14BOUZOXLr936AcJQICUjs8UgIEBRplRmhpRWUkHCwsGwG8GWRVRjw+FCh+AiAaJyIQFxkAAAAE//b/+gOmBy4AGwAnADkASQAAKQE1BiMiJicxJjc2MzIXNCcmIyIHETYzMhcWFQE1LgEHDgEVFBYXFhMzBgcGIyInJiczFhcWMzI3PgEzMjUzFCMiJiMiFSM0MzIDpv6aZ2qS0A0Kf3ewVFAPKXrHUp7GxXmP/pgJPSM1Sko1Uj29DDhUjYZWOAu8BxIdLS4gEzcfQaSXMbobM6yUKztB2aTCfXUfYxAzXgE5Rk5cuv3foBwlAgJSOzxSAgQFGmVGaGlFZSQcLCwb5UruOTvXAAAAAAT/9v5OA6YGJAAbACcAOQBGAAApATUGIyImJzEmNzYzMhc0JyYjIgcRNjMyFxYVATUuAQcOARUUFhcWEzMGBwYjIicmJzMWFxYzMjc2ExQGIzEiJjU0NjMyFgOm/ppnapLQDQp/d7BUUA8pesdSnsbFeY/+mAk9IzVKSjVSPb0MOFSNhlY4C7wHEh0tLiATAVQ7PFRUPDtUO0HZpMJ9dR9jEDNeATlGTly6/d+gHCUCAlI7PFICBAUaZUZoaUVlJBwsLBv43DlUVDk8VFQAAAAD//r/8gP6BkIAGAAfACMAAAEhFBcWMzI3EQYjICcmExI3NjcxNhcWERQlLgEnIgYHASMDMwP2/XNSSXfFha7F/wCeugYGspS+/IFz/q4GXkA9XgcBHaqi+AIEcT01df6uUpGuAVoBG6CBAgK0oP7vMcNHVwJZRwIWATQAA//6//ID+gZCABgAHwAjAAABIRQXFjMyNxEGIyAnJhMSNzY3MTYXFhEUJS4BJyIGBwEDIxMD9v1zUkl3xYWuxf8AnroGBrKUvvyBc/6uBl5APV4HAYiiqlQCBHE9NXX+rlKRrgFaARuggQICtKD+7zHDR1cCWUcDSv7MATQAAAAD//r/8gP6BssAGAAfADYAAAEhFBcWMzI3EQYjICcmExI3NjcxNhcWERQlLgEnIgYHEzYzMhYVFAcGBxUjNTY3NjU0JyYjIgcD9v1zUkl3xYWuxf8AnroGBrKUvvyBc/6uBl5APV4HPDpBXn4qLUSBPh0ZDhUtMi0CBHE9NXX+rlKRrgFaARuggQICtKD+7zHDR1cCWUcDuhlkVUY8PhQofgIgGiciEBcZAAAAA//6//ID+gYCABgAHwAvAAABIRQXFjMyNxEGIyAnJhMSNzY3MTYXFhEUJS4BJyIGBxIzMjUzFCMiJiMiFSM0MzID9v1zUkl3xYWuxf8AnroGBrKUvvyBc/6uBl5APV4H8x9BpJcxuhszrJQrAgRxPTV1/q5Ska4BWgEboIECArSg/u8xw0dXAllHAsBK7jk71wAAAAP/+v5OA/oEywAYAB8ALAAAASEUFxYzMjcRBiMgJyYTEjc2NzE2FxYRFCUuASciBgcBFAYjMSImNTQ2MzIWA/b9c1JJd8WFrsX/AJ66BgaylL78gXP+rgZeQD1eBwE9VDs8VFQ8O1QCBHE9NXX+rlKRrgFaARuggQICtKD+7zHDR1cCWUf74zlUVDk8VFQAAAP/+v/yA/oGQgAYAB8AJgAAASEUFxYzMjcRBiMgJyYTEjc2NzE2FxYRFCUuASciBgcBIycHIxMzA/b9c1JJd8WFrsX/AJ66BgaylL78gXP+rgZeQD1eBwH+2Xt63OjbAgRxPTV1/q5Ska4BWgEboIECArSg/u8xw0dXAllHAh+2tgErAAT/+v/yA/oHJwAYAB8AIwAqAAABIRQXFjMyNxEGIyAnJhMSNzY3MTYXFhEUJS4BJyIGBwEjAzMTIycHIxMzA/b9c1JJd8WFrsX/AJ66BgaylL78gXP+rgZeQD1eBwI+qqL4FNl7etzo2wIEcT01df6uUpGuAVoBG6CBAgK0oP7vMcNHVwJZRwL7ATT98La2ASsAAAAE//r/8gREBzEAGAAfACMAKgAAASEUFxYzMjcRBiMgJyYTEjc2NzE2FxYRFCUuASciBgcBAyMbASMnByMTMwP2/XNSSXfFha7F/wCeugYGspS+/IFz/q4GXkA9XgcC4qKqVBTZe3rc6NsCBHE9NXX+rlKRrgFaARuggQICtKD+7zHDR1cCWUcEOf7MATT95ra2ASsABP/6//IEHAeZABgAHwA2AD0AAAEhFBcWMzI3EQYjICcmExI3NjcxNhcWERQlLgEnIgYHATYzMhYVFAcGBxUjNTY3NjU0JyYjIgcTIycHIxMzA/b9c1JJd8WFrsX/AJ66BgaylL78gXP+rgZeQD1eBwFjOkFefiotRIE+HRkOFS0yLZvZe3rc6NsCBHE9NXX+rlKRrgFaARuggQICtKD+7zHDR1cCWUcEiBlkVUY8PhQofgIgGiciEBcZ/iK2tgErAAAAAAT/+v/yA/oHZwAYAB8ALwA2AAABIRQXFjMyNxEGIyAnJhMSNzY3MTYXFhEUJS4BJyIGBwAzMjUzFCMiJiMiFSM0MzIBIycHIxMzA/b9c1JJd8WFrsX/AJ66BgaylL78gXP+rgZeQD1eBwE1H0GklzG5HDOslCwBgdl7etzo2wIEcT01df6uUpGuAVoBG6CBAgK0oP7vMcNHVwJZRwQlSu45O9f9yba2ASsAAAAE//r+TgP6BkIAGAAfACYAMwAAASEUFxYzMjcRBiMgJyYTEjc2NzE2FxYRFCUuASciBgcBIycHIxMzExQGIzEiJjU0NjMyFgP2/XNSSXfFha7F/wCeugYGspS+/IFz/q4GXkA9XgcB/tl7etzo2yZUOzxUVDw7VAIEcT01df6uUpGuAVoBG6CBAgK0oP7vMcNHVwJZRwIftrYBK/iZOVRUOTxUVAAAAAACAAAAAAFeBkIAAwAHAAApAREhJyMDMwFe/qIBXg6qovgEuFYBNAAAAgAAAAABXgZCAAMABwAAKQERIREDIxMBXv6iAV6iqlQEuAGK/swBNAAAAAACABIAAAGUBssAAwAaAAApAREhATYzMhYVFAcGBxUjNTY3NjU0JyYjIgcBcP6iAV7+zTpBXn4qLUSBPh0ZDhUtMi0EuAH6GWRVRjw+FCh+AiAaJyIQFxkAAv+PAAACCwYCAAMAEwAAKQERIQIzMjUzFCMiJiMiFSM0MzIBcf6hAV9qH0GklzG6GzOslCsEuAEASu45O9cAAAMAAv5OAYEGfwAMABAAHQAAARQGIyImNTQ2NzEyFgMhESEDFAYjMSImNTQ2MzIWAYFmWFtmZltYZhD+oQFfFVQ7PFRUPDtUBaxcd3dcWncCefn6BLj6IzlUVDk8VFQAAAMAAv/wBEoGQgAUACEAJQAAARYVEAcGITEiJyYRNDc2NzYzMhcWAzQnJiMiBgcUFjMyNgMjAzMECEKFnv76/KCDQkWFf5SXf4zYOzdYVG0Cb1RWd06qovgDk4mw/v6mwsSkAQKyh5BSTk5Q/jGPVlCojYeopgNBATQAAAADAAL/8ARKBkIAFAAhACUAAAEWFRAHBiExIicmETQ3Njc2MzIXFgM0JyYjIgYHFBYzMjYTAyMTBAhChZ7++vygg0JFhX+Ul3+M2Ds3WFRtAm9UVncGoqpUA5OJsP7+psLEpAECsoeQUk5OUP4xj1ZQqI2HqKYEdf7MATQAAwAC//AESgbLABQAIQA4AAABFhUQBwYhMSInJhE0NzY3NjMyFxYDNCcmIyIGBxQWMzI2ATYzMhYVFAcGBxUjNTY3NjU0JyYjIgcECEKFnv76/KCDQkWFf5SXf4zYOzdYVG0Cb1RWd/67OkFefiotRIE+HRkOFS0yLQOTibD+/qbCxKQBArKHkFJOTlD+MY9WUKiNh6imBOUZZFVGPD4UKH4CIBonIhAXGQAAAAMAAv/wBEoGAgAUACEAMQAAARYVEAcGITEiJyYRNDc2NzYzMhcWAzQnJiMiBgcUFjMyNgIzMjUzFCMiJiMiFSM0MzIECEKFnv76/KCDQkWFf5SXf4zYOzdYVG0Cb1RWd4UfQaSXMbobM6yUKwOTibD+/qbCxKQBArKHkFJOTlD+MY9WUKiNh6imA+tK7jk71wAAAAADAAL+TgRKBMMAFAAhAC4AAAEWFRAHBiExIicmETQ3Njc2MzIXFgM0JyYjIgYHFBYzMjYDFAYjMSImNTQ2MzIWBAhChZ7++vygg0JFhX+Ul3+M2Ds3WFRtAm9UVnc5VDs8VFQ8O1QDk4mw/v6mwsSkAQKyh5BSTk5Q/jGPVlCojYeopv0OOVRUOTxUVAAAAAADAAL/8ARKBkIAFAAhACgAAAEWFRAHBiExIicmETQ3Njc2MzIXFgM0JyYjIgYHFBYzMjYTIycHIxMzBAhChZ7++vygg0JFhX+Ul3+M2Ds3WFRtAm9UVneO2X172+nZA5OJsP7+psLEpAECsoeQUk5OUP4xj1ZQqI2HqKYDSra2ASsAAAAEAAL/8ARKBycAFAAhACUALAAAARYVEAcGITEiJyYRNDc2NzYzMhcWAzQnJiMiBgcUFjMyNhMjAzMTIycHIxMzBAhChZ7++vygg0JFhX+Ul3+M2Ds3WFRtAm9UVnfGqqL4HNl9e9vp2QOTibD+/qbCxKQBArKHkFJOTlD+MY9WUKiNh6imBCYBNP3wtrYBKwAEAAL/8ARYBzEAFAAhACUALAAAARYVEAcGITEiJyYRNDc2NzYzMhcWAzQnJiMiBgcUFjMyNgEDIxsBIycHIxMzBAhChZ7++vygg0JFhX+Ul3+M2Ds3WFRtAm9UVncBaqKqVBzZfXvb6dkDk4mw/v6mwsSkAQKyh5BSTk5Q/jGPVlCojYeopgVk/swBNP3mtrYBKwAABAAC//AESgeZABQAIQA4AD8AAAEWFRAHBiExIicmETQ3Njc2MzIXFgM0JyYjIgYHFBYzMjYDNjMyFhUUBwYHFSM1Njc2NTQnJiMiBxMjJwcjEzMECEKFnv76/KCDQkWFf5SXf4zYOzdYVG0Cb1RWdxU6QV5+Ki1EgT4dGQ4VLTIto9l9e9vp2QOTibD+/qbCxKQBArKHkFJOTlD+MY9WUKiNh6imBbMZZFVGPD4UKH4CIBonIhAXGf4itrYBKwAABAAC//AESgdnABQAIQAxADgAAAEWFRAHBiExIicmETQ3Njc2MzIXFgM0JyYjIgYHFBYzMjYCMzI1MxQjIiYjIhUjNDMyASMnByMTMwQIQoWe/vr8oINCRYV/lJd/jNg7N1hUbQJvVFZ3Qx9BpJcxuRwzrJQsAYnZfXvb6dkDk4mw/v6mwsSkAQKyh5BSTk5Q/jGPVlCojYeopgVQSu45O9f9yba2ASsABAAC/k4ESgZCABQAIQAoADUAAAEWFRAHBiExIicmETQ3Njc2MzIXFgM0JyYjIgYHFBYzMjYTIycHIxMzExQGIzEiJjU0NjMyFgQIQoWe/vr8oINCRYV/lJd/jNg7N1hUbQJvVFZ3jtl9e9vp2SNUOzxUVDw7VAOTibD+/qbCxKQBArKHkFJOTlD+MY9WUKiNh6imA0q2tgEr+Jk5VFQ5PFRUAAACAAD/+APBBkIAEwAXAAApATUOAScmJyY1ESERFBYzMjcRISUjAzMDwf6jFI9UkGZ3AWBOM2sWAV/+laqi+EwjMQICYG+2Azf8+EFQjwMKVgE0AAACAAD/+APBBkIAEwAXAAApATUOAScmJyY1ESERFBYzMjcRIQsBIxMDwf6jFI9UkGZ3AWBOM2sWAV/yoqpUTCMxAgJgb7YDN/z4QVCPAwoBiv7MATQAAAAAAgAA//gDwQbLABMAKgAAKQE1DgEnJicmNREhERQWMzI3ESEBNjMyFhUUBwYHFSM1Njc2NTQnJiMiBwPB/qMUj1SQZncBYE4zaxYBX/2jOkFefiotRIE+HRkOFS0yLUwjMQICYG+2Azf8+EFQjwMKAfoZZFVGPD4UKH4CIBonIhAXGQAAAgAA//gDwQYCABMAIwAAKQE1DgEnJicmNREhERQWMzI3ESEAMzI1MxQjIiYjIhUjNDMyA8H+oxSPVJBmdwFgTjNrFgFf/ncfQaSXMbobM6yUK0wjMQICYG+2Azf8+EFQjwMKAQBK7jk71wAAAgAA/k4DwQS4ABMAIAAAKQE1DgEnJicmNREhERQWMzI3ESEBFAYjMSImNTQ2MzIWA8H+oxSPVJBmdwFgTjNrFgFf/t5UOzxUVDw7VEwjMQICYG+2Azf8+EFQjwMK+iM5VFQ5PFRUAAACAAD/+AQCBPcADAAnAAABFAYjMSImNTQ2MzIWBxEhNQ4BJyYnJjURIREUFjMyNxEzBhUUFjMyBAJBLi9BQS8uQUH+oxSPVJBmdwFgTjNrFp0HXEMWBIctQUEtLkJCxfwQTCMxAgJgb7YDN/z4QVCPAwoXGkBcAAADAAD/+AQCBkIAAwAQACsAAAEjAzMBFAYjMSImNTQ2MzIWBxEhNQ4BJyYnJjURIREUFjMyNxEzBhUUFjMyAlaqovgCAEEuL0FBLy5BQf6jFI9UkGZ3AWBOM2sWnQdcQxYFDgE0/kUtQUEtLkJCxfwQTCMxAgJgb7YDN/z4QVCPAwoXGkBcAAAAAwAA//gEAgZCAAMAEAArAAABAyMTARQGIzEiJjU0NjMyFgcRITUOAScmJyY1ESERFBYzMjcRMwYVFBYzMgLZoqpUAiFBLi9BQS8uQUH+oxSPVJBmdwFgTjNrFp0HXEMWBkL+zAE0/kUtQUEtLkJCxfwQTCMxAgJgb7YDN/z4QVCPAwoXGkBcAAMAAP/4BAIGywAWACMAPgAAATYzMhYVFAcGBxUjNTY3NjU0JyYjIgcBFAYjMSImNTQ2MzIWBxEhNQ4BJyYnJjURIREUFjMyNxEzBhUUFjMyAWQ6QV5+Ki1EgT4dGQ4VLTItAp5BLi9BQS8uQUH+oxSPVJBmdwFgTjNrFp0HXEMWBrIZZFVGPD4UKH4CIBonIhAXGf5gLUFBLS5CQsX8EEwjMQICYG+2Azf8+EFQjwMKFxpAXAAAAAADAAD/+AQCBgIADwAcADcAAAAzMjUzFCMiJiMiFSM0MzIBFAYjMSImNTQ2MzIWBxEhNQ4BJyYnJjURIREUFjMyNxEzBhUUFjMyAjgfQaSXMbobM6yUKwKDQS4vQUEvLkFB/qMUj1SQZncBYE4zaxadB1xDFgW4Su45O9f+ni1BQS0uQkLF/BBMIzECAmBvtgM3/PhBUI8DChcaQFwAAAAAAwAA/k4EAgT3AAwAGQA0AAABFAYjMSImNTQ2MzIWARQGIzEiJjU0NjMyFgcRITUOAScmJyY1ESERFBYzMjcRMwYVFBYzMgKfVDs8VFQ8O1QBY0EuL0FBLy5BQf6jFI9UkGZ3AWBOM2sWnQdcQxb+2zlUVDk8VFQFcC1BQS0uQkLF/BBMIzECAmBvtgM3/PhBUI8DChcaQFwAAAAAAwAC//AESgT3AAwAGQAzAAABNCcmIyIGBxQWMzI2ARQGIzEiJjU0NjMyFgcWFxYVEAcGISInJhE0NzY3NjMyFxUUFjMyAuw8N1hUbQJvVFZ3ASBBLi9BQS8uQT8hGEKFnv76/KCDQkWFf5R5altDGAJWj1ZQqI2HqKYCui1BQS0uQkLEKzOJsP7+psLEpAECsoeQUk4yCz9cAAAABAAC//AESgZCAAwAEAAdADcAAAE0JyYjIgYHFBYzMjYDIwMzARQGIzEiJjU0NjMyFgcWFxYVEAcGISInJhE0NzY3NjMyFxUUFjMyAuw8N1hUbQJvVFZ3Tqqi+AHCQS4vQUEvLkE/IRhChZ7++vygg0JFhX+UeWpbQxgCVo9WUKiNh6imA0EBNP5FLUFBLS5CQsQrM4mw/v6mwsSkAQKyh5BSTjILP1wABAAC//AESgZCAAwAEAAdADcAAAE0JyYjIgYHFBYzMjYTAyMTARQGIzEiJjU0NjMyFgcWFxYVEAcGISInJhE0NzY3NjMyFxUUFjMyAuw8N1hUbQJvVFZ3BqKqVAISQS4vQUEvLkE/IRhChZ7++vygg0JFhX+UeWpbQxgCVo9WUKiNh6imBHX+zAE0/kUtQUEtLkJCxCszibD+/qbCxKQBArKHkFJOMgs/XAAAAAQAAv/wBEoGywAMACMAMABKAAABNCcmIyIGBxQWMzI2ATYzMhYVFAcGBxUjNTY3NjU0JyYjIgcBFAYjMSImNTQ2MzIWBxYXFhUQBwYhIicmETQ3Njc2MzIXFRQWMzIC7Dw3WFRtAm9UVnf+uzpBXn4qLUSBPh0ZDhUtMi0CZUEuL0FBLy5BPyEYQoWe/vr8oINCRYV/lHlqW0MYAlaPVlCojYeopgTlGWRVRjw+FCh+AiAaJyIQFxn+YC1BQS0uQkLEKzOJsP7+psLEpAECsoeQUk4yCz9cAAQAAv/wBEoGAgAMABwAKQBDAAABNCcmIyIGBxQWMzI2AjMyNTMUIyImIyIVIzQzMgEUBiMxIiY1NDYzMhYHFhcWFRAHBiEiJyYRNDc2NzYzMhcVFBYzMgLsPDdYVG0Cb1RWd4UfQaSXMbobM6yUKwJeQS4vQUEvLkE/IRhChZ7++vygg0JFhX+UeWpbQxgCVo9WUKiNh6imA+tK7jk71/6eLUFBLS5CQsQrM4mw/v6mwsSkAQKyh5BSTjILP1wAAAQAAv5OBEoE9wAMABkAJgBAAAABNCcmIyIGBxQWMzI2AxQGIzEiJjU0NjMyFgEUBiMxIiY1NDYzMhYHFhcWFRAHBiEiJyYRNDc2NzYzMhcVFBYzMgLsPDdYVG0Cb1RWdzhUOzxUVDw7VAFYQS4vQUEvLkE/IRhChZ7++vygg0JFhX+UeWpbQxgCVo9WUKiNh6im/Q45VFQ5PFRUBXAtQUEtLkJCxCszibD+/qbCxKQBArKHkFJOMgs/XAAAAgAA/kQDwwZCAB0AIQAABRQHBiMiJxEWMzI9AQ4BIyInJjURIREUFjMyNxEhJSMDMwPDqpLf45qW1c4SeUyfa4MBZE4zaRYBX/5/qqL4LclqXFYBQX+JYx8rXnXtAvr8+j9SjwMIVgE0AAAAAgAA/kQDwwZCAB0AIQAABRQHBiMiJxEWMzI9AQ4BIyInJjURIREUFjMyNxEhCwEjEwPDqpLf45qW1c4SeUyfa4MBZE4zaRYBX+qiqlQtyWpcVgFBf4ljHytede0C+vz6P1KPAwgBiv7MATQAAgAA/kQDwwbLAB0ANAAABRQHBiMiJxEWMzI9AQ4BIyInJjURIREUFjMyNxEhATYzMhYVFAcGBxUjNTY3NjU0JyYjIgcDw6qS3+OaltXOEnlMn2uDAWROM2kWAV/9oTpBXn4qLUSBPh0ZDhUtMi0tyWpcVgFBf4ljHytede0C+vz6P1KPAwgB+hlkVUY8PhQofgIgGiciEBcZAAAAAgAA/kQDwwYCAB0ALQAABRQHBiMiJxEWMzI9AQ4BIyInJjURIREUFjMyNxEhADMyNTMUIyImIyIVIzQzMgPDqpLf45qW1c4SeUyfa4MBZE4zaRYBX/51H0GklzG6GzOslCstyWpcVgFBf4ljHytede0C+vz6P1KPAwgBAEruOTvXAAAAAgAA/kQD4AS4AAwAMQAAARQGIzEiJjU0NjMyFgUGIyInERYzMj0BDgEjIicmNREhERQWMzI3ESERFAcmIyIGFRQD4FQ7PFRUPDtU/tt2neOaltXOEnlMn2uDAWROM2kWAV8LKzhObP7bOVRUOTxUVKYtVgFBf4ljHytede0C+vz6P1KPAwj7GzItHWxNOQAAAgAAAAAFTAZCAAwAGAAAAQIAKQERIzUzESEgAAE0JiMHETMVIxEzIAVKAv6d/rf954ODAh0BTAFg/laLhIGxsYEBDwMf/oP+XgK6zwK5/lr+hcjaAv7Iz/7DAAAC//7/+gQGBo4ACAAeAAABNSYjIhMQNzYTNSURIScGIyInJgMCADMyFxYXNSM1Aqodg6gCpoMdAVz+qARGg7qPlgICAQrJGBdeTN0B/MKz/un+6AICBIJ6TPlyQkiqsgEEAQ4BVgIKMYbBAAABAAAEeQE5BkIAAwAAASMDIQE5k6YBBgR5AckAAQAABHkBOQZCAAMAAAEDIxMBOaaTMwZC/jcByQAAAAACAAIEeQJvBkIAAwAHAAATATMDMxMzAwIBCpSYQpGUHwZC/jcByf43AckAAAIAAAR5Am0GQgADAAcAAAkBIxMjAyMTAm3+9ZOXQZKTHwZC/jcByf43AckAAwAAAAAFlgFwAAMABwALAAApAREhASERIQEhESEBWv6mAVoCHv6mAVoCHv6mAVoBb/6RAW/+kgFvAAAAAAABAAAFbAABAOUDAAAHAl4AEAAk/9wAEAAmAEsAEAAqACYAEAAtACYAEAAyAEsAEAA3/5AAEAA5/4gAEAA6/5AAEAA7/04AEAA8/uYAEABSACYAJAAQ/9MAJAAd/9wAJAAe/9wAJAAk/7cAJAAm/9wAJAAq/9wAJAAy/9wAJAA0/9wAJAA2/9wAJAA3/0QAJAA4/7cAJAA5/5AAJAA6/8EAJAA7/5AAJAA8/2sAJABH/9wAJABIACYAJABJ/9wAJABU/9wAJABX/9wAJABY/7cAJABZ/5AAJABa/7cAJABc/7cAJADy/9wAJQAQADkAJQAmACYAJQAqACYAJQA5/9wAJQA6/9wAJQA8/60AJgAk/9wAJgA2/9wAJgA8/7cAJwAk/9wAJwA5/9wAJwA8/7cAKQAP/wMAKQAR/wMAKQAd/60AKQAe/60AKQAk/5AAKQA3ACYAKQBE/4gAKQBI/5oAKQBM/7cAKQBS/5oAKQBV/6QAKQBY/6QAKQBc/7cAKQBp/4gAKgAQAC8AKgAk/9wAKgA3/9wAKgA6/9wAKgA8/5AAKwAd/9wAKwAe/9wALQAQ/9wALQAk/9wALgAQ/ykALgAk/7cALgAm/5AALgAy/5AALgA3/9wALgA4/7cALgA6/5AALgA8/5AALgBE/9wALgBI/9wALgBS/7cALgBY/2sALgBc/5AALgBp/9wALwAk/9wALwA3/2sALwA4/9wALwA5/5AALwA6/7cALwA8/2sALwBY/9wALwBc/7cAMgAP/60AMgAQADkAMgAR/60AMgAk/9wAMgA5/7cAMgA7/7cAMgA8/7cAMwAP/tMAMwAQ/9MAMwAR/tMAMwAk/5AAMwBE/4gAMwBI/6QAMwBS/5oAMwBV/9wAMwBW/7cAMwBY/7cAMwBp/4gANQAQ/8kANQAd/7cANQAe/7cANQAk/7cANQA3/9wANQA5/9wANQA8/2sANQBI/9wANQBS/9wANQBY/9wANQBc/9wANgAk/7cANgAmACYANgAqACYANwAP/x8ANwAQ/2sANwAR/x8ANwAd/30ANwAe/30ANwAk/0QANwBE/0QANwBG/x8ANwBI/0QANwBM/7cANwBS/0QANwBV/9wANwBW/x8ANwBY/1kANwBa/2sANwBc/2sANwBp/0QAOAAk/5AAOQAP/q0AOQAQ/30AOQAR/q0AOQAd/04AOQAe/04AOQAk/5AAOQAy/9wAOQBE/2EAOQBI/1kAOQBM/7cAOQBS/30AOQBY/2sAOQBc/5AAOQBp/2EAOgAP/twAOgAQ/2EAOgAR/twAOgAd/4gAOgAe/4gAOgAk/7cAOgBE/4gAOgBI/30AOgBM/5AAOgBS/5AAOgBV/6QAOgBY/30AOgBc/5AAOgBp/4gAOwAQ/04AOwAk/7cAOwAm/9wAOwAy/7cAOwA3/7cAOwBI/7cAPAAP/vAAPAAQ/uYAPAAR/vAAPAAd/ykAPAAe/ykAPAAk/0QAPAAm/9wAPAAy/7cAPABE/0QAPABI/x8APABM/5AAPABS/0QAPABY/0QAPABp/0QASABb/9wASQAP/9wASQAR/9wATgBE/9wATgBI/9wATgBS/7cATgBY/9wATgBc/9wATgBp/9wAUgAQACYAUgBb/9wAVQAP/30AVQAQ/9wAVQAR/30AVQBJACYAVQBL/9wAVQBQACYAVQBRACYAVQBVACYAVQBYACYAVQBZACYAVQBaACYAVQBcAEsAWQAP/zwAWQAR/zwAWQAd/9wAWQAe/9wAWgAP/0QAWgAR/0QAWgAd/9wAWgAe/9wAWwBG/9wAWwBI/9wAWwBS/9wAXAAP/04AXAAQ/9wAXAAR/04AaQBb/9wAAAAbAUoAAAAAAAAAAADuAb4AAAAAAAAAAQAiAqwAAAAAAAAAAgAOAAAAAAAAAAAAAwAgAA4AAAAAAAAABAAiAqwAAAAAAAAABQBQAs4AAAAAAAAABgAiAqwAAAAAAAAABwB4AC4AAAAAAAAADAAqAx4AAQAAAAAAAAB3AKYAAQAAAAAAAQARATQAAQAAAAAAAgAHAR0AAQAAAAAAAwAQASQAAQAAAAAABAARATQAAQAAAAAABQAoAUUAAQAAAAAABgARATQAAQAAAAAABwA8AW0AAQAAAAAADAAVAakAAwABBAkAAADuAb4AAwABBAkAAQAiAqwAAwABBAkAAgAOAAAAAwABBAkAAwAgAA4AAwABBAkABAAiAqwAAwABBAkABQBQAs4AAwABBAkABgAiAqwAAwABBAkABwB4AC4AAwABBAkADAAqAx4AUgBlAGcAdQBsAGEAcgBVAFQATQA6AFYAZQByAHMAaQBvAG4AIAAxAC4AMAAwAFAAaADhAHQAIAB0AHIAaR7DAG4AIABiHt8AaQAgAFQAaABpAGUAbgAgAE0AaQBuAGgAIABDAG8ALgAsACAATAB0AGQAIAAtACAAaAB0AHQAcAA6AC8ALwB3AHcAdwAuAHQAaABpAGUAbgBtAGkAbgBoAC4AdgBuVGhpZXQga2UgYm9pIE1pY2hhZWwgRGluaCBLaWVuIC0gIkluIEdvZCBXZSBUcnVzdCAtIEZyZWUgZm9yIGV2ZXJ5b25lIiBFbWFpbDogZm9udGNodWRlcGNAZ21haWwuY29tOyB3d3cuZm9udGNodWRlcC5jb21SZWd1bGFyVVRNOlZlcnNpb24gMS4wMFVUTSBBbWVyaWNhbiBTYW5zQm8gRm9udCBjaHUgVmlldCBzdSBkdW5nIGJhbmcgbWEgVW5pY29kZVBoYXQgdHJpZW4gYm9pIFRoaWVuIE1pbmggQ28uLCBMdGQgLSBodHRwOi8vd3d3LnRoaWVubWluaC52bmh0dHA6Ly9mb250Y2h1ZGVwLmNvbQBUAGgAaR6/AHQAIABrHr8AIABiHt8AaQAgAE0AaQBjAGgAYQBlAGwAIAEQAGkAbgBoACAASwBpAOoAbgAgAC0AIAAiAEkAbgAgAEcAbwBkACAAVwBlACAAVAByAHUAcwB0ACAALQAgAEYAcgBlAGUAIABmAG8AcgAgAGUAdgBlAHIAeQBvAG4AZQAiACAARQBtAGEAaQBsADoAIABmAG8AbgB0AGMAaAB1AGQAZQBwAGMAQABnAG0AYQBpAGwALgBjAG8AbQA7ACAAdwB3AHcALgBmAG8AbgB0AGMAaAB1AGQAZQBwAC4AYwBvAG0AVQBUAE0AIABBAG0AZQByAGkAYwBhAG4AIABTAGEAbgBzAEIe2QAgAEYAbwBuAHQAIABjAGge7wAgAFYAaR7HAHQAIABzHu0AIABkHuUAbgBnACAAYh6jAG4AZwAgAG0A4wAgAFUAbgBpAGMAbwBkAGUAaAB0AHQAcAA6AC8ALwBmAG8AbgB0AGMAaAB1AGQAZQBwAC4AYwBvAG0AAAACAAAAAAAA/zsAbQAAAAAAAAAAAAAAAAAAAAAAAAAAAPsAAAABAAIAAwAEAAUABgAHAAgACQAKAAsADAANAA4ADwAQABEAEgATABQAFQAWABcAGAAZABoAGwAcAB0AHgAfACAAIQAiACMAJAAlACYAJwAoACkAKgArACwALQAuAC8AMAAxADIAMwA0ADUANgA3ADgAOQA6ADsAPAA9AD4APwBAAEEAQgBDAEQARQBGAEcASABJAEoASwBMAE0ATgBPAFAAUQBSAFMAVABVAFYAVwBYAFkAWgBbAFwAXQBeAF8AYABhAI4AiwCKAI0AiAD1APQA9gECAQMBBAEFAQYBBwEIAQkBCgELAQwBDQEOAQ8BEAERARIBEwEUARUBFgEXARgBGQEaARsBHAEdAR4BHwEgASEBIgEjASQBJQEmAScBKAEpASoBKwEsAS0BLgEvATABMQEyATMBNAE1ATYBNwE4ATkBOgE7ATwBPQE+AT8BQAFBAUIBQwFEAUUBRgFHAUgBSQFKAUsBTAFNAU4BTwFQAVEBUgFTAVQBVQFWAVcBWAFZAVoBWwFcAV0BXgFfAWABYQFiAWMBZAFlAWYBZwFoAWkBagFrAWwBbQFuAW8BcAFxAXIBcwF0AXUBdgF3AXgBeQF6AXsBfAF9AX4BfwGAAYEBggGDAYQBhQC4AH8AfgDsAP8BAAGGAQEAtgC3ALQAtQCrAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABkRzbGFzaAAAAQAAgAAAYwI7A2QAAHBjBOgAAFVWTkFpQ2FwUmVndWxhciD/////N////lVBQ1IwMAAAggAAAA==', 'UTM Aptima': 'AAEAAAAPAIAAAwBwT1MvMkC0lAsAAAF4AAAATlBDTFRD9kC/AAC4JAAAADZjbWFwqh29IwAABbQAAAQmY3Z0IMiEyy0AAAp0AAAAPGZwZ22DM8JPAAAJ3AAAABRnbHlm/KGoCAAADKgAAJ7oaGVhZPBcfcEAAAD8AAAANmhoZWEcvhH/AAABNAAAACRobXR4VPtSZQAAAcgAAAPsa2Vybg0XD8oAAKuQAAAFcGxvY2GBA62GAAAKsAAAAfhtYXhwAg8HFwAAAVgAAAAgbmFtZTy6tysAALEAAAAEfXBvc3TMtECzAAC1gAAAAqNwcmVwBWQUUgAACfAAAACEAAEAAAABAAC/IvUmXw889QADCAAAAAAAt7hpSAAAAADGhMjn/7v94xNOCLQAAAAGAAEAAAAAAAAAAQAACbL93QAAE7D/u/92E04AAQAAAAAAAAAAAAAAAAAAAPsAAQAAAPsGUQBxAAAAAAACAAgAQAAKAAAAkACEAAAAAAAAA3kBkAAFAAYFRwTMAAD+iAVHBMwAAAH1AG0CZgUCAgQGAwUFBgICBAAAAAAAAAAAAAAAAAAAAABLVCAgAEAAICAmBmX/HwDNCbICIwAAE7AALQAAAAACOwAAAk0AAAK8ANkCvABmBIcARQSHAJsHKwBeBc4AkwJNANQCTQB+Ak0ATQOVAG4E3QBqAk0AXgK8AFYCTQCjAk3/uwSHAFoEhwDABIcAWgSHAHoEhwAtBIcAegSHAHYEhwCjBIcAcgSHAF4CTQCjAk0AXgTdAGYE3QBqBN0AYgMrAJ8GegBmBWAAIAT1AMQFYABNBlEAzAUKALgEBAC4BlEAgwZRALgCTQDEAk3/5AT1ALwEBAC4BysAWgZRAMwFYAAcBIcAowa8AFYE9QC4BAQAXgSHACgFYABFBWAAMQgEABgE9QBJBWAAZgT1ACQCvAEWBAQARQK8AFYE3QBqBAQAAAK8ACgEBABeBIcAhwQEAFYEhwBJBAQARQJNACgEBABJBIcAnwJNALQCTQAABAQAowJNAMwGvACTBIcAnwQEAD0EhwCHBIcASQK8AKMDKwBWAk0AFAQEAFEEBAAoBlEAJAQEAD0EBAA1BAQALQK8AHYCvAESArwAWgTdAGoEAAAABhAAKAYzADsEAAAABAAAXQb0AAAG9AAABvQAAAVgACAFYAAgBWAAIAVgACAFYAAgBWAAIAVgACAFYAAgBWAAIAVgACAFYAAgBWAAIAVgACAFYAAgBWAAIAVgACAFVgAiBQoAuAUKALgFCgC4BQoAuAUKALgFCgC4BQoAuAUKALgFCgC4BQoAuAUKALgCTQAcAk0AYgJNAFgCTQAIAk0AxAVgABwFYAAcBWAAHAVgABwFYAAcBWAAHAVgABwFYAAcBWAAHAVgABwFYAAcBWAARQVgAEUFYABFBWAARQVgAEUFYABFBWAARQVgAEUFYABFBWAARQVgAEUFYAAcBWAAHAVgABwFYAAcBWAAHAVgABwFYABmBWAAZgVgAGYFYABmBWAAZgQEAF4EBABeBAQAXgQEAF4EBABeBAQAXgQEAF4EBABeBAQAXgQEAF4EBABeBAQAXgQEAF4EBABeBAQAXgQEAF4EBABeBAQARQQEAEUEBABFBAQARQQEAEUEBABFBAQARQQEAEUEBABFBAQARQQEAEUCTQAYAk0AYgJNAE8CTQAMAk0AyAQEAD0EBAA9BAQAPQQEAD0EBAA9BAQAPQQEAD0EBAA9BAQAPQQEAD0EBAA9BAQAUQQEAFEEBABRBAQAUQQEAFEEBABRBAQAUQQEAFEEBABRBAQAUQQEAFEEBAA9BAQAPQQEAD0EBAA9BAQARwQEAD0EBAA1BAQANQQEADUEBAA1BAQANQaqAAACRgAAAkQAAAJ1AAAE+gAAA5oAAAZRALgEhwBJAk0AjwJNAGoDlQCHA5UAagUtAKMAAAADAAAAAAAAABwAAQAAAAACIAADAAEAAAAcAAQCBAAAAEAAQAAFAAAAfgCpAK4AtAC2AL4AwwDKAM0A1QDaAN0A4wDqAO0A9QD3APoA/QEDAQ0BEQEpAWkBoQGwHvkgECAZIB0gJv//AAAAIACoAK4AtAC2ALwAwADIAMwA0gDZAN0A4ADoAOwA8gD3APkA/QECAQwBEAEoAWgBoAGvHqAgECAYIBwgJv///+P/uv+2/7H/sP+rAAAAAP+6AAD/vf/LAAAAAP/cAAD/9//f/+0AAP/m/+QAAAAAAAAAAAAA4ADg3uDc4NQAAQAAAAAAAAAAAAAAAAA0ADoAAAA8AAAAAAA+AEQAAABGAAAAAAAAAEYAAAAAAEQARgBIAEoATAAAAAAAAAAAAAAAagBrAG8AbQB7AHwAgACLAIwAkACOAKwArQCxAK8AvQC+AMIAzQDOANIA0AB1ALcAiQDLAJkA2wChAOMAmwDdAG4AsABsAK4AcQCzAHAAsgByALQAcwC1AHQAtgB3ALkAdgC4AHgAugB5ALsAegC8AH8AwQB9AL8AfgDAAIIAxACBAMMAgwDFAIQAxgCFAMcAiADKAIoAzACPANEAjQDPAJIA1ACRANMAkwDVAJQA1gCVANcAowDlAKIA5ACkAOYApQDnAKYA6ACaANwAmADaAJ0A3wCcAN4AngDgAJ8A4QCgAOIApwDpAKsA7QCpAOsAqgDsAAYCBgAAAAAA/gABAAAAAAAAAAAAAAAAAAAAAQADAAAAAAAAAAIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAAAAwAEAAUABgAHAAgACQAKAAsADAANAA4ADwAQABEAEgATABQAFQAWABcAGAAZABoAGwAcAB0AHgAfACAAIQAiACMAJAAlACYAJwAoACkAKgArACwALQAuAC8AMAAxADIAMwA0ADUANgA3ADgAOQA6ADsAPAA9AD4APwBAAEEAQgBDAEQARQBGAEcASABJAEoASwBMAE0ATgBPAFAAUQBSAFMAVABVAFYAVwBYAFkAWgBbAFwAXQBeAF8AYABhAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABiAGMAAAAAAAAAAABkAAAAAAAAAAAAAABlAAAAZgAAAAAAAAAAAAAAZwBoAGkAAABqAGsA7ADtAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAO4AAADvAPAAAAAAAPEAAEABACx2RSCwAyVFI2FoGCNoYEQtQCkXFxYWFRUUFBMTEhIRERAQDw8ODg0NDAwLCwoKCQkICAMDAgIBAQAAAY24Af+FRWhERWhERWhERWhERWhERWhERWhERWhERWhERWhERWhERWhERWhERWhERWhERWhERWhERWhERWhERWhEswUERgArswcGRgArsQQERWhEsQYGRWhE/mr/8QNxBPQAqwHJAEsAYQCEAEgBFgGhAhgB2ADjAxYBgQG3A54C/APxAVIDJQJYWnJaclpyWnIABAAGAAAIQAhACEAIQAhqCJQIzAksCZIKDAokCkYKZgqaCrIKzAraCvALBAs8C1wLoAvsDCQMaAykDNYNOA16DaANyg3eDfIOCA5WDs4O/g8+D3QPsA/kEBIQThCQEKoQyBEUEToRlhHAEfgSMBJ6EsgTDhM2E2oTqhQEFE4UihTAFNIU6BT6FQ4VHBU6FY4VzBYCFjwWeBauFyIXUBd2F64X/BgQGFwYjBi+GQIZQBlsGaYZ2BoGGjoajBrUGwwbOBtsG3obrBvcG9wcOBzKHMoc5hzmHOYc5h0uHXYd4h5AHoAevB8QH2Qf2iBEIJAg1CEuIYgiBiJ4IvAjPCOII/YkWCScJNwlNCWMJgYmdCbEJvYnKCd8J8Qn7ig+KI4pAilqKbIp9ipSKq4rLCueK/IsPCyILPYtWC2cLfAuXC7GL1Qv1jA6MI4w+jFmMfYyejLeMzIzhjP8NGY0sjUcNYY2FDaWNvo3WjfQOEY43jlqOdo6QDq8Ozo72jxuPOQ9OD2KPgA+aj62Pvw/Wj+4QDhArEECQTJBYEGyQfRCKkJ0Qr5DKkOKQ8xECkRgRLZFLkWaRehGLkZ0Rt5HOkd6R8RIJkiISQxJhEneSixKkkr4S4BL/ExaTKpM+k1uTdROHE4cThxOHE4cThxOHE5kTqhOxE7eTxBPPk90AHEALf6ME04H/QAQAB4AKgA5AE8AYwBsAH8AkwCsAMYA1QDnAQgBKAE+AV4BdwGCAY0BmAGcAa8ByAHaAegB+AIMAhsCHwItAjsCSgJSAl4CbgKAApoCvgLNAtoC5gLzAvsDAAMGAw4DFwMjAycDLAM6A04DUgNgA2QDaANsA3oDjgOqA8ED1APnA/YEDAQQBBQEGAQjBC8ENgRCBE4EWgReBGIEdgR6BIEEhwSMBKYErQS3BMgE6ATtBPoFEgUWBScFPAVIBVkFbAWBBZUFqQW8BcwF7QXzBfcGCwYPBhMGHwYmBiwGOQZFBlAAAAEzFhUUByM0PwEmJyMiByM2BRcUByMnByc2OwEXMzIFMxUjFTMVIxUHIxElMxcVMxUjFQcjNSM1MzUlMxcVMzY7ATIfARUjNTQrASIdASMRJTMXFRYzNj0BNzMVFAcGIyInJjU3MxUjESMRIzU3MxYXMzczESM1IwcjIi8BIxUjATMRIyc1NycGIyIvATU0PwEyFzMlMxcVIxUjNQYjJj0BMxUUHwEzMj8BNTM1JRUjFSM1IwYjIi8BNTMVFB8BMzI9ATMyNTcFMhcWFxQPASInJj0BNDchMzIXFSM1NCsBIh0BIzUzFTYhMzIXIyYrAQYVBxY7ATI3MzczFzcXNxcGIyIvATU0NzYhMzIXFSM0KwEiBxUUFxYVFA8BJjUzFBczMjc0JyY1NCUyFxYdASM1NCsBIgcVIzUjNzUzFTYhMzIXNSc3MxUUDwEjIiczFhczMjc2NyMGIyInJic0NwUzFRY7ATI9ATMVIyczJzU3NSMUByMiLwEFFjsBNj0BJisBIgUWOwEyNzQnIyIHBRY7ATY1NCcjBhUFMxUjBRYdARQHIzQ3NTQnIwYVIzU0NwUyFyMmIyIHBhUUHwEyNzMGIyInJjU0NzYhMhcWHQEUBwYjIicmPQE0NzYFMxczMjcXBisBJwcnNgUzMhcWFQYjFRYdARQPASMBMxUWMzI/ATU3MxcVFAcGIyIvATczMhczNTMXESMmJyMVIwEzESMBMzIXFh8BFRcUBwYrAQEzFSMVMxUjFRczFSMRBRUUHwEyPwE1NCcmJyIHJRUzMjU3JiMhFRcVMj8BNTQnJiMFMzIXNTMVIzUGIyIvATQ3JTMyFxUjNTQrASIHFSM1MxU2ITMyFzUzFRQHIyInMxY7ATI3BiMiLwE1NDclMzIXMzY7ATIXFh0BIzU0LwEjIgcVIzU0KwEiBxUjNTMVMzYlMhc1MxUjNQYjIi8BNDcFFBczMj8BNSYrASIHBRQfATMyNzUmKwEiBRUWOwE2PQE0LwEjBgUVFDMyNTQnARcHJiclFxQHJzYFMxcjJwcjNiEzFyMnIxQHIyUzFh8BNj8BMxUDIwEzFSM3MxcRIwEzFxUzFSMVIzUjNTM1NzMVMzY7ATIfARUjNTQrASIdASMTMxUjJTMXFTMVIxUjNSM1MzU3MxEjATMRIwEzFSMFMzIfARUUDwEiLwE0NyUzMhcWHQEjNSYrASIHFSM1MxU2ITMyFzM1MxUUDwEjIiczHwEzMjcGIyInJic0NyUzMh8BByMWMxcyNzMVBiMiLwE1NDc2ITMyFzM1MxUjNSMGIyIvATU0NyUzMhcHFRQHBiMiJxUHIxEzFTYhMhc1MxUjNQYjIic0NzYFMxUWOwEyPQEzFSM1IxQHIyInJj0BNzMVIyUzFSMlMxUjJRUWOwEyNyYrAQYFFjsBMjc1JisBIgclMzUmKwEiBRY7ATI3NSYrAQYVBRY7ATI3NTQnIyIHBRYzMj8BNTQnIyIHBTMVIyUzFSMFMzIXFRQPASM0PwE1JisBIgcjNgUXBycFMxYXByY1JRcHIic2JRcHJzcFMxUXMxUjBxEjNQYjIi8BNDczMhc1JyM1MyUzFyMnByMlMzIXIycGFSM1JTMVIxEjJzU3NSc3JzcnIzUlMxUXBxUXBxUXFQcXMzY7ATIXFh0BIzU0KwEiHQEjESUzFxUjJTMVNzMHFxUjJicVIwEVNjMyFxYdASM1NCsBIgcVIxEnNTcnNzsBFSMlMxU2OwEyHwEUBwYjIicVIwEzFTM2OwEyHwEVIzU0IycjIh0BIyUzFSMiHQEjNTMVNiEyFxUjNSYrASIdASM1MxU2ITIfAQYrARYzMjczBiMiJzU0NyUzMh8BFQcjFjsBMjczBiMiLwE0NyUzMhcWHQEjNTQnIyIHFSM1MxU2ITMyFzM1MxUjNSMGIyIvATU0NzYhMzIfARUjNTQnIyIHFSM1MxU2ITMyHwEUDwEiJxUjETMVNiEzMhc2OwEyHwEVIzU0KwEiBxUHIzU0JyMiHQEjNTMVNgUzFxUHIyUzFSMlMxUWOwEyPQEzFSM1IwYjIicmNSUzFSMlMxUjJRQXMzI3NTQnIyIHJTMmKwEiBwUzJisBIgUVFjsBNj0BNC8BIwYFFjsBMjc1JisBIgclFRQXMzI3JisBBg0XCiUgHBwCBQUJCAIeBvrwHSgTOwscCyALKgIK+gWOXllZBTECtSsGHh4GMRkZAdgqBAMXHwI6GQI0KgcrMwJIMQUKIywFMUIPFC8jDuufODU3v0cHTAJQSTYCSiwENhMDNwRzNC0FAwMdMUMhBVwXIxwD+VkkBC0wFyRZMxoSBhoNAzUFkB8vAg8qRBIDNBMVCSobBAP1k0QjCQNaID8mDGUBEANKCTMqBSw0Lh4B5wdIITwQGhE1AwwxCRYZKAIDAgIDAgIhTUwiBE0PBqECMRU0EAQOBUQePRdMNhsEEwVEIgRwNxYHNCgLIQc0AgIvGQEMBSgdAwMvVSEHRiI7GBUNFhUPBwMgKTknCgRX/dQ1BiIHLjMvAwMDAwQ5AzsZAvOnCjUHOw0uBToLdQ0wBToIMxYlEwLlCDkFOzsOOP5CNDT0xisgHB8HDAocIQkBXC48JSs3IApREiQnPSxeXTAKWh0BXTkuLlshHlkxDWId+qICLwMLDxISEQM2FBQS+gkTdgsZChQvRTZDByo1BicdDwMELQUoGCg3JAT/OwR2BDIEOh1gAzUBKDY2AvYImxMXGAQDUiNANwEamWdlZQRjnf3CTxNEHAM8DBtCHvUVCTYDCxIMIQJoEgIgGTX0uQUmITExJCxLGgVVASoDSgkzKgoiBTQvHAEGBS0aL2gQSiI7GhIONAwhKzwpB1UBiAIrEgIgJQQ5Fgg0FwwPIAQ0KwggBDYyAgYBoi8cLy8kKkocBlX7CT0ELREDDC0OKRIB9isSBS8QCy8MMgLZDyoOOiUSCkD6UQdNLwhvGDMSCfqUVRVXEgUzJjc2FRc2NgJBKDg2GAETNvVINAgnIgkZMDZwLAGoMzPDLgY0A8MtBB8fNRoacDQCFx8DORgDNCcKKjTvNDQBbCwGHR02GxvSNDQC0zQ0AWczM/U3BVMbA1UjTCMEXQEYBDUZBzYHHgomBDYxGgEMBC0SAzFZHAVJITQlDw4yCyEoPiQLAVYDTwJSHQICrA8eDh0UOSNJTSIBICICYwUpHQIvLwIjKkceBVQBMgdYEwJCFRkiHgUxMR8B3iwfMTEjKlwQSQ/zeTIDJwUsNC8FOAM3GwTxMzMF4TQ0BnQzM/T4DS4EOwcNLgs7Ae8PLAswCw0uDicRAzJ6ECsHIwIjDTAFNA0KLxA4AQsMMQMyDzEWLwsBxQo4KxICNBIqEf1ZMzMC0TMz+oQEIwgYChwcAwMGCggBHgb7gTQaNPtwBEsKFFgMVVYSClEPBEgTWxRc8tIzBQ4OBS4iL0geA2UOISEGKzEBFCg4NRcXNQTBIQwzNhcTOvYaoDgyBAICAgICAjYCji8CAgICAgICAxEiAzUYBzQoCCs0AlsvBTQCsjRGPk5aRgpANAEcGB05Fwo2KQsfBjUBAQEB8DMzArIzGykDSx4FQB4TKR8vBGc0AhcfAzwWAjQgCgwlNPCWAwUqNS8SAQtHDzMGIwYtNDIZA85IIQUCBakRLRgYOSFLUh9ZBKAFTR4DA6oSIwwVFTsiR1QfAlsBGQQ2GAc2IwsmBTYyGQJyBigeAi8vAiIsRx4ETQsBJAQ+FAM2JgkmBDYxGgGBAUoeBFQZKRs0Lx4CcAUiHRsqBjgXBjQnByMGBTAfESgzLxbvHzEFBTEDqjQ0AWA0BCcELDQvBQwvNBsFAykzMwgJMzPykjMMNgw2ESYUAWl6EiMHKxMEiXoVIQcuAkYKMwVAJhIOPAEADjALKRIIMBEvDAJiOwkyCw0tDzgH/QoqDC0YHgoNAhMxHR8QDgwMGR0LEjxLO4EFAUMFBU40vAXBNE4FBV4YRyePc1BWbQFDBQXeMwc01gXYVRsINxgh4Dz+9AEMNwUE9/v+uPLytjzyAUj+uAULAg4oWycDXh8DIDcGMd0XHw5TnGhPBwUkGoUZBjfdGSFOHZJ4MhIHRX4cAxdNEiRYJwNJFh4KXiBlmHdMTHf1FR1ZHw4vD0UbAwMDAwMHUV4kA1UjCDwOEA0NCRoTKDoWAwxHFAUXFhYbIEILPxIvfXBTNo0FAu4VHSgSAwvQYSMEUBYBFg0nKEYSLVglBYg7XWb1CgMFAgMXCEtVIUUOMw9BSUhLMRU5EEgMPD0MEC6lOaELJgQRKxkgBwwDBA8GIAw8YypEFhlOIAEnYXAfH2E3Dy8zQBRZOQ1lIRsSYjULAgsLJBMKByQQAxoaJDkGFysSPxkFAUjZPSceywYGq3YPGkw2zu3tBv6+ML7uAUj+uAFIKAtAJAsCXjcPAUg8SzlKBTkBQpkKTCABVhQPPSEIA1NLQxwOGc4DAkwPHSIiFw8oIPUgKGEkWSQDZpeAQz6F9RUdKCDbXx9SGU0qUSwQTyYDJSU3GRSZiiwLAkGCiDs5ivUVGAUqIvUgKFwpWiOLMA0uDxY+ORAwFAQ5F0FGDj0MNAstFAUIK1IFLSII/nMcNwwOHzYPGzYpITwaGjw8GgUVNASFbghckwL+ugFINjYF/r0BSAVONMHBNE4FYhdHJpBzUVdtAUg2NgVONMHBNE4F/rgBSP64AUg2FWYXC1MlBWEgYSECPBk4cJIyOYv1FR0nH85mIQNRFANIJ0wXJVUmAmgZGy0DFgNMYRwIMSgnJx/1HydZJA5WIgKAAQ9BKQsgYwUBRRwkJx/1HyeEVCUICIg8V231GBcJRCNAUQX19fX19YMQQkxHEEFCSwFHOQoCLU9EPwxIDjEMSDwWKxZICUIwDxA2DjysNDQ0iDICEBkRGR8CAhMTMhE8EzQKMAwlMQknOic3JAMqNCc6GhMFJAX+6R8oaRpmHSE7BSQQPRsbPT0bFQYEMTz+9AX1AwICAwIDAzYGSQIDAwIDAwICAwMYOhEZmX9EVm0BQgYGMTfGc3Z9AhZdcwFIYxg4Ezp4hT43jAE6AwMCAwM3N2whXiVLLQsoHwFIYxhKKYpvUgJQc/06OYr1FR1Xpog7VG/1FR1eJxgvFU9pJVEkA2EaFQ0vFU9mHV0jAzwZOW+KMAk5ivUVHSgg9R8oWiUMUiMGTlRbijAJNI/1FR1dKFgmAyJqAUYdJSUlQjOIekkyjAWMKg1NdvUVHQgG6gX19fWIPFFz9RghPwwWnfX19Xo1FEIKNRE5Ci8sAy8+C0kIPwUtFAUOP0U8DUlJCxYvD0xGEQAAAAIA2f/nAc8FkQALABcAAAEDIwMnNDYzMhcWFQM0NjMyFhUUBiMiJgG2SilNBCs3LRYf3U4xMUZGMTVKBMX8nwNhPTlWHCdQ+2gySUkyNUpKAAAAAAIAZgMbAkEFkQAMABoAABMRFCMiNTcRJzQzMhUFERQGIyI1NxEnNDMyFfFBSgQESkEBUB8mSgQESkUE7v5/UlIpAVgxcm41/oMpLVYlAVgtdnIAAAIARQAABDEFUAAbAB8AAAEVIwMjEyEDIxMjNTMTIzUzEzMDIRMzAzMVIwsBIQMhA//hPXc9/u5CdkHZ7ini8kF3QQESPnY9xdUpTv7tKQETAi1z/kYBuv5GAbpzARJzAZ7+YgGe/mJz/u4BEv7uAAADAJv/EgPWBfwABwAPAD4AAAERPgE1NCcmJxEOARUUFxYTERYXFhUUBwYHFScHNSImJz4BNTMWFxYzESYnJjU0NzY3NRc3FTIWFwYHIyYnJgJqXHFpR29UaEsjoNkMh2hgpCkppKA5DBkUQkFQcZpDf2RanikpZJo5IRQZJTM7Alb99BaQaH1IKfEB1xJ7WG9DHwG6/gBiCFymsHVtIOIFBdU4NytcKWQtOAI+NzNjn6BlWhqcBASYLTFIWFQpLwAFAF7/uga0BZEABQARACAAMABAAAAJAScHARcBFAYjIiY1NDYzMhYBFAYHDgEjIiY1NDYzMhYFFBcWMzI3NjU0JyYjIgcGARQXFjMyNzY1NCcmIyIHBgUj/QYxLQL5Lf38wIuSssORja4Dx1pSGWYhk7DAlI2u/gQhLWJlMSMdKWJvLyP8OSEtY2IxJTMrSm8vIwWR+ikJCQXXBP6Hi9G/lZLCvvyiYZs0EB29k5TEvq5tQVhsTnVyQl5sUAJObT9WbFJxj0Y5bU8AAAADAJP/4wVcBWAADQA/AE4AAAE2NzY1NCYjIgYVFBcWCQEuASMiBgcmJyYnDgEjIiY1NDc2PwEmJyY1NDYzMhYVFAcGBxYfATY3NjceARcGBwYBBwYHBhUUFjMyNjcmJyYCj14xQlpKVlopFgH6AQIzNRccIzMwDhguVuOBqttqWaUNTBIur413l1o7gX9/akBBMUQMKRlCQ0r9nBFoNEGsf1KsRmtYbQM/RkBWYEpia1ZJUiv9g/7ZBAQCBkYUITVgabudjHJfUQlyI1hSiaZyZ3NmRFOgoHtWb1J7FSsSZVxmAUwNQUZYbX+sUkaBcYkAAAAAAQDUAxsBXwWRAAwAAAERFCMiNTcRJzQzMhUBX0FKBARKQQTu/n9SUikBWDFybgAAAQB+/y8B7wX8ABAAAAEXBgcGERQeARcWFwcmAhEQAcYpgzoxHTMtI04psJgF/CW038H/AGjgyFxIdynNAZMBEQH2AAABAE3/LwG6BfwAEAAAFyc+AzUQJyYnNxYSFRACdilGWDEaLzeDKaKilNEpbbLC03cBAL/htCWw/kz4/vH+aQAAAQBuAqgDIgWFABgAABMFAxc3AyUWFw0BDgEHJRMnBxMHLwEtATanAQIcMUYhAQIaI/7dAR8QGw7+/iFGMRz5LgwBH/7ZJwT+uAE7BAj+vcA7L4R+GS0huP7BBAQBN7ROFIeELQAAAAABAGoAAARyBAwACwAAAREzESEVIREjESE1Ai2DAcL+PoP+PQJKAcL+PoP+OQHHgwABAF7+qAGiAPIADAAAGwE2NzYzMhYVFAYHA16PFQobJSQyDx7y/rQByzsPKScjGSUx/m8AAQBWAYUCVgIEAAMAABM1IRVWAgABhX9/AAAAAAEAo//nAZkA4QALAAA3NDYzMhYVFAYjIiajSjExSkgzMUpmMklJMjNMSgAAAf+7/y8CbwX8AAUAAAkBJwcBFwJv/bYtPQJKNQX8+TMEBAbNBAAAAAIAWv/nBBgFXAAQAB4AACUyNzYRECcmKwEiBwYREBcWARA3NiEyEhEQACMgJyYCQZ5MRkROkQi7Sj8rSv7jXn0BFenl/vzX/vp3ZimuogE3AQikv6SO/sP++IvwAloBMbby/qj+rP60/oPBpgAAAAABAMD/+AKTBXkADwAABREnByYnPgE3FxEuASMiBgHvDOYUKW3pXCEVJBkUMAgE2QR7MR0rbzcI+ocEBAYAAAAAAQBaAAADywVcACoAABMnNjMyFxYVFAcGBwMPARcyJDMOARUUFhchNTY/ATY3Njc2NTQnJiMiBgf+Sn/lu2p1PzJk8n8gCE4B204EBQIH/I9YUHuTJ1wtNjY7gV6JEwQ1Y8RUXLh3c1hs/v6DKRUZFSUUExohIVBYf5UvbWh7lIlIUXhhAAAAAAEAev/nA7kFXAAzAAATJzY3NjMyFxYVFAYHMhYVFAQjIiYnPgE/AR4BMzI2NTQmIyIGIzc0JxcyNzY1NCYjIgYH+TEjQV5pm2t/j4ORwv7T21KhRAoKBQw1lE2crJOIEFACCAhOeUE8c2ZKfx0Ec24nIzFDUJR3vDGok8XqIyMZPSUIO0zLnYiPCCkQGQRcUn1ykFpKAAAAAgAt//gECAVQABUAHwAAASE1Njc2NzY3FzcRNwcUFycRJyIGBxMRJwYHBgcGBxcCqP2Fd2R9XnNzQUK8CAi8UhcYIwQMPl4ncUtMCAF9HbCPtIOgoAQE/KQIRhgpCP57CAIGAfwCjwhShTWmb24IAAEAev/nA74FXAAsAAATETchFw4BFRcuASMhET4BMzIWFRQHBiMiJyYnPwEeATMyNzY1NCcmIyIHBgf9DAKUCAIOBEKLSv7RL3c3qOaGkeV9XjQ5HRAtnlyPVk5BSpxHOicgArQCoAgQCkYfKQ8S/jkZGN2ovIWSHxEiiARKTnNoopVQWhgQHQACAHb/5wQHBVwAGAAlAAABFyYjIgcGFTYzMhYVFAIjIicmERAAITIWAyIGFRQWMzI3NjU0JgMuGTEx4Hhfdde60/XJ9HlmAVABDhcrxYuYmoGDRj2LBVRGDfC8+LjPrsn+/rGVAQQBcQG6Av2HuLCHyXVmnpOsAAABAKP/+AQQBVwAGwAAEyEVBgMCBwIHJyIHBiM1NjcSNzY3JyIEIzc0JqMDbUiYn2uTZUUfDhMGfX++PHdYCXb+LXMIBgVcPXX++v7twv70ywgCBhjPzwE5ZcikCSFeGTUAAAAAAwBy/+cEAwVcAB4AMQBBAAABFR4BFRQEIyInJjU0Njc1JicmNTQ3NjMyFhcWFRQGASIHDgEVFBYXHgEzMjc+ATU0JgMiBwYVFBcWMzI3NjU0JyYC3ISj/v7My3eBrH9eRj15bp5WgTtvgf8AbT8bFiUgHUwvczkbEnNmg1BIQkmQh0o9PUgDChAZsIfN9mVsyYHRHxASVEpnl1pSIS1Sj2aiAfZaKWE3L1gpHxpeI1Q5aI79umtgiZNdaHVijY5WZAAAAAIAXv/nA+MFXAAcACsAAD8BFjMyNjc+ATUGIyImNTQ2MzIXFhUQACMiJicmATU0JiMiBwYVFBcWMzI2xBlUcWKuNyEhbd+o2frR4XVk/qb4PVgLBgI8jHqMRzw6Q4F9mm8ITpyPWMVkuNW0ye22nPj+oP41EwovA4cNlb9zYJaFVmTGAAIAo//nAZkDwwALABcAADc0NjMyFhUUBiMiJhE0NjMyFhUUBiMiJqNKMTFKSDMxSkgzMUpKMTFKZjJJSTIzTEoDFzNISjExSkoAAAACAF7+qAG+A8MADAAYAAAbATY3NjMyFhUUBgcDEzQ2MzIWFRQGIyImXo8VChslJDIPHvJFSDMySUkyMUr+tAHLOw8pJyMZJTH+bwSgM0hKMTFKSgABAGb/8AR2BCEABgAAJRUBNQEVAQR2+/AEEPyUc4MB428B33/+ZgAAAgBqAQIEcgMSAAMABwAAARUhNQEVITUEcvv4BAj7+AMSg4P+c4ODAAEAYv/wBHYEIQAGAAA3CQE1ARUBYgNt/JMEFPvscwGVAZp//iFv/h0AAAAAAgCf/+cCmwWRACgANAAAAQcOARUUFjMyNxcHBiMiJyY1NDc2PwE+ATU0JiMiBgcnPgEzMhYVFAYBNDYzMhYVFAYjIiYCIH8/K0ExFSkMGRghYEJHIBs7e0ItcVAtZBsMN2ExjaY3/plKMTFKSDMxSgNxkEVSKTFKEAg5CD1EcEg9MTyDQV8tTFw2JGYdII97Vnf8rDJJSTIzTEoAAgBm/98GAAWRAA0ATQAAARQWMzI3NjU0JiMiBwYBNzMDBhUUFjMyNzY1NCcmISAAERAAITIkNzMGBCMgJyYREAAhIBcWFRQHBiMiJyYnBgcGIyImJy4BNTQAMzIWAjE7RGBeWDU5e1xQAcYZtJMIHB1iXnN9oP7w/uX+jAF9AR6iAQhaf2D+ns3+wd7lAbABQgErwruaj5pWLyMITiFBTjlhJysmAQyuSF4CEEFWtKh3M0ikkAETXv3oIREcJXOL0aGOtP6g/u3+7v6kl4ey18fPATcBOQGssKjt4q6hMSU9ShQpKysrZkCqASE+AAAAAgAg//gFNwWRABQAFwAACQEuASMiBgcCAyEOAQcuASMiBgcBEwsBAtACZxc5Gx89E2B1/fhWWh0cGRQVKQwCf8ni4QWR+mcCBgYCASEBDNP4YgYCBgIFmfzqAgz99AAAAwDEAAAEUQV1ABIAHgAoAAAzESEyFhUUBwYHMhcWFRQHDgEjAxEXMjY3NjU0JyYjAxEzMjY1NCcmI8QBkerdXlaQkmaBuESucr1ORoU7oF5SrJjBl8F3ZskFdYGai2JdIkZWpN1/MSEFJ/3jBBcaRrCLPDP9mv2NsIuqTEIAAAABAE3/3wUJBZEAHgAAJQcOASMgABEQNzYhMhcOAQ8BJicmIyAHBhEQADMyNgTtCF/ngf6w/n/f1QFS6M4MFgcQOXtpaP7ymo0BL/Zu7tmDPToBjgFUAU/FvF4fUSsFSjcww7L+6f7Z/qBaAAACAMwAAAXKBXUAEAAhAAABETIWMzI2NzY3NjUQACEiBgMRITIXFhcWEhUUBwYHBgQhAYAjsC9lqkmcSkH+2f6oKczBAl6YVHtcbm9IPX1a/vr+9QUj+zsQHyJOoo/LAUQBDgj63QV1ExpOWv7vlc2ch25OTgAAAAABALgAAARSBXUAHwAAEyEHFy4BIychESEyNjMGFRciJiMhERcyNjcyNjcHFyG4A40EBCdoKc3+rAH0H3seCAgeex/+DFZ3z403Zx8EBPxmBXU+PQgMBP4ACSEVOQz9qgQGBg0EPj0AAAEAuP/4A40FdQAbAAAXESEHFy4BIycjESEyNjMGFRciJiMhES4BIyIGuALVBAQnaCnNnAE8HnsfCAgfex7+xBgpGRg0CAV9Pj0IDAT+AAkhFTkM/UAEBAYAAAAAAQCD/98FrgWRACEAAAEjLgEjIAAREAAhMjY3ERc3EQYEIyAnJhEQNzYhMgQXDgEFfRVU8Yn+8/6/ATkBLVamRFpah/7jif6Jx7jj1wFlnwERXA4ZBH9gZf6u/s/+yv6mIyMCDAQE/b8wM8/BAUkBX8K4PTkhVAAAAQC4//gFgQV1ACkAAAERHgEzMjYzES4BIyIGBxEiJCMiBCMRLgEjIgYHER4BMzI2MxEyBDMyJATMFSkdIisNGSkYGTMPS/6oC0n+qBEYKRkWHSclGhsjKwxMAV4ISgFWAycCTgQECPqDBAQGAgLECQn9PAQEAgYFfQQECP2yCAgAAAAAAQDE//gBeAV1AA0AABcRHgEzMjYzES4BIyIGxBQpHSMrDBgpGRg0CAV9BAQI+oMEBAYAAAH/5P7lAZYFdQAPAAABERQGIycyNzY1ER4BMzI2AZbhwRCaOyklGhsjKwV1+yvB+jZ7VqwE3QQECAAAAAEAvP/4BMAFdQAsAAAJAQcSExcVJyIGBy4BJwEuAScHES4BIyIGBxEeATMyNjMRFzI+ATcBHgEzMjYEqP4xsPn6pG4fQhInPiv+QgQKCwgYKRkYNA4UKR0jKwwICzExKwH4HhkbEi0Fdf5BsP7m/uXNDAgGAjtULQINBAICBP0zBAQGAgV9BAQI/YUIIi4rAggEBAYAAAAAAQC4AAADoQV1ABUAAAERFzI2MzI2Nw4BFRQWFSERHgEzMjYBbEYxyTE3bSAEBAj9FxQpHSMrBXX67QQMDQQRGhMYHwYFdQQECAAAAAEAWv/4BrgFdQA2AAABMxIXFhMWFy4BIyIHBiMmCgEnBgcGAgcjJy4BJyYnAgcGFS4BIyIGBxoBNzMWFxYXFhc2NzYSBecpKwsSJx0cKyUSKxMWChMlJA9yZ16qNxVzSXNUSEVMBBMcGRQTKwwriw81UlxoWm9meUhgvQV1/mRapP7H38sEBAIGzwGfAUxrzb+u/q6B6pngn4aF/VYly4sGAgYCARID0ZqkssmkyaXZhbIBWgAAAAABAMz/+AVwBXUAFwAAAREjJicBIxEuASMiBgcRMwEzER4BMzI2BXA+Ikj8ixQZFA0OIQpSA8sUGRQMDyEFdfqDN0gD0/uuBAQGAgV9+98EIQQEBgACABz/3wUuBZEAEAAdAAABNC4CIyIAERAXFjMyNzY1ASAAERAAISAXFhEQAASCLYG8aeP+/ImBzeyJbv4V/uP+ogFqARUBELXO/pACxZPNwmn+if7H/tOsoum72/07AZABSQFKAY+lv/6o/qz+XgAAAgCj//gEIAV1ABQAIAAAAREuASMiBgcRISAWFRQGBw4BIyImAxEXNz4BNTQnJi8BAVcYKRkYNA4BbQEp59PjI1AEI28KWm+XrTY7dYcCf/15BAQGAgV9lrq2vy0ECAgCpP2qBAQOtIpuREwMBAAAAAIAVv5WBlYFkQAZACoAAAEgFxYREAcGBxYXDgEHJicmJwYjICcmERAAATQuAiMgBwYREBcWMyATNgNMAVLV46SL7ublKVQjDqKqdSAR/qLT3QG0A4M1mt9//uSai6qX8AE1nGwFkbK+/rj+4cCiUK6uEikbG42VVAi9xAFYAT4Bm/00kc/EZ9G8/t3+xqqXARC/AAACALj/+AS8BXUAEAAwAAABETIWMzI2Nz4BNTQnLgErAQERITIWFRQHBgcBHwEuASMiBgcmJyYnAycjES4BIyIGAWwCRh8rM0V1kuISIx8e/o8Bsuzbg22yAaZiJR8zJRwjMyExIRDypE4YKRkWHQUn/c8IBgobl3XdJQIC+s0FfZqepWlWIf3oczUEBAIGL0MuFAE7wf1QBAQCAAABAF7/3wOmBZEALgAAEzMWFxYzMjY1NCcmJyY1NDc2MzIWFw4BByMuASMiBhUUFxYXFhUUBwYjIiYnPgGDFEREUXN9oqacmaiHe8RQoDcMIwoUH4Vaa5ennJyolo3ZVMUzDBEBDmwvOq59nlRERWfCv2pgMTEdZCdUYIdqnFZGQ2K314N9QjkhWgAAAAEAKP/0BEkFdQAWAAABES4BIyIGBxEiBgc+ATU0JichBxcuAQKfGSkYGTMOoIWeAgYGAgQhBARO4QUS+uIEBAYCBR4IEA4dEg8iDT49Cg4AAQBF/98E7QV1AB0AABMREBcWITI3NhkBFjM3ERAAISIuAScmNREeATMyNvleaQEA529kIRk5/r7+7JjVqCIbJRobIysFdfzt/uR7iZ2OAQoC/ggI/NH+1/7CSJqHZpQDMwQECAAAAAABADH/+AVDBXUAIgAAARsBNx4BMzI2NwYAAwIHJyIGByYDCgEnHgEzMjY3FxsBMzYDUNV7EBIhFxIrDBj+5W6OHikNGAhbmXPbLRktHBk7E0mM+hQ5AdMCKQFYIQQEBgIv/XL+9v6sYggGArwBXgEJAgJYBAQGAsn+nP2RfQAAAAEAGP/4B+cFdQA0AAAJAR4BMzcXGwEzNjcSNzY3FjMyNjcBMzY3NjcTNx4BMzcGBwYHAS4BIyIHASMBLgEjIgcGIwGJ/o8ZLRxfPXesFEBWZjFOEyAZDiEKAYUVFBcQF+0xEyEWRhMtHAv+exIfFBkp/osQ/nMTHBMfDhIGAQoEawQECNn+Xv3jtvoBJ5bpQggGAvtoOjsvRgMGqAQECCt1TBr7iQQECAR/+4EEBAIGAAAAAAEASf/4BJcFdQApAAABEwsBHgEzMjY3FxMSEx4BMzI2NwcBBwEuASMiBgcCAwYHBgcuASMiBgcBQ+HpzR0xIBtAFGvZrKwSIRYTLQ4l/slmAdsdMx8eQhKmu2JeUmITIRYVLQwBZAFYAYEBOAQEBgKw/osBEgETBAQGAin+Spj8+gQEBgIBTgEkkaCJuAQEBgIAAAABAGb/+AT1BXUAIQAAAREuASMiBgcRAR4BMzI2NxYAFzYTNjceATMyNjcGBwMOAQMSGSkYGTMO/ggxLRUaRBQ6ARY1MJdlWh4ZGxItDlA/4R9CAm/9iQQEBgICUgMrBAQGAnX+F1I1ARa3rgQEBgJpZP6TK3YAAAABACQAAASrBXUAHgAANwE2EjcnIgcEIz4BNTQmJyEVBgcGBwIHBTIkMwcXISQCUjHFLep0b/60CgIGBgIENXCmnJO5fwE4YgGNTgQE+4EtA0BHARtIBAkYDh0SDyINKZTh09f+9MMEIT49AAABARb/EgJVBfwABwAABREhFSMRMxUBFgE/xMTuBuo5+Yk6AAABAEUAAAO+BfwACAAAEwEuASMiBwEXxAL6Dy0KKRD9Bj0F/PoEAgIEBfwEAAEAVv8SAZUF/AAHAAABESE1MxEjNQGV/sHFxQX8+RY6Bnc5AAEAagI1BG4FdQAGAAATIwEzASMB+Y8BvogBvo/+jwI1A0D8wAKcAAABAAD+uAQA/wYAAwAAASE1IQQA/AAEAP64TgAAAQAoBEIB6wWaAA4AAAEjJSYvATc2OwEWFx4BFwHrRv68GBkIBA40FAwNFC0NBELIFxYhGSkHBg4vDAAAAgBe/+cDwgPbACcANgAAAREHFBYzNxUGDwEiJicHBiMiJjU0Njc2NzY1NCYjIgcGByM1PgEzIAMRBwYHBhUUFjMyNjc+AQNQBBQhQRojSjtICBCErHKgjfBoIVB7d2RIOQwZUKBcAUykSrYre2hhK1wcESkCg/4lHSklDS0PBgg5RhWDjnB5hSkRChtRc381KTFyODv88gErDCUVN3lgYC0gDSkAAAAAAgCH/+cEKQX8ABgAJwAAMxEXNxE2NzYzMhcWFRQHBiMiJyYnBgcGBwEiBwYVFBYzMjc2NTQnJodSUkVOWnPLcGN5g9NvVDcpHSk7CgGuolBBmYWcUkJCSgX8BAT9CmczO5eGvtmapjYiPBUnNwgDhZV706jNnH2ysGh1AAEAVv/nA6oD2wAhAAABByMuAScuASMiBwYVFBYzMjc2NxcHDgEjIicmNTQAMzIWA6otEAMiFSFuOqdhWMuqVkQzTgwMRJ5W+o2FASXrYZUDhYcCMRMmLIJ2rsf4IxtFBF41NpSL4eoBCiUAAAIASf/nA+cF/AAUACQAAAERJyIGBzUGIyInJjU0EjMyFhcRFwM0JyYjIgcGFRQXFjMyNzYD51IXGCOD3blsdfDGa508UlI8S5CySDU8SZKfUEAF/Pn8CAIGydp7g/bbASVmYwLqBPwImmiDk23Hm2uDnn0AAgBF/+cDugPbABsAJAAAJQcOASMiADU0NzYzMhcWHQEiJCMhBxQWMzI3NgEhNCcmIyIHBgONBFCyX9n+9nd/4axzf0j+sgj+3QS/qlxaOf2sAiEzQIuHUkrNazlCAQ/t3omRcXzeLQkppN0xHgGknFpvcWYAAAAAAQAo//gCagX8ACIAABcRIzUzNzY3NjsBDgEVBycmIyIGFRQXFhczBxcjES4BIyIGs4uLBBtSbLEpBQgIKSUlXFANDATRBATNFCUZFC8IA4lOENGNvxVaNQgUDXlgNkU2GCkl/HcEBAYAAAAAAwBJ/eMDxgPbAAwAQQBPAAAlIBUUFjMyNzY1NCcmARUnHgEVFAcGKwEiBwYVFBY7ASARFAQjIicmNTQ2NzUmJyY1NDc2NyYnJjU0NzY7AQUXMjYBBxQWMzI2NTQnJiMiBgID/sWgh4NWalw/AR/iREyBdcElKxopWmuDAWT+3+eSaHtxZDUdKScdR2ItNVhixxwBGzkXNf1eBHtnbHkxN3VteQz1eX05RoePMyMDx04VNIdUn1RMERg6PSX+7rLgRlKTa3sUEQwdK1RDKx8jLT9KbJhUXAwEBv7HFWqYmnCBRlCSAAAAAAEAn//4A9YF/AAbAAAXERc3ET4BMzIWFREnIgYHETQnJiMiBhURJyIGn1JSNahrrp1SFhkjLzWBiYFSFxgIBgQEBP0WYWjJyP2uCAIGAiWyTFakpP3PCAIAAAAAAgC0//gBhQWWAAkAFQAAAREnIgYHER4BMxMUBiMiJjU0NjMyFgFwUhYZIh4ZGmc+KSs/PyspPgPP/CkIAgYD1wQEAWQpPTsrK0A+AAIAAP3jAZEFlgAWACIAABcRHgEzNxEUBwYHDgErAScXMzI2Nz4BExQGIyImNTQ2MzIW2R8YG1IVHFIvczsNEBQVKUEVHRS4PSkrPz8rKT0IA9cEBAj8IZRWe04pMUIERzhFqAWeKT07KytAPgAAAAABAKP/+APiBfwAMQAAAREHFB8BMjc2PwIeATMyNjcVDgEHFhcWFxYXFS4BIyIGByYnJicmIyIVESciBgcRFwFHBAwMHz0lJ3+gHxgbEi0PjsprI3cQlGo7JCUdGzsQRHNadBsXGFIXGCNSBfz8aikSBgQ1IyODsAQEBgIRdrBjJ40SrHtEDAYCBgJah2uDIEn+WggCBgYEBAAAAAABAMz/+AFwBfwABwAAFxEXNxEnIgbMUlJSFxgIBgQEBPn8CAIAAAAAAQCT//gGHAPbADIAABcRHgEzNxU2NzYzMhYXPgEzMhcWFREnIgYHETQnJiMiBwYVESciBgcRECMiBwYVESciBpMfGBtSNURNaWSmIT2aaLVQR1IWGSMnNYmJOChSFxgj2ZI5K1IXGAgD1wQECLBcLTNsYWdmaF/K/a4IAgYCJaFMZ29Qjf3TCAIGAloBH1hCif2qCAIAAAABAJ//+APWA9sAHgAAFxEeATM3FT4BMzIWFREnIgYHETQnJiMiBwYVESciBp8fGBtSNahrsJtSFhkjKTWHlz41UhcYCAPXBAQIvWFoxM39rggCBgIlpEtlb17N/iEIAgACAD3/5wPCA9sADgAeAAATNAAzMhIVFAcGIyInJjUBIgcGFRQXFjMyNzY1NCcmQQEIy8HtdYHZuHuDAdOeUEFBTpSPTj03SAHs2wEU/u7i04+ef4jQAdyUeb6ucYemg56ocJIAAgCH/ewEJQPbAA8ALAAAARQXFjMyNzY1NCcmIyIHBhEuASMiBgcRHgEzMjY3FTY3NjMyFxYVFAIjIiYnAStIT5iPSD85SJmgTj0VJRgVLw4UJRkUMA49I2CgvXJr9MdsmDcBy7BncoN0w7Jmgp59+3EEBAYCBeMEBAYC0WYhVo+Fw/j+22VkAAIASf3sA+cD2wAPACcAAAE0JyYjIgcGFRQXFjMyNzYRHgEzNxEnIgYHEQYjIicmNTQSMzIXFhcDQ0pSj5hFPjpNrIFMRh8YG1JSFxgjadfOe3HXw49mRiEBy75/jnVnur5tk3hvAqYEBAj6HQgCBgLAxZqN1d4BGlY7UAABAKP/+AKTA9sAGQAAFxEeATM3FTc2NzYzMhcHJiciBw4BFREnIgajHxgbUgg5PEdGIx8dMTFSMTAaUhcYCAPXBAQIzRlWMTkMrBARMjlqY/3sCAIAAAAAAQBW/+cC0QPbACYAADczHgEzMjY1NCQ1NDYzMhcWFwYHIy4BIyIGFRQEFRQHBiMiJzY3NoMQKX1EUnf+HL+RSEUyJx8TEBdgOVJmAeN5bJSPcxAJEMFAWGhUfYy+j6ASDRZKSjhQVlJ7nKyZXVJGMRkxAAABABT/5wItBNkAHwAAEzcRMwcXIxEHFBcWMzI2NxUOASMiJyY1NxEjNjU0JzOTpNkEBNkEKyVLGzMRKV8keThBBH8EBH8EmEH+9i0h/fxGlzwzDAUyEBk8RaIhAlYMGR0MAAAAAQBR/+cDjAPPABwAAAERJyIGBzUGIyImNREeATM3ERQWMzI3NjURHgEzA4xSFhkiZ+Gqph8YG1JuiI0/Mh4ZGgPP/CkIAga0xb/PAloEBAj916ysblSKAjUEBAABACj/+APaA88AHQAAARMeATMyNwYHBgcGByciByYCJxYzMjY3FhIXPgE3ArOkDh0XEDEvVkxOXCc9GSk96mo5JRM1EiumXgIlAgIUAbsEBAhlvqq64HAICK4CQegIBgKQ/lDXBDIEAAEAJP/4BhgDzwAvAAABBgcGBwYHJwcmAicGAgcnIgYHCgEnHgEzMjY3FhIXNhI3FzcWEhc2NzY3HgEzMjYGGDM6VkNbOTk1K5Q/NJtINQ8gC16uXBQpHRM1Ej50UDq4LTU1K5RITV1kIQ4dFg8iA89rf76o36gICKABrptm/mbpCAYCASUB2dkEBAYC2f6dvnkB75IICKz+VqSy6PlnBAQGAAAAAQA9//gDwgPPACsAAAkBHgEzMjYzFhcWFz8BHgEzMjY3BgcGBwEVJyIGBy4BJwYHBgcuASMiBgc1AbL+ixktICsyDitSTD1zrBAhFBErDlJsc0wBfV4ZORAym1JMRmA1GRQQEyEKAd8B8AQECFB3bkiT6gQEBgJYfYVh/fwYCAYCVOltY2SJWgYCBgIYAAAAAQA1/ewD4wPPAB8AACUBHgEzMjY3FhIXNhI3HgEzMjcCBwIHAgcuASMiBwYjAdP+YhktHBc5Ez2LZ0G3OxAhFRAx0xakOn1TEx8UHQ4TCAQDywQEBgLB/p7XhwHJqgQECP4rMf6Xhf7j0gQEAgYAAAEALQAAA6YDwwAYAAAJATMyNyQzBxchNTY3Njc2NyMiBwQjNychA6b9hS9pbAFEJwkJ/JNch3V5cU0pXmD+4R8FBQMPA7L8oAYSNTUUcbCaoplrBhMxNgABAHb/EgJRBfwAIAAAAREUFhcjIiY1ETQmJz4BNRE0NzY7AQ4BFREUBwYHFhcWAaVOXimbezpiXEBJQpcdYkodImVnIhsBaP6scH8ThLABUG5mHRtmaQFsqEA3GXR1/pd4NkEbHUc3AAEBEgAAAZUF/AADAAAhETMRARKDBfz6BAAAAAABAFr/EgI1BfwAHgAAJRE0NzY3LgE1ETQmJzIXFhURFBYXDgEVERQGKwE+AQEGGyJnYkJKYqhEUz5eYDx+nCVeThABWIE4Rxsbe3gBaXB5GTNArP6UaWobG2Jw/rCwhBN9AAAAAQBqAVgEcgK4ABsAAAEXBgcGIyInJicmJyYjIgcGByc+ATMyBDMyNzYEKEozP1JfJz0ZlTchNSdIOyE1RkyHUEoBRzVCPTYCuFJgOUgVCD0XDBI9I1xSjWGQOjEAAAAAAwAo/98F2gWRAAsAFwA1AAAFIAAREAAhIAAREAAlMgA1EAAhIgARFAABBw4BIyImNTQkMzIWFw4BByMuASMiBhUUFjMyNzYC/f7T/lgBqAEtATEBrP5U/s/+AWz+lv8A/P6aAWgCGQ03i0zH5wEEx0GHPggNBAgWlj2QrLCDVFQhIQGsAS0BLQGs/lj+z/7T/lRrAXD+AQABc/6N/wD+/pABaE4iH9u+vdkdGBU3EyMzxJifuSEMAAQAO//bBfUFlgArAD0AUQBlAAABNCYnHgEzMjYzMh4CFRQOAgceAxcVJiMiBy4BJyMVFBcmIyIHPgE1Nx4BMzI+AjU0JiMiBgcOARUFNBI2JDMyBBYSFRQCBgQjIiQmAjcUHgIzMj4CNTQuAiMiDgICCAgHKVQrKVQpNl5FKTtWYCcnZGRdHi0hIi1MpFpCDSUdHyUFCmoLLxw0XkcpalQnSB4FCP3Jc8YBDZeYAQzHcnLH/vSYl/7zxnNWZK7uh4furmRkru6Hh+6uZAN5RZY5BAYKGDNOM0BcPiICMoWBahsKCgpu2m6PlJMKCkiPSNEFBBcxUDdQWgYEL2Iw2ZgBDMdzc8f+9JiX/vPGc3PGAQ2Xh++zaGiz74eH8LJpabLwAAABAF0AAAOhBZsADwAAARUjESMRIxEjES4BNTQ2MwOhf1KmVK7L17IFm0b6qwVV+qsC4gi9l53AAAMAIP/3BTcHMwACABIAJwAAAQsBASMlJicmPQE2OwEWFx4BFxMBLgEjIgYHAgMhDgEHLgEjIgYHAQNn4eIBvUb+vRkYBQ83EA0MFS0McQJnFzkbHz0TYHX9+FZaHRwZFBUpDAJ/AnsCDP30A2DJFhcIGRgpBgYOMAz+tPpmAgYGAgEhAQzT92MGAgYCBZoAAAMAIP/3BTcHMwACABIAJwAAAQsBAT4BNzY3MzIXFRQHBgcFIxcBLgEjIgYHAgMhDgEHLgEjIgYHAQNn4eIBRA0tFA0MEDgOBBkY/rxG6gJnFzkbHz0TYHX9+FZaHRwZFBUpDAJ/AnsCDP30BGIMMA4GBikYGQgXFslK+mYCBgYCASEBDNP3YwYCBgIFmgAAAAMAIP/3BTcH0QACABcAQQAAAQsBCQEuASMiBgcCAyEOAQcuASMiBgcBAzc2Nz4BMzIeARcWFRQGDwIOAQ8BIzU0Nj8CNjc0JwYHFhcUBgciJgNn4eIBLAJnFzkbHz0TYHX9+FZaHRwZFBUpDAJ/sRUGEhFiMSUdUBIxKyMzJxAGAgU1CgdSEgoEYjUVDQQjIx8vAnsCDP30Axb6ZgIGBgIBIQEM0/djBgIGAgWaAbE3EA8UJQYbGDJFGUcrJxsQFQZIPhIzC2wnHyFJDQkcGRgfKwQvAAAAAAMAIP/3BTcG7gACABcAOAAAAQsBCQEuASMiBgcCAyEOAQcuASMiBgcBJyM+ATMyHgEfAR4BFzI+AjczBgcGIyInJicuASMHDgEDZ+HiASwCZxc5Gx89E2B1/fhWWh0cGRQVKQwCf+QxEGlDISEWL0IQFQwTJBMSBjYVLTVKLScfEBs9GykWGwJ7Agz99AMW+mYCBgYCASEBDNP3YwYCBgIFmoxUcAwKGyEEBgIVGikTWDhBEhMIDh8ICScAAwAg/skFNwWRAAIAFwAjAAABCwEJAS4BIyIGBwIDIQ4BBy4BIyIGBwETIiY1NDYzMhYVFAYDZ+HiASwCZxc5Gx89E2B1/fhWWh0cGRQVKQwCfwwlOTklJzc5AnsCDP30Axb6ZgIGBgIBIQEM0/djBgIGAgWa+Tg5JSU5NyclOQADACD/9wU3Bz8AAgAXAB4AAAELAQkBLgEjIgYHAgMhDgEHLgEjIgYHAScjEzMTIycDZ+HiASwCZxc5Gx89E2B1/fhWWh0cGRQVKQwCf+NG/m/+Ru4CewIM/fQDFvpmAgYGAgEhAQzT92MGAgYCBZpWAVj+qNoAAAAEACD/9wU3CLQAAgAXAB4ALgAAAQsBCQEuASMiBgcCAyEOAQcuASMiBgcBJyMTMxMjJyUjJSYnJj0BNjsBFhceARcDZ+HiASwCZxc5Gx89E2B1/fhWWh0cGRQVKQwCf+NG/m/+Ru4BdEX+vBgZBA44EAwNFC0MAnsCDP30Axb6ZgIGBgIBIQEM0/djBgIGAgWaVgFY/qjam8kWFwgZGCkGBg4wDAAAAAAEACD/9wU8CFYAAgAXAB4ALQAAAQsBCQEuASMiBgcCAyEOAQcuASMiBgcBJyMTMxMjJwEFIwE3NjczMh8BFAcOAQNn4eIBLAJnFzkbHz0TYHX9+FZaHRwZFBUpDAJ/3EX+bv5G7QJO/rxGAQMxHh8RLw4ECAQlAnsCDP30Axb6ZgIGBgIBIQEM0/djBgIGAgWaVgFY/qjaAQLJAQIxFRQtIRAIDRoAAAAEACD/9wU3CK4AAgAXAB4ASAAAAQsBCQEuASMiBgcCAyEOAQcuASMiBgcBJyMTMxMjJxM3Njc+ATMyHgEXFhUUBg8CDgEPASM1NDY/AjY3NCcGBxYXFAYHIiYDZ+HiASwCZxc5Gx89E2B1/fhWWh0cGRQVKQwCf+NG/m/+Ru4/FQYSEWIxJR1QEjErIzMnEAYCBTUKB1ISCgRiNRUNBCMjHy8CewIM/fQDFvpmAgYGAgEhAQzT92MGAgYCBZpWAVj+qNoBXjcQDxQlBhsYMkUZRysnGxAVBkg+EjMLbCcfIUkNCRwZGB8rBC8AAAQAIP/3BTcIRAACABcAHgA/AAABCwEJAS4BIyIGBwIDIQ4BBy4BIyIGBwEnIxMzEyMvASM+ATMyHgEfAR4BFzI+AjczBgcGIyInJicuASMHDgEDZ+HiASwCZxc5Gx89E2B1/fhWWh0cGRQVKQwCf+NG/m/+Ru7yMRBpQyEhFi9CEBUMEyQTEgY2FS01Si0nHxAbPRspFhsCewIM/fQDFvpmAgYGAgEhAQzT92MGAgYCBZpWAVj+qNqyVHAMChshBAYCFRopE1g4QRITCA4fCAknAAAABAAg/skFNwc/AAIAFwAeACoAAAELAQkBLgEjIgYHAgMhDgEHLgEjIgYHAScjEzMTIycDIiY1NDYzMhYVFAYDZ+HiASwCZxc5Gx89E2B1/fhWWh0cGRQVKQwCf+NG/m/+Ru4CJTk5JSc3OQJ7Agz99AMW+mYCBgYCASEBDNP3YwYCBgIFmlYBWP6o2vgIOSUlOTcnJTkAAAADACD/9wU3Bs0AAgAXACQAAAELAQkBLgEjIgYHAgMhDgEHLgEjIgYHCQEOASMiJiczHgEzMjcDZ+HiASwCZxc5Gx89E2B1/fhWWh0cGRQVKQwCfwEjF417bJIQThxrRZQ5AnsCDP30Axb6ZgIGBgIBIQEM0/djBgIGAgWaATxxgYtnPEN/AAAABAAg//cFNwgcAAIAFwAkADQAAAELAQkBLgEjIgYHAgMhDgEHLgEjIgYHCQEOASMiJiczHgEzMjcHIyUmJyY9ATY7ARYXHgEXA2fh4gEsAmcXORsfPRNgdf34VlodHBkUFSkMAn8BIxeNe2ySEE4ca0WUOYVG/r0ZGAUPNxANDBUtDAJ7Agz99AMW+mYCBgYCASEBDNP3YwYCBgIFmgE8cYGLZzxDfwnJFhcIGRgpBgYOMAwABAAg//cFNwgcAAIAFwAkADQAAAELAQkBLgEjIgYHAgMhDgEHLgEjIgYHCQEOASMiJiczHgEzMj8BPgE3NjczMhcVFAcGBwUjA2fh4gEsAmcXORsfPRNgdf34VlodHBkUFSkMAn8BIxeNe2ySEE4ca0WUOSUNLRQNDBA4DgQZGP68RgJ7Agz99AMW+mYCBgYCASEBDNP3YwYCBgIFmgE8cYGLZzxDf/kMMA4GBikYGQgXFskABAAg//cFNwinAAIAFwAkAE4AAAELAQkBLgEjIgYHAgMhDgEHLgEjIgYHCQEOASMiJiczHgEzMjcBNzY3PgEzMh4BFxYVFAYPAg4BDwEjNTQ2PwI2NzQnBgcWFxQGByImA2fh4gEsAmcXORsfPRNgdf34VlodHBkUFSkMAn8BIxeNe2ySEE4ca0WUOf5yFQYSEWIxJR1QEjErIzMnEAYCBTUKB1ISCgRiNRUNBCMjHy8CewIM/fQDFvpmAgYGAgEhAQzT92MGAgYCBZoBPHGBi2c8Q38BSzcQDxQlBhsYMkUZRysnGxAVBkg+EjMLbCcfIUkNCRwZGB8rBC8ABAAg//cFNwfXAAIAFwAkAEUAAAELAQkBLgEjIgYHAgMhDgEHLgEjIgYHCQEOASMiJiczHgEzMjclIz4BMzIeAR8BHgEXMj4CNzMGBwYjIicmJy4BIwcOAQNn4eIBLAJnFzkbHz0TYHX9+FZaHRwZFBUpDAJ/ASMXjXtskhBOHGtFlDn+XTEQaUMhIRYvQhAVDBMkExIGNhUtNUotJx8QGz0bKRYbAnsCDP30Axb6ZgIGBgIBIQEM0/djBgIGAgWaATxxgYtnPEN/OVRwDAobIQQGAhUaKRNYOEESEwgOHwgJJwAABAAi/nsFMgbbACQALABAAEwAAAEWGgIeARcuASMiBgcuAycuASMiBgcGAgcuASMiBgcSABMLATIWMzI2NwEeATMyPgI3MxQOAiMiLgI1EzQ2MzIWFRQGIyImAsoxdXd0Z1YaHDMdHTMdDjE6PxtBh0Q/e0BBaxoVJRITJRSmAT2eHd81czU6cjr+fg5bWzBBLh0LOiE/X0BAYEAhWz4rKz09Kys+BZZ3/u3+5P7r8rw3BAYGBDWFkpVEAgICAqD+3WIEBgYEAWoCyQFt/uv9+AQCAgRiS1IWJzslNF1IKSlIXTT4CSs9PSsrPj4AAAAAAgC4AAAEUgczAB8ALwAAEyEHFy4BIychESEyNjMGFRciJiMhERcyNjcyNjcHFyEBIyUmJyY9ATY7ARYXHgEXuAONBAQnaCnN/qwB9B97HggIHnsf/gxWd8+NN2cfBAT8ZgKsRv69GRgEDjcRDAwVLQwFdT49CAwE/gAJIRU5DP2qBAYGDQQ+PQXbyRYXCBkYKQYGDjAMAAACALgAAARSBzMAHwAvAAATIQcXLgEjJyERITI2MwYVFyImIyERFzI2NzI2NwcXIQE+ATc2NzMyFxUUBwYHBSO4A40EBCdoKc3+rAH0H3seCAgeex/+DFZ3z403Zx8EBPxmAfAMLRQNDBA4DgQZGP68RQV1Pj0IDAT+AAkhFTkM/aoEBgYNBD49Bt0MMA4GBikYGQgXFskAAAIAuAAABFIH0QAfAEkAABMhBxcuASMnIREhMjYzBhUXIiYjIREXMjY3MjY3BxchEzc2Nz4BMzIeARcWFRQGDwIOAQ8BIzU0Nj8CNjc0JwYHFhcUBgciJrgDjQQEJ2gpzf6sAfQfex4ICB57H/4MVnfPjTdnHwQE/Gb6FAYTEGMxJRxQEzErIzMnEQYCBDUKBlITCgRiNhQMBCMiHy8FdT49CAwE/gAJIRU5DP2qBAYGDQQ+PQdCNxAPFCUGGxgyRRlHKycbEBUGSD4SMwtsJx8hSQ0JHBkYHysELwACALgAAARSBu4AHwBAAAATIQcXLgEjJyERITI2MwYVFyImIyERFzI2NzI2NwcXIRMjPgEzMh4BHwEeARcyPgI3MwYHBiMiJyYnLgEjBw4BuAONBAQnaCnN/qwB9B97HggIHnsf/gxWd8+NN2cfBAT8ZtcxEGlDISEWL0IQFQwTJBMSBjYVLTVKLSceERo+GykWGwV1Pj0IDAT+AAkhFTkM/aoEBgYNBD49Bh1UcAwKGyEEBgIVGikTWDhBEhMIDh8ICScAAgC4/nsEUgV1AB8AKwAAEyEHFy4BIychESEyNjMGFRciJiMhERcyNjcyNjcHFyEBNDYzMhYVFAYjIia4A40EBCdoKc3+rAH0H3seCAgeex/+DFZ3z403Zx8EBPxmAWQ+Kys9PSsrPgV1Pj0IDAT+AAkhFTkM/aoEBgYNBD49/uQrPT0rKz4+AAIAuAAABFIHPwAfACYAABMhBxcuASMnIREhMjYzBhUXIiYjIREXMjY3MjY3BxchEyMTMxMjJ7gDjQQEJ2gpzf6sAfQfex4ICB57H/4MVnfPjTdnHwQE/GbdRf5u/kbtBXU+PQgMBP4ACSEVOQz9qgQGBg0EPj0F5wFY/qjaAAAAAwC4AAAEUgi0AB8AJgA2AAATIQcXLgEjJyERITI2MwYVFyImIyERFzI2NzI2NwcXIRMjEzMTIyclIyUmJyY9ATY7ARYXHgEXuAONBAQnaCnN/qwB9B97HggIHnsf/gxWd8+NN2cfBAT8ZudG/m/+Ru4BdEX+vBgZBA44EAwNFC0MBXU+PQgMBP4ACSEVOQz9qgQGBg0EPj0F5wFY/qjam8kWFwgZGCkGBg4wDAAAAAADALgAAAULCGYAHwAmADYAABMhBxcuASMnIREhMjYzBhUXIiYjIREXMjY3MjY3BxchEyMTMxMjJwE+ATc2NzMyFxUUBwYHBSO4A40EBCdoKc3+rAH0H3seCAgeex/+DFZ3z403Zx8EBPxm50b+b/5G7gG/DC0VDAwRNw4EGBn+vUYFdT49CAwE/gAJIRU5DP2qBAYGDQQ+PQXnAVj+qNoBTwwwDgYGKRgZCBcWyQAAAAMAuAAABHUIrgAfACYAUAAAEyEHFy4BIychESEyNjMGFRciJiMhERcyNjcyNjcHFyETIxMzEyMnEzc2Nz4BMzIeARcWFRQGDwIOAQ8BIzU0Nj8CNjc0JwYHFhcUBgciJrgDjQQEJ2gpzf6sAfQfex4ICB57H/4MVnfPjTdnHwQE/GbnRv5v/kbuPxUGEhFiMSUdUBIxKyMzJxAGAgQ2CwZSEgoEYjUVDQQjIx8vBXU+PQgMBP4ACSEVOQz9qgQGBg0EPj0F5wFY/qjaAV43EA8UJQYbGDJFGUcrJxsQFQZIPhIzC2wnHyFJDQkcGRgfKwQvAAADALgAAARSCEQAHwAmAEcAABMhBxcuASMnIREhMjYzBhUXIiYjIREXMjY3MjY3BxchEyMTMxMjLwEjPgEzMh4BHwEeARcyPgI3MwYHBiMiJyYnLgEjBw4BuAONBAQnaCnN/qwB9B97HggIHnsf/gxWd8+NN2cfBAT8Zt1G/m/+Ru7yMRBpQyEhFjBBEBUMEyUSEgc1FS01Si0nHhEaPhsoFxsFdT49CAwE/gAJIRU5DP2qBAYGDQQ+PQXnAVj+qNqyVHAMChshBAYCFRopE1g4QRITCA4fCAknAAAAAwC4/nsEUgc/AB8AJgAyAAATIQcXLgEjJyERITI2MwYVFyImIyERFzI2NzI2NwcXIRMjEzMTIycDNDYzMhYVFAYjIia4A40EBCdoKc3+rAH0H3seCAgeex/+DFZ3z403Zx8EBPxm3UX+bv5G7Ws+Kys9PSsrPgV1Pj0IDAT+AAkhFTkM/aoEBgYNBD49BecBWP6o2vgjKz09Kys+PgAAAAIAHP/4Ad8HMwANABwAABcRHgEzMjYzES4BIyIGASMlJi8BNzY7ARYXHgEXxBQpHSMrDBgpGRkzAQ1G/rwYGQgEDjQUDA0ULQ0IBX0EBAj6gwQEBgXhyRYXIRgpBgYOMAwAAAACAGL/+AIlBzcADQAcAAAXER4BMzI2MxEuASMiBgEFIwE3NjczMh8BFAcOAcQVKRwjKw0ZKRkYMwEY/r1GAQIxHx8MMw4FCQQlCAV9BAQI+oMEBAYGqskBAjEVFC0hEAgMGwAAAgBY//gB/geiAA0ANwAAFxEeATMyNjMRLgEjIgYDNzY3PgEzMh4BFxYVFAYPAg4BDwEjNTQ2PwI2NzQnBgcWFxQGByImxRQpHSIrDRkpGBkzexQHEhBjMSUcUBMxKyMzJxAHAgQ1CgZSEwoEYjMXDAQiIx8vCAV9BAQI+oMEBAYHGDgQDhUlBhsZMUUZSCsnGhEUBkg+EjMKbScfIEoMCBwZGR4rBC8AAgAI//gCVgbuAA0ALgAAFxEeATMyNjMRLgEjIgYDIz4BMzIeAR8BHgEzMj4CNzMGBwYjIicmJy4BIyIOAcQVKR0iKw0ZKRgZM5oxEGVDJSEWMEEGIQYXKQ4SBzUVLTVKLSceERxAGwwvGwgFfQQECPqDBAQGBiNUcAwKGyECChsUKRNYOEESEwgOHxEnAAAAAgDE/skBhQV1AA0AGQAAFxEeATMyNjMRLgEjIgYTIiY1NDYzMhYVFAbEFCkdIysMGCkZGDRUJTk5JSc4OggFfQQECPqDBAQG/s85JSU5NyclOQAAAwAc/98FLgczABAAHQAtAAABNC4CIyIAERAXFjMyNzY1ASAAERAAISAXFhEQAAMjJSYnJj0BNjsBFhceARcEgi2BvGnj/vyJgc3siW7+Ff7j/qIBagEVARC1zv6QrkX+vBgZBA44EAwNFC0MAsWTzcJp/on+x/7TrKLpu9v9OwGQAUkBSgGPpb/+qP6s/l4F/MkWFwgZGCkGBg4wDAAAAAMAHP/fBS4HMwAQAB0ALQAAATQuAiMiABEQFxYzMjc2NQEgABEQACEgFxYREAADPgE3NjczMhcVFAcGBwUjBIItgbxp4/78iYHN7Ilu/hX+4/6iAWoBFQEQtc7+kIEMLRUMDBE3DgQYGf69RgLFk83Caf6J/sf+06yi6bvb/TsBkAFJAUoBj6W//qj+rP5eBv4MMA4GBikYGQgXFskAAAADABz/3wUuB9EAEAAdAEcAAAE0LgIjIgAREBcWMzI3NjUBIAAREAAhIBcWERAAATc2Nz4BMzIeARcWFRQGDwIOAQ8BIzU0Nj8CNjc0JwYHFhcUBgciJgSCLYG8aeP+/ImBzeyJbv4V/uP+ogFqARUBELXO/pD+FBUGEhFiMSUdUBIxKyMzJxAGAgQ2CwZSEgoEYjUVDQQjIx8vAsWTzcJp/on+x/7TrKLpu9v9OwGQAUkBSgGPpb/+qP6s/l4HYzcQDxQlBhsYMkUZRysnGxAVBkg+EjMLbCcfIUkNCRwZGB8rBC8AAAAAAwAc/98FLgbuABAAHQA+AAABNC4CIyIAERAXFjMyNzY1ASAAERAAISAXFhEQAAEjPgEzMh4BHwEeARcyPgI3MwYHBiMiJyYnLgEjBw4BBIItgbxp4/78iYHN7Ilu/hX+4/6iAWoBFQEQtc7+kP3xMRFoRCAhFy9BERQNEiUSEwY1FC02SS0nHxAbPhopFxoCxZPNwmn+if7H/tOsoum72/07AZABSQFKAY+lv/6o/qz+XgY+VHAMChshBAYCFRopE1g4QRITCA4fCAknAAAAAAMAHP57BS4FkQAQAB0AKQAAATQuAiMiABEQFxYzMjc2NQEgABEQACEgFxYREAAFNDYzMhYVFAYjIiYEgi2BvGnj/vyJgc3siW7+Ff7j/qIBagEVARC1zv6Q/n8+Kys9PSsrPgLFk83Caf6J/sf+06yi6bvb/TsBkAFJAUoBj6W//qj+rP5e+ys9PSsrPj4AAAMAHP/fBS4HPwAQAB0AJAAAATQuAiMiABEQFxYzMjc2NQEgABEQACEgFxYREAABIxMzEyMnBIItgbxp4/78iYHN7Ilu/hX+4/6iAWoBFQEQtc7+kP34Rv5v/UXuAsWTzcJp/on+x/7TrKLpu9v9OwGQAUkBSgGPpb/+qP6s/l4GCAFY/qjaAAAEABz/3wUuCLQAEAAdACQANAAAATQuAiMiABEQFxYzMjc2NQEgABEQACEgFxYREAABIxMzEyMnJSMlJicmPQE2OwEWFx4BFwSCLYG8aeP+/ImBzeyJbv4V/uP+ogFqARUBELXO/pD99EX+bv5F7gF0Rf68GRgEDjcRDAwVLQwCxZPNwmn+if7H/tOsoum72/07AZABSQFKAY+lv/6o/qz+XgYIAVj+qNqbyRYXCBkYKQYGDjAMAAAABAAc/98FLghmABAAHQAkADQAAAE0LgIjIgAREBcWMzI3NjUBIAAREAAhIBcWERAAASMTMxMjJwE+ATc2NzMyFxUUBwYHBSMEgi2BvGnj/vyJgc3siW7+Ff7j/qIBagEVARC1zv6Q/fRF/m7+Re4BvwwtFQwMETcOBBkY/rxFAsWTzcJp/on+x/7TrKLpu9v9OwGQAUkBSgGPpb/+qP6s/l4GCAFY/qjaAU8MMA4GBikYGQgXFskAAAQAHP/fBS4IrgAQAB0AJABOAAABNC4CIyIAERAXFjMyNzY1ASAAERAAISAXFhEQAAEjEzMTIycTNzY3PgEzMh4BFxYVFAYPAg4BDwEjNTQ2PwI2NzQnBgcWFxQGByImBIItgbxp4/78iYHN7Ilu/hX+4/6iAWoBFQEQtc7+kP30Rf5u/kXuPxQHEhBjMSUcUBMxKyMzJxAHAgQ1CgZSEwoEYjYUDAQiIx8vAsWTzcJp/on+x/7TrKLpu9v9OwGQAUkBSgGPpb/+qP6s/l4GCAFY/qjaAV43EA8UJQYbGDJFGUcrJxsQFQZIPhIzC2wnHyFJDQkcGRgfKwQvAAQAHP/fBS4IRAAQAB0AJABFAAABNC4CIyIAERAXFjMyNzY1ASAAERAAISAXFhEQAAEjEzMTIy8BIz4BMzIeAR8BHgEXMj4CNzMGBwYjIicmJy4BIwcOAQSCLYG8aeP+/ImBzeyJbv4V/uP+ogFqARUBELXO/pD99EX+bv5F7vIxEGhEISEWL0IQFQwSJRMSBjUULTVKLScfEBs9GykWGwLFk83Caf6J/sf+06yi6bvb/TsBkAFJAUoBj6W//qj+rP5eBggBWP6o2rJUcAwKGyEEBgIVGikTWDhBEhMIDh8ICScAAAQAHP57BS4HPwAQAB0AJAAwAAABNC4CIyIAERAXFjMyNzY1ASAAERAAISAXFhEQAAEjEzMTIycDNDYzMhYVFAYjIiYEgi2BvGnj/vyJgc3siW7+Ff7j/qIBagEVARC1zv6Q/fhG/m/9Re5qPisrPT0rKz4CxZPNwmn+if7H/tOsoum72/07AZABSQFKAY+lv/6o/qz+XgYIAVj+qNr4Iys9PSsrPj4AAAIARf/fBO0HMwAdAC0AABMREBcWITI3NhkBFjM3ERAAISIuAScmNREeATMyNiUjJSYnJj0BNjsBFhceARf5XmkBAOdvZCEZOf6+/uyY1agiGyUaGyMrAotF/rwZGAQONxEMDBUtDAV1/O3+5HuJnY4BCgL+CAj80f7X/sJImodmlAMzBAQIZskWFwgZGCkGBg4wDAACAEX/3wTtBzMAHQAtAAATERAXFiEyNzYZARYzNxEQACEiLgEnJjURHgEzMjYBPgE3NjczMhcVFAcGBwUj+V5pAQDnb2QhGTn+vv7smNWoIhslGhsjKwJQDC0VDAwRNw4EGBn+vUYFdfzt/uR7iZ2OAQoC/ggI/NH+1/7CSJqHZpQDMwQECAFoDDAOBgYpGBkIFxbJAAAAAAIARf/fBO0H0QAdAEcAABMREBcWITI3NhkBFjM3ERAAISIuAScmNREeATMyNhM3Njc+ATMyHgEXFhUUBg8CDgEPASM1NDY/AjY3NCcGBxYXFAYHIib5XmkBAOdvZCEZOf6+/uyY1agiGyUaGyMr5RUGEhFiMSUdUBIxKyMzJxAGAgQ2CwZSEgoEYjUVDQQjIx8vBXX87f7ke4mdjgEKAv4ICPzR/tf+wkiah2aUAzMEBAgBzTcQDxQlBhsYMkUZRysnGxAVBkg+EjMLbCcfIUkNCRwZGB8rBC8AAAACAEX/3wTtBu4AHQA+AAATERAXFiEyNzYZARYzNxEQACEiLgEnJjURHgEzMjY3Iz4BMzIeAR8BHgEXMj4CNzMGBwYjIicmJy4BIwcOAfleaQEA529kIRk5/r7+7JjVqCIbJRobIyvCMRFoRCEgFy9BERQNEiUSEwY1FC02SS0nHxAbPRspFxoFdfzt/uR7iZ2OAQoC/ggI/NH+1/7CSJqHZpQDMwQECKhUcAwKGyEEBgIVGikTWDhBEhMIDh8ICScAAAAAAgBF/nsE7QV1AB0AKQAAExEQFxYhMjc2GQEWMzcREAAhIi4BJyY1ER4BMzI2ATQ2MzIWFRQGIyIm+V5pAQDnb2QhGTn+vv7smNWoIhslGhsjKwFQPisrPT0rKz4Fdfzt/uR7iZ2OAQoC/ggI/NH+1/7CSJqHZpQDMwQECPlvKz09Kys+PgAAAAEARf/fBcQGVAA1AAABMjY3PgE1NCcuASc1FzczBxUUBgcOASMREAAhIi4BJyY1ER4BMzI2MxEQFxYhMjc2GQEWMzcE7RA0EAYQEgY+AjpaMQQOJxtCQf6+/uyY1agiGyUaGyMrDF5pAQDnb2QhGTkFSAIYCxgRFhkKBAZ7CAQdai8lLR8X/TT+1/7CSJqHZpQDMwQECPzt/uR7iZ2OAQoC/ggIAAAAAAIARf/fBcQHMwAPAEUAAAEjJSYnJj0BNjsBFhceARcBMjY3PgE1NCcuASc1FzczBxUUBgcOASMREAAhIi4BJyY1ER4BMzI2MxEQFxYhMjc2GQEWMzcDeEX+vBkYBA43EQwMFS0MAncQNBAGEBIGPgI6WjEEDicbQkH+vv7smNWoIhslGhsjKwxeaQEA529kIRk5BdvJFhcIGRgpBgYOMAz+awIYCxgRFhkKBAZ7CAQdai8lLR8X/TT+1/7CSJqHZpQDMwQECPzt/uR7iZ2OAQoC/ggIAAAAAAIARf/fBcQHMwAPAEUAAAE+ATc2NzMyFxUUBwYHBSMFMjY3PgE1NCcuASc1FzczBxUUBgcOASMREAAhIi4BJyY1ER4BMzI2MxEQFxYhMjc2GQEWMzcDPQwtFQwMETcOBBgZ/r1GArIQNBAGEBIGPgI6WjEEDicbQkH+vv7smNWoIhslGhsjKwxeaQEA529kIRk5Bt0MMA4GBikYGQgXFsmTAhgLGBEWGQoEBnsIBB1qLyUtHxf9NP7X/sJImodmlAMzBAQI/O3+5HuJnY4BCgL+CAgAAgBF/98FxAfRACkAXwAAATc2Nz4BMzIeARcWFRQGDwIOAQ8BIzU0Nj8CNjc0JwYHFhcUBgciJgEyNjc+ATU0Jy4BJzUXNzMHFRQGBw4BIxEQACEiLgEnJjURHgEzMjYzERAXFiEyNzYZARYzNwHSFQYSEWIxJR1QEjErIzMnEAYCBDYLBlISCgRiNRUNBCMjHy8DGxA0EAYQEgY+AjpaMQQOJxtCQf6+/uyY1agiGyUaGyMrDF5pAQDnb2QhGTkHQjcQDxQlBhsYMkUZRysnGxAVBkg+EjMLbCcfIUkNCRwZGB8rBC/+JQIYCxgRFhkKBAZ7CAQdai8lLR8X/TT+1/7CSJqHZpQDMwQECPzt/uR7iZ2OAQoC/ggIAAACAEX/3wXEBu4AIABWAAABIz4BMzIeAR8BHgEXMj4CNzMGBwYjIicmJy4BIwcOAQUyNjc+ATU0Jy4BJzUXNzMHFRQGBw4BIxEQACEiLgEnJjURHgEzMjYzERAXFiEyNzYZARYzNwGvMRFoRCEgFy9BERQNEiUSEwY1FC02SS0nHxAbPRspFxoDMRA0EAYQEgY+AjpaMQQOJxtCQf6+/uyY1agiGyUaGyMrDF5pAQDnb2QhGTkGHVRwDAobIQQGAhUaKRNYOEESEwgOHwgJJ/cCGAsYERYZCgQGewgEHWovJS0fF/00/tf+wkiah2aUAzMEBAj87f7ke4mdjgEKAv4ICAAAAAIARf57BcQGVAALAEEAAAE0NjMyFhUUBiMiJgEyNjc+ATU0Jy4BJzUXNzMHFRQGBw4BIxEQACEiLgEnJjURHgEzMjYzERAXFiEyNzYZARYzNwI9PisrPT0rKz4CsBA0EAYQEgY+AjpaMQQOJxtCQf6+/uyY1agiGyUaGyMrDF5pAQDnb2QhGTn+5Cs9PSsrPj4GjwIYCxgRFhkKBAZ7CAQdai8lLR8X/TT+1/7CSJqHZpQDMwQECPzt/uR7iZ2OAQoC/ggIAAAAAgAc/98FLgY3ACIAMwAAATI+ATU0Jy4BJzUXNzMHFRQGBwYHHgEVEAAhIAAREAAhMhYTNC4CIyIAERAXFjMyNzY1BEUZOx0ZBj4COmYxBBwRKVBSXv6Q/tn+4/6iAWoBFXHfly2BvGnj/vyJgc3siW4E/hYpIychCgQGewgEHGstaBMvDFj+nv6s/l4BkAFJAUoBj0v9f5PNwmn+if7H/tOsoum72wAAAwAc/98FLgczAA8AMgBDAAABIyUmJyY9ATY7ARYXHgEXATI+ATU0Jy4BJzUXNzMHFRQGBwYHHgEVEAAhIAAREAAhMhYTNC4CIyIAERAXFjMyNzY1AxBF/rwYGQQOOBAMDRQtDAI3GTsdGQY+AjpmMQQcESlQUl7+kP7Z/uP+ogFqARVx35ctgbxp4/78iYHN7IluBdvJFhcIGRgpBgYOMAz+IRYpIychCgQGewgEHGstaBMvDFj+nv6s/l4BkAFJAUoBj0v9f5PNwmn+if7H/tOsoum72wAAAwAc/98FLgczAA8AMgBDAAABPgE3NjczMhcVFAcGBwUjBTI+ATU0Jy4BJzUXNzMHFRQGBwYHHgEVEAAhIAAREAAhMhYTNC4CIyIAERAXFjMyNzY1Az0MLRUMDBE3DgQYGf69RgIKGTsdGQY+AjpmMQQcESlQUl7+kP7Z/uP+ogFqARVx35ctgbxp4/78iYHN7IluBt0MMA4GBikYGQgXFsndFikjJyEKBAZ7CAQcay1oEy8MWP6e/qz+XgGQAUkBSgGPS/1/k83Caf6J/sf+06yi6bvbAAAAAwAc/98FLgfRACkATABdAAABNzY3PgEzMh4BFxYVFAYPAg4BDwEjNTQ2PwI2NzQnBgcWFxQGByImATI+ATU0Jy4BJzUXNzMHFRQGBwYHHgEVEAAhIAAREAAhMhYTNC4CIyIAERAXFjMyNzY1AdIVBhIRYjElHVASMSsjMycQBgIENgsGUhIKBGI1FQ0EIyMfLwJzGTsdGQY+AjpmMQQcESlQUl7+kP7Z/uP+ogFqARVx35ctgbxp4/78iYHN7IluB0I3EA8UJQYbGDJFGUcrJxsQFQZIPhIzC2wnHyFJDQkcGRgfKwQv/dsWKSMnIQoEBnsIBBxrLWgTLwxY/p7+rP5eAZABSQFKAY9L/X+TzcJp/on+x/7TrKLpu9sAAAAAAwAc/98FLgbuACAAQwBUAAABIz4BMzIeAR8BHgEXMj4CNzMGBwYjIicmJy4BIwcOAQEyPgE1NCcuASc1FzczBxUUBgcGBx4BFRAAISAAERAAITIWEzQuAiMiABEQFxYzMjc2NQGvMRFoRCAhFy9BERQNEiUSEwY1FC02SS0nHxAbPhopFxoCiRk7HRkGPgI6ZjEEHBEpUFJe/pD+2f7j/qIBagEVcd+XLYG8aeP+/ImBzeyJbgYdVHAMChshBAYCFRopE1g4QRITCA4fCAkn/r8WKSMnIQoEBnsIBBxrLWgTLwxY/p7+rP5eAZABSQFKAY9L/X+TzcJp/on+x/7TrKLpu9sAAAAAAwAc/nsFLgY3AAsALgA/AAABNDYzMhYVFAYjIiYBMj4BNTQnLgEnNRc3MwcVFAYHBgceARUQACEgABEQACEyFhM0LgIjIgAREBcWMzI3NjUCPT4rKz09Kys+AggZOx0ZBj4COmYxBBwRKVBSXv6Q/tn+4/6iAWoBFXHfly2BvGnj/vyJgc3siW7+5Cs9PSsrPj4GRRYpIychCgQGewgEHGstaBMvDFj+nv6s/l4BkAFJAUoBj0v9f5PNwmn+if7H/tOsoum72wACAGb/+AT1BzMAIQAxAAABES4BIyIGBxEBHgEzMjY3FgAXNhM2Nx4BMzI2NwYHAw4BEyMlJicmPQE2OwEWFx4BFwMSGSkYGTMO/ggxLRUaRBQ6ARY1MJdlWh4ZGxItDlA/4R9CGkX+vBgZBA44EAwNFC0MAm/9iQQEBgICUgMrBAQGAnX+F1I1ARa3rgQEBgJpZP6TK3YDQckWFwgZGCkGBg4wDAAAAAACAGb/+AT1BykAIQAxAAABES4BIyIGBxEBHgEzMjY3FgAXNhM2Nx4BMzI2NwYHAw4BEz4BNzY3MzIXFRQHBgcFIwMSGSkYGTMO/ggxLRUaRBQ6ARY1MJdlWh4ZGxItDlA/4R9CgQwtFQwMETcOBBgZ/r1GAm/9iQQEBgICUgMrBAQGAnX+F1I1ARa3rgQEBgJpZP6TK3YEOQwwDgYGKRgZCBcWyQAAAAACAGb/+AT1B9EAIQBLAAABES4BIyIGBxEBHgEzMjY3FgAXNhM2Nx4BMzI2NwYHAw4BATc2Nz4BMzIeARcWFRQGDwIOAQ8BIzU0Nj8CNjc0JwYHFhcUBgciJgMSGSkYGTMO/ggxLRUaRBQ6ARY1MJdlWh4ZGxItDlA/4R9C/ukUBhMQYjElHVASMSsiNCcQBgIENQoGUhILBGM1FAwEIyMeLwJv/YkEBAYCAlIDKwQEBgJ1/hdSNQEWt64EBAYCaWT+kyt2BKg3EA8UJQYbGDJFGUcrJxsQFQZIPhIzC2wnHyFJDQkcGRgfKwQvAAIAZv/4BPUG7gAhAEIAAAERLgEjIgYHEQEeATMyNjcWABc2EzY3HgEzMjY3BgcDDgEBIz4BMzIeAR8BHgEXMj4CNzMGBwYjIicmJy4BIwcOAQMSGSkYGTMO/ggxLRUaRBQ6ARY1MJdlWh4ZGxItDlA/4R9C/sYxEGhEISEWL0IQFQwSJRMSBjUULTVKLScfEBs9GykWGwJv/YkEBAYCAlIDKwQEBgJ1/hdSNQEWt64EBAYCaWT+kyt2A4NUcAwKGyEEBgIVGikTWDhBEhMIDh8ICScAAgBm/nsE9QV1ACEALQAAAREuASMiBgcRAR4BMzI2NxYAFzYTNjceATMyNjcGBwMOAQM0NjMyFhUUBiMiJgMSGSkYGTMO/ggxLRUaRBQ6ARY1MJdlWh4ZGxItDlA/4R9C1D4rKz09Kys+Am/9iQQEBgICUgMrBAQGAnX+F1I1ARa3rgQEBgJpZP6TK3b8Sis9PSsrPj4AAAADAF7/5wPCBZoAJwA2AEYAAAERBxQWMzcVBg8BIiYnBwYjIiY1NDY3Njc2NTQmIyIHBgcjNT4BMyADEQcGBwYVFBYzMjY3PgETIyUmJyY9ATY7ARYXHgEXA1AEFCFBGiNKO0gIEISscqCN8GghUHt3ZEg5DBlQoFwBTKRKtit7aGErXBwRKQZG/r0ZGAQONxEMDBUtDAKD/iUdKSUNLQ8GCDlGFYOOcHmFKREKG1FzfzUpMXI4O/zyASsMJRU3eWBgLSANKQN9yBcWCBkZKQcGDi8MAAMAXv/nA8IFmgAnADYARgAAAREHFBYzNxUGDwEiJicHBiMiJjU0Njc2NzY1NCYjIgcGByM1PgEzIAMRBwYHBhUUFjMyNjc+AQM+ATc2NzMyFxUUBwYHBSMDUAQUIUEaI0o7SAgQhKxyoI3waCFQe3dkSDkMGVCgXAFMpEq2K3toYStcHBEptgwtFA0MEDgOBBkY/rxFAoP+JR0pJQ0tDwYIOUYVg45weYUpEQobUXN/NSkxcjg7/PIBKwwlFTd5YGAtIA0pBH8MLw4GBykZGQgWF8gAAwBe/+cDwgX+ACcANgBgAAABEQcUFjM3FQYPASImJwcGIyImNTQ2NzY3NjU0JiMiBwYHIzU+ATMgAxEHBgcGFRQWMzI2Nz4BAzU0Nj8CNjc0JwYHFhcUBgciJjU3Njc+ATMyHgEXFhUUBg8CDgEPAQNQBBQhQRojSjtICBCErHKgjfBoIVB7d2RIOQwZUKBcAUykSrYre2hhK1wcESnACgZSEgoFYzUUDAQjIx4wFQYTEGIxJR1QEjErIjQnEAYCAgKD/iUdKSUNLQ8GCDlGFYOOcHmFKREKG1FzfzUpMXI4O/zyASsMJRU3eWBgLSANKQNxFhIzC2wnHyFJDQkcGRgfKwQvHzcQDxQlBhsYMkUZRysnGxAVBiAAAAADAF7/5wPCBUgAJwA2AFcAAAERBxQWMzcVBg8BIiYnBwYjIiY1NDY3Njc2NTQmIyIHBgcjNT4BMyADEQcGBwYVFBYzMjY3PgEBIz4BMzIfARYXHgEzMj4CNzMGBwYjIiYnJicmIwcOAQNQBBQhQRojSjtICBCErHKgjfBoIVB7d2RIOQwZUKBcAUykSrYre2hhK1wcESn+bDURakYgDVYjIgkeBhMlFBUGMRAwNUweG0onEiMWKRUeAoP+JR0pJQ0tDwYIOUYVg45weYUpEQobUXN/NSkxcjg7/PIBKwwlFTd5YGAtIA0pA7JScgQtFA0CChUeKw1WOkEIJRQJEAgIMAAAAAMAXv7JA8ID2wAnADYAQgAAAREHFBYzNxUGDwEiJicHBiMiJjU0Njc2NzY1NCYjIgcGByM1PgEzIAMRBwYHBhUUFjMyNjc+AQMiJjU0NjMyFhUUBgNQBBQhQRojSjtICBCErHKgjfBoIVB7d2RIOQwZUKBcAUykSrYre2hhK1wcESmcJTk5JSc3OQKD/iUdKSUNLQ8GCDlGFYOOcHmFKREKG1FzfzUpMXI4O/zyASsMJRU3eWBgLSANKf4EOSUlOTcnJTkAAAAAAwBe/+cDwgWFACcANgA9AAABEQcUFjM3FQYPASImJwcGIyImNTQ2NzY3NjU0JiMiBwYHIzU+ATMgAxEHBgcGFRQWMzI2Nz4BASMTMxMjJwNQBBQhQRojSjtICBCErHKgjfBoIVB7d2RIOQwZUKBcAUykSrYre2hhK1wcESn+TEb+b/1F7gKD/iUdKSUNLQ8GCDlGFYOOcHmFKREKG1FzfzUpMXI4O/zyASsMJRU3eWBgLSANKQNoAVj+qNkAAAAABABe/+cDwgbZACcANgA9AE0AAAERBxQWMzcVBg8BIiYnBwYjIiY1NDY3Njc2NTQmIyIHBgcjNT4BMyADEQcGBwYVFBYzMjY3PgEBIxMzEyMnJSMlJicmPQE2OwEWFx4BFwNQBBQhQRojSjtICBCErHKgjfBoIVB7d2RIOQwZUKBcAUykSrYre2hhK1wcESn+TEb+b/1F7gF5Rv69GRgEDjcRDAwVLQwCg/4lHSklDS0PBgg5RhWDjnB5hSkRChtRc381KTFyODv88gErDCUVN3lgYC0gDSkDaAFY/qjZe8kWFwgZGCkGBg8vDAAEAF7/5wRwBpMAJwA2AD0ATAAAAREHFBYzNxUGDwEiJicHBiMiJjU0Njc2NzY1NCYjIgcGByM1PgEzIAMRBwYHBhUUFjMyNjc+AQEjEzMTIyclBSMBNzY3MzIfARQHDgEDUAQUIUEaI0o7SAgQhKxyoI3waCFQe3dkSDkMGVCgXAFMpEq2K3toYStcHBEp/kxG/m/9Re4CTv69RgECMR8fDDMOBAgEJQKD/iUdKSUNLQ8GCDlGFYOOcHmFKREKG1FzfzUpMXI4O/zyASsMJRU3eWBgLSANKQNoAVj+qNn6yQECMRUULSARCAwbAAQAXv/nA+8G1QAnADYAPQBnAAABEQcUFjM3FQYPASImJwcGIyImNTQ2NzY3NjU0JiMiBwYHIzU+ATMgAxEHBgcGFRQWMzI2Nz4BASMTMxMjJxM3Njc+ATMyHgEXFhUUBg8CDgIVIzU0Nj8CNjc0JwYHFhcUBgciJgNQBBQhQRojSjtICBCErHKgjfBoIVB7d2RIOQwZUKBcAUykSrYre2hhK1wcESn+TEb+b/1F7mEUBhMQYjElHVASMSsiNCcQCgI1CgZSEgsEYzUUDAQjIx4vAoP+JR0pJQ0tDwYIOUYVg45weYUpEQobUXN/NSkxcjg7/PIBKwwlFTd5YGAtIA0pA2gBWP6o2QFANxAPFCUGGxgyRRlHKycbDiU8BEASMQtsJx8hSQ0JHBkYHysELwAEAF7/5wPCBrAAJwA2AD0AXgAAAREHFBYzNxUGDwEiJicHBiMiJjU0Njc2NzY1NCYjIgcGByM1PgEzIAMRBwYHBhUUFjMyNjc+AQEjEzMTIy8BIz4BMzIfARYXHgEzMj4CNzMGBwYjIiYnJicmIwcOAQNQBBQhQRojSjtICBCErHKgjfBoIVB7d2RIOQwZUKBcAUykSrYre2hhK1wcESn+TEb+b/1F7t01EGtFIQxWIyMIHwYTJBUUBzERLzVMHxpKJxIjFykUHwKD/iUdKSUNLQ8GCDlGFYOOcHmFKREKG1FzfzUpMXI4O/zyASsMJRU3eWBgLSANKQNoAVj+qNnZUnMELRUMAgoUHysMVjlCCCUVCBAICC8ABABe/skDwgWFACcANgBCAEkAAAERBxQWMzcVBg8BIiYnBwYjIiY1NDY3Njc2NTQmIyIHBgcjNT4BMyADEQcGBwYVFBYzMjY3PgEDIiY1NDYzMhYVFAYBIxMzEyMnA1AEFCFBGiNKO0gIEISscqCN8GghUHt3ZEg5DBlQoFwBTKRKtit7aGErXBwRKZwlOTklJzc5/sNG/m/9Re4Cg/4lHSklDS0PBgg5RhWDjnB5hSkRChtRc381KTFyODv88gErDCUVN3lgYC0gDSn+BDklJTk3JyU5BWQBWP6o2QAAAAADAF7/5wPCBTMAJwA2AEMAAAERBxQWMzcVBg8BIiYnBwYjIiY1NDY3Njc2NTQmIyIHBgcjNT4BMyADEQcGBwYVFBYzMjY3PgETDgEjIiYnMx4BMzI3A1AEFCFBGiNKO0gIEISscqCN8GghUHt3ZEg5DBlQoFwBTKRKtit7aGErXBwRKWwWjXttkRFOHWpGkzoCg/4lHSklDS0PBgg5RhWDjnB5hSkRChtRc381KTFyODv88gErDCUVN3lgYC0gDSkEbnCBi2Y7RH8AAAAEAF7/5wPCBqQAJwA2AEMAUwAAAREHFBYzNxUGDwEiJicHBiMiJjU0Njc2NzY1NCYjIgcGByM1PgEzIAMRBwYHBhUUFjMyNjc+ARMOASMiJiczHgEzMjcnIyUmJyY9ATY7ARYXHgEXA1AEFCFBGiNKO0gIEISscqCN8GghUHt3ZEg5DBlQoFwBTKRKtit7aGErXBwRKWoWjnptkRFOHWpGkzprRf68GRgEDjcRDAwVLQwCg/4lHSklDS0PBgg5RhWDjnB5hSkRChtRc381KTFyODv88gErDCUVN3lgYC0gDSkEbnCBi2Y7RH8ZyBcXCBgZKQYGDy8MAAQAXv/nA8IGpAAnADYAQwBTAAABEQcUFjM3FQYPASImJwcGIyImNTQ2NzY3NjU0JiMiBwYHIzU+ATMgAxEHBgcGFRQWMzI2Nz4BEw4BIyImJzMeATMyNxM+ATc2NzMyFxUUBwYHBSMDUAQUIUEaI0o7SAgQhKxyoI3waCFQe3dkSDkMGVCgXAFMpEq2K3toYStcHBEpahaOem2REU4dakaTOg8MLRUMDBE3DgQYGf68RQKD/iUdKSUNLQ8GCDlGFYOOcHmFKREKG1FzfzUpMXI4O/zyASsMJRU3eWBgLSANKQRucIGLZjtEfwEbDC8PBgYpGRgIFxfIAAAAAAQAXv/nA8IG8gAnADYAQwBtAAABEQcUFjM3FQYPASImJwcGIyImNTQ2NzY3NjU0JiMiBwYHIzU+ATMgAxEHBgcGFRQWMzI2Nz4BEw4BIyImJzMeATMyNwE3Njc+ATMyHgEXFhUUBg8CDgEPASM1NDY/AjY3NCcGBxYXFAYHIiYDUAQUIUEaI0o7SAgQhKxyoI3waCFQe3dkSDkMGVCgXAFMpEq2K3toYStcHBEpahaOem2REU4dakaTOv50FQYSEWIxJR1QEjErIzMnEAYCBDYLBlISCgVjNRUNBCMjHjACg/4lHSklDS0PBgg5RhWDjnB5hSkRChtRc381KTFyODv88gErDCUVN3lgYC0gDSkEbnCBi2Y7RH8BLzgQDhUlBhsZMUUZSCsnGhEUBkg9EzMKbScfIEoMCB0YGR4rBTAABABe/+cD4wZSACcANgBDAGQAAAERBxQWMzcVBg8BIiYnBwYjIiY1NDY3Njc2NTQmIyIHBgcjNT4BMyADEQcGBwYVFBYzMjY3PgETDgEjIiYnMx4BMzI3JyM+ATMyHwEWFx4BMzI+AjczBgcGIyImJyYnJiMHDgEDUAQUIUEaI0o7SAgQhKxyoI3waCFQe3dkSDkMGVCgXAFMpEq2K3toYStcHBEpYhaOe2ySEE4dakaTOf02EWpGIQxWIyMIHgcSJRQVBjEQLzZLHxtJJxMjFikVHgKD/iUdKSUNLQ8GCDlGFYOOcHmFKREKG1FzfzUpMXI4O/zyASsMJRU3eWBgLSANKQRucIGLZjtEf05ScwQuFAwCCxUfKwxWOUIIJRUIEAgILwAAAAAEAF7+yQPCBTMAJwA2AEMATwAAAREHFBYzNxUGDwEiJicHBiMiJjU0Njc2NzY1NCYjIgcGByM1PgEzIAMRBwYHBhUUFjMyNjc+ARMOASMiJiczHgEzMjcDIiY1NDYzMhYVFAYDUAQUIUEaI0o7SAgQhKxyoI3waCFQe3dkSDkMGVCgXAFMpEq2K3toYStcHBEpbBaNe22REU4dakaTOsMlOTklJzc5AoP+JR0pJQ0tDwYIOUYVg45weYUpEQobUXN/NSkxcjg7/PIBKwwlFTd5YGAtIA0pBG5wgYtmO0R/+ZY5JSU5NyclOQAAAAMARf/nA7oFmgAbACQANAAAJQcOASMiADU0NzYzMhcWHQEiJCMhBxQWMzI3NgEhNCcmIyIHBgEjJSYnJj0BNjsBFhceARcDjQRQsl/Z/vZ3f+Gsc39I/rII/t0Ev6pcWjn9rAIhM0CLh1JKAbhF/rwYGQQOOBAMDBUtDM1rOUIBD+3eiZFxfN4tCSmk3TEeAaScWm9xZgF/yBcWCBkZKQcGDi8MAAAAAAMARf/nA7oFmgAbACQANAAAJQcOASMiADU0NzYzMhcWHQEiJCMhBxQWMzI3NgEhNCcmIyIHBhM+ATc2NzMyFxUUBwYHBSMDjQRQsl/Z/vZ3f+Gsc39I/rII/t0Ev6pcWjn9rAIhM0CLh1JK/AwtFQwMETcOBBgZ/r1GzWs5QgEP7d6JkXF83i0JKaTdMR4BpJxab3FmAoEMLw4GBykZGQgWF8gAAwBF/+cDugX+ABsAJABOAAAlBw4BIyIANTQ3NjMyFxYdASIkIyEHFBYzMjc2ASE0JyYjIgcGEzU0Nj8CNjc0JwYHFhcUBgciJjU3Njc+ATMyHgEXFhUUBg8CDgEPAQONBFCyX9n+9nd/4axzf0j+sgj+3QS/qlxaOf2sAiEzQIuHUkryCgZSEgoFYzUUDAQjIx4wFQYTEGIxJR1QEjErIjQnEAYCAs1rOUIBD+3eiZFxfN4tCSmk3TEeAaScWm9xZgFzFhIzC2wnHyFJDQkcGRgfKwQvHzcQDxQlBhsYMkUZRysnGxAVBiAAAAADAEX/5wO6BUgAGwAkAEUAACUHDgEjIgA1NDc2MzIXFh0BIiQjIQcUFjMyNzYBITQnJiMiBwYTIz4BMzIfARYXHgEzMj4CNzMGBwYjIiYnJicmIwcOAQONBFCyX9n+9nd/4axzf0j+sgj+3QS/qlxaOf2sAiEzQIuHUkofNRBrRSEMViMjCB8GEiUVFAYyES81TB8aSicSIxcpFB/NazlCAQ/t3omRcXzeLQkppN0xHgGknFpvcWYBtFJyBC0UDQIKFR4rDVY6QQglFAkQCAgwAAAAAAMARf7JA7oD2wAbACQAMAAAJQcOASMiADU0NzYzMhcWHQEiJCMhBxQWMzI3NgEhNCcmIyIHBgEiJjU0NjMyFhUUBgONBFCyX9n+9nd/4axzf0j+sgj+3QS/qlxaOf2sAiEzQIuHUkoBFyU5OSUnNznNazlCAQ/t3omRcXzeLQkppN0xHgGknFpvcWb8BjklJTk3JyU5AAAAAwBF/+cDugWFABsAJAArAAAlBw4BIyIANTQ3NjMyFxYdASIkIyEHFBYzMjc2ASE0JyYjIgcGEyMTMxMjJwONBFCyX9n+9nd/4axzf0j+sgj+3QS/qlxaOf2sAiEzQIuHUkoXRv5v/kbuzWs5QgEP7d6JkXF83i0JKaTdMR4BpJxab3FmAWoBWP6o2QAEAEX/5wO6BtkAGwAkACsAOwAAJQcOASMiADU0NzYzMhcWHQEiJCMhBxQWMzI3NgEhNCcmIyIHBhMjEzMTIyclIyUmJyY9ATY7ARYXHgEXA40EULJf2f72d3/hrHN/SP6yCP7dBL+qXFo5/awCITNAi4dSShxF/W/+Ru0BeUb+vBgZBA83EA0MFC0NzWs5QgEP7d6JkXF83i0JKaTdMR4BpJxab3FmAWoBWP6o2XvJFhcIGRgpBgYPLwwAAAQARf/nBI4GkwAbACQAKwA6AAAlBw4BIyIANTQ3NjMyFxYdASIkIyEHFBYzMjc2ASE0JyYjIgcGEyMTMxMjJyUFIwE3NjczMh8BFAcOAQONBFCyX9n+9nd/4axzf0j+sgj+3QS/qlxaOf2sAiEzQIuHUkocRf1v/kbtAk7+vEYBAjIeHww0DgQIBCXNazlCAQ/t3omRcXzeLQkppN0xHgGknFpvcWYBagFY/qjZ+skBAjEVFC0gEQgMGwAABABF/+cEDQbVABsAJAArAFUAACUHDgEjIgA1NDc2MzIXFh0BIiQjIQcUFjMyNzYBITQnJiMiBwYTIxMzEyMnEzc2Nz4BMzIeARcWFRQGDwIOAhUjNTQ2PwI2NzQnBgcWFxQGByImA40EULJf2f72d3/hrHN/SP6yCP7dBL+qXFo5/awCITNAi4dSShxF/W/+Ru1gFQYSEWIxJR1PEzErIzMnEAsCNQoHURMKBGI1FQwFIyMfL81rOUIBD+3eiZFxfN4tCSmk3TEeAaScWm9xZgFqAVj+qNkBQDcQDxQlBhsYMkUZRysnGw4lPARAEjELbCcfIUkNCRwZGB8rBC8AAAQARf/nA7oGsAAbACQAKwBMAAAlBw4BIyIANTQ3NjMyFxYdASIkIyEHFBYzMjc2ASE0JyYjIgcGEyMTMxMjLwEjPgEzMh8BFhceATMyPgI3MwYHBiMiJicmJyYjBw4BA40EULJf2f72d3/hrHN/SP6yCP7dBL+qXFo5/awCITNAi4dSShxF/W/+Ru3dNhFqRiEMViMjCB8GEiUUFQYxEC82Sx8bSScTIxYpFB/NazlCAQ/t3omRcXzeLQkppN0xHgGknFpvcWYBagFY/qjZ2VJzBC0VDAIKFB8rDFY5QgglFQgQCAgvAAAEAEX+yQO6BYUAGwAkACsANwAAJQcOASMiADU0NzYzMhcWHQEiJCMhBxQWMzI3NgEhNCcmIyIHBhMjEzMTIycTIiY1NDYzMhYVFAYDjQRQsl/Z/vZ3f+Gsc39I/rII/t0Ev6pcWjn9rAIhM0CLh1JKF0b+b/5G7g8lOTklJzc5zWs5QgEP7d6JkXF83i0JKaTdMR4BpJxab3FmAWoBWP6o2fnDOSUlOTcnJTkAAgAY//gB3wWaAAkAGgAAAREnIgYHER4BMzcjJSYnJi8BNzY7ARYXHgEXAXBSFhkjHxkawUr+wBQIEwYICA8vFBkEFC0NA8/8KQgCBgPXBAR7yA8GDAwdHSkJBA4vDAAAAgBi//gCJQWeAAkAGAAAAREnIgYHER4BMxMFIwE3NjczMh8BFAcOAQFwUhYZIx8ZGs3+vUYBAjEfHwwzDgUJBCUDz/wpCAIGA9cEBAFDyAECMRQVLSERCAwbAAACAE//+AH1BfgACQAzAAABESciBgcRHgEzAzc2Nz4BMzIeARcWFRQGDwIOAQ8BIzU0Nj8CNjc0JwYHFhcUBgciJgFwUhcYIx8YG88UBxIQYzElHFATMSsjMycQBwIENQoGUhMKBGIzFwwEIiMfLwPP/CkIAgYD1wQEAaE4EA4VJQYbGTFFGUgrJhsRFAZIPhIzC2wnHyBKDAgcGRkeKwQvAAAAAAIADP/4AloFSAAJACoAAAERJyIGBxEeATMnIz4BMzIfAR4DMzI+AjczBgcGIyImJyYnJiMiDgEBcFIWGSIeGRrdNRBpQyUNVhQZJxgCFykQFQYxES81TB4bSicUJRcMLR8Dz/wpCAIGA9cEBLBUcAQtDAwNCBsYKw1WOkEIJRQJEBAwAAMAyP7JAYQFhQAJABUAIQAAAREnIgYHER4BMxMiJjU0NjMyFhUUBgMiJjU0NjMyFhUUBgFwUhcYIx8YGwglOTklJzc5JSU5OSUnNzkDz/wpCAIGA9cEBPsCOSUlOTcnJTkGADklJTk3JyU5AAMAPf/nA8IFmgAOAB4ALgAAEzQAMzISFRQHBiMiJyY1ASIHBhUUFxYzMjc2NTQnJjcjJSYnJj0BNjsBFhceARdBAQjLwe11gdm4e4MB055QQUFOlI9OPTdIE0b+vBgZBA44EAwNFC0MAezbART+7uLTj55/iNAB3JR5vq5xh6aDnqhwkqjIFxYIGRkpBwYOLwwAAAADAD3/5wPCBZoADgAeAC4AABM0ADMyEhUUBwYjIicmNQEiBwYVFBcWMzI3NjU0JyYDPgE3NjczMhcVFAcGBwUjQQEIy8HtdYHZuHuDAdOeUEFBTpSPTj03SKoMLRUMDRA3DwUYGf69RgHs2wEU/u7i04+ef4jQAdyUeb6ucYemg56ocJIBqgwvDgYHKRkZCBYXyAAAAwA9/+cDwgX+AA4AHgBIAAATNAAzMhIVFAcGIyInJjUBIgcGFRQXFjMyNzY1NCcmJzU0Nj8CNjc0JwYHFhcUBgciJjU3Njc+ATMyHgEXFhUUBg8CDgEPAUEBCMvB7XWB2bh7gwHTnlBBQU6Uj049N0i0CgZSEgoFYzUUDAQjIx4wFQYTEGIxJR1QEjErIjQnEAYCAQHs2wEU/u7i04+ef4jQAdyUeb6ucYemg56ocJKcFhIzC2wnHyFJDQkcGRgfKwQvHzcQDxQlBhsYMkUZRysnGxAVBiAAAwA9/+cDwgVIAA4AHgA/AAATNAAzMhIVFAcGIyInJjUBIgcGFRQXFjMyNzY1NCcmJSM+ATMyHwEWFx4BMzI+AjczBgcGIyImJyYnJiMHDgFBAQjLwe11gdm4e4MB055QQUFOlI9OPTdI/nk1EGtFIQxWIyMIHwYTJBUUBzERLzVMHxpKJxIjFykUHwHs2wEU/u7i04+ef4jQAdyUeb6ucYemg56ocJLdUnIELRQNAgoVHisNVjpBCCUUCRAICDAAAwA9/skDwgPbAA4AHgAqAAATNAAzMhIVFAcGIyInJjUBIgcGFRQXFjMyNzY1NCcmAyImNTQ2MzIWFRQGQQEIy8HtdYHZuHuDAdOeUEFBTpSPTj03SJ8lOjolJjg6AezbART+7uLTj55/iNAB3JR5vq5xh6aDnqhwkvsvOSUlOTcnJTkAAwA9/+cDwgWFAA4AHgAlAAATNAAzMhIVFAcGIyInJjUBIgcGFRQXFjMyNzY1NCcmJSMTMxMjJ0EBCMvB7XWB2bh7gwHTnlBBQU6Uj049N0j+cUb+b/5G7QHs2wEU/u7i04+ef4jQAdyUeb6ucYemg56ocJKTAVj+qNkAAAQAPf/nA8IG2QAOAB4AJQA1AAATNAAzMhIVFAcGIyInJjUBIgcGFRQXFjMyNzY1NCcmJSMTMxMjJyUjJSYnJj0BNjsBFhceARdBAQjLwe11gdm4e4MB055QQUFOlI9OPTdI/nFG/m/+Ru0Bfkb+vRkZBA83EA0MFC4MAezbART+7uLTj55/iNAB3JR5vq5xh6aDnqhwkpMBWP6o2XvJFhcIGRgpBgYPLwwAAAAEAD3/5wSOBpMADgAeACUANAAAEzQAMzISFRQHBiMiJyY1ASIHBhUUFxYzMjc2NTQnJiUjEzMTIyclBSMBNzY3MzIfARQHDgFBAQjLwe11gdm4e4MB055QQUFOlI9OPTdI/nFG/m/+Ru0CU/68RQECMR8eDTMOBAgEJQHs2wEU/u7i04+ef4jQAdyUeb6ucYemg56ocJKTAVj+qNn6yQECMRUULSARCAwbAAAABAA9/+cEDQbVAA4AHgAlAE8AABM0ADMyEhUUBwYjIicmNQEiBwYVFBcWMzI3NjU0JyYlIxMzEyMnEzc2Nz4BMzIeARcWFRQGDwIOAhUjNTQ2PwI2NzQnBgcWFxQGByImQQEIy8HtdYHZuHuDAdOeUEFBTpSPTj03SP5xRv5v/kbtZRUGEhFiMSUdUBIxKyMzJxAKAjYLBlISCgRiNRUNBCMjHy8B7NsBFP7u4tOPnn+I0AHclHm+rnGHpoOeqHCSkwFY/qjZAUA3EA8UJQYbGDJFGUcrJxsOJTwEQBIxC2wnHyFJDQkcGRgfKwQvAAAABAA9/+cDwgawAA4AHgAlAEYAABM0ADMyEhUUBwYjIicmNQEiBwYVFBcWMzI3NjU0JyYlIxMzEyMvASM+ATMyHwEWFx4BMzI+AjczBgcGIyImJyYnJiMHDgFBAQjLwe11gdm4e4MB055QQUFOlI9OPTdI/nFG/m/+Ru3YNRBqRiEMViMjCB8GEiUVFAYxEC81TB8aSicTIhcpFB8B7NsBFP7u4tOPnn+I0AHclHm+rnGHpoOeqHCSkwFY/qjZ2VJzBC0VDAIKFB8rDFY5QgglFQgQCAgvAAAABAA9/skDwgWFAA4AHgAlADEAABM0ADMyEhUUBwYjIicmNQEiBwYVFBcWMzI3NjU0JyYlIxMzEyMnAyImNTQ2MzIWFRQGQQEIy8HtdYHZuHuDAdOeUEFBTpSPTj03SP5xRv5v/kbtAiU6OiUmODoB7NsBFP7u4tOPnn+I0AHclHm+rnGHpoOeqHCSkwFY/qjZ+cM5JSU5NyclOQAAAgBR/+cDjAWaABwALAAAAREnIgYHNQYjIiY1ER4BMzcRFBYzMjc2NREeATMnIyUmJyY9ATY7ARYXHgEXA4xSFhkiZ+Gqph8YG1JuiI0/Mh4ZGmxG/r0ZGAUPNxANDBUtDAPP/CkIAga0xb/PAloEBAj916ysblSKAjUEBHvIFxYIGRkpBwYOLwwAAAACAFH/5wOMBZoAHAAsAAABESciBgc1BiMiJjURHgEzNxEUFjMyNzY1ER4BMwE+ATc2NzMyFxUUBwYHBSMDjFIWGSJn4aqmHxgbUm6IjT8yHhka/tgMLRQNDBA4DgQZGP68RgPP/CkIAga0xb/PAloEBAj916ysblSKAjUEBAF9DC8OBgcpGRkIFhfIAAIAUf/nA4wF/gAcAEYAAAERJyIGBzUGIyImNREeATM3ERQWMzI3NjURHgEzJTU0Nj8CNjc0JwYHFhcUBgciJjU3Njc+ATMyHgEXFhUUBg8CDgEPAQOMUhYZImfhqqYfGBtSboiNPzIeGRr+jwoGUhIKBWM1FAwEIyMeMBUGExBiMSUdUBIxKyI0JxAGAgIDz/wpCAIGtMW/zwJaBAQI/desrG5UigI1BARvFhIzC2wnHyFJDQkcGRgfKwQvHzcQDxQlBhsYMkUZRysnGxAVBiAAAAAAAgBR/+cDjAVIABwAPQAAAREnIgYHNQYjIiY1ER4BMzcRFBYzMjc2NREeATMlIz4BMzIfARYXHgEzMj4CNzMGBwYjIiYnJicmIwcOAQOMUhYZImfhqqYfGBtSboiNPzIeGRr9wzUQa0UhDFYjIwgfBhIlFRQGMhEvNUwfGkonEiMXKRQfA8/8KQgCBrTFv88CWgQECP3XrKxuVIoCNQQEsFJyBC0UDQIKFR4rDVY6QQglFAkQCAgwAAIAUf7JA4wDzwAcACgAAAERJyIGBzUGIyImNREeATM3ERQWMzI3NjURHgEzASImNTQ2MzIWFRQGA4xSFhkiZ+Gqph8YG1JuiI0/Mh4ZGv61JTo6JSc3OQPP/CkIAga0xb/PAloEBAj916ysblSKAjUEBPsCOSUlOTcnJTkAAAAAAQBR/+cEQQTBADAAAAE+ATU0Jy4BJzUXMwcVFAYHDgEHESciBgc1BiMiJjURHgEzNxEUFjMyNzY1ER4BMzcDjCcfEAc9Aj2IBBUhGDgrUhYZImfhqqYfGBtSboiNPzIeGRpSA6IKKyEpEAoEB3sJIE42TycdGQT8lAgCBrTFv88CWgQECP3XrKxuVIoCNQQECAAAAAIAUf/nBEEFmgAPAEAAAAEjJSYnJj0BNjsBFhceARcBPgE1NCcuASc1FzMHFRQGBw4BBxEnIgYHNQYjIiY1ER4BMzcRFBYzMjc2NREeATM3ArFG/r0ZGAUPNxANDBUtDAHdJx8QBz0CPYgEFSEYOCtSFhkiZ+Gqph8YG1JuiI0/Mh4ZGlIEQsgXFggZGSkHBg4vDP5eCishKRAKBAd7CSBONk8nHRkE/JQIAga0xb/PAloEBAj916ysblSKAjUEBAgAAAACAFH/5wRBBZoADwBAAAABPgE3NjczMhcVFAcGBwUjBT4BNTQnLgEnNRczBxUUBgcOAQcRJyIGBzUGIyImNREeATM3ERQWMzI3NjURHgEzNwJNDC0UDQwQOA4EGRj+vEYCQicfEAc9Aj2IBBUhGDgrUhYZImfhqqYfGBtSboiNPzIeGRpSBUQMLw4GBykZGQgWF8igCishKRAKBAd7CSBONk8nHRkE/JQIAga0xb/PAloEBAj916ysblSKAjUEBAgAAAAAAgBR/+cEQQX+ACkAWgAAATU0Nj8CNjc0JwYHFhcUBgciJjU3Njc+ATMyHgEXFhUUBg8CDgEPAQU+ATU0Jy4BJzUXMwcVFAYHDgEHESciBgc1BiMiJjURHgEzNxEUFjMyNzY1ER4BMzcByQoGUhIKBWM1FAwEIyMeMBUGExBiMSUdUBIxKyI0JxAGAgIBjCcfEAc9Aj2IBBUhGDgrUhYZImfhqqYfGBtSboiNPzIeGRpSBDYWEjMLbCcfIUkNCRwZGB8rBC8fNxAPFCUGGxgyRRlHKycbEBUGIJQKKyEpEAoEB3sJIE42TycdGQT8lAgCBrTFv88CWgQECP3XrKxuVIoCNQQECAAAAgBR/+cEQQVIACAAUQAAASM+ATMyHwEWFx4BMzI+AjczBgcGIyImJyYnJiMHDgEFPgE1NCcuASc1FzMHFRQGBw4BBxEnIgYHNQYjIiY1ER4BMzcRFBYzMjc2NREeATM3ARo1EGtFIQxWIyMIHwYSJRUUBjIRLzVMHxpKJxIjFykUHwJsJx8QBz0CPYgEFSEYOCtSFhkiZ+Gqph8YG1JuiI0/Mh4ZGlIEd1JyBC0UDQIKFR4rDVY6QQglFAkQCAgw7worISkQCgQHewkgTjZPJx0ZBPyUCAIGtMW/zwJaBAQI/desrG5UigI1BAQIAAAAAgBR/skEQQTBAAsAPAAAASImNTQ2MzIWFRQGAT4BNTQnLgEnNRczBxUUBgcOAQcRJyIGBzUGIyImNREeATM3ERQWMzI3NjURHgEzNwHvJTo6JSc3OQF4Jx8QBz0CPYgEFSEYOCtSFhkiZ+Gqph8YG1JuiI0/Mh4ZGlL+yTklJTk3JyU5BNkKKyEpEAoEB3sJIE42TycdGQT8lAgCBrTFv88CWgQECP3XrKxuVIoCNQQECAAAAgA9/+cD+wR5ACMAMwAAAT4CNTQmJy4BJzUXMwcVFAYHBgcWFRQHBiMiJyY1NzQAMzIHIgcGFRQXFjMyNzY1NCcmAzcWLRsOCwY9Aj2HBAwhJztadYHZuHuDBAEIy6isnlBBQU6Uj049N0gDYAQRJSAPFgoLBAZ7CCFOO0IlLQyBv9OPnn+I0C7bARRBlHm+rnGHpoOeqHCSAAAAAwA9/+cD+wWaAA8AMwBDAAABIyUmJyY9ATY7ARYXHgEXAT4CNTQmJy4BJzUXMwcVFAYHBgcWFRQHBiMiJyY1NzQAMzIHIgcGFRQXFjMyNzY1NCcmArJG/rwYGQQOOBAMDRQtDAGIFi0bDgsGPQI9hwQMISc7WnWB2bh7gwQBCMuorJ5QQUFOlI9OPTdIBELIFxYIGRkpBwYOLwz+HAQRJSAPFgoLBAZ7CCFOO0IlLQyBv9OPnn+I0C7bARRBlHm+rnGHpoOeqHCSAAAAAwA9/+cD+wWaAA8AMwBDAAABPgE3NjczMhcVFAcGBwUjBT4CNTQmJy4BJzUXMwcVFAYHBgcWFRQHBiMiJyY1NzQAMzIHIgcGFRQXFjMyNzY1NCcmAfUMLRUMDRA3DwUYGf69RgJEFi0bDgsGPQI9hwQMISc7WnWB2bh7gwQBCMuorJ5QQUFOlI9OPTdIBUQMLw4GBykZGQgWF8jiBBElIA8WCgsEBnsIIU47QiUtDIG/04+ef4jQLtsBFEGUeb6ucYemg56ocJIAAAAAAwA9/+cD+wX+ACkATQBdAAABNTQ2PwI2NzQnBgcWFxQGByImNTc2Nz4BMzIeARcWFRQGDwIOAQ8BBT4CNTQmJy4BJzUXMwcVFAYHBgcWFRQHBiMiJyY1NzQAMzIHIgcGFRQXFjMyNzY1NCcmAesKBlISCgVjNRQMBCMjHjAVBhMQYjElHVASMSsiNCcQBgIBARQWLRsOCwY9Aj2HBAwhJztadYHZuHuDBAEIy6isnlBBQU6Uj049N0gENhYSMwtsJx8hSQ0JHBkYHysELx83EA8UJQYbGDJFGUcrJxsQFQYg1gQRJSAPFgoLBAZ7CCFOO0IlLQyBv9OPnn+I0C7bARRBlHm+rnGHpoOeqHCSAAADAEf/5wQFBUgAIABEAFQAAAEjPgEzMh8BFhceATMyPgI3MwYHBiMiJicmJyYjBw4BAT4CNTQmJy4BJzUXMwcVFAYHBgcWFRQHBiMiJyY1NzQAMzIHIgcGFRQXFjMyNzY1NCcmARg1EGtFIQxWIyMIHwYTJBUUBzERLzVMHxpKJxIjFykUHwIjFi0bDgsGPQI9hwQMISc7WnWB2bh7gwQBCMuorJ5QQUFOlI9OPTdIBHdScgQtFA0CChUeKw1WOkEIJRQJEAgIMP7PBBElIA8WCgsEBnsIIU47QiUtDIG/04+ef4jQLtsBFEGUeb6ucYemg56ocJIAAAMAPf7JA/sEeQALAC8APwAAASImNTQ2MzIWFRQGAT4CNTQmJy4BJzUXMwcVFAYHBgcWFRQHBiMiJyY1NzQAMzIHIgcGFRQXFjMyNzY1NCcmAgAlOjolJjg6ARMWLRsOCwY9Aj2HBAwhJztadYHZuHuDBAEIy6isnlBBQU6Uj049N0j+yTklJTk3JyU5BJcEESUgDxYKCwQGewghTjtCJS0Mgb/Tj55/iNAu2wEUQZR5vq5xh6aDnqhwkgAAAgA1/ewD4wWaAB8ALwAAJQEeATMyNjcWEhc2EjceATMyNwIHAgcCBy4BIyIHBiMBIyUmJyY9ATY7ARYXHgEXAdP+YhktHBc5Ez2LZ0G3OxAhFRAx0xakOn1TEx8UHQ4TCAHyRv68GBkEDjgQDA0ULQ0EA8sEBAYCwf6e14cByaoEBAj+KzH+l4X+49IEBAIGBlbIFxYIGRkpBwYOLwwAAAIANf3sA+MFmgAfAC8AACUBHgEzMjY3FhIXNhI3HgEzMjcCBwIHAgcuASMiBwYjAT4BNzY3MzIXFRQHBgcFIwHT/mIZLRwXORM9i2dBtzsQIRUQMdMWpDp9UxMfFB0OEwgBjQwuFAwNEDcPBBkZ/r1GBAPLBAQGAsH+nteHAcmqBAQI/isx/peF/uPSBAQCBgdYDC8OBgcpGRkIFhfIAAACADX97APjBf4AHwBJAAAlAR4BMzI2NxYSFzYSNx4BMzI3AgcCBwIHLgEjIgcGIwE1NDY/AjY3NCcGBxYXFAYHIiY1NzY3PgEzMh4BFxYVFAYPAg4BDwEB0/5iGS0cFzkTPYtnQbc7ECEVEDHTFqQ6fVMTHxQdDhMIAVcKBlISCgVjNRQMBCMjHjAVBhMQYjElHVASMSsiNCcQBgIBBAPLBAQGAsH+nteHAcmqBAQI/isx/peF/uPSBAQCBgZKFhIzC2wnHyFJDQkcGRgfKwQvHzcQDxQlBhsYMkUZRysnGxAVBiAAAAAAAgA1/ewD4wVIAB8AQAAAJQEeATMyNjcWEhc2EjceATMyNwIHAgcCBy4BIyIHBiMTIz4BMzIfARYXHgEzMj4CNzMGBwYjIiYnJicmIwcOAQHT/mIZLRwXORM9i2dBtzsQIRUQMdMWpDp9UxMfFB0OEwiWNhFqRiEMViMjCB8GEiUVFAYxEC81TB8bSScTIhcpFB8EA8sEBAYCwf6e14cByaoEBAj+KzH+l4X+49IEBAIGBotScgQtFA0CChUeKw1WOkEIJRQJEAgIMAAAAgA1/ewD4wPPAB8AKwAAJQEeATMyNjcWEhc2EjceATMyNwIHAgcCBy4BIyIHBiMlIiY1NDYzMhYVFAYB0/5iGS0cFzkTPYtnQbc7ECEVEDHTFqQ6fVMTHxQdDhMIAewlOTklJzc5BAPLBAQGAsH+nteHAcmqBAQI/isx/peF/uPSBAQCBt05JSU5NyclOQAAAgC4AAAFygV1ABQAKgAAAREhMhcWFxYSFRQHBgcGBCkBESM1AREhFSERMhcWMzcyNzY3NjUQACEiBgEKAiGXVHtcb25HPn1a/vr+9v6sUgEGAYn+dx0lcCMppHubSkL+7f7RKc0DFwJeExpOWv7vlc2ch25OTgK8WwIM/fRb/aIEDAQ9TqKPywFAARIIAAAAAgBJ/+cEPQX8ABwALAAAAREnIgYHNQYjIicmNTQSMzIWFxEhNSE1FzcVMxUDNCcmIyIHBhUUFxYzMjc2A+dSFxgjg925bHXwxmudPP76AQZSUlb6PEuQskg1PEmSn1BABLz7PAgCBsnae4P22wElZmMBqlvlBATlW/1EmmiDk23Hm2uDnn0AAAEAjwNIAc4FkQANAAABAwYHBiMiJjU0NzY3EwHOjw4PGicfMw4EG/IFhf45MxgrKyMaHQopAZEAAQBqA0gBrgWRAAwAABsBNjc2MzIWFRQGBwNqjxUKGyUkMg8e8gNYAcc7DiknIhklMf5vAAIAhwNIAyMFkQANABsAAAEDBgcGIyImNTQ3NjcTBQMGBwYjIiY1NDc2NxMDI5AODhsnHzMOBRry/sSPDg8aJx8zDgQb8gWF/jkzGCsrIxodCikBkQz+OTMYKysjGh0KKQGRAAACAGoDSAMKBZEADAAZAAAbATY3NjMyFhUUBgcDJRM2NzYzMhYVFAYHA2qPFQobJSQyDx7yATeQFAobJSUxDx7yA1gBxzsOKSciGSUx/m8QAcc7DiknIhklMf5vAAMAo//nBIAA4QALABcAIwAANzQ2MzIWFRQGIyImJTQ2MzIWFRQGIyImJTQ2MzIWFRQGIyImo0oxMUpIMzFKAX5KMTFKSDMxSgFpSjExSkgzMUpmMklJMjNMSjUySUkyM0xKNTJJSTIzTEoAAAAAAQAABWwAAQDlAwAABwJeABAAJP/cABAAJgBLABAAKgAmABAALQAmABAAMgBLABAAN/+QABAAOf+IABAAOv+QABAAO/9OABAAPP7mABAAUgAmACQAEP/TACQAHf/cACQAHv/cACQAJP+3ACQAJv/cACQAKv/cACQAMv/cACQANP/cACQANv/cACQAN/9EACQAOP+3ACQAOf+QACQAOv/BACQAO/+QACQAPP9rACQAR//cACQASAAmACQASf/cACQAVP/cACQAV//cACQAWP+3ACQAWf+QACQAWv+3ACQAXP+3ACQA8v/cACUAEAA5ACUAJgAmACUAKgAmACUAOf/cACUAOv/cACUAPP+tACYAJP/cACYANv/cACYAPP+3ACcAJP/cACcAOf/cACcAPP+3ACkAD/8DACkAEf8DACkAHf+tACkAHv+tACkAJP+QACkANwAmACkARP+IACkASP+aACkATP+3ACkAUv+aACkAVf+kACkAWP+kACkAXP+3ACkAaf+IACoAEAAvACoAJP/cACoAN//cACoAOv/cACoAPP+QACsAHf/cACsAHv/cAC0AEP/cAC0AJP/cAC4AEP8pAC4AJP+3AC4AJv+QAC4AMv+QAC4AN//cAC4AOP+3AC4AOv+QAC4APP+QAC4ARP/cAC4ASP/cAC4AUv+3AC4AWP9rAC4AXP+QAC4Aaf/cAC8AJP/cAC8AN/9rAC8AOP/cAC8AOf+QAC8AOv+3AC8APP9rAC8AWP/cAC8AXP+3ADIAD/+tADIAEAA5ADIAEf+tADIAJP/cADIAOf+3ADIAO/+3ADIAPP+3ADMAD/7TADMAEP/TADMAEf7TADMAJP+QADMARP+IADMASP+kADMAUv+aADMAVf/cADMAVv+3ADMAWP+3ADMAaf+IADUAEP/JADUAHf+3ADUAHv+3ADUAJP+3ADUAN//cADUAOf/cADUAPP9rADUASP/cADUAUv/cADUAWP/cADUAXP/cADYAJP+3ADYAJgAmADYAKgAmADcAD/8fADcAEP9rADcAEf8fADcAHf99ADcAHv99ADcAJP9EADcARP9EADcARv8fADcASP9EADcATP+3ADcAUv9EADcAVf/cADcAVv8fADcAWP9ZADcAWv9rADcAXP9rADcAaf9EADgAJP+QADkAD/6tADkAEP99ADkAEf6tADkAHf9OADkAHv9OADkAJP+QADkAMv/cADkARP9hADkASP9ZADkATP+3ADkAUv99ADkAWP9rADkAXP+QADkAaf9hADoAD/7cADoAEP9hADoAEf7cADoAHf+IADoAHv+IADoAJP+3ADoARP+IADoASP99ADoATP+QADoAUv+QADoAVf+kADoAWP99ADoAXP+QADoAaf+IADsAEP9OADsAJP+3ADsAJv/cADsAMv+3ADsAN/+3ADsASP+3ADwAD/7wADwAEP7mADwAEf7wADwAHf8pADwAHv8pADwAJP9EADwAJv/cADwAMv+3ADwARP9EADwASP8fADwATP+QADwAUv9EADwAWP9EADwAaf9EAEgAW//cAEkAD//cAEkAEf/cAE4ARP/cAE4ASP/cAE4AUv+3AE4AWP/cAE4AXP/cAE4Aaf/cAFIAEAAmAFIAW//cAFUAD/99AFUAEP/cAFUAEf99AFUASQAmAFUAS//cAFUAUAAmAFUAUQAmAFUAVQAmAFUAWAAmAFUAWQAmAFUAWgAmAFUAXABLAFkAD/88AFkAEf88AFkAHf/cAFkAHv/cAFoAD/9EAFoAEf9EAFoAHf/cAFoAHv/cAFsARv/cAFsASP/cAFsAUv/cAFwAD/9OAFwAEP/cAFwAEf9OAGkAW//cAAAAGwFKAAAAAAAAAAAA7gGXAAAAAAAAAAEAFAKlAAAAAAAAAAIADgAAAAAAAAAAAAMAIAKFAAAAAAAAAAQAFAKlAAAAAAAAAAUAUAK5AAAAAAAAAAYAFAKlAAAAAAAAAAcAeAAOAAAAAAAAAAwAKgMJAAEAAAAAAAAAdwCGAAEAAAAAAAEACgD9AAEAAAAAAAIABwEHAAEAAAAAAAMAEAEOAAEAAAAAAAQACgD9AAEAAAAAAAUAKAEeAAEAAAAAAAYACgD9AAEAAAAAAAcAPAFGAAEAAAAAAAwAFQGCAAMAAQQJAAAA7gGXAAMAAQQJAAEAFAKlAAMAAQQJAAIADgAAAAMAAQQJAAMAIAKFAAMAAQQJAAQAFAKlAAMAAQQJAAUAUAK5AAMAAQQJAAYAFAKlAAMAAQQJAAcAeAAOAAMAAQQJAAwAKgMJAFIAZQBnAHUAbABhAHIAUABoAOEAdAAgAHQAcgBpHsMAbgAgAGIe3wBpACAAVABoAGkAZQBuACAATQBpAG4AaAAgAEMAbwAuACwAIABMAHQAZAAgAC0AIABoAHQAdABwADoALwAvAHcAdwB3AC4AdABoAGkAZQBuAG0AaQBuAGgALgB2AG5UaGlldCBrZSBib2kgTWljaGFlbCBEaW5oIEtpZW4gLSAiSW4gR29kIFdlIFRydXN0IC0gRnJlZSBmb3IgZXZlcnlvbmUiIEVtYWlsOiBmb250Y2h1ZGVwY0BnbWFpbC5jb207IHd3dy5mb250Y2h1ZGVwLmNvbVVUTSBBcHRpbWFSZWd1bGFyVVRNOlZlcnNpb24gMS4wMEJvIEZvbnQgY2h1IFZpZXQgc3UgZHVuZyBiYW5nIG1hIFVuaWNvZGVQaGF0IHRyaWVuIGJvaSBUaGllbiBNaW5oIENvLiwgTHRkIC0gaHR0cDovL3d3dy50aGllbm1pbmgudm5odHRwOi8vZm9udGNodWRlcC5jb20AVABoAGkevwB0ACAAax6/ACAAYh7fAGkAIABNAGkAYwBoAGEAZQBsACABEABpAG4AaAAgAEsAaQDqAG4AIAAtACAAIgBJAG4AIABHAG8AZAAgAFcAZQAgAFQAcgB1AHMAdAAgAC0AIABGAHIAZQBlACAAZgBvAHIAIABlAHYAZQByAHkAbwBuAGUAIgAgAEUAbQBhAGkAbAA6ACAAZgBvAG4AdABjAGgAdQBkAGUAcABjAEAAZwBtAGEAaQBsAC4AYwBvAG0AOwAgAHcAdwB3AC4AZgBvAG4AdABjAGgAdQBkAGUAcAAuAGMAbwBtAFUAVABNADoAVgBlAHIAcwBpAG8AbgAgADEALgAwADAAVQBUAE0AIABBAHAAdABpAG0AYQBCHtkAIABGAG8AbgB0ACAAYwBoHu8AIABWAGkexwB0ACAAcx7tACAAZB7lAG4AZwAgAGIeowBuAGcAIABtAOMAIABVAG4AaQBjAG8AZABlAGgAdAB0AHAAOgAvAC8AZgBvAG4AdABjAGgAdQBkAGUAcAAuAGMAbwBtAAAAAAIAAAAAAAD/OwBtAAAAAAAAAAAAAAAAAAAAAAAAAAAA+wAAAAEAAgADAAQABQAGAAcACAAJAAoACwAMAA0ADgAPABAAEQASABMAFAAVABYAFwAYABkAGgAbABwAHQAeAB8AIAAhACIAIwAkACUAJgAnACgAKQAqACsALAAtAC4ALwAwADEAMgAzADQANQA2ADcAOAA5ADoAOwA8AD0APgA/AEAAQQBCAEMARABFAEYARwBIAEkASgBLAEwATQBOAE8AUABRAFIAUwBUAFUAVgBXAFgAWQBaAFsAXABdAF4AXwBgAGEAjgCLAIoAjQCIAPUA9AD2AQIBAwEEAQUBBgEHAQgBCQEKAQsBDAENAQ4BDwEQAREBEgETARQBFQEWARcBGAEZARoBGwEcAR0BHgEfASABIQEiASMBJAElASYBJwEoASkBKgErASwBLQEuAS8BMAExATIBMwE0ATUBNgE3ATgBOQE6ATsBPAE9AT4BPwFAAUEBQgFDAUQBRQFGAUcBSAFJAUoBSwFMAU0BTgFPAVABUQFSAVMBVAFVAVYBVwFYAVkBWgFbAVwBXQFeAV8BYAFhAWIBYwFkAWUBZgFnAWgBaQFqAWsBbAFtAW4BbwFwAXEBcgFzAXQBdQF2AXcBeAF5AXoBewF8AX0BfgF/AYABgQGCAYMBhAGFALgAfwB+AOwA/wEAAYYBAQC2ALcAtAC1AKsAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAGRHNsYXNoAAABAACAAABjAjsDZAAAcGME6AAAVVZOQWlDYXBSZWd1bGFyIP////83///+VUFDUjAwAACCAAAA' };
  let fontMFXong = null;
  function napFontMF() {
    if (!fontMFXong) fontMFXong = (async () => {
      for (const [ten, b64] of Object.entries(FONT_MF)) {
        const bin = atob(b64); const u8 = new Uint8Array(bin.length); for (let i = 0; i < bin.length; i++) u8[i] = bin.charCodeAt(i);
        const f = new FontFace(ten, u8.buffer); await f.load(); document.fonts.add(f);
      }
    })().catch((e) => { fontMFXong = null; throw new LoiMem('không nạp được font chữ (' + e.message + ')'); });
    return fontMFXong;
  }
  // tạo ảnh manifest 1080x1920 (9:16) từ chữ trong ô sheet + ảnh nền (đã làm tối sẵn), 1 font
  async function taoAnhManifest(nenBlob, chuO, font, fontCmt) {
    const W = 1080, H = 1920, LE = 130; // (5.9.7) lề 2 bên 12% → điện thoại cắt bớt 2 bên hay hiệu ứng phóng to 3% đều không mất chữ
    const RONG = W - LE * 2;
    const F = font || 'UTM American Sans', FC = fontCmt || 'UTM Aptima';
    // 1) tách chữ: câu đầu = tiêu đề; các câu giữa = thân; câu "Cmt…" = lời kêu gọi; dòng toàn hashtag cuối = bỏ (dùng làm chữ bài đăng)
    const dong = chuO.split(/\r?\n/).map((s) => s.trim()).filter(Boolean);
    if (dong.length && /^(#\S+\s*)+$/.test(dong[dong.length - 1])) dong.pop();
    if (dong.length && /^#manifest$/i.test(dong[0])) dong.shift();
    const tieuDe = (dong.shift() || '').toLocaleUpperCase('vi');
    const than = [], cta = [];
    for (const s of dong) (/^cmt\b/i.test(s) || cta.length ? cta : than).push(s);
    // 2) nền: phủ kín khung 9:16
    const cv = document.createElement('canvas'); cv.width = W; cv.height = H; const g = cv.getContext('2d');
    const bm = await createImageBitmap(nenBlob); const k = Math.max(W / bm.width, H / bm.height);
    g.drawImage(bm, (W - bm.width * k) / 2, (H - bm.height * k) / 2, bm.width * k, bm.height * k);
    // 3) ngắt dòng theo bề rộng
    const ngat = (txt, px, ff) => { g.font = `${px}px "${ff || F}"`; const ra = []; let cur = ''; for (const w of txt.split(/\s+/)) { const th = cur ? cur + ' ' + w : w; if (!cur || g.measureText(th).width <= RONG) cur = th; else { ra.push(cur); cur = w; } } if (cur) ra.push(cur);
      // tránh dòng cuối chỉ còn 1 chữ: kéo bớt 1 chữ từ dòng trên xuống
      if (ra.length > 1 && !/\s/.test(ra[ra.length - 1])) { const tr = ra[ra.length - 2].split(' '); if (tr.length > 2) { const m = tr.pop(); const moi = m + ' ' + ra[ra.length - 1]; if (g.measureText(moi).width <= RONG) { ra[ra.length - 2] = tr.join(' '); ra[ra.length - 1] = moi; } } }
      return ra; };
    // 4) cỡ chữ + khoảng cách đo theo ảnh mẫu (khung 1080x1920); chữ dài thì tự thu nhỏ đều cho vừa
    const DAY_DUOI = 1480; // dòng chữ cuối không thấp hơn mức này (chừa chỗ cho #sonmochuong)
    let bo;
    for (let tl = 1; tl >= 0.55; tl -= 0.02) {
      const kh = [
        { ds: ['#MANIFEST'], px: 47 * tl, mau: '#ffffff', cach: 0, dong: 0 },
        { ds: ngat(tieuDe, 73 * tl), px: 73 * tl, mau: '#f8ef3b', cach: 87 * tl, dong: 84 * tl },
      ];
      if (than.length) kh.push({ ds: than.flatMap((s) => ngat(s, 68 * tl)), px: 68 * tl, mau: '#ffffff', cach: 156 * tl, dong: 77 * tl });
      if (cta.length) kh.push({ ds: cta.flatMap((s) => ngat(s, 57 * tl, FC)), px: 57 * tl, mau: '#ffffff', cach: 177 * tl, dong: 96 * tl, ff: FC });
      let y = 350, toaDo = [];
      for (const k2 of kh) { y += k2.cach; k2.ds.forEach((d, i) => { if (i) y += k2.dong; toaDo.push([k2, d, y]); }); }
      bo = { toaDo, tl }; if (y <= DAY_DUOI) break;
    }
    // 5) vẽ chữ (bóng mờ nhẹ cho dễ đọc)
    g.textBaseline = 'alphabetic'; g.shadowColor = 'rgba(0,0,0,0.45)'; g.shadowBlur = 10; g.shadowOffsetY = 3;
    let tran = 0;
    for (const [k2, d, y] of bo.toaDo) { g.font = `${k2.px}px "${k2.ff || F}"`; g.fillStyle = k2.mau; g.fillText(d, LE, y); tran = Math.max(tran, LE + g.measureText(d).width); }
    g.shadowColor = 'transparent';
    g.textAlign = 'center'; g.font = `italic 56px "${F}"`; g.fillStyle = 'rgba(255,255,255,0.45)'; g.fillText('#sonmochuong', W / 2, 1589);
    // kiểm tra không chữ nào tràn lề
    return { blob: await new Promise((r) => cv.toBlob(r, 'image/jpeg', 0.93)), tl: bo.tl, phaiNhat: Math.round(tran) };
  }

  async function docOChu(o) { // đọc chữ trong 1 ô của tab Kênh 1
    const m = String(o || '').trim().toUpperCase().match(/^([A-Z]{1,2})(\d+)$/); if (!m) throw new LoiMem('ô "' + o + '" không đúng dạng (ví dụ Q213)');
    const r = await goiLark('GET', `https://open.larksuite.com/open-apis/sheets/v2/spreadsheets/${CAI_DAT.SHEET_TOKEN}/values/${TAB_VIDEO}!${m[0]}:${m[0]}`, null);
    if (!r.json || r.json.code !== 0) throw new LoiMem('không đọc được ô ' + m[0] + ' (mã ' + (r.json ? r.json.code : r.status) + ')');
    return chuOV((((r.json.data && r.json.data.valueRange && r.json.data.valueRange.values) || [])[0] || [])[0]).trim();
  }
  async function ghiAnhVaoO(o, blob) { // dán ảnh vào ô (ảnh nằm trong ô, giống dán tay) rồi đọc lại để chắc chắn
    const m = String(o || '').trim().toUpperCase().match(/^([A-Z]{1,2})(\d+)$/); if (!m) throw new LoiMem('ô "' + o + '" không đúng dạng (ví dụ S213)');
    const u8 = new Uint8Array(await blob.arrayBuffer());
    let loi = null;
    for (let lan = 0; lan < 2; lan++) {
      if (lan) await sleep(4000);
      try {
        const r = await goiLark('POST', `https://open.larksuite.com/open-apis/sheets/v2/spreadsheets/${CAI_DAT.SHEET_TOKEN}/values_image`, { range: `${TAB_VIDEO}!${m[0]}:${m[0]}`, image: Array.from(u8), name: 'manifest-' + homNay() + '.jpg' });
        if (!r.json || r.json.code !== 0) throw new LoiMem('Lark không nhận ảnh (mã ' + (r.json ? r.json.code : r.status) + ')');
      } catch (e) { loi = e; continue; }
      // kiểm tra lại: ô đã có ảnh chưa
      const r2 = await goiLark('GET', `https://open.larksuite.com/open-apis/sheets/v2/spreadsheets/${CAI_DAT.SHEET_TOKEN}/values/${TAB_VIDEO}!${m[0]}:${m[0]}`, null);
      const c = (((r2.json && r2.json.data && r2.json.data.valueRange && r2.json.data.valueRange.values) || [])[0] || [])[0];
      if (c && (c.fileToken || (Array.isArray(c) && c.some((x) => x && x.fileToken)))) return true;
      loi = new LoiMem('đã gửi ảnh nhưng đọc lại ô ' + m[0] + ' chưa thấy ảnh');
    }
    throw loi;
  }
  function hienAnhMF(blob, oGhi) {
    document.getElementById('smhfb-mf')?.remove();
    const url = URL.createObjectURL(blob);
    const w = document.createElement('div'); w.id = 'smhfb-mf';
    w.innerHTML = `<div class="hop"><b>🖼 Ảnh manifest đã tạo và dán vào ô ${oGhi}</b><img src="${url}" style="height:min(72vh,660px);aspect-ratio:9/16;border-radius:10px;align-self:center;object-fit:contain;background:#000">
      <div class="nut-h"><a class="nut" href="${url}" download="manifest.jpg">⬇ Tải về máy</a><button class="nut chinh" data-k="dong">Đóng</button></div></div>`;
    const st = document.createElement('style'); st.textContent = '#smhfb-mf{position:fixed;inset:0;z-index:2147483600;background:rgba(0,0,0,.55);display:flex;align-items:center;justify-content:center}#smhfb-mf .hop{background:#fff;border-radius:16px;padding:16px 18px;display:flex;flex-direction:column;gap:10px;max-height:94vh;font:15px/1.4 system-ui,sans-serif;color:#222}#smhfb-mf .nut-h{display:flex;gap:8px;justify-content:center}#smhfb-mf .nut{font:700 15px system-ui,sans-serif;border-radius:10px;padding:10px 16px;border:2px solid #d9d2c4;background:#f6f3ec;color:#333;cursor:pointer;text-decoration:none}#smhfb-mf .nut.chinh{background:#2e7d4f;border-color:#2e7d4f;color:#fff}';
    w.appendChild(st); document.body.appendChild(w);
    w.addEventListener('click', (e) => { const k = e.target.getAttribute && e.target.getAttribute('data-k'); if (k === 'dong' || e.target === w) w.remove(); });
  }
  async function taoAnhMFVaoO(oChu, oNen, oGhi) {
    const B = (m) => ghi('Tạo ảnh manifest: ' + m);
    try {
      B(`đọc chữ ô ${oChu} và ảnh nền ô ${oNen}…`);
      const chu = await docOChu(oChu); if (!chu) throw new LoiMem('ô ' + oChu + ' chưa có chữ');
      const tN = await docOTep(oNen);
      if (tN.type !== 'embed-image' && !/^image\//.test(tN.mimeType || '') && !/\.(jpe?g|png|webp)$/i.test(tN.text || '')) throw new LoiMem(`ô ${oNen} không phải ảnh`);
      const nen = await taiTepLark(tN);
      await napFontMF();
      const kq = await taoAnhManifest(nen, chu);
      if (!kq.blob || kq.blob.size < 20000) throw new LoiMem('ảnh tạo ra bị lỗi');
      if (kq.phaiNhat > 1080 - 128) throw new LoiMem('chữ sát mép phải quá, cần rút ngắn chữ');
      B(`đã tạo ảnh ${(kq.blob.size / 1024).toFixed(0)} KB${kq.tl < 1 ? ' (chữ dài nên thu nhỏ còn ' + Math.round(kq.tl * 100) + '%)' : ''} → dán vào ô ${oGhi}`);
      await ghiAnhVaoO(oGhi, kq.blob);
      B(`XONG: ô ${oGhi} đã có ảnh manifest`);
      hienAnhMF(kq.blob, oGhi);
    } catch (e) { B('Lỗi: ' + e.message); chupLoi('tạo ảnh manifest'); alert('Tạo ảnh manifest chưa được: ' + e.message); }
  }
  // ===================== (5.9.1) SOẠN THỬ MANIFEST: 1 ảnh + 1 bài nhạc → video 15 giây =====================
  async function docOTep(o) { // o: 'N214' trong tab Kênh 1 → file đính kèm đầu tiên
    const m = String(o || '').trim().toUpperCase().match(/^([A-Z]{1,2})(\d+)$/); if (!m) throw new LoiMem('ô "' + o + '" không đúng dạng (ví dụ N214)');
    const url = `https://open.larksuite.com/open-apis/sheets/v2/spreadsheets/${CAI_DAT.SHEET_TOKEN}/values/${TAB_VIDEO}!${m[0]}:${m[0]}`;
    const r = await goiLark('GET', url, null);
    if (!r.json || r.json.code !== 0) throw new LoiMem('không đọc được ô ' + m[0] + ' (mã ' + (r.json ? r.json.code : r.status) + ')');
    const c = (((r.json.data && r.json.data.valueRange && r.json.data.valueRange.values) || [])[0] || [])[0];
    const tep = Array.isArray(c) ? c.find((x) => x && x.fileToken) : (c && c.fileToken ? Object.assign({ text: 'anh-trong-o', mimeType: 'image/' }, c) : null); // (5.9.2) ảnh dán thẳng vào ô (embed-image) cũng nhận
    if (!tep) throw new LoiMem('ô ' + m[0] + ' chưa có file đính kèm');
    return tep;
  }
  async function taiTepLark(tep) {
    let loi = null;
    for (let lan = 0; lan < 3; lan++) {
      if (lan) await sleep(3000);
      const t = await larkToken();
      const r = await new Promise((resolve) => GM_xmlhttpRequest({ method: 'GET', url: 'https://open.larksuite.com/open-apis/drive/v1/medias/' + encodeURIComponent(tep.fileToken) + '/download', headers: { Authorization: 'Bearer ' + t }, responseType: 'blob', timeout: 180000,
        onload: (x) => resolve({ blob: x.response }), onerror: () => resolve({ mang: 'mất kết nối' }), ontimeout: () => resolve({ mang: 'quá lâu' }) }));
      if (r.mang) { loi = new LoiMem('tải "' + tep.text + '" lỗi: ' + r.mang); continue; }
      if (!r.blob || r.blob.size < 2000 || (tep.size && Math.abs(r.blob.size - tep.size) > 1024)) { loi = new LoiMem('tải "' + tep.text + '" chưa đủ (' + (r.blob ? r.blob.size : 0) + ' byte)'); continue; }
      return r.blob;
    }
    throw loi;
  }
  function chonDinhDangGhi() {
    for (const t of ['video/mp4;codecs=avc1.42E01E,mp4a.40.2', 'video/mp4;codecs=avc1,mp4a.40.2', 'video/mp4', 'video/webm;codecs=vp9,opus', 'video/webm;codecs=vp8,opus', 'video/webm']) if (window.MediaRecorder && MediaRecorder.isTypeSupported(t)) return t;
    return '';
  }
  // ghép ảnh + nhạc thành video dọc 1080x1920, dài `giay` giây (ảnh phóng to chậm, nền mờ, nhạc nhỏ dần ở giây cuối)
  async function ghepManifest(anhBlob, nhacBlob, giay, bao) {
    if (document.visibilityState !== 'visible') throw new LoiMem('tab Facebook phải đang mở trên màn hình trong lúc tạo video');
    const mt = chonDinhDangGhi(); if (!mt) throw new LoiMem('trình duyệt này không tạo được video');
    const bm = await createImageBitmap(anhBlob);
    const W = 1080, H = 1920; const cv = document.createElement('canvas'); cv.width = W; cv.height = H; const g = cv.getContext('2d');
    const ve = (t) => { // t: 0..1
      g.fillStyle = '#000'; g.fillRect(0, 0, W, H);
      const kn = Math.max(W / bm.width, H / bm.height) * 1.1; // nền: phủ kín + mờ
      g.save(); g.filter = 'blur(40px) brightness(0.55)'; g.drawImage(bm, (W - bm.width * kn) / 2, (H - bm.height * kn) / 2, bm.width * kn, bm.height * kn); g.restore();
      const k = Math.min(W / bm.width, H / bm.height) * (1 + 0.06 * t); // ảnh chính: vừa khung, phóng to chậm 6%
      g.drawImage(bm, (W - bm.width * k) / 2, (H - bm.height * k) / 2, bm.width * k, bm.height * k);
    };
    ve(0);
    const ac = new (window.AudioContext || window.webkitAudioContext)();
    const buf = await ac.decodeAudioData(await nhacBlob.arrayBuffer());
    const src = ac.createBufferSource(); src.buffer = buf; src.loop = buf.duration < giay;
    const gain = ac.createGain(); const dich = ac.createMediaStreamDestination();
    src.connect(gain); gain.connect(dich); // không nối ra loa → không phát tiếng
    const vs = cv.captureStream(30);
    const st = new MediaStream([...vs.getVideoTracks(), ...dich.stream.getAudioTracks()]);
    const rec = new MediaRecorder(st, { mimeType: mt, videoBitsPerSecond: 5000000, audioBitsPerSecond: 128000 });
    const phan = []; rec.ondataavailable = (e) => { if (e.data && e.data.size) phan.push(e.data); };
    const xong = new Promise((r) => { rec.onstop = r; });
    if (ac.state === 'suspended') { try { await ac.resume(); } catch (e) { /* */ } }
    const t0 = ac.currentTime + 0.05;
    gain.gain.setValueAtTime(1, t0); gain.gain.setValueAtTime(1, t0 + giay - 1); gain.gain.linearRampToValueAtTime(0, t0 + giay);
    rec.start(500); src.start(t0);
    const bd = performance.now(); let cuoiBao = 0;
    await new Promise((resolve) => {
      const iv = setInterval(() => {
        const da = (performance.now() - bd) / 1000;
        ve(Math.min(1, da / giay));
        if (da - cuoiBao >= 1) { cuoiBao = Math.floor(da); bao(`đang tạo video ${cuoiBao}/${giay} giây`); }
        if (da >= giay) { clearInterval(iv); resolve(); }
      }, 33);
    });
    rec.stop(); try { src.stop(); } catch (e) { /* */ } await xong; try { ac.close(); } catch (e) { /* */ }
    vs.getTracks().forEach((t) => t.stop());
    const loai = mt.split(';')[0];
    const blob = new Blob(phan, { type: loai });
    if (blob.size < 50000) throw new LoiMem('video tạo ra quá nhỏ (' + blob.size + ' byte) — có thể tab bị ẩn trong lúc tạo');
    return new File([blob], 'manifest-' + Date.now() + (/mp4/.test(loai) ? '.mp4' : '.webm'), { type: loai });
  }
  // ---- thư viện ghép file mp4 (mp4-muxer 5.2.2, giấy phép MIT, Vanilagy) ----
  var Mp4Muxer=(()=>{var e=Object.defineProperty,t=Object.getOwnPropertyDescriptor,i=Object.getOwnPropertyNames,s=Object.prototype.hasOwnProperty,a=(e,t,i)=>{if(!t.has(e))throw TypeError("Cannot "+i)},r=(e,t,i)=>(a(e,t,"read from private field"),i?i.call(e):t.get(e)),n=(e,t,i)=>{if(t.has(e))throw TypeError("Cannot add the same private member more than once");t instanceof WeakSet?t.add(e):t.set(e,i)},o=(e,t,i,s)=>(a(e,t,"write to private field"),s?s.call(e,i):t.set(e,i),i),h=(e,t,i)=>(a(e,t,"access private method"),i),l={};((t,i)=>{for(var s in i)e(t,s,{get:i[s],enumerable:!0})})(l,{ArrayBufferTarget:()=>Me,FileSystemWritableFileStreamTarget:()=>Oe,Muxer:()=>Rt,StreamTarget:()=>We});var d,f,u,m,p,c,w,g,b=new Uint8Array(8),y=new DataView(b.buffer),k=e=>[(e%256+256)%256],T=e=>(y.setUint16(0,e,!1),[b[0],b[1]]),C=e=>(y.setUint32(0,e,!1),[b[1],b[2],b[3]]),v=e=>(y.setUint32(0,e,!1),[b[0],b[1],b[2],b[3]]),S=e=>(y.setUint32(0,Math.floor(e/2**32),!1),y.setUint32(4,e,!1),[b[0],b[1],b[2],b[3],b[4],b[5],b[6],b[7]]),x=e=>(y.setInt16(0,256*e,!1),[b[0],b[1]]),z=e=>(y.setInt32(0,65536*e,!1),[b[0],b[1],b[2],b[3]]),E=e=>(y.setInt32(0,2**30*e,!1),[b[0],b[1],b[2],b[3]]),A=(e,t=!1)=>{let i=Array(e.length).fill(null).map((t,i)=>e.charCodeAt(i));return t&&i.push(0),i},M=e=>e&&e[e.length-1],W=e=>{let t;for(let i of e)(!t||i.presentationTimestamp>t.presentationTimestamp)&&(t=i);return t},O=(e,t,i=!0)=>{let s=e*t;return i?Math.round(s):s},B=e=>{let t=e*(Math.PI/180),i=Math.cos(t),s=Math.sin(t);return[i,s,0,-s,i,0,0,0,1]},U=B(0),D=e=>[z(e[0]),z(e[1]),E(e[2]),z(e[3]),z(e[4]),E(e[5]),z(e[6]),z(e[7]),E(e[8])],j=e=>e?"object"!=typeof e?e:Array.isArray(e)?e.map(j):Object.fromEntries(Object.entries(e).map(([e,t])=>[e,j(t)])):e,R=e=>e>=0&&e<2**32,I=(e,t,i)=>({type:e,contents:t&&new Uint8Array(t.flat(10)),children:i}),N=(e,t,i,s,a)=>I(e,[k(t),C(i),s??[]],a),V=e=>({type:"mdat",largeSize:e}),F=(e,t,i=!1)=>I("moov",null,[L(t,e),...e.map(e=>$(e,t)),i?me(e):null]),L=(e,t)=>{let i=O(Math.max(0,...t.filter(e=>e.samples.length>0).map(e=>{const t=W(e.samples);return t.presentationTimestamp+t.duration})),Bt),s=Math.max(...t.map(e=>e.id))+1,a=!R(e)||!R(i),r=a?S:v;return N("mvhd",+a,0,[r(e),r(e),v(Bt),r(i),z(1),x(1),Array(10).fill(0),D(U),Array(24).fill(0),v(s)])},$=(e,t)=>I("trak",null,[P(e,t),H(e,t)]),P=(e,t)=>{let i,s=W(e.samples),a=O(s?s.presentationTimestamp+s.duration:0,Bt),r=!R(t)||!R(a),n=r?S:v;return i="video"===e.info.type?"number"==typeof e.info.rotation?B(e.info.rotation):e.info.rotation:U,N("tkhd",+r,3,[n(t),n(t),v(e.id),v(0),n(a),Array(8).fill(0),T(0),T(0),x("audio"===e.info.type?1:0),T(0),D(i),z("video"===e.info.type?e.info.width:0),z("video"===e.info.type?e.info.height:0)])},H=(e,t)=>I("mdia",null,[_(e,t),q("video"===e.info.type?"vide":"soun"),G(e)]),_=(e,t)=>{let i=W(e.samples),s=O(i?i.presentationTimestamp+i.duration:0,e.timescale),a=!R(t)||!R(s),r=a?S:v;return N("mdhd",+a,0,[r(t),r(t),v(e.timescale),r(s),T(21956),T(0)])},q=e=>N("hdlr",0,0,[A("mhlr"),A(e),v(0),v(0),v(0),A("mp4-muxer-hdlr",!0)]),G=e=>I("minf",null,["video"===e.info.type?J():K(),Q(),Z(e)]),J=()=>N("vmhd",0,1,[T(0),T(0),T(0),T(0)]),K=()=>N("smhd",0,0,[T(0),T(0)]),Q=()=>I("dinf",null,[X()]),X=()=>N("dref",0,0,[v(1)],[Y()]),Y=()=>N("url ",0,1),Z=e=>{const t=e.compositionTimeOffsetTable.length>1||e.compositionTimeOffsetTable.some(e=>0!==e.sampleCompositionTimeOffset);return I("stbl",null,[ee(e),oe(e),he(e),le(e),de(e),fe(e),t?ue(e):null])},ee=e=>N("stsd",0,0,[v(1)],["video"===e.info.type?te(Se[e.info.codec],e):ne(ze[e.info.codec],e)]),te=(e,t)=>{return I(e,[Array(6).fill(0),T(1),T(0),T(0),Array(12).fill(0),T(t.info.width),T(t.info.height),v(4718592),v(4718592),v(0),T(1),Array(32).fill(0),T(24),(i=65535,y.setInt16(0,i,!1),[b[0],b[1]])],[xe[t.info.codec](t),t.info.decoderConfig.colorSpace?re(t):null]);var i},ie={bt709:1,bt470bg:5,smpte170m:6},se={bt709:1,smpte170m:6,"iec61966-2-1":13},ae={rgb:0,bt709:1,bt470bg:5,smpte170m:6},re=e=>I("colr",[A("nclx"),T(ie[e.info.decoderConfig.colorSpace.primaries]),T(se[e.info.decoderConfig.colorSpace.transfer]),T(ae[e.info.decoderConfig.colorSpace.matrix]),k((e.info.decoderConfig.colorSpace.fullRange?1:0)<<7)]),ne=(e,t)=>I(e,[Array(6).fill(0),T(1),T(0),T(0),v(0),T(t.info.numberOfChannels),T(16),T(0),T(0),z(t.info.sampleRate)],[Ee[t.info.codec](t)]),oe=e=>N("stts",0,0,[v(e.timeToSampleTable.length),e.timeToSampleTable.map(e=>[v(e.sampleCount),v(e.sampleDelta)])]),he=e=>{if(e.samples.every(e=>"key"===e.type))return null;let t=[...e.samples.entries()].filter(([,e])=>"key"===e.type);return N("stss",0,0,[v(t.length),t.map(([e])=>v(e+1))])},le=e=>N("stsc",0,0,[v(e.compactlyCodedChunkTable.length),e.compactlyCodedChunkTable.map(e=>[v(e.firstChunk),v(e.samplesPerChunk),v(1)])]),de=e=>N("stsz",0,0,[v(0),v(e.samples.length),e.samples.map(e=>v(e.size))]),fe=e=>e.finalizedChunks.length>0&&M(e.finalizedChunks).offset>=2**32?N("co64",0,0,[v(e.finalizedChunks.length),e.finalizedChunks.map(e=>S(e.offset))]):N("stco",0,0,[v(e.finalizedChunks.length),e.finalizedChunks.map(e=>v(e.offset))]),ue=e=>N("ctts",0,0,[v(e.compositionTimeOffsetTable.length),e.compositionTimeOffsetTable.map(e=>[v(e.sampleCount),v(e.sampleCompositionTimeOffset)])]),me=e=>I("mvex",null,e.map(pe)),pe=e=>N("trex",0,0,[v(e.id),v(1),v(0),v(0),v(0)]),ce=(e,t)=>I("moof",null,[we(e),...t.map(be)]),we=e=>N("mfhd",0,0,[v(e)]),ge=e=>{let t=0,i=0,s="delta"===e.type;return i|=+s,t|=s?1:2,t<<24|i<<16},be=e=>I("traf",null,[ye(e),ke(e),Te(e)]),ye=e=>{let t=0;t|=8,t|=16,t|=32,t|=131072;let i=e.currentChunk.samples[1]??e.currentChunk.samples[0],s={duration:i.timescaleUnitsToNextSample,size:i.size,flags:ge(i)};return N("tfhd",0,131128,[v(e.id),v(s.duration),v(s.size),v(s.flags)])},ke=e=>N("tfdt",1,0,[S(O(e.currentChunk.startTimestamp,e.timescale))]),Te=e=>{let t=e.currentChunk.samples.map(e=>e.timescaleUnitsToNextSample),i=e.currentChunk.samples.map(e=>e.size),s=e.currentChunk.samples.map(ge),a=e.currentChunk.samples.map(t=>O(t.presentationTimestamp-t.decodeTimestamp,e.timescale)),r=new Set(t),n=new Set(i),o=new Set(s),h=new Set(a),l=2===o.size&&s[0]!==s[1],d=r.size>1,f=n.size>1,u=!l&&o.size>1,m=h.size>1||[...h].some(e=>0!==e),p=0;return p|=1,p|=4*+l,p|=256*+d,p|=512*+f,p|=1024*+u,p|=2048*+m,N("trun",1,p,[v(e.currentChunk.samples.length),v(e.currentChunk.offset-e.currentChunk.moofOffset||0),l?v(s[0]):[],e.currentChunk.samples.map((e,r)=>{return[d?v(t[r]):[],f?v(i[r]):[],u?v(s[r]):[],m?(n=a[r],y.setInt32(0,n,!1),[b[0],b[1],b[2],b[3]]):[]];var n})])},Ce=(e,t)=>N("tfra",1,0,[v(e.id),v(63),v(e.finalizedChunks.length),e.finalizedChunks.map(i=>[S(O(i.startTimestamp,e.timescale)),S(i.moofOffset),v(t+1),v(1),v(1)])]),ve=()=>N("mfro",0,0,[v(0)]),Se={avc:"avc1",hevc:"hvc1",vp9:"vp09",av1:"av01"},xe={avc:e=>e.info.decoderConfig&&I("avcC",[...new Uint8Array(e.info.decoderConfig.description)]),hevc:e=>e.info.decoderConfig&&I("hvcC",[...new Uint8Array(e.info.decoderConfig.description)]),vp9:e=>{if(!e.info.decoderConfig)return null;let t=e.info.decoderConfig;if(!t.colorSpace)throw new Error("'colorSpace' is required in the decoder config for VP9.");let i=t.codec.split("."),s=Number(i[1]),a=Number(i[2]),r=0+(Number(i[3])<<4)+Number(t.colorSpace.fullRange);return N("vpcC",1,0,[k(s),k(a),k(r),k(2),k(2),k(2),T(0)])},av1:()=>I("av1C",[129,0,0,0])},ze={aac:"mp4a",opus:"Opus"},Ee={aac:e=>{let t=new Uint8Array(e.info.decoderConfig.description);return N("esds",0,0,[v(58753152),k(32+t.byteLength),T(1),k(0),v(75530368),k(18+t.byteLength),k(64),k(21),C(0),v(130071),v(130071),v(92307584),k(t.byteLength),...t,v(109084800),k(1),k(2)])},opus:e=>{let t=3840,i=0;const s=e.info.decoderConfig?.description;if(s){if(s.byteLength<18)throw new TypeError("Invalid decoder description provided for Opus; must be at least 18 bytes long.");const e=ArrayBuffer.isView(s)?new DataView(s.buffer,s.byteOffset,s.byteLength):new DataView(s);t=e.getUint16(10,!0),i=e.getInt16(14,!0)}return I("dOps",[k(0),k(e.info.numberOfChannels),T(t),v(e.info.sampleRate),x(i),k(0)])}},Ae=(Symbol("isTarget"),class{}),Me=class extends Ae{constructor(){super(...arguments),this.buffer=null}},We=class extends Ae{constructor(e){if(super(),this.options=e,"object"!=typeof e)throw new TypeError("StreamTarget requires an options object to be passed to its constructor.");if(e.onData){if("function"!=typeof e.onData)throw new TypeError("options.onData, when provided, must be a function.");if(e.onData.length<2)throw new TypeError("options.onData, when provided, must be a function that takes in at least two arguments (data and position). Ignoring the position argument, which specifies the byte offset at which the data is to be written, can lead to broken outputs.")}if(void 0!==e.chunked&&"boolean"!=typeof e.chunked)throw new TypeError("options.chunked, when provided, must be a boolean.");if(void 0!==e.chunkSize&&(!Number.isInteger(e.chunkSize)||e.chunkSize<1024))throw new TypeError("options.chunkSize, when provided, must be an integer and not smaller than 1024.")}},Oe=class extends Ae{constructor(e,t){if(super(),this.stream=e,this.options=t,!(e instanceof FileSystemWritableFileStream))throw new TypeError("FileSystemWritableFileStreamTarget requires a FileSystemWritableFileStream instance.");if(void 0!==t&&"object"!=typeof t)throw new TypeError("FileSystemWritableFileStreamTarget's options, when provided, must be an object.");if(t&&void 0!==t.chunkSize&&(!Number.isInteger(t.chunkSize)||t.chunkSize<=0))throw new TypeError("options.chunkSize, when provided, must be a positive integer")}},Be=class{constructor(){this.pos=0,n(this,d,new Uint8Array(8)),n(this,f,new DataView(r(this,d).buffer)),this.offsets=new WeakMap}seek(e){this.pos=e}writeU32(e){r(this,f).setUint32(0,e,!1),this.write(r(this,d).subarray(0,4))}writeU64(e){r(this,f).setUint32(0,Math.floor(e/2**32),!1),r(this,f).setUint32(4,e,!1),this.write(r(this,d).subarray(0,8))}writeAscii(e){for(let t=0;t<e.length;t++)r(this,f).setUint8(t%8,e.charCodeAt(t)),t%8==7&&this.write(r(this,d));e.length%8!=0&&this.write(r(this,d).subarray(0,e.length%8))}writeBox(e){if(this.offsets.set(e,this.pos),e.contents&&!e.children)this.writeBoxHeader(e,e.size??e.contents.byteLength+8),this.write(e.contents);else{let t=this.pos;if(this.writeBoxHeader(e,0),e.contents&&this.write(e.contents),e.children)for(let t of e.children)t&&this.writeBox(t);let i=this.pos,s=e.size??i-t;this.seek(t),this.writeBoxHeader(e,s),this.seek(i)}}writeBoxHeader(e,t){this.writeU32(e.largeSize?1:t),this.writeAscii(e.type),e.largeSize&&this.writeU64(t)}measureBoxHeader(e){return 8+(e.largeSize?8:0)}patchBox(e){let t=this.pos;this.seek(this.offsets.get(e)),this.writeBox(e),this.seek(t)}measureBox(e){if(e.contents&&!e.children){return this.measureBoxHeader(e)+e.contents.byteLength}{let t=this.measureBoxHeader(e);if(e.contents&&(t+=e.contents.byteLength),e.children)for(let i of e.children)i&&(t+=this.measureBox(i));return t}}};d=new WeakMap,f=new WeakMap;var Ue=class extends Be{constructor(e){super(),n(this,w),n(this,u,void 0),n(this,m,new ArrayBuffer(65536)),n(this,p,new Uint8Array(r(this,m))),n(this,c,0),o(this,u,e)}write(e){h(this,w,g).call(this,this.pos+e.byteLength),r(this,p).set(e,this.pos),this.pos+=e.byteLength,o(this,c,Math.max(r(this,c),this.pos))}finalize(){h(this,w,g).call(this,this.pos),r(this,u).buffer=r(this,m).slice(0,Math.max(r(this,c),this.pos))}};u=new WeakMap,m=new WeakMap,p=new WeakMap,c=new WeakMap,w=new WeakSet,g=function(e){let t=r(this,m).byteLength;for(;t<e;)t*=2;if(t===r(this,m).byteLength)return;let i=new ArrayBuffer(t),s=new Uint8Array(i);s.set(r(this,p),0),o(this,m,i),o(this,p,s)};var De,je,Re,Ie,Ne,Ve,Fe,Le,$e,Pe,He,_e,qe,Ge=class extends Be{constructor(e){super(),n(this,Ve),n(this,Le),n(this,Pe),n(this,_e),n(this,De,void 0),n(this,je,[]),n(this,Re,void 0),n(this,Ie,void 0),n(this,Ne,[]),o(this,De,e),o(this,Re,e.options?.chunked??!1),o(this,Ie,e.options?.chunkSize??16777216)}write(e){r(this,je).push({data:e.slice(),start:this.pos}),this.pos+=e.byteLength}flush(){if(0===r(this,je).length)return;let e=[],t=[...r(this,je)].sort((e,t)=>e.start-t.start);e.push({start:t[0].start,size:t[0].data.byteLength});for(let i=1;i<t.length;i++){let s=e[e.length-1],a=t[i];a.start<=s.start+s.size?s.size=Math.max(s.size,a.start+a.data.byteLength-s.start):e.push({start:a.start,size:a.data.byteLength})}for(let t of e){t.data=new Uint8Array(t.size);for(let e of r(this,je))t.start<=e.start&&e.start<t.start+t.size&&t.data.set(e.data,e.start-t.start);r(this,Re)?(h(this,Ve,Fe).call(this,t.data,t.start),h(this,_e,qe).call(this)):r(this,De).options.onData?.(t.data,t.start)}r(this,je).length=0}finalize(){r(this,Re)&&h(this,_e,qe).call(this,!0)}};De=new WeakMap,je=new WeakMap,Re=new WeakMap,Ie=new WeakMap,Ne=new WeakMap,Ve=new WeakSet,Fe=function(e,t){let i=r(this,Ne).findIndex(e=>e.start<=t&&t<e.start+r(this,Ie));-1===i&&(i=h(this,Pe,He).call(this,t));let s=r(this,Ne)[i],a=t-s.start,n=e.subarray(0,Math.min(r(this,Ie)-a,e.byteLength));s.data.set(n,a);let o={start:a,end:a+n.byteLength};if(h(this,Le,$e).call(this,s,o),0===s.written[0].start&&s.written[0].end===r(this,Ie)&&(s.shouldFlush=!0),r(this,Ne).length>2){for(let e=0;e<r(this,Ne).length-1;e++)r(this,Ne)[e].shouldFlush=!0;h(this,_e,qe).call(this)}n.byteLength<e.byteLength&&h(this,Ve,Fe).call(this,e.subarray(n.byteLength),t+n.byteLength)},Le=new WeakSet,$e=function(e,t){let i=0,s=e.written.length-1,a=-1;for(;i<=s;){let r=Math.floor(i+(s-i+1)/2);e.written[r].start<=t.start?(i=r+1,a=r):s=r-1}for(e.written.splice(a+1,0,t),(-1===a||e.written[a].end<t.start)&&a++;a<e.written.length-1&&e.written[a].end>=e.written[a+1].start;)e.written[a].end=Math.max(e.written[a].end,e.written[a+1].end),e.written.splice(a+1,1)},Pe=new WeakSet,He=function(e){let t={start:Math.floor(e/r(this,Ie))*r(this,Ie),data:new Uint8Array(r(this,Ie)),written:[],shouldFlush:!1};return r(this,Ne).push(t),r(this,Ne).sort((e,t)=>e.start-t.start),r(this,Ne).indexOf(t)},_e=new WeakSet,qe=function(e=!1){for(let t=0;t<r(this,Ne).length;t++){let i=r(this,Ne)[t];if(i.shouldFlush||e){for(let e of i.written)r(this,De).options.onData?.(i.data.subarray(e.start,e.end),i.start+e.start);r(this,Ne).splice(t--,1)}}};var Je,Ke,Qe,Xe,Ye,Ze,et,tt,it,st,at,rt,nt,ot,ht,lt,dt,ft,ut,mt,pt,ct,wt,gt,bt,yt,kt,Tt,Ct,vt,St,xt,zt,Et,At,Mt,Wt,Ot=class extends Ge{constructor(e){super(new We({onData:(t,i)=>e.stream.write({type:"write",data:t,position:i}),chunked:!0,chunkSize:e.options?.chunkSize}))}},Bt=1e3,Ut=["avc","hevc","vp9","av1"],Dt=["aac","opus"],jt=["strict","offset","cross-track-offset"],Rt=class{constructor(e){if(n(this,nt),n(this,ht),n(this,dt),n(this,ut),n(this,pt),n(this,wt),n(this,bt),n(this,kt),n(this,Ct),n(this,St),n(this,zt),n(this,At),n(this,Je,void 0),n(this,Ke,void 0),n(this,Qe,void 0),n(this,Xe,void 0),n(this,Ye,null),n(this,Ze,null),n(this,et,Math.floor(Date.now()/1e3)+2082844800),n(this,tt,[]),n(this,it,1),n(this,st,[]),n(this,at,[]),n(this,rt,!1),h(this,nt,ot).call(this,e),e.video=j(e.video),e.audio=j(e.audio),e.fastStart=j(e.fastStart),this.target=e.target,o(this,Je,{firstTimestampBehavior:"strict",...e}),e.target instanceof Me)o(this,Ke,new Ue(e.target));else if(e.target instanceof We)o(this,Ke,new Ge(e.target));else{if(!(e.target instanceof Oe))throw new Error(`Invalid target: ${e.target}`);o(this,Ke,new Ot(e.target))}h(this,ut,mt).call(this),h(this,ht,lt).call(this)}addVideoChunk(e,t,i,s){if(!(e instanceof EncodedVideoChunk))throw new TypeError("addVideoChunk's first argument (sample) must be of type EncodedVideoChunk.");if(t&&"object"!=typeof t)throw new TypeError("addVideoChunk's second argument (meta), when provided, must be an object.");if(void 0!==i&&(!Number.isFinite(i)||i<0))throw new TypeError("addVideoChunk's third argument (timestamp), when provided, must be a non-negative real number.");if(void 0!==s&&!Number.isFinite(s))throw new TypeError("addVideoChunk's fourth argument (compositionTimeOffset), when provided, must be a real number.");let a=new Uint8Array(e.byteLength);e.copyTo(a),this.addVideoChunkRaw(a,e.type,i??e.timestamp,e.duration,t,s)}addVideoChunkRaw(e,t,i,s,a,n){if(!(e instanceof Uint8Array))throw new TypeError("addVideoChunkRaw's first argument (data) must be an instance of Uint8Array.");if("key"!==t&&"delta"!==t)throw new TypeError("addVideoChunkRaw's second argument (type) must be either 'key' or 'delta'.");if(!Number.isFinite(i)||i<0)throw new TypeError("addVideoChunkRaw's third argument (timestamp) must be a non-negative real number.");if(!Number.isFinite(s)||s<0)throw new TypeError("addVideoChunkRaw's fourth argument (duration) must be a non-negative real number.");if(a&&"object"!=typeof a)throw new TypeError("addVideoChunkRaw's fifth argument (meta), when provided, must be an object.");if(void 0!==n&&!Number.isFinite(n))throw new TypeError("addVideoChunkRaw's sixth argument (compositionTimeOffset), when provided, must be a real number.");if(h(this,At,Mt).call(this),!r(this,Je).video)throw new Error("No video track declared.");if("object"==typeof r(this,Je).fastStart&&r(this,Ye).samples.length===r(this,Je).fastStart.expectedVideoChunks)throw new Error(`Cannot add more video chunks than specified in 'fastStart' (${r(this,Je).fastStart.expectedVideoChunks}).`);let o=h(this,wt,gt).call(this,r(this,Ye),e,t,i,s,a,n);if("fragmented"===r(this,Je).fastStart&&r(this,Ze)){for(;r(this,at).length>0&&r(this,at)[0].decodeTimestamp<=o.decodeTimestamp;){let e=r(this,at).shift();h(this,bt,yt).call(this,r(this,Ze),e)}o.decodeTimestamp<=r(this,Ze).lastDecodeTimestamp?h(this,bt,yt).call(this,r(this,Ye),o):r(this,st).push(o)}else h(this,bt,yt).call(this,r(this,Ye),o)}addAudioChunk(e,t,i){if(!(e instanceof EncodedAudioChunk))throw new TypeError("addAudioChunk's first argument (sample) must be of type EncodedAudioChunk.");if(t&&"object"!=typeof t)throw new TypeError("addAudioChunk's second argument (meta), when provided, must be an object.");if(void 0!==i&&(!Number.isFinite(i)||i<0))throw new TypeError("addAudioChunk's third argument (timestamp), when provided, must be a non-negative real number.");let s=new Uint8Array(e.byteLength);e.copyTo(s),this.addAudioChunkRaw(s,e.type,i??e.timestamp,e.duration,t)}addAudioChunkRaw(e,t,i,s,a){if(!(e instanceof Uint8Array))throw new TypeError("addAudioChunkRaw's first argument (data) must be an instance of Uint8Array.");if("key"!==t&&"delta"!==t)throw new TypeError("addAudioChunkRaw's second argument (type) must be either 'key' or 'delta'.");if(!Number.isFinite(i)||i<0)throw new TypeError("addAudioChunkRaw's third argument (timestamp) must be a non-negative real number.");if(!Number.isFinite(s)||s<0)throw new TypeError("addAudioChunkRaw's fourth argument (duration) must be a non-negative real number.");if(a&&"object"!=typeof a)throw new TypeError("addAudioChunkRaw's fifth argument (meta), when provided, must be an object.");if(h(this,At,Mt).call(this),!r(this,Je).audio)throw new Error("No audio track declared.");if("object"==typeof r(this,Je).fastStart&&r(this,Ze).samples.length===r(this,Je).fastStart.expectedAudioChunks)throw new Error(`Cannot add more audio chunks than specified in 'fastStart' (${r(this,Je).fastStart.expectedAudioChunks}).`);let n=h(this,wt,gt).call(this,r(this,Ze),e,t,i,s,a);if("fragmented"===r(this,Je).fastStart&&r(this,Ye)){for(;r(this,st).length>0&&r(this,st)[0].decodeTimestamp<=n.decodeTimestamp;){let e=r(this,st).shift();h(this,bt,yt).call(this,r(this,Ye),e)}n.decodeTimestamp<=r(this,Ye).lastDecodeTimestamp?h(this,bt,yt).call(this,r(this,Ze),n):r(this,at).push(n)}else h(this,bt,yt).call(this,r(this,Ze),n)}finalize(){if(r(this,rt))throw new Error("Cannot finalize a muxer more than once.");if("fragmented"===r(this,Je).fastStart){for(let e of r(this,st))h(this,bt,yt).call(this,r(this,Ye),e);for(let e of r(this,at))h(this,bt,yt).call(this,r(this,Ze),e);h(this,St,xt).call(this,!1)}else r(this,Ye)&&h(this,Ct,vt).call(this,r(this,Ye)),r(this,Ze)&&h(this,Ct,vt).call(this,r(this,Ze));let e=[r(this,Ye),r(this,Ze)].filter(Boolean);if("in-memory"===r(this,Je).fastStart){let t;for(let i=0;i<2;i++){let i=F(e,r(this,et)),s=r(this,Ke).measureBox(i);t=r(this,Ke).measureBox(r(this,Xe));let a=r(this,Ke).pos+s+t;for(let e of r(this,tt)){e.offset=a;for(let{data:i}of e.samples)a+=i.byteLength,t+=i.byteLength}if(a<2**32)break;t>=2**32&&(r(this,Xe).largeSize=!0)}let i=F(e,r(this,et));r(this,Ke).writeBox(i),r(this,Xe).size=t,r(this,Ke).writeBox(r(this,Xe));for(let e of r(this,tt))for(let t of e.samples)r(this,Ke).write(t.data),t.data=null}else if("fragmented"===r(this,Je).fastStart){let t=r(this,Ke).pos,i=(e=>I("mfra",null,[...e.map(Ce),ve()]))(e);r(this,Ke).writeBox(i);let s=r(this,Ke).pos-t;r(this,Ke).seek(r(this,Ke).pos-4),r(this,Ke).writeU32(s)}else{let t=r(this,Ke).offsets.get(r(this,Xe)),i=r(this,Ke).pos-t;r(this,Xe).size=i,r(this,Xe).largeSize=i>=2**32,r(this,Ke).patchBox(r(this,Xe));let s=F(e,r(this,et));if("object"==typeof r(this,Je).fastStart){r(this,Ke).seek(r(this,Qe)),r(this,Ke).writeBox(s);let e=t-r(this,Ke).pos;r(this,Ke).writeBox({type:"free",size:e})}else r(this,Ke).writeBox(s)}h(this,zt,Et).call(this),r(this,Ke).finalize(),o(this,rt,!0)}};return Je=new WeakMap,Ke=new WeakMap,Qe=new WeakMap,Xe=new WeakMap,Ye=new WeakMap,Ze=new WeakMap,et=new WeakMap,tt=new WeakMap,it=new WeakMap,st=new WeakMap,at=new WeakMap,rt=new WeakMap,nt=new WeakSet,ot=function(e){if("object"!=typeof e)throw new TypeError("The muxer requires an options object to be passed to its constructor.");if(!(e.target instanceof Ae))throw new TypeError("The target must be provided and an instance of Target.");if(e.video){if(!Ut.includes(e.video.codec))throw new TypeError(`Unsupported video codec: ${e.video.codec}`);if(!Number.isInteger(e.video.width)||e.video.width<=0)throw new TypeError(`Invalid video width: ${e.video.width}. Must be a positive integer.`);if(!Number.isInteger(e.video.height)||e.video.height<=0)throw new TypeError(`Invalid video height: ${e.video.height}. Must be a positive integer.`);const t=e.video.rotation;if("number"==typeof t&&![0,90,180,270].includes(t))throw new TypeError(`Invalid video rotation: ${t}. Has to be 0, 90, 180 or 270.`);if(Array.isArray(t)&&(9!==t.length||t.some(e=>"number"!=typeof e)))throw new TypeError(`Invalid video transformation matrix: ${t.join()}`);if(void 0!==e.video.frameRate&&(!Number.isInteger(e.video.frameRate)||e.video.frameRate<=0))throw new TypeError(`Invalid video frame rate: ${e.video.frameRate}. Must be a positive integer.`)}if(e.audio){if(!Dt.includes(e.audio.codec))throw new TypeError(`Unsupported audio codec: ${e.audio.codec}`);if(!Number.isInteger(e.audio.numberOfChannels)||e.audio.numberOfChannels<=0)throw new TypeError(`Invalid number of audio channels: ${e.audio.numberOfChannels}. Must be a positive integer.`);if(!Number.isInteger(e.audio.sampleRate)||e.audio.sampleRate<=0)throw new TypeError(`Invalid audio sample rate: ${e.audio.sampleRate}. Must be a positive integer.`)}if(e.firstTimestampBehavior&&!jt.includes(e.firstTimestampBehavior))throw new TypeError(`Invalid first timestamp behavior: ${e.firstTimestampBehavior}`);if("object"==typeof e.fastStart){if(e.video){if(void 0===e.fastStart.expectedVideoChunks)throw new TypeError("'fastStart' is an object but is missing property 'expectedVideoChunks'.");if(!Number.isInteger(e.fastStart.expectedVideoChunks)||e.fastStart.expectedVideoChunks<0)throw new TypeError("'expectedVideoChunks' must be a non-negative integer.")}if(e.audio){if(void 0===e.fastStart.expectedAudioChunks)throw new TypeError("'fastStart' is an object but is missing property 'expectedAudioChunks'.");if(!Number.isInteger(e.fastStart.expectedAudioChunks)||e.fastStart.expectedAudioChunks<0)throw new TypeError("'expectedAudioChunks' must be a non-negative integer.")}}else if(![!1,"in-memory","fragmented"].includes(e.fastStart))throw new TypeError("'fastStart' option must be false, 'in-memory', 'fragmented' or an object.");if(void 0!==e.minFragmentDuration&&(!Number.isFinite(e.minFragmentDuration)||e.minFragmentDuration<0))throw new TypeError("'minFragmentDuration' must be a non-negative number.")},ht=new WeakSet,lt=function(){var e;if(r(this,Ke).writeBox((e={holdsAvc:"avc"===r(this,Je).video?.codec,fragmented:"fragmented"===r(this,Je).fastStart}).fragmented?I("ftyp",[A("iso5"),v(512),A("iso5"),A("iso6"),A("mp41")]):I("ftyp",[A("isom"),v(512),A("isom"),e.holdsAvc?A("avc1"):[],A("mp41")])),o(this,Qe,r(this,Ke).pos),"in-memory"===r(this,Je).fastStart)o(this,Xe,V(!1));else if("fragmented"===r(this,Je).fastStart);else{if("object"==typeof r(this,Je).fastStart){let e=h(this,dt,ft).call(this);r(this,Ke).seek(r(this,Ke).pos+e)}o(this,Xe,V(!0)),r(this,Ke).writeBox(r(this,Xe))}h(this,zt,Et).call(this)},dt=new WeakSet,ft=function(){if("object"!=typeof r(this,Je).fastStart)return;let e=0,t=[r(this,Je).fastStart.expectedVideoChunks,r(this,Je).fastStart.expectedAudioChunks];for(let i of t)i&&(e+=8*Math.ceil(2/3*i),e+=4*i,e+=12*Math.ceil(2/3*i),e+=4*i,e+=8*i);return e+=4096,e},ut=new WeakSet,mt=function(){if(r(this,Je).video&&o(this,Ye,{id:1,info:{type:"video",codec:r(this,Je).video.codec,width:r(this,Je).video.width,height:r(this,Je).video.height,rotation:r(this,Je).video.rotation??0,decoderConfig:null},timescale:r(this,Je).video.frameRate??57600,samples:[],finalizedChunks:[],currentChunk:null,firstDecodeTimestamp:void 0,lastDecodeTimestamp:-1,timeToSampleTable:[],compositionTimeOffsetTable:[],lastTimescaleUnits:null,lastSample:null,compactlyCodedChunkTable:[]}),r(this,Je).audio&&(o(this,Ze,{id:r(this,Je).video?2:1,info:{type:"audio",codec:r(this,Je).audio.codec,numberOfChannels:r(this,Je).audio.numberOfChannels,sampleRate:r(this,Je).audio.sampleRate,decoderConfig:null},timescale:r(this,Je).audio.sampleRate,samples:[],finalizedChunks:[],currentChunk:null,firstDecodeTimestamp:void 0,lastDecodeTimestamp:-1,timeToSampleTable:[],compositionTimeOffsetTable:[],lastTimescaleUnits:null,lastSample:null,compactlyCodedChunkTable:[]}),"aac"===r(this,Je).audio.codec)){let e=h(this,pt,ct).call(this,2,r(this,Je).audio.sampleRate,r(this,Je).audio.numberOfChannels);r(this,Ze).info.decoderConfig={codec:r(this,Je).audio.codec,description:e,numberOfChannels:r(this,Je).audio.numberOfChannels,sampleRate:r(this,Je).audio.sampleRate}}},pt=new WeakSet,ct=function(e,t,i){let s=[96e3,88200,64e3,48e3,44100,32e3,24e3,22050,16e3,12e3,11025,8e3,7350].indexOf(t),a=i,r="";r+=e.toString(2).padStart(5,"0"),r+=s.toString(2).padStart(4,"0"),15===s&&(r+=t.toString(2).padStart(24,"0")),r+=a.toString(2).padStart(4,"0");let n=8*Math.ceil(r.length/8);r=r.padEnd(n,"0");let o=new Uint8Array(r.length/8);for(let e=0;e<r.length;e+=8)o[e/8]=parseInt(r.slice(e,e+8),2);return o},wt=new WeakSet,gt=function(e,t,i,s,a,r,n){let o=s/1e6,l=(s-(n??0))/1e6,d=a/1e6,f=h(this,kt,Tt).call(this,o,l,e);return o=f.presentationTimestamp,l=f.decodeTimestamp,r?.decoderConfig&&(null===e.info.decoderConfig?e.info.decoderConfig=r.decoderConfig:Object.assign(e.info.decoderConfig,r.decoderConfig)),{presentationTimestamp:o,decodeTimestamp:l,duration:d,data:t,size:t.byteLength,type:i,timescaleUnitsToNextSample:O(d,e.timescale)}},bt=new WeakSet,yt=function(e,t){"fragmented"!==r(this,Je).fastStart&&e.samples.push(t);const i=O(t.presentationTimestamp-t.decodeTimestamp,e.timescale);if(null!==e.lastTimescaleUnits){let s=O(t.decodeTimestamp,e.timescale,!1),a=Math.round(s-e.lastTimescaleUnits);if(e.lastTimescaleUnits+=a,e.lastSample.timescaleUnitsToNextSample=a,"fragmented"!==r(this,Je).fastStart){let t=M(e.timeToSampleTable);1===t.sampleCount?(t.sampleDelta=a,t.sampleCount++):t.sampleDelta===a?t.sampleCount++:(t.sampleCount--,e.timeToSampleTable.push({sampleCount:2,sampleDelta:a}));const s=M(e.compositionTimeOffsetTable);s.sampleCompositionTimeOffset===i?s.sampleCount++:e.compositionTimeOffsetTable.push({sampleCount:1,sampleCompositionTimeOffset:i})}}else e.lastTimescaleUnits=0,"fragmented"!==r(this,Je).fastStart&&(e.timeToSampleTable.push({sampleCount:1,sampleDelta:O(t.duration,e.timescale)}),e.compositionTimeOffsetTable.push({sampleCount:1,sampleCompositionTimeOffset:i}));e.lastSample=t;let s=!1;if(e.currentChunk){let i=t.presentationTimestamp-e.currentChunk.startTimestamp;if("fragmented"===r(this,Je).fastStart){let a=r(this,Ye)??r(this,Ze);const n=r(this,Je).minFragmentDuration??1;e===a&&"key"===t.type&&i>=n&&(s=!0,h(this,St,xt).call(this))}else s=i>=.5}else s=!0;s&&(e.currentChunk&&h(this,Ct,vt).call(this,e),e.currentChunk={startTimestamp:t.presentationTimestamp,samples:[]}),e.currentChunk.samples.push(t)},kt=new WeakSet,Tt=function(e,t,i){const s="strict"===r(this,Je).firstTimestampBehavior,a=-1===i.lastDecodeTimestamp;if(s&&a&&0!==t)throw new Error(`The first chunk for your media track must have a timestamp of 0 (received DTS=${t}).Non-zero first timestamps are often caused by directly piping frames or audio data from a MediaStreamTrack into the encoder. Their timestamps are typically relative to the age of thedocument, which is probably what you want.\n\nIf you want to offset all timestamps of a track such that the first one is zero, set firstTimestampBehavior: 'offset' in the options.\n`);if("offset"===r(this,Je).firstTimestampBehavior||"cross-track-offset"===r(this,Je).firstTimestampBehavior){let s;void 0===i.firstDecodeTimestamp&&(i.firstDecodeTimestamp=t),s="offset"===r(this,Je).firstTimestampBehavior?i.firstDecodeTimestamp:Math.min(r(this,Ye)?.firstDecodeTimestamp??1/0,r(this,Ze)?.firstDecodeTimestamp??1/0),t-=s,e-=s}if(t<i.lastDecodeTimestamp)throw new Error(`Timestamps must be monotonically increasing (DTS went from ${1e6*i.lastDecodeTimestamp} to ${1e6*t}).`);return i.lastDecodeTimestamp=t,{presentationTimestamp:e,decodeTimestamp:t}},Ct=new WeakSet,vt=function(e){if("fragmented"===r(this,Je).fastStart)throw new Error("Can't finalize individual chunks if 'fastStart' is set to 'fragmented'.");if(e.currentChunk)if(e.finalizedChunks.push(e.currentChunk),r(this,tt).push(e.currentChunk),0!==e.compactlyCodedChunkTable.length&&M(e.compactlyCodedChunkTable).samplesPerChunk===e.currentChunk.samples.length||e.compactlyCodedChunkTable.push({firstChunk:e.finalizedChunks.length,samplesPerChunk:e.currentChunk.samples.length}),"in-memory"!==r(this,Je).fastStart){e.currentChunk.offset=r(this,Ke).pos;for(let t of e.currentChunk.samples)r(this,Ke).write(t.data),t.data=null;h(this,zt,Et).call(this)}else e.currentChunk.offset=0},St=new WeakSet,xt=function(e=!0){if("fragmented"!==r(this,Je).fastStart)throw new Error("Can't finalize a fragment unless 'fastStart' is set to 'fragmented'.");let t=[r(this,Ye),r(this,Ze)].filter(e=>e&&e.currentChunk);if(0===t.length)return;let i=(s=this,a=it,{set _(e){o(s,a,e,n)},get _(){return r(s,a,l)}})._++;var s,a,n,l;if(1===i){let e=F(t,r(this,et),!0);r(this,Ke).writeBox(e)}let d=r(this,Ke).pos,f=ce(i,t);r(this,Ke).writeBox(f);{let e=V(!1),i=0;for(let e of t)for(let t of e.currentChunk.samples)i+=t.size;let s=r(this,Ke).measureBox(e)+i;s>=2**32&&(e.largeSize=!0,s=r(this,Ke).measureBox(e)+i),e.size=s,r(this,Ke).writeBox(e)}for(let e of t){e.currentChunk.offset=r(this,Ke).pos,e.currentChunk.moofOffset=d;for(let t of e.currentChunk.samples)r(this,Ke).write(t.data),t.data=null}let u=r(this,Ke).pos;r(this,Ke).seek(r(this,Ke).offsets.get(f));let m=ce(i,t);r(this,Ke).writeBox(m),r(this,Ke).seek(u);for(let e of t)e.finalizedChunks.push(e.currentChunk),r(this,tt).push(e.currentChunk),e.currentChunk=null;e&&h(this,zt,Et).call(this)},zt=new WeakSet,Et=function(){r(this,Ke)instanceof Ge&&r(this,Ke).flush()},At=new WeakSet,Mt=function(){if(r(this,rt))throw new Error("Cannot add new video or audio chunks after the file has been finalized.")},Wt=l,((a,r,n,o)=>{if(r&&"object"==typeof r||"function"==typeof r)for(let h of i(r))s.call(a,h)||h===n||e(a,h,{get:()=>r[h],enumerable:!(o=t(r,h))||o.enumerable});return a})(e({},"__esModule",{value:!0}),Wt)})();"object"==typeof module&&"object"==typeof module.exports&&Object.assign(module.exports,Mp4Muxer);
  // (5.9.2) ghép ảnh + nhạc → video mp4 dọc 1080x1920 bằng bộ mã hoá có sẵn của trình duyệt (không cần phát nhạc, không cần người bấm, tab ẩn vẫn chạy)
  // (5.9.5) hiệu ứng SIÊU NHẸ cho video manifest — chữ trên ảnh luôn đọc rõ; 1 giây đầu luôn là ảnh gốc (để làm hình thu nhỏ)
  const HIEU_UNG_MF = [
    ['nhiptho', 'Nhịp thở nhẹ'], ['anhsang', 'Ánh sáng lướt nhẹ'], ['hatsang', 'Hạt sáng bay nhẹ'],
    ['lapanh', 'Bụi vàng lấp lánh'], ['domdom', 'Đom đóm bay lượn'], ['khoitram', 'Khói trầm bay nhẹ'],
    ['hatroi', 'Hạt vàng rơi nhẹ'], ['bokeh', 'Đốm sáng mờ trôi'],
  ];
  const ngauMF = (i, n) => { const x = Math.sin(i * 127.1 + n * 311.7) * 43758.5453; return x - Math.floor(x); };
  const HAT_MF = Array.from({ length: 26 }, (_, i) => ({ x: ngauMF(i, 1), y: ngauMF(i, 2), v: 0.025 + ngauMF(i, 3) * 0.035, kt: 1.6 + ngauMF(i, 4) * 2.4, pha: ngauMF(i, 5) * 6.28, lac: 8 + ngauMF(i, 6) * 14 }));
  const LAP_MF = Array.from({ length: 28 }, (_, i) => ({ x: 0.04 + ngauMF(i + 50, 1) * 0.92, y: 0.04 + ngauMF(i + 50, 2) * 0.92, w: 0.7 + ngauMF(i + 50, 3) * 1.1, pha: ngauMF(i + 50, 4) * 6.28, kt: 3 + ngauMF(i + 50, 5) * 4 }));
  const DOM_MF = Array.from({ length: 13 }, (_, i) => ({ x: 0.08 + ngauMF(i + 90, 1) * 0.84, y: 0.1 + ngauMF(i + 90, 2) * 0.8, f1: 0.18 + ngauMF(i + 90, 3) * 0.2, f2: 0.14 + ngauMF(i + 90, 4) * 0.2, p1: ngauMF(i + 90, 5) * 6.28, p2: ngauMF(i + 90, 6) * 6.28, nhay: 0.8 + ngauMF(i + 90, 7) * 0.9 }));
  const KHOI_MF = Array.from({ length: 7 }, (_, i) => ({ x: 0.1 + ngauMF(i + 130, 1) * 0.8, chu: 7 + ngauMF(i + 130, 2) * 4, lech: ngauMF(i + 130, 3), lac: 0.03 + ngauMF(i + 130, 4) * 0.05, pha: ngauMF(i + 130, 5) * 6.28 }));
  const ROI_MF = Array.from({ length: 24 }, (_, i) => ({ x: ngauMF(i + 170, 1), y: ngauMF(i + 170, 2), v: 0.03 + ngauMF(i + 170, 3) * 0.035, kt: 2 + ngauMF(i + 170, 4) * 2.6, pha: ngauMF(i + 170, 5) * 6.28, lac: 10 + ngauMF(i + 170, 6) * 18 }));
  const BOK_MF = Array.from({ length: 9 }, (_, i) => { const canh = i % 2 === 0; return { x: canh ? (ngauMF(i + 210, 1) < 0.5 ? 0.02 + ngauMF(i + 210, 2) * 0.16 : 0.82 + ngauMF(i + 210, 2) * 0.16) : ngauMF(i + 210, 2), y: ngauMF(i + 210, 3), r: 45 + ngauMF(i + 210, 4) * 70, vx: (ngauMF(i + 210, 5) - 0.5) * 0.008, vy: -0.004 - ngauMF(i + 210, 6) * 0.008, pha: ngauMF(i + 210, 7) * 6.28 }; });
  // vẽ 1 đốm sáng tròn mờ
  function dotMF(g, x, y, r, mau, a) {
    if (a <= 0.002) return;
    const gr = g.createRadialGradient(x, y, 0, x, y, r); gr.addColorStop(0, `rgba(${mau},${a.toFixed(3)})`); gr.addColorStop(1, `rgba(${mau},0)`);
    g.fillStyle = gr; g.fillRect(x - r, y - r, r * 2, r * 2);
  }
  // vẽ 1 khung: t = 0..1 trên cả video, giay = độ dài video (giây)
  function veKhungMF(g, nen, bm, W, H, t, hu, giay) {
    giay = giay || 15;
    const s = t * giay; // giây hiện tại
    const st = s - 1; // thời gian tính từ lúc hiệu ứng bắt đầu (sau giây thứ 1)
    const vao = Math.max(0, Math.min(1, st / 1.2)); // hiệu ứng "vào" từ từ trong 1,2 giây
    const em = (x) => x * x * (3 - 2 * x);
    const fit = Math.min(W / bm.width, H / bm.height);
    let k = fit;
    if (hu === 'nhiptho') k = fit * (1 + 0.015 * (1 - Math.cos(st * Math.PI * 2 / 5)) * vao); // 0 → 3% → 0, chu kỳ 5 giây
    if (s < 1) k = fit;
    g.globalAlpha = 1; g.globalCompositeOperation = 'source-over'; g.drawImage(nen, 0, 0);
    const fx = (W - bm.width * fit) / 2, fy = (H - bm.height * fit) / 2, fw = bm.width * fit, fh = bm.height * fit;
    g.save(); g.beginPath(); g.rect(fx, fy, fw, fh); g.clip();
    const w = bm.width * k, h = bm.height * k; g.drawImage(bm, (W - w) / 2, (H - h) / 2, w, h);
    if (s >= 1) {
      g.globalCompositeOperation = 'screen';
      if (hu === 'anhsang') { // 1 dải sáng rất mờ, lướt trọn từ trái sang phải, từ giây 2 đến giây ~9
        const p = (s - 2) / 7;
        if (p > 0 && p < 1) {
          const goc = 0.35, bang = 260; const tran = Math.tan(goc) * H / 2 + bang;
          const cx = fx - tran + p * (fw + 2 * tran); const nx = Math.cos(goc), ny = -Math.sin(goc);
          const gr = g.createLinearGradient(cx - nx * bang, H / 2 - ny * bang, cx + nx * bang, H / 2 + ny * bang);
          const doSang = 0.13 * Math.sin(p * Math.PI); // sáng dần rồi mờ dần, không bị cắt ngang
          gr.addColorStop(0, 'rgba(255,240,205,0)'); gr.addColorStop(0.5, `rgba(255,240,205,${doSang.toFixed(3)})`); gr.addColorStop(1, 'rgba(255,240,205,0)');
          g.fillStyle = gr; g.fillRect(fx, fy, fw, fh);
        }
      } else if (hu === 'hatsang') { // vài hạt sáng vàng nhỏ bay lên chậm, rất mờ
        for (const p of HAT_MF) {
          const y = (((p.y - st * p.v) % 1) + 1) % 1; const x = p.x + Math.sin(st * 0.8 + p.pha) * p.lac / W;
          const a = 0.33 * vao * Math.min(1, y * 6, (1 - y) * 6) * (0.65 + 0.35 * Math.sin(s * 2 + p.pha));
          dotMF(g, fx + x * fw, fy + y * fh, p.kt * 3, '255,225,150', a);
        }
      } else if (hu === 'lapanh') { // bụi vàng đứng yên, lấp lánh lúc ẩn lúc hiện như kim tuyến
        for (const p of LAP_MF) {
          const nh = Math.pow(Math.max(0, Math.sin(st * p.w * 1.6 + p.pha)), 6) * vao; if (nh < 0.01) continue;
          const px = fx + p.x * fw, py = fy + p.y * fh;
          dotMF(g, px, py, p.kt * 3.2, '255,228,160', 0.42 * nh);
          g.strokeStyle = `rgba(255,240,200,${(0.38 * nh).toFixed(3)})`; g.lineWidth = 1.2; const d = p.kt * 3.2 * (0.7 + 0.5 * nh);
          g.beginPath(); g.moveTo(px - d, py); g.lineTo(px + d, py); g.moveTo(px, py - d); g.lineTo(px, py + d); g.stroke();
        }
      } else if (hu === 'domdom') { // vài đom đóm vàng ấm bay lượn chậm, chớp sáng dịu
        for (const p of DOM_MF) {
          const x = p.x + Math.sin(st * p.f1 + p.p1) * 0.05 + Math.sin(st * p.f1 * 2.3 + p.p2) * 0.015;
          const y = p.y + Math.sin(st * p.f2 + p.p2) * 0.04 - st * 0.004;
          const a = vao * (0.16 + 0.2 * (0.5 + 0.5 * Math.sin(st * p.nhay * 2 + p.p1)));
          const px = fx + x * fw, py = fy + y * fh;
          dotMF(g, px, py, 22, '255,214,120', a * 0.55); dotMF(g, px, py, 6, '255,245,200', a * 1.6);
        }
      } else if (hu === 'khoitram') { // vài làn khói trầm rất mờ bốc lên từ đáy ảnh rồi tan dần
        for (const p of KHOI_MF) {
          const q = (((st / p.chu + p.lech) % 1) + 1) % 1; // 0..1 vòng đời 1 làn khói
          const y = 1.08 - q * 0.6, x = p.x + Math.sin(st * 0.45 + p.pha) * p.lac + q * 0.04;
          const a = 0.075 * vao * Math.sin(q * Math.PI); const r = (70 + q * 200) * (fw / 1080);
          dotMF(g, fx + x * fw, fy + y * fh, r, '235,225,215', a);
          dotMF(g, fx + (x + 0.03 * Math.sin(st + p.pha)) * fw, fy + (y + 0.04) * fh, r * 0.6, '235,225,215', a * 0.8);
        }
      } else if (hu === 'hatroi') { // hạt vàng nhỏ rơi chậm từ trên xuống, đung đưa nhẹ
        for (const p of ROI_MF) {
          const y = (((p.y + st * p.v) % 1) + 1) % 1; const x = p.x + Math.sin(st * 0.9 + p.pha) * p.lac / W;
          const a = 0.34 * vao * Math.min(1, y * 6, (1 - y) * 6) * (0.7 + 0.3 * Math.sin(s * 1.7 + p.pha));
          dotMF(g, fx + x * fw, fy + y * fh, p.kt * 3, '255,215,130', a);
        }
      } else if (hu === 'bokeh') { // vài đốm sáng to, rất mờ (như ống kính nhoè) trôi chậm, chủ yếu ở 2 bên
        for (const p of BOK_MF) {
          const x = p.x + st * p.vx + Math.sin(st * 0.3 + p.pha) * 0.01; const y = (((p.y + st * p.vy) % 1.2) + 1.2) % 1.2 - 0.1;
          const a = vao * (0.05 + 0.025 * Math.sin(st * 0.7 + p.pha));
          const px = fx + x * fw, py = fy + y * fh, r = p.r * (fw / 1080);
          const gr = g.createRadialGradient(px, py, r * 0.55, px, py, r); gr.addColorStop(0, `rgba(255,220,160,${a.toFixed(3)})`); gr.addColorStop(0.85, `rgba(255,220,160,${(a * 0.8).toFixed(3)})`); gr.addColorStop(1, 'rgba(255,220,160,0)');
          g.fillStyle = gr; g.beginPath(); g.arc(px, py, r, 0, Math.PI * 2); g.fill();
        }
      }
      g.globalCompositeOperation = 'source-over';
    }
    g.restore();
    if (t > 0.95) { g.fillStyle = `rgba(0,0,0,${((t - 0.95) / 0.05 * 0.25).toFixed(3)})`; g.fillRect(0, 0, W, H); } // tối rất nhẹ ở cuối lúc nhạc nhỏ dần
  }
  async function ghepManifestWC(anhBlob, nhacBlob, giay, bao, hieuUng) {
    const hu = HIEU_UNG_MF.some(([m]) => m === hieuUng) ? hieuUng : HIEU_UNG_MF[Math.floor(Math.random() * HIEU_UNG_MF.length)][0];
    bao('hiệu ứng: ' + HIEU_UNG_MF.find(([m]) => m === hu)[1]);
    if (typeof VideoEncoder === 'undefined' || typeof AudioEncoder === 'undefined') throw new Error('trình duyệt chưa hỗ trợ tạo video (cần Chrome mới)');
    const W = 1080, H = 1920, FPS = 30, SR = 44100, KENH = 2;
    // 1) nhạc: giải mã + cắt đúng `giay` giây + nhỏ dần ở giây cuối (xử lý ngoại tuyến, không phát ra loa)
    bao('đang xử lý nhạc');
    const oac = new OfflineAudioContext(KENH, Math.round(SR * giay), SR);
    const goc = await oac.decodeAudioData(await nhacBlob.arrayBuffer());
    const src = oac.createBufferSource(); src.buffer = goc; src.loop = goc.duration < giay;
    const gain = oac.createGain(); gain.gain.setValueAtTime(1, 0); gain.gain.setValueAtTime(1, Math.max(0, giay - 1)); gain.gain.linearRampToValueAtTime(0, giay);
    src.connect(gain); gain.connect(oac.destination); src.start(0);
    const am = await oac.startRendering();
    // 2) ảnh: vẽ sẵn nền mờ 1 lần
    const bm = await createImageBitmap(anhBlob);
    const nen = document.createElement('canvas'); nen.width = W; nen.height = H; const gn = nen.getContext('2d');
    gn.fillStyle = '#000'; gn.fillRect(0, 0, W, H);
    const kn = Math.max(W / bm.width, H / bm.height) * 1.1;
    gn.filter = 'blur(40px) brightness(0.55)'; gn.drawImage(bm, (W - bm.width * kn) / 2, (H - bm.height * kn) / 2, bm.width * kn, bm.height * kn); gn.filter = 'none';
    const cv = document.createElement('canvas'); cv.width = W; cv.height = H; const g = cv.getContext('2d');
    const ve = (t) => veKhungMF(g, nen, bm, W, H, t, hu, giay);
    // 3) chọn kiểu mã hoá video được hỗ trợ
    let vcfg = null;
    for (const codec of ['avc1.640028', 'avc1.4d0028', 'avc1.42e028', 'avc1.42003e']) {
      const c = { codec, width: W, height: H, bitrate: 4000000, framerate: FPS, avc: { format: 'avc' } };
      try { if ((await VideoEncoder.isConfigSupported(c)).supported) { vcfg = c; break; } } catch (e) { /* */ }
    }
    if (!vcfg) throw new Error('trình duyệt không mã hoá được video H.264');
    const acfg = { codec: 'mp4a.40.2', sampleRate: SR, numberOfChannels: KENH, bitrate: 128000 };
    if (!(await AudioEncoder.isConfigSupported(acfg)).supported) throw new Error('trình duyệt không mã hoá được âm thanh AAC');
    const muxer = new Mp4Muxer.Muxer({ target: new Mp4Muxer.ArrayBufferTarget(), video: { codec: 'avc', width: W, height: H }, audio: { codec: 'aac', sampleRate: SR, numberOfChannels: KENH }, fastStart: 'in-memory', firstTimestampBehavior: 'offset' });
    let loiMa = null;
    const venc = new VideoEncoder({ output: (c, m) => muxer.addVideoChunk(c, m), error: (e) => { loiMa = e; } });
    const aenc = new AudioEncoder({ output: (c, m) => muxer.addAudioChunk(c, m), error: (e) => { loiMa = e; } });
    venc.configure(vcfg); aenc.configure(acfg);
    const choBotHang = () => new Promise((r) => { if (venc.encodeQueueSize <= 4) return r(); let xong = false; const het = () => { if (!xong && venc.encodeQueueSize <= 4) { xong = true; venc.removeEventListener('dequeue', het); r(); } }; venc.addEventListener('dequeue', het); setTimeout(() => { if (!xong) { xong = true; venc.removeEventListener('dequeue', het); r(); } }, 3000); });
    // 4) mã hoá âm thanh (từng gói 1024 mẫu)
    const L = am.getChannelData(0), R = am.numberOfChannels > 1 ? am.getChannelData(1) : am.getChannelData(0);
    for (let i = 0; i < am.length; i += 1024) {
      const n = Math.min(1024, am.length - i); const d = new Float32Array(n * 2); d.set(L.subarray(i, i + n), 0); d.set(R.subarray(i, i + n), n);
      const ad = new AudioData({ format: 'f32-planar', sampleRate: SR, numberOfFrames: n, numberOfChannels: 2, timestamp: Math.round(i / SR * 1e6), data: d });
      aenc.encode(ad); ad.close();
    }
    // 5) mã hoá hình (30 khung/giây)
    const tong = Math.round(giay * FPS);
    for (let i = 0; i < tong; i++) {
      if (loiMa) throw loiMa;
      ve(i / (tong - 1));
      const fr = new VideoFrame(cv, { timestamp: Math.round(i * 1e6 / FPS), duration: Math.round(1e6 / FPS) });
      venc.encode(fr, { keyFrame: i % (FPS * 2) === 0 }); fr.close();
      if (venc.encodeQueueSize > 8) await choBotHang(); // chờ bằng sự kiện của bộ mã hoá (tab ẩn vẫn chạy nhanh, không bị trình duyệt làm chậm)
      if (i % FPS === 0) bao(`đang tạo video ${Math.round(i / FPS)}/${giay} giây`);
    }
    await venc.flush(); await aenc.flush(); if (loiMa) throw loiMa;
    venc.close(); aenc.close(); if (bm.close) bm.close();
    muxer.finalize();
    const blob = new Blob([muxer.target.buffer], { type: 'video/mp4' });
    if (blob.size < 50000) throw new Error('video tạo ra quá nhỏ (' + blob.size + ' byte)');
    const fOut = new File([blob], 'manifest-' + Date.now() + '.mp4', { type: 'video/mp4' }); fOut.hieuUng = HIEU_UNG_MF.find(([m]) => m === hu)[1];
    return fOut;
  }

  // khung xem trước video vừa tạo: xem lại, tải về, hoặc gắn vào hộp đăng bài (vẫn dừng trước nút Đăng)
  function hienXemTruoc(file, chu) {
    document.getElementById('smhfb-mf')?.remove();
    const url = URL.createObjectURL(file);
    const w = document.createElement('div'); w.id = 'smhfb-mf';
    w.innerHTML = `<div class="hop"><b>🎵 Video manifest thử (${(file.size / 1048576).toFixed(1)} MB${file.hieuUng ? ' · hiệu ứng: ' + file.hieuUng : ''})</b><video controls playsinline src="${url}"></video>
      <div class="nut-h"><a class="nut" href="${url}" download="${file.name}">⬇ Tải về máy</a><button class="nut chinh" data-k="gan">Gắn vào hộp đăng bài</button><button class="nut" data-k="dong">Đóng</button></div>
      <small>Gắn vào hộp đăng bài: script điền chữ + gắn video rồi DỪNG, không bấm Đăng.</small></div>`;
    const st = document.createElement('style'); st.textContent = '#smhfb-mf{position:fixed;inset:0;z-index:2147483600;background:rgba(0,0,0,.55);display:flex;align-items:center;justify-content:center}#smhfb-mf .hop{background:#fff;border-radius:16px;padding:16px 18px;display:flex;flex-direction:column;gap:10px;max-height:94vh;font:15px/1.4 system-ui,sans-serif;color:#222}#smhfb-mf video{height:min(70vh,640px);aspect-ratio:9/16;background:#000;border-radius:10px;align-self:center}#smhfb-mf .nut-h{display:flex;gap:8px;justify-content:center}#smhfb-mf .nut{font:700 15px system-ui,sans-serif;border-radius:10px;padding:10px 16px;border:2px solid #d9d2c4;background:#f6f3ec;color:#333;cursor:pointer;text-decoration:none}#smhfb-mf .nut.chinh{background:#2e7d4f;border-color:#2e7d4f;color:#fff}#smhfb-mf small{color:#666;text-align:center}';
    w.appendChild(st); document.body.appendChild(w);
    w.addEventListener('click', async (e) => {
      const k = e.target.getAttribute && e.target.getAttribute('data-k');
      if (k === 'dong' || e.target === w) { w.remove(); return; }
      if (k === 'gan') { w.remove(); await theoDoi('soanmf', () => ganVideoVaoHop(file, chu, 'Soạn thử manifest'), 'Đang gắn video manifest vào hộp đăng bài'); }
    });
  }
  async function ganVideoVaoHop(file, chu, ten) {
    const B = (m) => ghi(ten + ': ' + m);
    try {
      window.scrollTo(0, 0); await sleep(800);
      let dlg = hopSoanBai();
      if (!dlg) { const nut = timNutSoanBai(); if (!nut) throw new LoiMem('không thấy ô "Bạn đang nghĩ gì?"'); nut.click(); dlg = await cho(hopSoanBai, 12000); }
      if (!dlg) throw new LoiMem('không mở được hộp soạn bài');
      await xoaAnhCu();
      const ed = () => { const d = hopSoanBai(); return d ? Array.from(d.querySelectorAll('div[contenteditable="true"][data-lexical-editor]')).pop() : null; };
      if (chu) await datChu(ed(), chu);
      const inps = Array.from(hopSoanBai().querySelectorAll('input[type="file"]'));
      const inp = inps.find((i) => /video/.test(i.accept || '')) || inps[0]; if (!inp) throw new LoiMem('không thấy ô chọn ảnh/video');
      const dt = new DataTransfer(); dt.items.add(file); inp.files = dt.files; inp.dispatchEvent(new Event('input', { bubbles: true })); inp.dispatchEvent(new Event('change', { bubbles: true }));
      const ok = await cho(() => Array.from(document.querySelectorAll('div[role="dialog"] video')).some((v) => v.getBoundingClientRect().width > 60), 90000, 1000);
      B('các hộp đang mở: ' + tomTatHop());
      if (!ok) throw new LoiMem('Facebook chưa nhận video');
      B('XONG: đã gắn video manifest vào hộp đăng bài. Script DỪNG, KHÔNG bấm Đăng — bấm "Tiếp" để xem màn thước phim, rồi tự quyết định đăng hay bỏ.');
    } catch (e) { B('Lỗi: ' + e.message); chupLoi(ten); alert(ten + ' chưa được: ' + e.message); }
  }
  async function soanThuManifest(oAnh, oNhac, chu, hieuUng) {
    const B = (m) => ghi('Soạn thử manifest: ' + m);
    try {
      B(`đọc ô ảnh ${oAnh} và ô nhạc ${oNhac}…`);
      const tA = await docOTep(oAnh); const tN = await docOTep(oNhac);
      if (tA.type !== 'embed-image' && !/^image\//.test(tA.mimeType || '') && !/\.(jpe?g|png|webp|heic)$/i.test(tA.text || '')) throw new LoiMem(`ô ${oAnh} không phải ảnh (${tA.text})`);
      if (!/^audio\//.test(tN.mimeType || '') && !/\.(mp3|m4a|aac|wav|ogg)$/i.test(tN.text || '')) throw new LoiMem(`ô ${oNhac} không phải file nhạc (${tN.text})`);
      B(`thấy ảnh "${tA.text}" và nhạc "${tN.text}" → đang tải về`);
      const [anh, nhac] = [await taiTepLark(tA), await taiTepLark(tN)];
      B(`đã tải ảnh (${(anh.size / 1024).toFixed(0)} KB) và nhạc (${(nhac.size / 1048576).toFixed(1)} MB) → bắt đầu tạo video 15 giây`);
      const baoTD = (m) => { if (hdChay) { hdChay.chi = m; hdChay.cap = Date.now(); if (hdChay.hien) luu('hoat_dong', hdChay); veBang(); } };
      let file;
      try { file = await ghepManifestWC(anh, nhac, 15, baoTD, hieuUng); } catch (e1) { B('tạo video bằng bộ mã hoá chưa được (' + e1.message + ') → thử cách ghi trực tiếp'); file = await ghepManifest(anh, nhac, 15, (m) => { if (hdChay) { hdChay.chi = m; hdChay.cap = Date.now(); if (hdChay.hien) luu('hoat_dong', hdChay); veBang(); } }); }
      B(`đã tạo video ${(file.size / 1048576).toFixed(1)} MB (${file.type})${file.hieuUng ? ' · hiệu ứng: ' + file.hieuUng : ''} → mở khung xem trước`);
      hienXemTruoc(file, chu);
    } catch (e) { B('Lỗi: ' + e.message); chupLoi('soạn thử manifest'); alert('Soạn thử manifest chưa được: ' + e.message); }
  }
  // chụp nhanh các hộp thoại đang mở (để biết Facebook chuyển sang màn hình nào sau khi gắn video)
  const tomTatHop = () => Array.from(document.querySelectorAll('div[role="dialog"]')).filter((d) => d.getBoundingClientRect().height > 40 && !d.closest('[aria-hidden="true"]')).map((d) => chuan(d.innerText).slice(0, 90)).join(' ¦ ') || 'không có hộp nào';
  let soanVideoDangChay = false;
  async function soanThuVideo(hang) {
    if (soanVideoDangChay) { ghi('Soạn thử video: đang chạy rồi, chờ xong lượt này'); return; }
    soanVideoDangChay = true;
    const B = (m) => ghi('Soạn thử video (hàng ' + hang + '): ' + m);
    try {
      if (!dungTrang()) throw new LoiMem('hãy mở đúng trang ' + CAI_DAT.TEN_NGAN + ' rồi bấm lại');
      B('đọc ô trong sheet…');
      const h = await docHangVideo(hang);
      if (!h.tep) throw new LoiMem('ô N' + hang + ' chưa có file video (mp4)');
      if (!h.chu) throw new LoiMem('ô E' + hang + ' (tiêu đề Facebook) đang trống');
      B(`thấy video "${h.tep.text}" (${((h.tep.size || 0) / 1048576).toFixed(1)} MB) · chữ mô tả: "${h.chu.slice(0, 60)}"`);
      const file = await taiVideoLark(h.tep);
      // mở hộp soạn bài (giống Bài 2/3)
      window.scrollTo(0, 0); await sleep(800);
      let dlg = hopSoanBai();
      if (!dlg) {
        const nut = timNutSoanBai(); if (!nut) throw new LoiMem('không thấy ô "Bạn đang nghĩ gì?" trên trang');
        nut.click(); dlg = await cho(hopSoanBai, 10000);
        if (!dlg) { const n2 = timNutSoanBai() || nut; try { ganBam(n2); } catch (e) { n2.click(); } dlg = await cho(hopSoanBai, 12000); }
      }
      if (!dlg) throw new LoiMem('không mở được hộp soạn bài');
      B('đã mở hộp soạn bài');
      await xoaAnhCu();
      const ed = () => { const d = hopSoanBai(); return d ? Array.from(d.querySelectorAll('div[contenteditable="true"][data-lexical-editor]')).pop() : null; };
      if (!(await datChu(ed(), h.chu))) { await sleep(800); if (!(await datChu(ed(), h.chu))) throw new LoiMem('điền chữ mô tả chưa khớp'); }
      B('đã điền chữ mô tả (' + h.chu.length + ' ký tự)');
      // gắn video vào ô chọn file của hộp soạn
      const d0 = hopSoanBai(); if (!d0) throw new LoiMem('hộp soạn bài đã đóng');
      const inps = Array.from(d0.querySelectorAll('input[type="file"]'));
      const inp = inps.find((i) => /video/.test(i.accept || '')) || inps.find((i) => !i.accept || /\*/.test(i.accept)) || inps[0];
      if (!inp) throw new LoiMem('không thấy ô chọn ảnh/video trong hộp soạn bài');
      B('ô chọn file nhận: ' + (inp.accept || '(mọi loại)').slice(0, 80));
      const gan = () => { const dt = new DataTransfer(); dt.items.add(file); inp.files = dt.files; inp.dispatchEvent(new Event('input', { bubbles: true })); inp.dispatchEvent(new Event('change', { bubbles: true })); };
      gan();
      const coVideo = () => Array.from(document.querySelectorAll('div[role="dialog"] video')).some((v) => v.getBoundingClientRect().width > 60) || /thước phim|Đang tải lên|đang xử lý|Đã tải lên/i.test(tomTatHop());
      let ok = await cho(coVideo, 90000, 1000);
      if (!ok && hopSoanBai()) { B('Facebook chưa hiện video sau 90 giây → gắn lại lần 2'); try { gan(); } catch (e) { /* */ } ok = await cho(coVideo, 90000, 1000); }
      B('các hộp đang mở sau khi gắn video: ' + tomTatHop());
      if (!ok) throw new LoiMem('Facebook chưa nhận video sau 2 lần gắn');
      // chữ mô tả có còn sau khi Facebook chuyển màn hình không
      await sleep(3000);
      const eds = Array.from(document.querySelectorAll('div[role="dialog"] div[contenteditable="true"]')).filter((e) => e.getBoundingClientRect().width > 50 && !e.closest('[aria-hidden="true"]'));
      const conChu = eds.some((e) => chuan(e.innerText).includes(chuan(h.chu).slice(0, 30)));
      if (!conChu && eds.length) { B('chữ mô tả bị mất khi Facebook chuyển màn hình → điền lại'); await datChu(eds[eds.length - 1], h.chu); }
      B('XONG phần soạn thử: đã gắn video + chữ mô tả. Script DỪNG ở đây, KHÔNG bấm Đăng. Hãy kiểm tra video trong hộp; nếu hiện nút "Gắn vị trí & thẻ" thì bấm để làm tiếp, rồi tự quyết định có bấm Đăng hay không.');
      luu('soan_video_kq', { luc: Date.now(), hang, ok: true, hop: tomTatHop() });
      thongBaoMay('Soạn thử video xong', 'Đã gắn video hàng ' + hang + ' vào hộp soạn bài — script dừng trước nút Đăng');
    } catch (e) {
      B('Lỗi: ' + e.message); chupLoi('soạn thử video');
      luu('soan_video_kq', { luc: Date.now(), hang, ok: false, loi: e.message });
      alert('Soạn thử video chưa được: ' + e.message + '\n\n(Xem chi tiết trong tab Nhật ký hoặc bấm 📋 Báo lỗi)');
    } finally { soanVideoDangChay = false; veBang(); }
  }

  async function dangLenFacebook(bai, { soanThu = false } = {}) {
    kiemDung();
    if (!soanThu) window.__smhMoHop = Date.now(); // (4.5) hộp soạn từ đây trở đi là do script mở
    window.scrollTo(0, 0); await sleep(800);
    let dlg = hopSoanBai();
    if (!dlg) {
      const nut = timNutSoanBai();
      if (!nut) throw new LoiMem('Không tìm thấy ô "Bạn đang nghĩ gì?" trên trang');
      nut.click();
      dlg = await cho(hopSoanBai, 10000);
      if (!dlg) { ghi('B1. Bấm mở hộp soạn lần 1 chưa ăn → bấm lại'); const n2 = timNutSoanBai() || nut; try { ganBam(n2); } catch (e) { n2.click(); } dlg = await cho(hopSoanBai, 12000); }
    }
    if (!dlg) throw new LoiMem('Không mở được hộp soạn bài');
    ghi('B1. Đã mở hộp soạn bài: ' + chuan(dlg.innerText.split('\n').slice(0, 3).join(' | ')));
    if (!chuan(dlg.innerText.split('\n').slice(0, 3).join(' ')).includes(chuan(CAI_DAT.TEN_TRANG))) throw new LoiMem('Hộp soạn bài không đứng tên ' + CAI_DAT.TEN_TRANG);
    const ed = () => Array.from(hopSoanBai().querySelectorAll('div[contenteditable="true"][data-lexical-editor]')).pop();

    kiemDung();
    await xoaAnhCu(); // bản nháp cũ còn ảnh thì gỡ
    // nội dung (thay toàn bộ, kể cả bản nháp cũ)
    if (!(await datChu(ed(), bai.bai))) {
      ghi('B2. Điền nội dung lần 1 chưa khớp → điền lại');
      await sleep(800);
      if (!(await datChu(ed(), bai.bai))) throw new LoiMem('Điền nội dung vào ô đăng bài không khớp (đang có: "' + chuan(ed().innerText).slice(0, 60) + '")');
    }
    ghi('B2. Đã điền nội dung (' + bai.bai.length + ' ký tự)');

    kiemDung();
    if (bai.files && bai.files.length) {
      // Bài 2 / Bài 3: gắn ảnh, không dùng nền đỏ
      await ganAnhVaoHop(bai.files);
      ghi('B3. Đã gắn ' + bai.files.length + ' ảnh');
    } else {
    // nền đỏ
    dlg = hopSoanBai();
    const moNen = dlg.querySelector('[aria-label="Hiển thị các tùy chọn phông nền"]');
    if (moNen) { moNen.click(); await sleep(1000); }
    const nen = await cho(() => hopSoanBai().querySelector(`[aria-label^="${CAI_DAT.NEN}"]`), 8000);
    if (!nen) throw new LoiMem('Không thấy nền "' + CAI_DAT.NEN + '" (bài có thể dài quá ' + CAI_DAT.GIOI_HAN_KY_TU_NEN + ' ký tự)');
    nen.click(); await sleep(900);
    ghi('B3. Đã chọn nền ' + CAI_DAT.NEN);
    }

    kiemDung();
    // vị trí
    const coViTri = () => chuan(hopSoanBai().innerText.split('\n').slice(0, 3).join(' ')).includes('đang ở ' + CAI_DAT.VI_TRI);
    if (!coViTri()) {
      const nutViTri = hopSoanBai().querySelector('[aria-label="Vị trí"], [aria-label="Check in"]');
      if (!nutViTri) throw new LoiMem('Không thấy nút Vị trí');
      nutViTri.click();
      const o = await cho(() => Array.from(document.querySelectorAll('div[role="dialog"] input')).find((i) =>
        (i.getAttribute('aria-label') === 'Bạn đang ở đâu?' || i.placeholder === 'Bạn đang ở đâu?') && i.getBoundingClientRect().width > 0), 20000);
      if (!o) throw new LoiMem('Không mở được ô tìm vị trí');
      o.focus(); document.execCommand('insertText', false, CAI_DAT.VI_TRI);
      const lc = await cho(() => Array.from(document.querySelectorAll('div[role="dialog"] [role="option"], div[role="dialog"] li'))
        .find((x) => chuan(x.innerText.split('\n')[0]) === CAI_DAT.VI_TRI && x.innerText.includes(CAI_DAT.VI_TRI_DIA_CHI)), 20000);
      if (!lc) throw new LoiMem('Không tìm thấy vị trí ' + CAI_DAT.VI_TRI);
      const oChon = lc.querySelector('[role="button"]') || lc.querySelector('div[tabindex]') || lc;
      oChon.click();
      if (!(await cho(() => hopSoanBai() && coViTri(), 10000))) {
        ghi('B4. Chọn vị trí lần 1 chưa ăn → bấm lại');
        if (oChon.isConnected) { try { ganBam(oChon); } catch (e) { oChon.click(); } }
        if (!(await cho(() => hopSoanBai() && coViTri(), 10000))) throw new LoiMem('Chọn vị trí không thành công');
      }
    }
    ghi('B4. Vị trí: đang ở ' + CAI_DAT.VI_TRI);
    if (chuan(ed().innerText) !== chuan(bai.bai)) throw new LoiMem('Nội dung bị thay đổi trong lúc soạn');

    kiemDung();
    // Tiếp
    const tiep = hopSoanBai().querySelector('[aria-label="Tiếp"]');
    if (!tiep || tiep.getAttribute('aria-disabled') === 'true') throw new LoiMem('Nút "Tiếp" đang bị khoá');
    tiep.click();
    let caiDat = await cho(() => hopThoai((d) => laCaiDat(d)), 12000);
    if (!caiDat && hopSoanBai()) { ghi('B5. Bấm Tiếp lần 1 chưa ăn → bấm lại'); const t2 = hopSoanBai().querySelector('[aria-label="Tiếp"]') || tiep; try { ganBam(t2); } catch (e) { t2.click(); } caiDat = await cho(() => hopThoai((d) => laCaiDat(d)), 12000); }
    if (!caiDat) throw new LoiMem('Không mở được bước Cài đặt bài viết');
    ghi('B5. Đã bấm Tiếp → Cài đặt bài viết');

    kiemDung();
    // chia sẻ lên nhóm
    const chuNhom = await cho(() => { const h = hopThoai((d) => laCaiDat(d));
      return h && Array.from(h.querySelectorAll('span')).find((s) => chuan(s.textContent) === 'Chia sẻ lên nhóm'); }, 15000);
    if (!chuNhom) throw new LoiMem('Không thấy mục "Chia sẻ lên nhóm"');
    const hangNhom = chuNhom.closest('[role="button"]') || chuNhom.closest('[tabindex]');
    const timHopNhom = () => hopThoai((d) => laNhom(d)) || (() => {
      const c = Array.from(document.querySelectorAll('div[role="dialog"] input[type="checkbox"]')).find((x) => x.getAttribute('role') !== 'switch' && x.parentElement && x.parentElement.getClientRects().length);
      return c ? c.closest('div[role="dialog"]') : null; })();
    ganBam(hangNhom);
    let hopNhom = await cho(timHopNhom, 8000);
    if (!hopNhom) { ghi('B6. Bấm lần 1 chưa mở được danh sách nhóm → bấm lại'); hangNhom.click(); hopNhom = await cho(timHopNhom, 12000); }
    if (!hopNhom) { // (4.5) lần 3: Facebook vẽ lại màn Cài đặt → tìm lại mục "Chia sẻ lên nhóm" rồi bấm
      const h3 = hopThoai((d) => laCaiDat(d));
      const c3 = h3 && Array.from(h3.querySelectorAll('span')).find((s) => chuan(s.textContent) === 'Chia sẻ lên nhóm');
      const n3 = c3 && (c3.closest('[role="button"]') || c3.closest('[tabindex]') || c3);
      if (n3) { ghi('B6. Bấm lần 3 (tìm lại mục Chia sẻ lên nhóm)'); try { ganBam(n3); } catch (e) { n3.click(); } hopNhom = await cho(timHopNhom, 12000); }
    }
    if (!hopNhom) throw new LoiMem('Không mở được danh sách nhóm');
    await cho(() => hopNhom.querySelector('input[type="checkbox"]') || hopNhom.innerText.includes('Không tìm thấy nhóm'), 15000);
    await sleep(800);
    const oNhom = () => Array.from(hopNhom.querySelectorAll('input[type="checkbox"]'))
      .filter((c) => !['Tắt', 'Bật'].includes(c.getAttribute('aria-label') || '') && c.getAttribute('role') !== 'switch' && !c.disabled);
    if (!oNhom().length) throw new LoiMem('Danh sách nhóm trống (trang không còn trong nhóm nào?)');
    const tenNhom = (c) => chuan(((c.closest('[role="listitem"]') || c.parentElement.parentElement.parentElement).innerText || '').split('\n')[0]);
    ghi('B6. Danh sách có ' + oNhom().length + ' nhóm, đang tick sẵn ' + oNhom().filter((x) => x.checked).length);
    for (const c of oNhom().filter((x) => x.checked).reverse()) {
      if (oNhom().filter((x) => x.checked).length <= CAI_DAT.SO_NHOM_TOI_DA) break;
      kiemDung(); c.click(); await sleep(400);
    }
    for (const c of oNhom()) {
      if (oNhom().filter((x) => x.checked).length >= CAI_DAT.SO_NHOM_TOI_DA) break;
      if (!c.checked) { kiemDung(); c.click(); await sleep(400); }
    }
    // (4.5) tick chưa đủ (Facebook vẽ lại danh sách / click bị bỏ qua) → tick lại bằng chuỗi sự kiện chuột
    const canNhom = Math.min(CAI_DAT.SO_NHOM_TOI_DA, oNhom().length);
    if (oNhom().filter((x) => x.checked).length < canNhom) {
      ghi('B7. Tick nhóm chưa đủ → tick lại');
      for (const c of oNhom()) {
        if (oNhom().filter((x) => x.checked).length >= canNhom) break;
        if (!c.checked) { kiemDung(); const o = c.closest('[role="listitem"]') || c; try { ganBam(o); } catch (e) { c.click(); } await sleep(500); if (!c.checked) { c.click(); await sleep(400); } }
      }
    }
    const soNhom = oNhom().filter((x) => x.checked).length;
    ghi('B7. Đã chọn ' + soNhom + ' nhóm: ' + oNhom().filter((x) => x.checked).map(tenNhom).join(' ; '));
    if (soNhom > CAI_DAT.SO_NHOM_TOI_DA) throw new LoiMem('Không bỏ bớt được nhóm (đang chọn ' + soNhom + ')');
    const xong = nutTheoChu(hopNhom, 'Xong');
    if (!xong) throw new LoiMem('Không thấy nút "Xong" ở danh sách nhóm');
    xong.click();
    let caiDat2 = await cho(() => hopThoai((d) => laCaiDat(d) && (!soNhom || d.innerText.includes(`Đã chọn ${soNhom} nhóm`))), 8000)
      || hopThoai((d) => laCaiDat(d));
    if (!caiDat2 && xong.isConnected) { ghi('B8. Bấm Xong lần 1 chưa ăn → bấm lại'); try { ganBam(xong); } catch (e) { xong.click(); } caiDat2 = await cho(() => hopThoai((d) => laCaiDat(d)), 8000); }
    if (!caiDat2) throw new LoiMem('Không quay lại được bước Cài đặt bài viết');
    if (soNhom && !caiDat2.innerText.includes(`Đã chọn ${soNhom} nhóm`)) throw new LoiMem('Chọn nhóm không thành công (màn Cài đặt ghi: ' + chuan(caiDat2.innerText).slice(0, 120) + ')');
    ghi('B8. Màn Cài đặt xác nhận ' + soNhom + ' nhóm');

    kiemDung();
    // Đăng
    const dang = await cho(() => Array.from(caiDat2.querySelectorAll('[role="button"]')).find((b) => (chuan(b.innerText) === 'Đăng' || b.getAttribute('aria-label') === 'Đăng') && b.getAttribute('aria-disabled') !== 'true'), 6000);
    if (!dang) throw new LoiMem('Không thấy nút "Đăng"');
    if (soanThu) {
      dang.style.outline = '3px solid #f7b928'; dang.style.outlineOffset = '2px';
      ghi('Soạn thử xong — đã dừng trước nút "Đăng". Cao tự bấm Đăng hoặc đóng hộp để huỷ');
      return -1;
    }
    kiemDung();
    if (!soanThu && coApi()) {
      // (4.5) dò trùng lần cuối: API lỗi thì KHÔNG bỏ cả bài — dò bằng trang (bài đã lên thường thấy ngay ở đầu trang)
      let trung = null;
      try { const tuLuc = new Date(new Date().setHours(0, 0, 0, 0)).getTime() - 6 * 3600e3; trung = baiGiongNhat((await baiTrenTrangApi(tuLuc)).filter((p) => p.luc >= tuLuc), bai.bai); }
      catch (e) { ghi('Dò trùng lần cuối qua API lỗi (' + e.message + ') → dò trên trang'); const x = timBai(bai.bai); if (x) trung = { link: linkBai(x.khung), luc: Date.now(), id: '' }; }
      kiemDung();
      if (trung) throw new LoiTrung('Phát hiện bài đã có ngay trước khi Đăng — không bấm Đăng', trung);
    }
    kiemDung();
    const lucBam = Date.now();
    luu('dang_do', Object.assign({ khoa: bai.khoa, ngay: bai.ngay, hang: bai.hang, bai: bai.bai, cmt: bai.cmt, luc: lucBam, buoc: 'kiem_bai', soNhom }, bai.ddThem || {}));
    try { dang.click(); } catch (e) { throw new LoiCung('Không rõ kết quả thao tác Đăng — script sẽ tải lại trang để kiểm tra'); }
    ghi(`Đã bấm Đăng (hàng ${bai.hang}, ${soNhom} nhóm)`);
    // (4.8) Facebook hay chen hộp gợi ý "Chat trực tiếp với khách hàng" (Lúc khác / Thêm nút) sau khi bấm Đăng bài có ảnh — hộp này chặn bài, phải bấm "Lúc khác"
    let lucHopPhu = 0, soLanHopPhu = 0;
    // các nút "để sau" an toàn (không đồng ý/không huỷ bài) — chỉ bấm khi trùng đúng chữ
    const CHU_BO_QUA = ['Lúc khác', 'Để sau', 'Không phải bây giờ', 'Không phải lúc này', 'Bỏ qua', 'Không, cảm ơn', 'Không cảm ơn'];
    const laBoSoanB9 = (d) => laCaiDat(d) || d.innerText.includes('Tạo bài viết');
    const nhanNutB9 = (x) => chuan(x.innerText || x.getAttribute('aria-label') || '');
    const nutCuaHop = (goc) => Array.from(goc.querySelectorAll('[role="button"],button,[role="link"],a[tabindex]')).filter(dangHien);
    // (5.1) nhận diện RỘNG: mọi hộp/khung nổi ngoài hộp soạn bài có nút "Lúc khác"-kiểu, hoặc bất kỳ nút "Lúc khác / Để sau / Không phải bây giờ" nằm đâu đó trên trang
    const nutHopPhu = () => {
      const lop = Array.from(document.querySelectorAll('div[role="dialog"],[role="alertdialog"],[aria-modal="true"]')).filter((d) => dangHien(d) && !laBoSoanB9(d));
      for (const d of lop) for (const chu of CHU_BO_QUA) { const n = nutCuaHop(d).find((x) => nhanNutB9(x) === chu); if (n) return { n, chu, hop: chuan(d.innerText).slice(0, 80) }; }
      for (const chu of CHU_BO_QUA.slice(0, 4)) {
        const n = Array.from(document.querySelectorAll('[role="button"],button')).find((x) => dangHien(x) && chuan(x.innerText) === chu);
        if (n) { const dl = n.closest('div[role="dialog"],[aria-modal="true"]') || n.parentElement || n; return { n, chu, hop: chuan(dl.innerText).slice(0, 80) }; }
      }
      // 3) chữ nằm trong phần tử không phải nút chuẩn (span/div/a…): tìm phần tử lá có đúng chữ rồi bấm phần tử bấm được gần nhất
      for (const chu of CHU_BO_QUA.slice(0, 4)) {
        const e = Array.from(document.querySelectorAll('span,div,a,li')).find((x) => x.children.length === 0 && chuan(x.textContent) === chu && dangHien(x));
        if (e) { const n = e.closest('[role="button"],button,a,[tabindex]') || e; const dl = n.closest('div[role="dialog"],[aria-modal="true"]') || n.parentElement || n; return { n, chu, hop: chuan(dl.innerText).slice(0, 80) }; }
      }
      return null;
    };
    const dongHopPhu = () => {
      const x = nutHopPhu(); if (!x) return false;
      if (Date.now() - lucHopPhu < 2500) return true;
      if (soLanHopPhu >= 8) return true;
      lucHopPhu = Date.now(); soLanHopPhu++;
      ghi(`B9. Facebook hiện hộp chặn bài («${x.hop}») → bấm "${x.chu}" để bài được đăng`);
      try { ganBam(x.n); } catch (e) { x.n.click(); }
      return true;
    };
    // ghi lại những gì đang hiện trên màn hình (để lần sau biết đúng hộp nào chặn nút Đăng)
    const chupHop = (nhan) => {
      try {
        const ds = Array.from(document.querySelectorAll('div[role="dialog"],[role="alertdialog"],[aria-modal="true"],[role="alert"]')).filter(dangHien);
        const mo = ds.slice(0, 5).map((d) => '«' + chuan(d.innerText).slice(0, 110) + '» nút: ' + (nutCuaHop(d).map(nhanNutB9).filter((t) => t && t.length < 28).slice(0, 8).join(' | ') || '-'));
        const quay = document.querySelectorAll('[role="progressbar"]').length;
        ghi(`B9. (${nhan}) đang hiện ${ds.length} hộp/khung${quay ? ', ' + quay + ' vòng xoay' : ''}: ` + (mo.join(' ;; ') || 'không có'));
      } catch (e) { /* */ }
    };
    const daDong0 = () => !hopThoai((d) => laCaiDat(d) || d.innerText.includes('Tạo bài viết'));
    let daChup15 = false;
    const daDong = () => { dongHopPhu(); const x = daDong0(); if (!x && !daChup15 && Date.now() - lucBam > 15000) { daChup15 = true; chupHop('sau 15 giây chưa đóng'); } return x; };
    let dong = await cho(daDong, 25000, 500);
    if (!dong) {
      // (4.5) phương án 2: hỏi Facebook (API) xem bài đã lên chưa; chưa lên mà nút Đăng vẫn bấm được (không có vòng xoay) → bấm lại bằng chuỗi sự kiện chuột
      let daLen = null, apiDoc = false;
      const hoiApi = async () => { apiDoc = false; if (!coApi()) return; try { daLen = baiGiongNhat(await baiTrenTrangApi(lucBam - 120000), bai.bai); apiDoc = true; } catch (e) { ghi('B9. Hỏi Facebook (API) lỗi: ' + e.message); } };
      await hoiApi();
      const nutLai = () => { if (nutHopPhu()) return null; const h = hopThoai((d) => laCaiDat(d)); if (!h || h.querySelector('[role="progressbar"]')) return null; return Array.from(h.querySelectorAll('[role="button"]')).find((b) => (chuan(b.innerText) === 'Đăng' || b.getAttribute('aria-label') === 'Đăng') && b.getAttribute('aria-disabled') !== 'true') || null; };
      if (!daLen && apiDoc && nutLai()) { await sleep(5000); if (!daDong()) await hoiApi(); } // hỏi lại lần 2 cho chắc (Facebook có thể chậm vài giây)
      if (daLen) { ghi('B9. Hộp đăng chưa đóng nhưng Facebook (API) đã có bài → coi như đã đăng'); dong = true; await dongHopSoan(); }
      else {
        const n2 = nutLai();
        if (n2 && !daDong() && apiDoc) { const dd2 = lay('dang_do', null); if (dd2) { dd2.lanBam = 2; luu('dang_do', dd2); } ghi('B9. Bấm Đăng lần 1 chưa ăn (nút vẫn còn, Facebook API xác nhận bài chưa lên) → bấm lại'); try { ganBam(n2); } catch (e) { n2.click(); } }
        else if (n2 && !daDong()) ghi('B9. Hộp đăng chưa đóng, chưa hỏi được Facebook (API) → KHÔNG bấm lại (tránh đăng trùng), chờ thêm rồi tải lại trang kiểm tra');
        dong = await cho(daDong, 35000, 1000);
        if (!dong && !daLen) {
          chupHop('sau khi bấm lại');
          await hoiApi();
          if (daLen) { ghi('B9. Hộp chưa đóng nhưng Facebook (API) đã có bài → coi như đã đăng'); dong = true; await dongHopSoan(); }
          else {
            const n3 = nutLai();
            if (n3 && apiDoc && !daDong()) { ghi('B9. Vẫn chưa đăng → thử bấm bằng bàn phím (Enter) lên nút Đăng'); try { n3.focus(); for (const t of ['keydown', 'keypress', 'keyup']) n3.dispatchEvent(new KeyboardEvent(t, { key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true, cancelable: true })); } catch (e) { /* */ } }
          }
        }
        if (!dong) dong = await cho(daDong, 55000, 1000);
      }
    }
    if (!dong) chupHop('hết giờ chờ');
    ghi(dong ? 'B9. Hộp đăng bài đã đóng' : 'B9. Hộp đăng bài KHÔNG đóng sau ~2 phút');
    if (!dong) throw new LoiCung(`Đã bấm Đăng hàng ${bai.hang} nhưng hộp đăng bài không đóng — script tải lại trang để kiểm tra bài đã lên chưa`);
    return soNhom;
  }

  // ---------------- thả cảm xúc (Thích / Yêu thích, ngẫu nhiên) ----------------
  // Nút của CHÍNH bài viết (không lấy nút của các comment bên trong)
  const nutCuaBai = (khung, nhan) => Array.from(khung.querySelectorAll('[role="button"][aria-label]')).find((b) => {
    const l = b.getAttribute('aria-label'); if (!(typeof nhan === 'string' ? l === nhan : nhan.test(l))) return false;
    const a = b.closest('[role="article"]'); return (!a || !khung.contains(a) || a === khung) && dangHien(b);
  });
  const nutCuaCmt = (art, nhan) => Array.from(art.querySelectorAll('[role="button"],button')).find((b) => {
    const l = chuan(b.getAttribute('aria-label') || b.innerText);
    const phuHop = typeof nhan === 'string' ? (l === nhan || (nhan === 'Thích' && /^Thích bình luận/.test(l)) || (nhan === 'Bày tỏ cảm xúc' && /^Bày tỏ cảm xúc/.test(l))) : nhan.test(l);
    return phuHop && b.closest('[role="article"]') === art && dangHien(b) && !b.querySelector('[role="button"],button');
  });

  // ---- (4.2) tìm lại đúng comment sau khi Facebook vẽ lại; thích 1 comment có thử lại ----
  const nhanArt = (a) => (a.getAttribute('aria-label') || '').replace(/ (vào|lúc) .*$/, '');
  // comment/phản hồi thật (bỏ khung bài, bài chia sẻ…): có nhãn "Bình luận/Phản hồi/Trả lời…" hoặc (không nhãn và không phải bài có nút ⋯)
  const laCmtArt = (a) => { const l = a.getAttribute('aria-label') || ''; if (!l && !chuan(a.innerText) && !a.querySelector('[role="button"],button')) return false; if (l) return /bình luận|phản hồi|trả lời/i.test(l); return !a.querySelector('[aria-label^="Hành động đối với bài viết này"]'); };
  function taoTimArt(art0, tapHop) {
    const khoaA = chuan(art0.innerText).slice(0, 25), nhan0 = nhanArt(art0);
    const tt = Math.max(0, tapHop().filter((a) => nhanArt(a) === nhan0).indexOf(art0));
    return () => {
      if (art0.isConnected) return art0;
      const ds = tapHop();
      const c = nhan0 ? ds.filter((a) => nhanArt(a) === nhan0) : [];
      if (c.length === 1) return c[0];
      if (c.length > 1) return c.find((a) => chuan(a.innerText).startsWith(khoaA)) || c[Math.min(tt, c.length - 1)];
      return ds.find((a) => chuan(a.innerText).startsWith(khoaA)) || art0;
    };
  }
  async function thichMotCmt(tim) {
    const nc = (n) => nutCuaCmt(tim(), n);
    try { tim().scrollIntoView({ block: 'center' }); } catch (e) { /* */ }
    await sleep(400);
    if (nc(DA_CO_CAM_XUC)) return { tt: 'co_san' };
    const co = await cho(() => nc('Thích') || nc('Bày tỏ cảm xúc'), 2500, 400);
    if (!co) {
      const a = tim();
      if (!chuan(a.innerText) && !a.querySelector('[role="button"],button')) return { tt: 'rong' }; // (5.6.1) khung trống (Facebook chưa vẽ nội dung) → bỏ qua, không phải lỗi
      const ds = Array.from(a.querySelectorAll('[role="button"],button')).map((b) => (dangHien(b) ? '' : '(ẩn) ') + chuan(b.getAttribute('aria-label') || b.innerText)).filter((x) => x.trim()).slice(0, 10).join(' | ');
      return { tt: 'khong_nut', chiTiet: `${chuan(a.getAttribute('aria-label') || chuan(a.innerText).slice(0, 30)).slice(0, 50)} → ${ds || 'không thấy nút nào'}` };
    }
    if (cheDoThu) return { tt: 'thu' };
    let loi = '';
    for (let lan = 0; lan < 2; lan++) {
      try { kiemDung(); const r0 = await thaCamXuc(nc, 'Comment', tim()); return { tt: r0 === 'co_san' ? 'co_san' : 'ok' }; }
      catch (e) { if (e instanceof LoiDung) throw e; loi = e.message; await sleep(1500); if (nc(DA_CO_CAM_XUC)) return { tt: 'ok' }; }
    }
    return { tt: 'loi', loi };
  }

  const DA_CO_CAM_XUC = /^(Gỡ |Thay đổi cảm xúc)/;
  async function thaCamXuc(timNut, ten, goc, chuaMs = 8000) {
    if (!CAI_DAT.THA_CAM_XUC) return;
    if (goc && goc.scrollIntoView) { try { goc.scrollIntoView({ block: 'center' }); } catch (e) { /* */ } await sleep(600); }
    // thanh nút Thích/Bình luận hiện chậm → chờ tới 8 giây
    const thay = await cho(() => timNut(DA_CO_CAM_XUC) || timNut('Thích') || timNut('Bày tỏ cảm xúc'), chuaMs, 400);
    if (!thay) {
      const ds = goc ? Array.from(goc.querySelectorAll('[role="button"],button')).filter(dangHien).map((b) => chuan(b.getAttribute('aria-label') || b.innerText)).filter(Boolean).slice(0, 12).join(' | ') : '';
      throw new Error('không tìm thấy nút Thích' + (ds ? ' (nút đang thấy: ' + ds + ')' : ''));
    }
    if (timNut(DA_CO_CAM_XUC)) { ghi(`${ten}: đã có cảm xúc sẵn, không bấm thêm`); return 'co_san'; }
    kiemDung();
    let chon = Math.random() < 0.5 ? 'Thích' : 'Yêu thích';
    if (chon === 'Yêu thích' && !timNut('Bày tỏ cảm xúc')) chon = 'Thích'; // không có nút mở bảng cảm xúc → Thích
    if (chon === 'Thích') {
      const nut = timNut('Thích'); if (!nut) throw new Error('không thấy nút "Thích"');
      nut.click();
    } else {
      const nut = timNut('Bày tỏ cảm xúc');
      nut.click();
      const yt = await cho(() => Array.from(document.querySelectorAll('[role="dialog"] [role="button"][aria-label="Yêu thích"]')).find(dangHien), 5000);
      if (!yt) { // (4.5) bảng cảm xúc không mở → đóng lại rồi bấm Thích
        document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', code: 'Escape', keyCode: 27, which: 27, bubbles: true })); await sleep(500);
        chon = 'Thích'; const nt = timNut('Thích'); if (!nt) throw new Error('không mở được bảng cảm xúc và không thấy nút "Thích"');
        kiemDung(); nt.click();
      } else { kiemDung(); yt.click(); }
    }
    let ok = await cho(() => timNut(DA_CO_CAM_XUC), 6000);
    if (!ok) { // phương án 2: Facebook chậm → chờ thêm; nút vẫn còn "Thích" (chưa nhận) thì bấm lại đúng 1 lần
      ok = await cho(() => timNut(DA_CO_CAM_XUC), 3000);
      if (!ok) { const lai = timNut('Thích'); if (lai) { kiemDung(); ghi(`${ten}: bấm lần 1 chưa được Facebook nhận → bấm lại`); try { ganBam(lai); } catch (e) { lai.click(); } ok = await cho(() => timNut(DA_CO_CAM_XUC), 6000); } }
    }
    if (!ok) throw new Error('đã bấm cảm xúc nhưng chưa xác nhận được');
    ghi(ok ? `${ten}: đã thả "${chon}"` : `${ten}: đã bấm "${chon}" nhưng chưa thấy Facebook ghi nhận`);
    return true;
  }
  async function thaCamXucBai(text) {
    if (!CAI_DAT.THA_CAM_XUC) return { tt: 'tat' };
    try {
      kiemDung(); const b = await cho(() => timBai(text), 10000);
      if (!b) throw new Error('không thấy bài trên trang');
      await thaCamXuc((n) => { const x = timBai(text); return nutCuaBai(x ? x.khung : b.khung, n); }, 'Cảm xúc cho bài', b.khung);
      return { tt: 'ok' };
    } catch (e) { ghi('Chưa thả được cảm xúc cho bài: ' + e.message); return { tt: 'chua', loi: e.message }; }
  }
  async function thaCamXucCmt(text, cmt) {
    if (!CAI_DAT.THA_CAM_XUC || CAI_DAT.THA_CAM_XUC_CMT === false) return { tt: 'tat' };
    try {
      kiemDung();
      const dong1 = chuan(String(cmt).split('\n')[0]).slice(0, 40);
      const k1 = khoaSo(dong1).slice(0, 25);
      // Facebook vẽ lại khung comment sau khi gửi (nhất là comment có link xem trước) → luôn tìm lại khung mới nhất
      const cacArt = () => {
        const b = timBai(text); const goc = b ? b.khung : document.body;
        return Array.from(goc.querySelectorAll('[role="article"]')).filter((a) => (!b || !a.contains(b.ed)) && (chuan(a.innerText).includes(dong1) || (k1.length >= 8 && khoaSo(a.innerText).includes(k1))));
      };
      const coNut = (a) => nutCuaCmt(a, DA_CO_CAM_XUC) || nutCuaCmt(a, 'Thích') || nutCuaCmt(a, 'Bày tỏ cảm xúc');
      const timArt = () => { const ds = cacArt(); const L = ds.filter(coNut).length ? ds.filter(coNut) : ds; return L.find((a) => !L.some((o) => o !== a && a.contains(o))) || null; };
      const art = await cho(timArt, 12000, 500);
      if (!art) throw new Error('không thấy comment vừa đăng');
      // (4.5) comment vừa gửi có thể đang "Đang đăng…" (chưa có nút Thích) → chờ tới 20 giây
      await cho(() => { const a = timArt(); return a && coNut(a); }, 20000, 500);
      const r = await thichMotCmt(() => timArt() || art);
      if (r.tt === 'ok' || r.tt === 'co_san') { if (r.tt === 'co_san') ghi('Cảm xúc cho comment: đã có sẵn'); return { tt: 'ok' }; }
      throw new Error(r.loi || r.chiTiet || 'không tìm thấy nút Thích');
    } catch (e) { if (e instanceof LoiDung) return { tt: 'chua', loi: e.message }; ghi('Chưa thả được cảm xúc cho comment: ' + e.message + ' — lượt quét sẽ thả bù'); return { tt: 'chua', loi: e.message }; }
  }

  // Tìm ô bình luận của bài có nội dung text
  // ô bình luận đứng tên người khác (không phải trang) → không dùng (tránh comment bằng tài khoản cá nhân)
  const oCuaNguoiKhac = (ed) => { const l = chuan(ed.getAttribute('aria-label') || ''); const m = l.match(/dưới tên (.+)$/); return !!(m && chuanTen(m[1]) !== chuanTen(CAI_DAT.TEN_TRANG)); };
  function timBai(text) {
    const khoa = chuan(text).slice(0, 60);
    const khoa2 = khoaSo(text).slice(0, 45); // (4.5) dự phòng: so chữ bỏ emoji / dấu câu / link rút gọn
    if (khoa2) for (const ed of document.querySelectorAll('div[contenteditable="true"][data-lexical-editor][aria-label^="Bình luận"]')) {
      if (oCuaNguoiKhac(ed)) { window.__smhSaiTuCach = Date.now(); continue; }
      let p = ed.parentElement;
      for (let i = 0; i < 30 && p; i++, p = p.parentElement) {
        const t = p.innerText;
        if (t && (chuan(t).includes(khoa) || (khoa2.length >= 12 && khoaSo(t).includes(khoa2)))) {
          if (p.querySelectorAll('div[contenteditable="true"][aria-label^="Bình luận"]').length === 1) return { ed, khung: p };
          break;
        }
      }
    }
    // (4.2) trang riêng của reel/video: ô bình luận nằm trong khung bên phải, hay không chứa chữ của bài (chữ bị cắt "… Xem thêm")
    // → trang chỉ có đúng 1 ô bình luận thì lấy ô đó; khung bình luận đang đóng thì bấm nút "Bình luận" để mở
    if (/\/(reel|reels|videos)\//.test(location.pathname) || /^\/watch/.test(location.pathname)) {
      const eds = Array.from(document.querySelectorAll('div[contenteditable="true"][data-lexical-editor][aria-label^="Bình luận"]')).filter((e) => dangHien(e) && !oCuaNguoiKhac(e));
      if (eds.length === 1) return { ed: eds[0], khung: document.body };
      if (!eds.length && Date.now() - (window.__smhMoCmt || 0) > 4000) {
        window.__smhMoCmt = Date.now();
        const b = Array.from(document.querySelectorAll('[aria-label="Bình luận"][role="button"]')).find(dangHien);
        if (b) { try { ganBam(b); } catch (e) { b.click(); } }
      }
    }
    return null;
  }

  // Lấy đường dẫn của bài (nếu Facebook để lộ); không lấy được thì trả về rỗng
  function linkBai(khung) {
    const a = Array.from(khung.querySelectorAll('a[href]')).map((x) => x.href)
      .find((h) => /\/posts\/|story_fbid=|\/permalink/.test(h) && !/comment_id=/.test(h));
    if (!a) return '';
    try { const u = new URL(a); const giu = new URLSearchParams();
      ['story_fbid', 'id'].forEach((k) => { if (u.searchParams.get(k)) giu.set(k, u.searchParams.get(k)); });
      return u.origin + u.pathname + (giu.toString() ? '?' + giu : ''); } catch (e) { return ''; }
  }

  // Facebook đôi khi hiện comment tạm rồi mới báo lỗi → phải chờ xem Facebook có nhận thật không
  function loiTuFacebook(khung) {
    const hop = hopThoai((d) => /Bài viết đã bị gỡ|không thể được bình luận/i.test(d.innerText));
    if (hop) {
      const ok = nutTheoChu(hop, 'OK') || hop.querySelector('[aria-label="Đóng"]');
      const noiDung = chuan(hop.innerText).slice(0, 120);
      if (ok) ok.click();
      return 'Facebook báo: ' + noiDung;
    }
    if (khung && /Không thể đăng bình luận/i.test(khung.innerText)) return 'Facebook báo: Không thể đăng bình luận';
    return null;
  }

  async function xoaO(ed) {
    try { ed.focus(); await sleep(150); const sel = window.getSelection(); const rg = document.createRange(); rg.selectNodeContents(ed); sel.removeAllRanges(); sel.addRange(rg); document.execCommand('delete'); await sleep(300); } catch (e) { /* */ }
  }
  async function dienCmt(ed, cmt) {
    ed.focus(); await sleep(300);
    if (chuan(ed.innerText)) await xoaO(ed); // (4.5) còn chữ nháp cũ → xoá trước
    const dt = new DataTransfer(); dt.setData('text/plain', cmt);
    ed.dispatchEvent(new ClipboardEvent('paste', { clipboardData: dt, bubbles: true, cancelable: true }));
    await sleep(1200);
    return chuan(ed.innerText) === chuan(cmt);
  }
  async function binhLuan(text, cmt, truocGui = () => {}) {
    kiemDung();
    let b = await cho(() => timBai(text), 15000);
    if (!b && window.__smhSaiTuCach && Date.now() - window.__smhSaiTuCach < 20000) { // ô bình luận đang đứng tên người khác → chuyển tư cách trước
      ghi('Ô bình luận đang đứng tên tài khoản khác → chuyển sang tư cách trang'); if (!(await damBaoTuCach())) { const e0 = new LoiChuaGui('đang chuyển tư cách trang — comment sau khi trang tải lại'); e0.doiTuCach = true; throw e0; }
      b = await cho(() => timBai(text), 8000);
    }
    if (!b) throw new LoiChuaGui('không tìm thấy ô bình luận của bài');
    ghi('C1. Đã thấy ô bình luận của bài');
    kiemDung();
    if (!(await dienCmt(b.ed, cmt))) {
      ghi('C2. Điền comment lần 1 chưa khớp → xoá và điền lại');
      const b2 = timBai(text) || b;
      if (!(await dienCmt(b2.ed, cmt))) { await xoaO(b2.ed); throw new LoiChuaGui('nội dung comment điền vào không khớp (đang có: "' + chuan(b2.ed.innerText).slice(0, 60) + '")'); }
      b = b2;
    }
    ghi('C2. Đã điền comment (' + cmt.split('\n').length + ' dòng)');
    const dong1 = chuan(cmt.split('\n')[0]).slice(0, 40);
    const soLanCo = () => { const x = timBai(text); return x ? chuan(x.khung.innerText).split(dong1).length - 1 : -1; };
    const soTruoc = soLanCo();
    const enter = (ed) => ed.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true, cancelable: true }));
    const oHienTai = () => { const x = timBai(text); return x ? x.ed : null; };
    const daTrong = () => { const e = oHienTai(); return (e && chuan(e.innerText) === '') || (!b.ed.isConnected && !e) || chuan(b.ed.innerText) === ''; };
    kiemDung(); truocGui(); enter(b.ed);
    let trong = await cho(daTrong, 6000);
    if (!trong) {
      // (4.5) Enter chưa ăn: ô vẫn còn nguyên chữ và chưa có comment mới → chưa gửi gì → bấm nút Gửi (chuỗi sự kiện chuột)
      const e2 = oHienTai() || b.ed;
      const conNguyen = chuan(e2.innerText) === chuan(cmt) && soLanCo() <= soTruoc;
      if (!conNguyen) throw new Error('bấm gửi comment không rõ kết quả');
      const form = e2.closest('form') || e2.parentElement;
      const nutGui = form && Array.from(form.querySelectorAll('[role="button"][aria-label], div[aria-label][tabindex]')).find((x) => /^(Bình luận|Gửi|Đăng)$/.test(chuan(x.getAttribute('aria-label'))) && dangHien(x));
      ghi('C3. Enter chưa gửi được → ' + (nutGui ? 'bấm nút Gửi' : 'nhấn Enter lại'));
      if (nutGui) { try { ganBam(nutGui); } catch (e) { nutGui.click(); } } else { e2.focus(); enter(e2); }
      trong = await cho(daTrong, 6000);
      if (!trong) {
        const e3 = oHienTai() || e2;
        if (chuan(e3.innerText) === chuan(cmt) && soLanCo() <= soTruoc) { await xoaO(e3); const e0 = new LoiChuaGui('bấm gửi comment không được (đã thử Enter và nút Gửi, comment chưa đi)'); e0.sauEnter = true; throw e0; }
        throw new Error('bấm gửi comment không rõ kết quả');
      }
    }
    ghi('C3. Đã gửi comment, chờ Facebook xác nhận');
    const han = Date.now() + 10000;
    while (Date.now() < han) {
      const x = timBai(text);
      const loi = loiTuFacebook(x && x.khung);
      if (loi) throw new LoiTuChoi(loi);
      await sleep(500);
    }
    let x = timBai(text);
    if (!x) { // ô bình luận có thể bị "treo" (biến mất) sau khi gửi → hỏi Facebook xem comment đã lên chưa
      await sleep(2500); x = timBai(text);
      if (!x && coApi()) {
        try {
          const p = baiGiongNhat(await baiTrenTrangApi(Date.now() - 864e5), text);
          if (p) { const cs = await cmtChiTietApi(p.id); if (cs.msgs.some((c) => khopCmt(c, cmt))) { ghi('C4. Ô bình luận biến mất nhưng Facebook (API) xác nhận comment đã lên'); return; } }
        } catch (e) { /* */ }
      }
      if (!x) throw new Error('sau khi gửi comment, ô bình luận biến mất và chưa xác nhận được comment đã lên — không tự gửi lại, lượt rà soát sẽ kiểm tra');
    }
    if (chuan(x.khung.innerText).split(dong1).length <= 1) throw new Error('đã gửi nhưng chưa thấy comment hiện lên');
    ghi('C4. Facebook đã nhận comment');
  }

  // =====================================================================
  //  Trạng thái theo ngày
  // =====================================================================
  function trangThaiNgay(ngay) {
    const s = lay('ngay_' + ngay, null) || {};
    if (s.gio == null) {
      const a = docGio(CAI_DAT.GIO_DANG_TU), b = docGio(CAI_DAT.GIO_DANG_DEN);
      s.gio = a + Math.floor(Math.random() * (b - a + 1));
      s.bai = s.bai || {};
      luu('ngay_' + ngay, s);
    }
    s.bai = s.bai || {};
    return s;
  }
  const luuNgay = (ngay, s) => luu('ngay_' + ngay, s);
  const capNhatNgay = (ngay, f) => { const x = trangThaiNgay(ngay); f(x); luuNgay(ngay, x); return x; };

  function daBaoTuanDau() {
    let d0 = lay('ngay_chay_dau', 0);
    if (!d0) { d0 = Date.now(); luu('ngay_chay_dau', d0); }
    return Date.now() - d0 < CAI_DAT.BAO_DA_DANG_SO_NGAY * 86400000;
  }

  // (5.6.1) việc dở phải chờ vì tab Facebook bị ẩn/thu nhỏ → ghi nhật ký (trước đây chờ im lặng)
  function choTabAn(ten) {
    const now = Date.now(); const k = lay('cho_tab_an', null);
    if (!k || k.ten !== ten) { luu('cho_tab_an', { ten, tu: now, bao: 0 }); ghi(`Đang chờ: tab Facebook bị ẩn/thu nhỏ nên chưa làm tiếp được ${ten} — mở tab này lên màn hình để script chạy tiếp`); return; }
    if (!k.bao && now - k.tu > 5 * 60000) { luu('cho_tab_an', Object.assign(k, { bao: now })); ghi(`Lỗi: ${ten} đã phải chờ ${Math.round((now - k.tu) / 60000)} phút vì tab Facebook bị ẩn/thu nhỏ`); thongBaoMay('Cần mở tab Facebook', `Script đang chờ để làm tiếp ${ten} — hãy mở tab Facebook lên màn hình`); }
  }
  function hetChoTabAn() { const k = lay('cho_tab_an', null); if (!k) return; luu('cho_tab_an', null); ghi(`Tab đã hiện lại sau ${Math.max(1, Math.round((Date.now() - k.tu) / 60000))} phút chờ → làm tiếp ${k.ten}`); }
  function thongBaoMay(tieuDe, noiDung) {
    try {
      GM_notification({ title: tieuDe, text: noiDung, timeout: 0, highlight: true, onclick: () => { try { window.focus(); } catch (e) { /* */ } } });
      ghi('Đã hiện thông báo trên máy: ' + tieuDe);
    } catch (e) { ghi('Không hiện được thông báo trên máy: ' + e.message); }
  }

  // Báo lỗi theo nhịp: lần đầu báo ngay, sau đó 2 tiếng nhắc lại (chỉ trong 7h–23h)
  async function baoLoiTheoNhip(s, luuFn, noiDungDau, noiDungNhac, choMs = 0) {
    const now = Date.now();
    if (!s.loi) s.loi = { msg: noiDungDau.msg, dau: now, baoLuc: 0 }; else s.loi.msg = noiDungDau.msg;
    const canBao = !s.loi.baoLuc || now - s.loi.baoLuc >= CAI_DAT.NHAC_LAI_PHUT * 60000;
    if (canBao && trongGioNhan() && now - (s.loi.dau || now) >= choMs) {
      const lanDau = !s.loi.baoLuc; s.loi.baoLuc = now; luuFn(s);
      await baoLark(lanDau ? noiDungDau.text : noiDungNhac, { toiDa: lanDau ? 1 : CAI_DAT.LOI_NHAC_TOI_DA });
    }
    luuFn(s);
  }

  // =====================================================================
  //  Kiểm tra trước (14h chiều hôm trước)
  // =====================================================================
  let dangKiemTruoc = false;
  async function kiemTruoc(ngay, opt = {}) {
    if (dangKiemTruoc) return;
    dangKiemTruoc = true;
    try { await kiemTruoc2(ngay, opt); } finally { dangKiemTruoc = false; }
  }
  async function kiemTruoc2(ngay, { thuCong = false } = {}) {
    const s = lay('kiem_' + ngay, null) || {};
    s.lanKiem = Date.now(); s.choAnh = false; s.anhMsg = '';
    let loi = null;
    try {
      const v = await docSheet();
      loi = kiemTenCot(v);
      if (!loi) {
        const hs = hangCuaNgay(v, ngay);
        if (!hs.length) loi = `Sheet ${ngayNgan(ngay)}: chưa có hàng đăng bài — cần bổ sung gấp`;
        else {
          const thieu = [];
          for (const h of hs) {
            if (!h.bai) thieu.push(`hàng ${h.hang} thiếu Bài 1`);
            if (!h.cmt) thieu.push(`hàng ${h.hang} thiếu comment Bài 1`);
            if (h.bai2 && h.bai2.length > CAI_DAT.GIOI_HAN_KY_TU_NEN && CAI_DAT.SUA_NEN_B2 !== false) ghi(`Lưu ý ngày ${ngay}: hàng ${h.hang} cột D dài ${h.bai2.length} ký tự — Bài 2 sẽ không sửa được sang nền đỏ (quá ${CAI_DAT.GIOI_HAN_KY_TU_NEN})`);
            if (h.bai && h.bai.length > CAI_DAT.GIOI_HAN_KY_TU_NEN) thieu.push(`hàng ${h.hang} Bài 1 dài ${h.bai.length} ký tự (quá ${CAI_DAT.GIOI_HAN_KY_TU_NEN}, không đặt được nền đỏ) — cần rút gọn`);
          }
          if (thieu.length) loi = `Sheet ${ngayNgan(ngay)}: thiếu ${thieu.join(', ')} — cần bổ sung gấp`;
          else {
            s.soBai = hs.length;
            const ta = hs.reduce((a, h) => a.concat(thieuAnhHang(h)), []);
            const taNgan = hs.reduce((a, h) => a.concat(thieuAnhNgan(h).map((x) => (hs.length > 1 ? `hàng ${h.hang}: ` : '') + x)), []);
            if (ta.length) {
              // thiếu ảnh: trước GIO_BAO_ANH chỉ hiện trên popup cho Cao bổ sung; từ giờ đó mới báo nhóm
              if (phutTrongNgay(new Date()) < docGio(CAI_DAT.GIO_BAO_ANH)) { s.choAnh = true; s.anhMsg = ta.join(', '); }
              else loi = `Sheet ${ngayNgan(ngay)}: thiếu ${taNgan.join(', ')} — cần bổ sung gấp`;
            }
          }
        }
      }
    } catch (e) {
      if (e instanceof LoiLark) { s.ok = false; s.chuaDocDuoc = true; s.loi = { msg: e.message }; luu('kiem_' + ngay, s); return; }
      loi = 'Không đọc được sheet: ' + e.message;
    }
    s.chuaDocDuoc = false;

    const luuK = (x) => luu('kiem_' + ngay, x);
    if (loi) {
      s.ok = false;
      if (thuCong) ghi('Kiểm tra sheet: ' + loi);
      await baoLoiTheoNhip(s, luuK, { msg: loi, text: loi }, 'Nhắc lại: ' + loi);
    } else if (s.choAnh) {
      s.ok = false; luuK(s);
      ghi(`Kiểm tra sheet ngày ${ngay}: còn thiếu ảnh (${s.anhMsg}) — chờ đến ${CAI_DAT.GIO_BAO_ANH} mới báo nhóm`);
    } else {
      const coLoiTruoc = !!(s.loi && s.loi.baoLuc);
      s.ok = true; s.loi = null; luuK(s);
      if (coLoiTruoc) await baoLark(`Sheet ${ngayNgan(ngay)}: đã đủ ✅`);
      ghi(`Kiểm tra sheet ngày ${ngay}: đủ${s.soBai > 1 ? ` (${s.soBai} bài)` : ''}`);
    }
    veBang();
  }

  // =====================================================================
  //  Sau khi đăng: gạch ô B → chờ 15 giây → tải lại trang → comment → gạch ô C
  // =====================================================================
  async function timHangHienTai(ngay, bai) {
    const v = await docSheet();
    const h = hangCuaNgay(v, ngay).find((x) => chuan(x.bai) === chuan(bai.bai));
    if (!h) throw new Error('không còn thấy hàng của bài trên sheet');
    return h.hang;
  }

  async function sauKhiDang(ngay, s, bai) {
    const lucDang = gioStr(new Date());
    s.bai[bai.khoa] = { tt: 'da_dang', luc: bai.lucApi || Date.now(), hang: bai.hang, soNhom: bai.soNhom, link: bai.link || '', id: bai.id || '' };
    luu('bai_cuoi_cua_script', Date.now());
    const coLoiTruoc = !!(s.loi && s.loi.baoLuc);
    s.loi = null; luuNgay(ngay, s);
    ghi(`Đã đăng Bài 1 lúc ${lucDang} (hàng ${bai.hang})`);

    const ghiChu = [];
    if (CAI_DAT.GACH_NGANG) { try { await gachNgang('B' + (await timHangHienTai(ngay, bai))); ghi('Đã gạch ngang ô B'); } catch (e) { ghiChu.push('chưa gạch ngang được ô B: ' + e.message); } }
    const dd = { khoa: bai.khoa, ngay, hang: bai.hang, bai: bai.bai, cmt: bai.cmt, lucDang, coLoiTruoc, ghiChu, lanThuCmt: 0, soNhom: bai.soNhom, link: bai.link || '', id: bai.id || '' };
    if (!bai.cmt) { dd.camXucBai = await thaCamXucBai(bai.bai); dd.cmtTrangThai = 'trong'; await hoanTat(dd, ['cột C trống nên chưa comment']); return; }
    luu('dang_do', Object.assign(dd, { buoc: 'cho_binh_luan', luc: Date.now() }));
    ghi('Chờ vài giây rồi tải lại trang để comment');
    await sleep(2500); await baoLinkBaiScript().catch(() => {}); await sleep(1500);
    roiTrang();
  }

  async function hoanTat(dd, ghiChuThem = []) {
    const ngay = dd.ngay; const s = trangThaiNgay(ngay);
    const ghiChu = [...new Set((dd.ghiChu || []).concat(ghiChuThem))];
    for (const [ten, kq] of [['bài', dd.camXucBai], ['comment', dd.camXucCmt]]) if (kq && kq.tt === 'chua') ghi('Chưa thả được cảm xúc cho ' + ten + ' (' + kq.loi + ') — lượt quét sẽ thả bù, không báo nhóm');
    s.bai[dd.khoa] = Object.assign(s.bai[dd.khoa] || { luc: Date.now(), hang: dd.hang }, { tt: 'xong', link: dd.link || '', id: dd.id || '', ghiChu, soNhom: dd.soNhom, cmtTrangThai: dd.cmtTrangThai || 'can_kiem', camXucBai: dd.camXucBai || null, camXucCmt: dd.camXucCmt || null });
    if (Object.values(s.bai).filter(daXongTt).length >= (s.biet_het || 1)) s.xong = true;
    s.doLuc = 0; // lần nhịp tới dò lấy link bài qua API
    luuNgay(ngay, s);
    luu('dang_do', null);
    if (dd.viaLink && !dungTrang()) setTimeout(() => { if (!dangBan && !lay('dang_do', null)) veTrang(); }, 4000);
    const phan = `Bài 1 đăng lúc ${dd.lucDang}`;
    if (dd.cmtTrangThai !== 'xac_nhan' && !ghiChu.some((x) => /comment/.test(x))) ghiChu.push('comment chưa được API xác nhận — cần kiểm tra');
    luuNgay(ngay, s);
    ghi(ghiChu.length ? 'Xong, có lưu ý: ' + ghiChu.join('; ') : 'Xong hàng ' + dd.hang);
    if (ghiChu.length) await baoLark(`⚠ ${phan} — ${ghiChu.join('; ')}`);
    else if (dd.coLoiTruoc) await baoLark(`✅ ${phan} (đã xử lý xong lỗi trước đó)`);
    else if (daBaoTuanDau()) await baoLark(`✅ ${phan}${dd.soNhom ? ` · ${dd.soNhom} nhóm` : ''}${dd.cmtTrangThai === 'xac_nhan' ? '' : ' · comment cần kiểm tra'}`);
  }

  async function xuLyDangDo() {
    const dd = lay('dang_do', null);
    if (!dd) return false;
    dangBan = true; giuKhoa();
    try { return await xuLyDangDo2(dd); } finally { dangBan = false; giuKhoa(); }
  }
  // link bài Bài 1 (để mở thẳng trang riêng của bài khi trang chính không hiện)
  async function layLinkBai1(dd) {
    if (dd.link && /^https?:/.test(dd.link)) return dd.link;
    if (!coApi()) return '';
    try { const p = baiGiongNhat(await baiTrenTrangApi(Date.now() - 864e5), dd.bai); if (p) { dd.id = p.id; dd.link = p.link; return p.link || ''; } } catch (e) { ghi('Tìm link bài qua API lỗi: ' + e.message); }
    return '';
  }
  async function xuLyDangDo2(dd) {
    if ((hopDangDo() || hopSoanBai() || dangODuongSua()) && nguoiDangThaoTac()) return true; // (5.4) người đang soạn bài → không tải lại trang, đợi họ xong
    if (dd.loai >= 2) return xuLyDangDoB23(dd); // Bài 2 / Bài 3
    const ngay = dd.ngay;
    if (!laTabChinh()) return true;
    if (trangThaiNgay(ngay).huy) { // (4.5) Cao bấm Hủy: không treo cả script — chốt việc dở rồi giải phóng
      luu('dang_do', null);
      if (dd.buoc === 'kiem_bai') capNhatNgay(ngay, (x) => { if (!x.bai[dd.khoa]) x.bai[dd.khoa] = { tt: 'khong_ro', luc: Date.now(), hang: dd.hang }; });
      else capNhatNgay(ngay, (x) => { x.bai[dd.khoa] = Object.assign(x.bai[dd.khoa] || { luc: Date.now(), hang: dd.hang }, { tt: 'xong', ghiChu: ['Cao bấm Hủy hôm nay nên script không comment'] }); });
      ghi('Hôm nay đã Hủy → bỏ việc dở của Bài 1 (không comment)'); return false;
    }
    if (lay('tam_dung', false)) {
      if (dd.buoc === 'kiem_bai' && coApi()) {
        try {
          const p = baiGiongNhat(await baiTrenTrangApi(Date.now() - 864e5), dd.bai);
          if (p) {
            capNhatNgay(ngay, (x) => { x.bai[dd.khoa] = Object.assign(x.bai[dd.khoa] || {}, { tt: 'da_dang', luc: p.luc, hang: dd.hang, soNhom: dd.soNhom, link: p.link, id: p.id, cmtTrangThai: 'cho' }); });
            Object.assign(dd, { buoc: 'cho_binh_luan', link: p.link, id: p.id, lucDang: gioStr(new Date(p.luc)), luc: Date.now() });
            luu('dang_do', dd); ghi('Đang dừng: API xác nhận bài đã đăng; comment còn chờ');
          }
        } catch (e) { ghi('Đang dừng: chưa xác minh được bài — ' + e.message); }
      }
      return true;
    }
    if (document.visibilityState !== 'visible') { choTabAn('Bài 1'); return true; } // (4.5) tab ẩn: Facebook không vẽ trang → chờ, không tính là thất bại
    hetChoTabAn();
    const choPhepTrang = dungTrang() || (dd.viaLink && /(^|\.)facebook\.com$/.test(location.hostname));
    if (!choPhepTrang) { veTrang(); return true; }

    if (dd.buoc === 'kiem_bai') { // vừa bấm Đăng thì trang tải lại
      dd.kiemLan = (dd.kiemLan || 0) + 1; luu('dang_do', dd);
      const thay = await cho(() => timBai(dd.bai), 30000, 1000);
      if (thay) { await sauKhiDang(ngay, trangThaiNgay(ngay), dd); return true; }
      // (4.5) phương án 2: hỏi Facebook API — bài có thể đã lên mà trang chưa hiện
      if (coApi()) {
        try {
          const p = baiGiongNhat(await baiTrenTrangApi(dd.luc - 10 * 60000), dd.bai);
          if (p) { ghi('Facebook (API) xác nhận Bài 1 đã lên (trang chưa hiện) → tiếp tục comment'); await sauKhiDang(ngay, trangThaiNgay(ngay), Object.assign({}, dd, { link: p.link, id: p.id, lucApi: p.luc })); return true; }
          dd.apiKhong = (dd.apiKhong || 0) + 1; luu('dang_do', dd); // (4.5) API TRẢ LỜI được: chưa có bài
        } catch (e) { ghi('Kiểm bài qua API lỗi: ' + e.message); }
      }
      if (dd.kiemLan === 2 || dd.kiemLan === 4 || dd.kiemLan === 8) { ghi('Chưa thấy bài vừa đăng → tải lại trang kiểm tra lần nữa'); roiTrang(); return true; }
      if (dd.kiemLan >= 6 && coApi() && (dd.apiKhong || 0) < 4 && dd.kiemLan < 12) { // (4.5) API lỗi nhiều → chưa đủ chắc là bài chưa lên → kiểm tiếp, KHÔNG đăng lại
        if (dd.kiemLan === 6) ghi('Chưa hỏi được Facebook (API) đủ số lần để chắc bài chưa lên → kiểm tiếp, chưa đăng lại');
        return true;
      }
      if (dd.kiemLan >= 6) {
        if (coApi() && (dd.apiKhong || 0) >= 4) { // API trả lời ≥4 lần đều không thấy → bài chưa lên → cho đăng lại (bước dò trùng trước khi bấm Đăng sẽ chặn đăng trùng)
          luu('dang_do', null);
          capNhatNgay(ngay, (x) => { delete x.bai[dd.khoa]; x.loi = Object.assign(x.loi || { dau: Date.now(), baoLuc: 0 }, { msg: 'Đã bấm Đăng nhưng bài không lên trang' }); x.lanThu = Date.now(); });
          ghi('Lỗi: đã bấm Đăng nhưng sau nhiều lần kiểm (trang + Facebook API) vẫn không có bài → coi như chưa đăng, sẽ tự đăng lại (có dò trùng trước khi bấm Đăng)'); chupLoi('Bài 1 không lên trang');
        } else {
          luu('dang_do', null);
          capNhatNgay(ngay, (x) => { x.bai[dd.khoa] = { tt: 'khong_ro', luc: Date.now(), hang: dd.hang }; });
          ghi(`Lỗi nhận diện Bài 1: đã bấm Đăng nhưng không thấy bài trên trang sau ${dd.kiemLan} lần kiểm${coApi() ? ' (API trả lời ' + (dd.apiKhong || 0) + ' lần là chưa có)' : ' — chưa cài mã khoá nên chỉ dò được bằng màn hình'}; sẽ tự dò lại mỗi 10 phút`); chupLoi('Bài 1 không nhận diện được');
          await baoLark(`Bài 1: đã bấm Đăng nhưng không thấy bài trên trang${coApi() ? '' : ' (chưa cài mã khoá)'} — script không đăng lại để tránh trùng, cần vào trang kiểm tra tay`, { batBuoc: true });
        }
      }
      return true;
    }

    if (dd.buoc === 'cho_binh_luan') {
      window.scrollTo(0, 0); await sleep(1500);
      const b = await cho(() => timBai(dd.bai), 25000, 1000);
      if (!b) {
        // (4.5) chưa thấy ô bình luận: tải lại 1 lần → mở thẳng link bài → tải lại trang bài → mới chịu
        dd.timLan = (dd.timLan || 0) + 1; luu('dang_do', dd);
        if (dd.timLan === 1) { ghi('Chưa thấy ô bình luận của Bài 1 → tải lại trang'); roiTrang(); return true; }
        if (!dd.viaLink) { const lk = await layLinkBai1(dd); if (lk) { dd.viaLink = lk; luu('dang_do', dd); ghi('Không thấy bài trên trang chính → mở thẳng link bài để comment: ' + lk); await sleep(800); roiTrang(lk); return true; } }
        if (dd.timLan >= 4) await hoanTat(dd, ['đã tải lại trang và mở thẳng link bài nhưng không tìm được ô bình luận nên chưa comment cột C — lượt rà soát sẽ thử lại']);
        else if (dd.viaLink) { ghi('Chưa thấy ô bình luận trên trang bài → tải lại'); roiTrang(); }
        return true;
      }
      dd.link = dd.link || linkBai(b.khung);
      if (!dd.daThaBai) { dd.camXucBai = await thaCamXucBai(dd.bai); dd.daThaBai = true; luu('dang_do', dd); }
      try {
        kiemDung();
        // Khi tiếp tục sau dừng/tải lại, dò trước để không gửi trùng comment.
        const coTruoc = await xacNhanCmtApi(dd.bai, dd.cmt, 1);
        if (coTruoc.thay === true) {
          Object.assign(dd, { id: coTruoc.id, link: coTruoc.link || dd.link, cmtTrangThai: 'xac_nhan' });
          ghi('C5. API xác nhận comment đã có — không gửi lại');
          await hoanTat(dd); return true;
        }
        if (dd.daGuiCmt) { dd.cmtTrangThai = 'can_kiem'; await hoanTat(dd, ['Đã gửi comment trước đó nhưng chưa xác nhận được — không gửi lại, lượt rà soát sẽ kiểm tra']); return true; }
        kiemDung();
        await binhLuan(dd.bai, dd.cmt, () => {
          dd.daGuiCmt = true; dd.cmtTrangThai = 'da_gui'; dd.buoc = 'dang_binh_luan'; luu('dang_do', dd);
        });
        const xn = await xacNhanCmtApi(dd.bai, dd.cmt);
        if (xn.link) dd.link = xn.link; if (xn.id) dd.id = xn.id;
        dd.cmtTrangThai = xn.thay === true ? 'xac_nhan' : 'can_kiem';
        const ghiChu = [];
        if (xn.thay === true) ghi('C5. Facebook API xác nhận comment cột C đã lên');
        else ghiChu.push(xn.thay === false ? 'API chưa thấy comment cột C — lượt rà soát sẽ kiểm tra lại' : 'Không kiểm chứng được comment qua API — lượt rà soát sẽ kiểm tra lại');
        dd.camXucCmt = await thaCamXucCmt(dd.bai, dd.cmt);
        if (CAI_DAT.GACH_NGANG && xn.thay === true) { try { kiemDung(); await gachNgang('C' + (await timHangHienTai(ngay, dd))); } catch (e) { ghiChu.push('chưa gạch ô C: ' + e.message); } }
        await hoanTat(dd, ghiChu);
      } catch (e) {
        if (e instanceof LoiChuaGui) { dd.daGuiCmt = false; dd.buoc = 'cho_binh_luan'; dd.cmtTrangThai = ''; luu('dang_do', dd); }
        if (e && e.doiTuCach) { ghi('Comment Bài 1 chờ: ' + e.message); return true; } // (4.5) trang đang tự tải lại sau khi chuyển tư cách
        if (e instanceof LoiDung && !dd.daGuiCmt) {
          dd.buoc = 'cho_binh_luan'; luu('dang_do', dd); ghi('Comment còn chờ: ' + e.message); return true;
        }
        if (!dd.daGuiCmt && !(e instanceof LoiTuChoi)) { // (4.5) chưa gửi gì → an toàn: tải lại thử lại 2 lần, rồi mở thẳng link bài
          dd.thuCmt = (dd.thuCmt || 0) + 1; luu('dang_do', dd);
          if (dd.thuCmt <= 2) { ghi(`Comment Bài 1 chưa gửi được (${e.message}) → tải lại trang rồi thử lại (lần ${dd.thuCmt}/2)`); roiTrang(); return true; }
          if (!dd.viaLink) { const lk = await layLinkBai1(dd); if (lk) { dd.viaLink = lk; luu('dang_do', dd); ghi('Vẫn chưa comment được → mở thẳng link bài để comment: ' + lk); roiTrang(lk); return true; } }
        }
        ghi('Lỗi comment: ' + e.message);
        const xn = await xacNhanCmtApi(dd.bai, dd.cmt);
        if (xn.link) dd.link = xn.link; if (xn.id) dd.id = xn.id;
        dd.cmtTrangThai = xn.thay === true ? 'xac_nhan' : 'can_kiem';
        await hoanTat(dd, xn.thay === true ? [] : ['Comment chưa được xác nhận (' + e.message + ') — lượt rà soát sẽ kiểm tra và gửi bù nếu thiếu']);
      }

      return true;
    }

    if (dd.buoc === 'dang_binh_luan') {
      const xn = await xacNhanCmtApi(dd.bai, dd.cmt);
      if (xn.id) dd.id = xn.id; if (xn.link) dd.link = xn.link;
      dd.cmtTrangThai = xn.thay === true ? 'xac_nhan' : 'can_kiem';
      await hoanTat(dd, xn.thay === true ? [] : ['trang tải lại lúc đang gửi comment — chưa xác nhận được, lượt rà soát sẽ kiểm tra']);
      return true;
    }
    return false;
  }

  // =====================================================================
  //  Vòng đăng bài buổi sáng
  // =====================================================================
  let demNguocDen = 0;   // thời điểm bấm đăng (ms), 0 = chưa đếm
  let hangSapDang = null;
  // =====================================================================
  //  1.1 — Dò bài trùng · Tự kiểm 6h50 · Tổng kết tối · Soạn thử
  // =====================================================================
  const daXongTt = (b) => b.tt === 'xong' || b.tt === 'co_san';

  // Tìm bài có cùng nội dung trong các bài gần đây trên trang (chỉ tìm trong bài đã đăng, không tính bản nháp)
  async function baiDaCoTrenTrang(text) {
    if (coApi()) {
      try {
        const tuLuc = new Date(new Date().setHours(0, 0, 0, 0)).getTime() - 6 * 3600e3; // (4.5) từ 18:00 hôm qua
        const ds = (await baiTrenTrangApi(tuLuc)).filter((p) => p.luc >= tuLuc);
        const p = baiGiongNhat(ds, text);
        ghi(p ? `Dò trùng qua API: bài đã có trên trang (giống ${Math.round(p.diem * 100)}%)` : 'Dò trùng qua API: chưa có bài này trên trang');
        return p ? { link: p.link, luc: p.luc, id: p.id } : null;
      } catch (e) { ghi('Dò trùng qua API lỗi (' + e.message + ') → dò bằng cách cuộn trang'); }
    }
    const y0 = window.scrollY; let thay = null;
    try {
      for (const y of [0, 1200, 2400, 3600, 4800]) {
        window.scrollTo(0, y); await sleep(y ? 1800 : 800);
        thay = timBai(text); if (thay) break;
      }
    } finally { window.scrollTo(0, y0); }
    return thay;
  }

  async function danhDauCoSan(ngay, bai, x) {
    const link = x ? (x.link || (x.khung ? linkBai(x.khung) : '')) : '';
    let gach = false;
    if (CAI_DAT.GACH_NGANG) { try { await gachNgang('B' + (await timHangHienTai(ngay, bai))); gach = true; } catch (e) { ghi('Chưa gạch được ô B: ' + e.message); } }
    const s = trangThaiNgay(ngay);
    s.bai[bai.khoa] = { tt: 'co_san', luc: x && x.luc ? x.luc : Date.now(), hang: bai.hang, link, id: (x && x.id) || '', ghiChu: ['bài đã có sẵn trên trang, script không đăng, không comment'] };
    if (Object.values(s.bai).filter(daXongTt).length >= (s.biet_het || 1)) s.xong = true;
    s.loi = null; luuNgay(ngay, s);
    luu('dang_ngay', null); demNguocDen = 0;
    ghi(`Hàng ${bai.hang} đã có sẵn trên trang → không đăng lại`);
    await baoLark(`Bài 1 đã có sẵn trên trang (có thể đăng tay), script không đăng lại — cần xem đã có comment chưa${link ? ` — ${link}` : ''}`, { batBuoc: true });
  }

  const hopDangDo = () => hopThoai((d) => laCaiDat(d) || laNhom(d));

  // 6h50: mở thử hộp đăng bài, xem đủ nút chưa, rồi đóng lại — không đăng gì
  async function tuKiem() {
    const ngay = homNay(); const s = trangThaiNgay(ngay);
    const ep = lay('tu_kiem_ngay', null); // Cao bấm "Tự kiểm ngay"
    if (!ep && !dangTuDongBat()) return false;
    if (ep) luu('tu_kiem_ngay', null);
    if (!(ep && Date.now() - ep.luc < 5 * 60000)) {
      if (s.tuKiem || s.xong || s.huy || s.dung || Object.keys(s.bai).length) return false;
      const m = phutTrongNgay(new Date());
      if (m < docGio(CAI_DAT.GIO_TU_KIEM) || m >= s.gio - 4) return false;
    } else if (dangBan || lay('dang_do', null) || (demNguocDen && demNguocDen - Date.now() < 90000)) { ghi('Tự kiểm ngay: đang sắp đăng/đang đăng nên bỏ qua'); return false; }
    const loi = [];
    try {
      if (document.visibilityState !== 'visible') throw new Error('tab Facebook đang bị ẩn hoặc thu nhỏ — đến giờ đăng sẽ không chạy được');
      if (!(await damBaoTuCach())) return true;
      if (!dungTrang()) { veTrang(); return true; }
      if (hopDangDo()) throw new Error('đang có hộp đăng bài mở dở (có thể do Soạn thử) — cần bấm Đăng hoặc đóng lại');
      window.scrollTo(0, 0); await sleep(800);
      let dlg = hopSoanBai();
      if (!dlg) {
        const nut = timNutSoanBai(); if (!nut) throw new Error('không thấy ô "Bạn đang nghĩ gì?"');
        nut.click(); dlg = await cho(hopSoanBai, 15000);
      }
      if (!dlg) throw new Error('không mở được hộp soạn bài');
      if (!chuan(dlg.innerText.split('\n').slice(0, 3).join(' ')).includes(chuan(CAI_DAT.TEN_TRANG))) loi.push('hộp soạn bài không đứng tên trang');
      const moNen = dlg.querySelector('[aria-label="Hiển thị các tùy chọn phông nền"]');
      if (moNen) { moNen.click(); await sleep(1000); }
      if (!(await cho(() => hopSoanBai() && hopSoanBai().querySelector(`[aria-label^="${CAI_DAT.NEN}"]`), 8000))) loi.push(`không thấy nền "${CAI_DAT.NEN}"`);
      const h = hopSoanBai();
      if (h && !h.querySelector('[aria-label="Vị trí"], [aria-label="Check in"]')) loi.push('không thấy nút Vị trí');
      if (h && !h.querySelector('[aria-label="Tiếp"]')) loi.push('không thấy nút Tiếp');
      const x = h && h.querySelector('[aria-label="Đóng hộp thoại của công cụ tạo"]'); if (x) x.click();
      await sleep(1200);
      const hoi = hopThoai((d) => /Bỏ bài viết|Rời khỏi|bỏ những thay đổi/i.test(d.innerText));
      if (hoi) { const bo = nutTheoChu(hoi, 'Bỏ') || nutTheoChu(hoi, 'Rời khỏi'); if (bo) bo.click(); await sleep(800); }
      if (hopSoanBai()) loi.push('đóng hộp soạn bài không được — cần đóng tay');
    } catch (e) { loi.push(e.message); }
    const s2 = trangThaiNgay(ngay);
    s2.tuKiem = { luc: Date.now(), ok: !loi.length, loi: loi.join('; ') }; luuNgay(ngay, s2);
    if (loi.length) {
      ghi('Tự kiểm: ' + loi.join('; '));
      await baoLark(`Cần xử lý trước ${phutStr(s2.gio)}: ${loi.join('; ')}`, { batBuoc: true });
    } else ghi('Tự kiểm: ổn (đủ nền đỏ, vị trí, nút Tiếp)');
    return true;
  }

  // =====================================================================
  //  1.3 — Đọc bài trên trang qua Facebook Graph API (CHỈ ĐỌC, không đăng gì)
  //  → biết Bài 1/2/3 đã lên trang chưa, giờ đăng chính xác, link bài.
  //  Không cuộn trang, không tải lại trang, chạy được cả khi tab bị ẩn.
  // =====================================================================
  const fbToken = () => lay('fb_token', '') || CAI_DAT.FB_TOKEN;
  const coApi = () => !!(fbToken() && CAI_DAT.FB_PAGE_ID);
  // So "gần giống": tách thành từng từ (bỏ dấu câu, emoji, xuống dòng, hoa/thường, đường link),
  // rồi tính bao nhiêu % số từ trên sheet có mặt trong bài/comment trên trang.
  const tuCua = (s) => String(s == null ? '' : s).normalize('NFC').toLowerCase().replace(/https?:\/\/\S+/g, ' ').split(/[^\p{L}\p{N}]+/u).filter(Boolean);
  const linkCua = (s) => (String(s == null ? '' : s).match(/https?:\/\/\S+/g) || []).map((u) => u.replace(/[?#].*$/, '').replace(/[)\].,]+$/, '').replace(/\/+$/, '').replace(/^https?:\/\/(www\.|m\.)?/, '').toLowerCase());
  function doGiong(msg, text) {
    const a = tuCua(text); if (!a.length) return 0;
    const dem = new Map(); for (const w of tuCua(msg)) dem.set(w, (dem.get(w) || 0) + 1);
    let co = 0; for (const w of a) { const n = dem.get(w) || 0; if (n > 0) { co++; dem.set(w, n - 1); } }
    return co / a.length;
  }
  const doDaiHop = (msg, text) => tuCua(msg).length <= tuCua(text).length * 1.6 + 6; // bài dài gấp rưỡi trở lên thì không phải cùng bài
  const khopBai = (msg, text) => tuCua(text).length >= 3 && doDaiHop(msg, text) && doGiong(msg, text) >= CAI_DAT.NGUONG_BAI;
  const khopCmt = (msg, text) => { const l = linkCua(text); if (l.length && linkCua(msg).some((x) => l.includes(x))) return true; return tuCua(text).length >= 2 && doGiong(msg, text) >= CAI_DAT.NGUONG_CMT; };
  // chọn bài giống nhất (đạt ngưỡng) trong danh sách, bỏ qua các bài đã dùng cho mục khác
  function baiGiongNhat(ds, text, daDung) {
    let tot = null; let diem = 0;
    for (const p of ds) { if (daDung && daDung.has(p.id)) continue; if (!doDaiHop(p.text, text)) continue; const d = doGiong(p.text, text); if (d > diem) { diem = d; tot = p; } }
    return tot && tuCua(text).length >= 3 && diem >= CAI_DAT.NGUONG_BAI ? Object.assign({ diem }, tot) : null;
  }

  function goiFbMot(duongDan, token) {
    return new Promise((resolve, reject) => {
      GM_xmlhttpRequest({
        method: 'GET', url: 'https://graph.facebook.com' + duongDan,
        headers: { Authorization: 'OAuth ' + (token || fbToken()) }, timeout: 20000,
        onload: (r) => {
          let j = null; try { j = JSON.parse(r.responseText); } catch (e) { /* */ }
          if (j && !j.error && r.status < 400) resolve(j);
          else { const e = new LoiMem('Facebook API từ chối: ' + (j && j.error ? `${j.error.message || ''} (mã ${j.error.code})` : 'mã ' + r.status)); e.ma = j && j.error ? j.error.code : r.status; e.tam = !j || r.status >= 500 || [1, 2, 4, 17, 32, 341, 368, 613].includes(e.ma); e.maKhoa = [190, 102, 463, 467].includes(e.ma); reject(e); }
        },
        onerror: () => { const e = new LoiMem('Mất kết nối khi gọi Facebook API'); e.tam = true; reject(e); },
        ontimeout: () => { const e = new LoiMem('Facebook API phản hồi quá lâu'); e.tam = true; reject(e); },
      });
    });
  }
  // (4.5) lỗi mạng/quá lâu/Facebook bận: tự thử lại tối đa 2 lần (cách 2–5 giây)
  async function goiFb(duongDan, token) {
    for (let lan = 0; ; lan++) {
      try { return await goiFbMot(duongDan, token); }
      catch (e) { if (e.tam && lan < 2) { await sleep(2000 + Math.floor(Math.random() * 3000)); continue; } throw e; }
    }
  }

  // Cao dán mã khoá (copy từ trang Meta for Developers) → kiểm tra thử rồi mới lưu
  async function caiMaKhoa() {
    const nhap = prompt('Dán mã khoá Facebook (chỉ đọc) của trang vào đây:\n(Để trống rồi bấm OK = xoá mã khoá đang cài)');
    if (nhap == null) return;
    const t = nhap.replace(/\s/g, '');
    if (!t) { luu('fb_token', ''); ghi('Đã xoá mã khoá Facebook'); veBang(); return; }
    if (!/^EAA[A-Za-z0-9]{50,}$/.test(t)) { alert('Mã khoá không đúng dạng (phải bắt đầu bằng EAA...). Cao copy lại giúp nhé.'); return; }
    try {
      // Nếu dán mã của NGƯỜI DÙNG (dài hạn) thì tự đổi sang mã của TRANG (không hết hạn)
      let maTrang = t;
      try {
        const acc = await goiFb('/me/accounts?fields=id,name,access_token&limit=100', t);
        const pg = (acc.data || []).find((x) => x.id === CAI_DAT.FB_PAGE_ID);
        if (pg && pg.access_token) { maTrang = pg.access_token; ghi('Mã dán vào là mã người dùng → đã đổi sang mã của trang ' + pg.name); }
      } catch (e) { /* mã của trang thì không có danh sách trang — dùng luôn */ }
      const j = await goiFb(`/${CAI_DAT.FB_PAGE_ID}?fields=name`, maTrang);
      let cmtOk = null;
      try { const ps = await goiFb(`/${CAI_DAT.FB_PAGE_ID}/posts?fields=id&limit=1`, maTrang); if (ps.data && ps.data[0]) { await goiFb(`/${ps.data[0].id}/comments?fields=message&limit=1`, maTrang); cmtOk = true; } } catch (e) { cmtOk = false; }
      luu('fb_token', maTrang); luu('fb_token_luc', Date.now()); luu('fb_token_nhac', 0);
      capNhat('suc_khoe', cmtOk === null ? {} : { cmtOk, cmtLuc: Date.now(), cmtLoi: cmtOk ? '' : 'mã khoá chưa có quyền đọc comment' });
      const s = trangThaiNgay(homNay()); s.doLuc = 0; s.apiBao = 0; luuNgay(homNay(), s);
      capNhat('suc_khoe', { apiOk: true, apiLuc: Date.now(), apiLoi: '' });
      ghi('Đã cài mã khoá Facebook cho trang ' + j.name);
      alert(`Đã kết nối: "${j.name}".\nĐọc bài: được · Đọc comment: ${cmtOk === false ? 'CHƯA được (mã khoá thiếu quyền đọc comment)' : 'được'}.`);
      yeuCauViec('dobai');
    } catch (e) { alert('Mã khoá chưa dùng được: ' + e.message); }
    veBang();
  }

  // Xoá dữ liệu từng ngày cũ hơn 30 ngày (1 lần/ngày)
  function donDuLieuCu() {
    if (typeof GM_listValues === 'function') {
      const giu = new Set(Array.from({ length: 7 }, (_, i) => K(khoaNK(congNgay(-i)))));
      const tinHomNay = K('tin112_' + homNay());
      for (const k of GM_listValues()) if (String(k).startsWith(K('tin112_')) && k !== tinHomNay) GM_deleteValue(k);
      for (const k of GM_listValues()) if (String(k).startsWith(K('nk112_')) && /^that_nk112_\d{2}-\d{2}-\d{4}$/.test(k) && !giu.has(k)) GM_deleteValue(k);
    }
    if (typeof GM_listValues !== 'function') return;
    const homNayS = homNay();
    if (lay('don_ngay', '') === homNayS) return;
    luu('don_ngay', homNayS);
    const han = Date.now() - CAI_DAT.GIU_DU_LIEU_NGAY * 864e5;
    let xoa = 0;
    for (const k of GM_listValues()) {
      const m = String(k).match(/^that_(?:ngay|kiem)_(\d{2})-(\d{2})-(\d{4})$/);
      if (!m) continue;
      const t = new Date(+m[3], +m[2] - 1, +m[1]).getTime();
      if (t < han) { GM_deleteValue(k); xoa++; }
    }
    if (xoa) ghi(`Đã dọn ${xoa} mục dữ liệu cũ hơn ${CAI_DAT.GIU_DU_LIEU_NGAY} ngày`);
  }

  // Kiểm tra mã khoá: đọc tên trang + thử đọc comment
  async function kiemMaKhoa() {
    if (!coApi()) { alert('Chưa cài mã khoá Facebook.'); return; }
    const kq = []; let ok = true;
    try { const j = await goiFb(`/${CAI_DAT.FB_PAGE_ID}?fields=name`); kq.push(`Đọc trang "${j.name}": được`); } catch (e) { ok = false; kq.push('Đọc trang: KHÔNG được — ' + e.message); }
    try { const ps = await goiFb(`/${CAI_DAT.FB_PAGE_ID}/posts?fields=id&limit=1`); if (ps.data && ps.data[0]) await cmtCuaBaiApi(ps.data[0].id); kq.push('Đọc comment: được'); capNhat('suc_khoe', { cmtOk: true, cmtLuc: Date.now(), cmtLoi: '' }); } catch (e) { ok = false; kq.push('Đọc comment: KHÔNG được — ' + e.message); }
    const luc = lay('fb_token_luc', 0);
    if (luc) { const n = Math.floor((Date.now() - luc) / 864e5); kq.push(`Mã khoá đã dùng ${n} ngày (cài ${ngayStr(new Date(luc))}) · nên lấy mã mới trước ${ngayStr(new Date(luc + CAI_DAT.MA_KHOA_HAN_NGAY * 864e5))}`); }
    capNhat('suc_khoe', { apiOk: ok, apiLuc: Date.now(), apiLoi: ok ? '' : 'xem nút Kiểm tra mã khoá' });
    ghi('Kiểm tra mã khoá: ' + kq.join(' · '));
    alert((ok ? '✅ Mã khoá dùng tốt' : '⚠ Mã khoá có vấn đề') + '\n\n' + kq.join('\n'));
    veBang();
  }
  // Facebook có thể đòi cấp lại quyền sau ~90 ngày → nhắc trước (ngày 80 và ngày 87)
  async function nhacGiaHanMa() {
    if (!coApi()) return;
    let luc = lay('fb_token_luc', 0);
    if (!luc) { luc = Date.now(); luu('fb_token_luc', luc); } // mã cài từ bản cũ: tính từ lúc lên bản này
    const n = Math.floor((Date.now() - luc) / 864e5);
    const moc = [CAI_DAT.MA_KHOA_HAN_NGAY - 10, CAI_DAT.MA_KHOA_HAN_NGAY - 3].filter((x) => n >= x);
    if (!moc.length || !trongGioNhan()) return;
    const daNhac = lay('fb_token_nhac', 0);
    if (daNhac >= moc[moc.length - 1]) return;
    luu('fb_token_nhac', moc[moc.length - 1]);
    await baoLark(`Mã khoá Facebook đã dùng ${n} ngày, sắp hết hạn (~${ngayStr(new Date(luc + CAI_DAT.MA_KHOA_HAN_NGAY * 864e5))}) — cần đổi mã mới ("Đổi mã khoá" trên popup)`);
  }

  // Các bài trang đã đăng từ mốc tuMs đến giờ → [{ text, luc, link }]
  async function baiTrenTrangApi(tuMs) {
    let url = `/${CAI_DAT.FB_PAGE_ID}/posts?fields=id,message,created_time,permalink_url&limit=50&since=${Math.floor(tuMs / 1000)}`;
    const out = [];
    try {
      for (let i = 0; i < 4 && url; i++) {
        const j = await goiFb(url);
        for (const p of j.data || []) {
          out.push({ id: p.id, text: p.message || '', luc: Date.parse(String(p.created_time).replace(/([+-]\d\d)(\d\d)$/, '$1:$2')), link: p.permalink_url || '' });
        }
        const next = j.paging && j.paging.next;
        url = next ? next.replace(/^https:\/\/graph\.facebook\.com(\/v[\d.]+)?/, '') : null;
      }
      capNhat('suc_khoe', { apiOk: true, apiLuc: Date.now(), apiLoi: '' });
      return out;
    } catch (e) {
      capNhat('suc_khoe', { apiOk: false, apiLuc: Date.now(), apiLoi: e.message });
      throw e;
    }
  }

  // Sau khi comment Bài 1: hỏi Facebook API xem comment cột C đã lên thật chưa (thử tối đa ~40 giây)
  // → { thay: true | false | null (không kiểm được), id, link }
  async function xacNhanCmtApi(text, cmt, soLan = 4) {
    if (!coApi() || !cmt) return { thay: null };
    let id = '', link = '', loiCuoi = '', docDuoc = false;
    for (let lan = 0; lan < soLan; lan++) {
      if (lan) await sleep(10000);
      try {
        if (!id) {
          const p = baiGiongNhat(await baiTrenTrangApi(Date.now() - 864e5), text);
          if (!p) { docDuoc = true; continue; }
          id = p.id; link = p.link;
        }
        const cs = await cmtCuaBaiApi(id); docDuoc = true;
        if (cs.some((c) => khopCmt(c, cmt))) return { thay: true, id, link };
      } catch (e) { loiCuoi = e.message; }
    }
    if (!docDuoc && loiCuoi) ghi('Không xác nhận được comment qua API: ' + loiCuoi);
    return { thay: id && docDuoc ? false : null, id, link };
  }

  // Ghi giá trị vào 1 ô của sheet (VD 'G31' = 'Đã đăng')
  async function ghiO(o, giaTri) {
    const r = await goiLark('PUT', `https://open.larksuite.com/open-apis/sheets/v2/spreadsheets/${CAI_DAT.SHEET_TOKEN}/values`,
      { valueRange: { range: `${CAI_DAT.SHEET_ID}!${o}:${o}`, values: [[giaTri]] } });
    if (!r.json || r.json.code !== 0) throw new Error('mã ' + (r.json ? r.json.code : r.status));
    sheetCache = null; const c112 = lay('sheet_cache112', null); luu('sheet_cache112', c112 ? Object.assign({}, c112, { het: true }) : null);
  }

  // Đủ Bài 1 + Bài 2 + Bài 3 của 1 hàng → chuyển cột G (Trạng thái) sang "Đã đăng"
  // (cột D/F để trống = hôm đó không có bài đó → không chờ)
  function hangDuBai(s, h, ngay) {
    const b1 = s.bai[ngay + '|' + bam(h.bai)];
    const b23 = s.b23 || {};
    return !!(h.bai && b1 && (daXongTt(b1) || b1.tt === 'da_dang') && (!h.bai2 || b23['2|' + h.hang]) && (!h.bai3 || b23['3|' + h.hang]));
  }
  async function capNhatCotG() {
    if (!laTabChinh() || chanLark()) return;
    const ngay = homNay(); const s = trangThaiNgay(ngay);
    const hs = hangHomNay();
    if (!hs || !hs.length) return;
    const canGhi = hs.filter((h) => !(s.gXong || {})[h.hang] && hangDuBai(s, h, ngay));
    if (!canGhi.length) return;
    if (s.gThuLuc && Date.now() - s.gThuLuc < Math.min(60, 5 * Math.pow(2, Math.max(0, (s.gLan || 1) - 1))) * 60000) return; // lỗi → 5, 10, 20, 40, 60 phút mới thử lại
    if ((s.gLan || 0) >= 6) { if (!s.gBao) { capNhatNgay(ngay, (x) => { x.gBao = Date.now(); }); await baoLark(`Cần chuyển tay cột G sang "Đã đăng" cho hàng ${canGhi.map((h) => h.hang).join(', ')} (bài đã đăng bình thường, script thử 6 lần chưa được)`); } return; }
    try {
      const v = await docSheet();
      const loiCot = kiemTenCot(v); if (loiCot) throw new Error(loiCot);
      for (const h of canGhi) {
        let hang = 0; let hienTai = '';
        for (let i = 1; i < v.length; i++) {
          const r = v[i] || [];
          if (ngayO(r[7]) === ngay && chuan(chuO(r[1])) === chuan(h.bai)) { hang = i + 1; hienTai = chuan(chuO(r[6])); break; }
        }
        if (!hang) { ghi(`Cột G: không còn thấy hàng của Bài 1 "${h.bai.slice(0, 30)}…" trên sheet`); continue; }
        if (hienTai !== 'Đã đăng') {
          if (!laTabChinh()) return;
          await ghiO('G' + hang, 'Đã đăng');
          const v2 = await docSheet({ moi: true }); // kiểm tra lại: đọc ô G vừa ghi
          if (chuan(chuO((v2[hang - 1] || [])[6])) !== 'Đã đăng') throw new Error(`đã ghi ô G${hang} nhưng đọc lại không thấy "Đã đăng"`);
          ghi(`Đủ 3 bài hàng ${hang} → đã chuyển ô G${hang} sang "Đã đăng" (đã đọc lại kiểm tra)`);
        }
        else ghi(`Đủ 3 bài hàng ${hang} — ô G${hang} đã là "Đã đăng" sẵn`);
        capNhatNgay(ngay, (x) => { x.gXong = x.gXong || {}; x.gXong[h.hang] = { luc: Date.now(), hang }; });
      }
    } catch (e) { capNhatNgay(ngay, (x) => { x.gThuLuc = Date.now(); x.gLan = (x.gLan || 0) + 1; }); ghi('Chưa chuyển được cột G sang "Đã đăng" (lần ' + ((trangThaiNgay(ngay).gLan) || 1) + '/6): ' + e.message); }
    veBang();
  }

  // Tên loại comment để hiển thị: Bài 2 = comment cột E, Bài 3 = comment cố định
  const tenCmt = (t) => (t.loai === 2 ? 'comment Bài 2' : 'comment cố định');
  // Comment dưới 1 bài kèm số comment là ảnh
  async function cmtChiTietApi(id) {
    const j = await goiFb(`/${id}/comments?fields=message,from{id},attachment{type}&limit=100&filter=stream`);
    let ds = j.data || [];
    // (4.5) chỉ tính comment của CHÍNH trang — ảnh/chữ khách gửi không được tính là "đủ"
    if (ds.some((c) => c.from && c.from.id)) ds = ds.filter((c) => c.from && String(c.from.id) === String(CAI_DAT.FB_PAGE_ID));
    return { msgs: ds.map((c) => c.message || ''), anh: ds.filter((c) => c.attachment && /photo|image/.test(c.attachment.type || '')).length };
  }

  // Chữ các comment dưới 1 bài (cần quyền đọc nội dung trên Trang)
  async function cmtCuaBaiApi(id) {
    const j = await goiFb(`/${id}/comments?fields=message&limit=100&filter=stream`);
    return (j.data || []).map((c) => c.message || '');
  }

  // Bài 2 (cột D) / Bài 3 (cột F) của hôm nay theo lần đọc sheet mới nhất
  const lichCu = (hs) => !!(hs && hs.length && !('a2' in hs[0])); // lịch sheet lưu từ bản cũ
  function hangHomNay() {
    const st = lay('sap_toi', null); const ngay = homNay();
    const d = st && !st.loiCot && st.ds ? st.ds.find((x) => x.ngay === ngay) : null;
    return d ? d.hangs : null;
  }
  function mucTieuB23(hs) {
    const out = [];
    for (const loai of [2, 3]) {
      for (const h of hs || []) {
        out.push({ k: loai + '|' + h.hang, loai, hang: h.hang, cot: loai === 2 ? 'D' : 'F', chiSo: loai === 2 ? 3 : 5, text: (loai === 2 ? h.bai2 : h.bai3) || '', cmt: loai === 2 ? (h.cmt2 || '') : (CAI_DAT.CMT_BAI3 || '') });
      }
    }
    return out;
  }

  async function timHangTheoCot(ngay, chiSo, text) {
    const v = await docSheet();
    for (let i = 1; i < v.length; i++) {
      const r = v[i] || [];
      if (ngayO(r[7]) === ngay && chuan(chuO(r[chiSo])) === chuan(text)) return i + 1;
    }
    throw new Error('không còn thấy hàng trên sheet');
  }
  async function gachBai23(ngay, t) {
    if (!CAI_DAT.GACH_NGANG) return false;
    try { const h = await timHangTheoCot(ngay, t.chiSo, t.text); await gachNgang(t.cot + h); ghi(`Đã gạch ngang ô ${t.cot}${h}`); return true; } catch (e) { ghi(`Chưa gạch được ô ${t.cot}${t.hang}: ${e.message}`); return false; }
  }

  // Dò bài trên trang: Bài 2/3 đã lên chưa, comment Bài 2 (cột E) / Bài 3 (cố định) đã có chưa, lấy link Bài 1 còn thiếu.
  // 10 phút/lần, 7h–23h; đủ hết thì thôi. Không cuộn trang (dùng Facebook API).
  async function doBaiTrang({ thuCong = false } = {}) {
    const ngay = homNay(); let s = trangThaiNgay(ngay);
    const m = phutTrongNgay(new Date());
    if (!laTabChinh()) return false;
    if (!thuCong) {
      if (dangBan || demNguocDen || lay('dang_do', null) || lay('soan_thu', null) || lay('b23_cho_tay', null)) return false;
      if (m < docGio(CAI_DAT.GIO_DO_TU) || m >= docGio(CAI_DAT.GIO_DO_DEN)) return false;
      if (s.doLuc && Date.now() - s.doLuc < (conBaiCuoi() ? 3 : CAI_DAT.DO_BAI_PHUT) * 60000) return false;
    }
    const canViec = (hs, x) => {
      const b23 = x.b23 || {};
      const ts = mucTieuB23(hs);
      return {
        canCmtB1: hs.map((h) => ({ h, k: ngay + '|' + bam(h.bai), b: x.bai[ngay + '|' + bam(h.bai)] })).filter((y) => y.h.cmt && y.b && y.b.id && (daXongTt(y.b) || y.b.tt === 'da_dang') && y.b.cmtTrangThai !== 'xac_nhan'),
        canTim: ts.filter((t) => t.text && (!b23[t.k] || (!b23[t.k].id && coApi()))),
        canTimB1: hs.map((h) => ({ h, k: ngay + '|' + bam(h.bai) })).filter((y) => y.h.bai && !(x.bai[y.k] && (daXongTt(x.bai[y.k]) || x.bai[y.k].tt === 'da_dang'))),
        canCmt: ts.filter((t) => t.cmt && b23[t.k] && b23[t.k].id && !b23[t.k].cmt),
        bai1ThieuLink: Object.entries(x.bai).filter(([, b]) => (coApi() ? !b.id : !b.link) && !b.matTrenApi && (daXongTt(b) || b.tt === 'da_dang'))
          .map(([k, b]) => ({ k, b, h: hs.find((h) => ngay + '|' + bam(h.bai) === k) })).filter((y) => y.h && y.h.bai),
      };
    };
    let hs = hangHomNay();
    if (!hs || lichCu(hs)) {
      if (!thuCong && s.docLichLuc && Date.now() - s.docLichLuc < 5 * 60000) return false; // sheet lỗi: 5 phút mới thử lại
      capNhatNgay(ngay, (x) => { x.docLichLuc = Date.now(); });
      await lamMoiSapToi().catch((e) => ghi('Đọc sheet lỗi: ' + e.message));
      hs = hangHomNay();
    }
    if (!hs) return false;
    s = trangThaiNgay(ngay);
    let viec = canViec(hs, s);
    if (!viec.canTim.length && !viec.canTimB1.length && !viec.canCmt.length && !viec.canCmtB1.length && !viec.bai1ThieuLink.length) return false;
    capNhatNgay(ngay, (x) => { x.doLuc = Date.now(); });

    let ds = null;
    if (coApi()) {
      try { ds = await baiTrenTrangApi(new Date(new Date().setHours(0, 0, 0, 0)).getTime()); } catch (e) {
        ghi('Dò bài qua Facebook API lỗi: ' + e.message);
        if (!trangThaiNgay(ngay).apiBao) {
          capNhatNgay(ngay, (x) => { x.apiBao = Date.now(); });
          await baoLark(`Không đọc được bài qua Facebook (${e.message}) — mã khoá có thể hết hiệu lực, cần đổi mã mới ("Đổi mã khoá" trên popup)`);
        }
      }
    }
    // Dự phòng khi không có API: chỉ xem các bài ĐANG HIỆN SẴN trên trang, không cuộn
    const trangDangHien = () => dungTrang() && document.visibilityState === 'visible';
    const daDung = new Set(Object.values(trangThaiNgay(ngay).b23 || {}).map((r) => r.id).filter(Boolean));
    const timTrenTrang = (text, ghiDung = true) => {
      if (ds) {
        const p = baiGiongNhat(ds, text, ghiDung ? daDung : null);
        if (p && ghiDung) daDung.add(p.id);
        return p ? { luc: p.luc, link: p.link, id: p.id, diem: p.diem, chinhXac: true } : null;
      }
      if (!trangDangHien()) return null;
      const x = timBai(text); return x ? { luc: Date.now(), link: linkBai(x.khung), id: '', chinhXac: false } : null;
    };

    if (!laTabChinh()) return false;
    s = trangThaiNgay(ngay); viec = canViec(hs, s);
    for (const t of viec.canTim) {
      const p = timTrenTrang(t.text);
      if (!p) continue;
      const cu = (s.b23 || {})[t.k];
      if (cu) { // đã ghi nhận rồi (đánh dấu tay / bản cũ chưa lưu ID) → chỉ bổ sung ID + link để xem bài và kiểm comment
        if (p.id) { capNhatNgay(ngay, (x) => { if (x.b23 && x.b23[t.k]) Object.assign(x.b23[t.k], { id: p.id, link: p.link || x.b23[t.k].link }); }); ghi(`Đã lấy được ID bài của Bài ${t.loai} (hàng ${t.hang})`); }
        continue;
      }
      capNhatNgay(ngay, (x) => { x.b23 = x.b23 || {}; x.b23[t.k] = { tt: 'xong', luc: p.luc, link: p.link, id: p.id, gan: !p.chinhXac, hang: t.hang }; });
      ghi(`Thấy Bài ${t.loai} (hàng ${t.hang}) trên trang, đăng lúc ${p.chinhXac ? '' : '~'}${gioStr(new Date(p.luc))}${p.diem ? ` (giống ${Math.round(p.diem * 100)}%)` : ''}`);
      const gach = await gachBai23(ngay, t);
      capNhatNgay(ngay, (x) => { if (x.b23 && x.b23[t.k]) x.b23[t.k].gach = gach; });
    }
    for (const y of viec.canTimB1) { // (5.6) Bài 1 do máy khác đăng (hoặc đăng tay) → nhận diện trên trang để ô B1 xanh ✓ và không báo thiếu
      const p = timTrenTrang(y.h.bai, false);
      if (!p || !(p.link || p.id)) {
        ghi(`${m >= docGio(CAI_DAT.GIO_DANG_DEN) + 30 ? 'Lỗi nhận diện' : 'Kiểm tra'} Bài 1 (hàng ${y.h.hang}): chưa thấy bài này trên trang — ${ds ? 'đã hỏi Facebook API, có ' + ds.length + ' bài hôm nay nhưng không bài nào khớp' : (coApi() ? 'API không trả về dữ liệu' : 'chưa cài mã khoá nên chỉ xem được các bài đang hiện trên màn hình' + (trangDangHien() ? '' : ' (tab đang ẩn/không ở trang chính)'))} | đầu bài: "${String(y.h.bai).slice(0, 50)}"`);
        if (!ds && m >= docGio(CAI_DAT.GIO_DANG_DEN) + 30) chupLoi('nhận diện Bài 1');
        continue;
      }
      capNhatNgay(ngay, (x) => {
        const cu = x.bai[y.k]; if (cu && (daXongTt(cu) || cu.tt === 'da_dang')) return;
        x.bai[y.k] = Object.assign({}, cu || {}, { tt: 'xong', luc: p.luc, hang: y.h.hang, link: p.link || '', id: p.id || '', soNhom: (cu && cu.soNhom) || 0, cmtTrangThai: 'cho', ghiChu: [], maySau: true });
        if (Object.values(x.bai).filter(daXongTt).length >= (x.biet_het || 1)) x.xong = true;
      });
      ghi(`Thấy Bài 1 (hàng ${y.h.hang}) trên trang, đăng lúc ${p.chinhXac ? '' : '~'}${gioStr(new Date(p.luc))}${p.diem ? ` (giống ${Math.round(p.diem * 100)}%)` : ''} → ghi nhận đã đăng`);
    }
    s = trangThaiNgay(ngay); viec = canViec(hs, s);
    for (const y of viec.bai1ThieuLink) {
      const p = timTrenTrang(y.h.bai, false);
      if (p && (p.link || p.id)) { capNhatNgay(ngay, (x) => { if (x.bai[y.k]) Object.assign(x.bai[y.k], { link: p.link || x.bai[y.k].link, id: p.id || x.bai[y.k].id }); }); ghi(`Kiểm tra: Bài 1 (hàng ${y.b.hang}) có trên trang${ds ? ' (Facebook API xác nhận)' : ''}`); }
      else if (ds && !p && Date.now() - (y.b.luc || 0) > 15 * 60000 && (y.b.luc || 0) >= new Date().setHours(0, 0, 0, 0)) {
        capNhatNgay(ngay, (x) => { if (x.bai[y.k]) x.bai[y.k].matTrenApi = Date.now(); });
        await baoLark(`Bài 1 (đăng lúc ${gioStr(new Date(y.b.luc))}) không thấy trên trang — có thể bị gỡ hoặc đăng lỗi, cần kiểm tra tay`, { batBuoc: true });
      }
    }

    // Xác nhận lại comment Bài 1 cho dữ liệu bản cũ hoặc kết quả từng chưa rõ; chỉ đọc.
    if (!laTabChinh()) return false;
    s = trangThaiNgay(ngay); viec = canViec(hs, s);
    for (const y of viec.canCmtB1) {
      if (!coApi()) break;
      try {
        const cs = await cmtCuaBaiApi(y.b.id);
        if (!laTabChinh()) return false;
        const co = cs.some((c) => khopCmt(c, y.h.cmt));
        capNhatNgay(ngay, (x) => {
          const b = x.bai[y.k]; if (!b) return;
          b.cmtTrangThai = co ? 'xac_nhan' : 'can_kiem';
          if (co) b.ghiChu = (b.ghiChu || []).filter((m) => !/comment/i.test(m) || /cảm xúc/.test(m));
        });
        if (co) ghi('C5. API xác nhận lại comment Bài 1 hàng ' + y.h.hang);
      } catch (e) { ghi('Chưa xác nhận lại được comment Bài 1: ' + e.message); }
    }

    // Comment của Bài 2 (cột E) / Bài 3 (đoạn chữ cố định) — đã có dưới bài chưa
    s = trangThaiNgay(ngay); viec = canViec(hs, s);
    for (const t of viec.canCmt) {
      const r = s.b23[t.k];
      let thay = null; let loiQuyen = ''; let anh = 0;
      if (coApi()) {
        try { const cs = await cmtChiTietApi(r.id); anh = cs.anh; thay = cs.msgs.some((c) => khopCmt(c, t.cmt)); capNhat('suc_khoe', { cmtOk: true, cmtLuc: Date.now(), cmtLoi: '' }); } catch (e) {
          loiQuyen = e.message; capNhat('suc_khoe', { cmtOk: false, cmtLuc: Date.now(), cmtLoi: e.message });
          if (!trangThaiNgay(ngay).cmtLoiGhi) { capNhatNgay(ngay, (x) => { x.cmtLoiGhi = Date.now(); }); ghi('Không đọc được comment qua Facebook API: ' + e.message); }
        }
      }
      if (!thay && (!coApi() || loiQuyen) && trangDangHien()) { // dự phòng: xem comment đang hiện dưới bài trên trang
        const x = timBai(t.text); if (x && khopCmt(x.khung.innerText, t.cmt)) thay = true;
      }
      if (!laTabChinh()) return false;
      if (!thay) continue;
      ghi(`Thấy ${tenCmt(t)} dưới Bài ${t.loai} (hàng ${t.hang})${t.loai === 3 && anh ? `, kèm ${anh} comment ảnh` : ''}`);
      const gach = t.loai === 2 ? await gachBai23(ngay, { cot: 'E', chiSo: 4, text: t.cmt, hang: t.hang }) : false;
      capNhatNgay(ngay, (x) => { if (x.b23 && x.b23[t.k]) x.b23[t.k].cmt = { luc: Date.now(), gach, anh }; });
    }
    veBang();
    return true;
  }

  // 11h30: còn Bài 2/3 chưa thấy trên trang (hoặc Bài 2 chưa có comment cột E) thì báo nhóm 1 lần
  async function nhacBai23() {
    const ngay = homNay();
    if (phutTrongNgay(new Date()) < docGio(CAI_DAT.GIO_NHAC_BAI23)) return;
    let s = trangThaiNgay(ngay);
    if (s.nhacB23) return;
    const hs = hangHomNay();
    if (!hs) return;
    capNhatNgay(ngay, (x) => { x.nhacB23 = Date.now(); });
    if (!s.doLuc || Date.now() - s.doLuc > 2 * 60000) await doBaiTrang({ thuCong: true });
    s = trangThaiNgay(ngay);
    if (!hs.length) { ghi(`${CAI_DAT.GIO_NHAC_BAI23}: hôm nay sheet không có hàng nào → không nhắc Bài 2/3`); return; }
    const b23 = s.b23 || {};
    const sk = lay('suc_khoe', {}) || {};
    const thieu = [];
    for (const t of mucTieuB23(hs)) {
      const ten = `Bài ${t.loai}${hs.length > 1 ? ` (hàng ${t.hang})` : ''}`;
      const r = b23[t.k];
      if (!r) thieu.push(t.text ? `${ten} chưa thấy trên trang${((s.loiB23 || {})[t.k] || {}).msg ? ' (script chưa đăng được: ' + s.loiB23[t.k].msg + ')' : ''}` : `${ten} thiếu nội dung trong sheet`);
      else if (t.cmt && r.id && !r.cmt && sk.cmtOk) thieu.push(`${ten} chưa thấy ${tenCmt(t)}`);
    }
    if (!thieu.length) { ghi(`${CAI_DAT.GIO_NHAC_BAI23}: Bài 2, Bài 3 đều đã lên trang`); return; }
    await baoLark(`Kiểm tra ${gioStr(new Date())}: ${thieu.join(', ')}. Nếu đã đăng thì bấm "Đánh dấu đã đăng" trên popup`);
  }

  // Đến giờ Bài 2 / Bài 3 mà chưa thấy trên trang → thông báo trên máy + nhắn nhóm (mỗi bài 1 lần/ngày)
  async function nhacGioBai23() {
    if (!dangTuDongBat()) return;
    const ngay = homNay(); const m = phutTrongNgay(new Date());
    const hs = hangHomNay(); if (!hs || !hs.length) return;
    for (const [loai, gio] of [[2, CAI_DAT.GIO_NHAC_BAI2], [3, CAI_DAT.GIO_NHAC_BAI3]]) {
      if (!gio || m < docGio(gio) || m >= docGio(CAI_DAT.GIO_NHAC_BAI23)) continue;
      const s = trangThaiNgay(ngay);
      if ((s.nhacGio || {})[loai]) continue;
      const ts = mucTieuB23(hs).filter((t) => t.loai === loai && t.text);
      if (!ts.length) continue;
      capNhatNgay(ngay, (x) => { x.nhacGio = x.nhacGio || {}; x.nhacGio[loai] = Date.now(); }); // nhận việc trước khi gọi API
      if (!s.doLuc || Date.now() - s.doLuc > 2 * 60000) await doBaiTrang({ thuCong: true }); // dò lại trước khi nhắc
      const s2 = capNhatNgay(ngay, (x) => { x.nhacGio = x.nhacGio || {}; x.nhacGio[loai] = Date.now(); });
      const chua = ts.filter((t) => !(s2.b23 || {})[t.k]);
      if (!chua.length) continue;
      thongBaoMay(`Đến giờ đăng Bài ${loai}`, `Chưa thấy Bài ${loai} trên trang Vòng Trầm Hương SMH (nội dung ô ${chua[0].cot}${chua[0].hang}).`);
      ghi(`Đến giờ đăng Bài ${loai} (${gio}) — chưa thấy Bài ${loai} trên trang (ô ${chua.map((t) => t.cot + t.hang).join(', ')}); sẽ gộp vào tin kiểm tra ${CAI_DAT.GIO_NHAC_BAI23}`);
    }
  }

  // Bấm "Xem" Bài 1 khi chưa có link: cuộn tới bài trên trang và nháy viền
  function cuonToiBai(text) {
    const x = text && timBai(text);
    if (!x) return false;
    x.khung.scrollIntoView({ behavior: 'smooth', block: 'center' });
    const cu = x.khung.style.outline;
    x.khung.style.outline = '4px solid #f0a800'; x.khung.style.outlineOffset = '4px';
    setTimeout(() => { x.khung.style.outline = cu; }, 4000);
    return true;
  }

  // 20h: 1 tin tổng kết trong ngày (gửi mỗi ngày, kể cả tuần đầu)
  function tomTatBai1(s) {
    const bai = Object.values(s.bai || {});
    if (bai.length) {
      return bai.map((b) => {
        const gc = (b.ghiChu || []).length;
        if (b.tt === 'co_san') return `Bài 1 hàng ${b.hang}: có sẵn trên trang (đăng tay?)`;
        if (b.tt === 'khong_ro') return `Bài 1 hàng ${b.hang}: ⚠ không rõ đã lên trang chưa`;
        return `Bài 1 hàng ${b.hang} ${gc ? '⚠' : '✓'} ${gioStr(new Date(b.luc))}${b.soNhom ? ` · ${b.soNhom} nhóm` : ''}${b.tt === 'xong' ? (b.cmtTrangThai === 'xac_nhan' ? ' · API xác nhận comment' : ' · comment cần kiểm tra') : ''}${gc ? ` · ${b.ghiChu.join('; ')}` : ''}`;
      }).join(' | ');
    }
    if (s.huy) return 'Bài 1: đã hủy';
    if (s.dung) return 'Bài 1: đã dừng, cần kiểm tra tay';
    if (s.daChot) return 'Bài 1: không đăng được' + (s.loi ? ` (${s.loi.msg})` : '');
    if (s.loi) return 'Bài 1: lỗi — ' + s.loi.msg;
    return 'Bài 1: chưa đăng';
  }
  function tomTatB23(s, hs) {
    const b23 = s.b23 || {};
    const ds = hs ? mucTieuB23(hs) : Object.keys(b23).map((k) => ({ k, loai: +k[0], hang: b23[k].hang, text: 'x' }));
    return ds.map((t) => {
      const r = b23[t.k];
      if (r) return `Bài ${t.loai} ✓ ${r.tt === 'tay' ? '(đánh dấu tay)' : (r.gan ? '~' : '') + gioStr(new Date(r.luc))}${t.cmt && r.id ? (r.cmt ? (t.loai === 2 ? ' (đã cmt E)' : ` (đã cmt cố định${r.cmt.anh ? ` + ${r.cmt.anh} ảnh` : ''})`) : ` (chưa thấy ${tenCmt(t)})`) : ''}`;
      return `Bài ${t.loai}: ${t.text ? 'chưa thấy trên trang' : `cột ${t.cot} trống`}`;
    }).join(' | ');
  }
  function tomTatNgay(s, hs) { const b = tomTatB23(s, hs); const g = Object.values(s.gXong || {}).map((x) => 'G' + x.hang).join(', '); return tomTatBai1(s) + (b ? ' | ' + b : '') + (g ? ` | Đã chuyển ${g} sang "Đã đăng"` : ''); }
  // (5.7.1) 1 tin/ngày vào nhóm Lark khi đã đăng đủ tất cả nội dung trong ngày (3 bài + video/manifest), kèm giờ + link từng bài
  // (5.8.1) máy Cao: chỉ còn 1 bài cuối chưa thấy (đã quá giờ) → dò 3 phút/lần để báo cáo ngày gửi ngay khi đủ bài
  function conBaiCuoi() {
    if (LA_GIAO) return false;
    try { const s = lay('ngay_' + homNay(), null); if (!s || s.bao8) return false; const m = phutTrongNgay(new Date()); const it = lichHomNay().items.filter((i) => i.tt !== 'huy'); const chua = it.filter((i) => !i.xong); return it.length > 1 && chua.length === 1 && m >= chua[0].gioDK; } catch (e) { return false; }
  }
  const NHAN_BAI_NGAY = { b1: 'Bài 1 twist', b2: 'Bài 2 twist + ảnh', b3: 'Bài 3 storytelling' };
  async function baoCaoNgay() {
    if (LA_GIAO || !laTabChinh()) return;
    const ngay = homNay(); const s = lay('ngay_' + ngay, null); if (!s || s.bao8) return;
    const it = lichHomNay().items.filter((i) => i.tt !== 'huy');
    if (!it.length || it.some((i) => !i.xong)) return;
    if (!s.du8) { capNhatNgay(ngay, (x) => { x.du8 = Date.now(); }); ghi(`Đã đủ ${it.length}/${it.length} nội dung hôm nay → chuẩn bị gửi báo cáo ngày`); }
    const thieu = it.filter((i) => !/^https?:/.test(i.link || ''));
    if (thieu.length && Date.now() - (trangThaiNgay(ngay).du8 || Date.now()) < 10 * 60000) return; // (5.8.1) thiếu link thì chờ tối đa 10 phút
    if (!trongGioNhan()) return;
    const d = new Date();
    const dong = it.slice().sort((a, b) => (a.luc || 0) - (b.luc || 0)).map((i) => {
      const hh = (String(i.ten).match(/ \(hàng \d+\)$/) || [''])[0];
      const ten = (NHAN_BAI_NGAY[i.loai] || String(i.ten).replace(/ \(hàng \d+\)$/, '')) + hh;
      return `${i.luc ? gioStr(new Date(i.luc)).replace(':', 'h') : '--h--'} ${ten}: ${/^https?:/.test(i.link || '') ? i.link : '(chưa lấy được link)'}`;
    });
    const ok = await baoLark(`\nBáo cáo ${d.getDate()}/${d.getMonth() + 1}/${d.getFullYear()}: đã đăng xong ${it.length} bài fb:\n${dong.join('\n')}`, { batBuoc: true, loai: 'ngay8' });
    if (ok) capNhatNgay(ngay, (x) => { x.bao8 = Date.now(); });
  }
  async function tongKet() {
    const ngay = homNay(); let s = trangThaiNgay(ngay);
    if (s.tongKet || phutTrongNgay(new Date()) < docGio(CAI_DAT.GIO_TONG_KET)) return;
    capNhatNgay(ngay, (x) => { x.tongKet = Date.now(); });
    await doBaiTrang({ thuCong: true }).catch(() => {}); // dò lần cuối cho số liệu mới nhất
    await capNhatCotG().catch(() => {});
    s = trangThaiNgay(ngay);
    const km = lay('kiem_' + ngayMai(), null);
    const mai = km ? (km.ok ? 'đủ' : 'thiếu — ' + (km.loi ? km.loi.msg : 'chưa đủ')) : 'chưa kiểm';
    await baoLark(tinTongKet(s, hangHomNay(), km, ngay));
  }
  // (4.6) tin tổng kết: mỗi bài 1 dòng; chỉ thêm dòng ⚠ khi có việc người phải làm (lỗi thả cảm xúc, số nhóm, API, cột G, thống kê quét… không đưa vào)
  function tinTongKet(s, hs, km, ngay) {
    const bai = [], canXuLy = [];
    const bai1 = Object.values(s.bai || {}); const nhieu1 = bai1.length > 1;
    if (bai1.length) {
      bai1.forEach((b) => {
        const ten = 'Bài 1' + (nhieu1 ? ` (hàng ${b.hang})` : '');
        if (b.tt === 'xong' || b.tt === 'da_dang' || b.tt === 'co_san') {
          bai.push(`✅ ${ten} — ${gioStr(new Date(b.luc))}${b.tt === 'co_san' ? ' (đăng tay)' : ''}`);
          if (b.tt !== 'co_san' && b.cmtTrangThai && b.cmtTrangThai !== 'xac_nhan') canXuLy.push(`${ten}: comment chưa xác nhận`);
        } else if (b.tt === 'khong_ro') bai.push(`⚠ ${ten} — chưa rõ`);
        else bai.push(`❌ ${ten} — chưa đăng`);
      });
    } else bai.push('❌ Bài 1 — ' + (s.huy ? 'đã hủy' : s.dung ? 'đã dừng' : s.daChot ? 'không đăng được' : s.loi ? 'lỗi' : 'chưa đăng'));
    const b23 = s.b23 || {};
    const ds = hs ? mucTieuB23(hs) : Object.keys(b23).map((k) => ({ k, loai: +k[0], hang: b23[k].hang, text: 'x', cmt: '' }));
    ds.forEach((t) => {
      const r = b23[t.k]; const ten = tenB23(t, hs);
      if (!r) { bai.push(`❌ ${ten} — ${t.text ? 'chưa đăng' : 'thiếu nội dung'}`); return; }
      if (r.tt === 'khong_ro') { bai.push(`⚠ ${ten} — chưa rõ`); return; }
      bai.push(`✅ ${ten} — ${r.tt === 'tay' ? 'đánh dấu tay' : gioStr(new Date(r.luc))}`);
      if (t.cmt && r.id && !r.cmt) canXuLy.push(`${ten}: chưa thấy comment`);
      else if (r.cmt && r.cmtCan && (r.cmt.anh || 0) < (r.cmtCan.anh || 0)) canXuLy.push(`${ten}: thiếu ảnh comment`);
    });
    const lich = s.lich || {};
    const nhom = (loai) => { const l = CAI_DAT.LICH_NGOAI.filter((x) => x.loai === loai); return { co: l.filter((x) => lich[x.k]).length, tong: l.length }; };
    const v = nhom('video'), m = nhom('manifest');
    const dem = (ten, x) => `${x.co < x.tong ? '❌ ' : ''}${ten} ${x.co}/${x.tong}`;
    const dong = [`${bai.join(' ')} ${dem('Video', v)} · ${dem('Manifest', m)}`];
    canXuLy.forEach((x) => dong.push('⚠ ' + x));
    dong.push(km ? (km.ok ? 'Sheet ngày mai: đủ' : '⚠ Sheet ngày mai: thiếu, cần bổ sung gấp') : 'Sheet ngày mai: chưa kiểm');
    return `\nTổng kết ${ngay.replace(/-/g, '/')} đăng bài fb kênh 1:\n` + dong.join('\n');
  }


  // ===== (5.0) Báo cáo tuần: trang Khanh Trầm Hương — 18:00 thứ Sáu, các bài trong 7 ngày qua =====
  const dangODuongKhanh = () => /nhangtramnuquangnam/i.test(location.pathname) || location.pathname.replace(/\/+$/, '') === '/100063806572484' || /[?&]id=100063806572484/.test(location.search);
  function moc0Khanh(now) {
    const d = new Date(now); const ph = docGio(CAI_DAT.KHANH_GIO);
    d.setDate(d.getDate() - ((d.getDay() - CAI_DAT.KHANH_THU + 7) % 7)); d.setHours(Math.floor(ph / 60), ph % 60, 0, 0);
    if (d.getTime() > now) d.setDate(d.getDate() - 7);
    return d.getTime();
  }
  // Giờ đăng → tuổi bài (ngày). Facebook ghi: "19 giờ trước", "Hôm qua lúc 10:30", "Thứ Ba lúc 09:00", "27 Tháng 9 lúc 10:00", "26 Tháng 9, 2025".
  // lenient = đang đọc đúng HÀNG ĐẦU BÀI (có thể chỉ ghi "19 giờ"); trả {tuoi, den} hoặc null
  function gioKhanh(txt, lenient) {
    const t = chuan(String(txt).replace(/(Facebook\s*)+/g, ' ')).slice(0, 400);
    const now = Date.now(); const ds = [];
    const cach = (d, h, m) => { const x = new Date(d); x.setHours(h == null ? 12 : +h, m == null ? 0 : +m, 0, 0); return Math.max(0, (now - x.getTime()) / 864e5); };
    let m = t.match(/(\d+)\s*(giây|phút|giờ|ngày|tuần|tháng|năm)\s*trước/i);
    if (!m && lenient) m = t.match(/(?:^|[\s·])(\d+)\s*(giây|phút|giờ|ngày|tuần)(?=\s|·|$)/i);
    if (m) { const n = +m[1], u = m[2].toLowerCase(); ds.push({ i: m.index, len: m[0].length, tuoi: u === 'giây' ? 0 : u === 'phút' ? n / 1440 : u === 'giờ' ? n / 24 : u === 'ngày' ? n : u === 'tuần' ? n * 7 : u === 'tháng' ? n * 30 : n * 365 }); }
    m = t.match(/vừa xong/i); if (m) ds.push({ i: m.index, len: m[0].length, tuoi: 0 });
    m = t.match(/hôm qua(?:\s*lúc\s*(\d{1,2}):(\d{2}))?/i); if (m) { const d = new Date(now); d.setDate(d.getDate() - 1); ds.push({ i: m.index, len: m[0].length, tuoi: cach(d, m[1], m[2]) }); }
    m = t.match(/(\d{1,2})\s*tháng\s*(\d{1,2})(?:\s*,\s*(\d{4}))?(?:\s*lúc\s*(\d{1,2}):(\d{2}))?/i);
    if (m) { const nam = m[3] ? +m[3] : new Date(now).getFullYear(); let x = new Date(nam, +m[2] - 1, +m[1]); if (!m[3] && x.getTime() > now + 864e5) x = new Date(nam - 1, +m[2] - 1, +m[1]); ds.push({ i: m.index, len: m[0].length, tuoi: cach(x, m[4], m[5]) }); }
    if (lenient) {
      m = t.match(/thứ\s*(hai|ba|tư|năm|sáu|bảy)(?:\s*lúc\s*(\d{1,2}):(\d{2}))?|chủ nhật(?:\s*lúc\s*(\d{1,2}):(\d{2}))?/i);
      if (m) { const mp = { hai: 1, ba: 2, 'tư': 3, 'năm': 4, 'sáu': 5, 'bảy': 6 }; const tg = m[1] ? mp[m[1].toLowerCase()] : 0; const d = new Date(now); let lui = (d.getDay() - tg + 7) % 7; if (lui === 0) lui = 7; d.setDate(d.getDate() - lui); ds.push({ i: m.index, len: m[0].length, tuoi: cach(d, m[2] || m[4], m[3] || m[5]) }); }
    }
    if (!ds.length) return null;
    ds.sort((x, y) => x.i - y.i); const g = ds[0];
    return g.i > 300 ? null : { tuoi: g.tuoi, den: g.i + g.len };
  }
  const KHANH_LINK_BAI = /\/posts\/|\/permalink\.php|\/reels?\/\d|\/videos\/\d|story_fbid=|\/watch\/?\?v=/;
  // làm sạch link: bỏ phần theo dõi; kieu 'bai' = link bài thật, 'anh' = link ảnh (dự phòng cho bài chỉ có ảnh)
  function sachLinkKhanh(h, kieu) {
    try {
      const u = new URL(h, location.href); if (!/(^|\.)facebook\.com$/.test(u.hostname)) return '';
      if (/comment_id=|reply_comment_id=/.test(u.search)) return '';
      const tp = u.pathname + u.search;
      const laAnh = /^\/photo\/?$|\/photo\.php|\/photos\//.test(u.pathname) && /fbid=|\/photos\/.+\/\d{6,}/.test(tp);
      const laBai = KHANH_LINK_BAI.test(tp) && !laAnh;
      if (kieu === 'bai' ? !laBai : !laAnh) return '';
      const giu = new URLSearchParams(); ['story_fbid', 'id', 'v', 'fbid'].forEach((k) => { if (u.searchParams.get(k)) giu.set(k, u.searchParams.get(k)); });
      return u.origin + u.pathname + (giu.toString() ? '?' + giu : '');
    } catch (e) { return ''; }
  }
  const gioTuNeoKhanh = (goc) => {
    const ds = [];
    for (const a of goc.querySelectorAll('a[href]')) { const sp = a.querySelector('[aria-labelledby]'); if (!sp) continue; const el = document.getElementById((sp.getAttribute('aria-labelledby') || '').split(/\s+/)[0]); if (el) ds.push(chuan(el.textContent)); if (ds.length >= 6) break; }
    return ds.join(' · ');
  };
  const idMenuKhanh = new WeakMap(); let demMenuKhanh = 0;
  // Đọc các bài đang có trên trang. Giờ đăng lấy ở HÀNG ĐẦU BÀI (cạnh nút ⋯), không lấy cả khung (khung bài đầu có thể lẫn phần đầu trang cá nhân).
  // Link bài: Facebook chỉ điền link thật vào chữ giờ đăng khi "chạm" (rê chuột/focus) → focus từng neo nhỏ ở hàng đầu bài; không được thì quét link trong bài; cuối cùng dùng link ảnh.
  async function docKhungKhanh(co) {
    const ds = []; const ten = chuan(CAI_DAT.KHANH_TEN);
    const sach = (s) => chuan(String(s).replace(/(Facebook\s*)+/g, ' '));
    for (const { khung, menu } of cacKhungBai()) {
      let hang = null, g = null;
      // hàng đầu bài = khung nhỏ (cao ≤ 200px) đầu tiên quanh nút ⋯ có chữ giờ đăng; Facebook giấu chữ giờ (nhất là ngày tháng cũ) trong phần tử aria-labelledby của neo giờ, innerText không có
      for (let p = menu.parentElement, i = 0; p && khung.contains(p) && i < 10; p = p.parentElement, i++) {
        if (p.getBoundingClientRect().height > 200) break;
        const lb = gioTuNeoKhanh(p); const x = gioKhanh((lb ? lb + ' · ' : '') + p.innerText, true); if (x) { hang = p; g = x; break; }
      }
      if (!g) continue; // chưa đọc được giờ (bài chưa vẽ xong) → bỏ qua, lượt sau đọc lại; KHÔNG đoán theo giờ của comment
      const tk = sach(khung.innerText), th = hang ? sach(hang.innerText) : ''; const ix = th ? tk.indexOf(th) : -1;
      const txt = (ix >= 0 ? tk.slice(ix + th.length) : tk.slice(g.den)).trim().slice(0, 70);
      if (!idMenuKhanh.has(menu)) idMenuKhanh.set(menu, ++demMenuKhanh);
      const key = txt.length >= 12 ? txt : (txt + '|m' + idMenuKhanh.get(menu));
      const cu = co && co.get(key);
      if (cu && cu.loai === 2) { ds.push({ key, tuoi: g.tuoi, link: cu.link, loai: 2 }); continue; }
      const neo = Array.from(khung.querySelectorAll('a[href]')); const trongHang = hang ? neo.filter((a) => hang.contains(a)) : [];
      const tim = (arr, kieu) => { for (const a of arr) { const l = sachLinkKhanh(a.href, kieu); if (l) return l; } return ''; };
      let link = tim(trongHang, 'bai'), loai = link ? 2 : 0;
      if (!link && hang) {
        const ung = trongHang.filter((a) => { const r = a.getBoundingClientRect(); return r.width >= 8 && r.width <= 170 && r.height >= 8 && r.height <= 30 && !chuan(a.textContent).includes(ten); });
        for (const a of ung.slice(0, 5)) { try { a.focus({ preventScroll: true }); } catch (e) { /* */ } await sleep(220); link = sachLinkKhanh(a.href, 'bai'); try { a.blur(); } catch (e) { /* */ } if (link) { loai = 2; break; } }
      }
      if (!link) { link = tim(neo, 'bai'); if (link) loai = 2; }
      if (!link) { link = tim(neo, 'anh'); if (link) loai = 1; }
      ds.push({ key, tuoi: g.tuoi, link, loai });
    }
    return ds;
  }
  // cuộn trang, gom các bài (Facebook làm trống bài ở xa nên phải gom dần lúc cuộn); dừng khi gặp bài cũ hơn 7 ngày, đủ số bài, hoặc hết thời gian
  async function docTrangKhanh() {
    const t0 = Date.now(); const gom = []; const co = new Map(); let khongTang = 0;
    const gop = async () => {
      let moi = 0;
      for (const p of await docKhungKhanh(co)) {
        const cu = co.get(p.key);
        if (!cu) { const it = { key: p.key, link: p.link, loai: p.loai, tuoi: p.tuoi }; co.set(p.key, it); gom.push(it); moi++; }
        else if (p.loai > cu.loai) { cu.link = p.link; cu.loai = p.loai; }
      }
      return moi;
    };
    while (Date.now() - t0 < 80000) {
      const moi = await gop();
      const cu7 = gom.filter((p) => p.tuoi >= 7).length;
      if (gom.length >= CAI_DAT.KHANH_TOI_DA_BAI || (cu7 >= 2 && gom.some((p) => p.tuoi < 7)) || cu7 >= 3) break;
      khongTang = moi === 0 ? khongTang + 1 : 0;
      if (khongTang >= 7) break;
      window.scrollBy(0, Math.round(window.innerHeight * 0.8)); await sleep(1300 + Math.floor(Math.random() * 900));
    }
    // bài trong tuần mà chưa có link bài thật (bị trống lúc cuộn / chưa chạm được giờ đăng) → về đầu trang, đi xuống lại và thử tiếp
    for (let r = 0; r < 2 && gom.some((p) => p.tuoi < 7 && p.loai < 2); r++) {
      window.scrollTo(0, 0); await sleep(1600);
      for (let k = 0; k < 14; k++) {
        await gop(); if (!gom.some((p) => p.tuoi < 7 && p.loai < 2)) break;
        window.scrollBy(0, Math.round(window.innerHeight * 0.7)); await sleep(1300 + Math.floor(Math.random() * 700));
      }
    }
    // cùng một bài đọc ra hai lần (Facebook vẽ bài chia sẻ 2 lần) → gộp theo link bài thật
    const thay = new Set(); const day = [];
    for (const p of gom.slice().sort((x, y) => x.tuoi - y.tuoi)) { const k = p.loai === 2 && p.link ? p.link.replace(/\/$/, '') : null; if (k && thay.has(k)) continue; if (k) thay.add(k); day.push(p); }
    return day;
  }
  const ngayThangKhanh = (d) => `${d.getDate()}/${d.getMonth() + 1}`;
  // tin: bài mới nhất là Bài 1
  function tinKhanh(tuan, now) {
    const dong = tuan.map((p, i) => `Bài ${i + 1}: ${p.link || '(chưa lấy được link)'}`);
    return `${ngayThangKhanh(new Date(now))} ${CAI_DAT.KHANH_TEN} 7 ngày qua đã lên ${tuan.length} bài` + (dong.length ? '\n' + dong.join('\n') : '');
  }
  function khanhDenHan() {
    const now = Date.now(); const t0 = moc0Khanh(now); const M = CAI_DAT.KHANH_MOC_GIO;
    const st = lay('khanh', null) || {}; const s = st.t0 === t0 ? st : { t0, slot: -1, xong: false };
    if (s.xong) return null;
    let cur = -1; M.forEach((h, i) => { if (t0 + h * 3600e3 <= now) cur = i; });
    if (cur < 0 || cur <= s.slot) return null;
    if (now > t0 + (M[M.length - 1] + 6) * 3600e3) { if (!s.boQua) { luu('khanh', Object.assign({}, s, { boQua: true })); ghi(`${CAI_DAT.KHANH_TEN}: tuần này không đọc được trang sau ${M.length} lần → bỏ qua, chờ thứ Sáu tuần sau`); } return null; }
    return { t0, cur, s };
  }
  const khanhBan = () => !laTabChinh() || lay('tam_dung', false) || lay('dang_do', null) || dangBan || dangQuet || demNguocDen || lay('quet_link', null) || lay('soan_thu', null) || lay('b23_cho_tay', null) || (lay('quet_dang', null) && Date.now() - lay('quet_dang', null).luc < 90000) || document.visibilityState !== 'visible' || hopDangDo() || hopSoanBai() || dangODuongSua();
  async function khanhTuan() {
    if (CAI_DAT.KHANH_BAT === false || lay('khanh_dang', null)) return false;
    const dh = khanhDenHan(); if (!dh) return false;
    if (khanhBan() || !trongGioNhan()) return false;
    luu('khanh', Object.assign({}, dh.s, { t0: dh.t0, slot: dh.cur, lan: (dh.s.lan || 0) + 1, luc: Date.now() }));
    luu('khanh_dang', { luc: Date.now(), t0: dh.t0, slot: dh.cur, slotTruoc: dh.s.slot, nav: 0 });
    ghi(`${CAI_DAT.KHANH_TEN}: đến giờ báo cáo tuần (lần ${(dh.s.lan || 0) + 1}/${CAI_DAT.KHANH_MOC_GIO.length}) → mở trang để đọc 7 ngày gần nhất`);
    await sleep(800); roiTrang(CAI_DAT.KHANH_URL); return true;
  }
  async function khanhThuNgay() { // nút "Kiểm thử ngay": chỉ đọc + hiển thị trong popup, KHÔNG gửi Lark
    if (khanhBan()) { ghi(`${CAI_DAT.KHANH_TEN}: tab đang bận việc khác nên chưa kiểm thử được — thử lại sau`); return; }
    luu('khanh_dang', { luc: Date.now(), thu: true, nav: 0, slot: -9, slotTruoc: -9 });
    ghi(`${CAI_DAT.KHANH_TEN}: kiểm thử (chỉ đọc và hiện trong popup, không gửi Lark)`);
    await sleep(500); roiTrang(CAI_DAT.KHANH_URL);
  }
  async function tiepKhanh() {
    const kd = lay('khanh_dang', null); if (!kd) return false;
    const huy = (lyDo, giuSlot) => { luu('khanh_dang', null); if (giuSlot && !kd.thu) { const s = lay('khanh', null) || {}; luu('khanh', Object.assign({}, s, { slot: kd.slotTruoc })); } ghi(`${CAI_DAT.KHANH_TEN}: ${lyDo}`); if (!dungTrang()) setTimeout(() => { if (!dangBan && !lay('dang_do', null)) veTrang(); }, 1500); };
    if (Date.now() - kd.luc > 12 * 60000) { huy('quá thời gian → chờ lần thử sau'); return true; }
    if (!laTabChinh()) return false;
    if (lay('dang_do', null) || dangBan || dangQuet) { huy('có việc đăng bài/quét đang chạy → nhường, thử lại sau', true); return false; }
    if (lay('tam_dung', false)) return false;
    if (!dangODuongKhanh()) {
      if ((kd.nav || 0) >= 2) { huy('không mở được trang → thử lại ở lần sau'); return true; }
      kd.nav = (kd.nav || 0) + 1; luu('khanh_dang', kd); await sleep(600); roiTrang(CAI_DAT.KHANH_URL); return true;
    }
    if (document.visibilityState !== 'visible') return true; // tab ẩn: Facebook không vẽ bài → chờ
    dangBan = true; giuKhoa(); let ds = null, loi = '';
    try { await cho(() => cacKhungBai().length > 0, 25000, 700); ds = await docTrangKhanh(); } catch (e) { loi = e.message; }
    finally { dangBan = false; giuKhoa(); }
    const now = Date.now();
    if (!ds || !ds.length) {
      kd.that = (kd.that || 0) + 1; luu('khanh_dang', kd);
      if (kd.that < 2) { ghi(`${CAI_DAT.KHANH_TEN}: chưa đọc được bài nào${loi ? ' (' + loi + ')' : ''} → tải lại trang đọc lần 2`); await sleep(1500); roiTrang(); return true; }
      huy('đọc trang lỗi 2 lần (không thấy bài nào) → thử lại ở lần sau');
      if (!kd.thu) luu('khanh_kq', Object.assign({}, lay('khanh_kq', {}) || {}, { loi: 'Lần đọc ' + gioStr(new Date(now)) + ' chưa được — script sẽ tự thử lại theo lịch', loiLuc: now }));
      return true;
    }
    const tuan = ds.filter((p) => p.tuoi < 7).sort((x, y) => x.tuoi - y.tuoi); // bài mới nhất = Bài 1
    const nd = tinKhanh(tuan, now);
    const nBai = tuan.filter((p) => p.loai === 2).length, nAnh = tuan.filter((p) => p.loai === 1).length, nThieu = tuan.length - nBai - nAnh;
    ghi(`${CAI_DAT.KHANH_TEN}: ${tuan.length} bài trong 7 ngày — link bài ${nBai}, chỉ có link ảnh ${nAnh}, chưa lấy được link ${nThieu}`);
    if (kd.thu) { luu('khanh_thu', { luc: now, nd }); luu('khanh_dang', null); ghi(`${CAI_DAT.KHANH_TEN}: kiểm thử xong — ${tuan.length} bài trong 7 ngày (xem tab "Khanh TH")`); setTimeout(veTrang, 2500); return true; }
    ghi(`${CAI_DAT.KHANH_TEN}: đọc được ${ds.length} bài, ${tuan.length} bài trong 7 ngày qua`);
    const ok = await baoLark('\n' + nd, { toiDa: 1, loai: 'khanh' });
    const hoan = !ok && !trongGioNhan(); // ngoài giờ nhắn: tin được để dành, đến giờ nhắn sẽ gửi
    if (ok || hoan) {
      const s = lay('khanh', null) || {}; luu('khanh', Object.assign({}, s, { t0: kd.t0, xong: true, xongLuc: now }));
      luu('khanh_kq', { luc: now, nd, n: tuan.length, gui: ok ? 'da_gui' : 'cho_gio_nhan' });
      luu('khanh_dang', null); setTimeout(veTrang, 2500);
    } else {
      luu('khanh_kq', Object.assign({}, lay('khanh_kq', {}) || {}, { loi: 'Đọc được nhưng chưa gửi được vào Lark lúc ' + gioStr(new Date(now)) + ' — script sẽ thử lại theo lịch', loiLuc: now }));
      huy('đọc xong nhưng gửi Lark chưa được → thử lại ở lần sau');
    }
    return true;
  }
  const linkHoaKhanh = (s) => esc(s).replace(/(https?:\/\/[^\s<]+)/g, '<a href="$1" target="_blank">$1</a>');
  function tabKhanh() {
    const kq = lay('khanh_kq', null), th = lay('khanh_thu', null), st = lay('khanh', null) || {}, kd = lay('khanh_dang', null);
    const now = Date.now(); const t0 = moc0Khanh(now); const M = CAI_DAT.KHANH_MOC_GIO;
    const dd = (t) => `${THU[new Date(t).getDay()]} ${ngayThangKhanh(new Date(t))} ${gioStr(new Date(t))}`;
    let tt;
    if (kd) tt = `<span class="chip cho" style="margin:0">Đang đọc trang${kd.thu ? ' (kiểm thử)' : ''}…</span>`;
    else if (st.t0 === t0 && st.xong) tt = `<span class="chip ok" style="margin:0">Tuần này đã xong</span> ${kq && kq.gui === 'cho_gio_nhan' ? 'tin để dành, đến giờ nhắn sẽ gửi' : 'đã gửi vào nhóm Lark'} lúc ${gioStr(new Date(st.xongLuc || (kq && kq.luc) || now))}`;
    else if (st.t0 === t0 && st.boQua) tt = '<span class="chip xam" style="margin:0">Tuần này bỏ qua</span> không đọc được sau mọi lần thử — chờ tuần sau';
    else if (st.t0 === t0 && (st.lan || 0) > 0) tt = `<span class="chip cho" style="margin:0">Đã thử ${st.lan}/${M.length} lần</span> chưa xong — script tự thử lại theo lịch (thứ Sáu đến 22:00, rồi thứ Bảy 07:50, 13:00, 19:00, 22:00)`;
    else tt = '<span class="chip xam" style="margin:0">Chờ đến giờ</span>';
    const tiep = (st.t0 === t0 && (st.xong || st.boQua)) || now >= t0 + (M[M.length - 1] + 6) * 3600e3 ? t0 + 7 * 86400e3 : null;
    let h = `<div class="acts mot"><button class="nut chinh" data-a="khanhthu" title="Mở trang và đọc ngay, chỉ hiện kết quả ở đây, không gửi Lark">🔎 Kiểm thử ngay (không gửi Lark)</button></div><div class="the-nd"><div class="nhan">Báo cáo tuần · ${esc(CAI_DAT.KHANH_TEN)}</div>
      <div class="mo" style="margin:4px 0 8px">Mỗi ${['Chủ nhật', 'thứ Hai', 'thứ Ba', 'thứ Tư', 'thứ Năm', 'thứ Sáu', 'thứ Bảy'][CAI_DAT.KHANH_THU]} ${CAI_DAT.KHANH_GIO}: script mở trang, đếm các bài trong 7 ngày qua và gửi vào nhóm Lark. ${tiep ? 'Lần tới: <b>' + dd(tiep) + '</b>.' : ''}</div>
      <div>${tt}</div>`;
    if (kq && kq.loi && !(st.t0 === t0 && st.xong)) h += `<div class="ghichu">⚠ ${esc(kq.loi)}</div>`;
    h += '</div>';
    const hien = (x, nhan) => x ? `<div class="the-nd"><div class="nhan">${nhan} · ${dd(x.luc)}</div><div style="white-space:pre-wrap;user-select:text;line-height:1.55;margin-top:6px">${linkHoaKhanh(x.nd)}</div></div>` : '';
    h += hien(kq, 'Tin gần nhất đã gửi vào Lark') || '<div class="the-nd"><div class="mo">Chưa có báo cáo nào được gửi.</div></div>';
    if (th && (!kq || th.luc > kq.luc)) h += hien(th, 'Kết quả kiểm thử (chưa gửi Lark)');
    return h;
  }

  // (4.6) báo cáo tuần: 19:00 thứ Bảy, chỉ số bài từng loại đã đăng trong tuần (Chủ nhật → thứ Bảy), mỗi loại 1 dòng
  async function baoCaoTuan() {
    const now = new Date(); const ngay = homNay();
    if (now.getDay() !== 6) return;
    const ph = phutTrongNgay(now); if (ph < docGio(CAI_DAT.GIO_BAO_CAO_TUAN) || ph >= docGio(CAI_DAT.GIO_NHAN_DEN)) return;
    const st = lay('bao_cao_tuan', null) || {};
    if (st.ngay === ngay && (st.xong || (st.lan || 0) >= 4 || Date.now() - (st.luc || 0) < 10 * 60000)) return; // đã gửi / thử 4 lần rồi / vừa thử chưa lâu
    luu('bao_cao_tuan', { ngay, lan: (st.ngay === ngay ? st.lan || 0 : 0) + 1, luc: Date.now(), xong: false });
    await doLichNgoai(true).catch(() => {}); // dò lần cuối cho số liệu mới nhất
    let b1 = 0, b2 = 0, b3 = 0, vd = 0, mf = 0;
    for (let i = 0; i < 7; i++) {
      const s = lay('ngay_' + ngayStr(congNgay(-i)), null); if (!s) continue;
      b1 += Object.values(s.bai || {}).filter((b) => b && (b.tt === 'xong' || b.tt === 'da_dang' || b.tt === 'co_san')).length;
      Object.keys(s.b23 || {}).forEach((k) => { const r = s.b23[k]; if (!r || r.tt === 'khong_ro') return; if (k[0] === '2') b2++; else if (k[0] === '3') b3++; });
      CAI_DAT.LICH_NGOAI.forEach((x) => { if ((s.lich || {})[x.k]) { if (x.loai === 'video') vd++; else mf++; } });
    }
    const dd = (d) => pad(d.getDate()) + '/' + pad(d.getMonth() + 1);
    const ok = await baoLark(`\nBáo cáo tuần ${dd(congNgay(-6))} – ${dd(now)} đăng bài fb kênh 1:\nBài 1: ${b1} · Bài 2: ${b2} · Bài 3: ${b3}\nVideo: ${vd} · Manifest: ${mf}`);
    if (ok) luu('bao_cao_tuan', { ngay, lan: 1, luc: Date.now(), xong: true });
    else ghi('Báo cáo tuần chưa gửi được — sẽ thử lại sau ~10 phút (tối đa 4 lần)');
  }

  // Soạn thử: điền đủ như thật rồi DỪNG trước nút Đăng
  async function soanThuLuong() {
    const yc = lay('soan_thu', null);
    if (!yc) return false;
    if (Date.now() - yc.luc > 5 * 60000) { luu('soan_thu', null); return false; }
    const ngay = homNay(); const s = trangThaiNgay(ngay);
    try {
      if (document.visibilityState !== 'visible') throw new Error('tab Facebook đang bị ẩn — cần để tab hiện trên màn hình');
      const v = await docSheet();
      const loiCot = kiemTenCot(v); if (loiCot) throw new Error(loiCot);
      const bai = hangCuaNgay(v, ngay).map((h) => Object.assign(h, { ngay, khoa: ngay + '|' + bam(h.bai) })).find((b) => !s.bai[b.khoa]);
      if (!bai) { luu('soan_thu', null); ghi('Soạn thử: hôm nay không còn bài nào chưa đăng'); return true; }
      if (!bai.bai) throw new Error(`hàng ${bai.hang} chưa có nội dung cột B`);
      if (!(await damBaoTuCach())) return true;
      if (!dungTrang()) { veTrang(); return true; }
      if (hopDangDo()) throw new Error('đang có hộp đăng bài mở dở — đóng lại rồi bấm Soạn thử lần nữa');
      luu('soan_thu', null);
      luu('tien_trinh', { hang: bai.hang, ngay, batDau: Date.now(), buoc: {}, soanThu: true });
      ghi(`Soạn thử hàng ${bai.hang}`);
      dangBan = true;
      await dangLenFacebook(bai, { soanThu: true });
    } catch (e) {
      luu('soan_thu', null); ghi('Soạn thử lỗi: ' + e.message);
    } finally { dangBan = false; }
    return true;
  }


  function yeuCauDangNgay() { const y = lay('dang_ngay', null); return y && Date.now() - y.luc < 10 * 60000 && (!y.ngay || y.ngay === homNay()) ? y : null; }

  async function nhacTabAn(ngay) {
    const s = trangThaiNgay(ngay);
    const bay = Date.now();
    if (phutTrongNgay(new Date()) < s.gio) return; // chưa tới giờ đăng → chờ, chưa nhắc
    const hs = hangHomNay();
    if (hs && (!hs.length || hs.every((h) => s.bai[ngay + '|' + bam(h.bai)]))) return; // hôm nay không có bài / đã đăng hết
    if ((!s.anMayLuc || bay - s.anMayLuc >= CAI_DAT.TAB_AN_NHAC_MAY_PHUT * 60000) && (s.anMaySo || 0) < 6) {
      capNhatNgay(ngay, (x) => { x.anMayLuc = bay; x.anMaySo = (x.anMaySo || 0) + 1; });
      thongBaoMay('Đến giờ đăng Bài 1 — cần mở tab Facebook', `Tab Facebook đang bị che/thu nhỏ nên chưa đăng được. Bấm vào đây (hoặc mở cửa sổ Facebook lên) là script đăng ngay.`);
    }
    if (!s.anLarkLuc || bay - s.anLarkLuc >= CAI_DAT.TAB_AN_NHAC_LARK_PHUT * 60000) {
      capNhatNgay(ngay, (x) => { x.anLarkLuc = bay; });
      await baoLark(`Đến giờ đăng Bài 1 nhưng tab Facebook đang bị che/thu nhỏ — cần mở Facebook lên màn hình, script sẽ đăng ngay`, { batBuoc: true });
    }
  }

  async function xuLyLoiDang(ngay, s, e) {
    const msg = e.message;
    ghi('Lỗi: ' + msg); chupLoi('Bài 1');
    await baoLoiTheoNhip(s, (x) => capNhatNgay(ngay, (y) => { y.loi = x.loi; }),
      { msg, text: `Chưa đăng được Bài 1: ${msg} — script tự thử lại mỗi ${CAI_DAT.THU_LAI_PHUT} phút` },
      `Nhắc lại: Bài 1 vẫn chưa đăng được: ${msg}`, CAI_DAT.BAO_LOI_SAU_PHUT * 60000);
    const x = capNhatNgay(ngay, (y) => { y.lanThu = Date.now(); y.loiLan = (y.loiLan || 0) + 1; });
    // (4.5) lỗi lặp lại → tải lại trang cho Facebook "sạch" trước lần thử sau (chưa bấm Đăng nên an toàn)
    if (x.loiLan % 2 === 0 && !lay('dang_do', null)) { ghi('Lỗi lặp lại → tải lại trang trước lần thử sau'); setTimeout(() => { if (!dangBan && !lay('dang_do', null)) roiTrang(); }, 3000); }
  }

  let lanGhiLark = 0;
  async function vongDang() {
    const yc = yeuCauDangNgay();
    const dangNgay = !!yc;
    if (!dangNgay && !dangTuDongBat()) { demNguocDen = 0; return; } // (5.3) đã tạm dừng đăng bài tự động trên máy này
    const m = phutTrongNgay(new Date());
    const ngay = homNay();
    const s = trangThaiNgay(ngay);
    if (!dangNgay && (s.huy || s.xong)) { demNguocDen = 0; return; }
    if (!dangNgay && s.dung && (m < docGio(CAI_DAT.GIO_CHOT) || s.daChot)) { demNguocDen = 0; return; } // (4.5) đã dừng: vẫn để mốc 12:00 báo lý do
    if (demNguocDen && Date.now() - demNguocDen > 5 * 60000) demNguocDen = 0; // đếm ngược cũ quá hạn → tính lại từ đầu

    // Giờ chót buổi sáng
    if (!dangNgay && m >= docGio(CAI_DAT.GIO_CHOT)) {
      demNguocDen = 0;
      const cai = lay('lan_dau_chay', 0);
      const caiSauGioChot = cai && ngayStr(new Date(cai)) === ngay && phutTrongNgay(new Date(cai)) >= docGio(CAI_DAT.GIO_CHOT);
      if (!s.daChot && caiSauGioChot) { capNhatNgay(ngay, (x) => { x.daChot = true; }); ghi('Mới cài sau ' + CAI_DAT.GIO_CHOT + ' — hôm nay không đăng, từ sáng mai chạy bình thường'); return; }
      if (!s.daChot) {
        const daDang = Object.values(s.bai).filter((b) => daXongTt(b) || b.tt === 'da_dang').length;
        const lyDo = s.loi ? s.loi.msg : s.dung && s.lyDoDung ? s.lyDoDung : (daDang ? `mới đăng ${daDang}/${s.biet_het || '?'} bài` : 'không rõ lý do (máy hoặc tab Facebook có thể đã không mở)');
        capNhatNgay(ngay, (x) => { x.daChot = true; });
        ghi('Quá giờ chót ' + CAI_DAT.GIO_CHOT);
        await baoLark(`Quá ${CAI_DAT.GIO_CHOT} chưa đăng được Bài 1: ${lyDo} — cần kiểm tra và đăng tay`, { batBuoc: true });
      }
      return;
    }

    const gioHen = lucPhut(s.gio);
    if (!dangNgay) {
      if (Date.now() >= gioHen - 5 * 60000 && Date.now() < gioHen - CAI_DAT.CHUAN_BI_TRUOC_PHUT * 60000 && document.visibilityState !== 'visible' && !s.anTruoc) {
        capNhatNgay(ngay, (x) => { x.anTruoc = Date.now(); });
        thongBaoMay('5 phút nữa đăng Bài 1', 'Tab Facebook đang bị che/thu nhỏ — mở cửa sổ Facebook lên màn hình để script đăng đúng giờ.');
      }
      if (Date.now() < gioHen - CAI_DAT.CHUAN_BI_TRUOC_PHUT * 60000) return;
      if (s.loi && s.lanThu && Date.now() - s.lanThu < CAI_DAT.THU_LAI_PHUT * 60000) return;
      if (s.choDen && Date.now() < s.choDen) return;
    }
    if (dangNgay && demNguocDen > Date.now()) demNguocDen = Date.now(); // bấm "Đăng ngay" lúc đang đếm ngược → đăng luôn
    if (demNguocDen && Date.now() < demNguocDen) return;

    // Tab bị che/ẩn thì Facebook đứng hình → không đăng được. Nhắc Cao (thông báo trên máy + Lark) rồi chờ;
    // tab vừa hiện lại là script chạy tiếp ngay (không cần chờ 15 giây)
    if (document.visibilityState !== 'visible') {
      demNguocDen = 0;
      await nhacTabAn(ngay);
      return;
    }

    let baiDang = null;
    try {
      // 1. đọc sheet (luôn đọc mới)
      const v = await docSheetChoDang(ngay);
      const loiCot = kiemTenCot(v); if (loiCot) throw new LoiMem(loiCot);
      const hs = hangCuaNgay(v, ngay);
      if (!hs.length) throw new LoiMem(`Không tìm thấy hàng nào có ngày ${ngay} ở cột H`);
      capNhatNgay(ngay, (x) => { x.biet_het = hs.length; });
      const baiList = hs.map((h) => Object.assign(h, { ngay, khoa: ngay + '|' + bam(h.bai) }));
      const conLaiDs = baiList.filter((b) => !s.bai[b.khoa]);
      if (!conLaiDs.length) {
        capNhatNgay(ngay, (x) => { x.xong = true; }); demNguocDen = 0; luu('dang_ngay', null);
        if (dangNgay) ghi(`Ngày ${ngay} không còn bài nào chưa đăng`);
        return;
      }
      const bai = conLaiDs[0]; baiDang = bai;
      hangSapDang = bai.hang;
      if (!bai.bai) throw new LoiMem(`Hàng ${bai.hang} chưa có nội dung cột B (Bài 1)`);

      // 2. đúng tư cách, đúng trang
      if ((hopDangDo() || hopSoanBai() || dangODuongSua()) && nguoiDangThaoTac()) return; // (4.5) người đang soạn/sửa bài trong tab này → chờ
      if (!(await damBaoTuCach())) return;
      if (!dungTrang()) { veTrang(); return; }
      if (hopDangDo() || hopSoanBai()) { // (4.5) hộp đăng mở dở → tự đóng (trả lời luôn hộp "Bỏ bài viết?"); không đóng được thì tải lại trang
        ghi('Có hộp đăng bài đang mở dở → đóng lại');
        if (!(await dongHopSoan())) { ghi('Không đóng được hộp đăng → tải lại trang'); roiTrang(); return; }
      }

      // 2b. dò bài trùng: nội dung cột B đã có trên trang (vd. đăng tay) thì không đăng lại
      if (!demNguocDen) {
        const coSan = await baiDaCoTrenTrang(bai.bai);
        if (coSan) { await danhDauCoSan(ngay, bai, coSan); return; }
      }

      // 3. giãn cách (bỏ qua khi bấm "Đăng ngay")
      if (!dangNgay && !demNguocDen) {
        const cuoi = Math.max(0, ...Object.values(s.bai).map((b) => b.luc || 0));
        if (cuoi && Date.now() - cuoi < CAI_DAT.CACH_BAI_TRUNG_NGAY_PHUT * 60000) {
          const den = cuoi + CAI_DAT.CACH_BAI_TRUNG_NGAY_PHUT * 60000; capNhatNgay(ngay, (x) => { x.choDen = den; });
          ghi(`Bài tiếp theo (hàng ${bai.hang}) chờ đến ${gioStr(new Date(den))}`);
          return;
        }
        const tuoi = await tuoiBaiMoiNhat();
        if (tuoi !== null && tuoi < CAI_DAT.CACH_BAI_KHAC_PHUT) {
          const den = Date.now() + (CAI_DAT.CACH_BAI_KHAC_PHUT - tuoi + 1) * 60000; capNhatNgay(ngay, (x) => { x.choDen = den; });
          ghi(`Bài gần nhất trên trang mới ${tuoi} phút → chờ đến ${gioStr(new Date(den))}`);
          return;
        }
      }

      // 4. đếm ngược
      if (!demNguocDen) {
        demNguocDen = dangNgay ? Date.now() : Math.max(gioHen, Date.now() + CAI_DAT.DEM_NGUOC_TOI_THIEU_GIAY * 1000);
        if (demNguocDen > Date.now()) {
          ghi(`Chuẩn bị đăng hàng ${bai.hang} lúc ${gioStr(new Date(demNguocDen))}`);
          veBang(); return;
        }
      }

      // 5. đăng — tab phải đang hiện trên màn hình
      if (document.visibilityState !== 'visible') {
        throw new LoiMem('Tab Facebook đang bị ẩn hoặc thu nhỏ nên Facebook không chạy — cần để tab này hiện trên màn hình');
      }
      // kiểm lại lần cuối: Cao vừa bấm Hủy / Tạm dừng, bài đã được ghi nhận, hoặc tab khác đang làm → không đăng
      {
        const sM = trangThaiNgay(ngay);
        if (lay('tam_dung', false) || (!dangNgay && (sM.huy || sM.dung || sM.xong)) || sM.bai[bai.khoa] || lay('dang_do', null) || !laTabChinh()) {
          demNguocDen = 0; luu('dang_ngay', null); ghi('Không đăng lượt này: trạng thái vừa thay đổi (Hủy/Tạm dừng/đã có bài/tab khác)'); return;
        }
      }
      dangBan = true; giuKhoa();
      demNguocDen = 0;
      luu('dang_ngay', null);
      luu('tien_trinh', { hang: bai.hang, ngay, batDau: Date.now(), buoc: {} });
      ghi(`Bắt đầu đăng hàng ${bai.hang}`);
      bai.soNhom = await dangLenFacebook(bai);
      const thay = await cho(() => timBai(bai.bai), 60000, 1000);
      if (!thay) { ghi('Chưa thấy bài trên trang → tải lại để kiểm tra'); roiTrang(CAI_DAT.URL_TRANG); return; }
      ghi('B10. Đã thấy bài trên trang');
      await sauKhiDang(ngay, trangThaiNgay(ngay), bai);
    } catch (e) {
      if (e instanceof LoiLark) { // Lark đang chặn và chưa có bản sheet lưu sẵn: chờ, không báo dồn (tin cổng Lark đã báo 1 lần/ngày)
        demNguocDen = 0;
        if (Date.now() - lanGhiLark > 10 * 60000) { lanGhiLark = Date.now(); ghi('Chưa đăng được Bài 1: ' + e.message + ' — chờ Lark hoạt động lại (hoặc đăng tay)'); }
        return;
      }
      demNguocDen = 0; luu('dang_ngay', null);
      const s2 = trangThaiNgay(ngay);
      if (e instanceof LoiTrung) { // (4.5) bài đã có trên trang ngay trước khi Đăng → đóng hộp, ghi nhận "có sẵn", không đăng trùng
        await dongHopSoan();
        if (baiDang) await danhDauCoSan(ngay, baiDang, e.p);
      } else if (e instanceof LoiDung) {
        const dd0 = lay('dang_do', null);
        if (dd0) { ghi('Đã bấm Đăng: giữ việc dở để xác minh kết quả; ' + e.message); return; }
        // (4.5) ẩn tab / tạm dừng / mất quyền giữa chừng: đóng hộp soạn, KHÔNG dừng cả ngày — lượt sau tự làm lại
        await dongHopSoan();
        ghi('Hoãn lượt đăng Bài 1: ' + e.message + ' — sẽ tự làm lại');
      } else if (e instanceof LoiCung) {
        const dd0 = lay('dang_do', null);
        if (dd0) { // (4.5) đã bấm Đăng mà chưa rõ kết quả → giữ việc dở, tải lại trang để kiểm tra (trang + API) rồi mới quyết định
          dd0.buoc = 'kiem_bai'; dd0.luc = Date.now(); dd0.khongRo = true; luu('dang_do', dd0);
          ghi(e.message);
          setTimeout(() => { roiTrang(CAI_DAT.URL_TRANG); }, 1500); return;
        }
        const dd1 = null; void dd1;
        ghi('Dừng: ' + e.message);
        await xuLyLoiDang(ngay, s2, e);
      } else if (lay('dang_do', null)) {
        ghi('Đã bắt đầu thao tác Đăng, giữ việc dở để xác minh: ' + e.message);
      } else {
        if (!(await dongHopSoan())) { ghi('Không đóng được hộp đăng bài → tải lại trang'); setTimeout(() => roiTrang(), 2500); }
        await xuLyLoiDang(ngay, s2, e);
      }
    } finally {
      dangBan = false; veBang();
    }
  }

  // =====================================================================
  //  1.14 — QUÉT 12h / 17h / 21h (và bấm tay "Quét ngay"):
  //   (1) video đăng trong 24h qua mà nhân sự quên → gắn thẻ "Sơn Mộc Hương" + cảm xúc ngẫu nhiên (bỏ video #Manifest)
  //   (2) bài và comment trong 48h qua chưa Thích/Yêu thích → thả ngẫu nhiên Thích hoặc Yêu thích
  //  Cần tab Facebook ĐANG HIỆN trên màn hình (tab bị che thì chờ tab hiện lại).
  // =====================================================================
  let dangQuet = false, buocQuet = '', moQuet = 0;
  const veQuet = (b) => { buocQuet = b; luu('quet_dang', { luc: Date.now(), buoc: b }); veBang(); };
  const nghiNgan = (a = 2500, b = 6000) => sleep(a + Math.floor(Math.random() * (b - a)));
  const dangODuongSua = () => /\/post\/edit/.test(location.pathname);
  const vidState = () => lay('quet_video112', {}) || {};
  function luuVid(id, o) {
    const m = vidState(); m[id] = Object.assign({}, m[id] || {}, o, { cap: Date.now() });
    const han = Date.now() - 5 * 864e5; for (const k of Object.keys(m)) if ((m[k].cap || 0) < han) delete m[k];
    luu('quet_video112', m);
  }

  let cheDoThu = false; // "Quét thử": chỉ liệt kê việc sẽ làm, KHÔNG bấm gì, KHÔNG ghi trạng thái
  const luuVid2 = (p, o) => { if (cheDoThu) return; luuVid(p.id, Object.assign({ gio: p.luc, link: p.link || '', ver: PHIEN_BAN }, o)); };
  const quetCfg = () => Object.assign({ video: true, thichBai: true, thichCmt: true, tuDong: true }, lay('quet_cfg', {}) || {});

  // Mỗi bài trên trang có đúng 1 nút ⋯ "Hành động đối với bài viết này" → leo lên đến khung chỉ chứa 1 bài
  function cacKhungBai() {
    const out = [];
    for (const b of document.querySelectorAll('[aria-label^="Hành động đối với bài viết này"][role="button"]')) {
      let p = b, best = null;
      for (let i = 0; i < 30 && p; i++) {
        p = p.parentElement; if (!p) break;
        if (p.querySelectorAll('[aria-label^="Hành động đối với bài viết này"][role="button"]').length > 1) break;
        best = p;
      }
      if (best) out.push({ khung: best, menu: b });
    }
    return out;
  }
  const khungKhop = (k, text) => { const kk = chuan(text).slice(0, 40); if (!kk) return false; if (chuan(k.khung.innerText).includes(kk)) return true; const k2 = khoaSo(text).slice(0, 35); return k2.length >= 12 && khoaSo(k.khung.innerText).includes(k2); };
  // (4.5) video: khớp theo số id trong link (/reel/123…) trước — chính xác hơn so chữ (nhiều bài mở đầu giống nhau)
  const idVideo = (p) => { const m = String((p && p.link) || '').match(/\/(?:reel|reels|videos)\/(\d{6,})/); return m ? m[1] : ''; };
  const khungKhopP = (k, p) => { const vid = idVideo(p); if (vid && k.khung.querySelector(`a[href*="${vid}"]`)) return true; return khungKhop(k, p.text); };
  // Đầu bài hiện "… đang cảm thấy X tại/cùng với Sơn Mộc Hương" = video đã có cả cảm xúc lẫn thẻ → khỏi mở màn hình sửa
  const dauBai = (k) => thuong(chuan(k.khung.innerText).replace(/(Facebook\s*)+/g, ' ')).slice(0, 300);
  const baiDaGan = (k) => { const t = dauBai(k); const cx = /đang[^a-zà-ỹ]{0,6}cảm thấy/.test(t); return { cx, the: new RegExp('cùng với[^.]{0,80}' + thuong(CAI_DAT.TAG_TEN)).test(t), du: cx && new RegExp('đang[^a-zà-ỹ]{0,6}cảm thấy[^.]{0,60}cùng với[^.]{0,80}' + thuong(CAI_DAT.TAG_TEN)).test(t) }; };
  // chỉ tính khung phát video / ảnh bìa video CỦA BÀI (không tính link nằm trong comment — comment Bài 1 có link reel)
  const ngoaiCmt = (k, e) => { const a = e.closest('[role="article"]'); return !a || !k.khung.contains(a) || a === k.khung; };
  const laVideoKhung = (k) => Array.from(k.khung.querySelectorAll('video')).some((v) => ngoaiCmt(k, v) && dangHien(v))
    || Array.from(k.khung.querySelectorAll('a[href*="/reel/"], a[href*="/videos/"], a[href*="/watch"]')).some((a) => ngoaiCmt(k, a) && !!a.querySelector('img, video') && dangHien(a));
  // Facebook API cho biết link bài: /reel/ /videos/ = video; /posts/ /photos/ = không phải; còn lại = chưa biết (null)
  const laVideoApi = (p) => { const l = String(p.link || ''); if (/\/(reel|reels|videos|watch)\b/i.test(l)) return true; if (/\/(posts|photos?|permalink)\b|story_fbid/i.test(l)) return false; return null; };
  // Đang ở trang khác (vd khung xem video /reel/ mở ra) → đóng khung / quay lại, KHÔNG tải lại trang
  async function khoiPhucTrang() {
    for (let lan = 0; lan < 3; lan++) {
      if (dangODuongSua()) await dongManHinhSua();
      if (dungTrang()) return true;
      const x = Array.from(document.querySelectorAll('[aria-label="Đóng"]')).filter(dangHien)[0];
      if (lan === 0 && x) x.click(); else history.back();
      await cho(() => dungTrang(), 4000, 300); await sleep(800);
    }
    return dungTrang();
  }
  async function cuonTimKhung(text, toiDa = 10, p = null) {
    for (let i = 0; i < toiDa; i++) {
      const k = cacKhungBai().find((x) => (p ? khungKhopP(x, p) : khungKhop(x, text)));
      if (k) return k;
      window.scrollBy(0, Math.round(window.innerHeight * 0.8)); await sleep(1500); kiemDung();
    }
    return null;
  }

  // ===== (5.7) giờ kiểm cố định =====
  const mocGanNhat = () => { const m = phutTrongNgay(new Date()); const ds = CAI_DAT.KHUNG_KIEM.map(docGio).filter((x) => x <= m); return ds.length ? lucPhut(ds[ds.length - 1]) : 0; };
  const daQuaMoc = (luc) => { const t = mocGanNhat(); return t > 0 && t > (luc || 0); };

  // ===== (5.7) nhân sự đang dùng trang → script KHÔNG tự chạy việc nào chạm vào trang (trừ khi bấm nút trên popup) =====
  let nguoiLuc = 0, nguoiPhim = 0;
  const trongPopup = (t) => !!(t && t.closest && t.closest('#smhfb,#smhfb-gan-w,#smhfb-gan-modal'));
  for (const ten of ['keydown', 'mousedown', 'wheel', 'touchstart']) {
    document.addEventListener(ten, (e) => { if (!e.isTrusted || trongPopup(e.target)) return; nguoiLuc = Date.now(); if (ten === 'keydown') nguoiPhim = nguoiLuc; }, { capture: true, passive: true });
  }
  function oDangGoDo() { // đang gõ dở bài viết / bình luận (con trỏ trong ô nhập có chữ, người vừa gõ phím trong 15 phút)
    const a = document.activeElement; if (!a || trongPopup(a) || Date.now() - nguoiPhim > 15 * 60000) return false;
    if (!(a.isContentEditable || a.tagName === 'TEXTAREA' || (a.tagName === 'INPUT' && /^(text|search|)$/.test(a.type || '')))) return false;
    return !!chuan(a.isContentEditable ? a.innerText : a.value);
  }
  const thuCongDangChay = () => lay('thu_cong_den', 0) > Date.now() || (() => { const q = lay('quet_ngay', null); return !!(q && Date.now() - q.luc < 10 * 60000); })(); // vừa bấm nút trên popup → làm ngay, không chờ
  function nhanSuDangDung() {
    if (thuCongDangChay()) return '';
    if (nguoiLuc && Date.now() - nguoiLuc < CAI_DAT.RANH_SAU_PHUT * 60000) return 'bạn đang thao tác trên trang';
    if (oDangGoDo()) return 'bạn đang gõ dở bài viết/bình luận';
    if (nguoiDangThaoTac()) return 'đang có hộp soạn bài do người mở';
    return '';
  }

  // ===== (5.7) thanh "đang làm gì" ngay dưới thanh tiêu đề: đèn nhấp nháy + đồng hồ + đếm ngược =====
  const HD_TEN = {
    dangdo: 'Đang làm tiếp việc dở', quet: 'Đang quét Thích & gắn thẻ video', khanh: 'Đang đọc trang ' + CAI_DAT.KHANH_TEN, soanthu: 'Đang soạn thử bài',
    tukiem: 'Đang tự kiểm hộp đăng bài', kiemsheet: 'Đang kiểm tra sheet ngày mai', tongket: 'Đang gửi tin tổng kết', baocao: 'Đang làm báo cáo tuần',
    dang1: 'Đang đăng Bài 1', dangb23: 'Đang đăng Bài 2/3', dobai: 'Đang dò bài trên trang', lichngoai: 'Đang kiểm tra video/manifest',
    taianh: 'Đang tải sẵn ảnh', tincuoi: 'Đang gửi tin đăng xong', giao: 'Đang kiểm tra Máy Giao', cmtlich: 'Đang comment video/manifest',
    rasoat: 'Đang kiểm tra comment', cotg: 'Đang cập nhật trạng thái trên sheet', lammoi: 'Đang đọc Lark sheet', yeucau: 'Đang làm việc bạn vừa bấm',
    linkbai: 'Đang gửi link bài', bao8: 'Đang gửi báo cáo ngày vào nhóm Lark', dongsua: 'Đang đóng màn chỉnh sửa bị kẹt', soanmf: 'Đang soạn thử manifest', soanvideo: 'Đang soạn thử video',
  };
  // thời gian dự kiến (giây) — đo từ nhật ký thực tế; sau mỗi lần chạy script tự học lại cho sát
  const HD_DK = { soanmf: 30, soanvideo: 60, dangdo: 50, quet: 200, khanh: 70, soanthu: 90, tukiem: 25, kiemsheet: 6, tongket: 4, baocao: 4, dang1: 120, dangb23: 150, dobai: 4, lichngoai: 4, taianh: 20, tincuoi: 4, giao: 8, cmtlich: 60, rasoat: 25, cotg: 5, lammoi: 5, yeucau: 20, linkbai: 4, dongsua: 6 };
  const HD_QUAN_TRONG = new Set(['bao8', 'dangdo', 'khanh', 'soanthu', 'tukiem', 'kiemsheet', 'dang1', 'dangb23', 'cmtlich', 'rasoat', 'yeucau', 'giao', 'tongket', 'baocao']);
  const hdDuKien = (key) => { const h = (lay('hd_tg', {}) || {})[key]; return Math.round(h || (HD_DK[key] || 20) * 1000); };
  const hdHoc = (key, ms) => { if (ms < 500 || ms > 30 * 60000) return; const h = lay('hd_tg', {}) || {}; h[key] = h[key] ? Math.round(h[key] * 0.6 + ms * 0.4) : ms; luu('hd_tg', h); };
  const tenDangDo = (dd) => (dd ? `Đang ${dd.buoc === 'kiem_bai' ? 'kiểm tra bài vừa đăng' : 'comment'} ${dd.ten || (dd.loai >= 2 ? 'Bài ' + dd.loai : 'Bài 1')}` : HD_TEN.dangdo);
  let hdChay = null; // việc tab này đang chạy
  async function theoDoi(key, fn, ten) {
    const hd0 = lay('hoat_dong', null);
    const tiep = !!(hd0 && hd0.key === key && Date.now() - (hd0.cap || 0) < 4 * 60000); // việc đang làm dở từ trước khi trang tải lại
    const rec = { key, ten: ten || HD_TEN[key] || 'Đang chạy', bd: tiep ? hd0.bd : Date.now(), dk: hdDuKien(key), chi: tiep ? hd0.chi : '', cuoi: tiep ? hd0.cuoi : '', soDong: tiep ? (hd0.soDong || 0) : 0, cap: Date.now(), hien: tiep };
    hdChay = rec;
    if (tiep) luu('hoat_dong', rec);
    const hen = setTimeout(() => { if (hdChay === rec && !rec.hien) { rec.hien = true; luu('hoat_dong', rec); veBang(); } }, 700); // việc nhanh (< 0,7 giây) thì không hiện cho đỡ nháy
    let kq;
    try { kq = await fn(); return kq; } finally {
      clearTimeout(hen);
      if (hdChay === rec) hdChay = null;
      const conDo = kq === true && ((key === 'dangdo' && lay('dang_do', null)) || (key === 'quet' && lay('quet_link', null)) || (key === 'khanh' && lay('khanh_dang', null)));
      if (conDo) { if (rec.hien) luu('hoat_dong', Object.assign(rec, { cap: Date.now() })); }
      else {
        if (rec.hien) { hdHoc(key, Date.now() - rec.bd); const h = lay('hoat_dong', null); if (h && h.bd === rec.bd) luu('hoat_dong', null); }
        if (rec.soDong && key !== 'quet' && (rec.hien || HD_QUAN_TRONG.has(key))) {
          luu('hd_ket', { key, ten: rec.ten, chu: rec.cuoi, luc: Date.now(), tg: Date.now() - rec.bd, mau: /Lỗi|lỗi|chưa được|không được|chưa gửi|thất bại/.test(rec.cuoi) ? 'vang' : 'ok', dong: false });
        }
        if (rec.hien || rec.soDong) veBang();
      }
    }
  }
  // việc chạm vào trang: chỉ chạy khi nhân sự không dùng trang (hoặc vừa bấm nút trên popup)
  async function chayRanh(key, fn, ten) {
    const ly = nhanSuDangDung();
    if (ly) { choNguoi(ly); return false; }
    return theoDoi(key, fn, typeof ten === 'function' ? ten() : ten);
  }
  // có việc đang chờ chạy không (để hiện "đang chờ bạn dùng xong trang")
  function viecDangCho() {
    const dd = lay('dang_do', null); if (dd) return tenDangDo(dd).replace(/^Đang /, '');
    if (lay('quet_link', null) || (quetCfg().tuDong && mocQuetDenHan())) return 'quét Thích & gắn thẻ video';
    try { const s = lay('ngay_' + homNay(), null); const rs = s && s.rs; if (rs && rs.gio && rs.lan < rs.gio.length && phutTrongNgay(new Date()) >= rs.gio[rs.lan]) return 'kiểm tra comment'; } catch (e) { /* */ }
    if (dangTuDongBat()) { const mm = phutTrongNgay(new Date()); const it = lichHomNay().items.find((i) => !i.ngoai && !i.xong && i.tt !== 'huy' && !i.loi && mm >= i.gioDK && mm - i.gioDK < 120); if (it) return 'đăng ' + it.ten; }
    return '';
  }
  let choNguoiGhi = 0;
  function choNguoi(ly) {
    const viec = viecDangCho();
    if (!viec) { if (lay('cho_nguoi', null)) luu('cho_nguoi', null); return; }
    const c = lay('cho_nguoi', null);
    if (!c || c.viec !== viec) luu('cho_nguoi', { viec, ly, luc: Date.now() });
    if (Date.now() - choNguoiGhi > 10 * 60000) { choNguoiGhi = Date.now(); ghi(`Đang chờ: ${ly} → tạm chưa ${viec}, sẽ tự làm khi trang rảnh ${CAI_DAT.RANH_SAU_PHUT} phút`); }
  }
  const hdHien = () => { const h = lay('hoat_dong', null); return h && Date.now() - (h.cap || 0) < 4 * 60000 ? h : null; };
  const dongHo = (ms) => { const g = Math.max(0, Math.round(ms / 1000)); return Math.floor(g / 60) + ':' + pad(g % 60); };
  function gioHd(bd, dk) {
    const da = Date.now() - bd; const con = dk - da;
    return `⏱ ${dongHo(da)}<small>${con >= 0 ? 'còn khoảng ' + dongHo(con) : 'lâu hơn dự kiến ' + dongHo(-con)}</small>`;
  }
  const boTab = (m) => String(m || '').replace(/\s*\[tab [^\]]+\]\s*$/, '');
  function thanhHoatDong() {
    const hd = hdHien();
    if (hd) {
      const pt = Math.min(100, Math.round((Date.now() - hd.bd) / Math.max(1, hd.dk) * 100));
      const dungQ = hd.key === 'quet' ? '<button class="phu-nut do" data-a="dungquet">⏹ Dừng</button>' : '';
      return `<div class="hdg chay"><span class="hd-den"></span><div class="hd-noi"><div class="hd-ten">${esc(hd.ten)}<span class="hd-cham"></span></div>${hd.chi ? `<div class="hd-chi">${esc(boTab(hd.chi))}</div>` : ''}</div><div class="hd-gio" data-hdbd="${hd.bd}" data-hddk="${hd.dk}">${gioHd(hd.bd, hd.dk)}</div>${dungQ}<div class="hd-tien"><i style="width:${pt}%"></i></div></div>`;
    }
    const c = lay('cho_nguoi', null);
    if (c && Date.now() - c.luc < 6 * 3600e3 && nhanSuDangDung()) return `<div class="hdg cho"><span class="hd-den cho"></span><div class="hd-noi"><div class="hd-ten">Đang chờ bạn dùng xong trang</div><div class="hd-chi">${esc(c.ly)} → script tạm chưa ${esc(c.viec)}, sẽ tự làm khi trang rảnh ${CAI_DAT.RANH_SAU_PHUT} phút</div></div></div>`;
    const tbq = lay('quet_thongbao', null); const k = lay('hd_ket', null);
    const kHien = k && !k.dong && Date.now() - k.luc < (HD_QUAN_TRONG.has(k.key) ? 30 : 3) * 60000;
    const qHien = tbq && !tbq.dong && Date.now() - tbq.luc < 45 * 60000;
    if (kHien && (!qHien || k.luc > tbq.luc)) {
      const bieu = k.mau === 'ok' ? '✅' : '⚠️';
      return `<div class="tb-quet ${k.mau}"><span>${bieu} <b>Xong: ${esc(ganLamHd(k.ten.replace(/^Đang /, '')))} lúc ${gioStr(new Date(k.luc))}</b> <span class="mo">(mất ${dongHo(k.tg)})</span> — ${esc(boTab(k.chu))}</span><button class="phu-nut" data-a="donghd">Đã xem ✕</button></div>`;
    }
    return thongBaoQuetHtml();
  }
  const ganLamHd = (t) => t.charAt(0).toLowerCase() + t.slice(1);

  // ---- màn hình "Chỉnh sửa thước phim" ----
  const hopSua = () => hopThoai((d) => /^Chỉnh sửa/.test(chuan(d.innerText)) && nutTheoChu(d, 'Lưu'));
  // (4.5) hộp soạn bài / màn chỉnh sửa đang mở mà KHÔNG phải script mở → có thể nhân viên đang thao tác tay:
  // script chờ, không đóng ngang. Để nguyên ≥ 10 phút không thay đổi gì → coi là bỏ quên, cho script đóng để làm tiếp.
  function nguoiDangThaoTac() {
    const sua = dangODuongSua();
    const el = sua ? hopSua() : (hopSoanBai() || hopDangDo());
    if (!sua && !el) { window.__smhNguoi = null; return false; }
    if (sua ? lay('quet_dang_sua', 0) : window.__smhMoHop) return false; // script tự mở → script tự đóng được
    const chu = location.pathname + '|' + (el ? chuan(el.innerText).slice(0, 500) : '');
    const w = window.__smhNguoi; const bg = Date.now();
    if (!w) { window.__smhNguoi = { luc: bg, chu }; ghi((sua ? 'Đang có màn chỉnh sửa bài' : 'Đang có hộp soạn bài') + ' do người mở (không phải script) — có thể nhân viên đang thao tác → script chờ, không đóng ngang'); return true; }
    if (w.chu !== chu) { w.chu = chu; w.luc = bg; w.boQuen = false; return true; }
    if (w.boQuen) return false;
    if (bg - w.luc >= 10 * 60000) { w.boQuen = true; ghi((sua ? 'Màn chỉnh sửa bài' : 'Hộp soạn bài') + ' để nguyên hơn 10 phút không thay đổi → coi như bỏ quên, script đóng lại để làm tiếp'); return false; }
    return true;
  }
  function chipsSua(d) {
    const bs = Array.from(d.querySelectorAll('[role="button"]')).filter((b) => chuan(b.innerText) && !/^(Đóng|Quay lại|Close)$/i.test(b.getAttribute('aria-label') || '')); // bỏ nút Đóng / Quay lại
    // (4.5) ô cảm xúc nhận theo chữ: "Cảm xúc/hoạt động" (chưa có) hoặc "Đang …" (đã có cảm xúc/hoạt động)
    const camXuc = bs.find((b) => /^(Cảm xúc|Đang cảm thấy)/i.test(chuan(b.innerText))) || bs.slice(1).find((b) => /^Đang\s(?!ở(\s|$))/i.test(chuan(b.innerText))) || bs.slice(2, 7).find((b) => { const t = chuan(b.innerText); return t.length <= 40 && !/^(Cộng tác viên|Thêm file khác|Chỉnh sửa|Mọi người|Lưu|Hủy|Nhận |Thêm )/i.test(t) && !(CAI_DAT.TAG_TEN && thuong(t).includes(thuong(CAI_DAT.TAG_TEN))); }) || null; // (4.8) Facebook đã có cảm xúc thì ô chỉ hiện đúng tên cảm xúc (vd "tuyệt vời"), không có chữ "Đang"
    return { the: bs[0] || null, viTri: bs[1] || null, camXuc, chu: bs.slice(0, 6).map((b) => chuan(b.innerText)) };
  }
  const daGanThe = (c) => !!c.the && thuong(chuan(c.the.innerText)).includes(thuong(CAI_DAT.TAG_TEN));
  const chuaCamXuc = (c) => !!c.camXuc && /^cảm xúc/i.test(chuan(c.camXuc.innerText)); // ô còn là "Cảm xúc/hoạt động" mới cần chọn

  async function dongManHinhSua() {
    for (let lan = 0; lan < 3 && dangODuongSua(); lan++) {
      dongBangCamXuc();
      const x = Array.from(document.querySelectorAll('[aria-label="Đóng"]')).filter(dangHien).sort((a, b) => a.getBoundingClientRect().x - b.getBoundingClientRect().x)[0];
      if (x && lan < 2) { if (lan) { try { ganBam(x); } catch (e) { x.click(); } } else x.click(); }
      else history.back(); // (4.5) lần 3 (hoặc không thấy nút Đóng): quay lại trang trước
      const hoi = await cho(() => hopThoai((d) => d.innerText.startsWith('Rời khỏi trang')), 3000);
      if (hoi) { const bo = nutTheoChu(hoi, 'Rời khỏi'); if (bo) { if (lan) { try { ganBam(bo); } catch (e) { bo.click(); } } else bo.click(); } }
      await cho(() => !dangODuongSua(), 8000);
    }
    if (!dangODuongSua()) luu('quet_dang_sua', 0);
    return !dangODuongSua();
  }
  // bảng chọn cảm xúc còn mở → đóng (Escape / nút Quay lại / Đóng trong bảng)
  function dongBangCamXuc() {
    const lb = document.querySelector('ul[role="listbox"]'); if (!lb) return;
    const hop = lb.closest('[role="dialog"]');
    const nut = hop && Array.from(hop.querySelectorAll('[aria-label="Quay lại"], [aria-label="Đóng"]')).find(dangHien);
    if (nut) nut.click(); else document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', code: 'Escape', keyCode: 27, which: 27, bubbles: true }));
  }
  async function moManHinhSua(k, text) {
    kiemDung();
    const MUC_SUA = /^Chỉnh sửa (bài viết|thước phim|video|reel)/i;
    let muc = null;
    for (let lanMo = 0; lanMo < 3 && !muc; lanMo++) {
      if (lanMo) { // lần 2: Facebook có thể đã vẽ lại bài → tìm lại khung, đóng menu mở dở, cuộn giữa màn hình rồi bấm lại
        if (document.querySelector('[role="menu"]')) { k.menu.click(); await sleep(700); }
        await sleep(1500); kiemDung();
      }
      if (text && !k.menu.isConnected) { const k2 = cacKhungBai().find((x) => khungKhop(x, text)); if (k2) k = k2; }
      k.khung.scrollIntoView({ block: 'center' }); await sleep(700);
      if (lanMo) { try { ganBam(k.menu); } catch (e) { k.menu.click(); } } else k.menu.click(); // lần 2-3: chuỗi sự kiện chuột đầy đủ như người bấm
      muc = await cho(() => Array.from(document.querySelectorAll('[role="menu"] [role="menuitem"]')).find((x) => MUC_SUA.test(chuan(x.innerText))) || (!dungTrang() && !dangODuongSua() ? 'roi' : null), lanMo ? 6000 : 5000);
      if (muc === 'roi') throw new Error('Facebook chuyển sang trang khác sau khi bấm ⋯');
    }
    if (!muc) {
      const ds = Array.from(document.querySelectorAll('[role="menu"] [role="menuitem"]')).map((x) => chuan(x.innerText).slice(0, 30)).slice(0, 8).join(' | ');
      if (document.querySelector('[role="menu"]')) k.menu.click();
      throw new Error('không thấy mục sửa trong menu ⋯ của bài' + (ds ? ' (menu có: ' + ds + ')' : ' (menu không mở, đã thử 3 lần)'));
    }
    luu('quet_dang_sua', Date.now());
    muc.click();
    let d = await cho(() => hopSua() || (!dungTrang() && !dangODuongSua() ? 'roi' : null), 10000, 400);
    if (!d && muc.isConnected) { ghi('Quét: bấm "Chỉnh sửa" lần 1 chưa ăn → bấm lại'); try { ganBam(muc); } catch (e) { muc.click(); } d = await cho(() => hopSua() || (!dungTrang() && !dangODuongSua() ? 'roi' : null), 10000, 400); }
    if (d === 'roi') throw new Error('Facebook chuyển sang trang khác khi mở màn hình chỉnh sửa');
    if (!d) throw new Error('không mở được màn hình chỉnh sửa');
    await cho(() => { const h = hopSua(); return h && (chipsSua(h).camXuc || !/^Chỉnh sửa thước phim/.test(chuan(h.innerText))); }, 8000, 400); // chờ các nút hiện đủ
    await sleep(800);
    return hopSua() || d;
  }
  async function ganTheSuaMot(lan) {
    kiemDung();
    const bam2 = (el) => { if (lan) { try { ganBam(el); } catch (e) { el.click(); } } else el.click(); };
    const c = chipsSua(hopSua()); if (!c.the) throw new Error('không thấy nút gắn thẻ (ô "Mọi người")');
    bam2(c.the);
    const inp = await cho(() => document.querySelector('input[aria-label="Tìm kiếm bạn bè"]'), 8000);
    if (!inp) throw new Error('không mở được bảng "Gắn thẻ người khác"');
    inp.focus(); document.execCommand('insertText', false, CAI_DAT.TAG_TEN);
    if (!inp.value) { // execCommand không ăn → đặt giá trị kiểu React
      try { Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value').set.call(inp, CAI_DAT.TAG_TEN); inp.dispatchEvent(new Event('input', { bubbles: true })); } catch (e) { /* */ }
    }
    const hang = await cho(() => Array.from(document.querySelectorAll('li[role="option"]')).find((li) => dangHien(li) && /Trang\s*·/.test(chuan(li.innerText)) && chuan(li.innerText).startsWith(chuan(CAI_DAT.TAG_TEN))), 9000, 400);
    if (!hang) throw new Error(`không thấy Trang "${CAI_DAT.TAG_TEN}" trong kết quả tìm`);
    kiemDung(); bam2(hang.querySelector('[role="none"]') || hang);
    const duoc = await cho(() => Array.from(document.querySelectorAll('span,div')).some((e) => !e.childElementCount && chuan(e.textContent) === 'Được gắn thẻ' && dangHien(e)), 6000);
    if (!duoc) throw new Error('đã bấm chọn nhưng chưa thấy mục "Được gắn thẻ"');
    const xong = Array.from(document.querySelectorAll('[role="button"]')).filter((b) => chuan(b.innerText) === 'Xong' && dangHien(b)).pop();
    if (!xong) throw new Error('không thấy nút "Xong"');
    bam2(xong);
    if (!(await cho(() => !document.querySelector('input[aria-label="Tìm kiếm bạn bè"]'), 6000))) { const x2 = Array.from(document.querySelectorAll('[role="button"]')).filter((b) => chuan(b.innerText) === 'Xong' && dangHien(b)).pop(); if (x2) { try { ganBam(x2); } catch (e) { x2.click(); } } }
    // (4.5) xác nhận có chờ: Facebook vẽ lại màn sửa mất vài giây
    if (!(await cho(() => { const d2 = hopSua(); return d2 && daGanThe(chipsSua(d2)); }, 8000, 400))) throw new Error('đã chọn thẻ nhưng màn hình chỉnh sửa chưa hiện thẻ');
  }
  async function ganTheSua() {
    try { await ganTheSuaMot(0); }
    catch (e1) {
      if (e1 instanceof LoiDung || !hopSua()) throw e1;
      ghi('Gắn thẻ lần 1 chưa được (' + e1.message + ') → thử lại bằng cách bấm khác');
      if (document.querySelector('input[aria-label="Tìm kiếm bạn bè"]')) { // bảng gắn thẻ còn mở → đóng
        const x = Array.from(document.querySelectorAll('[role="button"]')).filter((b) => /^(Xong|Quay lại)$/.test(chuan(b.innerText || b.getAttribute('aria-label'))) && dangHien(b)).pop() || Array.from(document.querySelectorAll('[aria-label="Quay lại"]')).find(dangHien);
        if (x) x.click(); else document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', code: 'Escape', keyCode: 27, which: 27, bubbles: true }));
        await sleep(1200);
      }
      const d = hopSua(); if (d && daGanThe(chipsSua(d))) return; // lần 1 thật ra đã được
      await ganTheSuaMot(1);
    }
  }
  async function camXucSua(lan = 0) {
    kiemDung();
    const bam2 = (el) => { if (lan) { try { ganBam(el); } catch (e) { el.click(); } } else el.click(); };
    const c = chipsSua(hopSua()); if (!c.camXuc) throw new Error('không thấy nút cảm xúc');
    bam2(c.camXuc);
    const lb = await cho(() => { const u = document.querySelector('ul[role="listbox"]'); return u && u.querySelectorAll('li[role="option"]').length > 10 ? u : null; }, 9000, 400);
    if (!lb) throw new Error('không mở được bảng cảm xúc');
    const lis = Array.from(lb.querySelectorAll('li[role="option"]'));
    const coSan = CAI_DAT.CAM_XUC_CHON.filter((n) => lis.some((x) => chuan(x.innerText) === n)); // (4.5) chỉ chọn cảm xúc thật sự có trong bảng
    const ds = coSan.length ? coSan : ['hạnh phúc'];
    const nhan0 = ds[Math.floor(Math.random() * ds.length)];
    const li = lis.find((x) => chuan(x.innerText) === nhan0) || lis[0];
    const nhan = chuan(li.innerText);
    kiemDung(); li.scrollIntoView({ block: 'center' }); await sleep(400);
    bam2(li.querySelector('[role="button"]') || li);
    if (!(await cho(() => !document.querySelector('ul[role="listbox"]'), 6000))) { // bấm chưa ăn → bấm lại kiểu khác
      const li2 = Array.from(document.querySelectorAll('ul[role="listbox"] li[role="option"]')).find((x) => chuan(x.innerText) === nhan);
      if (li2) { try { ganBam(li2.querySelector('[role="button"]') || li2); } catch (e) { li2.click(); } }
      await cho(() => !document.querySelector('ul[role="listbox"]'), 6000);
    }
    // xác nhận: ô cảm xúc chuyển từ "Cảm xúc/hoạt động" sang "Đang cảm thấy …"
    const daChon = () => { const d2 = hopSua(); if (!d2) return null; const c2 = chipsSua(d2); const t = c2.camXuc ? chuan(c2.camXuc.innerText) : ''; return t && !/^cảm xúc/i.test(t) ? t : null; };
    const t = await cho(daChon, 8000, 400);
    if (!t) { dongBangCamXuc(); const d3 = hopSua(); const c3 = d3 && chipsSua(d3); throw new Error(`đã chọn "${nhan}" nhưng màn hình chỉnh sửa chưa hiện (ô hiện đang là: ${(c3 && c3.chu ? c3.chu.join(' | ') : '?').slice(0, 120)})`); }
    if (!thuong(t).includes(thuong(nhan))) ghi(`Cảm xúc trên màn sửa: "${t.slice(0, 40)}" (đã chọn "${nhan}") → coi như đã gắn`);
    return t;
  }

  // Mở màn chỉnh sửa của 1 video → thiếu thẻ/cảm xúc thì bổ sung rồi Lưu; đủ rồi thì đóng lại không lưu
  async function xuLyVideo(k, p, kq) {
    if (baiDaGan(k).du) { luuVid2(p, { tt: 'xong' }); kq.daDu++; ghi('Quét: video ' + gioStr(new Date(p.luc)) + ' đã có cảm xúc + thẻ ngay trên bài → bỏ qua, không mở màn hình sửa'); return 'du'; }
    if (cheDoThu) { kq.thuMo.push(gioStr(new Date(p.luc))); return 'thu'; }
    const d = await moManHinhSua(k, p.text);
    let daLuu = false;
    try {
      if (!/^Chỉnh sửa thước phim/.test(chuan(d.innerText))) { luuVid2(p, { tt: 'khac' }); ghi('Quét: bài ' + gioStr(new Date(p.luc)) + ' không phải thước phim (màn "' + chuan(d.innerText).slice(0, 30) + '") → bỏ qua'); return 'khac'; }
      const c = chipsSua(d);
      if (!c.the || (!c.camXuc && !baiDaGan(k).cx)) throw new Error('không nhận ra các nút thẻ/cảm xúc: ' + c.chu.join(' | '));
      const canThe = !daGanThe(c), canCx = chuaCamXuc(c);
      if (!canThe && !canCx) { luuVid2(p, { tt: 'xong' }); kq.daDu++; return 'du'; }
      let nhan = '';
      if (canThe) await ganTheSua();
      if (canCx) {
        try { nhan = await camXucSua(0); }
        catch (e1) { if (e1 instanceof LoiDung || !hopSua()) throw e1; ghi('Cảm xúc lần 1 chưa xác nhận (' + e1.message + ') → thử lại lần 2 (bấm kiểu khác)'); dongBangCamXuc(); await sleep(1500); nhan = await camXucSua(1); }
      }
      kiemDung();
      // (4.5) nút Lưu có thể mờ vài giây sau khi sửa → chờ; bấm chưa ăn thì bấm lại kiểu khác
      const nutLuu = await cho(() => { const n = nutTheoChu(hopSua() || d, 'Lưu'); return n && n.getAttribute('aria-disabled') !== 'true' ? n : null; }, 8000, 400);
      if (!nutLuu) throw new Error('nút "Lưu" không bấm được');
      nutLuu.click();
      let dong = await cho(() => !hopSua(), 12000, 500);
      if (!dong) { const n2 = nutTheoChu(hopSua() || d, 'Lưu'); if (n2) { ghi('Quét: bấm Lưu lần 1 chưa ăn → bấm lại'); try { ganBam(n2); } catch (e) { n2.click(); } } dong = await cho(() => !hopSua(), 20000, 500); }
      if (!dong) throw new Error('đã bấm Lưu nhưng màn hình chỉnh sửa không đóng');
      daLuu = true;
      await cho(() => !dangODuongSua(), 10000); await sleep(1500);
      luuVid2(p, { tt: 'luu', luc: Date.now(), the: canThe, camXuc: nhan, xacNhan: false });
      kq.gan++;
      ghi(`Quét: đã lưu ${canThe ? 'thẻ "' + CAI_DAT.TAG_TEN + '"' : ''}${canThe && canCx ? ' + ' : ''}${canCx ? 'cảm xúc "' + nhan + '"' : ''} cho video đăng lúc ${gioStr(new Date(p.luc))}`);
      return 'da_sua';
    } finally { if (!daLuu) await dongManHinhSua(); }
  }

  // Facebook vẽ lại bài sau khi bấm → khung cũ mất khỏi trang thì tìm lại đúng bài theo nội dung
  function laiKhung(k) {
    if (k.khung.isConnected) return k.khung;
    const m = k.text && cacKhungBai().find((x) => khungKhop(x, k.text));
    if (m) { k.khung = m.khung; k.menu = m.menu; }
    return k.khung;
  }
  // Thích / Yêu thích cho 1 bài và các comment chưa có cảm xúc. Trả về số vấn đề gặp (để biết có cần thử lại qua trang riêng của bài)
  async function thichKhung(k, kq, p) {
    kiemDung();
    const cfg = quetCfg();
    if (p) k.text = p.text;
    laiKhung(k).scrollIntoView({ block: 'center' }); await sleep(700);
    const MAXN = CAI_DAT.QUET_THICH_TOI_DA;
    const nb = (n) => nutCuaBai(laiKhung(k), n);
    let vanDe = 0;
    if (cfg.thichBai) await cho(() => nb(DA_CO_CAM_XUC) || nb('Thích') || nb('Bày tỏ cảm xúc'), 5000, 400); // (4.5) bài đang tải → chờ thanh nút hiện
    if (cfg.thichBai && !nb(DA_CO_CAM_XUC) && kq.dem < MAXN) {
      if (nb('Thích') || nb('Bày tỏ cảm xúc')) {
        if (cheDoThu) kq.thuBai++;
        else {
          let loi = '';
          for (let lan = 0; lan < 2; lan++) {
            try { const r0 = await thaCamXuc(nb, 'Bài', laiKhung(k)); if (r0 !== 'co_san') { kq.thichBai++; kq.dem++; } loi = ''; break; }
            catch (e) { if (e instanceof LoiDung) throw e; loi = e.message; await sleep(1500); if (nb(DA_CO_CAM_XUC)) { kq.thichBai++; kq.dem++; loi = ''; break; } }
          }
          if (loi) { kq.loiThich.push('bài: ' + loi); vanDe++; }
          await nghiNgan();
        }
      } else { kq.thieuNut++; vanDe++; }
    }
    if (!cfg.thichCmt) return vanDe;
    if (!cheDoThu) for (let i = 0; i < 2; i++) { // mở thêm comment (chỉ bấm nút "Xem thêm … bình luận", không bấm link)
      const them = Array.from(laiKhung(k).querySelectorAll('[role="button"]')).find((b) => /^Xem thêm (\d+ )?bình luận|^Xem \d+ bình luận/.test(chuan(b.innerText)) && dangHien(b));
      if (!them) break;
      them.click(); await sleep(1800);
    }
    const layDs = () => Array.from(laiKhung(k).querySelectorAll('[role="article"]')).filter((a) => a !== laiKhung(k) && !a.contains(k.menu) && laCmtArt(a));
    if (p && p.soCmt != null && p.soCmt > layDs().length && !cheDoThu) { vanDe++; kq.cmtAn = (kq.cmtAn || 0) + 1; } // (4.5) comment bị ẩn sau "N bình luận" → mở trang riêng của bài
    for (const art0 of layDs()) {
      if (kq.dem >= MAXN) break;
      const r = await thichMotCmt(taoTimArt(art0, layDs));
      if (r.tt === 'ok') { kq.thichCmt++; kq.dem++; await nghiNgan(); }
      else if (r.tt === 'thu') kq.thuCmt++;
      else if (r.tt === 'khong_nut') { kq.thieuNutCmt++; vanDe++; if (kq.chiTietThieu.length < 3) kq.chiTietThieu.push(r.chiTiet); }
      else if (r.tt === 'loi') { kq.loiThich.push('comment: ' + r.loi); vanDe++; await nghiNgan(); }
    }
    return vanDe;
  }

  const tomTatKq = (kq) => `gắn thẻ/cảm xúc ${kq.gan} video${kq.daDu ? ` (${kq.daDu} đã đủ sẵn)` : ''} · thích ${kq.thichBai} bài + ${kq.thichCmt} comment${kq.loi.length || kq.loiThich.length ? ` · lỗi ${kq.loi.length + kq.loiThich.length}` : ''}`;
  const tomTatThu = (kq) => `sẽ mở kiểm tra ${kq.thuMo.length} video${kq.thuMo.length ? ' (' + kq.thuMo.join(', ') + ')' : ''}${kq.daDu ? ` · ${kq.daDu} video đã đủ sẵn` : ''} · sẽ thả cảm xúc cho ${kq.thuBai} bài + ${kq.thuCmt} comment`;
  function tomTatQuet(s) {
    const t = s.quetTong; if (!t) return '';
    return `Quét: gắn thẻ/cảm xúc ${t.gan} video, thích ${t.thichBai} bài + ${t.thichCmt} comment (${t.lan} lần quét)`;
  }

  // Chạy 1 lượt quét. slot = '12:00' | '17:00' | '21:00' | 'tay'
  async function quetChay(slot) {
    const ngay = homNay();
    const kq = { thuMo: [], thuBai: 0, thuCmt: 0, gan: 0, daDu: 0, thichBai: 0, thichCmt: 0, khongThay: 0, thieuNut: 0, thieuNutCmt: 0, dem: 0, loi: [], loiThich: [], loiLark: [], canLink: [], chiTietThieu: [], dsLink: [], lyDo: '', conLai: 0, daBaoNhom: 0 };
    let tamHoan = false;
    const han = Date.now() + 10 * 60000;
    const thu = slot === 'thu'; cheDoThu = thu; const cfg = quetCfg();
    moQuet = Date.now(); dangQuet = true; dangBan = true; giuKhoa(); veQuet('bắt đầu');
    if (!thu) capNhatNgay(ngay, (x) => { x.quetLan = x.quetLan || {}; x.quetLan[slot] = (x.quetLan[slot] || 0) + 1; x.quetLuc = Date.now(); });
    ghi(`Quét ${slot === 'tay' ? '(Cao bấm tay)' : slot === 'thu' ? '(quét thử — không bấm gì)' : 'mốc ' + slot}: bắt đầu`);
    let xong = false;
    try {
      kiemDung();
      // (4.5) dọn trước: đang kẹt ở màn sửa / trang khác → đóng, quay về trang Page rồi mới kiểm tư cách
      if (dangODuongSua()) await dongManHinhSua();
      if (!dungTrang()) await khoiPhucTrang();
      if (!(await damBaoTuCach())) { if (!thu && slot === 'tay' && Date.now() - lay('tc_reload_luc', 0) < 60000) { luu('quet_ngay', { luc: Date.now(), thu: false }); ghi('Quét tay sẽ tự chạy lại sau khi trang tải xong'); } kq.lyDo = 'chưa xác nhận được đang dùng tư cách Page (xem tab Hệ thống)'; if (!thu) datThongBaoQuet(kq, slot, thu, false, false, false); return; }
      if (dangODuongSua() || !dungTrang()) { if (!(await khoiPhucTrang())) { kq.lyDo = 'không quay về được trang Page'; if (!thu) datThongBaoQuet(kq, slot, thu, false, false, false); veTrang(); return; } }
      if ((hopDangDo() || hopSoanBai()) && !lay('dang_do', null)) { ghi('Quét: có hộp đăng bài mở dở → đóng lại'); await dongHopSoan(); }
      if (hopDangDo()) throw new Error('đang có hộp đăng bài mở dở — để lần sau');
      veQuet('đọc danh sách bài');
      const ds = await baiTrenTrangApi(Date.now() - Math.max(CAI_DAT.QUET_VIDEO_GIO, CAI_DAT.QUET_THICH_GIO) * 3600e3);
      // (4.5) số comment của từng bài (1 lần gọi cho cả danh sách) → biết bài nào còn comment bị ẩn
      try { const ids = ds.filter((p) => Date.now() - p.luc <= CAI_DAT.QUET_THICH_GIO * 3600e3).slice(0, 40).map((p) => p.id); if (ids.length && !thu) { const j = await goiFb('/?ids=' + ids.join(',') + '&fields=comments.limit(0).summary(true)'); for (const p of ds) { const x = j && j[p.id]; if (x && x.comments && x.comments.summary) p.soCmt = x.comments.summary.total_count; } } } catch (e) { /* không có cũng được */ }
      const cua = (g) => (p) => Date.now() - p.luc <= g * 3600e3 && chuan(p.text);
      const daChin = (p) => Date.now() - p.luc > 10 * 60000; // video vừa đăng < 10 phút: Facebook còn xử lý, chưa có mục sửa → để lượt sau

      // ---- (1) video: gắn thẻ + cảm xúc ----
      const st0 = vidState();
      if (cfg.video && !thu) ds.filter(cua(CAI_DAT.QUET_VIDEO_GIO)).filter((p) => thuong(p.text).includes(CAI_DAT.QUET_LOAI_TRU) && laVideoApi(p) !== false && !(st0[p.id] && st0[p.id].tt === 'manifest')).forEach((p) => luuVid2(p, { tt: 'manifest' }));
      const ungVien = !cfg.video ? [] : ds.filter(cua(CAI_DAT.QUET_VIDEO_GIO)).filter(daChin).filter((p) => !thuong(p.text).includes(CAI_DAT.QUET_LOAI_TRU)).filter((p) => {
        const s1 = st0[p.id];
        if (!s1) return true;
        if (s1.tt === 'loi') return !s1.gio || ((s1.lan || 0) < 3 && Date.now() - (s1.cap || 0) > 30 * 60000) || (s1.ver !== PHIEN_BAN && Date.now() - (s1.cap || 0) > 5 * 60000);
        if (s1.tt === 'luu' && s1.xacNhan === false) return Date.now() - (s1.cap || 0) > 20 * 60000 && (s1.kiemLai || 0) < 2; // (4.5) đã Lưu nhưng chưa thấy trên bài → kiểm lại
        if (s1.tt === 'khong_video' && laVideoApi(p) === true && (s1.lan || 0) < 2) return true; // (4.5) API nói là video mà lần trước trang chưa hiện video → thử lại
        return false;
      });
      let moRa = 0, suaRa = 0;
      for (let vi = 0; vi < ungVien.length; vi++) {
        const p = ungVien[vi];
        if (Date.now() > han || moRa >= 8 || suaRa >= CAI_DAT.QUET_VIDEO_TOI_DA) break;
        kiemDung();
        if (dangODuongSua() || !dungTrang()) { if (!(await khoiPhucTrang())) { kq.lyDo = 'không quay về được trang Page'; if (!thu) datThongBaoQuet(kq, slot, thu, false, false, false); veTrang(); return; } }
        veQuet(`video ${vi + 1}/${ungVien.length} · tìm bài ${gioStr(new Date(p.luc))}`);
        if (laVideoApi(p) === false) { luuVid2(p, { tt: 'khong_video' }); continue; } // bài chữ/ảnh: không cuộn tìm, không mở menu
        window.scrollTo(0, 0); await sleep(900);
        const k = await cuonTimKhung(p.text, 10, p);
        if (!k) { kq.khongThay++; continue; }
        if (!laVideoKhung(k)) { // (4.5) trang chưa hiện video (đang tải) → chờ thêm; API nói là video thì tin API
          k.khung.scrollIntoView({ block: 'center' });
          if (!(await cho(() => laVideoKhung(k), 5000, 500)) && laVideoApi(p) !== true) { luuVid2(p, { tt: 'khong_video', lan: ((st0[p.id] || {}).lan || 0) + 1 }); continue; }
        }
        if ((st0[p.id] || {}).tt === 'luu') { // đã Lưu lần trước nhưng chưa thấy trên bài → xem đầu bài
          if (baiDaGan(k).du) { luuVid2(p, { tt: 'luu', xacNhan: true }); kq.daDu++; continue; }
          luuVid2(p, { kiemLai: ((st0[p.id] || {}).kiemLai || 0) + 1 });
        }
        moRa++; veQuet(`video ${vi + 1}/${ungVien.length} · ${cheDoThu ? 'kiểm tra' : 'sửa'} ${gioStr(new Date(p.luc))}`);
        try { if ((await xuLyVideo(k, p, kq)) === 'da_sua') suaRa++; }
        catch (e) {
          if (e instanceof LoiDung) throw e;
          const lan = ((vidState()[p.id] || {}).lan || 0) + 1;
          luuVid2(p, { tt: 'loi', lan, loi: e.message });
          kq.loi.push(`video ${gioStr(new Date(p.luc))}: ${e.message}`);
          ghi(`Quét: lỗi với video đăng lúc ${gioStr(new Date(p.luc))} (lần ${lan}/3): ${e.message}`);
          // (4.5) thử ngay lần nữa trong lượt này (tải lại khung, bấm kiểu khác) trước khi tính là lỗi
          if (lan < 3 && !e.daThuLai) {
            try {
              if (dangODuongSua()) await dongManHinhSua();
              if (!dungTrang()) await khoiPhucTrang();
              window.scrollTo(0, 0); await sleep(1500);
              const k2 = await cuonTimKhung(p.text, 10, p);
              if (k2) { ghi(`Quét: thử lại ngay video ${gioStr(new Date(p.luc))}`); if ((await xuLyVideo(k2, p, kq)) === 'da_sua') { suaRa++; kq.loi.pop(); } }
            } catch (e2) { if (e2 instanceof LoiDung) throw e2; const l2 = ((vidState()[p.id] || {}).lan || 0) + 1; luuVid2(p, { tt: 'loi', lan: l2, loi: e2.message }); ghi(`Quét: thử lại vẫn lỗi (lần ${l2}/3): ${e2.message}`); }
          }
          const lanCuoi = (vidState()[p.id] || {}).lan || 0;
          if ((vidState()[p.id] || {}).tt === 'loi' && lanCuoi >= 3) { // hết cách → báo nhóm NGAY (không chờ cuối lượt, tránh mất tin khi lượt dừng giữa chừng)
            const kk = cacKhungBai().find((x) => khungKhopP(x, p));
            kq.daBaoNhom++;
            await baoLark(`Video đăng lúc ${gioStr(new Date(p.luc))} chưa tự gắn được thẻ/cảm xúc — cần gắn tay${p.link ? ' — ' + p.link : ''}`);
          }
        }
        if (!(await khoiPhucTrang())) { kq.lyDo = 'không quay về được trang Page'; if (!thu) datThongBaoQuet(kq, slot, thu, false, false, false); veTrang(); return; }
        await nghiNgan(CAI_DAT.QUET_NGHI_GIAY[0] * 1000, CAI_DAT.QUET_NGHI_GIAY[1] * 1000);
      }

      // ---- (2) Thích / Yêu thích bài + comment ----
      if (dangODuongSua() || !dungTrang()) { if (!(await khoiPhucTrang())) { kq.lyDo = 'không quay về được trang Page'; if (!thu) datThongBaoQuet(kq, slot, thu, false, false, false); veTrang(); return; } }
      const thSt = lay('quet_thich112', {}) || {};
      const dsTh = !(cfg.thichBai || cfg.thichCmt) ? [] : ds.filter(cua(CAI_DAT.QUET_THICH_GIO)).filter((p) => !(thSt[p.id] && Date.now() - thSt[p.id] < 3 * 3600e3)); // bài vừa làm xong < 3 giờ thì khỏi làm lại
      const daXong = new Set(); const daXuLy = new WeakSet();
      window.scrollTo(0, 0); await sleep(1000);
      for (let buoc = 0; buoc < 12 && daXong.size < dsTh.length && kq.dem < CAI_DAT.QUET_THICH_TOI_DA && Date.now() < han; buoc++) {
        kiemDung(); veQuet(`${cheDoThu ? 'thử ' : ''}thích bài/comment · bài ${daXong.size}/${dsTh.length} · đã thả ${kq.dem}/${CAI_DAT.QUET_THICH_TOI_DA}`);
        for (const k of cacKhungBai()) {
          if (daXuLy.has(k.khung)) continue;
          const p = dsTh.find((x) => !daXong.has(x.id) && khungKhopP(k, x));
          if (!p) continue;
          daXuLy.add(k.khung); daXong.add(p.id);
          const loiTruoc = kq.loiThich.length + kq.thieuNut + kq.thieuNutCmt;
          let vanDe = 0;
          try { vanDe = await thichKhung(k, kq, p); }
          catch (e) { if (e instanceof LoiDung) throw e; kq.loiThich.push('bài/comment: ' + e.message); vanDe = 1; ghi('Quét: lỗi khi thích ở một bài: ' + e.message); }
          if (vanDe && !cheDoThu && p.link && /^https?:/.test(p.link) && !kq.canLink.some((x) => x.id === p.id)) kq.canLink.push({ id: p.id, link: p.link, text: p.text, luc: p.luc });
          if (!cheDoThu && kq.loiThich.length + kq.thieuNut + kq.thieuNutCmt === loiTruoc && kq.dem < CAI_DAT.QUET_THICH_TOI_DA) {
            thSt[p.id] = Date.now(); for (const id of Object.keys(thSt)) if (Date.now() - thSt[id] > 3 * 864e5) delete thSt[id];
            luu('quet_thich112', thSt);
          }
          if (!dungTrang()) { if (!(await khoiPhucTrang())) { kq.lyDo = 'không quay về được trang Page'; if (!thu) datThongBaoQuet(kq, slot, thu, false, false, false); veTrang(); return; } }
        }
        window.scrollBy(0, Math.round(window.innerHeight * 0.8)); await sleep(1500);
      }
      window.scrollTo(0, 0);
      kq.conLai = Math.max(0, dsTh.length - daXong.size);
      // (4.5) bài không thấy trên trang chính (cuộn chưa tới / hết giờ) mà có link → cũng đưa vào danh sách mở trang riêng
      if (!thu && kq.dem < CAI_DAT.QUET_THICH_TOI_DA) for (const p of dsTh) if (!daXong.has(p.id) && p.link && /^https?:/.test(p.link) && !kq.canLink.some((x) => x.id === p.id)) kq.canLink.push({ id: p.id, link: p.link, text: p.text, luc: p.luc });
      { const da = lay('quet_link_da', {}) || {}; kq.dsLink = thu || kq.dem >= CAI_DAT.QUET_THICH_TOI_DA ? [] : kq.canLink.filter((x) => !(da[x.id] && Date.now() - da[x.id] < 3 * 3600e3)).slice(0, 4); }
      xong = true;
    } catch (e) {
      if (e instanceof LoiTamHoan) { tamHoan = true; ghi('Quét tạm hoãn: ' + e.message); kq.lyDo = 'tab bị ẩn / chuyển tab giữa chừng — lượt sau quét tiếp'; }
      else if (e instanceof LoiDung) ghi('Quét dừng giữa chừng: ' + e.message);
      else { kq.loi.push(e.message); kq.lyDo = e.message; ghi('Quét lỗi: ' + e.message); }
    } finally {
      if (tamHoan && !thu) capNhatNgay(ngay, (x) => { if (x.quetLan && x.quetLan[slot]) x.quetLan[slot]--; }); // (4.5) tạm hoãn không tính là 1 lượt
      try { if (dangODuongSua()) await dongManHinhSua(); } catch (e) { /* */ }
      cheDoThu = false; dangQuet = false; dangBan = false; buocQuet = ''; luu('quet_dang', null); giuKhoa();
    }
    const caoDung = lay('quet_dung', 0) > moQuet;
    const tt = (thu ? tomTatThu(kq) : tomTatKq(kq)) + (caoDung ? ' (Cao dừng giữa chừng)' : '');
    const coLink = !thu && xong && !caoDung && kq.dsLink.length > 0;
    if (thu) { luu('quet_thu', { luc: Date.now(), kq: tt }); ghi('Quét thử xong: ' + tt); }
    else if (xong || caoDung) {
      capNhatNgay(ngay, (x) => {
        x.quet = x.quet || {}; x.quet[slot] = { luc: Date.now(), kq: tt };
        const t = x.quetTong = x.quetTong || { gan: 0, thichBai: 0, thichCmt: 0, lan: 0 };
        t.gan += kq.gan; t.thichBai += kq.thichBai; t.thichCmt += kq.thichCmt; t.lan++;
      });
      ghi(`Quét ${slot === 'tay' ? '(tay)' : slot} xong: ${tt}${kq.thieuNut ? ` · ${kq.thieuNut} bài không thấy nút Thích` : ''}${kq.thieuNutCmt ? ` · ${kq.thieuNutCmt} comment không thấy nút Thích` : ''}${kq.khongThay ? ` · ${kq.khongThay} bài chưa thấy trên trang` : ''}`);
      if (kq.loiThich.length) ghi('Quét: lỗi thả cảm xúc: ' + kq.loiThich.slice(0, 3).join(' || '));
      if (kq.chiTietThieu.length) ghi('Quét: comment không thấy nút Thích — chi tiết: ' + kq.chiTietThieu.join(' || '));
    } else ghi(`Quét chưa xong (${tt}) — sẽ thử lại nếu còn lượt`);
    // (4.2) kế hoạch B: timeline không thích được → mở thẳng trang riêng của bài để thích ở đó
    if (coLink) {
      luu('quet_link', { luc: Date.now(), ngay, slot, ds: kq.dsLink.map((x) => ({ id: x.id, link: x.link, text: x.text })), i: 0, kq: { thichCmt: 0, thichBai: 0, loi: [], dem: kq.dem } });
      ghi(`Quét: ${kq.dsLink.length} bài chưa thích được hết trên trang chính → sẽ mở thẳng trang riêng của bài để thử lại`);
    }
    datThongBaoQuet(kq, slot, thu, xong, caoDung, coLink);
    veBang();
    // Facebook cuộn nhiều làm tab phình bộ nhớ → quét xong thì tải lại trang cho nhẹ
    if (xong && !thu && !coLink && document.querySelectorAll('[role="article"]').length > 12) setTimeout(() => { if (!dangBan && !lay('quet_link', null) && !lay('dang_do', null) && document.visibilityState === 'visible' && !nhanSuDangDung()) roiTrang(CAI_DAT.URL_TRANG); }, 5000);
    return xong || caoDung;
  }


  // ---- (4.2) THÔNG BÁO "ĐÃ QUÉT XONG" (hiện ngay dưới thanh tiêu đề, kể cả khi thu gọn; bấm "Đã xem" để tắt) ----
  function datThongBaoQuet(kq, slot, thu, xong, caoDung, coLink) {
    const kho = kq.loi.length - (kq.lyDo && kq.loi.includes(kq.lyDo) ? 1 : 0); const chuaThich = kq.loiThich.length + kq.thieuNut + kq.thieuNutCmt;
    const phan = [];
    if (thu) phan.push(tomTatThu(kq));
    else {
      phan.push(`gắn thẻ/cảm xúc ${kq.gan} video${kq.daDu ? ` (${kq.daDu} video đã đủ sẵn)` : ''}`);
      phan.push(`thích ${kq.thichBai} bài + ${kq.thichCmt} comment`);
      if (!kq.gan && !kq.daDu && !kq.thichBai && !kq.thichCmt && !kho && !chuaThich && !kq.lyDo) phan.push('không có việc gì cần làm');
    }
    const chiTiet = [];
    if (kho) { phan.push(`${kho} video chưa gắn được${kq.daBaoNhom ? ` (${kq.daBaoNhom} video đã thử 3 lần → đã báo nhóm gắn tay)` : ' (lượt sau sẽ thử lại)'}`); kq.loi.slice(0, 3).forEach((x) => chiTiet.push(x)); }
    if (kq.khongThay) phan.push(`${kq.khongThay} video chưa thấy trên trang (lượt sau tìm lại)`);
    if (kq.conLai && !coLink) phan.push(`${kq.conLai} bài chưa tới lượt thích (lượt sau làm tiếp)`);
    if (chuaThich) { phan.push(`${chuaThich} bài/comment chưa thích được${coLink ? ' → đang mở trang riêng của bài để thử lại' : ''}`); kq.loiThich.slice(0, 2).forEach((x) => chiTiet.push(x)); kq.chiTietThieu.slice(0, 2).forEach((x) => chiTiet.push('không thấy nút Thích: ' + x)); }
    if (kq.lyDo) phan.push('dừng vì: ' + String(kq.lyDo).slice(0, 140));
    const tieuDe = thu ? 'Quét thử xong' : caoDung ? 'Quét đã dừng' : xong ? 'Quét xong' : 'Quét chưa hoàn tất';
    const mau = (!xong && !caoDung && !thu) || kho || kq.lyDo ? 'loi' : chuaThich ? 'vang' : 'ok';
    luu('quet_thongbao', { luc: Date.now(), slot, tieuDe, chu: phan.join(' · '), mau, chiTiet, dong: false, choLink: !!coLink });
    veBang();
  }
  function thongBaoQuetHtml() {
    const tb = lay('quet_thongbao', null);
    const qd = lay('quet_dang', null); const dang = dangQuet || (qd && Date.now() - qd.luc < 90000) || !!lay('quet_link', null);
    if (dang) return `<div class="tb-quet cho"><span>🧹 <b>Đang quét…</b> ${esc((dangQuet ? buocQuet : (qd && qd.buoc)) || (lay('quet_link', null) ? 'đang thử lại qua trang riêng của bài' : ''))}</span></div>`;
    if (!tb || tb.dong || Date.now() - tb.luc > 45 * 60000) return '';
    const bieu = tb.mau === 'ok' ? '✅' : tb.mau === 'vang' ? '⚠️' : '❌';
    return `<div class="tb-quet ${tb.mau}"><span>${bieu} <b>${esc(tb.tieuDe)} lúc ${gioStr(new Date(tb.luc))}:</b> ${esc(tb.chu)}${(tb.chiTiet || []).length ? ` <span class="mo">(${esc(tb.chiTiet.join(' | ')).slice(0, 260)})</span>` : ''}</span><button class="phu-nut" data-a="dongtb">Đã xem ✕</button></div>`;
  }

  // ---- (4.2) KẾ HOẠCH B: mở thẳng trang riêng của bài (reel/bài) để thích bài + comment ở đó ----
  const dungLinkBai = (link) => {
    try { const u = new URL(link); const id = u.pathname.split('/').filter(Boolean).pop() || ''; const sf = u.searchParams.get('story_fbid');
      return !!id && (location.pathname.includes(id) || (!!sf && location.search.includes(sf))); } catch (e) { return false; }
  };
  async function quetMotTrang(ql, r = { thichCmt: 0, thichBai: 0, loi: [], chiTiet: [] }) {
    const MAXN = CAI_DAT.QUET_THICH_TOI_DA; const cfg = quetCfg();
    const arts = () => Array.from(document.querySelectorAll('[role="article"]')).filter(laCmtArt);
    await cho(() => document.querySelector('[role="article"]') || document.querySelector('[aria-label="Thích"]'), 12000, 500);
    await sleep(1500);
    // khung bình luận đóng (reel) → bấm mở
    for (let i = 0; i < 3 && !arts().length; i++) {
      const b = Array.from(document.querySelectorAll('[aria-label="Bình luận"][role="button"]')).find(dangHien);
      if (!b) break;
      try { ganBam(b); } catch (e) { b.click(); }
      await cho(() => arts().length, 6000, 400);
    }
    if (cfg.thichBai) {
      const nb = (n) => nutCuaBai(document.body, n);
      if (!nb(DA_CO_CAM_XUC) && (nb('Thích') || nb('Bày tỏ cảm xúc')) && ql.kq.dem < MAXN) {
        try { const r0 = await thaCamXuc(nb, 'Bài (trang riêng)', null, 5000); if (r0 !== 'co_san') { r.thichBai++; ql.kq.dem++; } } catch (e) { if (e instanceof LoiDung) throw e; r.loi.push('bài: ' + e.message); }
        await nghiNgan();
      } else if (!nb(DA_CO_CAM_XUC) && !nb('Thích') && !nb('Bày tỏ cảm xúc')) r.chiTiet.push('trang riêng: không thấy nút Thích của bài');
    }
    if (!cfg.thichCmt) return r;
    const daLam = new Set(); let khongMoi = 0;
    for (let vong = 0; vong < 8 && khongMoi < 2 && ql.kq.dem < MAXN; vong++) {
      let moi = 0;
      for (const art0 of arts()) {
        if (ql.kq.dem >= MAXN) break;
        const id = nhanArt(art0) + '|' + chuan(art0.innerText).slice(0, 25);
        if (daLam.has(id)) continue; daLam.add(id); moi++;
        kiemDung();
        const x = await thichMotCmt(taoTimArt(art0, arts));
        if (x.tt === 'ok') { r.thichCmt++; ql.kq.dem++; await nghiNgan(); }
        else if (x.tt === 'khong_nut') { r.loi.push('comment không thấy nút Thích'); if (r.chiTiet.length < 3) r.chiTiet.push(x.chiTiet); }
        else if (x.tt === 'loi') { r.loi.push('comment: ' + x.loi); await nghiNgan(); }
      }
      khongMoi = moi ? 0 : khongMoi + 1;
      const them = Array.from(document.querySelectorAll('[role="button"]')).find((b) => /^Xem thêm (\d+ )?(bình luận|phản hồi)|^Xem \d+ (bình luận|phản hồi)/.test(chuan(b.innerText)) && dangHien(b));
      if (them) { them.click(); await sleep(1800); khongMoi = 0; }
      else { const l = arts().pop(); if (l) { try { l.scrollIntoView({ block: 'end' }); } catch (e) { /* */ } } await sleep(1500); }
    }
    return r;
  }
  async function ketThucQuetLink(ql, lyDo) {
    const t = ql.kq; const da = lay('quet_link_da', {}) || {};
    ql.ds.forEach((x) => { da[x.id] = Date.now(); }); for (const id of Object.keys(da)) if (Date.now() - da[id] > 3 * 864e5) delete da[id];
    luu('quet_link_da', da); luu('quet_link', null);
    capNhatNgay(ql.ngay, (x) => {
      const tg = x.quetTong = x.quetTong || { gan: 0, thichBai: 0, thichCmt: 0, lan: 0 }; tg.thichBai += t.thichBai; tg.thichCmt += t.thichCmt;
      if (x.quet && x.quet[ql.slot]) x.quet[ql.slot].kq += ` · thử lại qua trang bài: +${t.thichBai} bài, +${t.thichCmt} comment`;
    });
    ghi(`Quét (thử lại qua trang riêng của bài) xong${lyDo ? ' [' + lyDo + ']' : ''}: thêm ${t.thichBai} bài + ${t.thichCmt} comment${t.loi.length ? ' · còn ' + t.loi.length + ' việc chưa được: ' + t.loi.slice(0, 3).join(' || ') : ''}${t.chiTiet && t.chiTiet.length ? ' · chi tiết: ' + t.chiTiet.join(' || ') : ''}`);
    const tb = lay('quet_thongbao', null) || { luc: Date.now(), slot: ql.slot, tieuDe: 'Quét xong', chu: '', chiTiet: [] };
    const goc = String(tb.chu || '').replace(/ → đang mở trang riêng của bài để thử lại/, '');
    luu('quet_thongbao', Object.assign(tb, { luc: Date.now(), tieuDe: 'Quét xong (kèm thử lại qua trang bài)', chu: `${goc} · thử lại qua trang bài: thêm ${t.thichBai} bài + ${t.thichCmt} comment${t.loi.length ? ` · còn ${t.loi.length} việc chưa được` : ''}`, mau: t.loi.length ? 'vang' : 'ok', chiTiet: (t.chiTiet || []).map((x) => 'không thấy nút Thích: ' + x), dong: false, choLink: false }));
    if (!dungTrang()) setTimeout(() => { if (!dangBan && !lay('dang_do', null)) veTrang(); }, 1500);
    veBang();
  }
  async function tiepQuetLink() {
    const ql = lay('quet_link', null); if (!ql) return false;
    if (Date.now() - ql.luc > 25 * 60000 || ql.i >= ql.ds.length) { await ketThucQuetLink(ql, ql.i < ql.ds.length ? 'quá thời gian' : ''); return true; }
    if (!laTabChinh() || lay('tam_dung', false) || lay('dang_do', null) || dangBan || dangQuet || document.visibilityState !== 'visible') return false;
    if ((hopDangDo() || hopSoanBai() || dangODuongSua()) && nguoiDangThaoTac()) return false; // (4.5) người đang thao tác → chờ
    if (lay('quet_dung', 0) > ql.luc) { ghi('Quét: Cao dừng → bỏ phần thử lại qua trang bài'); await ketThucQuetLink(ql, 'Cao dừng'); return true; }
    const it = ql.ds[ql.i];
    const toiNoi = dungLinkBai(it.link) || ((it.nav || 0) >= 1 && !dungTrang() && /facebook\.com$/.test(location.hostname) && /\/(posts|reel|reels|videos|permalink|watch|photo)|story_fbid|[?&]v=/.test(location.pathname + location.search));
    if (!toiNoi) {
      if ((it.nav || 0) >= 2) { ql.kq.loi.push('không mở được trang bài ' + it.link); ql.i++; luu('quet_link', ql); return true; }
      it.nav = (it.nav || 0) + 1; luu('quet_link', ql);
      ghi(`Quét: mở trang riêng của bài (${ql.i + 1}/${ql.ds.length}) để thích: ${it.link}`); await sleep(800);
      roiTrang(it.link); return true;
    }
    dangBan = true; dangQuet = true; moQuet = Date.now(); giuKhoa();
    const r = { thichCmt: 0, thichBai: 0, loi: [], chiTiet: [] };
    let hoan = false;
    try {
      veQuet(`trang riêng của bài ${ql.i + 1}/${ql.ds.length} · đang thích`);
      await quetMotTrang(ql, r);
    } catch (e) {
      if (e instanceof LoiTamHoan && (it.hoan || 0) < 2) { hoan = true; it.hoan = (it.hoan || 0) + 1; ghi('Quét (trang bài) tạm hoãn: ' + e.message + ' — làm lại bài này sau'); }
      else { r.loi.push(e instanceof LoiDung ? 'bị dừng' : e.message); ghi('Quét (trang bài) lỗi: ' + e.message); }
    }
    finally { dangBan = false; dangQuet = false; buocQuet = ''; luu('quet_dang', null); giuKhoa(); }
    if (hoan) { ql.kq.thichCmt += r.thichCmt; ql.kq.thichBai += r.thichBai; luu('quet_link', ql); return true; }
    ql.kq.thichCmt += r.thichCmt; ql.kq.thichBai += r.thichBai; ql.kq.loi.push(...r.loi); ql.kq.chiTiet = (ql.kq.chiTiet || []).concat(r.chiTiet || []).slice(0, 3);
    ghi(`Quét (trang bài ${ql.i + 1}/${ql.ds.length}): thích ${r.thichBai} bài + ${r.thichCmt} comment${r.loi.length ? ' · chưa được: ' + r.loi.slice(0, 2).join(' || ') : ''}`);
    ql.i++; luu('quet_link', ql); veBang();
    return true;
  }

  // Mốc quét đang đến hạn mà hôm nay chưa chạy (mốc còn hiệu lực đến khi mốc kế tiếp bắt đầu)
  const quetDangChay = () => { const qd = lay('quet_dang', null); return dangQuet || !!(qd && Date.now() - qd.luc < 90000); };
  const lechMoc = (g) => 1 + (parseInt(bam(homNay() + g), 36) % 3); // mỗi mốc lệch 1–3 phút (cố định trong ngày) cho giống người làm tay
  function mocQuetDenHan() {
    const m = phutTrongNgay(new Date()); const mocs = CAI_DAT.GIO_QUET; const da = trangThaiNgay(homNay()).quet || {};
    for (let i = 0; i < mocs.length; i++) {
      const tu = docGio(mocs[i]) + lechMoc(mocs[i]), den = i + 1 < mocs.length ? docGio(mocs[i + 1]) : 1440;
      if (m >= tu && m < Math.min(den, tu + CAI_DAT.QUET_BU_PHUT) && !da[mocs[i]]) return mocs[i];
    }
    return null;
  }
  async function quetNeuDenHan() {
    const ep = lay('quet_ngay', null); const epHop = !!(ep && Date.now() - ep.luc < 10 * 60000);
    if (ep && !epHop) luu('quet_ngay', null);
    if (!laTabChinh() || lay('quet_link', null)) return; // (4.2) chỉ tab làm việc (⭐ Main) mới quét; đang thử lại qua trang bài thì chờ
    if (!lay('quet_ngay', null) && lay('quet_yen', 0) > Date.now()) return; // đang yên lặng: không tự quét
    let slot = epHop ? (ep.thu ? 'thu' : 'tay') : (quetCfg().tuDong ? mocQuetDenHan() : null);
    if (!slot) return;
    if (lay('tam_dung', false) || dangBan || demNguocDen || lay('dang_do', null) || lay('soan_thu', null) || lay('b23_cho_tay', null)) return;
    if (document.visibilityState !== 'visible') return; // cần tab hiện (Facebook đứng hình khi tab bị che)
    if (!epHop && (hopDangDo() || hopSoanBai() || dangODuongSua()) && nguoiDangThaoTac()) return; // (4.5) quét tự động: không chen ngang người đang soạn/sửa bài
    if (!coApi()) { if (epHop) { luu('quet_ngay', null); ghi('Quét: chưa cài mã khoá Facebook nên chưa quét được'); } return; }
    if (!epHop) { // quét tự động: tối đa 2 lượt/mốc, cách nhau 10 phút
      const s = trangThaiNgay(homNay()); const lan = (s.quetLan || {})[slot] || 0;
      if (lan >= 2 || (lan && Date.now() - (s.quetLuc || 0) < 10 * 60000)) return;
      if (Object.values(s.quet || {}).some((v) => Date.now() - v.luc < 90 * 60000)) return; // vừa quét xong chưa lâu → khỏi quét tiếp
    } else luu('quet_ngay', null);
    await quetChay(slot);
  }

  // =====================================================================
  //  GIAO DIỆN — thanh tiêu đề có màu (kéo thả được) + phần mở rộng có tab
  // =====================================================================
  // Cỡ chữ: 1.0 = cỡ của bản 1.0/1.1; mặc định 1.2 (to hơn 1,2 lần). Chỉnh bằng A− / A+ trên khung
  const CO_CHU_MAC_DINH = 1.2;
  const coChu = () => { const z = +lay('ui_co_chu', CO_CHU_MAC_DINH); return z >= 0.8 && z <= 1.8 ? z : CO_CHU_MAC_DINH; };

  function taoCSS(Z) {
    const p = (n) => (Math.round(n * Z * 10) / 10) + 'px';
    return `
  #smhfb{--nen:#fdfcf9;--chu:#1c1a15;--phu:#6b665a;--vien:#e6e0d2;--vien2:#efeadf;--the:#ffffff;--the-vien:#ece6d8;--nut:#efeadf;--nut-chu:#1c1a15;--icon:#ffffff;
    --chinh-nen:#2a8a4f;--chinh-chu:#ffffff;--acc:#2e9d57;
    --xanh-nen:#e6f3ea;--xanh-chu:#1f6b3a;--do-nen:#fbe9e7;--do-chu:#b3261e;--vang-nen:#fbf0d6;--vang-chu:#7a5a12;--xam-nen:#efeadf;--xam-chu:#5f5a4e;--thieu:#fff6f4;--link:#1f7a44;--bong:rgba(40,30,10,.28);
    --khung:#9b9588;--dau:#f4f1e9}
  #smhfb.toi{--nen:#1a1916;--chu:#f3efe6;--phu:#aaa497;--vien:#38342b;--vien2:#2e2b24;--the:#22201b;--the-vien:#34312a;--nut:#2f2c25;--nut-chu:#f3efe6;--icon:#2a2721;
    --chinh-nen:#3fae6a;--chinh-chu:#0d1f15;--acc:#3fae6a;
    --xanh-nen:#1c3326;--xanh-chu:#8fdca9;--do-nen:#472225;--do-chu:#ff9e98;--vang-nen:#40340f;--vang-chu:#f3d27c;--xam-nen:#2f2c25;--xam-chu:#c4beb0;--thieu:#35231f;--link:#6fd39b;--bong:rgba(0,0,0,.65);--dau:#24221d}
  #smhfb.k-xanh{--khung:#2e9d57;--dau:#eef6f0}#smhfb.k-vang{--khung:#e0a21a;--dau:#fbf3de}#smhfb.k-do{--khung:#d93a3a;--dau:#fbecea}#smhfb.k-xam{--khung:#9b9588;--dau:#f1eee6}
  #smhfb.k-xanh{--vang-nen:var(--xanh-nen);--vang-chu:var(--xanh-chu)} /* trạng thái ổn: mọi chip/nút 'đang chờ' hiện xanh lá, chỉ khi có việc/lỗi mới sang vàng-đỏ */
  #smhfb.toi.k-xanh{--dau:#1d2a22}#smhfb.toi.k-vang{--dau:#2e2813}#smhfb.toi.k-do{--dau:#36201f}#smhfb.toi.k-xam{--dau:#25231e}
  #smhfb{position:fixed;box-sizing:border-box;z-index:2147483600;font:${p(14)}/1.5 "Segoe UI Variable Text","Segoe UI",system-ui,-apple-system,Roboto,Arial,sans-serif;color:var(--chu);
    background:var(--nen);border:3px solid var(--khung);border-radius:${p(18)};box-shadow:0 18px 48px var(--bong),0 2px 6px rgba(0,0,0,.08);
    width:${p(1033)};max-width:calc(100vw - 16px);user-select:none;-webkit-font-smoothing:antialiased;overflow:hidden;display:flex;flex-direction:column}
  #smhfb.ghim{border-top-width:0;border-radius:0 0 ${p(18)} ${p(18)}}
  #smhfb>*{flex:none}#smhfb>.nd{flex:1 1 auto;min-height:0}
  #smhfb *{box-sizing:border-box}
  #smhfb .bar{position:relative;padding:${p(7)} calc(50px + 34px + var(--ext,0px)) ${p(7)} ${p(16)};min-height:53px;display:flex;align-items:center;cursor:move;background:var(--dau)}
  /* thu gọn: cao đúng bằng thanh ngang của Facebook (56px = 53px + viền 3px), 1 hàng duy nhất */
  #smhfb:not(.mo-rong) .bar{height:53px;padding-top:0;padding-bottom:0;overflow:hidden}
  #smhfb:not(.mo-rong) .h1{flex-wrap:nowrap}
  #smhfb:not(.mo-rong) .tt{flex:1 1 0}
  #smhfb:not(.mo-rong) .grip{display:none}
  #smhfb:not(.mo-rong) .h1{gap:0 ${p(8)}}
  #smhfb:not(.mo-rong) .h2{gap:${p(4)}}
  #smhfb:not(.mo-rong) .h2 .tg{padding:${p(2)} ${p(8)};font-size:${p(12)}}
  #smhfb:not(.mo-rong) .nsheet{padding:${p(2)} ${p(12)};font-size:${p(17)}}
  #smhfb:not(.mo-rong) .h2{flex:0 1 auto;flex-wrap:nowrap;min-width:0;overflow:hidden}
  #smhfb .ten,#smhfb .grip,#smhfb .den,#smhfb .nsheet{flex:none}
  #smhfb.keo .bar{cursor:grabbing}
  #smhfb .h1{display:flex;flex-wrap:wrap;align-items:center;gap:${p(6)} ${p(10)};width:100%}
  #smhfb .h2{display:flex;flex-wrap:wrap;align-items:center;gap:${p(6)};margin:0;padding:0}
  #smhfb .act{position:absolute;right:calc(14px + var(--ext,0px));top:0;height:53px;display:flex;align-items:center;gap:${p(8)}}
  #smhfb .grip{color:var(--phu);font-size:${p(15)};line-height:1;letter-spacing:-1px;flex:none;opacity:.55}
  #smhfb .den{width:${p(11)};height:${p(11)};border-radius:50%;flex:none;box-shadow:0 0 0 ${p(4)} rgba(127,127,127,.14)}
  #smhfb .den.xanh{background:#2e9d57}#smhfb .den.vang{background:#e0a21a}#smhfb .den.do{background:#d93a3a}#smhfb .den.xam{background:#9b9588}
  #smhfb .den.nhay{animation:smhfbNhay 1.2s infinite}
  @keyframes smhfbNhay{50%{opacity:.3}}
  @keyframes smhfbQuay{to{transform:rotate(360deg)}}
  #smhfb .ten{font-weight:700;font-size:${p(14.5)};white-space:nowrap;letter-spacing:.2px}
  #smhfb .the{font-size:${p(11.5)};font-weight:700;color:#fff;background:#8a5a00;border-radius:${p(6)};padding:1px ${p(7)}}
  #smhfb .tt{flex:1 1 ${p(70)};min-width:0;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;font-size:${p(13.5)};font-weight:600;color:var(--phu)}
  #smhfb .tt b{font-variant-numeric:tabular-nums;color:var(--chu)}
  #smhfb .icon{border:1px solid var(--vien);background:var(--icon);color:var(--chu);width:${p(32)};height:${p(32)};border-radius:50%;cursor:pointer;font-size:${p(14)};flex:none;
    display:inline-flex;align-items:center;justify-content:center;padding:0;font-family:inherit;transition:background .15s,border-color .15s}
  #smhfb .icon.lon{width:50px;height:50px;font-size:${p(21)};border:1px solid color-mix(in srgb,var(--chu) 55%,transparent)}
  #smhfb .icon:hover{border-color:var(--acc);color:var(--acc)}
  #smhfb .nsheet{border:1px solid var(--acc);background:var(--icon);color:var(--chu);border-radius:999px;padding:${p(2)} ${p(15)};line-height:1.15;font-family:inherit;font-size:${p(18.75)};font-weight:700;cursor:pointer;flex:none;white-space:nowrap;transition:background .15s}
  #smhfb .nsheet:hover{background:var(--acc);color:var(--chinh-chu)}
  #smhfb .nsheet.canh{background:var(--do-nen);color:var(--do-chu);border-color:#d93a3a88}
  #smhfb .icon.quay span{display:inline-block;animation:smhfbQuay .9s linear infinite}
  #smhfb .tg{font-size:${p(12.5)};font-weight:600;border-radius:999px;padding:${p(2)} ${p(11)};background:var(--icon);color:var(--xam-chu);border:1px solid var(--vien);white-space:nowrap;
    font-family:inherit;line-height:1.5;cursor:default}
  #smhfb .tg.ok{color:var(--xanh-chu);border-color:#2e9d5755;background:var(--xanh-nen)}#smhfb .tg.cho{color:var(--vang-chu);border-color:color-mix(in srgb,var(--vang-chu) 40%,transparent);background:var(--vang-nen)}#smhfb .tg.loi{color:var(--do-chu);border-color:#d93a3a66;background:var(--do-nen)}
  #smhfb button.tg{cursor:pointer;transition:filter .15s}#smhfb button.tg:hover{filter:brightness(.95)}
  #smhfb .tabs{display:flex;gap:${p(6)};padding:0 ${p(16)};border-bottom:1px solid var(--vien2);background:var(--nen)}
  #smhfb .tab{border:0;background:none;padding:${p(11)} ${p(14)};font-family:inherit;font-size:${p(14)};font-weight:600;color:var(--phu);cursor:pointer;border-bottom:${p(2.5)} solid transparent;margin-bottom:-1px;transition:color .15s}
  #smhfb .tab:hover{color:var(--chu)}
  #smhfb .tab.chon{color:var(--link);border-bottom-color:var(--acc)}
  #smhfb .nd{padding:${p(14)} ${p(16)} ${p(4)};max-height:none;overflow:auto;user-select:text;scrollbar-width:thin;background:var(--dau);background:color-mix(in srgb,var(--nen) 60%,var(--vien2))}
  #smhfb .nd.cot2{display:grid;grid-template-columns:1fr 1fr;gap:0 ${p(16)};align-items:start}
  #smhfb .cot{min-width:0}
  @media (max-width:1100px){#smhfb .nd.cot2{display:block}}
  #smhfb .the-nd{background:var(--the);border:1px solid var(--the-vien);border-radius:${p(14)};padding:${p(12)} ${p(16)};margin-bottom:${p(12)};box-shadow:0 1px 2px rgba(40,30,10,.05)}
  #smhfb .nhan{font-size:${p(11.5)};color:var(--phu);font-weight:700;text-transform:uppercase;letter-spacing:.9px;margin-bottom:${p(6)}}
  #smhfb .dong{display:flex;justify-content:space-between;gap:${p(12)};align-items:baseline;margin:${p(4)} 0}
  #smhfb .dong>span:first-child{color:var(--phu);flex:none}
  #smhfb .dong>span:last-child{text-align:right}
  #smhfb .noidung{font-size:${p(14.5)};line-height:1.6;white-space:pre-wrap;word-break:break-word}
  #smhfb .noidung.phu{font-size:${p(13.5)};color:var(--phu)}
  #smhfb .chip{display:inline-block;font-size:${p(12.5)};font-weight:600;border-radius:999px;padding:1px ${p(10)};margin-left:${p(6)};vertical-align:middle;text-transform:none;letter-spacing:0}
  #smhfb .chip.ok{background:var(--xanh-nen);color:var(--xanh-chu)}#smhfb .chip.loi{background:var(--do-nen);color:var(--do-chu)}#smhfb .chip.cho{background:var(--vang-nen);color:var(--vang-chu)}#smhfb .chip.xam{background:var(--xam-nen);color:var(--xam-chu)}
  #smhfb .buoc{display:flex;flex-wrap:wrap;gap:${p(6)}}
  #smhfb .b{font-size:${p(12.5)};border-radius:${p(9)};padding:${p(3)} ${p(10)};background:var(--xam-nen);color:var(--xam-chu);font-weight:600}
  #smhfb .b.xong{background:var(--xanh-nen);color:var(--xanh-chu)}#smhfb .b.dang{background:var(--vang-nen);color:var(--vang-chu)}#smhfb .b.loi{background:var(--do-nen);color:var(--do-chu)}
  #smhfb .skhoe{display:grid;grid-template-columns:1fr 1fr;gap:${p(8)} ${p(16)};font-size:${p(13.5)}}
  #smhfb table{width:100%;border-collapse:collapse;font-size:${p(13.5)}}
  #smhfb th{text-align:left;color:var(--phu);font-weight:600;font-size:${p(12)};padding:${p(5)} ${p(8)};border-bottom:1px solid var(--vien);text-transform:uppercase;letter-spacing:.5px}
  #smhfb td{padding:${p(8)} ${p(8)};border-bottom:1px solid var(--vien2);vertical-align:top}
  #smhfb tr.thieu td{background:var(--thieu)}
  #smhfb td:first-child,#smhfb table.ls td:nth-child(2),#smhfb table.ls .chip{white-space:nowrap}
  #smhfb .nk{font:${p(12.5)}/1.65 ui-monospace,Consolas,monospace;white-space:pre-wrap}
  #smhfb .foot{display:flex;flex-wrap:wrap;align-items:center;gap:${p(8)} ${p(14)};padding:${p(10)} ${p(16)};border-top:1px solid var(--vien2);background:var(--nen)}
  #smhfb .chan{display:flex;flex-wrap:wrap;gap:${p(8)};padding:0;border:0}
  #smhfb .chan.vua{padding:0}
  #smhfb .nut{border:0;border-radius:${p(12)};padding:${p(9)} ${p(18)};font-family:inherit;font-size:${p(14.5)};white-space:nowrap;font-weight:700;cursor:pointer;background:var(--nut);color:var(--nut-chu);transition:filter .15s,transform .05s}
  #smhfb .nut:hover{filter:brightness(.93)}#smhfb .nut:active{transform:translateY(1px)}
  #smhfb .nut.chinh{background:var(--chinh-nen);color:var(--chinh-chu)}#smhfb .nut.do{background:#c0392b;color:#fff}#smhfb .nut.vang{background:#e8b64a;color:#1c1a15}
  #smhfb .nut.nho{padding:${p(5)} ${p(13)};font-size:${p(13)};border-radius:${p(9)}}
  #smhfb .chan2{display:flex;flex-wrap:wrap;align-items:center;gap:${p(2)} ${p(4)};padding:0;margin-left:auto}
  #smhfb .phu-nut{border:0;background:none;color:var(--phu);font-family:inherit;font-size:${p(12.5)};font-weight:600;padding:${p(4)} ${p(8)};border-radius:${p(7)};cursor:pointer;transition:background .15s}
  #smhfb .phu-nut:hover{background:var(--xam-nen);color:var(--chu)}
  #smhfb .phu-nut.do{color:var(--do-chu)}
  #smhfb .co{margin-left:${p(8)};display:inline-flex;align-items:center;gap:${p(2)};color:var(--phu);font-size:${p(12.5)}}
  #smhfb .co b{min-width:${p(40)};text-align:center;font-variant-numeric:tabular-nums}
  #smhfb a{color:var(--link);text-decoration:none;font-weight:600}
  #smhfb .mo{color:var(--phu);font-size:${p(12.5)}}
  #smhfb .ghichu{color:var(--do-chu);font-size:${p(12.5)};margin-top:2px}

  /* ===== 2.1: giao diện mới ===== */
  #smhfb .bar{height:53px;padding-top:0;padding-bottom:0;overflow:hidden}
  #smhfb .bar .h1{flex-wrap:nowrap;gap:0 ${p(8)}}
  #smhfb .bar .grip{display:none}
  #smhfb .bar .tt{flex:1 1 0}
  #smhfb .bar .h2{flex:none;flex-wrap:nowrap;gap:${p(4)}}
  #smhfb .bar .h2 .tg{padding:${p(2)} ${p(8)};font-size:${p(12)};flex:none}
  #smhfb .bar .nsheet{padding:${p(2)} ${p(11)};font-size:${p(14)}}
  #smhfb .tg.viec-pill{flex:none;background:#d93a3a;color:#fff;border-color:#d93a3a;font-weight:800;font-size:${p(13)};padding:${p(3)} ${p(12)}}
  #smhfb .tg.viec-pill:hover{filter:brightness(1.08)}
  #smhfb .tab{font-size:${p(15)};padding:${p(12)} ${p(15)}}
  #smhfb .tab .chip{margin-left:${p(5)};padding:0 ${p(7)}}
  #smhfb .strip{display:flex;align-items:center;gap:${p(10)};padding:${p(11)} ${p(16)};border-radius:${p(14)};margin-bottom:${p(12)};font-size:${p(16)};font-weight:700;background:var(--the);border:1px solid var(--the-vien);border-left:${p(7)} solid var(--khung)}
  #smhfb .strip .den{flex:none}
  #smhfb .strip.s-xanh{border-left-color:#2e9d57}#smhfb .strip.s-vang{border-left-color:#e0a21a}#smhfb .strip.s-do{border-left-color:#d93a3a}#smhfb .strip.s-xam{border-left-color:#9b9588}
  #smhfb .viec{background:var(--do-nen);border:1px solid #d93a3a66;border-radius:${p(14)};padding:${p(12)} ${p(16)};margin-bottom:${p(12)}}
  #smhfb .viec h3{margin:0 0 ${p(4)};font-size:${p(15.5)};color:var(--do-chu);font-weight:800}
  #smhfb .viec .vr{display:flex;gap:${p(12)};align-items:center;justify-content:space-between;padding:${p(7)} 0;border-top:1px solid #d93a3a30}
  #smhfb .viec .vr.dau{border-top:0}
  #smhfb .viec .vt{flex:1 1 ${p(200)};font-size:${p(14.5)};line-height:1.45}
  #smhfb .viec .vn{white-space:nowrap;display:flex;gap:${p(6)}}
  #smhfb .viec.ok{background:var(--xanh-nen);border-color:#2e9d5755;color:var(--xanh-chu);font-weight:700;padding:${p(8)} ${p(16)};font-size:${p(14.5)}}
  #smhfb .luoi{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:${p(12)};margin-bottom:${p(12)}}
  #smhfb .luoi.hai{grid-template-columns:repeat(2,minmax(0,1fr))}
  @media (max-width:1100px){#smhfb .luoi,#smhfb .luoi.hai{grid-template-columns:1fr}}
  #smhfb .bai{background:var(--the);border:1px solid var(--the-vien);border-top:${p(5)} solid var(--mau,#999);border-radius:${p(14)};padding:${p(12)} ${p(15)} ${p(8)};box-shadow:0 1px 2px rgba(40,30,10,.05);min-width:0}
  #smhfb .bai.b1{--mau:#2e9d57}#smhfb .bai.b2{--mau:#2f7fd1}#smhfb .bai.b3{--mau:#d98a1f}
  #smhfb .bai-h{display:flex;align-items:center;justify-content:space-between;gap:${p(8)};flex-wrap:wrap;margin-bottom:${p(6)}}
  #smhfb .bai-t{font-size:${p(20)};font-weight:800;color:var(--mau)}
  #smhfb .bai-t small{font-size:${p(12)};font-weight:600;color:var(--phu);margin-left:${p(6)}}
  #smhfb .kq{font-size:${p(14)};font-weight:800;border-radius:999px;padding:${p(3)} ${p(13)};white-space:nowrap}
  #smhfb .kq.ok{background:var(--xanh-nen);color:var(--xanh-chu)}#smhfb .kq.cho{background:var(--vang-nen);color:var(--vang-chu)}#smhfb .kq.loi{background:var(--do-nen);color:var(--do-chu)}#smhfb .kq.xam{background:var(--xam-nen);color:var(--xam-chu)}
  #smhfb .r{padding:${p(7)} 0;border-top:1px dashed var(--vien)}
  #smhfb .rl{font-size:${p(11.5)};color:var(--phu);font-weight:700;text-transform:uppercase;letter-spacing:.6px}
  #smhfb .tb-quet{display:flex;align-items:center;justify-content:space-between;gap:${p(10)};padding:${p(7)} ${p(16)};font-size:${p(13.5)};line-height:1.45;border-top:1px solid var(--vien2);cursor:default;user-select:text}
  #smhfb .tb-quet>span{min-width:0;white-space:normal;word-break:break-word}
  #smhfb .tb-quet.ok{background:var(--xanh-nen);color:var(--xanh-chu)}#smhfb .tb-quet.vang{background:var(--vang-nen);color:var(--vang-chu)}#smhfb .tb-quet.loi{background:var(--do-nen);color:var(--do-chu)}#smhfb .tb-quet.cho{background:var(--xam-nen);color:var(--xam-chu)}
  #smhfb .tb-quet .phu-nut{flex:none;white-space:nowrap}
  #smhfb .hdg{position:relative;display:flex;align-items:center;gap:${p(12)};padding:${p(8)} ${p(16)} ${p(10)};border-top:1px solid var(--vien2);font-size:${p(13.5)};line-height:1.4;cursor:default}
  #smhfb .hdg.chay{background:var(--vang-nen);color:var(--vang-chu)}#smhfb .hdg.cho{background:var(--xam-nen);color:var(--xam-chu)}
  #smhfb .hd-den{flex:none;width:${p(11)};height:${p(11)};border-radius:50%;background:#e0a21a;animation:smhHdDen 1.6s ease-out infinite}
  #smhfb .hd-den.cho{background:#9a9384;animation:smhHdNhe 2.4s ease-in-out infinite}
  @keyframes smhHdDen{0%{box-shadow:0 0 0 0 rgba(224,162,26,.6)}70%{box-shadow:0 0 0 ${p(8)} rgba(224,162,26,0)}100%{box-shadow:0 0 0 0 rgba(224,162,26,0)}}
  @keyframes smhHdNhe{0%,100%{opacity:1}50%{opacity:.35}}
  #smhfb .hd-noi{flex:1 1 auto;min-width:0}
  #smhfb .hd-ten{font-weight:700}
  #smhfb .hd-cham::after{content:"";display:inline-block;width:1.5em;text-align:left;animation:smhHdCham 1.2s steps(4,end) infinite}
  @keyframes smhHdCham{0%{content:""}25%{content:"."}50%{content:".."}75%{content:"..."}}
  #smhfb .hd-chi{font-size:${p(12.5)};opacity:.85;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
  #smhfb .hd-gio{flex:none;text-align:right;font-weight:700;font-size:${p(14)};font-variant-numeric:tabular-nums;white-space:nowrap}
  #smhfb .hd-gio small{display:block;font-size:${p(11.5)};font-weight:600;opacity:.8}
  #smhfb .hdg .phu-nut{flex:none}
  #smhfb .hd-tien{position:absolute;left:0;right:0;bottom:0;height:3px;background:rgba(224,162,26,.2)}
  #smhfb .hd-tien i{display:block;height:100%;background:#e0a21a;transition:width 1s linear}
  #smhfb .tn3{display:grid;grid-template-columns:minmax(${p(170)},.7fr) minmax(${p(260)},1.3fr) minmax(${p(240)},1fr);gap:${p(10)};margin:0 0 ${p(12)}}
  @media (max-width:900px){#smhfb .tn3{grid-template-columns:1fr}}
  #smhfb .tn.bam{cursor:pointer}#smhfb .tn.bam:hover{border-color:var(--acc);box-shadow:0 6px 16px rgba(40,30,10,.14)}#smhfb .tn.bam:active{transform:translateY(1px)}#smhfb .tn.bam.run{pointer-events:none}
  #smhfb .tn.bam .tn-nut .nut{display:flex;align-items:center;justify-content:center;pointer-events:none}
  #smhfb .tn{display:flex;flex-direction:column;gap:${p(6)};padding:${p(12)} ${p(14)};border:1.5px solid var(--vien);border-radius:${p(14)};background:var(--the);min-width:0;transition:border-color .2s,background .2s}
  #smhfb .tn-dau{display:flex;align-items:center;gap:${p(10)};min-width:0}
  #smhfb .tn-ic{flex:none;width:${p(36)};height:${p(36)};border-radius:50%;display:flex;align-items:center;justify-content:center;background:var(--xanh-nen);font-size:${p(17)};font-weight:800;line-height:1}
  #smhfb .tn-ten{display:flex;flex-direction:column;min-width:0}
  #smhfb .tn-ten b{font-size:${p(15)};font-weight:800}
  #smhfb .tn-ten span{font-size:${p(13)};font-weight:700;color:var(--chu);opacity:.85;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
  #smhfb .tn-mo{font-size:${p(12)};color:var(--phu);line-height:1.4;min-height:2.8em;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden}
  #smhfb .tn-mo.live{color:var(--vang-chu);font-weight:600}#smhfb .tn-mo.canh{color:var(--do-chu)}
  #smhfb .tn-nut{display:flex;gap:${p(6)};margin-top:auto;flex-wrap:wrap}
  #smhfb .tn-nut .nut{flex:1;min-height:${p(42)};padding:${p(9)} ${p(14)};font-size:${p(15)};border-radius:${p(11)}}
  #smhfb .seg{display:flex;flex:1;border:1.5px solid var(--vien);border-radius:${p(10)};overflow:hidden}
  #smhfb .seg button{flex:1;min-height:${p(84)};border:0;background:var(--the);padding:${p(14)} ${p(8)};font-family:inherit;font-weight:800;font-size:${p(20)};color:var(--chu);cursor:pointer;white-space:nowrap}
  #smhfb .seg button+button{border-left:1.5px solid var(--vien)}
  #smhfb .seg button:hover{background:var(--xanh-nen);color:var(--xanh-chu)}
  #smhfb .tn.run{border-color:#e0a21a;background:var(--vang-nen)}#smhfb .tn.run .tn-ic{background:#fff6dd}
  #smhfb .tn.run .tn-nut{opacity:.45;pointer-events:none}
  #smhfb .tn.xong{border-color:#2e9d57;background:var(--xanh-nen)}#smhfb .tn.xong .tn-ic{background:#2e9d57;color:#fff;animation:smhfbNay .5s ease-out}
  #smhfb .tn.vang{border-color:#d93a3a88}#smhfb .tn.vang .tn-ic{background:#d93a3a;color:#fff}
  #smhfb .xoay{display:block;width:${p(18)};height:${p(18)};border:3px solid rgba(224,162,26,.3);border-top-color:#e0a21a;border-radius:50%;animation:smhfbQuay .8s linear infinite}
  #smhfb .rv{font-size:${p(14.5)};margin-top:${p(2)};word-break:break-word;line-height:1.5}
  #smhfb .rv.phu{color:var(--phu);font-size:${p(13.5)}}
  #smhfb .rv .chip{margin-left:0;margin-right:${p(6)}}
  #smhfb .mk{font-size:${p(13)};font-weight:600;white-space:nowrap;line-height:1.6}
  #smhfb .mk.ok{color:var(--xanh-chu)}#smhfb .mk.loi{color:var(--do-chu);font-weight:800}#smhfb .mk.cho{color:var(--vang-chu);font-weight:700}#smhfb .mk.xam{color:var(--phu)}
  #smhfb table.st td{padding:${p(8)} ${p(10)}}
  #smhfb table.st tr.dau td{border-top:2px solid var(--vien)}
  #smhfb table.st tr.xa td{background:color-mix(in srgb,var(--vang-nen) 40%,transparent)}
  #smhfb table.st td.ng{white-space:nowrap;min-width:${p(118)}}
  #smhfb .ghi{font-size:${p(13)};color:var(--phu);margin:${p(2)} 0 ${p(10)}}
  #smhfb .the-nd h4{margin:0 0 ${p(8)};font-size:${p(16)};font-weight:800}
  #smhfb .kq{white-space:normal;text-align:right;line-height:1.3}
  #smhfb .tlay{display:grid;grid-template-columns:${p(400)} minmax(0,1fr);gap:${p(16)};align-items:start}
  @media (max-width:1100px){#smhfb .tlay{grid-template-columns:1fr}}
  #smhfb .tl{background:var(--nen);border:1px solid var(--the-vien);border-radius:${p(14)};padding:${p(12)} ${p(10)} ${p(6)}}
  #smhfb .tl h4{margin:0 0 ${p(10)} ${p(8)};font-size:${p(12.5)};color:var(--phu);text-transform:uppercase;letter-spacing:.8px;font-weight:800}
  #smhfb .it{position:relative;padding:${p(7)} ${p(10)} ${p(13)} ${p(56)};cursor:pointer;border-radius:${p(12)};border:2px solid transparent}
  #smhfb .it:before{content:"";position:absolute;left:${p(27)};top:${p(40)};bottom:${p(-6)};width:3px;background:var(--vien)}
  #smhfb .it:last-child:before{display:none}
  #smhfb .it .dm{position:absolute;left:${p(10)};top:${p(7)};width:${p(34)};height:${p(34)};border-radius:50%;display:flex;align-items:center;justify-content:center;font-weight:800;color:#fff;font-size:${p(13.5)};padding:0;background:#b3ad9f;overflow:visible;max-height:none}
  #smhfb .it .dm.ok{background:#2e9d57}#smhfb .it .dm.cho{background:#e0a21a}#smhfb .it .dm.loi{background:#d93a3a}#smhfb .it .dm.xam{background:#b3ad9f}
  #smhfb .it .h{font-weight:800;font-size:${p(16)};line-height:1.3}
  #smhfb .it .h .who{font-size:${p(11)};font-weight:700;color:var(--phu);background:var(--xam-nen);border-radius:99px;padding:0 ${p(7)};margin-left:${p(4)}}
  #smhfb .it .t{font-size:${p(13)};color:var(--phu)}
  #smhfb .it .tk{position:absolute;right:${p(8)};top:${p(9)};background:var(--xam-nen)}
  #smhfb .it .tk.dang{background:var(--acc);color:#fff;font-weight:800}
  #smhfb .it.sel{background:var(--the);border-color:var(--acc);box-shadow:0 4px 14px rgba(0,0,0,.08)}
  #smhfb .bai.bv{--mau:#7c5cd6}#smhfb .bai.bm{--mau:#c2418a}
  #smhfb .tg.xam{color:var(--xam-chu)}
  #smhfb .acts{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:${p(12)};margin-bottom:${p(8)}}
  #smhfb .acts.hai{grid-template-columns:repeat(2,minmax(0,1fr))}#smhfb .acts.mot{grid-template-columns:minmax(0,1fr)}
  @media (max-width:1100px){#smhfb .acts{grid-template-columns:1fr}}
  #smhfb .big{display:flex;align-items:center;gap:${p(14)};text-align:left;border:2px solid var(--vien);background:var(--the);color:var(--chu);border-radius:${p(16)};padding:${p(10)} ${p(16)};min-height:${p(66)};font-family:inherit;cursor:pointer;box-shadow:0 2px 6px rgba(40,30,10,.07);transition:transform .08s,box-shadow .15s,border-color .15s,background .15s}
  #smhfb .big:hover{border-color:var(--acc);box-shadow:0 6px 16px rgba(40,30,10,.14)}
  #smhfb .big:active{transform:translateY(1px)}
  #smhfb .big .bi{flex:none;width:${p(46)};height:${p(46)};border-radius:50%;background:var(--xanh-nen);color:var(--xanh-chu);display:flex;align-items:center;justify-content:center;font-size:${p(24)};line-height:1}
  #smhfb .big .bi span{display:inline-block}
  #smhfb .big .bt{display:flex;flex-direction:column;min-width:0}
  #smhfb .big .bt b{font-size:${p(16.5)};font-weight:800}
  #smhfb .big .bt small{font-size:${p(12.5)};color:var(--phu);margin-top:2px;line-height:1.35}
  #smhfb .big.run{border-color:#e0a21a;background:var(--vang-nen);cursor:progress;pointer-events:none}
  #smhfb .big.run .bi{background:#e0a21a;color:#fff}
  #smhfb .big.run .bi span{animation:smhfbQuay .9s linear infinite}
  #smhfb .big.xong{border-color:#2e9d57;background:var(--xanh-nen)}
  #smhfb .big.xong .bi{background:#2e9d57;color:#fff;animation:smhfbNay .5s ease-out}
  @keyframes smhfbNay{0%{transform:scale(.6)}70%{transform:scale(1.15)}100%{transform:scale(1)}}
  #smhfb .big.sheet .bi{background:var(--xam-nen);color:var(--chu)}
  `;
  }

  const vt = { keo: null, lamMoi: false };
  // vị trí + mở rộng chỉ nhớ trong tab đang mở: tải lại trang → khung về giữa phía trên, thu gọn
  const uiTab = { viTri: null, moRong: false };
  const rongKhung = () => Math.min(Math.round(1033 * coChu()), window.innerWidth - 16);
  function viTriMacDinh() { return { x: Math.max(8, Math.round((window.innerWidth - rongKhung()) / 2)), y: 0 }; /* sát mép trên, che luôn thanh nút Facebook */ }
  // p.x = vị trí ngang của thanh THU GỌN. Khi mở rộng popup nở thêm 20% sang 2 bên nhưng nút thu gọn vẫn đứng yên chỗ cũ; cao tới sát đáy màn hình
  function datViTri(el, p) {
    const Z = coChu(); const toiDa = window.innerWidth - 16;
    const wC = Math.min(Math.round(1033 * Z), toiDa), wE = Math.min(Math.round(1033 * 1.2 * Z), toiDa);
    const moRong = el.classList.contains('mo-rong'); const w = moRong ? wE : wC;
    const bx = Math.min(Math.max(0, p.x), Math.max(0, window.innerWidth - wC - 8));
    const y = Math.min(Math.max(0, p.y), Math.max(0, window.innerHeight - 40));
    const left = moRong ? Math.min(Math.max(0, bx - (wE - wC) / 2), Math.max(0, window.innerWidth - wE - 8)) : bx;
    el.dataset.bx = String(Math.round(bx));
    el.style.width = w + 'px'; el.style.left = Math.round(left) + 'px'; el.style.top = y + 'px';
    el.style.setProperty('--ext', (moRong ? Math.round(left + wE - (bx + wC)) : 0) + 'px');
    el.classList.toggle('ghim', y <= 2);
    el.style.height = moRong ? Math.max(160, window.innerHeight - y) + 'px' : '';
    el.style.maxHeight = Math.max(160, window.innerHeight - y) + 'px';
  }
  // Facebook đang ở giao diện tối? (lớp của Facebook, dự phòng: đo màu nền trang)
  function fbToi() {
    const h = document.documentElement;
    if (h.classList.contains('__fb-dark-mode')) return true;
    if (h.classList.contains('__fb-light-mode')) return false;
    const m = (getComputedStyle(document.body).backgroundColor || '').match(/\d+/g);
    return !!m && (+m[0] + +m[1] + +m[2]) / 3 < 80;
  }
  const boThe = (h) => { const d = document.createElement('div'); d.innerHTML = String(h); return d.textContent; };

  // Bài 1 đã xong → trạng thái cả ngày (Bài 1 + Bài 2 + Bài 3)
  function trangThaiCaNgay(s, daXong) {
    const hs = hangHomNay();
    if (!hs) return { den: 'xanh', chu: `✅ Bài 1 xong: ${daXong}` };
    const b23 = s.b23 || {};
    const ts = mucTieuB23(hs);
    const b1Xong = Object.values(s.bai || {}).filter(daXongTt).length;
    const tong = Math.max(s.biet_het || 0, b1Xong) + ts.length;
    const chua = ts.filter((t) => !b23[t.k]);
    const xong = tong - chua.length - (Math.max(s.biet_het || 0, b1Xong) - b1Xong);
    const docCmtDuoc = !coApi() || !!(lay('suc_khoe', {}) || {}).cmtOk || !(lay('suc_khoe', {}) || {}).cmtLuc;
    const b1CanKiem = Object.values(s.bai || {}).some((b) => (daXongTt(b) || b.tt === 'da_dang') && b.cmtTrangThai !== 'xac_nhan');
    const thieuCmt = ts.filter((t) => t.cmt && b23[t.k] && b23[t.k].id && !b23[t.k].cmt);
    const ten = (t) => `Bài ${t.loai}${hs.length > 1 ? ` (h${t.hang})` : ''}`;
    const cmtChu = !thieuCmt.length ? (b1CanKiem ? ' · comment Bài 1 cần kiểm tra' : '') : docCmtDuoc ? ` · ${thieuCmt.map((t) => `${ten(t)} chưa thấy ${tenCmt(t)}`).join(', ')}` : ' · chưa đọc được comment (cần cài lại mã khoá)';
    const ngayHt = homNay().replace(/-/g, '/');
    if (!chua.length) return { den: b1CanKiem || thieuCmt.length && phutTrongNgay(new Date()) >= docGio(CAI_DAT.GIO_NHAC_BAI23) ? 'vang' : 'xanh', chu: `✅ Đủ ${xong}/${tong} bài hôm nay (${ngayHt})${cmtChu}` };
    if (phutTrongNgay(new Date()) < docGio(CAI_DAT.GIO_NHAC_BAI23)) return { den: 'xanh', chu: `Đã có ${xong}/${tong} bài hôm nay (${ngayHt}) · chờ ${chua.map(ten).join(', ')}${cmtChu}` };
    return { den: 'vang', chu: `⚠ ${xong}/${tong} bài hôm nay (${ngayHt}) · chưa thấy ${chua.map(ten).join(', ')} trên trang${cmtChu}` };
  }

  function tinhTrangDuLieu() {
    const st = lay('sap_toi', null), sk = lay('suc_khoe', {}) || {}, gate = chanLark();
    const coHom = !!(st && st.ds && st.ds.some((x) => x.ngay === homNay()));
    const dungCu = !!(st && coHom && Date.now() - st.luc < 36 * 3600e3); // còn dữ liệu đã lưu dùng được → script vẫn chạy bình thường
    const cu = !st || !coHom || (trongGioDocSheet() && !gate && Date.now() - st.luc > 240 * 60000);
    return { canh: !dungCu || (!gate && sk.larkOk === false) || (!gate && !!cu), st, gate, cu, dungCu };
  }
  function trangThaiChinh() {
    const t = trangThaiCongViec(), dl = tinhTrangDuLieu();
    if (dl.canh) {
      if (t.den === 'xanh') t.den = 'vang';
      t.chu += dl.gate || (lay('suc_khoe', {}) || {}).larkOk === false ? ' · ⚠ Lark lỗi' : ' · ⚠ Dữ liệu chưa mới';
    }
    return t;
  }
  function trangThaiCongViec() {
    const ngay = homNay(); const s = lay('ngay_' + ngay, null) || { bai: {} };
    const dd = lay('dang_do', null);
    const now = Date.now(); const m = phutTrongNgay(new Date());
    const bai = Object.values(s.bai || {});
    const daXong = bai.filter(daXongTt).map((b) => `hàng ${b.hang} ${b.tt === 'co_san' ? '(có sẵn)' : 'lúc ' + gioStr(new Date(b.luc))}`).join(', ');
    if (lay('tam_dung', false)) return { den: 'xam', chu: '⏸ Đang tạm dừng' + (dd ? ' · có việc dở cần xác minh/tiếp tục' : ' — bấm Chạy lại để tiếp tục') };
    if (lay('soan_thu', null)) return { den: 'vang', nhay: true, chu: 'Đang soạn thử…' };
    const qd = lay('quet_dang', null);
    if (dangQuet || (qd && Date.now() - qd.luc < 90000)) return { den: 'vang', nhay: true, chu: 'Đang quét Thích &amp; gắn thẻ video… ' + esc((dangQuet ? buocQuet : qd.buoc) || '') };
    if (dd) return { den: 'vang', nhay: true, chu: dd.loai ? `Đang ${dd.buoc === 'kiem_bai' ? 'kiểm tra' : 'comment'} ${dd.ten || 'Bài ' + dd.loai}${dd.ngoai ? '' : ' (hàng ' + dd.hang + ')'}${dd.cmts && dd.buoc !== 'kiem_bai' ? ` · comment ${Math.min((dd.cmtIdx || 0) + 1, dd.cmts.length)}/${dd.cmts.length}` : ''}…` : (dd.buoc === 'kiem_bai' ? `Đang kiểm tra bài hàng ${dd.hang} đã lên trang…` : `Đang comment bài hàng ${dd.hang}…`) };
    { const ct = lay('b23_cho_tay', null); if (ct && ct.ngay === ngay) return { den: 'vang', nhay: true, chu: `CHẠY THỬ: đã soạn sẵn Bài ${ct.loai} — kiểm tra rồi bấm Đăng (script sẽ tự comment)` }; }
    if (dangBan) return { den: 'vang', nhay: true, chu: `Đang làm việc với hàng ${hangSapDang || ''}…` };
    if (!dangTuDongBat()) { const it = lichHomNay().items.filter((i) => !i.ngoai); return { den: 'xam', chu: `⏸ Đăng bài đang TẠM DỪNG trên máy này · hôm nay đã lên ${it.filter((i) => i.xong).length}/${it.length} bài` }; }
    if (s.dungB23) return { den: 'do', chu: '⛔ Đã dừng Bài 2/3 hôm nay — cần vào trang kiểm tra tay' };
    if (s.dung) return { den: 'do', chu: '⛔ Đã dừng hôm nay — cần vào trang kiểm tra tay' };
    if (s.huy) return { den: 'xam', chu: 'Đã hủy đăng hôm nay' };
    if (s.xong) return trangThaiCaNgay(s, daXong);
    if (s.daChot) return { den: 'do', chu: `Quá ${CAI_DAT.GIO_CHOT} chưa đăng được — cần đăng tay` };
    if (demNguocDen) return { den: 'vang', nhay: true, dem: true, chu: `Sắp đăng hàng ${hangSapDang || ''} · còn <b data-dem>${conLai(demNguocDen - now)}</b>` };
    if (s.loi) return { den: 'do', nhay: true, chu: '⚠ ' + esc(s.loi.msg) };
    if (s.choDen && s.choDen > now) return { den: 'vang', chu: `Chờ giãn cách đến ${gioStr(new Date(s.choDen))}` };
    // Tự kiểm là kết quả lịch sử; trạng thái tab hiện tại có ở mục Kiểm tra hệ thống.
    if (s.gio != null && m < s.gio) return { den: 'xanh', chu: `Chờ đăng lúc <b>${phutStr(s.gio)}</b> · còn <b data-hen="${lucPhut(s.gio)}">${conLai(lucPhut(s.gio) - now)}</b>` };
    if (daXong) return { den: 'vang', chu: `Đã đăng ${daXong} · còn bài chờ` };
    return { den: 'vang', chu: 'Đến giờ đăng — đang chuẩn bị…' };
  }

  // Nội dung sheet của ngày mai — tính từ lần đọc sheet mới nhất (tự làm mới 30 phút/lần hoặc bấm ↻)
  // chiBC = true: chỉ xét cột B, C (2 cột script cần để tự đăng Bài 1)
  function thieuCuaNgay(n, chiBC = false) {
    if (!n.hangs.length) return ['chưa có hàng nào ở cột H'];
    const t = [];
    for (const h of n.hangs) {
      if (!h.bai) t.push(`hàng ${h.hang} thiếu cột B`);
      if (!h.cmt) t.push(`hàng ${h.hang} thiếu cột C`);
      if (h.bai && h.bai.length > CAI_DAT.GIOI_HAN_KY_TU_NEN) t.push(`hàng ${h.hang} quá ${CAI_DAT.GIOI_HAN_KY_TU_NEN} ký tự`);
      thieuAnhHang(h).forEach((x) => t.push(x));
      if (chiBC) continue;
      if (!h.bai2) t.push(`hàng ${h.hang} thiếu cột D`);
      if (!h.cmt2) t.push(`hàng ${h.hang} thiếu cột E`);
      if (!h.bai3) t.push(`hàng ${h.hang} thiếu cột F`);
    }
    return t;
  }
  function trangThaiMai() {
    const st = lay('sap_toi', null); const mai = ngayMai();
    if (!st) return { lop: '', chu: 'Mai: chưa đọc sheet', title: 'Vào tab Sắp tới, bấm Đọc lại Lark sheet' };
    if (st.loiCot) return { lop: 'loi', chu: 'Sheet: sai tên cột', title: st.loiCot };
    const n = (st.ds || []).find((x) => x.ngay === mai);
    if (!n) return { lop: '', chu: 'Mai: chưa đọc sheet', title: 'Vào tab Sắp tới, bấm Đọc lại Lark sheet' };
    const t = thieuCuaNgay(n);
    if (tinhTrangDuLieu().canh) return { lop: 'cho', chu: 'Mai ' + mai.slice(0, 5) + ': dữ liệu cũ', title: 'Chưa xác minh được nội dung mới. Lần đọc: ' + ngayStr(new Date(st.luc)) + ' ' + gioStr(new Date(st.luc)) };
    const gioDoc = `Đọc sheet lúc ${gioStr(new Date(st.luc))}`;
    if (!t.length) return { lop: 'ok', chu: `Mai ${mai.slice(0, 5)}: ✓ đủ${n.hangs.length > 1 ? ` (${n.hangs.length} bài)` : ''}`, title: gioDoc };
    const gap = phutTrongNgay(new Date()) >= docGio(CAI_DAT.GIO_KIEM_TRUOC);
    return { lop: gap ? 'loi' : 'cho', chu: `Mai ${mai.slice(0, 5)}: ${t[0]}${t.length > 1 ? ` +${t.length - 1}` : ''}`, title: t.join('; ') + ' · ' + gioDoc + (gap ? '' : ` · trước ${CAI_DAT.GIO_KIEM_TRUOC} chỉ nhắc trên khung, chưa báo nhóm`) };
  }

  // ===== 2.1: các mục "việc cần xử lý" + thanh trên cùng =====
  const daDangHomNay = (s, loai, hang) => (loai === 1
    ? Object.values(s.bai || {}).some((b) => b.hang === hang && (b.tt === 'xong' || b.tt === 'co_san' || b.tt === 'da_dang'))
    : !!(s.b23 && s.b23[loai + '|' + hang]));
  // Nội dung còn thiếu của 1 ngày, nói bằng lời dễ hiểu. hom = trạng thái hôm nay (chỉ truyền khi n là hôm nay: bài nào đã đăng rồi thì không tính thiếu nữa)
  function thieuNgan(n, hom) {
    const out = []; const nhieu = n.hangs.length > 1; const GH = CAI_DAT.GIOI_HAN_KY_TU_NEN;
    if (!n.hangs.length) return [{ loai: 0, hang: 0, t: 'chưa có hàng nào mang ngày này ở cột H' }];
    for (const h of n.hangs) {
      const them = (loai, t) => { if (hom && daDangHomNay(hom, loai, h.hang)) return; out.push({ loai, hang: h.hang, t: (nhieu ? `hàng ${h.hang}: ` : '') + t }); };
      if (!h.bai) them(1, 'chữ Bài 1'); else if (h.bai.length > GH) them(1, `Bài 1 quá ${GH} ký tự`);
      if (!h.cmt) them(1, 'comment Bài 1');
      if (!h.bai2) them(2, 'chữ Bài 2');
      if (!h.cmt2) them(2, 'comment Bài 2');
      if (h.bai2 && !h.a2) them(2, 'ảnh Bài 2');
      if (!h.bai3) them(3, 'chữ Bài 3');
      if (h.bai3 && !h.a3) them(3, 'ảnh Bài 3');
      if (h.bai3 && !h.ac) them(3, 'ảnh comment Bài 3');
    }
    return out;
  }
  // Chỉ xét N ngày gần nhất (hôm nay + các ngày kế tiếp) để cảnh báo thiếu
  function ngayCanhBao() {
    const st = lay('sap_toi', null); if (!st || !st.ds || st.loiCot) return [];
    const hom = lay('ngay_' + homNay(), null) || {};
    return st.ds.slice(0, CAI_DAT.CANH_BAO_THIEU_NGAY).map((n) => ({ n, ds: thieuNgan(n, n.ngay === homNay() ? hom : null) })).filter((x) => x.ds.length);
  }
  const nhanNgay = (n) => `${n.thu} ${n.ngay.slice(0, 5).replace('-', '/')}`;
  const nhanNgayDai = (n) => nhanNgay(n) + (n.ngay === homNay() ? ' (hôm nay)' : n.ngay === ngayMai() ? ' (ngày mai)' : '');
  function soVideoLoi() {
    const vs = vidState(); const han = Date.now() - 26 * 3600e3;
    return Object.keys(vs).filter((id) => vs[id].tt === 'loi' && vs[id].gio && vs[id].gio > han).length;
  }

  // ===== 2.2: lịch cả ngày (3 bài script đăng + video/manifest do nhân sự đăng) =====
  const lopTt = (tt) => (tt === 'xong' ? 'ok' : tt === 'do' ? 'loi' : tt === 'vang' ? 'cho' : 'xam');
  function lichHomNay() {
    const ngay = homNay(); const s = lay('ngay_' + ngay, null) || { bai: {} }; const hs = hangHomNay(); const m = phutTrongNgay(new Date());
    const dsH = hs && hs.length ? hs : [null]; const nhieu = dsH.length > 1; const items = [];
    const muc = (gioDK, xong, loi) => (xong ? 'xong' : loi ? 'do' : m >= gioDK + 60 ? 'do' : m >= gioDK + 30 ? 'vang' : 'cho');
    const bai1 = Object.values(s.bai || {});
    const hh = (h) => (nhieu && h ? ` (hàng ${h.hang})` : '');
    dsH.forEach((h) => {
      const b = h ? bai1.find((x) => x.hang === h.hang) : null;
      const gio = s.gio != null ? s.gio : docGio(CAI_DAT.GIO_DANG_TU);
      const xong = !!(b && (b.tt === 'xong' || b.tt === 'co_san' || b.tt === 'da_dang'));
      const loi = !!(s.loi || s.dung || s.daChot);
      items.push({ k: 'b1|' + (h ? h.hang : 0), ten: 'Bài 1' + hh(h), ky: 'B1', loai: 'b1', khung: CAI_DAT.GIO_DANG_TU + '–' + CAI_DAT.GIO_DANG_DEN, gioDK: gio, daCoGio: s.gio != null, xong, luc: b ? b.luc : 0, link: b ? b.link : '', loi, tt: s.huy && !xong ? 'huy' : muc(gio, xong, loi), h, b });
    });
    for (const loai of [2, 3]) dsH.forEach((h) => {
      const t = h ? mucTieuB23([h])[loai - 2] : null; const r = t ? (s.b23 || {})[t.k] : null; const g = s['gio' + loai];
      const tu = loai === 2 ? CAI_DAT.GIO_BAI2_TU : CAI_DAT.GIO_BAI3_TU; const den = loai === 2 ? CAI_DAT.GIO_BAI2_DEN : CAI_DAT.GIO_BAI3_DEN;
      const gio = g != null ? g : docGio(tu);
      const loi = !!(t && ((s.loiB23 || {})[t.k] || !t.text));
      items.push({ k: `b${loai}|` + (h ? h.hang : 0), ten: `Bài ${loai}` + hh(h), ky: 'B' + loai, loai: 'b' + loai, khung: tu + '–' + den, gioDK: gio, daCoGio: g != null, xong: !!r, luc: r ? r.luc : 0, link: r ? r.link : '', tay: !!(r && r.tt === 'tay'), loi, tt: muc(gio, !!r, loi), h, t, r });
    });
    CAI_DAT.LICH_NGOAI.forEach((x) => {
      const r = (s.lich || {})[x.k]; const gio = docGio(x.gio);
      items.push({ k: x.k, ten: x.ten, ky: x.ky, loai: x.loai, ngoai: true, gioDK: gio, daCoGio: true, xong: !!r, luc: r ? r.luc : 0, link: r ? r.link : '', tay: !!(r && r.tay), tt: muc(gio, !!r, false) });
    });
    items.sort((a, b) => a.gioDK - b.gioDK);
    return { s, items, nhieu };
  }
  // dòng giờ + dòng mô tả của 1 mục trong lịch
  function nhanLich(it) {
    const m = phutTrongNgay(new Date()); const le = m - it.gioDK;
    const gioDK = it.daCoGio ? phutStr(it.gioDK) : it.khung;
    if (it.xong) {
      const lr = it.ngoai ? (((lay('ngay_' + homNay(), null) || {}).lich || {})[it.k] || {}) : {};
      const cm = !it.ngoai ? '' : lr.cmt ? (lr.cmt.ok ? ' · đã comment ✓' : ' · comment cần kiểm tra') : lr.cmtDang ? ' · đang comment…' : '';
      return { gio: gioStr(new Date(it.luc)), mo: `Đã đăng lúc ${gioStr(new Date(it.luc))}${it.tay ? ' (tick tay)' : ''}${cm}` };
    }
    if (it.tt === 'huy') return { gio: gioDK, mo: 'Đã hủy hôm nay' };
    if (it.loi) return { gio: gioDK, mo: 'Có lỗi — bấm để xem' };
    if (le >= 30) return { gio: gioDK, mo: `Dự kiến ${gioDK} · quá ${le} phút chưa thấy` };
    return { gio: gioDK, mo: it.ngoai ? `Dự kiến ${gioDK} · đăng tay` : `Tự động · ${it.daCoGio ? 'hẹn' : 'khung'} ${gioDK}` };
  }

  // Thanh trên cùng: 8 ô nhỏ — xanh = đã lên trang, xám = chưa, vàng/đỏ = quá giờ
  function dongThoiGian() {
    const { items } = lichHomNay();
    return items.map((it) => {
      const nl = nhanLich(it);
      const coLink = /^https?:/.test(it.link || '');
      return `<button class="tg ${lopTt(it.tt)}" data-a="${coLink ? 'mobai' : 'chon'}" data-k="${esc(it.k)}"${coLink ? ` data-link="${esc(it.link)}"` : ''} title="${esc(it.ten + ' · ' + nl.mo + (coLink ? ' · bấm để mở bài' : ''))}">${it.xong ? '✓ ' : ''}${it.ky}</button>`;
    }).join('');
  }

  // ---- "Việc cần xử lý": gom mọi thứ cần người làm vào 1 chỗ ----
  function viecCanXuLy() {
    const ds = [];
    const vs = vidState(); const han = Date.now() - 26 * 3600e3;
    Object.keys(vs).map((id) => Object.assign({ id }, vs[id])).filter((v) => v.tt === 'loi' && v.gio && v.gio > han).sort((a, b) => b.gio - a.gio).forEach((v) => {
      ds.push({ k: 'vid_' + v.id, chu: `Quét: video lúc ${gioStr(new Date(v.gio))} chưa tự gắn được thẻ/cảm xúc`, tip: v.loi || '', nut: [v.link ? ['↗ Mở video', 'mobai', `data-link="${esc(v.link)}"`] : null, ['Đã gắn tay', 'gantay', `data-id="${esc(v.id)}"`]].filter(Boolean) });
    });
    { const cb = ngayCanhBao(); // gom tất cả ngày còn thiếu thành 1 việc
      if (cb.length) {
        const coAnh = cb.some((x) => x.ds.some((y) => /ảnh/.test(y.t)));
        const ngays = cb.map((x) => x.n.ngay.slice(0, 5).replace('-', '/'));
        ds.push({ k: 'thieu|' + cb.map((x) => x.n.ngay + ':' + x.ds.length).join(','), chu: `Cập nhật ${coAnh ? 'ảnh bài viết' : 'nội dung bài viết'} cho các ngày ${ngays.join(', ')}`, tip: cb.map((x) => `${nhanNgayDai(x.n)} còn thiếu: ${x.ds.map((y) => y.t).join(', ')}`).join('\n'), nut: [['▦ Mở sheet', 'mosheet', '']] });
      } }
    { const mm = phutTrongNgay(new Date()); const qua = lichHomNay().items.filter((it) => it.ngoai && !it.xong && mm >= it.gioDK + 60);
      if (qua.length) { const it = qua[0]; ds.push({ k: 'lich|' + it.k, chu: `Đăng bài tiếp theo: ${it.ten} (dự kiến ${phutStr(it.gioDK)})`, tip: qua.map((x) => `${x.ten} (dự kiến ${phutStr(x.gioDK)}) chưa thấy lên trang`).join('\n'), nut: [['✓ Đã đăng — tick', 'ticklich', `data-k="${it.k}"`]] }); } }
    const st = lay('sap_toi', null);
    if (st && st.chung && (!st.chung.co || !st.chung.pool)) ds.push({ k: 'anhchung' + (st.chung.co ? 1 : 0) + st.chung.pool, chu: 'Cập nhật ảnh cố định cho comment Bài 3', tip: `Ảnh cố định comment Bài 3 chưa đủ${st.chung.co ? '' : ' (chưa có ảnh chính)'}${st.chung.pool ? '' : ' (chưa có ảnh dự phòng)'}`, nut: [['▦ Mở sheet', 'mosheet', '']] });
    if (!coApi()) ds.push({ k: 'chuama', chu: 'Chưa cài mã khoá Facebook (script chưa đọc/quét được bài)', nut: [['🔑 Cài mã khoá', 'caima', '']] });
    else { const luc = lay('fb_token_luc', 0); const n = luc ? Math.floor((Date.now() - luc) / 864e5) : 0; if (n >= CAI_DAT.MA_KHOA_HAN_NGAY - 10) ds.push({ k: 'hetma', chu: `Mã khoá Facebook đã dùng ${n} ngày — nên lấy mã mới`, nut: [['🔑 Đổi mã khoá', 'caima', '']] }); }
    const dl = tinhTrangDuLieu();
    if (dl.canh) ds.push({ k: 'dulieu', chu: dl.gate ? dl.gate.msg : 'Dữ liệu sheet chưa được cập nhật', nut: [['Kiểm tra kết nối lại', 'ketnoi', '']] });
    return ds;
  }
  function theViec() {
    const ds = viecCanXuLy();
    if (!ds.length) return '<div class="viec ok">✓ Không có việc nào cần bạn xử lý</div>';
    return `<div class="viec"><h3>⚠ ${ds.length} việc cần bạn xử lý</h3>${ds.map((v, i) => `<div class="vr${i ? '' : ' dau'}" title="${esc(v.tip || '')}"><span class="vt">${esc(v.chu)}</span><span class="vn">${v.nut.map(([t, a, x]) => `<button class="nut nho${a === 'gantay' || a === 'caima' ? ' chinh' : ''}" data-a="${a}" ${x}>${t}</button>`).join(' ')}</span></div>`).join('')}</div>`;
  }
  // nút đỏ riêng trên thanh tiêu đề: có việc là thấy ngay, bấm để xem là việc gì
  function chipViec() {
    const ds = viecCanXuLy(); if (!ds.length) return '';
    return `<button class="tg viec-pill" data-a="moviec" title="${esc(ds.map((v) => '• ' + v.chu).join('\n'))}">⚠ ${ds.length} việc</button>`;
  }
  // chip quét trên thanh tiêu đề: CHỈ nói về việc quét Thích/gắn thẻ video
  function chipQuet() {
    const s = lay('ngay_' + homNay(), null) || {}; const moiNhat = Object.values(s.quet || {}).sort((a, b) => b.luc - a.luc)[0];
    const dang = quetDangChay() || !!lay('quet_link', null); const loiV = soVideoLoi();
    const chu = dang ? '🧹 Quét: đang chạy…' : `🧹 Quét ${moiNhat ? gioStr(new Date(moiNhat.luc)) + ' ✓' : ''}${loiV ? ` · ${loiV} video lỗi` : ''}`;
    return `<button class="tg ${dang ? 'cho' : loiV ? 'loi' : moiNhat ? 'ok' : 'xam'}" data-a="moquet" title="Quét Thích &amp; gắn thẻ video — bấm để xem tab Quét">${chu}</button>`;
  }

  // âm báo + chớp tiêu đề tab khi có việc MỚI cần người xử lý (chỉ tab đang làm việc báo; tab hiện lại thì thôi chớp)
  const TIEN_TO_CHOP = '⚠ Cần xem — ';
  let chopTimer = 0, chopCan = false;
  function chopTieuDe(bat) {
    if (!bat) { if (chopTimer) { clearInterval(chopTimer); chopTimer = 0; } document.title = document.title.replace(TIEN_TO_CHOP, ''); return; }
    if (chopTimer) return;
    let b = false;
    chopTimer = setInterval(() => { b = !b; const cur = document.title.replace(TIEN_TO_CHOP, ''); document.title = b ? TIEN_TO_CHOP + cur : cur; }, 1000);
  }
  function amBao() {
    try {
      const C = window.AudioContext || window.webkitAudioContext; if (!C) return;
      const c = new C(); const o = c.createOscillator(); const g = c.createGain();
      o.type = 'sine'; o.frequency.value = 880; g.gain.setValueAtTime(0.12, c.currentTime); g.gain.exponentialRampToValueAtTime(0.001, c.currentTime + 0.6);
      o.connect(g); g.connect(c.destination); o.start(); o.stop(c.currentTime + 0.65); setTimeout(() => { try { c.close(); } catch (e) { /* */ } }, 900);
    } catch (e) { /* */ }
  }
  function kiemViecMoi() {
    if (!laTabChinh()) { if (chopCan) { chopCan = false; chopTieuDe(false); } return; }
    const ds = viecCanXuLy(); const sig = ds.map((v) => v.k).join('|');
    if (!ds.length) { if (lay('viec_sig', '')) luu('viec_sig', ''); chopCan = false; chopTieuDe(false); return; }
    if (sig !== lay('viec_sig', '')) {
      const moi = ds.some((v) => !(lay('viec_sig', '') || '').split('|').includes(v.k));
      luu('viec_sig', sig);
      if (moi && lay('ui_am_bao', true)) { amBao(); chopCan = true; }
    }
    if (chopCan && document.visibilityState !== 'visible') chopTieuDe(true); else if (document.visibilityState === 'visible') { chopCan = false; chopTieuDe(false); }
  }
  document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'visible') { chopCan = false; chopTieuDe(false); } });
  setInterval(kiemViecMoi, 20000);

  // ===== 2.1: các tab =====
  const cat = (t, n) => { t = String(t || ''); return t.length > n ? t.slice(0, n) + '…' : t; };
  const hang_ = (loai, nhan, nd) => `<div class="r"><div class="rl">${nhan}</div><div class="rv">${nd}</div></div>`;
  const chipAnh = (n, nhan) => (n ? `<span class="chip ok">${n} ảnh</span>` : '<span class="chip loi">Chưa có ảnh</span>') + `<span class="mo">${nhan}</span>`;

  // thẻ Bài 1 của một hàng
  function theBai1(h, s, ngay, nhieuHang) {
    const b = Object.values(s.bai || {}).find((x) => x.hang === h.hang);
    const m = phutTrongNgay(new Date()); let kq;
    if (b) kq = b.tt === 'xong' ? ['ok', `✓ Đã đăng ${gioStr(new Date(b.luc))}`] : b.tt === 'co_san' ? ['ok', '✓ Có sẵn trên trang'] : b.tt === 'da_dang' ? ['cho', `Đã đăng ${gioStr(new Date(b.luc))} · chờ comment`] : ['loi', 'Không rõ đã lên chưa'];
    else if (s.huy) kq = ['xam', 'Đã hủy hôm nay'];
    else if (s.dung || s.daChot) kq = ['loi', 'Chưa đăng được — cần đăng tay'];
    else if (s.loi) kq = ['loi', 'Lỗi'];
    else if (demNguocDen) kq = ['cho', `Sắp đăng · còn <span data-dem>${conLai(demNguocDen - Date.now())}</span>`];
    else if (s.gio != null && m < s.gio) kq = ['cho', `Chờ ${phutStr(s.gio)} · còn <span data-hen="${lucPhut(s.gio)}">${conLai(lucPhut(s.gio) - Date.now())}</span>`];
    else kq = ['cho', 'Đến giờ — đang chuẩn bị…'];
    const dai = (h.bai || '').length;
    let html = `<div class="bai b1"><div class="bai-h"><span class="bai-t">Bài 1${nhieuHang ? `<small>hàng ${h.hang}</small>` : ''}</span><span class="kq ${kq[0]}">${kq[1]}</span></div>`;
    html += hang_(1, `Giờ đăng`, `<b>${s.gio != null ? phutStr(s.gio) : '—'}</b>${b && b.soNhom ? ` · ${b.soNhom} nhóm` : ''}`);
    html += hang_(1, `Nội dung · cột B <span class="chip ${!dai || dai > CAI_DAT.GIOI_HAN_KY_TU_NEN ? 'loi' : 'ok'}">${dai}/${CAI_DAT.GIOI_HAN_KY_TU_NEN} ký tự</span>`, h.bai ? `<span class="rv phu">${esc(cat(h.bai, 150))}</span>` : '<span class="chip loi">Trống</span>');
    const cmtTt = !b ? '<span class="chip xam">Chờ đăng bài</span>' : b.cmtTrangThai === 'xac_nhan' ? '<span class="chip ok">✓ Đã thấy comment</span>' : b.cmtTrangThai === 'cho' ? '<span class="chip cho">Còn chờ gửi</span>' : '<span class="chip cho">Cần kiểm tra</span>';
    html += hang_(1, 'Comment · cột C', `${h.cmt ? cmtTt : '<span class="chip loi">Cột C trống</span>'}${h.cmt ? `<div class="rv phu">${esc(cat(h.cmt, 100))}</div>` : ''}`);
    if (b && locGhiChu(b.ghiChu).length) html += `<div class="ghichu">⚠ ${esc(locGhiChu(b.ghiChu).join('; '))}</div>`;
    if (b && b.tt !== 'co_san') html += hang_(1, 'Bài trên trang', b.link ? `<a href="#" data-a="mobai" data-link="${esc(b.link)}">Mở bài ↗</a>` : '<span class="mo">Chưa có link — script tự lấy trong vài phút</span>');
    return html + '</div>';
  }

  // thẻ Bài 2 / Bài 3 của một hàng
  function theBai23(t, h, s, ngay, nhieuHang) {
    const r = (s.b23 || {})[t.k]; const le = (s.loiB23 || {})[t.k]; const g = s['gio' + t.loai]; const ct = lay('b23_cho_tay', null);
    const m = phutTrongNgay(new Date()); const truoc = m < docGio(CAI_DAT.GIO_NHAC_BAI23); let kq;
    if (r && r.tt === 'tay') kq = ['ok', '✓ Đã đăng (đánh dấu tay)'];
    else if (r) kq = ['ok', `✓ Đã đăng ${r.gan ? '~' : ''}${gioStr(new Date(r.luc))}`];
    else if (!t.text) kq = ['loi', `Cột ${t.cot} trống`];
    else if (ct && ct.k === t.k) kq = ['cho', 'Chờ Cao bấm Đăng (chạy thử)'];
    else if (le) kq = ['loi', 'Lỗi — chưa đăng được'];
    else if (g != null && m < g) kq = ['cho', `Chờ ${phutStr(g)} · còn <span data-hen="${lucPhut(g)}">${conLai(lucPhut(g) - Date.now())}</span>`];
    else kq = truoc ? ['cho', g != null ? `Đang trong khung đăng (hẹn ${phutStr(g)})` : 'Chưa đăng'] : ['loi', 'Chưa thấy trên trang'];
    let html = `<div class="bai b${t.loai}"><div class="bai-h"><span class="bai-t">Bài ${t.loai}${nhieuHang ? `<small>hàng ${h.hang}</small>` : ''}</span><span class="kq ${kq[0]}">${kq[1]}</span></div>`;
    html += hang_(t.loai, 'Giờ đăng (tự động)', `<b>${t.loai === 2 ? CAI_DAT.GIO_BAI2_TU + '–' + CAI_DAT.GIO_BAI2_DEN : CAI_DAT.GIO_BAI3_TU + '–' + CAI_DAT.GIO_BAI3_DEN}</b>${g != null ? ` · hẹn <b>${phutStr(g)}</b>` : ''}`);
    html += hang_(t.loai, `Nội dung · cột ${t.cot}`, t.text ? `<span class="rv phu">${esc(cat(t.text, 150))}</span>` : '<span class="chip loi">Trống</span>');
    if (t.text) html += hang_(t.loai, `Ảnh của bài · ô ${t.loai === 2 ? 'I–K' : 'L–N'}`, chipAnh(t.loai === 2 ? h.a2 : h.a3, ''));
    if (t.loai === 3 && t.text) html += hang_(3, 'Ảnh comment · ô O–Q', chipAnh(h.ac, ''));
    let cm;
    if (t.loai === 2) cm = !t.cmt ? '<span class="chip loi">Cột E trống</span>' : !r ? '<span class="chip xam">Chờ đăng bài</span>' : r.cmt ? '<span class="chip ok">✓ Đã thấy comment</span>' : !r.id ? `<span class="chip xam">${coApi() ? 'Đang lấy thông tin bài… (tab Sắp tới → Kiểm tra bài)' : 'Chưa cài mã khoá'}</span>` : '<span class="chip cho">Chưa thấy comment</span>';
    else cm = !t.text ? '<span class="chip xam">—</span>' : !r ? '<span class="chip xam">Chờ đăng bài</span>' : r.cmt ? `<span class="chip ok">✓ Đã thấy comment</span>${r.cmt.anh ? `<span class="mo">${r.cmt.anh} comment ảnh</span>` : ''}` : !r.id ? `<span class="chip xam">${coApi() ? 'Đang lấy thông tin bài… (tab Sắp tới → Kiểm tra bài)' : 'Chưa cài mã khoá'}</span>` : '<span class="chip cho">Chưa thấy comment</span>';
    html += hang_(t.loai, t.loai === 2 ? 'Comment · ô E' : 'Comment · chữ cố định + ảnh', cm + (t.loai === 2 && t.cmt ? `<div class="rv phu">${esc(cat(t.cmt, 100))}</div>` : ''));
    if (le && !r) html += `<div class="ghichu">⚠ ${esc(le.msg)}</div>`;
    let nut = '';
    if (r && r.tt === 'tay') nut = `<button class="phu-nut" data-a="bodanhdau" data-k="${t.k}">Bỏ đánh dấu</button>`;
    else if (r && r.link) nut = `<a href="#" data-a="mobai" data-link="${esc(r.link)}">Mở bài ↗</a>`;
    else if (!r && t.text) nut = `<button class="nut nho chinh" data-a="dangb23" data-k="${t.k}" title="Đăng Bài ${t.loai} ngay, bỏ qua giờ hẹn">▶ Đăng Bài ${t.loai} ngay</button> <button class="phu-nut" data-a="danhdau" data-k="${t.k}" title="Bài đã lên trang mà script chưa nhận ra">Đánh dấu đã đăng</button>`;
    if (nut) html += `<div class="r">${nut}</div>`;
    return html + '</div>';
  }

  // thẻ chi tiết của video / manifest do nhân sự đăng
  function theLichNgoai(it, s) {
    const m = phutTrongNgay(new Date());
    const kq = it.xong ? ['ok', `✓ Đã đăng ${gioStr(new Date(it.luc))}${it.tay ? ' (tick tay)' : ''}`] : it.tt === 'do' ? ['loi', 'Quá giờ — chưa thấy bài'] : it.tt === 'vang' ? ['cho', 'Quá giờ một chút — chưa thấy bài'] : ['xam', 'Chưa đăng'];
    let h = `<div class="bai ${it.loai === 'video' ? 'bv' : 'bm'}"><div class="bai-h"><span class="bai-t">${esc(it.ten)}<small>đăng tay</small></span><span class="kq ${kq[0]}">${kq[1]}</span></div>`;
    h += hang_(0, 'Giờ dự kiến', `<b>${phutStr(it.gioDK)}</b>`);
    h += hang_(0, 'Giờ đăng thực tế', it.xong ? `<b>${gioStr(new Date(it.luc))}</b>` : '<span class="mo">Chưa có</span>');
    h += hang_(0, 'Script nhận ra bài bằng', it.loai === 'video' ? 'Bài dạng video / reel trên trang (không có chữ #Manifest)' : 'Bài có chữ #Manifest');
    let kiem;
    if (it.xong && !it.tay) kiem = '<span class="chip ok">Script đã tự nhận ra bài</span>';
    else if (it.xong) kiem = '<span class="chip ok">Đã tick tay</span>';
    else if (!coApi()) kiem = '<span class="chip loi">Chưa cài mã khoá — hãy tick tay khi bài đã lên</span>';
    else if (m < it.gioDK + CAI_DAT.LICH_KIEM_SAU_PHUT) kiem = `<span class="chip xam">Bắt đầu kiểm lúc ${phutStr(it.gioDK + CAI_DAT.LICH_KIEM_SAU_PHUT)}</span>`;
    else kiem = `<span class="chip cho">Tự kiểm ${CAI_DAT.LICH_KIEM_PHUT} phút/lần</span>${s.lichLuc ? `<span class="mo">lần cuối ${gioStr(new Date(s.lichLuc))} · lần tới ${gioStr(new Date(s.lichLuc + CAI_DAT.LICH_KIEM_PHUT * 60000))}</span>` : ''}`;
    h += hang_(0, 'Tự kiểm trên trang', kiem);
    let nut = '';
    if (it.link) nut += `<a href="#" data-a="mobai" data-link="${esc(it.link)}">Mở bài ↗</a> `;
    if (!it.xong) nut += `<button class="nut nho chinh" data-a="ticklich" data-k="${esc(it.k)}">✓ Đã đăng — tick tay</button>`;
    else if (it.tay) nut += `<button class="phu-nut" data-a="boticklich" data-k="${esc(it.k)}">Bỏ tick</button>`;
    if (nut) h += `<div class="r">${nut}</div>`;
    return h + '</div>';
  }

  const nutLonChung = (hd, bieuTuong, tieuDe, tt, mo, tip) => {
    const v = lay('viec112_' + hd, null); const dang = !!(v && v.tt !== 'xong' && Date.now() - v.luc < 3 * 60000);
    const vuaXong = !dang && v && v.tt === 'xong' && v.xong && Date.now() - v.xong < 9000;
    return `<button class="big${dang ? ' run' : vuaXong ? ' xong' : ''}" data-a="${hd}" title="${esc(tip)}"><span class="bi"><span>${dang ? '↻' : vuaXong ? '✓' : bieuTuong}</span></span><span class="bt"><b>${dang ? tt.dang : vuaXong ? tt.xong : tieuDe}</b><small>${mo}</small></span></button>`;
  };
  const nutKiemBai = () => {
    const kq = lay('kiembai_kq', null);
    const Lh = lichHomNay(); const xongNay = Lh.items.filter((i) => i.xong).length;
    const moBai = kq && kq.luc > Date.now() - 24 * 3600e3 ? `Lần kiểm gần nhất lúc <b>${gioStr(new Date(kq.luc))}</b> (lúc đó ${kq.xong}/${kq.tong}) · hiện đã lên trang <b>${xongNay}/${Lh.items.length}</b>` : 'Chưa kiểm lần nào · F5 trang cũng tự kiểm';
    return nutLonChung('kiembai', '🔍', 'Kiểm tra bài đã đăng hôm nay', { dang: 'Đang kiểm tra trên trang…', xong: 'Đã kiểm xong!' }, moBai, 'Kiểm tra ngay các bài đã lên trang hôm nay (Bài 1–3, Video, Manifest)');
  };
  const nutRaSoat = () => {
    const rs = (lay('ngay_' + homNay(), null) || {}).rs; const kq = lay('rasoat_kq', null);
    const mo = `Tự rà soát 3 lần/ngày${rs && rs.gio ? ' (' + rs.gio.slice(Math.min(rs.lan || 0, rs.gio.length - 1)).slice(0, 1).map((m) => (rs.lan >= rs.gio.length ? 'đã xong hôm nay' : 'lần tới ~' + phutStr(m))).join('') + ')' : ''} · đếm comment + ảnh thật trên Facebook so với sheet, thiếu thì gửi bù${kq && kq.luc > Date.now() - 24 * 3600e3 ? ' · bấm tay lúc <b>' + gioStr(new Date(kq.luc)) + '</b>' : ''}`;
    return nutLonChung('rasoat', '🧾', 'Rà soát comment ngay', { dang: 'Đang rà soát…', xong: 'Đã rà soát!' }, mo, 'Kiểm ngay comment (chữ + ảnh) của các bài hôm nay; thiếu thì tự gửi bù');
  };
  const nutAnhMoi = () => {
    const tr = (lay('ngay_' + homNay(), null) || {}).truoc;
    const mo = tr && tr.luc ? `Tải lần cuối <b>${gioStr(new Date(tr.luc))}</b> · kho đang giữ ${tr.kho != null ? tr.kho : '?'} ảnh (~${tr.mb != null ? tr.mb : '?'} MB) · chỉ tải ảnh chưa có` : `Sáng nay script tự tải sẵn${tr && tr.gio != null ? ' lúc ' + phutStr(tr.gio) : ''} · bấm khi vừa đổi ảnh trong sheet`;
    return nutLonChung('anhmoi', '🖼', 'Cập nhật ảnh mới từ sheet', { dang: 'Đang tải ảnh mới…', xong: 'Đã cập nhật ảnh!' }, mo, 'Đọc lại sheet và tải về những ảnh mới chưa có trong kho tạm (ảnh đã có thì không gọi Lark lại)');
  };
  // (5.8) trạng thái 1 nút bấm: '' | 'cho' (đã nhận lệnh) | 'dang' (đang chạy) | 'xong' (vừa xong)
  function ttYeuCau(loai) {
    const v = lay('viec112_' + loai, null); if (!v) return { tt: '', v };
    if (v.tt === 'cho' && Date.now() - v.luc < (loai === 'rasoat' ? 45 : 10) * 60000) return { tt: 'cho', v };
    if (v.tt === 'dang' && Date.now() - (v.nhan || v.luc) < 6 * 60000) return { tt: 'dang', v };
    if (v.tt === 'xong' && v.xong) { if (Date.now() - v.luc < 1500) return { tt: 'dang', v }; if (Date.now() - v.xong < 12000) return { tt: 'xong', v }; }
    return { tt: '', v };
  }
  function oThaoTac(loai, ic, ten, tt, mo, nut, bam) {
    const { tt: st, v } = ttYeuCau(loai);
    const hd = hdHien();
    const live = st === 'dang' ? ((hd && hd.key === 'yeucau' && hd.chi) ? String(hd.chi).replace(/\s*\[tab [^\]]+\]\s*$/, '') : 'Đang làm…') : st === 'cho' ? (lay('dang_do', null) || dangQuet || lay('quet_link', null) ? 'Đã nhận lệnh — chờ script làm xong việc đang dở rồi làm ngay…' : 'Đã nhận lệnh — đang bắt đầu…') : '';
    const kq = v && v.kq && v.xong && Date.now() - v.xong < 6 * 3600e3 ? `${v.mau === 'vang' ? '⚠' : '✓'} ${gioStr(new Date(v.xong))} · ${v.kq}` : '';
    const lop = st === 'dang' || st === 'cho' ? 'run' : st === 'xong' ? (v && v.mau === 'vang' ? 'vang' : 'xong') : '';
    const icon = lop === 'run' ? '<span class="xoay"></span>' : lop === 'xong' ? '✓' : lop === 'vang' ? '!' : ic;
    const dong = live || kq || mo;
    return `<div class="tn ${lop}${bam ? ' bam' : ''} tn-${loai}"${bam ? ` data-a="${bam}" role="button" tabindex="0"` : ''}><div class="tn-dau"><span class="tn-ic">${icon}</span><div class="tn-ten"><b>${ten}</b><span>${esc(tt)}</span></div></div><div class="tn-mo${live ? ' live' : kq && v.mau === 'vang' ? ' canh' : ''}" title="${esc(dong)}">${esc(dong)}</div><div class="tn-nut">${nut}</div></div>`;
  }
  function khuThaoTac() {
    const Lh = lichHomNay(); const xongNay = Lh.items.filter((i) => i.xong).length;
    const kb = lay('kiembai_kq', null);
    const o1 = oThaoTac('kiembai', '🔍', 'Kiểm tra bài đã đăng', `${xongNay}/${Lh.items.length} bài hôm nay đã lên trang`,
      kb && Date.now() - kb.luc < 24 * 3600e3 ? `Lần kiểm tay gần nhất ${gioStr(new Date(kb.luc))} · script cũng tự dò 10 phút/lần` : 'Script tự dò 10 phút/lần · bấm để kiểm ngay',
      '<span class="nut nho chinh">Kiểm ngay</span>', 'kiembai');
    const at = lay('anh_tai_cuoi', null) || (lay('ngay_' + homNay(), null) || {}).truoc;
    const o2 = oThaoTac('anhmoi', '🖼', 'Ảnh từ sheet', at && at.kho != null ? `Kho đang giữ ${at.kho} ảnh (~${at.mb} MB)` : 'Chưa tải ảnh',
      (at && at.luc ? `Tải lần cuối ${ngayNgan(ngayStr(new Date(at.luc)))} ${gioStr(new Date(at.luc))} · ` : '') + (LA_GIAO ? 'tự tải sẵn mỗi sáng' : 'máy Cao tự tải 2 ngày/lần'),
      '<span class="nut nho chinh">Tải ảnh mới</span>', 'anhmoi');
    const s = lay('ngay_' + homNay(), null) || {}; const rs = s.rs;
    let chua = 0, du = 0; try { const mu = mucTieuRaSoat(s); du = mu.filter((t) => rs && rs.kq && rs.kq[t.key] && rs.kq[t.key].ok && rs.kq[t.key].v === 2).length; chua = mu.length - du; } catch (e) { /* */ }
    const toi = !(rs && rs.gio) ? 'tự rà soát lúc ' + CAI_DAT.RA_SOAT_GIO.map(([h, m]) => pad(h) + ':' + pad(m)).join(', ') : rs.lan < rs.gio.length ? 'lần tự rà soát tới ~' + phutStr(rs.gio[rs.lan]) : 'đã tự rà soát đủ lượt hôm nay';
    const o3 = oThaoTac('rasoat', '🧾', 'Rà soát comment', `${chua} bài chưa kiểm · ${du} bài đã đủ`, `Bài đã kiểm đủ lần trước sẽ bỏ qua · ${toi}`,
      '<div class="seg" role="group" aria-label="Rà soát comment"><button data-a="rasoat" data-so="1" title="Kiểm 1 bài gần nhất chưa kiểm đủ">1 bài</button><button data-a="rasoat" data-so="3" title="Kiểm 3 bài gần nhất chưa kiểm đủ">3 bài</button><button data-a="rasoat" data-so="5" title="Kiểm 5 bài gần nhất chưa kiểm đủ">Tất cả</button></div>');
    return `<div class="tn3">${o2}${o3}${o1}</div>`; // (5.8.3) Ảnh (hẹp) | Rà soát | Kiểm tra bài
  }
  function tabHomNay() {
    const ngay = homNay(); const d = new Date();
    const st = lay('sap_toi', null);
    const homNayDs = (() => { const x = st && !st.loiCot && st.ds ? st.ds.find((y) => y.ngay === ngay) : null; return x ? x.hangs : null; })();
    const tt = lay('tien_trinh', {}) || {};
    const dd = lay('dang_do', null);
    const t = trangThaiChinh();
    const L = lichHomNay(); const s = L.s;
    const xongN = L.items.filter((i) => i.xong).length;
    const chon = L.items.find((i) => i.k === uiTab.chon) || L.items.find((i) => !i.xong) || L.items[L.items.length - 1];
    let html = theViec();
    html += khuThaoTac();
    html += `<div class="strip s-${t.den}"><span class="den ${t.den}${t.nhay ? ' nhay' : ''}"></span><span style="flex:1">${t.chu}</span><span class="kq ${xongN === L.items.length ? 'ok' : 'xam'}">${xongN}/${L.items.length} bài đã lên trang</span></div>`;
    const khoaGio = (i) => (i.xong && i.luc ? phutTrongNgay(new Date(i.luc)) : i.gioDK);
    // (4.8) bài đã đăng lên trên (theo giờ đăng thật); bài chưa đăng xuống dưới, nếu giờ dự kiến trùng/trước bài gần nhất thì xếp lại cách bài trước 20 phút
    const daXong = L.items.filter((i) => i.xong).sort((a, b) => khoaGio(a) - khoaGio(b));
    let moc = daXong.length ? khoaGio(daXong[daXong.length - 1]) : -1;
    const chuaXong = L.items.filter((i) => !i.xong).sort((a, b) => a.gioDK - b.gioDK).map((i) => {
      const moi = moc >= 0 && i.gioDK < moc + 20 ? moc + 20 : i.gioDK;
      moc = Math.max(moc, moi);
      return moi !== i.gioDK ? Object.assign({}, i, { gioDK: moi, daCoGio: true, doiGio: true }) : i;
    });
    const tl = daXong.concat(chuaXong).map((it) => {
      const nl = nhanLich(it);
      return `<div class="it${it.k === chon.k ? ' sel' : ''}" data-a="chon" data-k="${esc(it.k)}"><div class="dm ${lopTt(it.tt)}">${it.xong ? '✓' : it.ky}</div>
        <div class="h">${nl.gio} · ${esc(it.ten)}${it.ngoai ? '' : ' <span class="who">tự động</span>'}</div><div class="t">${nl.mo}</div>
        ${it.ngoai && !it.xong ? `<button class="phu-nut tk" data-a="ticklich" data-k="${esc(it.k)}" title="Bài đã lên trang rồi? Bấm để tick xanh">✓ Tick</button>` : ''}${!it.ngoai && !it.xong && (it.loai === 'b1' || (it.t && it.t.text)) ? `<button class="phu-nut tk dang" data-a="${it.loai === 'b1' ? 'dangngay' : 'dangb23'}"${it.t ? ` data-k="${esc(it.t.k)}"` : ''} title="Đăng ${esc(it.ten)} ngay bây giờ, bỏ qua giờ hẹn">▶ Đăng</button>` : ''}</div>`;
    }).join('');
    let ct;
    if (chon.ngoai) ct = theLichNgoai(chon, s);
    else if (!chon.h) ct = '<div class="the-nd"><div class="mo">Chưa đọc sheet — vào tab Sắp tới, bấm “Đọc lại Lark sheet”.</div></div>';
    else if (chon.loai === 'b1') ct = theBai1(chon.h, s, ngay, L.nhieu);
    else ct = theBai23(chon.t, chon.h, s, ngay, L.nhieu);
    if (homNayDs && !homNayDs.length) ct = `<div class="the-nd"><span class="chip loi" style="margin:0">Không có hàng nào mang ngày ${ngay} ở cột H</span></div>` + ct;

    const BUOC = [['B1', 'Mở hộp soạn'], ['B2', 'Điền chữ'], ['B3', 'Nền đỏ/ảnh'], ['B4', 'Vị trí'], ['B7', 'Chọn nhóm'], ['B9', 'Đăng'], ['B10', 'Thấy bài'], ['C4', 'Comment']];
    const b = tt.buoc || {};
    const daBatDau = !!tt.batDau && tt.ngay === ngay;
    let dangO = -1; BUOC.forEach(([k], i) => { if (b[k]) dangO = i; });
    let tien = `<div class="the-nd"><div class="nhan">${tt.soanThu && daBatDau ? 'Soạn thử' : 'Tiến trình đăng'} ${daBatDau ? `hàng ${tt.hang} · bắt đầu ${gioStr(new Date(tt.batDau))}` : '(chưa chạy hôm nay)'}</div><div class="buoc">`;
    BUOC.forEach(([k, ten], i) => {
      const lop = !daBatDau ? '' : b[k] ? 'xong' : (i === dangO + 1 && (dangBan || dd)) ? 'dang' : (i === dangO + 1 && s.loi) ? 'loi' : '';
      tien += `<span class="b ${lop}">${lop === 'xong' ? '✓ ' : ''}${ten}</span>`;
    });
    tien += '</div></div>';
    let gHtml = '<div class="the-nd"><div class="nhan">Cột Trạng thái (G) trên sheet</div>';
    for (const h of (homNayDs || [])) {
      const g = (s.gXong || {})[h.hang];
      gHtml += `<div class="dong"><span>Hàng ${g && g.hang ? g.hang : h.hang}</span><span>${g ? `<span class="chip ok">Đã đăng</span> lúc ${gioStr(new Date(g.luc))}` : hangDuBai(s, h, ngay) ? '<span class="chip cho">Đủ bài — chưa đồng bộ được Lark</span>' : '<span class="chip xam">Chờ đủ cả 3 bài</span>'}</span></div>`;
    }
    if (!(homNayDs || []).length) gHtml += '<div class="mo">—</div>';
    gHtml += '</div>';
    const mo = `<div class="mo" style="margin:0 0 10px">${THU[d.getDay()]} ${ngay.replace(/-/g, '/')} · 3 bài script tự đăng; video / manifest đăng tay, script tự kiểm ${CAI_DAT.LICH_KIEM_PHUT} phút/lần đến khi thấy bài (hoặc bấm Tick tay).</div>`;
    return html + `<div class="tlay"><div class="tl"><h4>Lịch hôm nay</h4>${tl}</div><div class="ct">${mo}${ct}<div class="luoi hai">${tien}${gHtml}</div></div></div>`;
  }

  const locGhiChu = (g) => (g || []).filter((x) => !/cảm xúc|nút Thích|bày tỏ/i.test(x)); // (4.6) việc thả Thích/cảm xúc không thành chỉ là việc phụ, lượt quét sau tự bù
  // Hôm qua: các bài đã đăng (xếp theo giờ thực tế), trạng thái comment, link
  function tabHomQua() {
    const d = congNgay(-1); const ngay = ngayStr(d); const s = lay('ngay_' + ngay, null);
    const dau = `<div class="mo" style="margin:0 0 10px"><b>${THU[d.getDay()]} ${ngay.replace(/-/g, '/')}</b> — các bài đã đăng hôm qua</div>`;
    if (!s) return dau + '<div class="the-nd"><span class="chip xam" style="margin:0">Chưa có dữ liệu</span><div class="mo">Hôm qua script chưa chạy (hoặc dữ liệu đã được dọn).</div></div>';
    const rows = []; const phut = (ms) => phutTrongNgay(new Date(ms));
    // (4.6) comment đã ổn ("✓" / tick tay / có sẵn) → KHÔNG hiện ghi chú lỗi cũ; chưa ổn → 1 dòng nhẹ nhàng, chi tiết kỹ thuật thu gọn
    const khongQuanTrong = /cảm xúc|nút Thích|bày tỏ/i;
    const ghiChuHtml = (g, ct) => {
      if (/✓|tick tay|có sẵn/.test(ct || '')) return '';
      const ds = (g || []).filter((x) => !khongQuanTrong.test(x));
      if (!/comment/.test(ct || '') ) return '';
      return `<div class="mo" style="margin:4px 0 0">Script chưa xác nhận được comment của bài này — Cao bấm "Mở" để xem giúp.</div>${ds.length ? `<details style="margin-top:2px"><summary class="mo" style="cursor:pointer">Chi tiết kỹ thuật</summary><div class="mo">${esc(ds.join('; '))}</div></details>` : ''}`;
    };
    Object.values(s.bai || {}).forEach((b) => {
      if (b.tt === 'khong_ro') { rows.push({ k: b.luc ? phut(b.luc) : 0, ten: `Bài 1 (hàng ${b.hang})`, ok: false, gio: '—', ct: 'không rõ đã lên chưa' }); return; }
      const cm = b.tt === 'xong' ? (b.cmtTrangThai === 'xac_nhan' ? 'đã comment ✓' : 'comment cần kiểm tra') : b.tt === 'co_san' ? 'có sẵn trên trang' : 'chưa comment';
      rows.push({ k: phut(b.luc), ten: `Bài 1 (hàng ${b.hang})`, ok: true, gio: gioStr(new Date(b.luc)), ct: `${b.soNhom ? b.soNhom + ' nhóm · ' : ''}${cm}`, link: b.link, gc: b.tt !== 'co_san' ? b.ghiChu : [] });
    });
    Object.entries(s.b23 || {}).forEach(([k, r]) => {
      const loai = k.split('|')[0];
      const cm = r.tt === 'tay' ? 'tick tay' : r.cmt ? 'đã comment ✓' : 'comment cần kiểm tra';
      if (r.tt === 'khong_ro') { rows.push({ k: r.luc ? phut(r.luc) : 0, ten: `Bài ${loai}`, ok: false, gio: '—', ct: 'không rõ đã lên chưa' }); return; }
      rows.push({ k: phut(r.luc), ten: `Bài ${loai}`, ok: true, gio: gioStr(new Date(r.luc)), ct: `${r.soNhom ? r.soNhom + ' nhóm · ' : ''}${cm}`, link: r.link, gc: r.ghiChu });
    });
    if (!Object.keys(s.bai || {}).length) rows.push({ k: s.gio != null ? s.gio : 420, ten: 'Bài 1', ok: false, gio: s.gio != null ? phutStr(s.gio) : '—', ct: s.huy ? 'đã hủy' : s.loi ? esc(s.loi.msg) : 'không có ghi nhận đăng' });
    for (const loai of [2, 3]) if (!Object.keys(s.b23 || {}).some((k) => k.startsWith(loai + '|'))) rows.push({ k: s['gio' + loai] != null ? s['gio' + loai] : (loai === 2 ? 570 : 630), ten: `Bài ${loai}`, ok: false, gio: s['gio' + loai] != null ? phutStr(s['gio' + loai]) : '—', ct: 'không có ghi nhận đăng' });
    CAI_DAT.LICH_NGOAI.forEach((x) => {
      const r = (s.lich || {})[x.k];
      if (!r) { rows.push({ k: docGio(x.gio), ten: x.ten, ok: false, gio: x.gio, ct: 'chưa thấy bài trên trang' }); return; }
      const cm = r.cmt ? (r.cmt.ok ? 'đã comment ✓' : 'comment cần kiểm tra') : 'chưa comment';
      rows.push({ k: phut(r.luc), ten: x.ten, ok: true, gio: gioStr(new Date(r.luc)), ct: `${r.tay ? 'tick tay · ' : ''}${cm}`, link: r.link, gc: r.cmt && !r.cmt.ok ? r.cmt.ghiChu : [] });
    });
    rows.sort((a, b) => a.k - b.k);
    const xong = rows.filter((r) => r.ok).length;
    const ds = rows.map((r) => `<div class="it" style="cursor:default"><div class="dm ${r.ok ? 'xong' : 'cho'}">${r.ok ? '✓' : '–'}</div><div class="h">${r.gio} · ${esc(r.ten)}</div><div class="t">${String(r.ct).replace('comment cần kiểm tra', 'comment chưa xác nhận')}${r.link ? ` · <a href="${esc(r.link)}" target="_blank">Mở ↗</a>` : ''}</div>${ghiChuHtml(r.gc, r.ct)}</div>`).join('');
    const canXem = rows.filter((r) => r.ok && /cần kiểm tra|chưa comment/.test(String(r.ct))).length;
    return dau + `<div class="strip s-xanh"><span style="flex:1">Hôm qua đã lên trang</span><span class="kq ${xong === rows.length ? 'ok' : 'xam'}">${xong}/${rows.length} bài</span>${canXem ? `<span class="kq xam">${canXem} bài cần xem comment</span>` : ''}</div><div class="tlay"><div class="tl" style="max-width:none;width:100%"><h4>Lịch hôm qua (theo giờ thực tế)</h4>${ds}</div></div>`;
  }

  function tabQuet() {
    const s = lay('ngay_' + homNay(), null) || {}; const q = s.quet || {}; const m = phutTrongNgay(new Date());
    const qd = lay('quet_dang', null); const dang = dangQuet || (qd && Date.now() - qd.luc < 90000);
    const cfg = quetCfg();
    const chips = CAI_DAT.GIO_QUET.map((g) => q[g] ? `<span class="chip ok">${g} ✓ ${gioStr(new Date(q[g].luc))}</span>` : (!cfg.tuDong ? `<span class="chip xam">${g}</span>` : m >= docGio(g) ? (m - docGio(g) > CAI_DAT.QUET_BU_PHUT ? `<span class="chip xam">${g} bỏ qua</span>` : `<span class="chip cho">${g} sắp quét</span>`) : `<span class="chip xam">${g}</span>`)).join(' ');
    const moiNhat = Object.values(q).sort((a, b) => b.luc - a.luc)[0];
    const tong = s.quetTong; let thu = lay('quet_thu', null);
    if (thu && (Date.now() - thu.luc > 3 * 3600e3 || Object.values(q).some((v) => v.luc > thu.luc))) thu = null;
    const bat = (k, ten, tip) => `<button class="tg ${cfg[k] ? 'ok' : ''}" data-a="cfg" data-k="${k}" title="${esc(tip)}">${cfg[k] ? '✓' : '✕'} ${ten}</button>`;
    const vs = vidState(); const hanV = Date.now() - 26 * 3600e3;
    const dsV = Object.keys(vs).map((id) => Object.assign({ id }, vs[id])).filter((v) => v.gio && v.gio > hanV && v.tt !== 'khong_video' && v.tt !== 'khac').sort((a, b) => b.gio - a.gio).slice(0, 10);
    const nhanV = (v) => v.tt === 'xong' ? '<span class="chip ok">✓ đã đủ sẵn</span>' : v.tt === 'luu' ? '<span class="chip ok">✓ vừa gắn</span>' : v.tt === 'tay' ? '<span class="chip ok">✓ gắn tay</span>' : v.tt === 'manifest' ? '<span class="chip xam">bỏ qua #Manifest</span>' : v.tt === 'loi' ? `<span class="chip loi" title="${esc(v.loi || '')}">⚠ lỗi${v.lan ? ' (lần ' + v.lan + ')' : ''}</span>` : '';
    const dongV = dsV.map((v) => `<div class="dong"><span>${v.link ? `<a href="#" data-a="mobai" data-link="${esc(v.link)}" title="Mở video">Video ${gioStr(new Date(v.gio))} ↗</a>` : 'Video ' + gioStr(new Date(v.gio))}</span><span>${nhanV(v)}${v.tt === 'loi' ? ` <button class="nut nho" data-a="gantay" data-id="${esc(v.id)}" title="Đã tự gắn thẻ + cảm xúc bằng tay → script ngừng thử lại và ngừng báo Lark cho video này">Đã gắn tay</button>` : v.tt === 'tay' ? ` <button class="phu-nut" data-a="bogantay" data-id="${esc(v.id)}" title="Bỏ đánh dấu, cho script thử lại">bỏ</button>` : ''}</span></div>`).join('');
    const yenDen = lay('quet_yen', 0) > Date.now();
    const trai = `<div class="cot">
      <div class="the-nd"><h4>🧹 Lần quét gần nhất</h4>
        ${dang ? `<div class="rv"><span class="kq cho">Đang quét… ${esc((dangQuet ? buocQuet : qd.buoc) || '')}</span></div>` : moiNhat ? `<div class="rv"><span class="kq ok">✓ ${gioStr(new Date(moiNhat.luc))}</span> ${esc(moiNhat.kq)}</div>` : '<div class="rv"><span class="kq xam">Hôm nay chưa quét lần nào</span></div>'}
        ${(() => { const tb = lay('quet_thongbao', null); return tb && (tb.chiTiet || []).length ? `<div class="mo" style="margin-top:6px">Chi tiết việc chưa được: ${esc(tb.chiTiet.join(' | '))}</div>` : ''; })()}
        ${tong ? `<div class="mo" style="margin-top:8px">Cả ngày: gắn ${tong.gan} video · Thích ${tong.thichBai} bài + ${tong.thichCmt} comment (${tong.lan} lần quét)</div>` : ''}
        ${thu ? `<div class="mo" style="margin-top:4px">Quét thử lúc ${gioStr(new Date(thu.luc))}: ${esc(thu.kq)}</div>` : ''}</div>
      <div class="the-nd"><h4>Các mốc tự quét hôm nay</h4><div>${chips}</div></div>
      <div class="the-nd"><h4>Bấm để làm</h4><div style="display:flex;flex-wrap:wrap;gap:8px">
        <button class="nut chinh" data-a="quetngay" title="Quét ngay: gắn thẻ + cảm xúc video 24h qua (trừ Manifest) và Thích bài/comment 48h qua chưa có">🧹 Quét ngay</button>
        <button class="nut" data-a="quetthu" title="Quét thử: chỉ liệt kê việc sẽ làm, không bấm gì trên Facebook">👁 Quét thử</button>
        <button class="nut" data-a="yen" title="Bật: 1 giờ không tự quét để bạn làm việc không bị gián đoạn. Bấm lại để bỏ">${yenDen ? '🤫 Bỏ yên lặng (đến ' + gioStr(new Date(lay('quet_yen', 0))) + ')' : '🤫 Yên lặng 1 giờ'}</button>
        ${dang ? '<button class="nut do" data-a="dungquet">⏹ Dừng quét</button>' : ''}</div></div></div>`;
    const phai = `<div class="cot">
      <div class="the-nd"><h4>Video 24 giờ qua</h4>${dongV || '<div class="mo">Chưa có video nào được quét.</div>'}</div>
      <div class="the-nd"><h4>Bật / tắt</h4><div style="display:flex;flex-wrap:wrap;gap:6px">${bat('video', 'Gắn thẻ video', 'Gắn thẻ Page + cảm xúc cho video quên gắn')}${bat('thichBai', 'Thích bài', 'Thích/Yêu thích bài chưa có cảm xúc')}${bat('thichCmt', 'Thích comment', 'Thích/Yêu thích comment chưa có cảm xúc')}${bat('tuDong', 'Tự quét 12h/17h/21h', 'Tắt = chỉ quét khi bấm nút')}</div></div></div>`;
    return trai + phai;
  }

  function tabHeThong() {
    const ngay = homNay(); const s = lay('ngay_' + ngay, null) || { bai: {} };
    const sk = lay('suc_khoe', {}) || {}; const dl = tinhTrangDuLieu(); const tk = s.tuKiem; const d = new Date();
    const docLuc = dl.st && dl.st.luc;
    const label = dl.gate ? dl.gate.msg : sk.larkOk === false ? 'Chưa kết nối được Lark' : dl.canh ? 'Dữ liệu chưa được cập nhật' : 'Lark hoạt động bình thường';
    const hien = document.visibilityState === 'visible';
    const o = (ten, ok, chu) => `<div>${ok === null ? '⚪' : ok ? '🟢' : '🔴'} <b>${ten}</b><br><span class="mo">${chu}</span></div>`;
    const trai = `<div class="cot">
      <div class="the-nd"><h4>${dl.canh ? '🔴' : '🟢'} Lark: ${esc(label)}</h4><div class="mo">Sheet đọc lúc ${docLuc ? ngayStr(new Date(docLuc)) + ' ' + gioStr(new Date(docLuc)) : 'chưa có'}</div>${dl.canh ? '<div style="margin-top:8px"><button class="nut nho" data-a="ketnoi">Kiểm tra kết nối lại</button></div>' : ''}</div>
      <div class="the-nd"><h4>Kiểm tra hệ thống</h4><div class="skhoe">
      ${o('Tư cách Facebook', sk.tuCach ? !!sk.tuCachDung : null, sk.tuCach ? `${esc(sk.tuCach)} · ${gioStr(new Date(sk.tuCachLuc))}` : 'chưa kiểm')}
      ${o('Đúng trang', dungTrang(), dungTrang() ? CAI_DAT.TEN_NGAN : 'đang ở trang khác (đến giờ sẽ tự chuyển)')}
      ${o('Tab đang hiện', hien, hien ? 'tốt' : 'bị ẩn — Facebook sẽ chạy chậm')}
      ${o('Tab làm việc', laTabChinh(), laTabChinh() ? ((GM_getValue('khoa_dang_bai_that', {}) || {}).ghim ? 'tab này · ⭐ Main (các tab khác không giành được)' : 'tab này <button class="phu-nut" data-a="dungtab" title="Ghim tab này làm tab chính — tab khác không tự giành">⭐ Đặt làm Main</button>') : (() => { const k = GM_getValue('khoa_dang_bai_that', {}) || {}; return 'một tab Facebook khác đang làm' + (k.v && k.v !== PHIEN_BAN ? ` (bản ${esc(k.v)} — tải lại tab đó bằng F5)` : !k.v ? ' (bản cũ — tải lại tab đó bằng F5)' : '') + ' <button class="phu-nut" data-a="dungtab" title="Biến tab này thành tab chính (Main) thay tab kia">⭐ Đặt tab này làm Main</button>'; })())}
      ${o('Đọc Lark sheet', sk.larkLuc ? !!sk.larkOk : null, sk.larkLuc ? `${sk.larkOk ? 'ổn' : esc(sk.larkLoi)} · ${gioStr(new Date(sk.larkLuc))}` : 'chưa đọc')}
      ${o('Gửi tin Lark', sk.tinLuc ? !!sk.tinOk : null, sk.tinLuc ? `${sk.tinOk ? 'ổn' : esc(sk.tinLoi)} · ${gioStr(new Date(sk.tinLuc))}` : 'chưa gửi')}
      ${o('Đọc comment qua API', !coApi() ? null : sk.cmtLuc ? !!sk.cmtOk : null, !coApi() ? 'chưa cài mã khoá' : sk.cmtLuc ? `${sk.cmtOk ? 'ổn' : esc(sk.cmtLoi)} · ${gioStr(new Date(sk.cmtLuc))}` : 'chưa đọc')}
      ${o('Đọc bài qua Facebook API', !coApi() ? false : sk.apiLuc ? !!sk.apiOk : null, (!coApi() ? 'chưa cài mã khoá' : sk.apiLuc ? `${sk.apiOk ? 'ổn' : esc(sk.apiLoi)} · ${gioStr(new Date(sk.apiLuc))}` : 'chưa đọc') + (coApi() && lay('fb_token_luc', 0) ? ` · mã dùng ${Math.floor((Date.now() - lay('fb_token_luc', 0)) / 864e5)}/${CAI_DAT.MA_KHOA_HAN_NGAY} ngày` : ''))}
      </div></div></div>`;
    const tuKiemHtml = tk ? (tk.ok ? `<span class="chip ok">Ổn</span> lúc ${gioStr(new Date(tk.luc))}` : `<span class="chip cho">${gioStr(new Date(tk.luc))}</span> ${esc(tk.loi)}`)
      : (Object.keys(s.bai || {}).length || s.xong || s.huy || s.dung || (s.gio != null && phutTrongNgay(d) >= s.gio - 4)) ? '<span class="chip xam">Hôm nay bỏ qua</span> <span class="mo">(đã tới giờ đăng / đã đăng)</span>'
      : `<span class="chip xam">Sẽ chạy lúc ${CAI_DAT.GIO_TU_KIEM}</span>`;
    const phai = `<div class="cot">
      <div class="the-nd"><h4>Tự kiểm trước giờ đăng</h4><div class="rv">${tuKiemHtml}</div><div style="margin-top:8px"><button class="nut nho" data-a="tukiem" title="Mở thử hộp đăng bài rồi đóng lại, không đăng gì">Tự kiểm ngay</button></div></div>
      <div class="the-nd"><h4>Công cụ</h4><div style="display:flex;flex-wrap:wrap;gap:8px">
        <button class="nut nho" data-a="kiem" title="Kiểm sheet ngày mai và báo nhóm nếu thiếu">✓ Kiểm ngày mai</button>
        <button class="nut nho" data-a="tinthu" title="Gửi 1 tin thử vào nhóm Lark &quot;Đăng bài fb&quot;">✉ Gửi tin thử</button>
        <button class="nut nho" data-a="amBao" title="Có việc mới cần xử lý thì kêu một tiếng và chớp tiêu đề tab">${lay('ui_am_bao', true) ? '🔔 Âm báo: bật' : '🔕 Âm báo: tắt'}</button>
        <button class="nut nho${coApi() ? '' : ' do'}" data-a="caima" title="Mã khoá chỉ đọc để script đọc bài trên trang qua Facebook">🔑 ${coApi() ? 'Đổi mã khoá FB' : 'Cài mã khoá FB'}</button>
        ${coApi() ? '<button class="nut nho" data-a="kiemma">Kiểm tra mã khoá</button>' : ''}
        <button class="nut nho do" data-a="baoloi">📋 Báo lỗi</button></div></div>
      <div class="mo">Mở trang: <a href="${CAI_DAT.URL_TRANG}" target="_self">${CAI_DAT.TEN_NGAN}</a> · Bản ${(typeof GM_info !== 'undefined' && GM_info.script && GM_info.script.version) || PHIEN_BAN} · Máy ${LA_GIAO ? 'Giao' : 'Cao'}</div></div>`;
    return trai + phai;
  }

  function tabSapToi() {
    const st = lay('sap_toi', null); const SO = CAI_DAT.CANH_BAO_THIEU_NGAY; const GH = CAI_DAT.GIOI_HAN_KY_TU_NEN;
    const hom = lay('ngay_' + homNay(), null) || {};
    const moSheet = st ? `Đọc xong lúc <b>${gioStr(new Date(st.luc))}</b> · chỉ đọc khi cần, tiết kiệm lượt gọi` : 'Chưa đọc sheet — bấm để đọc';
    let html = `<div class="acts hai">${nutLonChung('lammoi', '↻', 'Đọc lại Lark sheet', { dang: 'Đang đọc sheet…', xong: 'Đã đọc xong!' }, moSheet, 'Đọc lại nội dung sheet ngay, đọc ngay, không chờ')}
      <button class="big sheet" data-a="mosheet" title="Mở Lark sheet để bổ sung các ô trống"><span class="bi"><span>▦</span></span><span class="bt"><b>Mở Lark sheet</b><small>Mở trang sheet để bổ sung ô còn thiếu</small></span></button></div>`;
    if (tinhTrangDuLieu().canh) html += '<div class="ghichu">⚠ Dữ liệu có thể cũ — chưa xác minh lại được. Không dùng dấu ✓ dưới đây để kết luận nội dung hiện tại.</div>';
    if (!st) return html;
    if (st.loiCot) return html + `<span class="chip loi" style="margin:0;white-space:normal">${esc(st.loiCot)}</span>`;
    html += `<div class="ghi">Bảng hiện ${st.ds.length} ngày. <b style="color:var(--do-chu)">Đỏ = thiếu trong ${SO} ngày gần nhất</b> (script sẽ báo, nút "Mở sheet" cũng chỉ đếm ${SO} ngày này); <b style="color:var(--vang-chu)">vàng = ngày xa hơn</b>, chưa cần báo.</div>`;
    const mk = (co, ten, lop, xam) => `<div class="mk ${co ? 'ok' : xam ? 'xam' : lop}">${co ? '✓' : xam ? '–' : '✕'} ${ten}</div>`;
    html += '<table class="st"><tr><th>Ngày</th><th>Bài 1</th><th>Bài 2</th><th>Bài 3</th></tr>';
    st.ds.forEach((n, idx) => {
      const trong = idx < SO; const lop = trong ? 'loi' : 'cho';
      const isHom = n.ngay === homNay();
      const thieuN = thieuNgan(n, isHom ? hom : null);
      const tag = isHom ? ' <span class="chip ok" style="margin:0">Hôm nay</span>' : n.ngay === ngayMai() ? ' <span class="chip xam" style="margin:0">Ngày mai</span>' : '';
      const kl = !thieuN.length ? '<div class="mk ok">✓ Đủ</div>' : `<div class="mk ${lop}">${trong ? '⚠' : '•'} Thiếu ${thieuN.length} mục</div>`;
      const ngayCell = `<td class="ng"><b>${n.thu}</b> ${n.ngay.slice(0, 5).replace('-', '/')}${tag}${kl}</td>`;
      const cls = `${idx ? 'dau ' : ''}${thieuN.length ? (trong ? 'thieu' : 'xa') : ''}`;
      if (!n.hangs.length) { html += `<tr class="${cls}">${ngayCell}<td colspan="3"><div class="mk ${lop}">✕ Chưa có hàng nào mang ngày này ở cột H</div></td></tr>`; return; }
      n.hangs.forEach((h, i) => {
        const xong = (loai) => isHom && daDangHomNay(hom, loai, h.hang);
        const dai = (h.bai || '').length;
        const c1 = xong(1) ? '<div class="mk ok">✓ Đã đăng</div>' : mk(h.bai && dai <= GH, h.bai ? (dai > GH ? `Chữ quá dài (${dai}/${GH})` : `Chữ · ${dai} ký tự`) : 'Chữ', lop) + mk(h.cmt, 'Comment', lop);
        const c2 = xong(2) ? '<div class="mk ok">✓ Đã đăng</div>' : mk(h.bai2, 'Chữ', lop) + mk(h.cmt2, 'Comment', lop) + mk(h.a2, h.a2 ? `${h.a2} ảnh` : 'Ảnh', lop, !h.bai2 && !h.a2);
        const c3 = xong(3) ? '<div class="mk ok">✓ Đã đăng</div>' : mk(h.bai3, 'Chữ', lop) + mk(h.a3, h.a3 ? `${h.a3} ảnh` : 'Ảnh bài', lop, !h.bai3 && !h.a3) + mk(h.ac, h.ac ? `${h.ac} ảnh comment` : 'Ảnh comment', lop, !h.bai3 && !h.ac);
        html += `<tr class="${i ? cls.replace('dau ', '') : cls}">${i ? '<td class="ng"><span class="mo">hàng ' + h.hang + '</span></td>' : ngayCell.replace('</td>', `${n.hangs.length > 1 ? `<div class="mo">hàng ${h.hang}</div>` : ''}</td>`)}<td>${c1}</td><td>${c2}</td><td>${c3}</td></tr>`;
      });
    });
    return html + '</table>';
  }

  function tabLichSu() {
    let html = '<table class="ls"><tr><th>Ngày</th><th>Kết quả</th><th>Chi tiết</th></tr>';
    for (let i = 0; i < 7; i++) {
      const d = congNgay(-i); const ngay = ngayStr(d);
      const s = lay('ngay_' + ngay, null);
      const ngayHtml = `<b>${THU[d.getDay()]}</b> ${ngay.slice(0, 5)}${i ? '' : '<br><span class="mo">hôm nay</span>'}`;
      if (!s) { html += `<tr><td>${ngayHtml}</td><td><span class="chip xam" style="margin:0">Chưa có dữ liệu</span></td><td class="mo">script chưa chạy ngày này</td></tr>`; continue; }
      const bai = Object.values(s.bai || {}).sort((a, b) => a.luc - b.luc);
      let kq; let ct = '';
      if (bai.length) {
        const coLoi = bai.some((b) => b.cmtTrangThai !== 'xac_nhan') || bai.some((b) => (b.ghiChu || []).length && b.tt !== 'co_san') || bai.some((b) => b.tt === 'khong_ro');
        kq = coLoi ? '<span class="chip cho" style="margin:0">Có lưu ý</span>' : '<span class="chip ok" style="margin:0">Xong</span>';
        ct = bai.map((b) => {
          const dau = b.tt === 'co_san' ? `Hàng ${b.hang}: có sẵn trên trang` : b.tt === 'khong_ro' ? `Hàng ${b.hang}: không rõ đã lên chưa`
            : `Hàng ${b.hang} · ${gioStr(new Date(b.luc))}${b.soNhom ? ` · ${b.soNhom} nhóm` : ''}${b.tt === 'xong' ? (b.cmtTrangThai === 'xac_nhan' ? ' · API xác nhận comment' : ' · comment cần kiểm tra') : b.tt === 'da_dang' ? ' · chưa comment' : ''}`;
          return `<div>${dau}${b.link ? ` · <a href="${esc(b.link)}" target="_blank">Mở ↗</a>` : ''}</div>${locGhiChu(b.ghiChu).length && b.tt !== 'co_san' ? `<div class="ghichu">⚠ ${esc(locGhiChu(b.ghiChu).join('; '))}</div>` : ''}`;
        }).join('');
      } else if (s.huy) kq = '<span class="chip xam" style="margin:0">Đã hủy</span>';
      else if (s.dung) kq = '<span class="chip loi" style="margin:0">Đã dừng</span>';
      else if (s.daChot) { kq = '<span class="chip loi" style="margin:0">Không đăng được</span>'; ct = s.loi ? `<div class="ghichu">${esc(s.loi.msg)}</div>` : ''; }
      else if (s.loi) { kq = '<span class="chip loi" style="margin:0">Lỗi</span>'; ct = `<div class="ghichu">${esc(s.loi.msg)}</div>`; }
      else kq = `<span class="chip ${i ? 'xam' : 'cho'}" style="margin:0">${i ? 'Không đăng' : 'Chờ ' + (s.gio != null ? phutStr(s.gio) : '')}</span>`;
      { const b = tomTatB23(s, i ? null : hangHomNay()); if (b) ct += `<div>${esc(b)}</div>`; }
      if (s.tuKiem) ct += `<div class="mo">Tự kiểm: ${s.tuKiem.ok ? 'ổn' : '⚠ ' + esc(s.tuKiem.loi)}</div>`;
      html += `<tr><td>${ngayHtml}</td><td>${kq}</td><td>${ct || '<span class="mo">—</span>'}</td></tr>`;
    }
    return html + '</table>';
  }

  function tabNhatKy() {
    const loc = lay('ui_loc_nk', 'tatca');
    const ds = [];
    for (let i = 6; i >= 0; i--) ds.push(...lay(khoaNK(congNgay(-i)), []));
    const laLoi = (m) => /lỗi|Lỗi|không (thấy|đọc|mở|được|tìm)|chưa (thấy|gắn|thả|đọc|xác nhận)|thất bại|⚠|KHÔNG|dừng giữa chừng/.test(m);
    const loc2 = ds.sort((a, b) => a.luc - b.luc).filter((e) => loc === 'qt' ? e.quanTrong : loc === 'loi' ? laLoi(e.msg) : true);
    const nk = loc2.slice(-100).reverse().map(dongNK);
    const nutLoc = (k, ten) => `<button class="tg ${loc === k ? 'ok' : ''}" data-a="locnk" data-k="${k}">${ten}</button>`;
    return `<div style="display:flex;gap:6px;margin-bottom:6px">${nutLoc('tatca', 'Tất cả')}${nutLoc('qt', 'Quan trọng')}${nutLoc('loi', 'Lỗi')}</div><div class="mo" style="margin-bottom:6px">Mới nhất ở trên · giữ 7 ngày, gộp lỗi lặp · bấm "📋 Báo lỗi" để xuất</div><div class="nk">${esc(nk.join('\n')) || '(không có dòng nào)'}</div>`;
  }

  const CSS_THEM = `
#smhfb .cdang{border:2px solid #1d7a3e;background:#1fa152;color:#fff;font-weight:800;border-radius:999px;padding:.3em .9em;cursor:pointer;white-space:nowrap;font-size:inherit}
#smhfb .cdang.tat{background:#8a8578;border-color:#5f5a4e;color:#fff}#smhfb .cdang:hover{filter:brightness(1.12)}
#smhfb .cdang{flex:none}
/* (5.5) thanh thu gọn: nhóm chip có thể co lại, nút "Mở sheet" luôn hiện đủ (không bị nút Thu gọn che) */
#smhfb .bar .h2.chips{flex:0 1 auto;min-width:0;overflow:hidden}
#smhfb .bar .nsheet{flex:none;position:relative;z-index:1}
#smhfb .bar .tt{min-width:0}
#smhfb .bar .h1{padding-right:6px}
#smhfb.gon1 .bar .h2 .tg{padding-left:6px;padding-right:6px}#smhfb.gon1 .bar .h2.chips{gap:3px}#smhfb.gon1 .bar .h1{gap:0 6px}`;
  function veBang() {
    if (!document.body || vt.keo) return;
    const Z = coChu();
    let css = document.getElementById('smhfb-css');
    if (!css) { css = document.createElement('style'); css.id = 'smhfb-css'; document.head.appendChild(css); }
    if (css.getAttribute('data-z') !== String(Z)) { css.textContent = taoCSS(Z) + CSS_THEM; css.setAttribute('data-z', String(Z)); }
    let el = document.getElementById('smhfb');
    if (!el) { el = document.createElement('div'); el.id = 'smhfb'; document.body.appendChild(el); }
    const moRong = uiTab.moRong;
    const tabLuu = lay('ui_tab', 'homnay');
    const tab = ['homnay', 'saptoi', 'homqua', 'quet', 'lichsu', 'hethong', 'nhatky', 'khanh'].includes(tabLuu) && !(LA_GIAO && tabLuu === 'khanh') ? tabLuu : 'homnay';
    const t = trangThaiChinh();
    const dsViec = viecCanXuLy();
    if (t.den === 'xanh' && dsViec.length) t.den = 'vang';
    el.className = `k-${t.den}${fbToi() ? ' toi' : ''}${moRong ? ' mo-rong' : ''}`;
    const st = lay('sap_toi', null);
    const ngayThieu = ngayCanhBao();
    const soNgayThieu = ngayThieu.length;
    const s = lay('ngay_' + homNay(), null) || {};
    const tamDung = lay('tam_dung', false);
    const cuon = el.querySelector('.nd') ? el.querySelector('.nd').scrollTop : 0;
    const tipThieu = ngayThieu.map(({ n, ds }) => `${nhanNgayDai(n)}: ${ds.map((x) => x.t).join(', ')}`).join('\n');

    let html = `<div class="bar" data-keo="1">
        <div class="h1">
          <span class="grip" title="Kéo thanh này để di chuyển · bấm đúp để về chỗ cũ">⠿</span>
          <span class="den ${t.den}${t.nhay ? ' nhay' : ''}"></span>
          <span class="ten" title="Đăng bài fb kênh 1 · Máy ${LA_GIAO ? 'Giao' : 'Cao'}">${LA_GIAO ? 'GIAO' : 'CAO'}</span><button class="cdang ${dangTuDongBat() ? 'bat' : 'tat'}" data-a="cdang" title="Công tắc đăng 3 bài tự động của máy này (các tính năng kiểm tra khác vẫn chạy)">${dangTuDongBat() ? '⏻ ĐĂNG BÀI: BẬT' : '⏻ ĐĂNG BÀI: TẮT'}</button>
          ${chipViec()}
          <span class="tt" title="${esc(boThe(t.chu))}">${t.chu}</span>
          <div class="h2 chips">${dongThoiGian()}${chipQuet()}</div><button class="nsheet${soNgayThieu ? ' canh' : ''}" data-a="mosheet" title="${soNgayThieu ? esc(`Mở Lark sheet — nội dung còn thiếu trong ${CAI_DAT.CANH_BAO_THIEU_NGAY} ngày gần nhất:\n${tipThieu}`) : 'Mở Lark sheet'}">▦ Mở sheet${soNgayThieu ? ` · ${soNgayThieu} thiếu` : ''}</button>
          <div class="h2">${t.dem ? '<button class="nut nho do" data-a="huy">Hủy</button><button class="nut nho chinh" data-a="dangngay">Đăng ngay</button>' : ''}${quetDangChay() && !(hdHien() && hdHien().key === 'quet') ? '<button class="nut nho do" data-a="dungquet">⏹ Dừng quét</button>' : ''}</div>
          <div class="act">
          <button class="icon lon" data-a="morong" title="${moRong ? 'Thu gọn' : 'Mở rộng'}">${moRong ? '▴' : '▾'}</button></div>
        </div>
      </div>`;
    html += thanhHoatDong();
    if (moRong) {
      const dl = tinhTrangDuLieu(); const loiV = soVideoLoi();
      const sk = lay('suc_khoe', {}) || {};
      const huyHieu = (n, lop) => (n ? ` <span class="chip ${lop || 'loi'}">${n}</span>` : '');
      const TABS = [['homnay', `Hôm nay${huyHieu(dsViec.length)}`], ['saptoi', `Sắp tới${huyHieu(soNgayThieu)}`], ['homqua', 'Hôm qua'], ['quet', `Quét${huyHieu(loiV)}`], ['lichsu', 'Lịch sử'], ['hethong', `Hệ thống${dl.canh || sk.larkOk === false ? huyHieu('!') : ''}`], ['nhatky', 'Nhật ký'], ['khanh', 'Khanh TH']].filter(([k]) => !(LA_GIAO && k === 'khanh'));
      const noiDung = tab === 'saptoi' ? tabSapToi() : tab === 'homqua' ? tabHomQua() : tab === 'quet' ? tabQuet() : tab === 'lichsu' ? tabLichSu() : tab === 'hethong' ? tabHeThong() : tab === 'nhatky' ? tabNhatKy() : tab === 'khanh' ? tabKhanh() : tabHomNay();
      html += `<div class="tabs">${TABS.map(([k, ten]) => `<button class="tab ${tab === k ? 'chon' : ''}" data-tab="${k}">${ten}</button>`).join('')}</div>
        <div class="nd${tab === 'quet' || tab === 'hethong' ? ' cot2' : ''}">${noiDung}</div>
        <div class="foot">
        <div class="chan">
          <button class="nut ${tamDung ? 'vang' : ''}" data-a="tamdung">${tamDung ? '▶ Chạy lại' : '⏸ Tạm dừng'}</button>
        </div>
        <div class="chan vua">
          ${s.huy || s.dung || s.daChot ? '<button class="nut nho" data-a="batlai">↺ Bật lại hôm nay</button>' : '<button class="nut nho" data-a="huy">✕ Hủy hôm nay</button>'}
          <button class="nut nho" data-a="doigio">🕒 Đổi giờ hôm nay</button>
          <button class="nut nho" data-a="soanthu" title="Điền sẵn như thật rồi dừng trước nút Đăng">✎ Soạn thử</button>
          <button class="nut nho chinh" data-a="taoanhmf" title="Lấy chữ + ảnh nền trong sheet, tạo ảnh manifest rồi dán vào ô (chỉ chạy khi bấm)">🖼 Tạo ảnh manifest</button>
          <button class="nut nho chinh" data-a="soanmf" title="Ghép 1 ảnh + 1 bài nhạc trong sheet thành video 15 giây, xem trước rồi mới gắn vào hộp đăng bài">🎵 Soạn thử manifest</button>
          <button class="nut nho chinh" data-a="soanvideo" title="Lấy video ở cột N + chữ ở cột E (tab Kênh 1) gắn vào hộp đăng bài rồi DỪNG trước nút Đăng">🎬 Soạn thử video</button>
        </div>
        <div class="chan2">
          <span class="co" title="Cỡ chữ của khung">Cỡ chữ
            <button class="phu-nut" data-a="chunho" title="Nhỏ hơn">A−</button><b>${Math.round(Z * 100)}%</b><button class="phu-nut" data-a="chuto" title="To hơn">A+</button></span>
        </div></div>`;
    }
    el.innerHTML = html;
    if (el.querySelector('.nd')) el.querySelector('.nd').scrollTop = cuon;
    datViTri(el, uiTab.viTri || viTriMacDinh());
    // (5.5.1) thanh trên cùng hẹp: tự thu nhỏ khoảng cách rồi rút gọn chữ ô Quét để KHÔNG ô nào bị cắt
    try {
      const c = el.querySelector('.bar .h2.chips');
      if (c) {
        const tt = el.querySelector('.bar .tt'); if (tt) { tt.style.visibility = ''; if (tt.scrollWidth > tt.clientWidth + 1) tt.style.visibility = 'hidden'; } // chữ trạng thái bị cắt dở thì ẩn hẳn (đã có đèn + công tắc nói rõ)
        el.classList.remove('gon1', 'gon2');
        const thieu = () => c.scrollWidth > c.clientWidth + 1;
        if (thieu()) el.classList.add('gon1');
        if (thieu()) { el.classList.add('gon2'); const q = c.querySelector('[data-a="moquet"]'); if (q) q.textContent = q.textContent.replace(/^(🧹 Quét).*$/, '$1'); }
      }
    } catch (e) { /* */ }
  }

  // cập nhật đồng hồ đếm mỗi giây mà không vẽ lại cả khung
  let veTnLuc = 0;
  function capNhatDongHo() {
    const el = document.getElementById('smhfb'); if (!el || vt.keo) return;
    if (el.querySelector('.tn.run, .tn.xong, .tn.vang') && Date.now() - veTnLuc > 1500) { veTnLuc = Date.now(); setTimeout(veBang, 0); }
    el.querySelectorAll('[data-hdbd]').forEach((g) => { const bd = +g.getAttribute('data-hdbd'), dk = +g.getAttribute('data-hddk'); g.innerHTML = gioHd(bd, dk); const t = g.parentNode.querySelector('.hd-tien i'); if (t) t.style.width = Math.min(100, Math.round((Date.now() - bd) / Math.max(1, dk) * 100)) + '%'; });
    if (hdChay && hdChay.hien && Date.now() - hdChay.cap > 30000) { hdChay.cap = Date.now(); luu('hoat_dong', hdChay); }
    el.querySelectorAll('[data-dem]').forEach((dem) => { if (demNguocDen) dem.textContent = conLai(demNguocDen - Date.now()); });
    el.querySelectorAll('[data-hen]').forEach((hen) => { hen.textContent = conLai(+hen.getAttribute('data-hen') - Date.now()); });
  }

  // ---------------- kéo thả ----------------
  document.addEventListener('mousedown', (ev) => {
    const bar = ev.target.closest && ev.target.closest('#smhfb [data-keo]');
    if (!bar || ev.target.closest('button,a') || ev.button !== 0) return;
    const el = document.getElementById('smhfb'); const r = el.getBoundingClientRect();
    vt.keo = { dx: ev.clientX - (parseInt(el.dataset.bx, 10) || r.left), dy: ev.clientY - r.top }; el.classList.add('keo'); ev.preventDefault();
  }, true);
  document.addEventListener('mousemove', (ev) => {
    if (!vt.keo) return;
    datViTri(document.getElementById('smhfb'), { x: ev.clientX - vt.keo.dx, y: ev.clientY - vt.keo.dy });
  }, true);
  document.addEventListener('mouseup', () => {
    if (!vt.keo) return;
    const el = document.getElementById('smhfb'); el.classList.remove('keo');
    uiTab.viTri = { x: parseInt(el.dataset.bx, 10) || 0, y: parseInt(el.style.top, 10) };
    vt.keo = null; veBang();
  }, true);
  document.addEventListener('dblclick', (ev) => {
    if (!(ev.target.closest && ev.target.closest('#smhfb [data-keo]')) || ev.target.closest('button,a')) return;
    uiTab.viTri = null; veBang();
  }, true);
  // mở rộng xong, 10 giây không đụng tới (không rê chuột/bấm/cuộn/gõ trong popup) thì tự thu gọn lên
  ['mousemove', 'mousedown', 'keydown', 'wheel', 'touchstart'].forEach((e) => document.addEventListener(e, (ev) => { if (ev.target && ev.target.closest && ev.target.closest('#smhfb')) uiTab.moLuc = Date.now(); }, true));
  setInterval(() => {
    if (!uiTab.moRong) { uiTab.moLuc = 0; return; }
    const el = document.getElementById('smhfb'); if (!el) return;
    if (!uiTab.moLuc || vt.keo || el.contains(document.activeElement) && /INPUT|TEXTAREA/.test(document.activeElement.tagName)) { uiTab.moLuc = Date.now(); return; }
    if (Date.now() - uiTab.moLuc > 10000) { uiTab.moRong = false; uiTab.moLuc = 0; veBang(); }
  }, 1000);
  window.addEventListener('resize', () => { const el = document.getElementById('smhfb'); if (el) datViTri(el, uiTab.viTri || viTriMacDinh()); });

  // ---------------- các nút ----------------
  document.addEventListener('click', async (ev) => {
    const tabBtn = ev.target.closest && ev.target.closest('#smhfb [data-tab]');
    if (tabBtn) { luu('ui_tab', tabBtn.getAttribute('data-tab')); veBang(); return; }
    const a = ev.target.closest && ev.target.closest('#smhfb [data-a]');
    if (!a) return;
    const hd = a.getAttribute('data-a');
    if (['dangngay', 'quetngay', 'quetthu', 'kiem', 'kiembai', 'lammoi', 'anhmoi', 'rasoat', 'khanhthu', 'dangb23', 'tukiem', 'soanthu', 'batlai', 'ketnoi', 'kiemma'].includes(hd)) luu('thu_cong_den', Date.now() + 20 * 60000); // (5.7) bấm tay → chạy ngay dù đang có người dùng trang
    const ngay = homNay();
    if (hd === 'chon') { uiTab.chon = a.getAttribute('data-k'); uiTab.moRong = true; luu('ui_tab', 'homnay'); veBang(); return; }
    if (hd === 'ticklich' || hd === 'boticklich') {
      const k = a.getAttribute('data-k');
      capNhatNgay(ngay, (x) => { x.lich = x.lich || {}; if (hd === 'ticklich') x.lich[k] = { luc: Date.now(), tay: true }; else { delete x.lich[k]; x.lichLuc = 0; } });
      ghi(`Cao ${hd === 'ticklich' ? 'tick tay' : 'bỏ tick'} ${k}`); veBang(); return;
    }
    if (hd === 'moquet') { uiTab.moRong = true; luu('ui_tab', 'quet'); veBang(); return; }
    if (hd === 'moviec') { uiTab.moRong = true; luu('ui_tab', 'homnay'); veBang(); return; }
    if (hd === 'amBao') { luu('ui_am_bao', !lay('ui_am_bao', true)); veBang(); return; }
    if (hd === 'yen') { const dangYen = lay('quet_yen', 0) > Date.now(); luu('quet_yen', dangYen ? 0 : Date.now() + 3600e3); if (!dangYen && quetDangChay()) luu('quet_dung', Date.now()); ghi(dangYen ? 'Cao bỏ chế độ yên lặng' : 'Cao bật yên lặng 1 giờ (không tự quét)'); veBang(); return; }
    if (hd === 'locnk') { luu('ui_loc_nk', a.getAttribute('data-k')); veBang(); return; }
    if (hd === 'morong') { uiTab.moRong = !uiTab.moRong; if (uiTab.moRong) luu('ui_tab', 'homnay'); veBang(); return; }
    if (hd === 'dangngay') {
      if (lay('dang_do', null)) { alert('Có việc đăng/comment còn dở. Dùng Chạy lại để xác minh và tiếp tục, không tạo lượt đăng mới.'); return; }
      if (!confirm(`Đăng Bài 1 ngày ${ngay} lên "${CAI_DAT.TEN_TRANG}" ngay bây giờ?\n(Bỏ qua giờ hẹn và giãn cách 20 phút)`)) return;
      const s = trangThaiNgay(ngay); s.huy = false; s.loi = null; s.lanThu = 0; s.choDen = 0; luuNgay(ngay, s);
      luu('tam_dung', false);
      luu('dang_ngay', { ngay, luc: Date.now() }); ghi('Cao bấm "Đăng ngay"');
      if (!laTabChinh()) { // bấm ở tab phụ → tab này nhận làm luôn (trừ khi tab kia đang đăng dở)
        const k = GM_getValue('khoa_dang_bai_that', null);
        if (!(k && k.ban)) GM_setValue('khoa_dang_bai_that', { id: MA_TAB, ts: Date.now(), hien: document.visibilityState === 'visible', anTu: 0, ban: false, v: PHIEN_BAN });
      }
      nhip();
    }
    if (hd === 'huy') {
      if (!confirm('Hủy đăng Bài 1 hôm nay?')) return;
      luu('dung_moc', Math.max(Date.now(), lay('dung_moc', 0) + 1));
      const s = trangThaiNgay(ngay); s.huy = true; luuNgay(ngay, s);
      demNguocDen = 0; luu('dang_ngay', null); ghi('Cao đã hủy đăng hôm nay');
    }
    if (hd === 'batlai') { const s = trangThaiNgay(ngay); s.huy = false; s.dung = false; s.lyDoDung = ''; s.daChot = false; s.loi = null; s.lanThu = 0; luuNgay(ngay, s); ghi('Bật lại đăng bài hôm nay'); }
    if (hd === 'donghd') { const k = lay('hd_ket', null); if (k) { k.dong = true; luu('hd_ket', k); } veBang(); return; }
    if (hd === 'dongtb') { const tb = lay('quet_thongbao', null); if (tb) { tb.dong = true; luu('quet_thongbao', tb); } veBang(); return; }
    if (hd === 'dungquet') { luu('quet_dung', Date.now()); ghi('Cao bấm "Dừng quét"'); veBang(); return; }
    if (hd === 'gantay' || hd === 'bogantay') {
      const id = a.getAttribute('data-id'); const m = vidState();
      if (m[id]) { if (hd === 'gantay') m[id].tt = 'tay'; else { m[id].tt = 'loi'; m[id].lan = 1; m[id].cap = Date.now() - 31 * 60000; } luu('quet_video112', m); ghi(hd === 'gantay' ? 'Cao đánh dấu một video đã gắn tay' : 'Cao bỏ đánh dấu gắn tay một video'); }
      veBang(); return;
    }
    if (hd === 'cfg') { const kc = a.getAttribute('data-k'); const c = quetCfg(); if (kc in c) { c[kc] = !c[kc]; luu('quet_cfg', c); ghi('Cao ' + (c[kc] ? 'bật' : 'tắt') + ' mục quét: ' + kc); } veBang(); return; }
    if (hd === 'quetngay' || hd === 'quetthu') {
      const thu = hd === 'quetthu';
      if (lay('dang_do', null)) { alert('Có việc đăng/comment còn dở — đợi xong rồi quét.'); return; }
      if (lay('tam_dung', false)) { alert('Script đang tạm dừng. Bấm Chạy lại rồi quét.'); return; }
      if (!coApi()) { alert('Chưa cài mã khoá Facebook (🔑) nên script chưa đọc được danh sách bài để quét.'); return; }
      if (dangQuet) { alert('Đang quét rồi — đợi lượt này xong.'); return; }
      if (!confirm(thu ? 'Quét thử bây giờ?\n• Chỉ liệt kê việc sẽ làm (video cần kiểm tra, bài/comment sẽ Thích), KHÔNG bấm gì trên Facebook\n\nGiữ tab Facebook này hiện trên màn hình trong lúc quét thử.' : 'Quét ngay bây giờ?\n• Gắn thẻ "' + CAI_DAT.TAG_TEN + '" + cảm xúc cho video 24h qua chưa gắn (trừ #Manifest, tối đa ' + CAI_DAT.QUET_VIDEO_TOI_DA + ' video)\n• Thích/Yêu thích bài + comment 48h qua chưa có\n\nGiữ tab Facebook này hiện trên màn hình trong lúc quét (vài phút).')) return;
      luu('quet_ngay', { luc: Date.now(), thu }); ghi(thu ? 'Cao bấm "Quét thử"' : 'Cao bấm "Quét ngay"');
      if (!laTabChinh()) { const k = GM_getValue('khoa_dang_bai_that', null); if (!(k && k.ban)) GM_setValue('khoa_dang_bai_that', { id: MA_TAB, ts: Date.now(), hien: document.visibilityState === 'visible', anTu: 0, ban: false, v: PHIEN_BAN }); }
      nhip(); veBang(); return;
    }
    if (hd === 'cdang') {
      const moi = !dangTuDongBat();
      if (moi && !confirm('Bật đăng 3 bài tự động trên máy này?\n(Hãy chắc chắn máy kia không đang đăng. Script sẽ kiểm trên trang và chỉ đăng bài còn thiếu.)')) return;
      luu('dang_tu_dong', moi); if (!moi) { demNguocDen = 0; luu('dang_ngay', null); }
      ghi(moi ? 'Cao BẬT đăng bài tự động trên máy này' : 'Cao TẠM DỪNG đăng bài tự động trên máy này'); veBang(); if (moi) setTimeout(nhip, 500); return;
    }
    if (hd === 'tamdung') {
      const moi = !lay('tam_dung', false); if (moi) luu('dung_moc', Math.max(Date.now(), lay('dung_moc', 0) + 1)); luu('tam_dung', moi); if (moi) { demNguocDen = 0; luu('dang_ngay', null); }
      ghi(moi ? 'Cao tạm dừng toàn bộ script' : 'Cao cho script chạy lại');
    }
    if (hd === 'doigio') {
      const s = trangThaiNgay(ngay);
      const nhap = prompt(`Giờ đăng hôm nay đang là ${phutStr(s.gio)}.\nNhập giờ mới (HH:MM, trước ${CAI_DAT.GIO_CHOT}):`, phutStr(s.gio));
      if (nhap == null) return;
      const mm = nhap.trim().match(/^(\d{1,2})[:h.](\d{2})$/);
      if (!mm || +mm[1] > 23 || +mm[2] > 59) { alert('Giờ không hợp lệ, ví dụ đúng: 07:45'); return; }
      const p = +mm[1] * 60 + +mm[2];
      if (p >= docGio(CAI_DAT.GIO_CHOT)) { alert(`Giờ đăng phải trước ${CAI_DAT.GIO_CHOT}`); return; }
      s.gio = p; s.choDen = 0; luuNgay(ngay, s); demNguocDen = 0; ghi('Đổi giờ đăng hôm nay thành ' + phutStr(p));
    }
    if (hd === 'kiem') { yeuCauViec('kiem'); return; }
    if (hd === 'ketnoi') { yeuCauViec('ketnoi'); return; }
    if (hd === 'lammoi' || hd === 'kiembai') { capNhatNgay(ngay, (x) => { x.lichLuc = 0; }); yeuCauViec(hd); veBang(); return; }

    if (hd === 'caima') { if (!laTabChinh() || dangChay) { alert('Dùng nút Dùng tab này và đợi lượt đang chạy xong rồi cài mã.'); return; } await caiMaKhoa(); return; }
    if (hd === 'kiemma') { yeuCauViec('kiemma'); return; }
    if (hd === 'anhmoi') { yeuCauViec('anhmoi'); veBang(); return; }
    if (hd === 'rasoat') { yeuCauViec('rasoat', { so: Math.max(1, +(a.getAttribute('data-so') || 5)) }); veBang(); return; }
    if (hd === 'khanhthu') { yeuCauViec('khanhthu'); veBang(); return; }
    if (hd === 'dungtab') {
      const k = GM_getValue('khoa_dang_bai_that', null);
      if (k && k.ban) { alert('Tab kia đang đăng bài dở — đợi xong rồi bấm lại.'); return; }
      GM_setValue('khoa_dang_bai_that', { id: MA_TAB, ts: Date.now(), hien: document.visibilityState === 'visible', anTu: 0, ban: false, v: PHIEN_BAN, ghim: true });
      ghi('Cao đặt tab này làm Main (tab chính)'); nhip(); veBang();
    }
    if (hd === 'mobai') { window.open(a.getAttribute('data-link'), '_blank', 'noopener'); return; }
    if (hd === 'timbai1') {
      const hs = hangHomNay() || []; const k = a.getAttribute('data-k');
      const h = hs.find((x) => ngay + '|' + bam(x.bai) === k);
      if (!(h && cuonToiBai(h.bai))) {
        if (!dungTrang()) { roiTrang(CAI_DAT.URL_TRANG); return; }
        alert('Chưa thấy bài này trong phần trang đang hiện. Script sẽ tự lấy link bài trong vài phút tới — khi đó bấm lại là mở được bài.');
      }
      yeuCauViec('dobai');
      return;
    }
    if (hd === 'dangb23') {
      const k = a.getAttribute('data-k'); const t = mucTieuB23(hangHomNay() || []).find((x) => x.k === k); if (!t) return;
      if (lay('dang_do', null)) { alert('Có việc đăng/comment còn dở — đợi xong rồi bấm lại.'); return; }
      if (!confirm(`Đăng Bài ${t.loai} ngày ${ngay} lên "${CAI_DAT.TEN_TRANG}" ngay bây giờ?\n(Bỏ qua giờ hẹn; vẫn giữ giãn cách ${CAI_DAT.CACH_BAI_KHAC_PHUT} phút với bài gần nhất)`)) return;
      luu('tam_dung', false);
      capNhatNgay(ngay, (x) => { x.huy = false; x.dungB23 = false; x.daChotB23 = false; x.choDenB23 = 0; if (x.thuLaiB23) delete x.thuLaiB23[k]; x.epB23 = k; });
      ghi(`Cao bấm "Đăng Bài ${t.loai} ngay"`); veBang(); nhip(); return;
    }
    if (hd === 'danhdau') {
      const k = a.getAttribute('data-k'); const t = mucTieuB23(hangHomNay() || []).find((x) => x.k === k);
      if (!t) return;
      if (!confirm(`Đánh dấu Bài ${t.loai} (hàng ${t.hang}) hôm nay ĐÃ ĐĂNG?\n\nDùng khi bài đã lên trang nhưng script không nhận ra (ví dụ chữ đăng lên khác chữ trên sheet).\nScript sẽ ghi nhận bài này đã đăng và không nhắc lúc ${CAI_DAT.GIO_NHAC_BAI23} nữa.`)) return;
      let s = trangThaiNgay(ngay); s.b23 = s.b23 || {}; s.b23[k] = { tt: 'tay', luc: Date.now(), hang: t.hang }; luuNgay(ngay, s);
      ghi(`Cao đánh dấu Bài ${t.loai} (hàng ${t.hang}) đã đăng`); veBang();
      if (t.text) { const g = await gachBai23(ngay, t); capNhatNgay(ngay, (x) => { if (x.b23 && x.b23[k]) x.b23[k].gach = g; }); }
      yeuCauViec('lammoi');
    }
    if (hd === 'bodanhdau') {
      const k = a.getAttribute('data-k');
      if (!confirm('Bỏ đánh dấu bài này? Script sẽ dò lại xem bài đã lên trang chưa.')) return;
      const s = trangThaiNgay(ngay); if (s.b23) delete s.b23[k]; s.doLuc = 0; luuNgay(ngay, s); ghi('Cao bỏ đánh dấu ' + k);
    }
    if (hd === 'tukiem') {
      if (!confirm('Tự kiểm ngay: script mở thử hộp đăng bài, xem đủ nền đỏ / vị trí / nút Tiếp rồi đóng lại — KHÔNG đăng gì. Tiếp tục?')) return;
      if (lay('tam_dung', false)) { alert('Script đang tạm dừng. Bấm Chạy lại trước khi tự kiểm.'); return; }
      luu('tu_kiem_ngay', { luc: Date.now() }); ghi('Cao bấm "Tự kiểm ngay"');
      const s = trangThaiNgay(ngay); delete s.tuKiem; luuNgay(ngay, s); nhip();
    }
    if (hd === 'xemsaptoi') { luu('ui_tab', 'saptoi'); uiTab.moRong = true; }
    if (hd === 'chuto' || hd === 'chunho') {
      const z = Math.round((coChu() + (hd === 'chuto' ? 0.1 : -0.1)) * 10) / 10;
      luu('ui_co_chu', Math.min(1.6, Math.max(0.9, z)));
    }
    if (hd === 'tinthu') { yeuCauViec('tinthu'); return; }

    if (hd === 'mosheet') { window.open(CAI_DAT.LINK_SHEET, '_blank', 'noopener'); }
    if (hd === 'baoloi') { await xuatBaoLoi(); return; }
    if (hd === 'taoanhmf') {
      const v = prompt('TẠO ẢNH MANIFEST\nGõ 3 ô cách nhau dấu cách: ô CHỮ · ô ẢNH NỀN · ô DÁN ẢNH (tab "Kênh 1 Vòng Trầm Hương SMH")', lay('mf_tao_o', 'Q213 R213 S213')); if (!v) return;
      const [oC, oN, oG] = v.trim().toUpperCase().split(/[\s,;]+/);
      if (!oC || !oN || !oG) { alert('Cần đủ 3 ô, ví dụ: Q213 R213 S213'); return; }
      luu('mf_tao_o', `${oC} ${oN} ${oG}`); ghi(`Cao bấm "Tạo ảnh manifest" — chữ ${oC}, nền ${oN}, dán vào ${oG}`);
      theoDoi('taoanhmf', () => taoAnhMFVaoO(oC, oN, oG), 'Đang tạo ảnh manifest và dán vào ô ' + oG);
      return;
    }
    if (hd === 'soanmf') {
      const oA = prompt('SOẠN THỬ MANIFEST (bước 1/4)\nÔ chứa ẢNH manifest trong tab "Kênh 1 Vòng Trầm Hương SMH" (ví dụ N214):', lay('mf_o_anh', 'N214')); if (!oA) return;
      const oN = prompt('SOẠN THỬ MANIFEST (bước 2/4)\nÔ chứa file NHẠC (mp3) trong cùng tab (ví dụ N215):', lay('mf_o_nhac', 'N215')); if (!oN) return;
      const dsHU = HIEU_UNG_MF.map(([, t], i) => (i + 1) + ' = ' + t).join('\n');
      const sHU = prompt('SOẠN THỬ MANIFEST (bước 3/4)\nChọn hiệu ứng (gõ số), để 0 = ngẫu nhiên:\n' + dsHU, String(lay('mf_hu', 0))); if (sHU === null) return;
      const nHU = parseInt(sHU, 10) || 0; luu('mf_hu', nHU); const hieuUng = nHU >= 1 && nHU <= HIEU_UNG_MF.length ? HIEU_UNG_MF[nHU - 1][0] : '';
      const chu = prompt('SOẠN THỬ MANIFEST (bước 4/4)\nChữ mô tả khi đăng (có thể để trống):', lay('mf_chu', '#Manifest')); if (chu === null) return;
      luu('mf_o_anh', oA.trim()); luu('mf_o_nhac', oN.trim()); luu('mf_chu', chu);
      ghi(`Cao bấm "Soạn thử manifest" — ảnh ${oA.trim()}, nhạc ${oN.trim()}`);
      theoDoi('soanmf', () => soanThuManifest(oA.trim(), oN.trim(), chu, hieuUng), 'Đang soạn thử manifest (ảnh + nhạc → video 15 giây)');
      return;
    }
    if (hd === 'soanvideo') {
      const sv = prompt('SOẠN THỬ VIDEO (dừng trước nút Đăng)\n\nNhập số hàng trong tab "Kênh 1 Vòng Trầm Hương SMH" có video ở cột N:', String(lay('soan_video_hang', 213)));
      const hang = parseInt(sv, 10); if (!hang || hang < 2) return;
      luu('soan_video_hang', hang); ghi('Cao bấm "Soạn thử video" — hàng ' + hang);
      theoDoi('soanvideo', () => soanThuVideo(hang), 'Đang soạn thử video hàng ' + hang);
      return;
    }
    if (hd === 'soanthu') {
      if (!confirm('Soạn thử: script sẽ điền đủ nội dung, nền, vị trí, nhóm rồi DỪNG trước nút Đăng để Cao xem.\nKhông bấm Đăng thì nhớ đóng hộp lại. Tiếp tục?')) return;
      if (lay('tam_dung', false)) { alert('Script đang tạm dừng. Bấm Chạy lại trước khi soạn thử.'); return; }
      luu('soan_thu', { luc: Date.now() }); ghi('Cao bấm "Soạn thử"'); nhip();
    }
    veBang();
  }, true);

  async function xuatBaoLoi() {
    const ngay = homNay();
    const hopDangMo = Array.from(document.querySelectorAll('div[role="dialog"]')).filter(dangHien).map((d) => chuan(d.innerText).slice(0, 150));
    const noiDung = [
      `BÁO LỖI — ${TEN_HE_THONG} · bản CHẠY THẬT ${(typeof GM_info !== 'undefined' && GM_info.script && GM_info.script.version) || PHIEN_BAN}`,
      `Lúc: ${ngayStr(new Date())} ${gioStr(new Date())}:${pad(new Date().getSeconds())}`,
      `Trang đang mở: ${location.origin}${location.pathname}`,
      `Tab này đang làm việc: ${laTabChinh() ? 'có' : 'không (tab phụ)'} · tab ${document.visibilityState === 'visible' ? 'đang hiện' : 'bị ẩn'} · tạm dừng: ${lay('tam_dung', false) ? 'có' : 'không'}`,
      `Hộp thoại đang mở: ${hopDangMo.length ? hopDangMo.join(' || ') : 'không có'}`,
      `Trạng thái ngày ${ngay}: ${JSON.stringify(lay('ngay_' + ngay, null))}`,
      `Quét hôm nay: ${JSON.stringify({ lan: trangThaiNgay(ngay).quetLan, quet: trangThaiNgay(ngay).quet, tong: trangThaiNgay(ngay).quetTong, dang: dangQuet })}`,
      `Video đã xử lý (5 ngày): ${JSON.stringify(lay('quet_video112', null))}`,
      `Quét — công tắc: ${JSON.stringify(quetCfg())}; quét thử gần nhất: ${JSON.stringify(lay('quet_thu', null))}`,
      `Quét — video 24h qua: ${Object.entries(vidState()).filter(([, v]) => v.gio && Date.now() - v.gio < 26 * 3600e3).sort((a, b) => b[1].gio - a[1].gio).map(([id, v]) => `[${gioStr(new Date(v.gio))} ${v.tt}${v.lan ? ' lần ' + v.lan : ''}${v.loi ? ' "' + v.loi + '"' : ''} ${id}]`).join(' ') || '(chưa có)'}`,
      `Việc dở dang: ${JSON.stringify(lay('dang_do', null))}`,
      `Tiến trình: ${JSON.stringify(lay('tien_trinh', null))}`,
      `Soạn thử đang chờ: ${JSON.stringify(lay('soan_thu', null))}`,
      `Tab xuất báo lỗi: ${MA_TAB}; tab giữ quyền: ${JSON.stringify(GM_getValue('khoa_dang_bai_that', null))}`,
      `Giờ hẹn: ${phutStr(trangThaiNgay(ngay).gio)}; lý do dừng: ${trangThaiNgay(ngay).lyDoDung || ''}; chờ đến: ${trangThaiNgay(ngay).choDen || 0}`,
      `Dữ liệu lịch: ${JSON.stringify({ luc: (lay('sap_toi', {}) || {}).luc || 0, canhBao: tinhTrangDuLieu().canh })}`,
      `Tình trạng Lark: ${JSON.stringify(lay('lark_gate', null))}; số yêu cầu hôm nay (bản ${PHIEN_BAN}): ${JSON.stringify(lay('lark_dem', null))}`,
      `Comment Bài 1: ${JSON.stringify(Object.values(trangThaiNgay(ngay).bai).map((b) => ({ hang: b.hang, xacNhan: b.cmtTrangThai || 'ban_cu', camXucBai: b.camXucBai, camXucCmt: b.camXucCmt })))}`,
      `Sức khoẻ: ${JSON.stringify(lay('suc_khoe', null))}`,
      `Kiểm sheet ngày mai: ${JSON.stringify(lay('kiem_' + ngayMai(), null))}`,
      '',
      '— NHẬT KÝ TỪNG BƯỚC —',
      ...docNhatKy(),
    ].map(anBiMat).join('\n');
    let daCopy = false;
    try { await navigator.clipboard.writeText(noiDung); daCopy = true; } catch (e) {
      const ta = document.createElement('textarea'); ta.value = noiDung; document.body.appendChild(ta); ta.select();
      try { daCopy = document.execCommand('copy'); } catch (e2) { /* */ } ta.remove();
    }
    const a = document.createElement('a');
    a.href = URL.createObjectURL(new Blob([noiDung], { type: 'text/plain;charset=utf-8' }));
    a.download = `bao-loi-dang-bai-that-${ngay}-${gioStr(new Date()).replace(':', 'h')}.txt`;
    document.body.appendChild(a); a.click(); a.remove();
    alert((daCopy ? 'Đã copy bản báo lỗi và ' : '') + 'đã tải file báo lỗi về máy.\nCao gửi file đó để kiểm tra lỗi.');
  }

  GM_registerMenuCommand('Quét Thích & gắn thẻ video ngay', () => { luu('quet_ngay', { luc: Date.now() }); ghi('Cao chọn menu Quét ngay'); nhip(); });
  GM_registerMenuCommand('Kiểm sheet ngày mai ngay', () => yeuCauViec('kiem'));
  GM_registerMenuCommand('Cài / đổi mã khoá Facebook (chỉ đọc)', () => { if (!laTabChinh() || dangChay) { alert('Dùng tab làm việc và đợi lượt đang chạy xong để cài mã.'); return; } caiMaKhoa(); });
  GM_registerMenuCommand('Kiểm tra mã khoá Facebook', () => yeuCauViec('kiemma'));
  GM_registerMenuCommand('Dò bài trên trang ngay (Bài 2/3, link Bài 1)', () => yeuCauViec('dobai'));
  GM_registerMenuCommand('Đưa popup về vị trí mặc định', () => { uiTab.viTri = null; veBang(); });
  GM_registerMenuCommand('Xoá trạng thái hôm nay (chỉ dùng khi chắc chắn bài chưa lên trang)', () => {
    const ngay = homNay();
    if (confirm(`Xoá trạng thái ngày ${ngay}? Script sẽ coi như hôm nay chưa đăng bài nào.`)) {
      GM_deleteValue(K('ngay_' + ngay)); luu('dang_do', null); ghi('Đã xoá trạng thái ngày ' + ngay);
    }
  });

  // =====================================================================
  //  2.0 — ĐĂNG BÀI 2 VÀ BÀI 3 CÓ ẢNH (ảnh lấy từ ô trong Lark sheet)
  //   Bài 2: chữ cột D + ảnh cột I–K, comment cột E.
  //   Bài 3: chữ cột F + ảnh cột L–N; comment: chữ cố định → ảnh cố định (ô O2) → 1 ảnh ngẫu nhiên (P2,Q2,O3,P3,Q3) → các ảnh cột O–Q của hàng hôm nay.
  //   Mỗi bài: vị trí "Sơn Mộc Hương" + chia sẻ 9 nhóm; cách bài gần nhất trên trang ≥ 20 phút. Ngày CAI_DAT.NGAY_THU_B23: soạn sẵn rồi dừng trước nút Đăng.
  // =====================================================================
  class LoiThieuAnh extends LoiMem {}

  // Tải 1 ảnh trong ô sheet về máy (qua Lark API, dùng khoá app sẵn có) → File
  // ---- kho ảnh tạm (IndexedDB): ảnh đã tải/thu nhỏ được giữ 36 giờ, dùng lại khi đăng/comment/gửi bù (kể cả lúc Lark lỗi) ----
  let khoDb = null;
  const khoMo = () => khoDb || (khoDb = new Promise((res, rej) => { const q = indexedDB.open('smh_anh_kho', 1); q.onupgradeneeded = () => q.result.createObjectStore('anh'); q.onsuccess = () => res(q.result); q.onerror = () => { khoDb = null; rej(q.error); }; }));
  async function khoLay(k) { try { const d = await khoMo(); return await new Promise((res) => { const r = d.transaction('anh').objectStore('anh').get(k); r.onsuccess = () => res(r.result || null); r.onerror = () => res(null); }); } catch (e) { return null; } }
  async function khoLuu(k, blob) { try { const d = await khoMo(); await new Promise((res) => { const t = d.transaction('anh', 'readwrite'); t.objectStore('anh').put({ blob, luc: Date.now(), size: blob.size }, k); t.oncomplete = () => res(); t.onerror = () => res(); t.onabort = () => res(); }); } catch (e) { /* kho lỗi thì thôi, vẫn tải trực tiếp */ } }
  async function khoDonTong() {
    try {
      const d = await khoMo(); let tong = 0, xoa = 0, n = 0;
      await new Promise((res) => { const t = d.transaction('anh', 'readwrite'); const st = t.objectStore('anh'); const cur = st.openCursor();
        cur.onsuccess = () => { const c = cur.result; if (!c) return; if (Date.now() - (c.value.luc || 0) > 36 * 3600e3) { c.delete(); xoa++; } else { tong += c.value.size || 0; n++; } c.continue(); };
        t.oncomplete = () => res(); t.onerror = () => res(); t.onabort = () => res(); });
      return { tong, xoa, n };
    } catch (e) { return { tong: 0, xoa: 0, n: 0 }; }
  }
  const MA_KHOA_LARK = ['99991403', '99991400', '429', '91403', '99991672', '99991676', '99991679', '99991668', '10014']; // hết hạn mức / giới hạn tốc độ / quyền ứng dụng → mới khoá Lark
  async function taiAnhLark(token, ten) {
    const trongKho = await khoLay(token);
    if (trongKho && trongKho.blob && trongKho.blob.size > 500) { ghi('Ảnh ' + ten + ': lấy từ bộ nhớ tạm (không gọi Lark)'); return new File([trongKho.blob], ten + (/png/.test(trongKho.blob.type) ? '.png' : '.jpg'), { type: trongKho.blob.type || 'image/jpeg' }); }
    const gate = chanLark();
    if (gate) throw new LoiLark(gate.msg + ' — đang chờ kiểm tra lại');
    let loiCuoi = null;
    for (let lan = 0; lan < 3; lan++) { // (4.5) mất mạng/quá lâu/máy chủ bận → thử lại; mã truy cập hết hạn → lấy mã mới
      if (lan) await sleep(3000 + Math.floor(Math.random() * 4000));
      const t = await larkToken();
      capNhat('lark_dem', { ngay: homNay(), so: (lay('lark_dem', {}).ngay === homNay() ? lay('lark_dem', {}).so || 0 : 0) + 1 });
      const r = await new Promise((resolve) => {
        GM_xmlhttpRequest({
          method: 'GET', url: 'https://open.larksuite.com/open-apis/drive/v1/medias/' + encodeURIComponent(token) + '/download',
          headers: { Authorization: 'Bearer ' + t }, responseType: 'blob', timeout: 120000,
          onload: (x) => resolve({ status: x.status, blob: x.response }),
          onerror: () => resolve({ mang: 'Mất kết nối khi tải ảnh từ Lark' }),
          ontimeout: () => resolve({ mang: 'Tải ảnh từ Lark quá lâu' }),
        });
      });
      if (r.mang) { loiCuoi = new LoiMem(r.mang); continue; }
      let blob = r.blob; let j = null;
      const laAnh = blob && blob.size > 500 && /^image\//.test(blob.type || '');
      if (!laAnh) { try { if (blob && blob.text) j = JSON.parse(await blob.text()); } catch (e2) { /* */ } }
      if (j && j.code != null && j.code !== 0) {
        const ma = String(j.code);
        if (MA_TOKEN_LARK.includes(ma)) { boTokenLark(); loiCuoi = new LoiMem('Mã truy cập Lark hết hạn'); continue; }
        if (MA_KHOA_LARK.includes(ma)) throw loiLark(ma, j.msg);
        throw new LoiMem('Ô ảnh này Lark báo lỗi (mã ' + ma + ') — có thể ảnh đã bị xoá hoặc không có quyền');
      }
      if (r.status >= 500 || !blob) { loiCuoi = new LoiMem('Không tải được ảnh từ Lark (mã ' + r.status + ')'); continue; }
      if (!(r.status >= 200 && r.status < 300) || blob.size <= 500) throw new LoiMem('Không tải được ảnh từ Lark (mã ' + r.status + ')');
      if (!/^image\//.test(blob.type || '') && blob.type && blob.type !== 'application/octet-stream') throw new LoiMem('Ô này không phải ảnh (loại ' + blob.type + ')');
      const fAnh = await thuNhoAnh(blob, ten); await khoLuu(token, fAnh);
      return fAnh;
    }
    throw loiCuoi || new LoiMem('Không tải được ảnh từ Lark');
  }

  // Sáng sớm: tải sẵn ảnh cả ngày (Bài 2, Bài 3, ảnh comment) vào kho tạm — giờ ngẫu nhiên, mỗi ảnh cách nhau vài giây
  // (5.3) tải sẵn ảnh của NGÀY MAI từ chiều hôm trước (16:10–17:00), tối đa 3 lượt, mỗi lượt cách ≥20 phút; sáng hôm sau chỉ kiểm bù lúc 06:30
  async function taiTruocAnhMai() {
    if (CAI_DAT.TAI_TRUOC_ANH === false || !dangTuDongBat()) return;
    if (!laTabChinh() || lay('tam_dung', false) || lay('dang_do', null) || lay('soan_thu', null) || dangBan || demNguocDen || chanLark()) return;
    const ngay = ngayMai(); const k = 'truoc_mai_' + ngay; let t = lay(k, null);
    if (!t) { t = { gio: 19 * 60 + Math.floor(Math.random() * 10), lan: 0 }; luu(k, t); ghi('Tải sẵn ảnh ngày mai lúc ' + pad(Math.floor(t.gio / 60)) + ':' + pad(t.gio % 60)); }
    const m = phutTrongNgay(new Date());
    if (t.xong || t.lan >= 3 || m < t.gio || m > 21 * 60 + 30 || Date.now() - (t.thuLuc || 0) < 20 * 60000) return;
    t.lan++; t.thuLuc = Date.now(); luu(k, t);
    let v; try { v = await docSheet(); } catch (e) { ghi('Tải sẵn ảnh ngày mai: chưa đọc được sheet (' + e.message + ') — thử lại sau'); return; }
    const hs = hangCuaNgay(v, ngay); if (!hs.length) { ghi('Tải sẵn ảnh ngày mai: sheet chưa có hàng của ngày mai — thử lại sau'); return; }
    const toks = new Set(); const chung = anhChung(v);
    if (chung.co) toks.add(chung.co); (chung.pool || []).forEach((x) => toks.add(x));
    for (const h of hs) [...(h.anh2 || []), ...(h.anh3 || []), ...(h.anhCmt || [])].forEach((x) => toks.add(x));
    let moi = 0, loi = 0, co = 0;
    for (const tk of toks) {
      if (lay('dang_do', null) || dangBan) break;
      if (await khoLay(tk)) { co++; continue; }
      try { await taiAnhLark(tk, 'truoc'); moi++; await sleep(1500 + Math.floor(Math.random() * 3000)); }
      catch (e) { loi++; ghi('Tải sẵn ảnh ngày mai: một ảnh lỗi (' + e.message + ')'); if (e instanceof LoiLark) break; }
    }
    t.xong = toks.size > 0 && loi === 0 && moi + co === toks.size; luu(k, t);
    ghi(`Tải sẵn ảnh ngày mai: ${toks.size} ảnh (${co} đã có, ${moi} tải mới${loi ? ', ' + loi + ' lỗi' : ''})`);
  }
  async function taiTruocAnh(ep = false) {
    if (CAI_DAT.TAI_TRUOC_ANH === false && !ep) return;
    const haiNgay = !ep && !LA_GIAO && !dangTuDongBat(); // (5.8) máy Cao không tự đăng: tự tải ảnh 2 ngày/lần (bấm tay vẫn tải ngay)
    if (!ep && !dangTuDongBat() && !haiNgay) return;
    if (haiNgay && Date.now() - lay('anh_2ngay', 0) < 48 * 3600e3) return;
    if (ep && (lay('dang_do', null) || dangBan)) { ghi('Cập nhật ảnh mới: đang có việc đăng/comment dở — bấm lại sau khi xong'); return; }
    if (!laTabChinh() || lay('tam_dung', false) || lay('dang_do', null) || lay('soan_thu', null) || dangBan || demNguocDen) return;
    const ngay = homNay(); let s = lay('ngay_' + ngay, null); if (!s) return;
    if (!ep && s.truoc && (s.truoc.xong || s.truoc.lan >= 3)) return;
    if (!s.truoc) { const gio = 6 * 60 + 30 + Math.floor(Math.random() * 8); s = capNhatNgay(ngay, (x) => { x.truoc = { gio, lan: 0 }; }); ghi('Tải sẵn ảnh trong ngày lúc ' + pad(Math.floor(gio / 60)) + ':' + pad(gio % 60)); }
    const m = phutTrongNgay(new Date()); if (!ep && (m < s.truoc.gio || m > 20 * 60)) return;
    if (!ep && Date.now() - (s.truoc.thuLuc || 0) < 10 * 60000) return;
    capNhatNgay(ngay, (x) => { x.truoc.thuLuc = Date.now(); x.truoc.lan = (x.truoc.lan || 0) + 1; });
    if (chanLark()) { if (ep) ghi('Cập nhật ảnh mới: Lark đang bị giới hạn nên chưa đọc được sheet'); return; }
    let v; try { v = await docSheet({ moi: ep }); } catch (e) { ghi('Tải sẵn ảnh: chưa đọc được sheet (' + e.message + ') — thử lại sau'); return; }
    const toks = new Set(); const chung = anhChung(v);
    if (chung.co) toks.add(chung.co); (chung.pool || []).forEach((t) => toks.add(t));
    for (const nx of (ep || haiNgay ? [ngay, ngayMai()] : [ngay])) for (const h of hangCuaNgay(v, nx)) [...(h.anh2 || []), ...(h.anh3 || []), ...(h.anhCmt || [])].forEach((t) => toks.add(t)); // (5.3) bấm tay thì tải luôn ảnh ngày mai
    const don = await khoDonTong(); let moi = 0, loi = 0, co = 0;
    for (const t of toks) {
      if (lay('dang_do', null) || dangBan) break;
      if (await khoLay(t)) { co++; continue; }
      try { await taiAnhLark(t, 'truoc'); moi++; await sleep(1500 + Math.floor(Math.random() * 3000)); }
      catch (e) { loi++; ghi('Tải sẵn ảnh: một ảnh lỗi (' + e.message + ') — lúc dùng sẽ tải lại'); if (e instanceof LoiLark) break; }
    }
    const tk = await khoDonTong();
    capNhatNgay(ngay, (x) => { x.truoc.xong = loi === 0 && moi + co === toks.size; x.truoc.moi = moi; x.truoc.loi = loi; x.truoc.luc = Date.now(); x.truoc.kho = tk.n; x.truoc.mb = +(tk.tong / 1048576).toFixed(1); });
    luu('anh_tai_cuoi', { luc: Date.now(), kho: tk.n, mb: +(tk.tong / 1048576).toFixed(1), moi, loi });
    if (loi === 0 && (haiNgay || ep)) luu('anh_2ngay', Date.now());
    ghi(`Tải sẵn ảnh: ${toks.size} ảnh cần dùng (${co} đã có sẵn, ${moi} tải mới${loi ? ', ' + loi + ' lỗi' : ''}) — kho tạm đang giữ ${tk.n} ảnh, khoảng ${(tk.tong / 1048576).toFixed(1)} MB${don.xoa ? '; đã dọn ' + don.xoa + ' ảnh cũ' : ''}`);
  }
  // Ảnh quá lớn (ảnh gốc điện thoại ~5MB, 3000px) thì thu nhỏ cho Facebook tải lên nhanh; ảnh vừa thì giữ nguyên
  async function thuNhoAnh(blob, ten) {
    const duoi = /png/.test(blob.type) ? 'png' : 'jpg';
    try {
      const bm = await createImageBitmap(blob);
      const lon = Math.max(bm.width, bm.height); const cap = CAI_DAT.ANH_CANH_TOI_DA;
      if (lon <= cap && blob.size <= 3.5e6) { if (bm.close) bm.close(); return new File([blob], ten + '.' + duoi, { type: blob.type || 'image/jpeg' }); }
      const k = Math.min(1, cap / lon);
      const c = document.createElement('canvas'); c.width = Math.max(1, Math.round(bm.width * k)); c.height = Math.max(1, Math.round(bm.height * k));
      c.getContext('2d').drawImage(bm, 0, 0, c.width, c.height); if (bm.close) bm.close();
      const out = await new Promise((r) => c.toBlob(r, 'image/jpeg', 0.9));
      if (out && out.size > 500) return new File([out], ten + '.jpg', { type: 'image/jpeg' });
    } catch (e) { /* dùng ảnh gốc */ }
    return new File([blob], ten + '.' + duoi, { type: blob.type || 'image/jpeg' });
  }

  const demAnhLon = (d) => Array.from(d.querySelectorAll('img')).filter((i) => { const r = i.getBoundingClientRect(); return r.width > 80 && r.height > 80; }).length;
  // Hộp soạn bài còn ảnh của bản nháp cũ → gỡ hết trước khi gắn ảnh mới
  async function xoaAnhCu(dlg) {
    for (let i = 0; i < 5; i++) {
      const h = hopSoanBai(); if (!h) return;
      const x = h.querySelector('[aria-label="Gỡ file đính kèm trong bài viết"]'); if (!x) return;
      x.click(); await sleep(900);
    }
  }
  async function ganAnhVaoHop(files) {
    await xoaAnhCu();
    const dlg = hopSoanBai(); if (!dlg) throw new LoiMem('Hộp soạn bài đã đóng');
    const truoc = demAnhLon(dlg);
    const inp = Array.from(dlg.querySelectorAll('input[type="file"]')).find((i) => /image/.test(i.accept || '') && i.multiple) || dlg.querySelector('input[type="file"]');
    if (!inp) throw new LoiMem('Không thấy ô chọn ảnh trong hộp soạn bài');
    const dt = new DataTransfer(); files.forEach((f) => dt.items.add(f));
    inp.files = dt.files;
    inp.dispatchEvent(new Event('input', { bubbles: true })); inp.dispatchEvent(new Event('change', { bubbles: true }));
    let ok = await cho(() => { const h = hopSoanBai(); return h && demAnhLon(h) >= truoc + files.length; }, 45000, 500);
    if (!ok && hopSoanBai()) { // (5.4) lần 1 chưa hiện → gắn lại ảnh lần 2
      ghi('Ảnh: lần 1 chưa hiện đủ → gắn lại ảnh lần 2');
      try { const dt2 = new DataTransfer(); files.forEach((f) => dt2.items.add(f)); inp.files = dt2.files; inp.dispatchEvent(new Event('input', { bubbles: true })); inp.dispatchEvent(new Event('change', { bubbles: true })); } catch (e) { ghi('Lỗi gắn ảnh lần 2: ' + e.message); }
      ok = await cho(() => { const h = hopSoanBai(); return h && demAnhLon(h) >= truoc + files.length; }, 45000, 500);
    }
    if (!ok) { const h = hopSoanBai(); throw new LoiMem(`Facebook chưa hiện đủ ${files.length} ảnh trong bài soạn (đang thấy ${h ? demAnhLon(h) - truoc : 0})`); }
    await sleep(1500);
  }
  // (4.5) đóng hộp đăng bài (soạn / cài đặt / chia sẻ nhóm) chắc chắn: 3 lần, có trả lời hộp "Bỏ bài viết?"; trả về true nếu đã đóng
  const coHopDang = () => hopThoai((d) => d.innerText.includes('Tạo bài viết') || laCaiDat(d) || laNhom(d));
  async function dongHopSoan() {
    for (let lan = 0; lan < 3 && coHopDang(); lan++) {
      const h = coHopDang();
      const x = h.querySelector('[aria-label="Đóng hộp thoại của công cụ tạo"], [aria-label="Đóng"], [aria-label="Quay lại"]');
      if (x) { if (lan) { try { ganBam(x); } catch (e) { x.click(); } } else x.click(); }
      else document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', code: 'Escape', keyCode: 27, which: 27, bubbles: true }));
      await sleep(1200);
      const hoi = hopThoai((d) => /Bỏ bài viết|Rời khỏi|bỏ những thay đổi/i.test(d.innerText));
      if (hoi) { const bo = Array.from(hoi.querySelectorAll('[role="button"]')).find((b) => /^(Bỏ|Bỏ bài viết|Rời khỏi|Rời khỏi trang|Bỏ thay đổi)$/i.test(chuan(b.innerText))); if (bo) bo.click(); await sleep(900); }
    }
    return !coHopDang();
  }

  // Comment chỉ có ảnh (không chữ): gắn ảnh vào ô bình luận của bài rồi Enter
  async function binhLuanAnh(text, file) {
    kiemDung();
    const b = await cho(() => timBai(text), 15000);
    if (!b) throw new LoiChuaGui('không tìm thấy ô bình luận của bài');
    const hopO = () => { const x = timBai(text); const f = x && x.ed.closest('form'); return f ? f.parentElement : null; };
    const coAnh = () => { const o = hopO(); return !!(o && o.querySelector('[aria-label="Gỡ ảnh"]')); };
    const goAnh = async () => { for (let i = 0; i < 3 && coAnh(); i++) { const o = hopO(); const g = o && o.querySelector('[aria-label="Gỡ ảnh"]'); if (g) { try { ganBam(g); } catch (e) { g.click(); } } await sleep(900); } return !coAnh(); };
    if (coAnh()) { ghi('C2. Ô bình luận còn ảnh cũ chưa gửi → gỡ ra trước'); if (!(await goAnh())) throw new LoiChuaGui('ô bình luận đang còn ảnh cũ chưa gửi, gỡ không được'); }
    const ganVao = async () => {
      const x = timBai(text) || b; const f0 = x.ed.closest('form');
      const inp = f0 && Array.from(f0.querySelectorAll('input[type="file"]')).find((i) => /image/.test(i.accept || ''));
      if (!inp) throw new LoiChuaGui('không thấy ô chọn ảnh của ô bình luận');
      x.ed.focus(); await sleep(300);
      const dt = new DataTransfer(); dt.items.add(file); inp.files = dt.files;
      inp.dispatchEvent(new Event('input', { bubbles: true })); inp.dispatchEvent(new Event('change', { bubbles: true }));
      return cho(coAnh, 25000, 400);
    };
    if (!(await ganVao())) { // (4.5) Facebook chưa hiện ảnh xem trước → gắn lại 1 lần
      ghi('C2. Ảnh chưa hiện trong ô bình luận → gắn lại');
      if (!(await ganVao())) throw new LoiChuaGui('Facebook không hiện ảnh xem trước trong ô bình luận');
    }
    ghi('C2. Đã gắn ảnh vào ô bình luận');
    await sleep(2000); // chờ ảnh tải lên
    kiemDung();
    const x = timBai(text); if (!x) throw new LoiChuaGui('bài biến mất khỏi trang trước khi gửi comment ảnh');
    x.ed.focus(); await sleep(200);
    x.ed.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true, cancelable: true }));
    if (!(await cho(() => !coAnh(), 20000, 500))) {
      // (4.5) Enter chưa ăn (ảnh xem trước vẫn còn = chưa gửi) → bấm nút Gửi bằng chuỗi sự kiện chuột
      const o = hopO(); const nutGui = o && Array.from(o.querySelectorAll('[role="button"][aria-label], div[aria-label][tabindex]')).find((n) => /^(Bình luận|Gửi|Đăng)$/.test(chuan(n.getAttribute('aria-label'))) && dangHien(n));
      ghi('C3. Enter chưa gửi được ảnh → ' + (nutGui ? 'bấm nút Gửi' : 'nhấn Enter lại'));
      if (nutGui) { try { ganBam(nutGui); } catch (e) { nutGui.click(); } } else { const x2 = timBai(text); if (x2) { x2.ed.focus(); x2.ed.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true, cancelable: true })); } }
      if (!(await cho(() => !coAnh(), 15000, 500))) { await goAnh(); const e0 = new LoiChuaGui('đã bấm gửi comment ảnh (Enter + nút Gửi) nhưng ảnh xem trước vẫn còn — chưa gửi được'); e0.sauEnter = true; throw e0; }
    }
    ghi('C3. Đã gửi comment ảnh, chờ Facebook xác nhận');
    const han = Date.now() + 6000;
    while (Date.now() < han) {
      const y = timBai(text); const loi = loiTuFacebook(y && y.khung);
      if (loi) throw new LoiTuChoi(loi);
      await sleep(500);
    }
  }

  // ---------------- giờ đăng, lỗi, nhắc ----------------
  function gioB23(ngay, loai) {
    const kg = loai === 2 ? 'gio2' : 'gio3';
    let s = trangThaiNgay(ngay);
    if (s[kg] == null) {
      const truoc = loai === 2 ? s.gio : gioB23(ngay, 2); // (5.3) chuỗi sáng: Bài 2 = Bài 1 + 28–30 phút, Bài 3 = Bài 2 + 28–30 phút
      const g = truoc + 28 + Math.floor(Math.random() * 3);
      s = capNhatNgay(ngay, (x) => { if (x[kg] == null) x[kg] = g; });
    }
    return s[kg];
  }
  const tenB23 = (t, hs) => `Bài ${t.loai}${hs && hs.length > 1 ? ` (hàng ${t.hang})` : ''}`;
  // Lỗi của 1 bài: lần đầu báo ngay, 2 tiếng nhắc lại (tối đa 2 lần), hết lỗi thì báo "đã sửa xong"
  async function baoLoiB23(ngay, k, msg, tin) {
    const now = Date.now();
    const s = capNhatNgay(ngay, (x) => { x.loiB23 = x.loiB23 || {}; const e = x.loiB23[k] || { dau: now, baoLuc: 0 }; e.msg = msg; x.loiB23[k] = e; });
    const e = s.loiB23[k];
    if ((!e.baoLuc || now - e.baoLuc >= CAI_DAT.NHAC_LAI_PHUT * 60000) && trongGioNhan() && now - e.dau >= (CAI_DAT.BAO_LOI_SAU_PHUT || 0) * 60000) {
      const lanDau = !e.baoLuc;
      capNhatNgay(ngay, (x) => { x.loiB23[k].baoLuc = now; });
      await baoLark(lanDau ? tin : 'Nhắc lại: ' + tin, { toiDa: lanDau ? 1 : CAI_DAT.LOI_NHAC_TOI_DA });
    }
  }
  async function xoaLoiB23(ngay, k, noiDung) {
    const s = trangThaiNgay(ngay); const e = (s.loiB23 || {})[k];
    if (!e) return;
    capNhatNgay(ngay, (x) => { delete x.loiB23[k]; });
    if (e.baoLuc && noiDung) await baoLark(noiDung);
  }
  async function nhacTabAnB23(ngay, t) {
    const s = trangThaiNgay(ngay); const bay = Date.now();
    if ((!s.anMayB23 || bay - s.anMayB23 >= CAI_DAT.TAB_AN_NHAC_MAY_PHUT * 60000) && (s.anMaySoB23 || 0) < 6) {
      capNhatNgay(ngay, (x) => { x.anMayB23 = bay; x.anMaySoB23 = (x.anMaySoB23 || 0) + 1; });
      thongBaoMay(`Đến giờ đăng Bài ${t.loai} — cần mở tab Facebook`, 'Tab Facebook đang bị che/thu nhỏ nên chưa đăng được. Mở cửa sổ Facebook lên là script đăng ngay.');
    }
    if (!s.anLarkB23) {
      capNhatNgay(ngay, (x) => { x.anLarkB23 = bay; });
      await baoLark(`Đến giờ đăng Bài ${t.loai} nhưng tab Facebook đang bị che/thu nhỏ — cần mở Facebook lên màn hình, script sẽ đăng ngay`);
    }
  }

  // ---------------- vòng đăng Bài 2 / Bài 3 ----------------
  const laNgayThuB23 = (ngay) => !!CAI_DAT.NGAY_THU_B23 && ngay === CAI_DAT.NGAY_THU_B23;
  async function vongDangB23() {
    if (!laTabChinh()) return;
    if (lay('tam_dung', false) || dangBan || demNguocDen || lay('dang_do', null) || lay('soan_thu', null) || lay('b23_cho_tay', null)) return;
    const ngay = homNay(); const m = phutTrongNgay(new Date());
    const s = trangThaiNgay(ngay);
    if (s.huy) return; // (4.5) không còn "dừng cả Bài 2/3" vì 1 bài chậm; Bài 1 lỗi cũng không chặn Bài 2/3
    if (!dangTuDongBat() && !s.epB23) return; // (5.3) đã tạm dừng đăng bài tự động (bấm "▶ Đăng" vẫn đăng được)
    const hs0 = hangHomNay(); if (!hs0 || !hs0.length) return;
    const b23 = s.b23 || {};
    const conLai = mucTieuB23(hs0).filter((t) => t.text && !b23[t.k]).sort((a, b) => a.loai - b.loai || a.hang - b.hang);
    if (!conLai.length) return;
    const ep = s.epB23 ? conLai.find((x) => x.k === s.epB23) : null;
    if (s.epB23 && (!ep || document.visibilityState === 'visible')) capNhatNgay(ngay, (x) => { x.epB23 = null; }); // tab ẩn thì giữ yêu cầu "Đăng ngay" đến khi tab hiện
    // quá giờ chót buổi sáng: dừng, báo 1 lần
    if (!ep && m >= docGio(CAI_DAT.GIO_CHOT)) {
      if (!s.daChotB23) {
        capNhatNgay(ngay, (x) => { x.daChotB23 = true; });
        const ly = conLai.map((t) => `${tenB23(t, hs0)}: ${((s.loiB23 || {})[t.k] || {}).msg || 'chưa đến lượt/không rõ lý do'}`).join('; ');
        ghi('Quá giờ chót ' + CAI_DAT.GIO_CHOT + ' — Bài 2/3 chưa đăng được: ' + ly);
        await baoLark(`Quá ${CAI_DAT.GIO_CHOT} chưa đăng được: ${ly} — cần kiểm tra và đăng tay`, { batBuoc: true });
      }
      return;
    }
    const t = ep || conLai.find((x) => m >= gioB23(ngay, x.loai) && !(s.thuLaiB23 && s.thuLaiB23[x.k] && Date.now() - s.thuLaiB23[x.k] < CAI_DAT.THU_LAI_PHUT * 60000));
    if (!t) return;
    if (!ep && s.choDenB23 && Date.now() < s.choDenB23) return;
    if (document.visibilityState !== 'visible') { await nhacTabAnB23(ngay, t); return; }
    if ((hopDangDo() || hopSoanBai() || dangODuongSua()) && nguoiDangThaoTac()) return; // (4.5) người đang soạn/sửa bài trong tab này → chờ
    dangBan = true; giuKhoa(); hangSapDang = t.hang;
    try {
      if (hopDangDo() || hopSoanBai()) { ghi('Có hộp đăng bài mở dở → đóng lại trước khi đăng'); if (!(await dongHopSoan())) { ghi('Không đóng được hộp đăng → tải lại trang'); roiTrang(); return; } }
      await dangBaiCoAnh(ngay, t, hs0);
    }
    catch (e) { await xuLyLoiB23(ngay, t, hs0, e); }
    finally { dangBan = false; veBang(); }
  }

  async function dangBaiCoAnh(ngay, t, hs0) {
    const thu = laNgayThuB23(ngay);
    const sMoi = (trangThaiNgay(ngay).loiB23 || {})[t.k];
    let v; try { v = docSheetSangNay() || await docSheet({ moi: true }); } catch (e1) { ghi('Chưa đọc được sheet mới (' + e1.message + ') → dùng bản đã lưu'); v = await docSheet(); } // (4.4) luôn đọc mới: Cao có thể vừa bổ sung ảnh comment (ô O–Q) sau lần đọc trước
    const loiCot = kiemTenCot(v); if (loiCot) throw new LoiMem(loiCot);
    const h = hangCuaNgay(v, ngay).find((x) => x.hang === t.hang);
    if (!h) throw new LoiMem(`Không còn thấy hàng ${t.hang} (ngày ${ngay}) trên sheet`);
    const text = t.loai === 2 ? h.bai2 : h.bai3;
    if (!text) throw new LoiMem(`Ô ${t.cot}${t.hang} đang trống`);
    const toks = t.loai === 2 ? h.anh2 : h.anh3;
    const cotAnh = t.loai === 2 ? 'I–K' : 'L–N';
    if (!toks.length) throw new LoiThieuAnh(`Chưa có ảnh Bài ${t.loai} ở các ô ${cotAnh} của hàng ${t.hang}`);

    // bình luận sẽ đăng sau bài
    const cmts = []; const ghiChuTruoc = [];
    if (t.loai === 2) { if (h.cmt2) cmts.push({ k: 'text', v: h.cmt2 }); else ghiChuTruoc.push('ô E (comment Bài 2) đang trống nên không comment'); }
    else {
      const chung = anhChung(v);
      if (CAI_DAT.CMT_BAI3) cmts.push({ k: 'text', v: CAI_DAT.CMT_BAI3 });
      if (chung.co) cmts.push({ k: 'anh', v: chung.co }); else ghiChuTruoc.push('ô O2 (ảnh cố định) đang trống');
      if (chung.pool.length) cmts.push({ k: 'anh', v: chung.pool[Math.floor(Math.random() * chung.pool.length)] }); else ghiChuTruoc.push('các ô P2, Q2, O3, P3, Q3 (ảnh ngẫu nhiên) đang trống');
      for (const tk of h.anhCmt) cmts.push({ k: 'anh', v: tk });
      if (!h.anhCmt.length) ghiChuTruoc.push(`các ô O–Q của hàng ${t.hang} (ảnh comment) đang trống`);
    }
    // (4.5) tải ảnh trước khi thao tác trên trang: Lark lỗi thì dừng sớm, không mở menu tài khoản / đọc API thừa
    ghi(`Bài ${t.loai}: chuẩn bị ${toks.length} ảnh`);
    const files = [];
    for (let i = 0; i < toks.length; i++) { kiemDung(); files.push(await taiAnhLark(toks[i], 'anh-' + (i + 1))); }

    // giãn cách: bài gần nhất trên trang (mọi loại) phải ≥ CACH_BAI_KHAC_PHUT phút
    if (!(await damBaoTuCach())) return;
    if (!dungTrang()) { veTrang(); return; }
    if (hopDangDo()) throw new LoiMem('Có hộp đăng bài đang mở dở — script đóng lại rồi thử lại');
    const cuoiMay = Math.max(0, ...Object.values(trangThaiNgay(ngay).bai || {}).map((b) => b.luc || 0), ...Object.values(trangThaiNgay(ngay).b23 || {}).map((b) => b.luc || 0));
    if (cuoiMay && Date.now() - cuoiMay < CAI_DAT.CACH_BAI_KHAC_PHUT * 60000) {
      const den = cuoiMay + CAI_DAT.CACH_BAI_KHAC_PHUT * 60000 + 30000; capNhatNgay(ngay, (x) => { x.choDenB23 = den; });
      ghi(`Bài ${t.loai}: chờ giãn cách đến ${gioStr(new Date(den))}`); return;
    }
    const tuoi = await tuoiBaiMoiNhat();
    if (tuoi !== null && tuoi < CAI_DAT.CACH_BAI_KHAC_PHUT) {
      const den = Date.now() + (CAI_DAT.CACH_BAI_KHAC_PHUT - tuoi + 1) * 60000; capNhatNgay(ngay, (x) => { x.choDenB23 = den; });
      ghi(`Bài ${t.loai}: bài gần nhất trên trang mới ${tuoi} phút → chờ đến ${gioStr(new Date(den))}`); return;
    }
    // dò trùng (nhân sự đã đăng tay)
    const coSan = await baiDaCoTrenTrang(text);
    if (coSan) {
      capNhatNgay(ngay, (x) => { x.b23 = x.b23 || {}; x.b23[t.k] = { tt: 'xong', luc: coSan.luc || Date.now(), link: coSan.link || '', id: coSan.id || '', hang: t.hang, coSan: true }; });
      ghi(`Bài ${t.loai} (hàng ${t.hang}) đã có sẵn trên trang → script không đăng lại, không comment`);
      await baoLark(`Bài ${t.loai} đã có sẵn trên trang (có thể đăng tay), script không đăng lại — cần xem đã có comment chưa${coSan.link ? ` — ${coSan.link}` : ''}`);
      return;
    }

    kiemDung();
    if (document.visibilityState !== 'visible') throw new LoiMem('Tab Facebook đang bị ẩn hoặc thu nhỏ nên Facebook không chạy — cần để tab này hiện trên màn hình');
    const bai = { ngay, hang: t.hang, khoa: ngay + '|' + t.k, bai: text, cmt: '', files,
      ddThem: { loai: t.loai, k: t.k, cmts, cmtIdx: 0, soAnh: files.length, ghiChuTruoc } };
    luu('dang_ngay', null);
    luu('tien_trinh', { hang: t.hang, ngay, batDau: Date.now(), buoc: {}, soanThu: thu });
    ghi(`Bắt đầu đăng Bài ${t.loai} (hàng ${t.hang}, ${files.length} ảnh${thu ? ', CHẠY THỬ: dừng trước nút Đăng' : ''})`);
    const soNhom = await dangLenFacebook(bai, { soanThu: thu });
    if (thu) {
      luu('b23_cho_tay', { ngay, k: t.k, loai: t.loai, hang: t.hang, text, cmts, soAnh: files.length, ghiChuTruoc, luc: Date.now() });
      await xoaLoiB23(ngay, t.k, null);
      thongBaoMay(`Đã soạn sẵn Bài ${t.loai}`, 'Kiểm tra bài rồi bấm Đăng. Sau khi đăng, script tự comment.');
      await baoLark(`Chạy thử: Bài ${t.loai} đã soạn sẵn, dừng trước nút Đăng — kiểm tra rồi bấm Đăng (xong script tự comment)`, { batBuoc: true });
      return;
    }
    const thay = await cho(() => timBai(text), 60000, 1000);
    if (!thay) { ghi('Chưa thấy bài trên trang → tải lại để kiểm tra'); roiTrang(CAI_DAT.URL_TRANG); return; }
    ghi('B10. Đã thấy bài trên trang');
    await sauKhiDangB23(ngay, lay('dang_do', null) || Object.assign({ ngay, hang: t.hang, khoa: bai.khoa, bai: text, soNhom }, bai.ddThem));
  }

  async function xuLyLoiB23(ngay, t, hs0, e) {
    const ten = tenB23(t, hs0);
    if (e instanceof LoiLark) { // Lark đang chặn: chờ tới khi Lark mở lại (không lặp lại thao tác mỗi 15 giây), quá thời gian chờ mới báo
      if (Date.now() - lanGhiLark > 10 * 60000) { lanGhiLark = Date.now(); ghi(`Chưa đăng được ${ten}: ${e.message} — chờ Lark hoạt động lại`); }
      const g = chanLark();
      capNhatNgay(ngay, (x) => { x.thuLaiB23 = x.thuLaiB23 || {}; x.thuLaiB23[t.k] = g ? Math.min(Date.now(), g.den - CAI_DAT.THU_LAI_PHUT * 60000) : Date.now(); });
      await baoLoiB23(ngay, t.k, e.message, `Chưa đăng được ${ten}: ${e.message} — script tự thử lại khi Lark hoạt động lại`);
      return;
    }
    ghi(`Lỗi ${ten}: ${e.message}`); chupLoi(ten);
    const dd0 = lay('dang_do', null);
    if (e instanceof LoiTrung) { // (4.5) bài đã có ngay trước khi Đăng → ghi nhận có sẵn
      await dongHopSoan();
      capNhatNgay(ngay, (x) => { x.b23 = x.b23 || {}; x.b23[t.k] = { tt: 'xong', luc: (e.p && e.p.luc) || Date.now(), link: (e.p && e.p.link) || '', id: (e.p && e.p.id) || '', hang: t.hang, coSan: true }; });
      ghi(`${ten} đã có sẵn trên trang (phát hiện ngay trước khi Đăng) → không đăng lại`);
      return;
    }
    if (e instanceof LoiDung) {
      if (dd0) { ghi('Đã bấm Đăng: giữ việc dở để xác minh; ' + e.message); return; }
      await dongHopSoan(); // (4.5) hoãn: đóng hộp soạn, thử lại sau ~1 phút
      capNhatNgay(ngay, (x) => { x.thuLaiB23 = x.thuLaiB23 || {}; x.thuLaiB23[t.k] = Date.now() - (CAI_DAT.THU_LAI_PHUT - 1) * 60000; });
      return;
    }
    if (e instanceof LoiCung) {
      if (dd0) { // (4.5) đã bấm Đăng mà chưa rõ → giữ việc dở, tải lại để kiểm tra (trang + API); KHÔNG dừng cả Bài 2/3
        dd0.buoc = 'kiem_bai'; dd0.luc = Date.now(); dd0.khongRo = true; luu('dang_do', dd0);
        setTimeout(() => { roiTrang(CAI_DAT.URL_TRANG); }, 1500); return;
      }
    }
    if (dd0) { ghi('Đã bắt đầu thao tác Đăng, giữ việc dở để xác minh: ' + e.message); return; }
    let dong = true; try { dong = await dongHopSoan(); } catch (e2) { /* */ }
    const x0 = capNhatNgay(ngay, (x) => { x.thuLaiB23 = x.thuLaiB23 || {}; x.thuLaiB23[t.k] = Date.now(); x.loiLanB23 = x.loiLanB23 || {}; x.loiLanB23[t.k] = (x.loiLanB23[t.k] || 0) + 1; });
    if ((!dong || x0.loiLanB23[t.k] % 2 === 0) && !lay('dang_do', null)) { ghi('Lỗi lặp lại / hộp đăng chưa đóng → tải lại trang trước lần thử sau'); setTimeout(() => { if (!dangBan && !lay('dang_do', null)) roiTrang(); }, 3000); }
    const thieuAnh = e instanceof LoiThieuAnh;
    await baoLoiB23(ngay, t.k, e.message, thieuAnh
      ? `${ten} chưa đăng được: thiếu ảnh trong sheet — cần bổ sung gấp`
      : `Chưa đăng được ${ten}: ${e.message} — script tự thử lại mỗi ${CAI_DAT.THU_LAI_PHUT} phút`);
  }

  async function sauKhiDangB23(ngay, dd) {
    const lucDang = gioStr(new Date());
    const anhToks = (dd.cmts || []).filter((x) => x.k === 'anh').map((x) => x.v); const tCmt = (dd.cmts || []).find((x) => x.k === 'text');
    capNhatNgay(ngay, (x) => { x.b23 = x.b23 || {}; x.b23[dd.k] = { tt: 'xong', luc: dd.lucApi || Date.now(), hang: dd.hang, script: true, soNhom: dd.soNhom, soAnh: dd.soAnh, link: dd.link || '', id: dd.id || '', textBai: dd.bai, cmtText: tCmt ? tCmt.v : '', anhToks }; });
    luu('bai_cuoi_cua_script', Date.now());
    ghi(`Đã đăng Bài ${dd.loai} lúc ${lucDang} (hàng ${dd.hang}, ${dd.soAnh || 0} ảnh)`);
    await xoaLoiB23(ngay, dd.k, `✅ Bài ${dd.loai} đã đăng lúc ${lucDang} (đã xử lý xong lỗi trước đó)`);
    Object.assign(dd, { buoc: 'cho_binh_luan', luc: Date.now(), lucDang, cmtIdx: dd.cmtIdx || 0 });
    const canSuaNen = dd.loai === 2 && CAI_DAT.SUA_NEN_B2 !== false;
    if ((!dd.cmts || !dd.cmts.length) && !canSuaNen) { await hoanTatB23(dd, dd.ghiChuTruoc || []); return; }
    dd.cmts = dd.cmts || [];
    luu('dang_do', dd);
    ghi(dd.cmts.length ? 'Chờ vài giây rồi tải lại trang để comment' : 'Chờ vài giây rồi tải lại trang để sửa nền đỏ');
    await sleep(2500); await baoLinkBaiScript().catch(() => {}); await sleep(1500);
    roiTrang();
  }

  // Ngày chạy thử: Cao tự bấm Đăng → khi hộp đăng đóng và thấy bài trên trang thì script comment tiếp
  async function tiepSauThuB23() {
    const p = lay('b23_cho_tay', null); if (!p) return false;
    if (!laTabChinh() || lay('tam_dung', false) || lay('dang_do', null) || dangBan) return true;
    if (p.ngay !== homNay()) { luu('b23_cho_tay', null); ghi('Bài chạy thử của ngày cũ — bỏ qua'); return true; }
    const hopMo = hopThoai((d) => laCaiDat(d) || laNhom(d) || d.innerText.includes('Tạo bài viết'));
    if (hopMo) {
      if (Date.now() - p.luc > 45 * 60000) { luu('b23_cho_tay', null); ghi(`Bài ${p.loai} chạy thử: quá 45 phút Cao chưa bấm Đăng — bỏ soạn thử`); await baoLark(`Chạy thử: Bài ${p.loai} soạn quá 45 phút chưa bấm Đăng — script bỏ lượt này, cần đăng tay`, { batBuoc: true }); }
      return true;
    }
    if (!p.dongLuc) { p.dongLuc = Date.now(); luu('b23_cho_tay', p); }
    const thay = await cho(() => timBai(p.text), 20000, 1000);
    if (!thay) {
      if (Date.now() - p.dongLuc > 3 * 60000) { luu('b23_cho_tay', null); ghi(`Bài ${p.loai} chạy thử: hộp đã đóng nhưng không thấy bài trên trang — coi như Cao đã hủy`); }
      return true;
    }
    luu('b23_cho_tay', null);
    capNhatNgay(p.ngay, (x) => { x.b23 = x.b23 || {}; x.b23[p.k] = { tt: 'xong', luc: Date.now(), hang: p.hang, script: true, thu: true, soAnh: p.soAnh, link: '', id: '' }; });
    ghi(`Chạy thử: đã thấy Bài ${p.loai} được đăng → script tiếp tục comment`);
    const dd = { loai: p.loai, k: p.k, ngay: p.ngay, hang: p.hang, khoa: p.ngay + '|' + p.k, bai: p.text, cmts: p.cmts, cmtIdx: 0, soAnh: p.soAnh, ghiChuTruoc: p.ghiChuTruoc || [], thu: true, luc: Date.now(), buoc: 'cho_binh_luan', lucDang: gioStr(new Date()) };
    if (!dd.cmts || !dd.cmts.length) { await hoanTatB23(dd, dd.ghiChuTruoc); return true; }
    luu('dang_do', dd);
    ghi('Chờ vài giây rồi tải lại trang để comment');
    await sleep(2500); await baoLinkBaiScript().catch(() => {}); await sleep(1500);
    roiTrang();
    return true;
  }

  async function xuLyDangDoB23(dd) {
    const ngay = dd.ngay;
    if (lay('tam_dung', false) || !laTabChinh()) return true;
    if (document.visibilityState !== 'visible') { choTabAn(dd.ten || ('Bài ' + dd.loai)); return true; } // (4.5) tab ẩn: chờ tab hiện, không tính là thất bại
    hetChoTabAn();
    if (!dungTrang() && !(dd.viaLink && /(^|\.)facebook\.com$/.test(location.hostname))) { veTrang(); return true; }
    if (dd.buoc === 'kiem_bai') { // vừa bấm Đăng thì trang tải lại
      dd.kiemLan = (dd.kiemLan || 0) + 1; luu('dang_do', dd);
      const thay = await cho(() => timBai(dd.bai), 30000, 1000);
      if (thay) { await sauKhiDangB23(ngay, dd); return true; }
      if (coApi()) { // (4.5) hỏi Facebook API: bài có thể đã lên mà trang chưa hiện
        try {
          const p = baiGiongNhat(await baiTrenTrangApi(dd.luc - 10 * 60000), dd.bai);
          if (p) { ghi(`Facebook (API) xác nhận Bài ${dd.loai} đã lên (trang chưa hiện) → tiếp tục comment`); Object.assign(dd, { id: p.id, link: p.link, lucApi: p.luc }); await sauKhiDangB23(ngay, dd); return true; }
          dd.apiKhong = (dd.apiKhong || 0) + 1; luu('dang_do', dd); // (4.5) API TRẢ LỜI được: chưa có bài
        } catch (e) { ghi('Kiểm bài qua API lỗi: ' + e.message); }
      }
      if (dd.kiemLan === 2 || dd.kiemLan === 4 || dd.kiemLan === 8) { ghi(`Chưa thấy Bài ${dd.loai} vừa đăng → tải lại trang kiểm tra lần nữa`); roiTrang(); return true; }
      if (dd.kiemLan >= 6 && coApi() && (dd.apiKhong || 0) < 4 && dd.kiemLan < 12) { // (4.5) API lỗi nhiều → kiểm tiếp, KHÔNG đăng lại
        if (dd.kiemLan === 6) ghi(`Chưa hỏi được Facebook (API) đủ số lần để chắc Bài ${dd.loai} chưa lên → kiểm tiếp, chưa đăng lại`);
        return true;
      }
      if (dd.kiemLan >= 6) {
        luu('dang_do', null);
        if (coApi() && (dd.apiKhong || 0) >= 4) { // nhiều lần (trang + API) không thấy → bài chưa lên → cho đăng lại (dò trùng trước khi bấm Đăng chặn đăng trùng)
          capNhatNgay(ngay, (x) => { x.thuLaiB23 = x.thuLaiB23 || {}; x.thuLaiB23[dd.k] = Date.now(); });
          ghi(`Đã bấm Đăng Bài ${dd.loai} nhưng nhiều lần kiểm vẫn không có bài → coi như chưa đăng, sẽ tự đăng lại (có dò trùng trước khi bấm Đăng)`);
        } else {
          capNhatNgay(ngay, (x) => { x.b23 = x.b23 || {}; x.b23[dd.k] = { tt: 'khong_ro', luc: Date.now(), hang: dd.hang }; });
          await baoLark(`Bài ${dd.loai}: đã bấm Đăng nhưng không thấy bài trên trang${coApi() ? '' : ' (chưa cài mã khoá)'} — script không đăng lại để tránh trùng, cần vào trang kiểm tra tay`, { batBuoc: true });
        }
      }
      return true;
    }
    if (dd.buoc === 'cho_binh_luan' || dd.buoc === 'dang_binh_luan') {
      dangBan = true; giuKhoa();
      try { return await chayComment(dd); } finally { dangBan = false; giuKhoa(); }
    }
    return false;
  }

  // Comment đã lên chưa (hỏi Facebook API) — true / false / null (không kiểm được)
  async function cmtDaCoApi(dd, it) {
    if (!coApi()) return null;
    try {
      let id = dd.id;
      if (!id) { const p = baiGiongNhat(await baiTrenTrangApi(Date.now() - 864e5), dd.bai); if (!p) return null; id = p.id; dd.id = id; }
      const cs = await cmtChiTietApi(id);
      if (it.k === 'text') return cs.msgs.some((c) => khopCmt(c, it.v));
      const soAnhDaGui = dd.cmts.slice(0, dd.cmtIdx + 1).filter((x) => x.k === 'anh').length - (dd.anhLoi || 0) + (dd.anhCoSan || 0);
      return cs.anh >= soAnhDaGui;
    } catch (e) { return null; }
  }

  // Bài 2: sửa bài đã đăng → gỡ ảnh → nền đỏ → Lưu
  async function suaNenDo(b) {
    const thuLai = (fn, ms) => cho(fn, ms);
    const art = b.khung.closest('[role="article"]') || b.khung;
    const nutBa = () => art.querySelector('[aria-label^="Hành động đối với bài viết này"]') || b.khung.querySelector('[aria-label^="Hành động đối với bài viết này"]');
    const n1 = await thuLai(nutBa, 10000); if (!n1) throw new Error('không thấy nút ⋯ của bài');
    ganBam(n1);
    const timMenu = () => Array.from(document.querySelectorAll('[role="menuitem"]')).find((x) => dangHien(x) && /Chỉnh sửa bài viết/.test(x.innerText));
    let mn = await thuLai(timMenu, 6000);
    if (!mn) { n1.click(); mn = await thuLai(timMenu, 6000); }
    if (!mn) throw new Error('không thấy mục "Chỉnh sửa bài viết"');
    ganBam(mn);
    const hop = await thuLai(() => hopThoai((d) => /Chỉnh sửa bài viết/.test(d.innerText) && (d.querySelector('[aria-label="Gỡ ảnh"]') || d.querySelector('[aria-label="Hiển thị các tùy chọn phông nền"]'))), 15000);
    if (!hop) throw new Error('không mở được hộp chỉnh sửa bài viết');
    ghi('Sửa nền: đã mở hộp chỉnh sửa');
    await sleep(1200);
    for (let i = 0; i < 20; i++) { const x = hop.querySelector('[aria-label="Gỡ ảnh"]'); if (!x) break; ganBam(x); await sleep(900); }
    if (hop.querySelector('[aria-label="Gỡ ảnh"]')) throw new Error('chưa gỡ hết ảnh');
    ghi('Sửa nền: đã gỡ ảnh');
    const aa = await thuLai(() => hop.querySelector('[aria-label="Hiển thị các tùy chọn phông nền"]'), 10000);
    if (!aa) throw new Error('không thấy nút Aa (bài có thể dài quá ' + CAI_DAT.GIOI_HAN_KY_TU_NEN + ' ký tự)');
    ganBam(aa); await sleep(800);
    let sw = await thuLai(() => hop.querySelector(`[aria-label^="${CAI_DAT.NEN}"]`), 6000);
    if (!sw) { ganBam(aa); sw = await thuLai(() => hop.querySelector(`[aria-label^="${CAI_DAT.NEN}"]`), 6000); }
    if (!sw) throw new Error('không thấy nền "' + CAI_DAT.NEN + '"');
    ganBam(sw); await sleep(900);
    ghi('Sửa nền: đã chọn nền ' + CAI_DAT.NEN);
    const luuNut = () => Array.from(hop.querySelectorAll('[role="button"],[aria-label="Lưu"]')).find((x) => dangHien(x) && (chuan(x.innerText) === 'Lưu' || x.getAttribute('aria-label') === 'Lưu') && x.getAttribute('aria-disabled') !== 'true');
    const nl = await thuLai(luuNut, 8000); if (!nl) throw new Error('không thấy nút Lưu');
    ganBam(nl);
    if (!(await cho(() => !hop.isConnected || !dangHien(hop), 15000))) { // (4.5) Lưu chưa ăn → bấm lại bằng cách khác
      const nl2 = luuNut(); if (nl2) { ghi('Sửa nền: bấm Lưu lần 1 chưa ăn → bấm lại'); nl2.click(); }
      if (!(await cho(() => !hop.isConnected || !dangHien(hop), 20000))) throw new Error('bấm Lưu nhưng hộp chưa đóng');
    }
    await sleep(4000);
    // kiểm lại trên bài: không còn ảnh lớn (ngoài phần comment)
    const conAnhF = () => { const b2 = timBai(b.bai || '') || b; return !!(b2 && b2.khung && Array.from(b2.khung.querySelectorAll('img')).some((im) => { const a = im.closest('[role="article"]'); return (!a || a === b2.khung || !b2.khung.contains(a)) && im.getBoundingClientRect().width > 150; })); };
    if (conAnhF()) { ghi('Sửa nền: đã Lưu nhưng trang chưa vẽ lại → chờ thêm (tối đa 25 giây)'); if (!(await cho(() => !conAnhF(), 25000, 1500))) throw new Error('đã Lưu nhưng trên bài vẫn còn ảnh'); }
    ghi('Sửa nền: đã Lưu bài (nền đỏ, không còn ảnh)');
  }
  function dongHopSua() {
    try {
      const h = hopThoai((d) => /Chỉnh sửa bài viết/.test(d.innerText)); if (!h) return;
      const x = h.querySelector('[aria-label="Đóng"]'); if (x) ganBam(x);
      setTimeout(() => { const h2 = hopThoai((d) => /Bỏ|Hủy bỏ|Huỷ bỏ/.test(d.innerText) && /thay đổi|chỉnh sửa/i.test(d.innerText)); const bo = h2 && Array.from(h2.querySelectorAll('[role="button"]')).find((y) => /^(Bỏ|Hủy bỏ|Huỷ bỏ)$/.test(chuan(y.innerText))); if (bo) ganBam(bo); }, 1500);
    } catch (e) { /* */ }
  }

  // Comment thiếu (API không thấy) → lập danh sách bổ sung, tải lại trang và gửi nốt (chỉ 1 lần)
  async function lenLaiCmtThieu(dd) {
    if ((dd.suaLan || 0) >= 1 || !coApi() || !(dd.cmts || []).length) return false;
    const goc = dd.cmtsGoc || dd.cmts;
    try {
      let id = dd.id;
      if (!id) { const p = baiGiongNhat(await baiTrenTrangApi(Date.now() - 864e5), dd.bai); if (!p) return false; id = p.id; }
      const textCan = goc.find((x) => x.k === 'text');
      const anhs = goc.filter((x) => x.k === 'anh');
      let cs = null, thieuText = false, thieuAnh = 0;
      for (let lan = 0; lan < 3; lan++) { // (4.5) comment ảnh hay lên chậm → hỏi tối đa 3 lần cách 10 giây
        await sleep(lan ? 10000 : 6000);
        cs = await cmtChiTietApi(id);
        thieuText = !!(textCan && !cs.msgs.some((c) => khopCmt(c, textCan.v)));
        thieuAnh = Math.max(0, anhs.length - cs.anh);
        if (!thieuText && !thieuAnh) return false;
      }
      const ds = []; if (thieuText) ds.push(textCan);
      if (thieuAnh) { // ưu tiên đúng những ảnh chưa gửi được; không biết thì lấy các ảnh cuối
        const ok = new Set(dd.anhOk || []);
        let chon = anhs.filter((x) => !ok.has(x.v));
        if (chon.length < thieuAnh) chon = chon.concat(anhs.filter((x) => !chon.includes(x)).slice(-(thieuAnh - chon.length)));
        ds.push(...chon.slice(0, thieuAnh));
      }
      dd.cmtsGoc = goc; dd.cmts = ds; dd.cmtIdx = 0; dd.anhLoi = 0; dd.dungAnh = false; dd.dangGui = null;
      /* giữ ghi chú không liên quan comment (vd nền đỏ) */ dd.ghiChuLan1 = (dd.ghiChu || []).filter((x) => !/comment/.test(x)); dd.ghiChu = []; dd.anhCoSan = cs.anh; dd.suaLan = 1; dd.reloadLan = 0; dd.reloadCmt = -1;
      dd.buoc = 'cho_binh_luan'; dd.luc = Date.now(); luu('dang_do', dd);
      ghi(`Kiểm tra: thiếu ${thieuText ? '1 comment chữ' : ''}${thieuText && thieuAnh ? ' + ' : ''}${thieuAnh ? thieuAnh + ' comment ảnh' : ''} → tải lại trang và gửi bù`);
      await sleep(2500); roiTrang();
      return true;
    } catch (e) { ghi('Không kiểm tra bù comment được: ' + e.message); return false; }
  }

  async function chayComment(dd) {
    if ((hopDangDo() || hopSoanBai() || dangODuongSua()) && nguoiDangThaoTac()) return true; // (5.4) người đang soạn bài → không tải lại trang, đợi họ xong
    const ngay = dd.ngay;
    window.scrollTo(0, 0); await sleep(1500);
    const b = await cho(() => timBai(dd.bai), 25000, 1000);
    if (!b) {
      // (4.5) đếm số lần (không tính giờ): tải lại → mở thẳng link bài → tải lại trang bài → mới chốt
      dd.timLan = (dd.timLan || 0) + 1; luu('dang_do', dd);
      if (dd.timLan === 1 && !dd.viaLink) { ghi('Chưa thấy ô bình luận của bài → tải lại trang'); roiTrang(); return true; }
      if (!dd.viaLink) {
        let lk = dd.link; try { if (!lk && coApi()) { const p = baiGiongNhat(await baiTrenTrangApi(Date.now() - 864e5), dd.bai); lk = p && p.link; if (p) dd.id = dd.id || p.id; } } catch (e3) { /* */ }
        if (lk && /^https?:/.test(lk)) { dd.viaLink = lk; dd.link = lk; dd.luc = Date.now(); luu('dang_do', dd); ghi('Không thấy bài trên trang → mở thẳng link bài: ' + lk); await sleep(1000); roiTrang(lk); return true; }
      }
      if (dd.timLan >= 4) await hoanTatB23(dd, ['đã tải lại trang và mở thẳng link bài nhưng không tìm được ô bình luận nên chưa comment xong — lượt rà soát sẽ thử lại']);
      else { ghi('Chưa thấy ô bình luận → tải lại'); roiTrang(); }
      return true;
    }
    dd.link = dd.link || linkBai(b.khung);
    if (dd.ngoai) { dd.daThaBai = true; dd.camXucCmt = dd.camXucCmt || { tt: 'bo' }; }
    if (!dd.daThaBai) { dd.camXucBai = await thaCamXucBai(dd.bai); dd.daThaBai = true; luu('dang_do', dd); }
    const ghiChu = dd.ghiChu || (dd.ghiChu = []);
    // dự phòng: thả Thích cho comment lần trước thất bại → sau khi tải lại trang thử lại 1 lần
    if (dd.camXucCmt && dd.camXucCmt.tt === 'chua' && !dd.thuLaiCx) {
      dd.thuLaiCx = true; const tcx = (dd.cmtsGoc || dd.cmts || []).find((x) => x.k === 'text');
      if (tcx) { try { dd.camXucCmt = await thaCamXucCmt(dd.bai, tcx.v); ghi('Thử lại thả cảm xúc cho comment: ' + (dd.camXucCmt.tt === 'ok' ? 'được' : 'vẫn chưa được')); } catch (e) { /* */ } }
      luu('dang_do', dd);
    }
    if (dd.loai === 2 && !dd.ngoai && !dd.raSoat && !dd.daSuaNen && !dd.suaNenXong && (dd.suaNenLan || 0) < 3 && CAI_DAT.SUA_NEN_B2 !== false) {
      // (4.5) đếm số lần thử (qua cả các lần tải lại); thử tối đa 3 lần (lần 3 sau khi tải lại trang)
      dd.suaNenLan = (dd.suaNenLan || 0) + 1; luu('dang_do', dd);
      try {
        b.bai = dd.bai;
        try { await suaNenDo(b); }
        catch (e1) { ghi('Sửa nền đỏ lần ' + dd.suaNenLan + ' lỗi: ' + e1.message + ' → thử lại'); dongHopSua(); await sleep(4000); const b2 = await cho(() => timBai(dd.bai), 15000, 1000); if (b2) b2.bai = dd.bai; await suaNenDo(b2 || b); }
        dd.suaNenXong = true; luu('dang_do', dd);
      }
      catch (e) {
        ghi('Sửa nền đỏ Bài 2 lỗi: ' + e.message); dongHopSua(); await sleep(3000);
        if (dd.suaNenLan < 3) { luu('dang_do', dd); ghi('Sửa nền đỏ chưa được → tải lại trang thử lại'); roiTrang(); return true; }
        ghiChu.push('chưa sửa được nền đỏ cho Bài 2 (đã thử 3 lần): ' + e.message + ' — cần sửa tay');
      }
      luu('dang_do', dd);
      if (!(await cho(() => timBai(dd.bai), 20000, 1000))) { ghi('Sau khi sửa nền chưa thấy ô bình luận → tải lại trang'); roiTrang(); return true; }
    }
    // trang vừa tải lại giữa lúc đang gửi 1 comment → hỏi API xem comment đó lên chưa, KHÔNG tự gửi lại
    if (dd.dangGui != null && dd.dangGui === dd.cmtIdx) {
      const it = dd.cmts[dd.cmtIdx];
      let co = await cmtDaCoApi(dd, it);
      if (co === false) { await sleep(10000); co = await cmtDaCoApi(dd, it); } // hỏi lại cho chắc (Facebook có thể chậm)
      if (co === false) { ghi(`Comment thứ ${dd.cmtIdx + 1} chưa lên (API xác nhận) → gửi lại`); dd.dangGui = null; luu('dang_do', dd); }
      else {
        if (co !== true) ghiChu.push(`comment thứ ${dd.cmtIdx + 1} (${it.k === 'text' ? 'chữ' : 'ảnh'}) không rõ đã lên chưa — không gửi lại, lượt rà soát sẽ kiểm tra`);
        else if (it.k === 'anh') dd.anhOk = (dd.anhOk || []).concat(it.v);
        dd.cmtIdx++; dd.dangGui = null; luu('dang_do', dd);
      }
    }
    while (dd.cmtIdx < dd.cmts.length) {
      kiemDung();
      const it = dd.cmts[dd.cmtIdx];
      dd.dangGui = dd.cmtIdx; dd.buoc = 'dang_binh_luan'; luu('dang_do', dd);
      try {
        if (it.k === 'text') await binhLuan(dd.bai, it.v);
        else {
          const f = await taiAnhLark(it.v, 'cmt-' + (dd.cmtIdx + 1));
          kiemDung();
          await binhLuanAnh(dd.bai, f);
        }
        if (it.k === 'text' && !dd.camXucCmt) dd.camXucCmt = await thaCamXucCmt(dd.bai, it.v);
        ghi(`C4. Đã gửi comment ${dd.cmtIdx + 1}/${dd.cmts.length} (${it.k === 'text' ? 'chữ' : 'ảnh'})`);
        if (it.k === 'anh') dd.anhOk = (dd.anhOk || []).concat(it.v);
        dd.dangGui = null; dd.cmtIdx++; dd.buoc = 'cho_binh_luan'; luu('dang_do', dd);
        await sleep(1800 + Math.floor(Math.random() * 1400));
        if (CAI_DAT.TAI_LAI_SAU_CMT !== false && dd.cmtIdx < dd.cmts.length) { ghi('Tải lại trang (F5) trước comment kế để ô bình luận không bị treo'); await sleep(1500); roiTrang(); return true; }
      } catch (e) {
        if (e instanceof LoiDung || (e && e.doiTuCach)) { dd.dangGui = null; dd.buoc = 'cho_binh_luan'; luu('dang_do', dd); ghi('Comment còn chờ: ' + e.message); return true; }
        if ((e instanceof LoiChuaGui || /không tìm thấy ô bình luận/.test(e.message)) && (dd.taiLaiTong || 0) < 8) { // chưa gửi gì (tối đa 8 lần tải lại cho cả lượt comment) (ô treo / ảnh không gắn được / Enter không ăn) → F5 rồi thử lại đúng comment này
          if (dd.reloadCmt !== dd.cmtIdx) { dd.reloadCmt = dd.cmtIdx; dd.reloadLan = 0; }
          if ((dd.reloadLan || 0) >= 2 && !dd.viaLink) { // phương án 2: mở thẳng trang riêng của bài rồi comment ở đó
            let lk = dd.link; try { if (!lk && coApi()) { const p = baiGiongNhat(await baiTrenTrangApi(Date.now() - 864e5), dd.bai); lk = p && p.link; } } catch (e3) { /* */ }
            if (lk && /^https?:/.test(lk)) { dd.viaLink = lk; dd.reloadLan = 0; dd.taiLaiTong = (dd.taiLaiTong || 0) + 1; dd.dangGui = e.sauEnter ? dd.cmtIdx : null; dd.buoc = 'cho_binh_luan'; luu('dang_do', dd); ghi('Tải lại vẫn chưa được → mở thẳng link bài để comment: ' + lk); await sleep(1500); roiTrang(lk); return true; }
          }
          if ((dd.reloadLan || 0) < 3) { dd.reloadLan = (dd.reloadLan || 0) + 1; dd.taiLaiTong = (dd.taiLaiTong || 0) + 1; dd.dangGui = e.sauEnter ? dd.cmtIdx : null; dd.buoc = 'cho_binh_luan'; luu('dang_do', dd); ghi(`Ô bình luận bị treo → tải lại trang rồi thử lại comment ${dd.cmtIdx + 1} (lần ${dd.reloadLan}/3)`); await sleep(2000); roiTrang(); return true; }
        }
        if (e instanceof LoiLark || (it.k === 'anh' && !(e instanceof LoiTuChoi) && /tải ảnh|Ô này không phải ảnh|Mất kết nối khi tải|Ô ảnh này Lark báo lỗi|Mã truy cập Lark/.test(e.message))) {
          // chưa gửi gì cả → được phép bỏ qua mục này và đi tiếp
          dd.anhLoi = (dd.anhLoi || 0) + 1;
          ghiChu.push(`comment ảnh thứ ${dd.cmtIdx + 1} bỏ qua vì không tải được ảnh: ${e.message}`);
          dd.dangGui = null; dd.cmtIdx++; dd.buoc = 'cho_binh_luan'; luu('dang_do', dd); continue;
        }
        ghi('Lỗi comment: ' + e.message);
        if (it.k === 'anh') { // (4.5) không còn "bỏ hết các ảnh sau" — chỉ ảnh này tính là lỗi, ảnh sau vẫn gửi; gửi bù/rà soát sẽ lo ảnh này
          dd.anhLoi = (dd.anhLoi || 0) + 1;
          try { const x = timBai(dd.bai); const rm = x && x.ed.closest('form') && x.ed.closest('form').parentElement.querySelector('[aria-label="Gỡ ảnh"]'); if (rm) rm.click(); } catch (e2) { /* */ }
        }
        ghiChu.push(`comment thứ ${dd.cmtIdx + 1} (${it.k === 'text' ? 'chữ' : 'ảnh'}) lỗi: ${e.message} — không tự gửi lại`);
        dd.dangGui = null; dd.cmtIdx++; dd.buoc = 'cho_binh_luan'; luu('dang_do', dd);
        if (e instanceof LoiTuChoi) { ghiChu.push('Facebook từ chối comment → dừng các comment còn lại'); break; }
        await sleep(2500);
      }
    }
    await hoanTatB23(dd, ghiChu);
    return true;
  }

  async function hoanTatB23(dd, ghiChu = []) {
    const ngay = dd.ngay;
    if (dd.raSoat) { await hoanTatRaSoat(dd, [...new Set((dd.ghiChuTruoc || []).concat(ghiChu))]); return; }
    if (!dd.thu && await lenLaiCmtThieu(dd)) return;
    ghiChu = [...new Set((dd.ghiChuTruoc || []).concat(dd.ghiChuLan1 || [], ghiChu))];
    if (dd.ngoai) { // video / manifest do nhân sự đăng: script chỉ comment rồi ghi kết quả vào ô lịch
      const tc = (dd.cmtsGoc || dd.cmts || []).find((x) => x.k === 'text'); const soA = (dd.cmts || []).filter((x) => x.k === 'anh').length - (dd.anhLoi || 0) + (dd.anhCoSan || 0);
      let okC = false, anhA = null, thayT = null;
      if (coApi() && dd.id) {
        for (let lan = 0; lan < 3; lan++) {
          if (lan) await sleep(10000);
          try { const cs = await cmtChiTietApi(dd.id); anhA = cs.anh; thayT = tc ? cs.msgs.some((c) => khopCmt(c, tc.v)) : null; if ((!tc || thayT) && cs.anh >= soA) { okC = true; break; } } catch (e) { ghi('Không xác nhận được comment ' + dd.ten + ' qua API: ' + e.message); break; }
        }
        if (!okC) ghiChu.push(`API ${thayT ? 'thấy comment chữ' : 'chưa thấy comment chữ'}, ${anhA == null ? '?' : anhA}/${soA} comment ảnh — cần kiểm tra`);
      } else ghiChu.push('không kiểm chứng được comment qua API');
      capNhatNgay(dd.ngay, (x) => { const r = (x.lich || {})[dd.ngoaiK]; if (r) { r.cmt = { luc: Date.now(), ok: okC && !ghiChu.length, ghiChu, anh: anhA || 0, anhCan: (dd.cmtsGoc || dd.cmts || []).filter((x) => x.k === 'anh').length }; r.cmtDang = false; } x.doLuc = 0; });
      luu('dang_do', null);
      if (dd.viaLink) setTimeout(veTrang, 4000);
      ghi(ghiChu.length ? `Xong comment ${dd.ten}, có lưu ý: ${ghiChu.join('; ')}` : `Xong comment ${dd.ten} (${(dd.cmts || []).length} comment)`);
      if (ghiChu.length) await baoLark(`⚠ ${dd.ten}: đã comment nhưng ${ghiChu.join('; ')}${dd.link ? ' — ' + dd.link : ''}`, { batBuoc: true });
      return;
    }
    for (const [ten, kq] of [['bài', dd.camXucBai], ['comment', dd.camXucCmt]]) if (kq && kq.tt === 'chua') ghi('Chưa thả được cảm xúc cho ' + ten + ' (' + kq.loi + ') — lượt quét sẽ thả bù, không báo nhóm');
    // xác nhận lại qua Facebook API: bài + số comment ảnh
    let id = '', link = dd.link || '', anhApi = null, textThay = null;
    const soAnhGui = (dd.cmts || []).filter((x) => x.k === 'anh').length - (dd.anhLoi || 0) + (dd.anhCoSan || 0);
    const textCan = (dd.cmtsGoc || dd.cmts || []).find((x) => x.k === 'text');
    if (coApi() && (dd.cmts || []).length) {
      for (let lan = 0; lan < 3; lan++) {
        if (lan) await sleep(10000);
        try {
          const p = baiGiongNhat(await baiTrenTrangApi(Date.now() - 864e5), dd.bai); if (!p) continue;
          id = p.id; link = p.link || link;
          const cs = await cmtChiTietApi(id); anhApi = cs.anh; textThay = textCan ? cs.msgs.some((c) => khopCmt(c, textCan.v)) : null;
          if ((!textCan || textThay) && cs.anh >= soAnhGui) break;
        } catch (e) { ghi('Không xác nhận được comment qua API: ' + e.message); break; }
      }
      if (textCan && textThay === false) ghiChu.push('API chưa thấy comment chữ — cần kiểm tra');
      if (anhApi !== null && anhApi < soAnhGui) ghiChu.push(`API thấy ${anhApi}/${soAnhGui} comment ảnh — cần kiểm tra`);
      if (anhApi === null && id === '') ghiChu.push('không kiểm chứng được comment qua API — cần kiểm tra');
    }
    capNhatNgay(ngay, (x) => {
      x.b23 = x.b23 || {}; const r = x.b23[dd.k] || { tt: 'xong', luc: Date.now(), hang: dd.hang };
      Object.assign(r, { tt: 'xong', id: id || r.id || '', link: link || r.link || '', ghiChu, soAnh: dd.soAnh, soNhom: dd.soNhom || r.soNhom, cmtCan: { anh: (dd.cmtsGoc || dd.cmts || []).filter((x) => x.k === 'anh').length } });
      const canAnh = (dd.cmtsGoc || dd.cmts || []).filter((y) => y.k === 'anh').length;
      r.anhOk = [...new Set((r.anhOk || []).concat(dd.anhOk || []))];
      if (!r.anhToks) r.anhToks = (dd.cmtsGoc || dd.cmts || []).filter((y) => y.k === 'anh').map((y) => y.v);
      if (!r.textBai) r.textBai = dd.bai; if (r.cmtText == null && textCan) r.cmtText = textCan.v;
      if ((!textCan || textThay) && (anhApi === null ? !(dd.anhLoi > 0) : anhApi >= canAnh) && id) r.cmt = { luc: Date.now(), anh: anhApi || 0 };
      x.b23[dd.k] = r; x.doLuc = 0;
    });
    luu('dang_do', null);
    if (dd.viaLink) setTimeout(veTrang, 4000);
    const phan = `Bài ${dd.loai} đăng lúc ${dd.lucDang || gioStr(new Date())}`;
    ghi(ghiChu.length ? `Xong Bài ${dd.loai}, có lưu ý: ${ghiChu.join('; ')}` : `Xong Bài ${dd.loai} hàng ${dd.hang}`);
    if (ghiChu.length) await baoLark(`⚠ ${phan} — ${ghiChu.join('; ')}`);
    else if (dd.thu || daBaoTuanDau() || laNgayThuB23(ngay)) await baoLark(`✅ ${phan}${dd.soNhom ? ` · ${dd.soNhom} nhóm` : ''} · ${(dd.cmtsGoc || dd.cmts || []).length} comment${anhApi !== null && soAnhGui ? ` (${anhApi} ảnh)` : ''}`);
  }


  // =====================================================================
  //  Nhịp chạy chính (15 giây/lần)
  // =====================================================================
  let dangChay = false; let nhipBatDau = 0, baoTreo = 0;
  // ===== 2.2: video / manifest do nhân sự đăng — script tự kiểm 30 phút/lần đến khi thấy bài =====
  let lichDaKiemTrangNay = false;
  async function doLichNgoai(ep = false) {
    if (!coApi()) { if (ep) ghi('Kiểm bài: chưa cài mã khoá nên chưa tự kiểm được video/manifest — hãy bấm Tick tay'); return; }
    const ngay = homNay(); const m = phutTrongNgay(new Date());
    const s = lay('ngay_' + ngay, null); if (!s) return;
    const lich = s.lich || {};
    const tre = ep ? 0 : CAI_DAT.LICH_KIEM_SAU_PHUT;
    const cho = CAI_DAT.LICH_NGOAI.filter((x) => !(lich[x.k] && !lich[x.k].tay) && m >= docGio(x.gio) + tre);
    if (!cho.length) return;
    // kiểm khi: đủ 30 phút từ lần trước, HOẶC có ô vừa tới giờ kiểm kể từ lần trước, HOẶC vừa tải lại trang (F5) / bấm ↻
    const lanTruoc = s.lichLuc || 0; const vuaTaiTrang = !lichDaKiemTrangNay;
    const oMoiToi = cho.some((x) => lucPhut(docGio(x.gio) + CAI_DAT.LICH_KIEM_SAU_PHUT) > lanTruoc);
    if (!ep && !(Date.now() - lanTruoc >= (conBaiCuoi() ? 3 : CAI_DAT.LICH_KIEM_PHUT) * 60000 || oMoiToi || (vuaTaiTrang && Date.now() - lanTruoc >= 60000))) return;
    lichDaKiemTrangNay = true;
    capNhatNgay(ngay, (x) => { x.lichLuc = Date.now(); });
    let ds;
    try { ds = await baiTrenTrangApi(new Date(new Date().setHours(0, 0, 0, 0)).getTime()); }
    catch (e) { capNhatNgay(ngay, (x) => { x.lichLuc = Date.now() - 25 * 60000; }); ghi('Kiểm video/manifest: chưa đọc được bài trên trang (' + e.message + ') — 5 phút sau thử lại'); return; }
    const dung = new Set(Object.values(lich).map((r) => r.id).filter(Boolean));
    const manifest = ds.filter((p) => thuong(p.text).includes(CAI_DAT.QUET_LOAI_TRU)).sort((a, b) => a.luc - b.luc);
    const video = ds.filter((p) => !thuong(p.text).includes(CAI_DAT.QUET_LOAI_TRU) && laVideoApi(p) === true).sort((a, b) => a.luc - b.luc);
    const kq = {};
    for (const [loai, bai] of [['video', video], ['manifest', manifest]]) {
      const conLai2 = bai.filter((p) => !dung.has(p.id));
      for (const x of CAI_DAT.LICH_NGOAI.filter((y) => y.loai === loai)) {
        if (m < docGio(x.gio) + tre) break; // chưa tới giờ thì chưa nhận bài cho ô này (giữ đúng thứ tự)
        const r = lich[x.k];
        if (r && r.id) continue;
        const p = conLai2.shift();
        if (p) kq[x.k] = { luc: p.luc, id: p.id, link: p.link, tay: false };
        else if (r) conLai2.length = conLai2.length; // ô đã tick tay, chưa có bài để ghép
      }
    }
    ghi(`Kiểm video/manifest: đọc ${ds.length} bài hôm nay (${video.length} video, ${manifest.length} manifest); ${Object.keys(kq).length ? 'ghép được ' + Object.keys(kq).length + ' ô' : 'chưa có ô mới'}`);
    const ks = Object.keys(kq);
    if (ks.length) {
      capNhatNgay(ngay, (x) => { x.lich = x.lich || {}; ks.forEach((k) => { x.lich[k] = kq[k]; }); });
      ghi('Kiểm trên trang: thấy ' + ks.map((k) => (CAI_DAT.LICH_NGOAI.find((y) => y.k === k) || {}).ten + ' lúc ' + gioStr(new Date(kq[k].luc))).join(', '));
    }
  }


  // ===== 3.1: video / manifest do nhân sự đăng → script tự comment: chữ cố định (như Bài 3) → ảnh ô O2 → 1 ảnh ngẫu nhiên trong 5 ô =====
  async function taoCmtLichNgoai() {
    if (!laTabChinh() || !coApi() || lay('tam_dung', false) || lay('dang_do', null) || lay('soan_thu', null) || lay('b23_cho_tay', null) || dangBan || demNguocDen) return;
    const ngay = homNay(); const s = lay('ngay_' + ngay, null); if (!s || !s.lich) return;
    const kDen = Object.keys(s.lich).find((k) => { const r = s.lich[k]; return r && r.id && !r.tay && !r.cmt && !r.cmtDang && Date.now() - (r.luc || 0) > 3 * 60000 && Date.now() - (r.luc || 0) < 20 * 3600e3 && Date.now() - (r.cmtThuLuc || 0) > 10 * 60000; });
    if (!kDen) return;
    const r = s.lich[kDen]; const cfg = CAI_DAT.LICH_NGOAI.find((x) => x.k === kDen); if (!cfg) return;
    capNhatNgay(ngay, (x) => { x.lich[kDen].cmtThuLuc = Date.now(); });
    let p;
    try { p = (await baiTrenTrangApi(new Date(new Date().setHours(0, 0, 0, 0)).getTime())).find((b) => b.id === r.id); } catch (e) { ghi(`Comment ${cfg.ten}: chưa đọc được bài trên trang (${e.message}) — thử lại sau`); return; }
    const laReel = (l) => /\/(reel|reels|videos|watch)\b/i.test(String(l || ''));
    if (p && !chuan(p.text) && laReel(p.link || r.link)) ghi(`Comment ${cfg.ten}: bài không có chữ mô tả nhưng là video/reel → comment qua trang riêng của bài`);
    else if (!p || !chuan(p.text)) { capNhatNgay(ngay, (x) => { x.lich[kDen].cmt = { luc: Date.now(), ok: false, ghiChu: ['bài không có chữ mô tả nên script không tìm được ô bình luận — cần comment tay'] }; }); ghi(`Comment ${cfg.ten}: bài không có chữ mô tả → bỏ qua, cần comment tay`); await baoLark(`${cfg.ten} ngày ${ngay} chưa comment được vì bài không có chữ mô tả — cần comment tay${r.link ? ' — ' + r.link : ''}`, { batBuoc: true }); return; }
    // nhân sự đã comment đủ rồi thì thôi
    try { const cs = await cmtChiTietApi(p.id); if (CAI_DAT.CMT_BAI3 && cs.msgs.some((c) => khopCmt(c, CAI_DAT.CMT_BAI3))) { capNhatNgay(ngay, (x) => { x.lich[kDen].cmt = { luc: Date.now(), ok: true, ghiChu: [], coSan: true, anh: cs.anh }; }); ghi(`Comment ${cfg.ten}: đã có comment chữ trên bài → không comment lại`); return; } } catch (e) { /* vẫn thử comment */ }
    const v = await docSheet().catch((e) => { ghi(`Comment ${cfg.ten}: không đọc được sheet (${e.message}) — thử lại sau`); return null; }); if (!v) return;
    const chung = anhChung(v); const cmts = []; const ghiChuTruoc = [];
    if (CAI_DAT.CMT_BAI3) cmts.push({ k: 'text', v: CAI_DAT.CMT_BAI3 });
    if (chung.co) cmts.push({ k: 'anh', v: chung.co }); else ghiChuTruoc.push('ô O2 (ảnh cố định) đang trống');
    if (chung.pool.length) cmts.push({ k: 'anh', v: chung.pool[Math.floor(Math.random() * chung.pool.length)] }); else ghiChuTruoc.push('các ô P2, Q2, O3, P3, Q3 (ảnh ngẫu nhiên) đang trống');
    const dd = { loai: 9, ngoai: true, ngoaiK: kDen, ten: cfg.ten, k: 'ngoai|' + kDen, ngay, hang: 0, khoa: ngay + '|ngoai|' + kDen, bai: p.text, id: p.id, link: p.link || r.link || '', cmts, cmtIdx: 0, soAnh: 0, ghiChuTruoc, luc: Date.now(), buoc: 'cho_binh_luan' };
    capNhatNgay(ngay, (x) => { x.lich[kDen].cmtDang = true; });
    luu('dang_do', dd);
    if (dd.link && /^https?:/.test(dd.link)) { // bài nhân sự đăng đã nằm sâu dưới các bài mới → mở thẳng link bài cho chắc
      dd.viaLink = dd.link; luu('dang_do', dd);
      ghi(`${cfg.ten}: bắt đầu comment (${cmts.length} comment) — mở thẳng link bài: ${dd.link}`);
      await sleep(1500); roiTrang(dd.link); return;
    }
    ghi(`${cfg.ten}: bắt đầu comment (${cmts.length} comment) — tải lại trang để thấy bài`);
    await sleep(1500); roiTrang();
  }


  // ===== 3.7: rà soát định kỳ — bài nào thiếu comment thì gửi bù (ít gọi API, giờ ngẫu nhiên) =====
  function gioRaSoat(ngay) {
    const s = lay('ngay_' + ngay, null); if (s && s.rs && s.rs.gio) return s.rs.gio;
    const gio = CAI_DAT.RA_SOAT_GIO.map(([h, m]) => h * 60 + m + Math.floor(Math.random() * 4)).sort((a, b) => a - b);
    capNhatNgay(ngay, (x) => { x.rs = { gio, lan: 0, kq: {}, thatBai: 0 }; });
    ghi('Rà soát comment hôm nay lúc: ' + gio.map((m) => pad(Math.floor(m / 60)) + ':' + pad(m % 60)).join(', '));
    return gio;
  }
  function mucTieuRaSoat(s) {
    const hs = hangHomNay() || []; const out = [];
    for (const [kb, b] of Object.entries(s.bai || {})) { if (!b || !b.id || !(b.tt === 'xong' || b.tt === 'da_dang' || b.tt === 'co_san')) continue; const h = hs.find((x) => x.hang === b.hang); out.push({ key: 'b1|' + b.id, ten: 'Bài 1', id: b.id, link: b.link || '', luc: b.luc, text: h && h.cmt ? [h.cmt] : [], anhCan: 0, loai: 1, hang: b.hang }); }
    for (const [k, r] of Object.entries(s.b23 || {})) {
      if (!r || !r.id || r.tt !== 'xong' || r.tay) continue; const [loai, hang] = k.split('|'); const h = hs.find((x) => String(x.hang) === hang);
      if (loai === '2') { const ct = r.cmtText != null ? r.cmtText : (h && h.cmt2) || ''; out.push({ key: 'b23|' + k, ten: 'Bài 2', id: r.id, link: r.link, luc: r.luc, text: ct ? [ct] : [], anhCan: 0, loai: 2, hang: +hang, k, textBai: r.textBai || (h && h.bai2) || '' }); }
      else out.push({ key: 'b23|' + k, ten: 'Bài 3', id: r.id, link: r.link, luc: r.luc, text: CAI_DAT.CMT_BAI3 ? [CAI_DAT.CMT_BAI3] : [], anhCan: r.anhToks ? r.anhToks.length : r.cmtCan ? r.cmtCan.anh : 0, loai: 3, hang: +hang, k, anhOk: r.anhOk || [], textBai: r.textBai || (h && h.bai3) || '' });
    }
    for (const [k, r] of Object.entries(s.lich || {})) {
      if (!r || !r.id || r.tay) continue; const cfg = CAI_DAT.LICH_NGOAI.find((x) => x.k === k); if (!cfg) continue;
      out.push({ key: 'ngoai|' + k, ten: cfg.ten, id: r.id, link: r.link, luc: r.luc, text: CAI_DAT.CMT_BAI3 ? [CAI_DAT.CMT_BAI3] : [], anhCan: (r.cmt && r.cmt.anhCan != null) ? r.cmt.anhCan : 2, loai: 9, ngoaiK: k });
    }
    return out.filter((t) => Date.now() - (t.luc || 0) > 4 * 60000 && Date.now() - (t.luc || 0) < 20 * 3600e3);
  }
  // (4.8) bài vừa đăng (5–90 phút) mà chưa xác nhận đủ comment → rà soát bù ngay, không chờ giờ cố định (tối đa 4 lần/bài, cách nhau ≥ 8 phút)
  function raSoatSom() {
    if (CAI_DAT.RA_SOAT_CMT === false) return;
    const ng = homNay(); let s = lay('ngay_' + ng, null); if (!s || !s.rs) return;
    const mu = mucTieuRaSoat(s).filter((t) => !(s.rs.kq[t.key] && s.rs.kq[t.key].ok && s.rs.kq[t.key].v === 2));
    const tre = mu.filter((t) => Date.now() - t.luc > (dangTuDongBat() ? 5 : 60) * 60000 && Date.now() - t.luc < 90 * 60000 && ((s.rs.som || {})[t.key] || { n: 0, luc: 0 }).n < 4 && Date.now() - ((s.rs.som || {})[t.key] || { luc: 0 }).luc > 8 * 60000);
    if (!tre.length) return;
    if (!laTabChinh() || lay('tam_dung', false) || lay('dang_do', null) || lay('soan_thu', null) || lay('b23_cho_tay', null) || dangBan || demNguocDen) return;
    capNhatNgay(ng, (x) => { x.rs.som = x.rs.som || {}; tre.forEach((t) => { const o = x.rs.som[t.key] || { n: 0 }; x.rs.som[t.key] = { n: o.n + 1, luc: Date.now() }; }); const g = x.rs.gio; g.splice(x.rs.lan, 0, phutTrongNgay(new Date()) - 1); x.rs.thuLuc = 0; });
    ghi('Rà soát sớm: ' + tre.map((t) => t.ten).join(', ') + ' vừa đăng mà chưa xác nhận đủ comment → kiểm và gửi bù ngay');
  }
  async function raSoatCmt(thuCong, soBai) {
    const lyDo = (x) => { if (thuCong) ghi('Rà soát comment: chưa làm được vì ' + x); return; };
    if (CAI_DAT.RA_SOAT_CMT === false) return;
    if (!laTabChinh()) return lyDo('tab này không phải tab làm việc chính');
    if (!coApi()) return lyDo('chưa có mã khoá Facebook API');
    if (lay('tam_dung', false)) return lyDo('script đang tạm dừng');
    if (lay('dang_do', null)) return lyDo('script đang bận đăng/comment bài khác');
    if (lay('soan_thu', null) || lay('b23_cho_tay', null) || dangBan || demNguocDen) return lyDo('script đang bận việc khác');
    const ngay = homNay(); if (!lay('ngay_' + ngay, null)) return lyDo('chưa có dữ liệu hôm nay');
    const gio = gioRaSoat(ngay); let s = lay('ngay_' + ngay, null); const rs = s.rs; if (!rs || rs.lan >= gio.length) return lyDo('đã rà soát đủ số lượt hôm nay');
    const m = phutTrongNgay(new Date()); if (m < gio[rs.lan] || m > 23 * 60 + 20) return lyDo('chưa tới giờ rà soát');
    if (Date.now() - (rs.thuLuc || 0) < 6 * 60000) return lyDo('vừa rà soát cách đây chưa tới 6 phút');
    capNhatNgay(ngay, (x) => { x.rs.thuLuc = Date.now(); });
    let muc = mucTieuRaSoat(s).filter((t) => !(rs.kq[t.key] && rs.kq[t.key].ok && rs.kq[t.key].v === 2) && (dangTuDongBat() || Date.now() - t.luc >= (thuCong ? 2 : 60) * 60000));
    if (soBai) muc = muc.sort((a, b) => (b.luc || 0) - (a.luc || 0)).slice(0, soBai); // (5.8) bấm tay: chỉ kiểm N bài gần nhất chưa kiểm đủ // (5.3) máy khác đang đăng: bài mới < 60 phút thì chưa gửi bù
    if (muc.some((t) => t.loai === 3)) { // (4.4) số comment ảnh cần có của Bài 3 = ô O2 + 1 ảnh ngẫu nhiên + ảnh ô O–Q của hàng, tính theo sheet MỚI NHẤT
      let vm = null; try { vm = await docSheet({ moi: true }); } catch (e1) { try { vm = await docSheet(); } catch (e2) { /* */ } }
      if (vm) { const chung = anhChung(vm); for (const t of muc) if (t.loai === 3) { const hs = hangCuaNgay(vm, ngay); const h = (t.textBai && hs.find((x) => chuan(x.bai3) === chuan(t.textBai))) || hs.find((x) => x.hang === t.hang); t.anhCan = Math.max(t.anhCan || 0, (chung.co ? 1 : 0) + (chung.pool.length ? 1 : 0) + (h ? h.anhCmt.length : 0)); t.chungMoi = chung; t.hangMoi = h || null; } }
    }
    if (!muc.length) { capNhatNgay(ngay, (x) => { x.rs.lan++; }); ghi('Rà soát comment: không còn bài nào cần kiểm'); return; }
    let thieu = [];
    for (const t of muc) {
      try {
        const cs = await cmtChiTietApi(t.id);
        const thieuText = t.text.length && !cs.msgs.some((c) => t.text.some((v) => khopCmt(c, v)));
        const thieuAnh = Math.max(0, (t.anhCan || 0) - cs.anh);
        if (!thieuText && !thieuAnh) capNhatNgay(ngay, (x) => { x.rs.kq[t.key] = Object.assign(x.rs.kq[t.key] || {}, { ok: true, v: 2, luc: Date.now() }); });
        else { thieu.push(Object.assign(t, { thieuText, thieuAnh, anhCo: cs.anh })); if (rs.kq[t.key] && rs.kq[t.key].ok) capNhatNgay(ngay, (x) => { x.rs.kq[t.key].ok = false; }); }
      } catch (e) { ghi('Rà soát comment: chưa đọc được ' + t.ten + ' (' + e.message + ')'); capNhatNgay(ngay, (x) => { x.rs.thuLuc = Date.now() + 5 * 60000; }); return; }
      await sleep(1200 + Math.floor(Math.random() * 2200));
    }
    ghi(`Rà soát comment: kiểm ${muc.length} bài, thiếu ${thieu.length}${thieu.length ? ' (' + thieu.map((t) => t.ten + (t.thieuText ? ' chữ' : '') + (t.thieuAnh ? ' ' + t.thieuAnh + ' ảnh' : '')).join('; ') + ')' : ''}`);
    s = lay('ngay_' + ngay, null);
    const sua = (t) => { const q = s.rs.kq[t.key] || {}; return q.suaVer === PHIEN_BAN ? (q.sua || 0) : 0; }; // (4.5) bản mới → được gửi bù lại từ đầu
    const het = thieu.filter((t) => sua(t) >= CAI_DAT.RA_SOAT_SUA_TOI_DA);
    for (const t of het) { const q0 = s.rs.kq[t.key] || {}; if (!q0.baoLuc || q0.baoVer !== PHIEN_BAN) { capNhatNgay(ngay, (x) => { x.rs.kq[t.key] = Object.assign(x.rs.kq[t.key] || {}, { baoLuc: Date.now(), baoVer: PHIEN_BAN }); }); await baoLark(`${t.ten}: gửi bù ${CAI_DAT.RA_SOAT_SUA_TOI_DA} lần vẫn thiếu${t.thieuText ? ' comment chữ' : ''}${t.thieuAnh ? ' ' + t.thieuAnh + ' comment ảnh' : ''} — cần comment tay${t.link ? ' — ' + t.link : ''}`, { batBuoc: true }); } }
    const t = thieu.filter((x) => sua(x) < CAI_DAT.RA_SOAT_SUA_TOI_DA).sort((a, b) => a.luc - b.luc)[0];
    if (!t) { capNhatNgay(ngay, (x) => { x.rs.lan++; }); return; }
    // gửi bù cho 1 bài (lượt kiểm sau sẽ làm bài tiếp theo)
    const cmts = []; const ghiChuTruoc = [];
    if (t.thieuText) cmts.push({ k: 'text', v: t.text[0] });
    if (t.thieuAnh) {
      let v = null; try { v = await docSheet(); } catch (e) { ghiChuTruoc.push('không đọc được sheet nên chưa gửi bù ảnh: ' + e.message); }
      if (v) {
        const chung = anhChung(v); let L = [];
        if (t.loai === 3) {
          const hs = hangCuaNgay(v, ngay); const h = t.hangMoi || (t.textBai && hs.find((x) => chuan(x.bai3) === chuan(t.textBai))) || hs.find((x) => x.hang === t.hang);
          // (4.5) biết ảnh nào đã gửi được → gửi đúng ảnh còn thiếu; không biết thì lấy các ảnh cuối
          const ok = new Set(t.anhOk || []); const thieuDs = [];
          if (chung.co && !ok.has(chung.co)) thieuDs.push(chung.co);
          if (chung.pool.length && !chung.pool.some((x) => ok.has(x))) thieuDs.push(chung.pool[Math.floor(Math.random() * chung.pool.length)]);
          if (h) for (const x of h.anhCmt) if (!ok.has(x)) thieuDs.push(x);
          if (chung.co) L.push(chung.co); if (chung.pool.length) L.push(chung.pool[Math.floor(Math.random() * chung.pool.length)]); if (h) L.push(...h.anhCmt);
          L = ok.size && thieuDs.length ? thieuDs.concat(L.filter((x) => !thieuDs.includes(x))) : L.slice(Math.max(0, L.length - t.thieuAnh));
          L = L.slice(0, t.thieuAnh);
        } else if (t.loai === 9) { if (chung.co) L.push(chung.co); if (chung.pool.length) L.push(chung.pool[Math.floor(Math.random() * chung.pool.length)]); L = L.slice(Math.max(0, L.length - t.thieuAnh)); }
        L.forEach((tk) => cmts.push({ k: 'anh', v: tk }));
      }
    }
    if (!cmts.length) { capNhatNgay(ngay, (x) => { x.rs.kq[t.key] = Object.assign(x.rs.kq[t.key] || {}, { sua: CAI_DAT.RA_SOAT_SUA_TOI_DA }); }); ghi('Rà soát: ' + t.ten + ' thiếu comment nhưng chưa có nội dung để gửi bù — ' + ghiChuTruoc.join('; ')); return; }
    let text = ''; let lk = t.link; let apiLoi = false;
    try { const p = (await baiTrenTrangApi(new Date(new Date().setHours(0, 0, 0, 0)).getTime())).find((b) => b.id === t.id); if (p) { text = p.text; lk = p.link || lk; } } catch (e) { apiLoi = true; }
    if (!chuan(text) && t.textBai) text = t.textBai; // (4.5) API không trả chữ → dùng chữ bài đã lưu lúc đăng
    if (!chuan(text) && apiLoi) { capNhatNgay(ngay, (x) => { x.rs.thuLuc = Date.now() + 5 * 60000; }); ghi('Rà soát: chưa đọc được bài qua API → thử lại sau'); return; }
    if (!chuan(text) && /\/(reel|reels|videos|watch)\b/i.test(String(lk || ''))) ghi('Rà soát: ' + t.ten + ' không có chữ mô tả nhưng là video/reel → gửi bù qua trang riêng của bài');
    else if (!chuan(text)) { capNhatNgay(ngay, (x) => { x.rs.kq[t.key] = Object.assign(x.rs.kq[t.key] || {}, { sua: CAI_DAT.RA_SOAT_SUA_TOI_DA }); }); ghi('Rà soát: ' + t.ten + ' không có chữ mô tả nên script không tìm được ô bình luận — cần comment tay'); return; }
    capNhatNgay(ngay, (x) => { x.rs.kq[t.key] = Object.assign(x.rs.kq[t.key] || {}, { sua: sua(t) + 1, suaVer: PHIEN_BAN, suaLuc: Date.now() }); });
    const dd = { loai: t.loai === 1 ? 8 : t.loai, k: t.k || t.key, ten: t.ten, ngay, hang: t.hang || 0, khoa: ngay + '|rs|' + t.key, bai: text, id: t.id, link: lk || '', cmts, cmtIdx: 0, soAnh: 0, ghiChuTruoc, luc: Date.now(), buoc: 'cho_binh_luan', raSoat: true, rsKey: t.key, anhCoSan: t.anhCo, daThaBai: true, daSuaNen: true, camXucCmt: { tt: 'bo' }, suaLan: 1 };
    luu('dang_do', dd);
    ghi(`Rà soát: gửi bù cho ${t.ten} (${cmts.length} comment)`);
    await sleep(1500);
    if (dd.link && /^https?:/.test(dd.link)) { dd.viaLink = dd.link; luu('dang_do', dd); roiTrang(dd.link); } else roiTrang();
  }
  async function hoanTatRaSoat(dd, ghiChu) {
    const goc = dd.cmts || []; let ok = false, cs = null;
    const tc = goc.find((x) => x.k === 'text'); const soA = goc.filter((x) => x.k === 'anh').length + (dd.anhCoSan || 0); // ảnh gửi lỗi vẫn tính là thiếu
    if (coApi() && dd.id) for (let lan = 0; lan < 2; lan++) { if (lan) await sleep(10000); try { cs = await cmtChiTietApi(dd.id); if ((!tc || cs.msgs.some((c) => khopCmt(c, tc.v))) && cs.anh >= soA) { ok = true; break; } } catch (e) { break; } }
    capNhatNgay(dd.ngay, (x) => {
      x.rs = x.rs || { kq: {} }; x.rs.kq = x.rs.kq || {}; x.rs.kq[dd.rsKey] = Object.assign(x.rs.kq[dd.rsKey] || {}, ok ? { ok: true, v: 2, luc: Date.now() } : {}); x.doLuc = 0;
      const kb = String(dd.rsKey || '').startsWith('b23|') ? String(dd.rsKey).slice(4) : null;
      if (kb && x.b23 && x.b23[kb] && (dd.anhOk || []).length) x.b23[kb].anhOk = [...new Set((x.b23[kb].anhOk || []).concat(dd.anhOk))];
    });
    luu('dang_do', null);
    if (dd.viaLink) setTimeout(veTrang, 4000);
    ghi(ok ? `Rà soát: đã gửi bù đủ comment cho ${dd.ten}` : `Rà soát: gửi bù cho ${dd.ten} xong nhưng chưa xác nhận đủ${ghiChu.length ? ' — ' + ghiChu.join('; ') : ''} (lượt kiểm sau sẽ xem lại)`);
  }

  // ===== 2.2: 3 bài script đăng → gửi link vào nhóm Lark ngay khi đăng xong =====
  async function baoLinkBaiScript() {
    if (!laTabChinh()) return;
    const ngay = homNay(); const s = lay('ngay_' + ngay, null); if (!s) return;
    const hs = hangHomNay() || []; const nhieu = hs.length > 1; const ds = [];
    for (const h of hs) {
      const kb = ngay + '|' + bam(h.bai); const b = (s.bai || {})[kb];
      if (b && (b.tt === 'xong' || b.tt === 'da_dang')) ds.push({ loai: 1, h, text: h.bai, r: b, luu: (f) => capNhatNgay(ngay, (x) => { if (x.bai[kb]) f(x.bai[kb]); }) });
      for (const loai of [2, 3]) {
        const k = loai + '|' + h.hang; const r = (s.b23 || {})[k];
        if (r && r.script) ds.push({ loai, h, text: loai === 2 ? h.bai2 : h.bai3, r, luu: (f) => capNhatNgay(ngay, (x) => { if (x.b23 && x.b23[k]) f(x.b23[k]); }) });
      }
    }
    for (const it of ds) {
      const r = it.r; if (r.linkBao === 'co' || Date.now() - r.luc > 12 * 3600e3) continue;
      const ten = `Bài ${it.loai}${nhieu ? ` (hàng ${it.h.hang})` : ''}`;
      const choLan = Math.min(30 * 60000, 45000 * Math.pow(2, r.linkLan || 0));
      if (!r.link && coApi() && (r.linkLan || 0) < 8 && Date.now() - (r.linkThu || 0) > choLan && Date.now() - lay('link_tim_luc', 0) > 45000) {
        luu('link_tim_luc', Date.now()); it.luu((x) => { x.linkLan = (x.linkLan || 0) + 1; x.linkThu = Date.now(); });
        const daDung = new Set(ds.map((y) => y.r.id).filter(Boolean));
        try { const p = baiGiongNhat((await baiTrenTrangApi(Date.now() - 12 * 3600e3)).filter((y) => y.luc >= (r.luc || 0) - 30 * 60000), it.text, daDung); if (p && p.link) { it.luu((x) => { x.link = p.link; x.id = p.id; }); r.link = p.link; } } catch (e) { /* thử lại lần sau */ }
      }
      if (r.link) { if (await baoLark(`Đã đăng ${ten}: ${r.link}`, { batBuoc: true })) it.luu((x) => { x.linkBao = 'co'; }); }
      else if (!r.linkBao && Date.now() - r.luc > 10 * 60000) { if (await baoLark(`Đã đăng ${ten} lúc ${gioStr(new Date(r.luc))} — chưa lấy được link, cần kiểm tra trên trang`, { batBuoc: true })) it.luu((x) => { x.linkBao = 'khong'; }); }
    }
  }

  // (5.3) Máy Giao: 1 tin duy nhất khi cả 3 bài đã lên trang
  async function tinCuoiGiao() {
    if (!LA_GIAO || !laTabChinh()) return;
    const ngay = homNay(); const s0 = lay('ngay_' + ngay, null); if (!s0 || s0.tinCuoi) return;
    const hs = hangHomNay(); if (!hs || !hs.length) return;
    const it = lichHomNay().items.filter((i) => !i.ngoai).sort((a, b) => (a.loai < b.loai ? -1 : a.loai > b.loai ? 1 : 0) || String(a.k).localeCompare(String(b.k)));
    if (!it.length || it.some((i) => !i.xong)) return;
    const coLink = (i) => /^https?:/.test(i.link || '');
    if (it.some((i) => !coLink(i)) && Date.now() - Math.max(...it.map((i) => i.luc || 0)) < 10 * 60000) return; // chờ lấy link tối đa 10 phút
    const d = new Date();
    const dong = it.map((i) => `${i.ten} (${gioStr(new Date(i.luc)).replace(':', 'h')}): ${coLink(i) ? i.link : '(chưa lấy được link)'}`);
    const ok = await baoLark(`[Máy Giao] ${d.getDate()}/${d.getMonth() + 1}/${d.getFullYear()} đã đăng xong ${it.length} bài fb:\n${dong.join('\n')}`, { tinCuoi: true, batBuoc: true });
    if (ok) capNhatNgay(ngay, (x) => { x.tinCuoi = Date.now(); });
  }
  // (5.3) Máy Cao (đang tạm dừng đăng): từ 08:00 mà Máy Giao chưa đăng đủ 3 bài thì báo nhóm Lark cũ
  async function kiemMayGiao() {
    if (LA_GIAO || dangTuDongBat() || !laTabChinh()) return;
    const ngay = homNay(); const m = phutTrongNgay(new Date());
    if (m < docGio(CAI_DAT.GIO_KIEM_GIAO) || m >= docGio(CAI_DAT.GIO_CHOT)) return;
    const s = lay('ngay_' + ngay, null); if (!s || s.baoGiao8) return;
    const hs = hangHomNay(); if (!hs || !hs.length) return;
    if (dangBan || lay('dang_do', null)) return;
    capNhatNgay(ngay, (x) => { x.baoGiao8 = Date.now(); });
    try { await doBaiTrang({ thuCong: true }); } catch (e) { ghi('Kiểm Máy Giao: dò bài lỗi (' + e.message + ') → dùng dữ liệu đã có'); }
    const it = lichHomNay().items.filter((i) => !i.ngoai); const chua = it.filter((i) => !i.xong);
    if (!chua.length) { ghi('Kiểm Máy Giao lúc ' + gioStr(new Date()) + ': đã đủ ' + it.length + ' bài'); return; }
    await baoLark(`Đến ${gioStr(new Date())} Máy Giao mới đăng được ${it.length - chua.length}/${it.length} bài fb (chưa thấy: ${chua.map((i) => i.ten).join(', ')}) — kiểm tra Máy Giao hoặc gạt bật đăng bài ở Máy Cao`, { batBuoc: true });
  }

  async function nhip() {
    if (!(await nhanQuyen())) { if (!laTabChinh()) demNguocDen = 0; veBang(); return; }
    try {
      await theoDoi('yeucau', () => xuLyYeuCau());
      donDuLieuCu();
      await baoTinhTrangLark();
      // lịch sắp tới: 30 phút làm mới 1 lần (kể cả khi tạm dừng — chỉ đọc sheet)
      const st = lay('sap_toi', null);
      const stCu = st && st.ds && st.ds[0] && lichCu(st.ds[0].hangs); // lưu từ bản cũ, chưa đủ cột D/E/F
      const coHomNay = !!(st && st.ds && st.ds.some((x) => x.ngay === homNay())); const mmN = phutTrongNgay(new Date());
      if (!chanLark() && trongGioDocSheet() && (!st || stCu || !coHomNay || Date.now() - st.luc > CAI_DAT.SAP_TOI_LAM_MOI_PHUT * 60000)) {
        if (Date.now() - lay('sap_toi_loi_luc', 0) > 5 * 60000) await theoDoi('lammoi', () => lamMoiSapToi()).catch((e) => { luu('sap_toi_loi_luc', Date.now()); ghi('Đọc lịch sắp tới lỗi: ' + e.message); });
      }
      if (lay('tam_dung', false)) {
        const dd = lay('dang_do', null);
        if (dd && Date.now() - (dd.xacMinhDungLuc || 0) > 5 * 60000) { dd.xacMinhDungLuc = Date.now(); luu('dang_do', dd); await xuLyDangDo(); }
        return;
      }
      await guiTinCho().catch(() => {});
      if (!dangBan && !dangQuet) { if (!dangODuongSua() && lay('quet_dang_sua', 0)) luu('quet_dang_sua', 0); if (!hopSoanBai() && !hopDangDo()) window.__smhMoHop = 0; }
      if (dangODuongSua() && !dangQuet && !dangBan && document.visibilityState === 'visible' && !lay('dang_do', null) && !nhanSuDangDung()) { await theoDoi('dongsua', async () => { ghi('Đang kẹt ở màn chỉnh sửa bài → đóng lại'); await dongManHinhSua().catch(() => {}); }); }
      await theoDoi('linkbai', () => baoLinkBaiScript().catch((e) => ghi('Gửi link bài lỗi: ' + e.message)));
      if (lay('cho_nguoi', null) && !nhanSuDangDung()) luu('cho_nguoi', null);
      if (await chayRanh('dangdo', () => xuLyDangDo(), () => tenDangDo(lay('dang_do', null)))) return;
      if (await chayRanh('quet', () => tiepQuetLink())) return;
      if (await chayRanh('khanh', () => tiepKhanh()).catch((e) => { luu('khanh_dang', null); ghi(CAI_DAT.KHANH_TEN + ' lỗi: ' + e.message); return false; })) return;
      if (lay('lark_phuc_hoi', 0)) {
        luu('lark_phuc_hoi', 0); await lamMoiSapToi();
        capNhatNgay(homNay(), (x) => { x.gThuLuc = 0; });
        await kiemTruoc(ngayMai()); await capNhatCotG();
      }
      if (await theoDoi('soanthu', () => soanThuLuong())) return;
      if (await chayRanh('tukiem', () => tuKiem())) return;
      // Kiểm sheet của ngày mai: từ 14h kiểm lần đầu; đã có cảnh báo thiếu thì kiểm lại 30 phút/lần ở MỌI giờ,
      // và kiểm lại ngay khi lần đọc sheet mới nhất thấy ngày mai đã đủ (để xoá cảnh báo cũ)
      {
        const km = lay('kiem_' + ngayMai(), null);
        const denHan = km && !km.ok && (daQuaMoc(km.lanKiem) || (km.choAnh && phutTrongNgay(new Date()) >= docGio(CAI_DAT.GIO_BAO_ANH)));
        const stMoi = lay('sap_toi', null);
        const nMai = stMoi && !stMoi.loiCot && (stMoi.ds || []).find((x) => x.ngay === ngayMai());
        const maiDaDu = km && !km.ok && nMai && stMoi.luc > (km.lanKiem || 0) && !thieuCuaNgay(nMai, true).length;
        if (!chanLark() && trongGioDocSheet() && ((phutTrongNgay(new Date()) >= docGio(CAI_DAT.GIO_KIEM_TRUOC) && !km) || denHan || maiDaDu)) await theoDoi('kiemsheet', () => kiemTruoc(ngayMai()));
      }
      await chayRanh('quet', () => quetNeuDenHan());
      await theoDoi('tongket', () => tongKet());
      await theoDoi('bao8', () => baoCaoNgay().catch((e) => ghi('Báo cáo ngày lỗi: ' + e.message)));
      await theoDoi('baocao', () => baoCaoTuan().catch((e) => ghi('Báo cáo tuần lỗi: ' + e.message)));
      if (await chayRanh('khanh', () => khanhTuan()).catch((e) => { luu('khanh_dang', null); ghi(CAI_DAT.KHANH_TEN + ' lỗi: ' + e.message); return false; })) return;
      await chayRanh('dang1', () => vongDang());
      await theoDoi('dangb23', () => tiepSauThuB23());
      await chayRanh('dangb23', () => vongDangB23());
      await theoDoi('dobai', () => doBaiTrang());
      await theoDoi('lichngoai', () => doLichNgoai().catch((e) => ghi('Kiểm video/manifest lỗi: ' + e.message)));
      await theoDoi('taianh', () => taiTruocAnh().catch((e) => ghi('Tải sẵn ảnh lỗi: ' + e.message)));
      await theoDoi('taianh', () => taiTruocAnhMai().catch((e) => ghi('Tải sẵn ảnh ngày mai lỗi: ' + e.message)));
      await theoDoi('tincuoi', () => tinCuoiGiao().catch((e) => ghi('Tin cuối Máy Giao lỗi: ' + e.message)));
      await theoDoi('giao', () => kiemMayGiao().catch((e) => ghi('Kiểm Máy Giao lỗi: ' + e.message)));
      await chayRanh('cmtlich', () => taoCmtLichNgoai().catch((e) => ghi('Comment video/manifest lỗi: ' + e.message)));
      raSoatSom();
      await chayRanh('rasoat', () => raSoatCmt().catch((e) => ghi('Rà soát comment lỗi: ' + e.message)));
      await nhacGioBai23();
      await theoDoi('cotg', () => capNhatCotG());
      await nhacGiaHanMa();
      donDuLieuCu();
      await nhacBai23();
    } catch (e) {
      if (e instanceof LoiTamHoan) ghi('Tạm hoãn: ' + e.message); else { ghi('Lỗi không lường trước: ' + e.message); chupLoi('nhịp chính'); }
    } finally {
      { const h = lay('hoat_dong', null); if (h && !hdChay && Date.now() - (h.cap || 0) > 4 * 60000) luu('hoat_dong', null); }
      await baoTinhTrangLark().catch(() => {});
      dangChay = false; if (laTabChinh()) giuKhoa(); veBang();
    }
  }

  // Tab vừa hiện lại (Cao mở cửa sổ Facebook lên) → nhận việc và chạy ngay
  document.addEventListener('visibilitychange', () => {
    if (document.visibilityState !== 'visible') return;
    giuKhoa(); veBang(); setTimeout(nhip, 800);
  });

  // ===== 2.6: nút "Gắn vị trí & thẻ" trong khung đăng Thước phim (KHÔNG bấm Đăng) =====
  const GAN = {
    VI_TRI: 'Sơn Mộc Hương',
    THE: [
      'Bí kíp chọn vòng trầm hương 108 hạt giá bao nhiêu cho người mua lần đầu',
      'Vì sao cùng là vòng trầm hương 108 hạt nhưng giá lại chênh lệch rất lớn',
      'Làm sao biết giá vòng trầm hương 108 hạt có hợp lý hay không',
      'Hướng dẫn cách xem giá vòng trầm hương 108 hạt chuẩn xác để không bị mua hớ',
      'Vòng trầm hương 108 hạt tự nhiên giá bao nhiêu là hợp lý',
      'Vòng trầm hương 108 hạt giá bao nhiêu mới đúng giá trị',
      'Hướng dẫn cách xem giá vòng trầm hương 108 hạt cho người mới chơi trầm',
      'Tại sao cùng là vòng trầm hương 108 hạt nhưng giá lại khác nhau?',
    ],
  };
  const ganDsThe = () => { const v = lay('gan_the', null); return Array.isArray(v) && v.length ? v : GAN.THE; };
  const ganThay = (el) => {
    if (!(el && el.getClientRects().length && getComputedStyle(el).visibility !== 'hidden')) return false;
    if (el.closest('[aria-hidden="true"]')) return false;
    const r = el.getBoundingClientRect();
    return r.width > 0 && r.height > 0 && r.right > 0 && r.bottom > 0 && r.left < window.innerWidth && r.top < window.innerHeight;
  };
  const ganNut = (txt) => [...document.querySelectorAll('[role=button],button')].find((b) => ganThay(b) && (chuan(b.innerText) === txt || b.getAttribute('aria-label') === txt));
  const ganNutTiep = () => {
    const nfc = (t) => String(t || '').normalize('NFC').replace(/\s+/g, ' ').trim();
    const ung = [...document.querySelectorAll('[aria-label],[role=button],button,span,div')].filter((e) => ganThay(e) && (nfc(e.getAttribute('aria-label')) === 'Tiếp' || (e.children.length === 0 && nfc(e.innerText) === 'Tiếp')));
    const ds = [];
    for (const e of ung.reverse()) { const b = e.closest('[role=button],button') || e; if (b.getAttribute('aria-disabled') === 'true' || b.disabled || ds.includes(b)) continue; ds.push(b); }
    const tren = ds.find((b) => { const r = b.getBoundingClientRect(); const t = document.elementFromPoint(r.left + r.width / 2, r.top + r.height / 2); return t && (b.contains(t) || t.contains(b)); });
    return tren || ds[0] || null;
  };
  const ganNutChua = (txt) => [...document.querySelectorAll('[role=button]')].find((b) => ganThay(b) && chuan(b.innerText).startsWith(txt));
  const ganO = (aria) => [...document.querySelectorAll('input')].find((i) => ganThay(i) && i.getAttribute('aria-label') === aria);
  const ganGan = (el, v) => { const p = Object.getPrototypeOf(el); const d = Object.getOwnPropertyDescriptor(p, 'value'); (d && d.set ? d.set : (x) => { el.value = x; }).call(el, v); el.dispatchEvent(new Event('input', { bubbles: true })); };
  const ganPhim = (el, key) => { for (const t of ['keydown', 'keypress', 'keyup']) el.dispatchEvent(new KeyboardEvent(t, { key, code: key === 'Enter' ? 'Enter' : 'Comma', keyCode: key === 'Enter' ? 13 : 188, which: key === 'Enter' ? 13 : 188, bubbles: true, cancelable: true })); };
  const ganBam = (el) => {
    if (!el) return;
    try { el.scrollIntoView({ block: 'center' }); } catch (e) { /* */ }
    const b = el.getBoundingClientRect();
    if (!(b.width > 0 && b.height > 0)) { el.click(); return; } // phần tử không có kích thước → bấm thường
    const x = b.left + b.width / 2, y = b.top + b.height / 2;
    const t0 = document.elementFromPoint(x, y);
    const t = t0 && (el.contains(t0) || t0.contains(el)) ? t0 : el; // (4.5) điểm giữa bị thứ khác che (vd khung popup) → bắn sự kiện thẳng vào phần tử
    const base = { bubbles: true, cancelable: true, clientX: x, clientY: y, button: 0 };
    let ok = 0;
    for (const [n, C] of [['pointerover', PointerEvent], ['mouseover', MouseEvent], ['pointerdown', PointerEvent], ['mousedown', MouseEvent], ['pointerup', PointerEvent], ['mouseup', MouseEvent], ['click', MouseEvent]]) {
      try { t.dispatchEvent(new C(n, { ...base, pointerId: 1, isPrimary: true, pointerType: 'mouse' })); ok++; } catch (e) { /* */ }
    }
    if (!ok) el.click();
  };
  // cách bấm của bản cũ (đã chạy tốt trên Facebook thật): bắn chuỗi sự kiện vào đúng thứ đang nằm tại điểm giữa nút
  const ganBamCu = (el) => { el.scrollIntoView({ block: 'center' }); const b = el.getBoundingClientRect(); const x = b.left + b.width / 2, y = b.top + b.height / 2; const t = document.elementFromPoint(x, y) || el; const base = { bubbles: true, cancelable: true, clientX: x, clientY: y, button: 0 }; for (const [n, C] of [['pointerover', PointerEvent], ['mouseover', MouseEvent], ['pointerdown', PointerEvent], ['mousedown', MouseEvent], ['pointerup', PointerEvent], ['mouseup', MouseEvent], ['click', MouseEvent]]) { try { t.dispatchEvent(new C(n, { ...base, pointerId: 1, isPrimary: true, pointerType: 'mouse' })); } catch (e) { /* */ } } };
  const ganGo = (el, v) => { el.focus(); el.select(); document.execCommand('insertText', false, v); };
  const ganCoText = (t) => [...document.querySelectorAll('span,div,h2,h1')].some((e) => ganThay(e) && e.children.length === 0 && chuan(e.innerText) === t);
  function ganManHinh() {
    if (ganCoText('Cài đặt thước phim')) return 'caidat';
    if (ganO('Thêm thẻ')) return 'the';
    if (ganO('Bạn đang ở đâu?')) return 'vitri-tim';
    const vt = [...document.querySelectorAll('[aria-label="Vị trí"]')].find(ganThay);
    if (vt && vt.closest('[role=dialog]')) return 'soan';
    return '';
  }

  async function ganViTri(bao) {
    if (ganManHinh() === 'soan') { bao('Gắn vị trí…'); ganBamCu([...document.querySelectorAll('[aria-label="Vị trí"]')].find(ganThay)); }
    const o = await cho(() => ganO('Bạn đang ở đâu?'), 8000);
    if (!o) throw new Error('không thấy ô tìm vị trí');
    ganGo(o, GAN.VI_TRI + ' ');
    const op = await cho(() => [...document.querySelectorAll('[role=option]')].find((x) => ganThay(x) && /Sơn Mộc Hương/i.test(x.innerText)), 8000);
    if (!op) throw new Error('không thấy kết quả "' + GAN.VI_TRI + '"');
    ganBamCu(op); await ganCham(1500);
    if (ganO('Bạn đang ở đâu?')) { // (4.5) chọn chưa ăn → bấm lại kiểu thường
      const op2 = [...document.querySelectorAll('[role=option]')].find((x) => ganThay(x) && /Sơn Mộc Hương/i.test(x.innerText));
      if (op2) { (op2.querySelector('[role=button]') || op2).click(); await ganCham(1500); }
    }
    const tiep = await cho(() => ganNutTiep() || ((ganManHinh() === 'the' || ganManHinh() === 'caidat') ? true : null), 12000);
    if (!tiep) throw new Error('không thấy nút Tiếp sau khi chọn vị trí');
    if (tiep === true) return;
    ganBamCu(tiep);
    await ganCham(1200);
    if (ganO('Bạn đang ở đâu?') || ganManHinh() === 'soan') { const t2 = ganNutTiep(); if (t2) { ghi('Gắn vị trí: Tiếp chưa ăn → bấm lại'); ganBam(t2); } }
  }
  async function ganThe(bao) {
    const o0 = await cho(() => ganO('Thêm thẻ'), 10000); if (!o0) throw new Error('không thấy ô Thêm thẻ');
    let i = 0;
    const dsThe = ganDsThe();
    for (const the of dsThe) {
      i++; bao(`Gắn thẻ ${i}/${dsThe.length}…`);
      const o = ganO('Thêm thẻ'); if (!o) throw new Error('mất ô Thêm thẻ ở thẻ ' + i);
      ganGo(o, the); await ganCham(500); ganPhim(o, 'Enter');
      let xong = await cho(() => { const x = ganO('Thêm thẻ'); return x && x.value === ''; }, 2000, 150);
      if (!xong) { ganGo(o, the); await ganCham(300); ganPhim(o, ','); xong = await cho(() => { const x = ganO('Thêm thẻ'); return x && x.value === ''; }, 2000, 150); }
      if (!xong) throw new Error('thẻ ' + i + ' không được nhận (đã thử Enter và dấu phẩy)');
      await ganCham(350);
    }
    const tiep = await cho(() => ganNutTiep(), 8000); if (!tiep) throw new Error('không thấy nút Tiếp sau khi gắn thẻ');
    ganBamCu(tiep);
  }
  async function ganThuNho(bao) {
    bao('Chỉnh hình thu nhỏ…');
    const sua = await cho(() => ganNut('Chỉnh sửa'), 8000); if (!sua) throw new Error('không thấy nút Chỉnh sửa hình thu nhỏ');
    ganBamCu(sua);
    const luuNut = await cho(() => ganNut('Lưu'), 8000); if (!luuNut) throw new Error('không mở được khung chỉnh hình thu nhỏ');
    await ganCham(900);
    const r = [...document.querySelectorAll('input[type=range]')].find(ganThay);
    if (r) { ganGan(r, r.min || '0'); r.dispatchEvent(new Event('change', { bubbles: true })); await ganCham(700); }
    else ghi('Gắn thẻ: không thấy thanh kéo hình thu nhỏ — giữ khung hình mặc định');
    const nutLuu = (luuNut.isConnected && ganThay(luuNut)) ? luuNut : (ganNut('Lưu') || luuNut);
    ganBamCu(nutLuu);
    // khung chỉnh hình đã đóng = đúng cái nút Lưu đó biến mất (không dò chữ 'Lưu' chung vì màn Cài đặt có thể có nút Lưu khác), hết chữ 'Đang lưu', và đã về màn Cài đặt
    const daLuu = () => !(nutLuu.isConnected && ganThay(nutLuu)) && !ganCoText('Đang lưu') && ganManHinh() === 'caidat';
    let ok = await cho(daLuu, 15000, 300);
    if (!ok) { const l2 = (nutLuu.isConnected && ganThay(nutLuu)) ? nutLuu : null; if (l2 && !ganCoText('Đang lưu')) { ghi('Gắn thẻ: hình thu nhỏ chưa lưu xong → bấm Lưu lại'); ganBam(l2); ok = await cho(daLuu, 15000, 300); } }
    if (!ok) throw new Error('hình thu nhỏ chưa lưu xong (khung chỉnh hình vẫn đang mở)');
    await ganCham(3500); // Facebook cần ~2s để lưu xong hình thu nhỏ → đứng yên, không làm gì thêm
    return !!r;
  }
  async function ganNhom(bao) {
    bao('Chọn nhóm…');
    const hang = await cho(() => ganNutChua('Chia sẻ lên nhóm'), 8000); if (!hang) throw new Error('không thấy mục Chia sẻ lên nhóm');
    const timDs = () => { const c = [...document.querySelectorAll('input[type=checkbox]')].filter((x) => ganThay(x.parentElement) && x.getAttribute('role') !== 'switch'); return c.length ? c : null; };
    let ds = null;
    const cach = [() => ganBamCu(hang), () => ganBam(hang), () => { const h = ganNutChua('Chia sẻ lên nhóm') || hang; h.click(); }, () => { const h = ganNutChua('Chia sẻ lên nhóm') || hang; const con = h.querySelector('[role=button],div,span'); (con || h).click(); }];
    for (let i = 0; i < cach.length && !ds; i++) { // (4.6) bấm bằng nhiều cách cho tới khi danh sách nhóm hiện ra
      if (i) ghi('Gắn thẻ: danh sách nhóm chưa mở → thử cách bấm khác (' + (i + 1) + '/' + cach.length + ')');
      try { cach[i](); } catch (e) { /* */ }
      ds = await cho(timDs, i === 0 ? 8000 : 5000);
    }
    if (!ds) throw new Error('không thấy danh sách nhóm');
    await ganCham(800);
    let moi = 0;
    for (const c of [...document.querySelectorAll('input[type=checkbox]')].filter((x) => x.getAttribute('role') !== 'switch')) { if (!c.checked) { c.click(); moi++; await ganCham(350); } }
    await ganCham(600);
    const tong = [...document.querySelectorAll('input[type=checkbox]')].filter((x) => x.getAttribute('role') !== 'switch' && x.checked).length;
    const xong = await cho(() => ganNut('Xong'), 5000); if (!xong) throw new Error('không thấy nút Xong của danh sách nhóm');
    ganBamCu(xong); await ganCham(900);
    return { moi, tong };
  }

  let ganDangChay = false;
  // trạng thái hiển thị của nút (5.5): từng bước có màu riêng — xong: xanh lá + dấu ✓, đang làm: vàng + vòng xoay, lỗi: đỏ + dấu ✕
  let ganTT = null; // { buoc:{vitri,the,nhom,thunho: 'cho'|'chay'|'xong'|'loi'}, chu:{}, cur, tien, loai:'chay'|'xong'|'loi', loi, mat }
  const GAN_BUOC = [['vitri', 'Vị trí'], ['the', 'Thẻ'], ['nhom', 'Nhóm'], ['thunho', 'Hình thu nhỏ']];
  const GAN_DANG = { vitri: 'gắn vị trí', the: 'gắn thẻ', nhom: 'chọn nhóm', thunho: 'sửa hình thu nhỏ' };
  const ganLam = (t) => t.charAt(0).toLowerCase() + t.slice(1);
  const ganHoa = (t) => t.charAt(0).toUpperCase() + t.slice(1);
  const ganNhan = (k) => ganHoa(String(ganTT.chu[k] || '').replace(/^Đã (gắn|chọn|sửa) /, ''));
  function ganDongChinh() {
    const t = ganTT; if (!t) return '';
    const xongK = GAN_BUOC.filter(([k]) => t.buoc[k] === 'xong' && t.chu[k]);
    const ngan = (k) => ganNhan(k);
    if (t.loai === 'xong') return 'Xong: ' + xongK.map(([k]) => ganLam(ngan(k))).join(', ') + '. Hãy kiểm tra lại rồi bấm Đăng.';
    if (t.loai === 'loi') { const k = (GAN_BUOC.find(([k2]) => t.buoc[k2] === 'loi') || [])[0]; return 'Lỗi khi ' + (k ? GAN_DANG[k] : 'thao tác') + ': ' + t.loi + '. Bấm vào đây để thử lại.'; }
    const m = (t.tien || '').match(/\d+\/\d+/);
    const cuoi = xongK.length ? xongK[xongK.length - 1][0] : null; // việc vừa xong gần nhất
    const dang = 'đang ' + (t.cur ? GAN_DANG[t.cur] : 'chuẩn bị') + (m ? ' (' + m[0] + ')' : '');
    return ganHoa((cuoi ? ganLam(t.chu[cuoi]) + ', ' : '') + dang);
  }
  const ganCham = (ms) => sleep(ms >= 3000 ? 3000 : Math.max(120, Math.round(ms * 0.5))); // (5.6) nhanh gấp đôi; riêng bước chờ lưu hình thu nhỏ giữ ~3s
  async function ganCho(fn, t, step) { let r = await cho(fn, t || 8000, step); if (!r) { await sleep(1500); r = fn(); } return r; }
  async function ganChay() {
    if (ganDangChay) return; ganDangChay = true;
    ganTT = { buoc: { vitri: 'cho', the: 'cho', nhom: 'cho', thunho: 'cho' }, chu: {}, cur: null, tien: '', loai: 'chay', loi: '', mat: 0 };
    const dat = (k, tt, chu) => { ganTT.buoc[k] = tt; if (chu) ganTT.chu[k] = chu; if (tt === 'chay') ganTT.cur = k; else if (ganTT.cur === k) ganTT.cur = null; ganTT.tien = ''; ganVe(); };
    const bao = (t) => { if (ganTT) { ganTT.tien = t; ganVe(); } };
    const kq = [];
    ghi('Gắn vị trí & thẻ: bắt đầu');
    try {
      let mh = ganManHinh();
      if (mh === 'soan' || mh === 'vitri-tim') {
        dat('vitri', 'chay'); await ganViTri(bao); kq.push('vị trí'); dat('vitri', 'xong', 'Đã gắn vị trí ' + GAN.VI_TRI); ghi('Gắn vị trí & thẻ: đã gắn vị trí'); await ganCham(1500); mh = ganManHinh();
      } else dat('vitri', 'xong', 'Vị trí đã có sẵn');
      if (mh === 'the' || (await ganCho(() => ganManHinh() === 'the', 6000))) {
        dat('the', 'chay'); await ganThe(bao); const nt = ganDsThe().length; kq.push(nt + ' thẻ'); dat('the', 'xong', 'Đã gắn ' + nt + ' thẻ'); ghi('Gắn vị trí & thẻ: đã gắn ' + nt + ' thẻ'); await ganCham(1800);
      } else dat('the', 'xong', 'Thẻ đã có sẵn');
      if (!(await ganCho(() => ganManHinh() === 'caidat', 10000))) throw new Error('chưa sang được màn Cài đặt thước phim');
      dat('nhom', 'chay'); const n = await ganNhom(bao); kq.push(n.tong + ' nhóm');
      if (!(await ganCho(() => ganManHinh() === 'caidat' && ![...document.querySelectorAll('input[type=checkbox]')].some((x) => x.getAttribute('role') !== 'switch' && ganThay(x)), 12000, 300))) throw new Error('chưa quay lại được màn Cài đặt thước phim sau khi chọn nhóm');
      dat('nhom', 'xong', 'Đã chọn ' + n.tong + ' nhóm'); ghi('Gắn vị trí & thẻ: đã chọn ' + n.tong + ' nhóm'); await ganCham(900);
      dat('thunho', 'chay'); const coRange = await ganThuNho(bao); kq.push(coRange ? 'hình thu nhỏ' : 'hình thu nhỏ (bỏ qua)');
      dat('thunho', 'xong', coRange ? 'Đã sửa hình thu nhỏ' : 'Hình thu nhỏ giữ mặc định'); ghi('Gắn vị trí & thẻ: đã xử lý hình thu nhỏ');
      ganTT.loai = 'xong';
      ghi('Gắn vị trí & thẻ xong: ' + kq.join(', ') + ' — chưa bấm Đăng');
    } catch (e) {
      const k = ganTT && ganTT.cur; if (ganTT) { if (k) ganTT.buoc[k] = 'loi'; ganTT.cur = null; ganTT.loai = 'loi'; ganTT.loi = e.message; }
      ghi('Lỗi gắn vị trí & thẻ ở bước "' + (k ? GAN_DANG[k] : 'không rõ') + '": ' + e.message + (kq.length ? ' (đã xong: ' + kq.join(', ') + ')' : '')); chupLoi('gắn vị trí & thẻ');
    } finally { ganDangChay = false; if (ganTT) ganTT.mat = 0; ganVe(); }
  }
  function ganMoSua() {
    if (document.getElementById('smhfb-gan-modal')) return;
    const m = document.createElement('div'); m.id = 'smhfb-gan-modal';
    const macDinh = !(Array.isArray(lay('gan_the', null)) && lay('gan_the', null).length);
    m.innerHTML = `<div class="hop"><h3>✎ Sửa các thẻ</h3>
      <p>Mỗi thẻ một dòng — nhấn <b>Enter</b> để xuống dòng tạo thẻ mới. Nút sẽ gắn lần lượt từng thẻ theo đúng thứ tự này.</p>
      <textarea spellcheck="false"></textarea>
      <div class="dem"></div>
      <div class="nut-h"><button class="mac">Khôi phục mặc định</button><span style="flex:1"></span><button class="huy">Hủy</button><button class="luu">Lưu thẻ</button></div></div>`;
    document.body.appendChild(m);
    const ta = m.querySelector('textarea'), dem = m.querySelector('.dem');
    ta.value = ganDsThe().join('\n');
    const doc = () => [...new Set(ta.value.split('\n').map((x) => chuan(x)).filter(Boolean))];
    const cap = () => { const n = doc().length; dem.textContent = n + ' thẻ' + (macDinh && n === GAN.THE.length ? ' (đang dùng danh sách mặc định)' : ''); };
    cap(); ta.addEventListener('input', cap);
    for (const t of ['keydown', 'keyup', 'keypress']) m.addEventListener(t, (e) => { e.stopPropagation(); if (t === 'keydown' && e.key === 'Escape') m.remove(); }, true);
    const dong = () => m.remove();
    m.addEventListener('click', (e) => { if (e.target === m) dong(); });
    m.querySelector('.huy').addEventListener('click', dong);
    m.querySelector('.mac').addEventListener('click', () => { luu('gan_the', null); ghi('Gắn thẻ: khôi phục danh sách thẻ mặc định'); ta.value = GAN.THE.join('\n'); cap(); });
    m.querySelector('.luu').addEventListener('click', () => { const ds = doc(); if (!ds.length) { dem.textContent = 'Cần ít nhất 1 thẻ'; return; } luu('gan_the', ds); ghi('Gắn thẻ: đã lưu ' + ds.length + ' thẻ mới'); dong(); ghi('Gắn thẻ: đã lưu ' + ds.length + ' thẻ mới'); });
    setTimeout(() => ta.focus(), 50);
  }
  const ganCoHop = () => !!ganManHinh() || Array.from(document.querySelectorAll('div[role="dialog"]')).some((d) => d.getBoundingClientRect().height > 100 && !d.closest('[aria-hidden="true"]') && /Tạo bài viết|Cài đặt|Chia sẻ lên nhóm|thước phim/i.test(d.innerText || ''));
  let ganHtmlCu = '';
  // người dùng bấm "Đăng" → xoá thông báo (trước đó thông báo "Xong…" được giữ nguyên)
  document.addEventListener('click', (e) => { try { if (!ganTT || ganDangChay) return; const b = e.target && e.target.closest && e.target.closest('[role=button],button'); if (b && !b.closest('#smhfb-gan-w') && chuan(b.innerText) === 'Đăng') setTimeout(() => { if (!ganDangChay) { ganTT = null; ganVe(); } }, 800); } catch (er) { /* */ } }, true);
  function ganVe() {
    let w = document.getElementById('smhfb-gan-w');
    const hien = !!ganManHinh();
    if (ganTT && !ganDangChay) { if (!ganCoHop()) { ganTT.mat = (ganTT.mat || 0) + 1; if (ganTT.mat >= 3) ganTT = null; } else ganTT.mat = 0; } // hộp đã đóng (đăng xong / đóng bỏ) → mới xoá thông báo
    if (!w) {
      const st = document.createElement('style');
      st.textContent = `#smhfb-gan-w{position:fixed;left:50%;transform:translateX(-50%);width:max-content;bottom:15.3px;z-index:2147483000;display:none;align-items:flex-end;gap:8.5px;max-width:calc(100vw - 20.4px);font-family:"Segoe UI Variable Text","Segoe UI",system-ui,sans-serif}
#smhfb-gan{display:flex;flex-direction:column;gap:7.6px;min-width:min(255px,90vw);max-width:min(780px,calc(100vw - 70px));padding:11px 17px;border-radius:13.6px;border:1.7px solid #c2418a;background:#fff;color:#7a1f55;font:700 13.9px/1.35 "Segoe UI Variable Text","Segoe UI",system-ui,sans-serif;box-shadow:0 6.8px 22.1px rgba(0,0,0,.28);cursor:pointer;transition:background .2s,border-color .2s}
#smhfb-gan:hover{background:#fdf0f7}
#smhfb-gan .gh{display:flex;align-items:center;gap:8.5px;justify-content:center}#smhfb-gan .gh i{font-style:normal;font-size:20.4px}
#smhfb-gan .gx{margin-left:auto;border:0;background:transparent;color:inherit;font-size:22px;line-height:1;cursor:pointer;padding:4px 8px;border-radius:8px;opacity:.75}#smhfb-gan .gx:hover{background:rgba(0,0,0,.06)}#smhfb-gan .gx:hover{opacity:1}
#smhfb-gan .gb{display:flex;flex-wrap:wrap;gap:6.8px;justify-content:center}
#smhfb-gan .gc{display:inline-flex;align-items:center;gap:6px;padding:4.2px 10.2px 4.2px 6px;border-radius:849.1px;border:1.7px solid #d8d2c4;background:#faf8f3;color:#6b665a;font-size:12.8px;font-weight:700;white-space:nowrap}
#smhfb-gan .gc .ic{width:18.7px;height:18.7px;border-radius:50%;flex:none;display:inline-flex;align-items:center;justify-content:center;font-size:11.9px;line-height:1;color:#fff;border:1.7px solid #cfc8b8;background:#fff}
#smhfb-gan .gc.xong{border-color:#2e9d57;background:#e6f6ec;color:#1c6b3a}#smhfb-gan .gc.xong .ic{background:#2e9d57;border-color:#2e9d57}
#smhfb-gan .gc.chay{border-color:#e0a21a;background:#fff3d1;color:#7a5410}#smhfb-gan .gc.chay .ic{border:2.5px solid #f1d38a;border-top-color:#e0a21a;background:transparent;animation:smhfbGan .9s linear infinite}
#smhfb-gan .gc.loi{border-color:#d93a3a;background:#fdeaea;color:#9c2323}#smhfb-gan .gc.loi .ic{background:#d93a3a;border-color:#d93a3a}
#smhfb-gan .gd{font-size:13.9px;font-weight:700;text-align:center;white-space:normal}
#smhfb-gan.chay{background:#fff9e8;border-color:#e0a21a;color:#7a5410;cursor:progress}
#smhfb-gan.xong{background:#eefaf2;border-color:#2e9d57;color:#1c6b3a;cursor:default}
#smhfb-gan.loi{background:#fff1f0;border-color:#d93a3a;color:#9c2323}
#smhfb-gan.chay .gd:after{content:"";display:inline-block;width:1.4em;text-align:left;animation:smhfbCham 1.2s steps(4,end) infinite}
@keyframes smhfbGan{to{transform:rotate(360deg)}}@keyframes smhfbCham{0%{content:""}25%{content:"."}50%{content:".."}75%{content:"..."}}
#smhfb-gan-sua{width:44px;height:44px;border-radius:50%;border:1.7px solid #c2418a;background:#fff;color:#7a1f55;font-size:20px;line-height:1;cursor:pointer;box-shadow:0 3.4px 10.2px rgba(0,0,0,.22);padding:0;display:flex;align-items:center;justify-content:center;flex:none}
#smhfb-gan-sua:hover{background:#fdf0f7}#smhfb-gan-sua:disabled{opacity:.45;cursor:not-allowed}
#smhfb-gan-modal{position:fixed;inset:0;z-index:2147483600;background:rgba(0,0,0,.45);display:flex;align-items:center;justify-content:center;padding:16px}
#smhfb-gan-modal .hop{background:#fff;color:#222;border-radius:16px;padding:20px 22px;width:min(640px,100%);box-shadow:0 12px 40px rgba(0,0,0,.35);font:15px/1.45 system-ui,sans-serif}
#smhfb-gan-modal h3{margin:0 0 6px;font-size:19px;color:#7a1f55}#smhfb-gan-modal p{margin:0 0 10px;color:#555;font-size:14px}
#smhfb-gan-modal textarea{width:100%;box-sizing:border-box;height:260px;resize:vertical;border:2px solid #d9d2c4;border-radius:12px;padding:10px 12px;font:15px/1.5 system-ui,sans-serif;color:#222;background:#fffdf8}
#smhfb-gan-modal textarea:focus{outline:none;border-color:#c2418a}#smhfb-gan-modal .dem{margin:6px 2px 12px;font-size:13.5px;color:#7a5410;font-weight:700}
#smhfb-gan-modal .nut-h{display:flex;gap:10px;align-items:center}#smhfb-gan-modal button{font:700 14.5px system-ui,sans-serif;border-radius:10px;padding:9px 16px;border:2px solid #d9d2c4;background:#f6f3ec;color:#444;cursor:pointer}
#smhfb-gan-modal button.luu{background:#c2418a;border-color:#c2418a;color:#fff}#smhfb-gan-modal button:hover{filter:brightness(.96)}`;
      document.head.appendChild(st);
      w = document.createElement('div'); w.id = 'smhfb-gan-w';
      w.innerHTML = '<div id="smhfb-gan"></div><button id="smhfb-gan-sua" title="Sửa nội dung các thẻ" aria-label="Sửa nội dung các thẻ">✎</button>';
      w.querySelector('#smhfb-gan').addEventListener('click', (e) => {
        if (e.target.closest && e.target.closest('.gx')) { if (!ganDangChay) { ganTT = null; ganVe(); } return; }
        if (ganDangChay) return;
        if (ganTT && ganTT.loai === 'xong') return; // đã xong: giữ nguyên thông báo, tránh gắn thẻ trùng
        ganChay();
      });
      w.querySelector('#smhfb-gan-sua').addEventListener('click', () => { if (!ganDangChay) ganMoSua(); });
      document.body.appendChild(w);
    }
    const nut = document.getElementById('smhfb-gan');
    let html, lop;
    if (ganTT) {
      lop = ganTT.loai;
      const chip = (k, ten) => { const tt = ganTT.buoc[k]; const ic = tt === 'xong' ? '✓' : tt === 'loi' ? '✕' : tt === 'chay' ? '' : ''; const nhan = tt === 'xong' && ganTT.chu[k] ? ganNhan(k) : ten; return `<span class="gc ${tt === 'cho' ? '' : tt}"><span class="ic">${ic}</span>${esc(nhan)}</span>`; };
      html = `<div class="gh"><i>${lop === 'xong' ? '✅' : lop === 'loi' ? '⚠️' : '📍'}</i><span>Gắn vị trí &amp; thẻ</span>${lop === 'chay' ? '' : '<button class="gx" title="Ẩn thông báo">✕</button>'}</div><div class="gb">${GAN_BUOC.map(([k, ten]) => chip(k, ten)).join('')}</div><div class="gd">${esc(ganDongChinh())}</div>`;
    } else { lop = ''; html = '<div class="gh"><i>📍</i><span>Gắn vị trí &amp; thẻ</span></div>'; }
    if (html !== ganHtmlCu) { nut.innerHTML = html; ganHtmlCu = html; }
    nut.className = lop;
    w.querySelector('#smhfb-gan-sua').disabled = ganDangChay;
    w.querySelector('#smhfb-gan-sua').style.display = (ganTT && ganTT.loai === 'xong') ? 'none' : '';
    w.style.display = (hien || ganDangChay || ganTT || document.getElementById('smhfb-gan-modal')) ? 'flex' : 'none';
  }
  setInterval(() => { try { ganVe(); } catch (e) { /* */ } }, 1000);

  let demGiay = 0;
  setInterval(() => { // (5.8) chống treo giữa chừng
    try {
      if (!dangChay || !nhipBatDau || Date.now() - nhipBatDau < 20 * 60000) return;
      if (Date.now() - baoTreo > 10 * 60000) { baoTreo = Date.now(); ghi('Lỗi: một lượt làm việc bị treo hơn 20 phút' + (lay('dang_do', null) ? ' (đang dở: ' + tenDangDo(lay('dang_do', null)).replace(/^Đang /, '') + ')' : '') + ' → tải lại trang để làm tiếp'); chupLoi('treo giữa chừng'); }
      if (document.visibilityState === 'visible' && !nhanSuDangDung()) roiTrang();
    } catch (e) { /* */ }
  }, 30000);
  // tab bị ẩn thì không vẽ lại khung (nhẹ máy); vẫn giữ quyền làm việc
  setInterval(() => { demGiay++; if (demGiay % 5 === 0 || document.visibilityState !== 'visible') giuKhoa(); if (document.visibilityState !== 'visible') return; if (demGiay % 10 === 0) veBang(); else capNhatDongHo(); }, 1000);
  setInterval(nhip, 15000);
  setTimeout(nhip, 4000);
  if (!lay('lan_dau_chay', 0)) luu('lan_dau_chay', Date.now());
  chuyenNhatKyCu();
  trangThaiNgay(homNay()); // tạo sẵn giờ đăng hôm nay để hiện trên popup
  try { gioB23(homNay(), 2); gioB23(homNay(), 3); } catch (e) { /* */ }
  veBang();
  { let kieu = ''; try { const nv = performance.getEntriesByType('navigation')[0]; kieu = nv ? ({ reload: 'tải lại', navigate: 'mở trang', back_forward: 'quay lại' }[nv.type] || nv.type) : ''; } catch (e) { /* */ }
    ghi(`Khởi động bản chạy thật ${(typeof GM_info !== 'undefined' && GM_info.script && GM_info.script.version) || PHIEN_BAN} · ${location.pathname.slice(0, 40)}${kieu ? ' · ' + kieu : ''}`); }
})();